internal static class MultidimEntry
{
    public static int Main(string[] arguments) => MultidimBehavior.Run(arguments);
}
