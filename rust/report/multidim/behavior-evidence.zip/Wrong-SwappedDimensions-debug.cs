using System;
using __cil_ref_53f83322a093499b35543907f3fc976c23ad5b68 = int[,];
using __cil_ref_1c43421b690cda6d33a2142a8c05b9a4f94dbdfe = double[,];
using __cil_ref_ed993ef5a865c9a54ecbded32e2ec23bfb2b8dab = string[,];
namespace MultidimCases {
public static class Grids {
public static int[,] Build(int rows, int columns)
{
    // structural signature __cil_ref_53f83322a093499b35543907f3fc976c23ad5b68 bytes=14080200020000: int32[0...,0...]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; general array reference identity (element and rank); no element, layout or bounds inference.
    __cil_ref_53f83322a093499b35543907f3fc976c23ad5b68 v2 = new int[columns, rows];
    return v2;
}


public static int Cell(int[,] grid, int i, int j)
{
    // structural signature __cil_ref_53f83322a093499b35543907f3fc976c23ad5b68 bytes=14080200020000: int32[0...,0...]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; general array reference identity (element and rank); no element, layout or bounds inference.
    int v3 = grid[i, j];
    return v3;
}


public static void Store(int[,] grid, int i, int j, int value)
{
    // structural signature __cil_ref_53f83322a093499b35543907f3fc976c23ad5b68 bytes=14080200020000: int32[0...,0...]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; general array reference identity (element and rank); no element, layout or bounds inference.
    grid[i, j] = value;
    return;
}


public static double SumDouble(double[,] grid)
{
    // structural signature __cil_ref_1c43421b690cda6d33a2142a8c05b9a4f94dbdfe bytes=140D0200020000: float64[0...,0...]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; general array reference identity (element and rank); no element, layout or bounds inference.
    double v3 = grid[0, 0];
    double v7 = grid[1, 1];
    return unchecked((double)(unchecked(v3 + v7)));
}


public static string Pick(string[,] grid, int i, int j)
{
    // structural signature __cil_ref_ed993ef5a865c9a54ecbded32e2ec23bfb2b8dab bytes=140E0200020000: string[0...,0...]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; general array reference identity (element and rank); no element, layout or bounds inference.
    string v3 = grid[i, j];
    return v3;
}


} }
