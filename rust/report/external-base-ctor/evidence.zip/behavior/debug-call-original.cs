using System;
using System.Reflection;
using System.Reflection.Emit;

public static class Recovered<TKey, TValue>
{
    static Action<RelationCases.ForeignOuter<TKey, TValue>.NestedForeign, int> SeedLeaf = MakeSeedLeaf();
    static Action<RelationCases.ForeignOuter<TKey, TValue>.NestedTyped, TValue, TKey> TypedLeaf = MakeTypedLeaf();

    static Action<RelationCases.ForeignOuter<TKey, TValue>.NestedForeign, int> MakeSeedLeaf()
    {
        var receiver = typeof(RelationCases.ForeignOuter<TKey, TValue>.NestedForeign);
        var constructor = typeof(RelationLibrary.OpBase<TValue, TKey>).GetConstructor(
            BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(int) }, null)
            ?? throw new Exception("Owned base constructor missing");
        var method = new DynamicMethod("SeedLeaf", typeof(void), new[] { receiver, typeof(int) }, typeof(Recovered<TKey, TValue>).Module, true);
        var il = method.GetILGenerator();
        il.Emit(OpCodes.Ldarg_0); il.Emit(OpCodes.Ldarg_1); il.Emit(OpCodes.Call, constructor); il.Emit(OpCodes.Ret);
        return method.CreateDelegate<Action<RelationCases.ForeignOuter<TKey, TValue>.NestedForeign, int>>();
    }

    static Action<RelationCases.ForeignOuter<TKey, TValue>.NestedTyped, TValue, TKey> MakeTypedLeaf()
    {
        var receiver = typeof(RelationCases.ForeignOuter<TKey, TValue>.NestedTyped);
        var constructor = typeof(RelationLibrary.GenericCtorBase<TValue, TKey>).GetConstructor(
            BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(TValue), typeof(TKey) }, null)
            ?? throw new Exception("Owned typed base constructor missing");
        var method = new DynamicMethod("TypedLeaf", typeof(void), new[] { receiver, typeof(TValue), typeof(TKey) }, typeof(Recovered<TKey, TValue>).Module, true);
        var il = method.GetILGenerator();
        il.Emit(OpCodes.Ldarg_0); il.Emit(OpCodes.Ldarg_1); il.Emit(OpCodes.Ldarg_2);
        il.Emit(OpCodes.Call, constructor); il.Emit(OpCodes.Ret);
        return method.CreateDelegate<Action<RelationCases.ForeignOuter<TKey, TValue>.NestedTyped, TValue, TKey>>();
    }

    static void __cil_ctor_call_0A00001A(RelationCases.ForeignOuter<TKey, TValue>.NestedForeign receiver, int seed)
        => SeedLeaf(receiver, seed);
    static void __cil_ctor_call_0A00001D(RelationCases.ForeignOuter<TKey, TValue>.NestedTyped receiver, TValue first, TKey second)
        => TypedLeaf(receiver, first, second);

    public static void RunSeed(RelationCases.ForeignOuter<TKey, TValue>.NestedForeign receiver, int seed)
    {
    // generic body context type-owner=0x0200001E type-arity=2 method-owner=0x06000068 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
    __cil_ctor_call_0A00001A(receiver, seed);
    receiver.Derived = unchecked(seed + 5);
    return;
    }
    public static void RunTyped(RelationCases.ForeignOuter<TKey, TValue>.NestedTyped receiver, TValue first, TKey second)
    {
    // generic body context type-owner=0x02000020 type-arity=2 method-owner=0x0600006A method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
    // structural signature __cil_generic_818cd0295bfe7662dfc5f0e3323abd2bb8aa95ee bytes=1301: !1; type-owner=0x02000020 method-owner=0x00000000; tokens scoped to receiver input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
    // structural signature __cil_generic_5b77c8b88251a5e84c60d40b37ac4c8d598bdc34 bytes=1300: !0; type-owner=0x02000020 method-owner=0x00000000; tokens scoped to receiver input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
    __cil_ctor_call_0A00001D(receiver, first, second);
    return;
    }
}
