# slice-17 Quality Review Summary

45 classes reviewed across 13 assemblies. 21 classes with IL fallback (93 methods total;
excluded from quality). 17 classes truncated at byte budget.

## Ranked recurring patterns

### 1. Opaque `__cil_*` / `__il_field_*` synthetic names (42 classes, ~8500 occurrences)
- `__cil_type_0100002C v1 = __cil_callvirt_0A00001F(e);` vs `SuspendingDeferral deferral = e.SuspendingOperation.GetDeferral();`
- Fix: **mostly printer-only**; auto-property recognition needs **small proof**.

### 2. `global::` and `System.Int32`/`System.String` spelling (40 classes, ~1837 occurrences)
- `global::RegularAppWithoutNotify.XamlTypeInfoProvider v1 = this._provider;` vs imported short name
- `System.String.Concat(...)` vs `string.Concat(...)`
- Fix: **printer-only**.

### 3. `goto`/label dispatch vs structured control flow (35 classes, ~1981 occurrences)
- `if (v1 is not null) { goto IL_0013; } else { goto IL_0008; }` vs `if (_provider == null) { ... }`
- `lock` via `Monitor.Enter/try/finally/goto` vs `lock(_root) { ... }`
- Fix: null-guard patterns need **small proof**; lock needs **new analysis**.

### 4. `get_`/`set_` methods vs C# property syntax (45 classes, ~503 method declarations)
- `public virtual string get_Name() { string v1 = this._name; return v1; }` vs `public string Name => _name;`
- Fix: **small proof**.

### 5. IR evidence leaked as `//` comments (39 classes, ~929 occurrences)
- `// structural signature __cil_ref_...` / `// enum storage token=...` / `// Dependency identity substituted: ...`
- Fix: **printer-only**.

### 6. Compression: `__cil_bool_store`, `ReferenceEquals`, boxing casts (38 classes, ~200 occurrences)
- `this._isAttachable = __cil_bool_store(1);` vs `_isAttachable = true;`
- `int v2 = (System.Object.ReferenceEquals(v1, null) ? 1 : 0); return (v2 == 0);` vs `return v1 != null;`
- Fix: **mostly printer-only**; null check and boxing simplification need **small proof**.

### 7. Redundant `: base()`, trailing `return;`, assign-then-return (45 classes)
- `public Baz() : base() { return; }` vs `public Baz() { }`
- `string v0 = Foo.Bar(); string v1 = v0; return v1;` vs `return Foo.Bar();`
- Fix: **printer-only** for :base()/return;; assign-then-return needs **small proof**.