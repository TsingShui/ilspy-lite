# slice-06 Summary

## Top patterns (ranked by class count)

1. **Synthetic locals/fields** — 43 classes  
   `v0..vN`, `__il_field_0400XXXX` vs named. Fix: **printer-only**.
   *Ex:* `string v0 = __cil_ldstr_70000001("foo!"); Console.WriteLine(v0);` vs `Console.WriteLine("foo!");`

2. **`get_`/`set_` methods not properties** — 15 classes  
   `public int get_Count() { return v1; }` + `// property` comment vs `public int Count => ...`  
   Fix: **printer-only**.

3. **Fully-qualified types & missing `using`** — 40 classes  
   `System.Int32.Parse(...)`, `global::NUnit...` vs short names. Fix: **printer-only**.

4. **`__cil_bool_load`/`__cil_bool_store` noise** — 32 classes  
   `__cil_bool_store(1)` vs `true`. Fix: **printer-only**.

5. **Goto/label dispatch vs `switch`/`foreach`/`while`** — 24 classes  
   `goto IL_0218;` chains vs structured. Fix: **new analysis**.

6. **`lock` → Monitor.Enter/Exit decomposition** — 10 classes  
   `Monitor.Enter(v2, ref v3);` + try/finally vs `lock (s_lock) { }`. Fix: **small proof**.

7. **`// structural signature`, `// Dependency`, `// IL fallback` comments** — 39 classes  
   Debug evidence in readable output. Fix: **printer-only**.

8. **Iterator/lambda classes not reconstructed** — 6 classes  
   `__name_3C...` state machine vs `yield return`. **Deliberate**.

9. **Field initializers in ctor vs inline** — 7 classes  
   `this._order = -1;` in ctor body vs `private int _order = -1;`. Fix: **small proof**.

10. **Empty-ctor `return;` noise** — 35 classes  
    `public X() : base() { return; }` vs elided. Fix: **printer-only**.