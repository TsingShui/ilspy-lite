# slice-07 Quality Review Summary

46 classes reviewed across 13 images. 25 classes have ours_truncated=true.

## Ranked Patterns

### 1. Synthetic names (`__cil_*`, `v0` locals, token aliases) — all 46 classes (492 occurrences)
- `__cil_ldstr_70000001("foo!")` instead of `"foo!"`; `__cil_type_0100005C` instead of resolved type name.
- **Fix**: Mostly printer-only; single-use temp→name needs small proof.

### 2. IR evidence comments in readable output — 31 classes (387 occurrences)
- `// structural signature`, `// enum storage`, `// generic body context`, `// Exact call kept`, `// Dependency identity substituted`.
- **Fix**: Printer-only.

### 3. Uncompressed IL statements — 28 classes (315 occurrences)
- Assign-then-return, `__cil_bool_load`/`__cil_bool_store` pairs, `unchecked(...)` noise, double-cast boxing chains.
- **Fix**: Small proof for single-use folding.

### 4. Fully-qualified names vs short names — 24 classes (278 occurrences)
- `System.String.op_Equality` not `==`; `System.Console.WriteLine` not `Console.WriteLine`; `global::` prefix.
- **Fix**: Printer-only for namespace; small proof for operator detection.

### 5. Goto/label dispatch vs structured control flow — 17 classes (203 occurrences)
- `if (v1 == 0) goto IL_0014; else goto IL_0009;` with unreferenced labels.
- **Fix**: Small proof for if/else; new analysis for foreach/while.

### 6. Property/member lowering — 12 classes (165 occurrences)
- `get_`/`set_` methods + `__il_field_` backing fields instead of properties; field initializers in .cctor; enum-as-class.
- **Fix**: Small proof for auto-property pattern; printer-only for enum keyword.

### 7. IL fallback blocks — 7+ classes
- `// IL fallback: EH leave must originate in a try or catch` with raw .code-bytes.
- **Fix**: New analysis (EH region reconstruction, foreach patterns, generic resolution).

### 8. Async/iterator/closure lowering — 3 classes (deliberate)
- State-machine structs with builder-pattern exposed.
- **Fix**: Deliberate — out of scope.