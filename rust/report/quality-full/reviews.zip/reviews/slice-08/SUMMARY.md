# Slice-08 Quality Review Summary

46 classes reviewed across 13 images. 4 nearly clean.

## Ranked recurring patterns (classes / 46)

1. **Synthetic vN locals** (45) -- `int v1 = unchecked((int)(this.runState));` vs `return runState;` -- printer-only or small proof

2. **__cil_ token aliases** (45) -- `__cil_ref_e7eaa... v1 = this.arguments; return v1;` vs `return arguments;` -- printer-only

3. **get_/set_ methods instead of properties** (31) -- `public int get_TestCount() { ... } // property int TestCount ...` vs `public int TestCount { get; private set; }` -- printer-only

4. **IR comments in readable output** (44) -- `// structural signature __cil_value_<hash> bytes=...` / `// enum storage token=...` vs (none) -- printer-only

5. **Fully qualified type names** (40) -- `global::System.Exception v1 = this.providerException;` vs `using System; ... Exception ProviderException => providerException;` -- printer-only

6. **unchecked(...) noise** (30) -- `int v1 = unchecked((int)(this.runState));` vs `return runState;` -- printer-only

7. **goto/label instead of structured control flow** (20) -- `if(v1==0){goto IL_0009;}else{goto IL_0008;} IL_0008: ;` vs `if(...) return ...; return ...;` -- new analysis

8. **__il_field_ backing fields** (10) -- `private int __il_field_04000002;` vs `public int TestCount { get; private set; }` -- printer-only

9. **__name_<hex> for explicit interface methods** (5) -- `__name_53797374656D2E...436F7079546F` vs `void ICollection.CopyTo(...)` -- printer-only

10. **IL fallback blocks** (20) -- `// IL fallback:\nil_0000: ldarg.0` vs pure C# decompilation -- new analysis