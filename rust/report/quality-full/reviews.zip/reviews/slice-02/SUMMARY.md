# slice-02 Quality Review Summary
46 classes, 13 images, 19 partial, 5 no-ILSpy (status 65).
## Ranked Patterns (class count, fix class)
1. Synthetic locals v0-vN – 45 classes | printer-only
   `int v1 = __cil_bool_load(System.Object.ReferenceEquals(...)); if (!(v1 == 0)) return false;`
2. goto/label dispatch – 43 classes | printer-only (if-else); new analysis (foreach)
   `goto IL_000B; ... IL_0009: ; return __cil_bool_store(v2);`
3. global:: prefix, full qual – 43 classes | printer-only
   `global::System.ArgumentOutOfRangeException`, `System.Object.ReferenceEquals`
4. IR evidence comments – 44 classes | printer-only
   `// structural signature`, `// generic body context`, `// enum storage`
5. __il_field_<token> names – 25 classes | printer-only (names); small proof (auto-prop)
   `private int __il_field_04000005;`
6. get_/set_ methods vs properties – 42 classes | printer-only
   `public int get_TestCount()` + `// property int TestCount { ... }` footer
7. __cil_{callvirt,newobj,ldstr,bool_load}_<hex> wrappers – 40+ classes | printer-only
   `__cil_callvirt_0A00004D(...)`, `__cil_ldstr_7000002B("length1")`
8. unchecked noise, one-op-per-stmt – 24 classes | printer-only
   `int v6 = unchecked(v4 * v5); int v7 = unchecked(v6 ^ v8);`
9. IL fallback .code-bytes – 24 classes | new analysis (EH); small proof (fn-ptr)
   Fault handlers, function-pointer returns dump raw IL hex
10. Hex-encoded method names – 19 classes | printer-only
    `__name_53797374656D2E...` for explicit-interface/compiler-generated methods