# Slice 19 Quality Review Summary

45 classes reviewed across 13 images (id 21-906).

1. **IR comment leakage** (41 classes, printer-only)
   `// structural signature __cil_ref_ee50d71f...` per-variable, `// enum storage token=...`.
   Fix: suppress debug comments.

2. **Synthetic __cil_* types + v0-v199 temporaries** (42 classes, printer-only)
   `__cil_type_01000025 v11 = __cil_callvirt_0A00064F(v1, v10);` vs ILSpy short names.

3. **__il_field_<token> fields instead of property names** (30 classes, small proof)
   `private int __il_field_04000005;` vs `PassCount { get; private set; }`.
   Association known from `// property` comments.

4. **get_/set_ methods not merged to properties** (20 classes, small proof)
   `public int get_PassCount() { ... }` + `// property int PassCount { get: ... }`.

5. **IL_ labels + goto dispatch** (39 classes)
   Basic if/else: printer-only. ?? / ?: merge: small proof. Switch->goto-table: new analysis.
   `goto IL_001C; ... IL_001C: ;` vs `return a ?? (b + c + d)`.

6. **unchecked(...) on every arithmetic op** (36 classes, printer-only)
   `int v4 = unchecked(v1 + v3);` vs `PassCount + ErrorCount + FailureCount`.

7. **Fully qualified names, global::, no using directives** (40 classes, printer-only)
   `global::System.Collections.Generic.List`1` vs `List<T>`; `System.String` vs `string`.

8. **__cil_ldstr / __cil_bool_load helpers** (38 classes, printer-only)
   `string v1 = __cil_ldstr_700049AE("<root>");` vs `"<root>"`.

9. **__name_<hex> for display classes & explicit interface methods** (9 classes, small proof)
   `__name_3C3E635F...` vs `<CheckXmlDoc>b__0`. Recoverable from metadata/interface mapping.

10. **System.Nullable<T> vs T?** (12 classes, printer-only)
    `System.Nullable<int> foo = 1234` vs `int? foo = 1234`.

---
IL fallback in 20 classes; ILSpy failed 4 assemblies. Most issues printer-only;
largest impact areas: properties, using directives, control-flow structuring.