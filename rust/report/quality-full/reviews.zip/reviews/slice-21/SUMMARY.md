# Slice-21 Summary (45 classes, 13 images)
8 classes have ilspy_status=65 (no ILSpy reference). Judged from ours alone.

## Ranked patterns
1. **get_/set_ for properties** (structure, all 45)
   `public bool LazyLoad { get; set; }` -> 7+ lines of accessor methods +
   `__il_field_<token>` + trailing `// property` comment. Fix: printer-only.
2. **goto/label control flow** (control_flow, ~41)
   Every if-else/while/null-check becomes `goto IL_xxxx`/label dispatch with
   unreferenced labels. 25 lines for a 3-line if-throw. Fix: new analysis.
3. **__cil_* opaque symbols** (naming, all 45)
   Types as `__cil_type_<token>`, fields as `__il_field_<token>`, methods as
   `__name_<hex>`, locals as `__cil_ref_<hash>`, generic params as
   `__cil_generic_<hash>`. `__cil_bool_load/store` round-trip. Fix: printer-only.
4. **global:: prefix** (spelling, all 45)
   `global::System.Exception` on every reference, `System.Int32` instead of
   `int`. Fix: printer-only.
5. **Redundant temporaries + unchecked(...)** (compression, ~40)
   `int v4 = unchecked(v1+v3); int v5 = unchecked(v4+v6); return v5;`
   instead of one expression. Fix: new analysis.
6. **IR comments leaked** (comments, ~30)
   `// structural signature`, `// enum storage`, `// Exact call`,
   `// generic body context`, `// Dependency identity substituted`.
   Fix: printer-only.
7. **Token-based intrinsics** (spelling, ~35)
   `__cil_newobj_<token>`, `__cil_ldstr_<token>("...")`,
   `__cil_callvirt_<token>` instead of `new`, literals, named calls.
   Fix: printer-only.
8. **Trailing return; / : base()** (compression, all 45)
   Void methods end with `return;`, default-ctors carry `: base()`.
   Fix: printer-only.
9. **Event accessor expansion** (compression, ~5)
   Field-like events print 20+ line CAS loops. Fix: new analysis.
10. **IL fallback** (other, 3)
    Unsafe ops, iterator state machines, abstract generic instantiations
    fall back to raw IL. Fix: new analysis.