# slice-03 Quality Review Summary

## Top Patterns (ranked by recurrence)

### 1. `__cil_type_*` opaque type aliases / `__cil_newobj_*` call stubs (naming)
- **Classes**: ~40/46. **Fix**: printer-only
- **Rep**: `__cil_type_01000080 v0 = __cil_newobj_0A0000B0();` vs `new DefaultSuiteBuilder()`

### 2. Compound assignment expansion (compression)
- **Classes**: ~15/46. **Fix**: small proof
- **Rep**: `int v0 = i; i = unchecked(v0 + 1);` vs `i++;`

### 3. `get_`/`set_` methods instead of properties (structure)
- **Classes**: ~25/46. **Fix**: printer-only
- **Rep**: `private string get_Report()` method body vs `private string Report => ...`

### 4. `__il_field_*` backing fields for auto-properties (naming)
- **Classes**: ~5/46. **Fix**: printer-only
- **Rep**: `private bool __il_field_040000FE;` vs `public bool CreateNoWindow { get; set; }`

### 5. `global::` fully-qualified type names (spelling)
- **Classes**: ~35/46. **Fix**: printer-only
- **Rep**: `global::ICSharpCode.Decompiler.Tests.TestCases.Pretty.CompoundAssignmentTest`

### 6. IR evidence comments (comments)
- **Classes**: ~20/46. **Fix**: printer-only
- **Rep**: `// structural signature __cil_ref_...` and `// enum storage token=0x...`

### 7. Goto/label dispatch instead of structured loops (control_flow)
- **Classes**: ~8/46. **Fix**: new analysis
- **Rep**: `while` as `goto IL_002E;` with labels; `foreach` as manual index loop

### 8. Null coalescing `??` expansion (compression)
- **Classes**: ~6/46. **Fix**: small proof
- **Rep**: explicit if/else with ssa phi temps vs `return x ?? (x = new(...));`

### 9. Enum-as-class instead of `enum` keyword (structure)
- **Classes**: ~1/46. **Fix**: printer-only

### 10. IL fallback blocks (other)
- **Classes**: ~3/46. **Fix**: varies (`// IL fallback: ...` with raw .code-bytes)