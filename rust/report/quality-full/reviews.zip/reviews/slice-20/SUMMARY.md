# Slice-20 Quality Review Summary

45 classes reviewed; 3 ILSpy-crashed (DispatchProxy inner types). 2145 findings.

## Recurring Patterns (ranked)

1. **Token-type aliases (naming)** — 45 cls. `__cil_type_01000080` vs `DefaultSuiteBuilder`. Printer-only.

2. **Token method calls (naming)** — 45 cls. `__cil_callvirt_060000BA(v1)` vs `_shortName.Value`. Printer-only.

3. **Structural signature comments (comments)** — 43 cls. `// structural signature __cil_value_...`. Printer-only: suppress IR diagnostics.

4. **Dependency substitution comment (comments)** — 40 cls. `// Dependency identity substituted: mscorlib...`. Printer-only.

5. **Empty default ctors (structure)** — 34 cls. `Foo() : base() { return; }`. Printer-only: omit compiler-default.

6. **goto/label dispatch (control_flow)** — 25 cls. `goto IL_002E; ... if(...) goto IL_0028;` vs `while(...)`. Needs new analysis: loop detection.

7. **Bool-through-int (compression)** — 22 cls. `__cil_bool_load(...) if (v2==0) return false`. Small proof: fold single-use bool temps.

8. **S0/S1 phi null-coalescing (compression)** — 20 cls. 200+ char phi dispatch vs `??`. Small proof: pattern-match two-branch result assignment.

9. **Property-comment annotation (structure)** — 18 cls. `// property string X { get: get_X; }` vs real syntax. Small proof.

10. **Field inits in ctor body (structure)** — 15 cls. `this._x = new L("X")` in body vs inline `= new L("X")`. Printer-only.

11. **Enum-as-class (spelling)** — 12 cls. `sealed class X:Enum{int value__;const X A=0;}` vs `enum X{A,B,C}`. Printer-only.

12. **IL fallback (other)** — 19 cls. Raw bytecode for entire methods. Needs new analysis: "incompatible types", "generic/external class".

13. **Missing DllImport (spelling)** — 1 cls. PInvoke extern without `[DllImport]`. Printer-only.

Top winners by impact: suppress structural signature comments + use token→name resolution (printer-only, >60% of findings). Loop detection and phi folding are the main analysis gaps.