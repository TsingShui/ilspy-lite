# Slice-18 Summary

**45 classes, 13 assemblies, 4 truncated**

1. **Fully-qualified `global::` names** (30+ classes)
   `global::...EqualConstraint v2` vs `new EqualConstraint(expected)` — **printer-only**

2. **Synthetic locals + `__cil_` wrappers** (35+ classes)
   `string v0 = __cil_ldstr("text"); throw v1;` vs `throw new Exception("text");` — **small proof**

3. **`get_`/`set_` methods instead of properties** (25+ classes)
   `get_Not()` + trailing `// property` comments vs `public ... Not =>` — **printer-only**

4. **IR `// structural signature` comments** (28+ classes)
   Up to 96 per class leaking internal evidence — **printer-only**

5. **Goto/label dispatch vs structured loops** (20+ classes)
   `goto IL_0059; IL_0059: ;` vs `for (int i = ...)` — **new analysis**

6. **IL fallback for compiler features** (8 classes)
   Iterators (yield-return), unsafe pointers, generic virtual dispatch — **new analysis**

7. **Enums as `class : System.Enum`** (2 classes)
   `public const TestEnum A = 0;` vs `A,` — **printer-only**

8. **`?.` / `??` missing** (6+ classes)
   goto-based null-checks vs `s?.GetHashCode() ?? 0` — **small proof**

9. **`__name_<hex>` explicit interface impls** (8+ classes)
   `__name_53797374656D2E...` vs `void ICollection.CopyTo(...)` — **printer-only**

10. **Static field init moved to ctor** (3+ classes)
    `static T() { F = 21; }` vs `public static int F = 21;` — **small proof**