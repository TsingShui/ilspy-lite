# slice-10 Quality Review Summary

46 classes reviewed (13 assemblies), 18 truncated.

## Top Patterns (ranked by class count)

1. **IL-fidelity goto/label control flow** (22 classes)
   `if (v0 == 0) { goto IL_0024; } else { goto IL_0003; }` vs `if (isGood) { ... } else { ... }`
   Fix: **new analysis** — loop/condition structure reconstruction

2. **Fully-qualified type names everywhere** (20 classes)
   `System.Console.WriteLine`, `global::System.Exception` — no `using` directives emitted.
   Fix: **printer-only**

3. **Synthetic __cil_* locals and opaque type aliases** (18 classes)
   `__cil_type_01000017 v0 = __cil_newobj_0A000019()` vs `new AutoRun()`
   Fix: **printer-only** — type names resolved in metadata

4. **Properties as get_/set_ methods + trailing comments** (10 classes)
   `// property string Path { get: get_Path; set: set_Path; }` vs `public string Path { get; private set; }`
   Fix: **small proof** — detect get_/set_ pairing

5. **|ildstr + assign-then-use for strings** (15 classes)
   `string v0 = __cil_ldstr_70000001("text"); Method(v0);` vs inline arg. Fix: **small proof**

6. **Missing custom attributes** (12 classes)
   No `[TestFixture]`, `[Test]`, `[Obsolete]` emitted. Fix: **printer-only**

7. **Field initializers left in constructor body** (8 classes)
   `this.invalidFile = v3;` in ctor vs `private string invalidFile = Path.Combine(...);`. Fix: **small proof**

8. **Lambda/delegate caching as __name_<hex> classes** (4 classes)
   `__name_3C3E63.__il_field_04000009` vs `() => { ... }`. Fix: **new analysis**

9. **IR-internals comments in output** (18 classes)
   `// structural signature`, `// Dependency identity substituted:...`. Fix: **printer-only**

10. **Explicit `return;` / `: base()` noise** (10 classes)
    `{ return; }` vs `{ }`, `: base()` always explicit. Fix: **printer-only**

## Fix Class Summary

printer: 7 | small-proof: 3 | new-analysis: 3