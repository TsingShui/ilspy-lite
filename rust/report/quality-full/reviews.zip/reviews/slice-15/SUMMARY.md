# Slice-15 Quality Review Summary

46 classes across 14 assemblies. Pervasive IL-level printing: one instruction per
statement with synthetic helpers, goto dispatch, explicit temporaries.

## Ranked patterns

1. **__cil_* synthetic calls/fields/values** (48 classes)
   `__cil_callvirt_0A0000C6`, `__cil_bool_store(1)` for `true`. Fix: small proof.

2. **goto/label control flow** (40 classes)
   Every if/else = `goto IL_xxxx; IL_xxxx: ;` instead of structured blocks.
   `IL_0000: ;` at method entry. Fix: new analysis.

3. **Synthetic locals for single-use** (42 classes)
   `string v1 = this.eq1;` then `v1` used once. Fix: small proof.

4. **get_/set_ methods instead of properties** (35 classes)
   `get_StateMachineType()` + `// property ...` comment. Fix: printer-only.

5. **Hex-mangled compiler-generated names** (20 classes)
   `__name_3C47656E6572617465446174613E645F5F34` for `<GenerateData>d__4`,
   closure classes. Fix: printer-only.

6. **Unnecessary casts and type noise** (38 classes)
   `((object)(v1))`, `((__cil_type_0100002F)(v6))`, `global::` on own type.
   Fix: printer-only.

7. **Structural signature / evidence comments** (30 classes)
   `// structural signature`, `// Exact call ...`, `// Dependency identity ...`.
   Fix: printer-only.

8. **Field initializers in constructors** (15 classes)
   `this._delimiter = ";";` in every ctor body. ILSpy: field initializer.
   Fix: small proof.

9. **Missing class-level attributes** (8 classes)
   `[AttributeUsage(...)]` absent from declarations. Fix: printer-only.

10. **Iterator/async state machines as raw IL** (4 classes)
    `yield return` printed as state machine class. Fix: deliberate.