# Slice 13 — Quality Summary

46 classes (17 truncated), 14 assemblies.

## Ranked Patterns
1. structural-signature comments — 39 classes, printer-only
   `// structural signature __cil_ref_f13343b484af... bytes=15121D...`

2. opaque type aliases `__cil_type_XXXXXXXX` — 38 classes, printer-only
   `__cil_type_0100001C l0 = default;`

3. goto/label dispatch — 36 classes, new analysis
   `goto IL_001D; ... IL_000C: ;`

4. `unchecked(...)` noise — 36 classes, printer-only
   `((ModuleParameters)v5).Kind = unchecked((ModuleKind)(v6));`

5. `global::` prefix on every type — 36 classes, printer-only
   `global::Mono.Cecil.Tests.ImportReflectionTests.Emitter v0 = ...`

6. `__cil_bool_store`/`load` wrappers — 35 classes, printer-only
   `TestCSharp(..., __cil_bool_store(1), __cil_bool_store(0), ...)`

7. `__cil_ldstr_XXXXXXXX` string wrappers — 34 classes, printer-only
   `string v0 = __cil_ldstr_70002797("CustomAttributes.cs");`

8. empty base-calling constructors — 31 classes, printer-only
   `public ImportReflectionTests() : base() { return; }`

9. opaque ref/callvirt aliases (`__cil_ref_`, `__cil_callvirt_`) — 28/26 cl, printer-only

10. `__il_field_XXXXXXXX` token field names — 20 classes, printer-only
    `private static System.Action<...> __il_field_04000052;`

11. `get_`/`set_` methods instead of properties — 18 classes, small proof
    `public System.Uri get_Address()` → ILSpy: `public Uri Address { get; set; }`

12. phi temporaries (`e0_`, `e1_`, `s2_`) — 16 classes, new analysis
    `__cil_F e1_3_0 = v5;`

Deliberate: async/iterator state machines, compiler-generated `<>c`.