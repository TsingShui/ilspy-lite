# Slice-04 Quality Review Summary

46 classes reviewed across 13 images (ICSharpCode.Decompiler, hello, Mono.Cecil, slow-nunit-tests, nunit-agent, mock-assembly, nunit.framework, System.Diagnostics.StackTrace, System.Net.Ping, System.Runtime.Numerics, gmcs, Microsoft.Build.Tasks.CodeAnalysis, Microsoft.CodeAnalysis.CSharp).

## Ranked recurring patterns

1. **`__cil_*` helpers instead of member names or literals** (46/46 classes) — `__cil_callvirt_06001705(node)` instead of `node.FirstChild`, `__cil_ldstr_70000001("...")` instead of inline `"..."`. Fix: printer-only for tokens resolved to metadata names; small proof for call-site inlining.
   - Rep: `global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v1 = __cil_callvirt_06001705(node);` vs `AstNode astNode = node.FirstChild;`

2. **Synthetic locals v0..vN instead of named locals** (44/46 classes) — every method's temporaries are `v0, v1, v2...` instead of recovered source names. Fix: printer-only (name already lost in metadata).
   - Rep: `string v0 = __cil_ldstr_700000AF("Intentional failure"); NUnit.Framework.Assert.Fail(v0);`

3. **Fully qualified names with `global::` prefix** (33/46 classes, ~1660 total `global::` occurrences) — `global::Microsoft.CodeAnalysis.BuildTasks.PropertyDictionary` vs `PropertyDictionary`. Fix: printer-only (using directives already computed).
   - Rep: `global::NUnit.Framework.Constraints.ConstraintBuilder v1 = this.builder;`

4. **`goto IL_xxxx` dispatch instead of structured loops** (24/46 classes, ~1500 total gotos) — a simple while loop becomes 6+ goto/label blocks. Fix: new analysis (detect loop patterns).
   - Rep: `goto IL_0019; IL_0009: ; ... goto IL_0009; IL_0019: ; if (v7 is not null) { goto IL_0009; }` vs `while (astNode != null)`

5. **`get_`/`set_` methods instead of properties** (12/46 classes, ~600 methods) — `public bool get_XYZ()` instead of `public bool XYZ { get; }`. Fix: small proof (match get_/set_ pairs).
   - Rep: CSharpFormattingOptions has 202 get_/set_ methods, all should be properties.

6. **`__il_field_<token>` instead of field names** (11/46 classes, ~687 occurrences) — 21 anonymous fields in TestExecutionContext, 361 in CSharpFormattingOptions. Fix: needs new analysis to recover names from property metadata.
   - Rep: `private NUnit.Framework.Internal.Test __il_field_040000E6;` vs `public Test CurrentTest { get; set; }`

7. **`// structural signature` IR comments** (30/46 classes, ~560 total) — verbose metadata-description comments printed inside readable output. Fix: printer-only (comments silenced or moved to debug).
   - Rep: `// structural signature __cil_value_fc01eeb... bytes=1134: valuetype System.Diagnostics.SymbolStore.SymbolToken...`

8. **Redundant constructors with empty base() calls** (13/46 classes) — `public Foo() : base() { return; }` where ILSpy omits the implicit default constructor. Fix: printer-only.
   - Rep: `public AAA() : base() { return; }`

9. **Missing attributes on members** (7/46 classes) — `[Test]`, `[TestFixture]`, `[Explicit]`, `[Ignore("BECAUSE")]` attributes absent where ILSpy shows them. Fix: small proof (attribute metadata already available).
   - Rep: lacking `[Test]` on every test method in MockTestFixture, ExplicitFixture, IgnoredFixture, CDataTestFixure.

10. **`unchecked(...)` cast noise** (30/46 classes) — `unchecked((byte)(unchecked((int)(value))))` chain vs plain `value`. Fix: printer-only.
    - Rep: `return unchecked((__cil_enum_020000CB)(unchecked((ushort)(v1))));`