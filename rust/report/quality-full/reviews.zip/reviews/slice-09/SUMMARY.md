# Slice-09 Quality Summary (46 classes, 13 images)

1. **Synthetic `__cil_` names / v0..vN locals** — 46 classes
   `__cil_bool_load(__cil_value_call_...v0,v1)); return __cil_bool_store(v2);` vs `return left.Equals(right);`
   Fix: printer-only (aliases) + small proof (bool sequences).

2. **Fully-qualified `System.*` type names** — 46 classes
   `global::System.Collections.Immutable.ImmutableArray\`1<T0>` vs `ImmutableArray<T>`
   Fix: printer-only (short-name import resolution).

3. **Structural signature / body context comments** — 46 classes
   `// structural signature __cil_value_3bd7ae2f... bytes=...` (none in ILSpy)
   Fix: printer-only (debug-only).

4. **Goto/label dispatch** — 40 classes
   `goto IL_001B; ... s2_0._comparer = s2_1;` vs `_comparer = comparer ?? Comparer<T>.Default;`
   Fix: new analysis (switch/loop/merge-point reconstruction).

5. **get_/set_ methods instead of properties** — 36 classes
   `public T get_Item(int index) { ... }` vs `public T this[int index] { get { ... } }`
   Fix: small proof (recognize get_/set_ pairs from metadata).

6. **String/constant inlining failure** — 35 classes
   `string v1 = __cil_ldstr_...("&"); Replace(v1,...);` vs `Replace("&","&amp;").Replace(...)`
   Fix: printer-only + small proof (inline ldstr, fold chained calls).

7. **Enum values as raw int casts** — 30 classes
   `unchecked((int)(mode)); switch(v0) { case 0: ... }` vs `switch(mode) { case ZipArchiveMode.Read: ... }`
   Fix: small proof (restore enum member names).

8. **Redundant local variable explosion** — 35 classes
   `NUnit2FrameworkDriver v5 = this; string v6 = x; v5._x = v6;` vs `_x = x;`
   Fix: printer-only (fold single-use temps, `this` aliases).

9. **Bool load/store/compare expansion** — 28 classes
   `int v2 = __cil_bool_load(...); int v4 = (v2==0?1:0); __cil_bool_store(v4);` vs `return !...;`
   Fix: small proof (bool-negation pattern).

10. **`__il_field_` backing for auto-properties** — 20 classes
    `private string __il_field_0400000A; get_ID()->__il_field_...` vs `public string ID { get; set; }`
    Fix: small proof (auto-property shape from metadata).

Notes: Image 180 (STLCLR) has ~30 IL fallback methods/class (byref/modified locals). Images 515/474/892: ILSpy also fails (status 65). 4 classes truncated; counts representative.