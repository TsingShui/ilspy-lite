# Slice-01 Quality Review Summary

46 classes across 13 images. Ranked patterns:
## 1. __cil_* token-type names (46 classes, ~23K occ)
`__cil_type_01000083 v0 = ...;` — every type/field/method uses internal hashes.
ILSpy prints `ResourceManager`, `Culture`. **Fix: printer-only.**

## 2. Synthetic locals v0/v1/v2 (45 classes)
All temporaries named v<n>. **Fix: printer-only** (single-use) or Roslyn naming.

## 3. get_/set_ methods instead of properties (10 classes)
`public string get_Text()` + `// property ...` trailing comments.
**Fix: small-proof** — detect accessor pairs, merge into property syntax.

## 4. goto/label dispatch (15 classes)
`if (c) { goto IL_000C; } IL_000C: ;` — IL branch targets as goto+label.
ILSpy: `while`, `if/else`, `||`/`&&`. **Fix: small-proof** for if/else,
**new-analysis** for loops.

## 5. IR evidence comments (22 classes)
`// structural signature`, `// .code-bytes IL_00D8: [00, 00, ...]`,
`// enum storage`, `// Dependency identity substituted`.
Hex bytes, token metadata, dependency trails. **Fix: printer-only.**

## 6. IL fallback blocks (5 classes, ~10 methods)
`// IL fallback:` — raw IL where decompiler can't produce C#.
Iterators, LINQ, enum dispatch. **Fix: new-analysis.**

## 7. Boolean logic as int comparison (8 classes)
`int v1 = __cil_bool_load(call); if (v1 == 0) ...`.
ILSpy: `a || b || !c`. **Fix: small-proof.**

## 8. global:: and FQN noise (20 classes)
`global::System.ArgumentNullException`, no using directives. **Fix: printer-only.**

## 9. Misc noise: return; in voids, unchecked(...), : base() on empty ctors.
Most classes. **Fix: printer-only.**

**Assessment:** Dominant gaps are printer-only. Highest-value: real type names,
fold single-use temporaries, fix simple goto patterns. IL fallback blocks are
correctness gaps.