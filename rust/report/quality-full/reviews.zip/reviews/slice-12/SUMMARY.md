# Slice-12 Quality Review Summary

46 classes reviewed, 16 truncated, across 13 assemblies.

## Ranked Recurring Patterns (class count, fix class)

1. **__cil_* IL helpers** (43, printer/small): `__cil_newobj_*`, `__cil_ldstr_*`,
   `__cil_callvirt_*` instead of `new T(...)`, `"string"`, `.M()`. Printer-only for
   ldstr/ldsfld, small proof for newobj/callvirt.

2. **Synthetic locals v0..vN** (43, small proof): All locals numbered sequentially
   instead of inferred names or inlined expression. `global::...NotConstraint v2 =
   __cil_newobj_060004FC(v1)` vs ILSpy's `new NotConstraint(new EqualConstraint(expected))`.

3. **get_/set_ methods vs properties** (36, printer): `public ... get_Not()`
   plus trailing `// property ... { get: get_Not; }` comments vs ILSpy's
   `public ConstraintExpression Not => ...`. Tokens already mapped; printer-only.

4. **global:: on all types** (24, printer): No `using` directives;
   `global::NUnit.Framework.Constraints.ConstraintExpression` vs `ConstraintExpression`.

5. **IL_XXXX goto/label CFG** (29, new analysis): goto/label dispatch instead of
   structured if/else/while. `if (...) { goto IL_001A; } else { goto IL_0009; }`
   vs ILSpy's `if (testExecutionContext == null) { ... }`.

6. **// structural signature comments** (41, printer): IR debug evidence
   `// structural signature __cil_ref_<sha> bytes=...` in method bodies.

7. **__il_field_* backing fields** (14, small proof): `private Test
   __il_field_040001A7;` vs ILSpy's `public Test CurrentTest { get; set; }`.

8. **Redundant temp-to-return** (8, small proof): `SomeType v3 = v2; return v3;`
   instead of `return v2;` or inline.

9. **__cil_type_/*, __cil_ref_/* names** (23, printer): Unresolved types use
   SHA-based names like `__cil_type_01000012`, `__cil_ref_<sha>`.

10. **// Dependency comments** (16, printer): Resolution trail leaked at file bottom.

All findings are printer-only or small-proof except IL label/goto restructuring
which requires new control-flow analysis. No new semantic gaps found.