# Slice-24 Quality Review Summary
45 classes, 13 assemblies (21 our-truncated, 4 ILSpy-truncated).
Ranked patterns by class count:

**1. goto/label dispatch** — 39 classes — new analysis
`HexToInt`: 23 gotos vs 0 in ILSpy; `SyncTextWriter`: 169 gotos vs 0.
Every branch and loop is a `goto IL_XXXX` where ILSpy has `if`/`while`/`switch`.

**2. Synthetic locals** — 39 classes — printer-only
20987 total `v0`..`vN` temps. `AXmlElement` alone has 498. ILSpy inlines or uses source names.

**3. __cil_* helpers** — 37 classes — printer-only / small proof
7899 `__cil_ref_<hash>`, `__cil_callvirt_<token>`, `__cil_type_<token>` replacing real type/member names.

**4. unchecked(...) noise** — 25 classes — printer-only
2294 occurrences. `TokenReader` wraps 92 comparisons in `unchecked((uint)X)` vs plain comparisons in ILSpy.

**5. Properties as get_/set_ methods** — 16 classes — small proof
652 get_ methods with `// property` end-of-class comments. ILSpy emits inline property declarations.

**6. global:: prefix** — 35 classes — printer-only
1660 instances. `AXmlElement`: 74 `global::` prefixes on types where ILSpy uses short names.

**7. structural signature comments** — 30 classes — printer-only
592 IR debug comments with hex hashes and byte ranges should be suppressed.

**8. (E)(constant) enum casts** — 8 classes — printer-only
`unchecked((StringComparison)(4))` instead of `StringComparison.Ordinal`. 173 occurrences.

**9. __il_field_/__name_ synthetic names** — 15 classes — small proof
Backing fields like `__il_field_04000001`; compiler-generated types like `__name_<hex>`.

**10. Deliberate: iterator/async lowering** — 3 classes — deliberate
`<GetLittleArgs>d__0`, `AXmlElement.Content`, `XDocumentNavigable` kept lowered.

Dominant gap is control_flow structuring (new analysis), followed by naming/spelling (printer-only).