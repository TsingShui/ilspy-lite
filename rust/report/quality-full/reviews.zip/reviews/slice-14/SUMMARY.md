# Slice-14 Summary — 46 classes, 14 assemblies

## Top Patterns (by class count)

1. **global:: + __cil_newobj/__cil_callvirt/__cil_ldsfld tokens** (46/46): `global::System.ArgumentException v1 = __cil_newobj_0A000031(msg);` vs `throw new ArgumentException(msg);` — printer-only

2. **get_/set_ methods + `// property` comments** (30+): `public int get_TestCount() { ... }` vs `public int TestCount { get; private set; }` — printer-only

3. **__il_field_ for auto-props with private setter** (15+): `private int __il_field_04000005;` + get_/set_ pair vs auto-property — printer-only

4. **Decomposed expressions: unchecked(int) casts, __cil_bool_load/store wrappers, chain temporaries** (25+): `int v1 = this.PassCount; int v3 = this.ErrorCount; int v4 = unchecked(v1+v3);` vs `PassCount + ErrorCount + ...` — printer-only

5. **IL labels + goto for all control flow; phi-resolution locals** (20+): `if (p is not null) { goto IL_000E; } else { goto IL_0003; } IL_0003: ; throw ...;` vs `if (p == null) throw ...;` — small proof

6. **`// structural signature` and `// generic body context` comments** (25+): SHA-named blob comments on every generic/struct method — printer-only

7. **Op_* method calls for operators** (6): `System.IntPtr.op_Inequality(v1, v2)` vs `... != IntPtr.Zero` — printer-only

8. **__cil_ldstr with hex ID + hex data** (10+): `__cil_ldstr_7000055B("path")` vs `"path"` — printer-only

9. **Dependency substitution trailing comments** (12+): assembly version substitution notes — printer-only

10. **IL fallback blocks** (4): raw IL when nested/generic/retargetable external types unresolved — new analysis

11. **Lost type names** (4): `__cil_type_0100000A` vs `PlatformNotSupportedException` in platform-stub classes — printer-only

12. **__name_HEX names for explicit interface members** (5): `__name_53797374...494C6973742E416464(object)` vs `int IList.Add(object)` — printer-only

13. **Hex-named nested compiler class** (1): `__name_3C3E63` vs `<>c`, with `__il_field_` cached lambda delgates — printer-only

14. **Type tests with __cil_type placeholders** (3): `((object)v2 as __cil_type_01000018)` vs `runtime as ClrRuntime` — new analysis

15. **No using directives, no short names** (46/46): Every type fully qualified, no `using` emitted — printer-only