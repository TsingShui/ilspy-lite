# Slice-16 Quality Review Summary

44 classes reviewed (5 empty, 18 truncated at 60KB).

## Ranked Patterns

1. **Opaque `__cil_*` token aliases** (40+ classes): `__cil_type_01000013` vs `ResourceManager`. printer-only.
2. **`global::` fully-qualified names, no using directives** (35+): `global::System.Exception` vs `Exception`. printer-only.
3. **`get_`/`set_` methods instead of properties, `__il_field_*` names** (20+): `get_ResourceManager()` vs `ResourceManager` property. printer-only.
4. **Trailing `return;` in void methods** (30+): Nearly every void body. printer-only.
5. **IR evidence comments leaked** (30+): `// structural signature ...`, `// enum storage ...`, dependency substitution notes. printer-only.
6. **Goto/label control flow** (10+): Ternary `? :` as 20+ lines of gotos; if-else with IL_XXXX labels; `__cil_finally_end_0`. small proof for ternaries; new analysis for loops.
7. **`__cil_bool_load`/`__cil_bool_store` bool round-trip** (8+): `int v1 = __cil_bool_load(inheritHandle); ... __cil_bool_store(v1)`. printer-only.
8. **Missing field initializers** (6+): `private int _connectionLeaseTimeout;` vs `-1`. printer-only.
9. **Synthetic hex names for explicit interface impls** (3+): `__name_49466F6F3C...()` vs `IFoo<byte[]>.Do()`. printer-only.
10. **Missing custom attributes** (5+): `[TestFixture]`, `[Test]`, `[DllImport]`, `[DebuggerDisplay]` absent. small proof.
11. **IL fallback blocks** (4+): sizeof, pinned locals, interface dispatch fall back to IL comments. new analysis.