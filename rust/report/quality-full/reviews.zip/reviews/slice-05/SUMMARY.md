# Slice-05 Quality Review Summary
46 classes reviewed; 28 partially truncated.

1. `__cil_*` type/call/field/ldstr tokens (naming) — 46 classes
`__cil_type_01000011 v0 = __cil_newobj_0A000039();` vs `XmlDocument xmlDocument = new XmlDocument();`
`__cil_bool_load/__cil_bool_store` round-trips for bools — ~20 classes
Fix: printer-only; bool round-trip needs small proof.

2. Properties as get_/set_ methods; explicit iface as hex-named methods (structure) — ~38 classes
`public virtual string get_ProjectPath()` + `// property string ProjectPath ...` vs `public string ProjectPath { get; set; }`
Fix: printer-only.

3. IR diagnostic comments (comments) — ~40 classes
`// structural signature __cil_value_bbd9b440...` / `// IL fallback: EH fault handlers...`
Fix: printer-only.

4. Goto/label instead of structured loops (control_flow) — ~25 classes
`goto IL_0031; ... if (v12 != 0) { goto IL_0014; }` vs `foreach (XmlNode node in ConfigNodes)`
Fix: new analysis (foreach/while/for/do-while/switch).

5. Fully-qualified names, `global::`, raw enum casts (spelling) — ~35 classes
`global::NUnit.Framework.Constraints.ConstraintExpression` vs `ConstraintExpression`
`unchecked((__cil_enum_02000014)(8))` vs `TraceEventType.Information`
Fix: printer-only.

6. `typeof(T)`/`default(T)` lowered to ldtoken+GetTypeFromHandle/initobj (spelling) — ~8 classes
`__cil_ldtoken_type_1B000018; System.Type.GetTypeFromHandle(v1)` vs `typeof(TExpected)`
Fix: small proof.

7. String concat with token-loads, assign-then-use temps, int boxing via double-cast (compression) — ~20 classes
`string v1 = __cil_ldstr_7000031D("<"); ...` vs `"<" + name + "/>"`
`string v0 = ...; Console.WriteLine(v0);` vs `Console.WriteLine("foo!");`
`object v2 = ((object)((int)(0)));` vs `new GreaterThanConstraint(0);`
Fix: small proof.

8. Field initializers left in ctor body, ternary reduced to branched assign (structure) — ~8 classes
`this._indentSize = 4;` in ctor vs `private int _indentSize = 4;` at declaration
multi-block phi-temp field assign vs `x = (cond) ? a : b`
Fix: printer-only (field hoist), small proof (ternary).