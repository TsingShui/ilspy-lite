namespace OpenRA;

public sealed class Map : OpenRA.FileSystem.IReadOnlyFileSystem, System.IDisposable
{
    public const int SupportedMapFormat = 11;
    public const int CurrentMapFormat = 12;
    private const short InvalidCachedTerrainIndex = -1;
    private static readonly OpenRA.MapField[] YamlFields;
    private int __il_field_04000247;
    public readonly byte TileFormat;
    public string RequiresMod;
    public string Title;
    public string Author;
    public string Tileset;
    public bool LockPreview;
    public OpenRA.Primitives.Rectangle Bounds;
    public OpenRA.MapVisibility Visibility;
    public string[] Categories;
    private OpenRA.int2 __il_field_04000251;
    public System.Collections.Generic.IReadOnlyCollection<OpenRA.MiniYamlNode> PlayerDefinitions;
    public System.Collections.Generic.IReadOnlyCollection<OpenRA.MiniYamlNode> ActorDefinitions;
    public OpenRA.MiniYaml RuleDefinitions;
    public OpenRA.MiniYaml FluentMessageDefinitions;
    public OpenRA.MiniYaml SequenceDefinitions;
    public OpenRA.MiniYaml ModelSequenceDefinitions;
    public OpenRA.MiniYaml WeaponDefinitions;
    public OpenRA.MiniYaml VoiceDefinitions;
    public OpenRA.MiniYaml MusicDefinitions;
    public OpenRA.MiniYaml NotificationDefinitions;
    public readonly System.Collections.Generic.Dictionary<OpenRA.CPos, OpenRA.TerrainTile> ReplacedInvalidTerrainTiles;
    public readonly OpenRA.MapGrid Grid;
    private OpenRA.FileSystem.IReadOnlyPackage __il_field_0400025E;
    private string __il_field_0400025F;
    private OpenRA.Ruleset __il_field_04000260;
    private OpenRA.Graphics.SequenceSet __il_field_04000261;
    private bool __il_field_04000262;
    private System.Exception __il_field_04000263;
    private OpenRA.WPos __il_field_04000264;
    private OpenRA.WPos __il_field_04000265;
    private OpenRA.CellLayer<OpenRA.TerrainTile> __il_field_04000266;
    private OpenRA.CellLayer<OpenRA.ResourceTile> __il_field_04000267;
    private OpenRA.CellLayer<byte> __il_field_04000268;
    private OpenRA.CellLayer<byte> __il_field_04000269;
    private OpenRA.CellLayer<byte> __il_field_0400026A;
    private OpenRA.PPos[] __il_field_0400026B;
    private OpenRA.CellRegion __il_field_0400026C;
    private System.Collections.Generic.List<OpenRA.CPos> __il_field_0400026D;
    private System.Action<OpenRA.CPos> CellProjectionChanged;
    private readonly OpenRA.ModData modData;
    private OpenRA.CellLayer<short> cachedTerrainIndexes;
    private bool initializedCellProjection;
    private OpenRA.CellLayer<OpenRA.PPos[]> cellProjection;
    private OpenRA.CellLayer<System.Collections.Generic.List<OpenRA.MPos>> inverseCellProjection;
    private OpenRA.CellLayer<byte> projectedHeight;
    private OpenRA.Primitives.Rectangle projectionSafeBounds;
    private static readonly OpenRA.PPos[] NoProjectedCells;

    public int get_MapFormat()
    {
        int v1 = this.__il_field_04000247;
        return v1;
    }

    private void set_MapFormat(int value)
    {
        this.__il_field_04000247 = value;
        return;
    }

    public OpenRA.int2 get_MapSize()
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v1 = this.__il_field_04000251;
        return v1;
    }

    private void set_MapSize(OpenRA.int2 value)
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_04000251 = value;
        return;
    }

    public OpenRA.FileSystem.IReadOnlyPackage get_Package()
    {
        global::OpenRA.FileSystem.IReadOnlyPackage v1 = this.__il_field_0400025E;
        return v1;
    }

    private void set_Package(OpenRA.FileSystem.IReadOnlyPackage value)
    {
        this.__il_field_0400025E = value;
        return;
    }

    public string get_Uid()
    {
        string v1 = this.__il_field_0400025F;
        return v1;
    }

    private void set_Uid(string value)
    {
        this.__il_field_0400025F = value;
        return;
    }

    public OpenRA.Ruleset get_Rules()
    {
        global::OpenRA.Ruleset v1 = this.__il_field_04000260;
        return v1;
    }

    private void set_Rules(OpenRA.Ruleset value)
    {
        this.__il_field_04000260 = value;
        return;
    }

    public OpenRA.Graphics.SequenceSet get_Sequences()
    {
        global::OpenRA.Graphics.SequenceSet v1 = this.__il_field_04000261;
        return v1;
    }

    private void set_Sequences(OpenRA.Graphics.SequenceSet value)
    {
        this.__il_field_04000261 = value;
        return;
    }

    public bool get_InvalidCustomRules()
    {
        return this.__il_field_04000262;
    }

    private void set_InvalidCustomRules(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000262 = __cil_bool_store(v1);
        return;
    }

    public System.Exception get_InvalidCustomRulesException()
    {
        global::System.Exception v1 = this.__il_field_04000263;
        return v1;
    }

    private void set_InvalidCustomRulesException(System.Exception value)
    {
        this.__il_field_04000263 = value;
        return;
    }

    public OpenRA.WPos get_ProjectedTopLeft()
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v1 = this.__il_field_04000264;
        return v1;
    }

    private void set_ProjectedTopLeft(OpenRA.WPos value)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_04000264 = value;
        return;
    }

    public OpenRA.WPos get_ProjectedBottomRight()
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v1 = this.__il_field_04000265;
        return v1;
    }

    private void set_ProjectedBottomRight(OpenRA.WPos value)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_04000265 = value;
        return;
    }

    public OpenRA.CellLayer<OpenRA.TerrainTile> get_Tiles()
    {
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v1 = this.__il_field_04000266;
        return v1;
    }

    private void set_Tiles(OpenRA.CellLayer<OpenRA.TerrainTile> value)
    {
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        this.__il_field_04000266 = value;
        return;
    }

    public OpenRA.CellLayer<OpenRA.ResourceTile> get_Resources()
    {
        // structural signature __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 bytes=15128180011181F8: class OpenRA.CellLayer`1<valuetype OpenRA.ResourceTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 v1 = this.__il_field_04000267;
        return v1;
    }

    private void set_Resources(OpenRA.CellLayer<OpenRA.ResourceTile> value)
    {
        // structural signature __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 bytes=15128180011181F8: class OpenRA.CellLayer`1<valuetype OpenRA.ResourceTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        this.__il_field_04000267 = value;
        return;
    }

    public OpenRA.CellLayer<byte> get_Height()
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = this.__il_field_04000268;
        return v1;
    }

    private void set_Height(OpenRA.CellLayer<byte> value)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        this.__il_field_04000268 = value;
        return;
    }

    public OpenRA.CellLayer<byte> get_Ramp()
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = this.__il_field_04000269;
        return v1;
    }

    private void set_Ramp(OpenRA.CellLayer<byte> value)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        this.__il_field_04000269 = value;
        return;
    }

    public OpenRA.CellLayer<byte> get_CustomTerrain()
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = this.__il_field_0400026A;
        return v1;
    }

    private void set_CustomTerrain(OpenRA.CellLayer<byte> value)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        this.__il_field_0400026A = value;
        return;
    }

    public OpenRA.PPos[] get_ProjectedCells()
    {
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v1 = this.__il_field_0400026B;
        return v1;
    }

    private void set_ProjectedCells(OpenRA.PPos[] value)
    {
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        this.__il_field_0400026B = value;
        return;
    }

    public OpenRA.CellRegion get_AllCells()
    {
        global::OpenRA.CellRegion v1 = this.__il_field_0400026C;
        return v1;
    }

    private void set_AllCells(OpenRA.CellRegion value)
    {
        this.__il_field_0400026C = value;
        return;
    }

    public System.Collections.Generic.List<OpenRA.CPos> get_AllEdgeCells()
    {
        // structural signature __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 bytes=1512809D011124: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v1 = this.__il_field_0400026D;
        return v1;
    }

    private void set_AllEdgeCells(System.Collections.Generic.List<OpenRA.CPos> value)
    {
        // structural signature __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 bytes=1512809D011124: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        this.__il_field_0400026D = value;
        return;
    }

    public void add_CellProjectionChanged(System.Action<OpenRA.CPos> value)
    {
        // structural signature __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da bytes=151281A9011124: class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da l0 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da l1 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da l2 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v1 = v0.CellProjectionChanged;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v2 = l0;
        l1 = v2;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v3 = l1;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Combine(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v6 = ((__cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da)(object)v5);
        l2 = v6;
        global::OpenRA.Map v7 = this;
        ref __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v8 = ref v7.CellProjectionChanged;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v9 = l2;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v10 = l1;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v11 = __cil_methodspec_call_2B00009E(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v12 = l0;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public void remove_CellProjectionChanged(System.Action<OpenRA.CPos> value)
    {
        // structural signature __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da bytes=151281A9011124: class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da l0 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da l1 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da l2 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v1 = v0.CellProjectionChanged;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v2 = l0;
        l1 = v2;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v3 = l1;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Remove(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v6 = ((__cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da)(object)v5);
        l2 = v6;
        global::OpenRA.Map v7 = this;
        ref __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v8 = ref v7.CellProjectionChanged;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v9 = l2;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v10 = l1;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v11 = __cil_methodspec_call_2B00009E(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v12 = l0;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public static string ComputeUID(OpenRA.FileSystem.IReadOnlyPackage package)
    {
        int v2 = OpenRA.Map.GetMapFormat(package);
        string v3 = OpenRA.Map.ComputeUID(package, v2);
        return v3;
    }

    private static string ComputeUID(OpenRA.FileSystem.IReadOnlyPackage package, int format)
    {
        // IL fallback: EH leave must originate in a try or catch
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [18, 8D, FE, 00, 00, 01, 25, 16, 72, E2, 47, 00, 70, A2, 25, 17, 72, F4, 47, 00, 70, A2, 0A, 02]
        // .code-bytes IL_0018: [6F, 03, 0F, 00, 06, 28, A1, 00, 00, 2B, 0B, 06, 0D, 16, 13, 04, 2B, 2D, 09, 11, 04, 9A, 13, 05]
        // .code-bytes IL_0030: [07, 11, 05, 6F, 43, 03, 00, 0A, 2D, 17, 72, 04, 48, 00, 70, 11, 05, 72, 22, 48, 00, 70, 28, 6D]
        // .code-bytes IL_0048: [00, 00, 0A, 73, 44, 03, 00, 0A, 7A, 11, 04, 17, 58, 13, 04, 11, 04, 09, 8E, 69, 32, CC, 73, 45]
        // .code-bytes IL_0060: [03, 00, 0A, 0C, 07, 6F, 46, 03, 00, 0A, 13, 07, 2B, 57, 12, 07, 28, 47, 03, 00, 0A, 13, 08, 11]
        // .code-bytes IL_0078: [08, 72, A0, 0B, 00, 70, 1A, 6F, 48, 03, 00, 0A, 2D, 31, 11, 08, 72, 54, 48, 00, 70, 1A, 6F, 48]
        // .code-bytes IL_0090: [03, 00, 0A, 2D, 22, 11, 08, 72, 5E, 48, 00, 70, 1A, 6F, 48, 03, 00, 0A, 2D, 13, 03, 1F, 0C, 32]
        // .code-bytes IL_00A8: [1C, 11, 08, 72, 68, 48, 00, 70, 28, D9, 00, 00, 0A, 2C, 0E, 08, 02, 11, 08, 6F, 04, 0F, 00, 06]
        // .code-bytes IL_00C0: [6F, 49, 03, 00, 0A, 12, 07, 28, 4A, 03, 00, 0A, 2D, A0, DE, 0E, 12, 07, FE, 16, 68, 01, 00, 1B]
        // .code-bytes IL_00D8: [6F, 17, 00, 00, 0A, DC, 08, 6F, 4B, 03, 00, 0A, 2D, 0E, 28, A2, 00, 00, 2B, 28, 7A, 00, 00, 06]
        // .code-bytes IL_00F0: [13, 09, DE, 6E, 08, 16, 6F, 4C, 03, 00, 0A, 13, 06, 17, 13, 0A, 2B, 17, 11, 06, 08, 11, 0A, 6F]
        // .code-bytes IL_0108: [4C, 03, 00, 0A, 73, 21, 0B, 00, 06, 13, 06, 11, 0A, 17, 58, 13, 0A, 11, 0A, 08, 6F, 4B, 03, 00]
        // .code-bytes IL_0120: [0A, 32, DF, 11, 06, 28, 79, 00, 00, 06, 13, 09, DE, 34, 08, 6F, 4D, 03, 00, 0A, 13, 0B, 2B, 10]
        // .code-bytes IL_0138: [12, 0B, 28, 4E, 03, 00, 0A, 13, 0C, 11, 0C, 6F, 4F, 03, 00, 0A, 12, 0B, 28, 50, 03, 00, 0A, 2D]
        // .code-bytes IL_0150: [E7, DE, 0E, 12, 0B, FE, 16, 69, 01, 00, 1B, 6F, 17, 00, 00, 0A, DC, DC, 11, 09, 2A]
        // .local [0] string[]
        // .local [1] class [System.Collections]System.Collections.Generic.List`1<string>
        // .local [2] class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>
        // .local [3] string[]
        // .local [4] int32
        // .local [5] string
        // .local [6] class [System.Runtime]System.IO.Stream
        // .local [7] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<string>
        // .local [8] string
        // .local [9] string
        // .local [10] int32
        // .local [11] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [System.Runtime]System.IO.Stream>
        // .local [12] class [System.Runtime]System.IO.Stream
        // IL_0000: ldc.i4.2 2
        // IL_0001: newarr 0x010000FE [System.Runtime]System.String
        // IL_0006: dup 
        // IL_0007: ldc.i4.0 0
        // IL_0008: ldstr 0x700047E2 [109, 97, 112, 46, 121, 97, 109, 108] utf16-bytes=[6D, 00, 61, 00, 70, 00, 2E, 00, 79, 00, 61, 00, 6D, 00, 6C, 00] terminal-flag=Some(0)
        // IL_000D: stelem.ref 
        // IL_000E: dup 
        // IL_000F: ldc.i4.1 1
        // IL_0010: ldstr 0x700047F4 [109, 97, 112, 46, 98, 105, 110] utf16-bytes=[6D, 00, 61, 00, 70, 00, 2E, 00, 62, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_0015: stelem.ref 
        // IL_0016: stloc.0 0
        // IL_0017: ldarg.0 0
        // IL_0018: callvirt 0x06000F03 OpenRA.FileSystem.IReadOnlyPackage::get_Contents
        // IL_001D: call 0x2B0000A1 [System.Linq]System.Linq.Enumerable::ToList<string>
        // IL_0022: stloc.1 1
        // IL_0023: ldloc.0 0
        // IL_0024: stloc.3 3
        // IL_0025: ldc.i4.0 0
        // IL_0026: stloc.s 4
        // IL_0028: br.s IL_0057
        // IL_002A: ldloc.3 3
        // IL_002B: ldloc.s 4
        // IL_002D: ldelem.ref 
        // IL_002E: stloc.s 5
        // IL_0030: ldloc.1 1
        // IL_0031: ldloc.s 5
        // IL_0033: callvirt 0x0A000343 class [System.Collections]System.Collections.Generic.List`1<string>::Contains
        // IL_0038: brtrue.s IL_0051
        // IL_003A: ldstr 0x70004804 [82, 101, 113, 117, 105, 114, 101, 100, 32, 102, 105, 108, 101, 32] utf16-bytes=[52, 00, 65, 00, 71, 00, 75, 00, 69, 00, 72, 00, 65, 00, 64, 00, 20, 00, 66, 00, 69, 00, 6C, 00, 65, 00, 20, 00] terminal-flag=Some(0)
        // IL_003F: ldloc.s 5
        // IL_0041: ldstr 0x70004822 [32, 110, 111, 116, 32, 112, 114, 101, 115, 101, 110, 116, 32, 105, 110, 32, 116, 104, 105, 115, 32, 109, 97, 112] utf16-bytes=[20, 00, 6E, 00, 6F, 00, 74, 00, 20, 00, 70, 00, 72, 00, 65, 00, 73, 00, 65, 00, 6E, 00, 74, 00, 20, 00, 69, 00, 6E, 00, 20, 00, 74, 00, 68, 00, 69, 00, 73, 00, 20, 00, 6D, 00, 61, 00, 70, 00] terminal-flag=Some(0)
        // IL_0046: call 0x0A00006D [System.Runtime]System.String::Concat
        // IL_004B: newobj 0x0A000344 [System.Runtime]System.IO.FileNotFoundException::.ctor
        // IL_0050: throw 
        // IL_0051: ldloc.s 4
        // IL_0053: ldc.i4.1 1
        // IL_0054: add 
        // IL_0055: stloc.s 4
        // IL_0057: ldloc.s 4
        // IL_0059: ldloc.3 3
        // IL_005A: ldlen 
        // IL_005B: conv.i4 
        // IL_005C: blt.s IL_002A
        // IL_005E: newobj 0x0A000345 class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>::.ctor
        // IL_0063: stloc.2 2
        // IL_0064: ldloc.1 1
        // IL_0065: callvirt 0x0A000346 class [System.Collections]System.Collections.Generic.List`1<string>::GetEnumerator
        // IL_006A: stloc.s 7
        // IL_006C: br.s IL_00C5
        // IL_006E: ldloca.s 7
        // IL_0070: call 0x0A000347 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<string>::get_Current
        // IL_0075: stloc.s 8
        // IL_0077: ldloc.s 8
        // IL_0079: ldstr 0x70000BA0 [46, 121, 97, 109, 108] utf16-bytes=[2E, 00, 79, 00, 61, 00, 6D, 00, 6C, 00] terminal-flag=Some(0)
        // IL_007E: ldc.i4.4 4
        // IL_007F: callvirt 0x0A000348 [System.Runtime]System.String::EndsWith
        // IL_0084: brtrue.s IL_00B7
        // IL_0086: ldloc.s 8
        // IL_0088: ldstr 0x70004854 [46, 98, 105, 110] utf16-bytes=[2E, 00, 62, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_008D: ldc.i4.4 4
        // IL_008E: callvirt 0x0A000348 [System.Runtime]System.String::EndsWith
        // IL_0093: brtrue.s IL_00B7
        // IL_0095: ldloc.s 8
        // IL_0097: ldstr 0x7000485E [46, 108, 117, 97] utf16-bytes=[2E, 00, 6C, 00, 75, 00, 61, 00] terminal-flag=Some(0)
        // IL_009C: ldc.i4.4 4
        // IL_009D: callvirt 0x0A000348 [System.Runtime]System.String::EndsWith
        // IL_00A2: brtrue.s IL_00B7
        // IL_00A4: ldarg.1 1
        // IL_00A5: ldc.i4.s 12
        // IL_00A7: blt.s IL_00C5
        // IL_00A9: ldloc.s 8
        // IL_00AB: ldstr 0x70004868 [109, 97, 112, 46, 112, 110, 103] utf16-bytes=[6D, 00, 61, 00, 70, 00, 2E, 00, 70, 00, 6E, 00, 67, 00] terminal-flag=Some(0)
        // IL_00B0: call 0x0A0000D9 [System.Runtime]System.String::op_Equality
        // IL_00B5: brfalse.s IL_00C5
        // IL_00B7: ldloc.2 2
        // IL_00B8: ldarg.0 0
        // IL_00B9: ldloc.s 8
        // IL_00BB: callvirt 0x06000F04 OpenRA.FileSystem.IReadOnlyPackage::GetStream
        // IL_00C0: callvirt 0x0A000349 class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>::Add
        // IL_00C5: ldloca.s 7
        // IL_00C7: call 0x0A00034A valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<string>::MoveNext
        // IL_00CC: brtrue.s IL_006E
        // IL_00CE: leave.s IL_00DE
        // IL_00D0: ldloca.s 7
        // IL_00D2: constrained. 0x1B000168 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<string>
        // IL_00D8: callvirt 0x0A000017 [System.Runtime]System.IDisposable::Dispose
        // IL_00DD: endfinally 
        // IL_00DE: ldloc.2 2
        // IL_00DF: callvirt 0x0A00034B class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>::get_Count
        // IL_00E4: brtrue.s IL_00F4
        // IL_00E6: call 0x2B0000A2 [System.Runtime]System.Array::Empty<uint8>
        // IL_00EB: call 0x0600007A OpenRA.CryptoUtil::SHA1Hash
        // IL_00F0: stloc.s 9
        // IL_00F2: leave.s IL_0162
        // IL_00F4: ldloc.2 2
        // IL_00F5: ldc.i4.0 0
        // IL_00F6: callvirt 0x0A00034C class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>::get_Item
        // IL_00FB: stloc.s 6
        // IL_00FD: ldc.i4.1 1
        // IL_00FE: stloc.s 10
        // IL_0100: br.s IL_0119
        // IL_0102: ldloc.s 6
        // IL_0104: ldloc.2 2
        // IL_0105: ldloc.s 10
        // IL_0107: callvirt 0x0A00034C class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>::get_Item
        // IL_010C: newobj 0x06000B21 OpenRA.Primitives.MergedStream::.ctor
        // IL_0111: stloc.s 6
        // IL_0113: ldloc.s 10
        // IL_0115: ldc.i4.1 1
        // IL_0116: add 
        // IL_0117: stloc.s 10
        // IL_0119: ldloc.s 10
        // IL_011B: ldloc.2 2
        // IL_011C: callvirt 0x0A00034B class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>::get_Count
        // IL_0121: blt.s IL_0102
        // IL_0123: ldloc.s 6
        // IL_0125: call 0x06000079 OpenRA.CryptoUtil::SHA1Hash
        // IL_012A: stloc.s 9
        // IL_012C: leave.s IL_0162
        // IL_012E: ldloc.2 2
        // IL_012F: callvirt 0x0A00034D class [System.Collections]System.Collections.Generic.List`1<class [System.Runtime]System.IO.Stream>::GetEnumerator
        // IL_0134: stloc.s 11
        // IL_0136: br.s IL_0148
        // IL_0138: ldloca.s 11
        // IL_013A: call 0x0A00034E valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [System.Runtime]System.IO.Stream>::get_Current
        // IL_013F: stloc.s 12
        // IL_0141: ldloc.s 12
        // IL_0143: callvirt 0x0A00034F [System.Runtime]System.IO.Stream::Dispose
        // IL_0148: ldloca.s 11
        // IL_014A: call 0x0A000350 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [System.Runtime]System.IO.Stream>::MoveNext
        // IL_014F: brtrue.s IL_0138
        // IL_0151: leave.s IL_0161
        // IL_0153: ldloca.s 11
        // IL_0155: constrained. 0x1B000169 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [System.Runtime]System.IO.Stream>
        // IL_015B: callvirt 0x0A000017 [System.Runtime]System.IDisposable::Dispose
        // IL_0160: endfinally 
        // IL_0161: endfinally 
        // IL_0162: ldloc.s 9
        // IL_0164: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 108, try_length: 100, handler_offset: 208, handler_length: 14, raw_flags: 2 }
        // .try IL_006C..IL_00D0 finally IL_00D0..IL_00DE
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 310, try_length: 29, handler_offset: 339, handler_length: 14, raw_flags: 2 }
        // .try IL_0136..IL_0153 finally IL_0153..IL_0161
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 100, try_length: 202, handler_offset: 302, handler_length: 52, raw_flags: 2 }
        // .try IL_0064..IL_012E finally IL_012E..IL_0162
    }

    private static int GetMapFormat(OpenRA.FileSystem.IReadOnlyPackage p)
    {
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerator`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd bytes=15128085010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100003C l0 = default;
        __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 l1 = default;
        string l2 = default;
        __cil_type_0100008F l3 = default;
        int l4 = default;
        IL_0000: ;
        global::OpenRA.FileSystem.IReadOnlyPackage v0 = p;
        string v1 = __cil_ldstr_700047E2("map.yaml");
        __cil_type_0100003C v2 = __cil_callvirt_06000F04(v0, v1);
        l0 = v2;
        try {
            IL_000C: ;
            __cil_type_0100003C v3 = l0;
            if (v3 is not null) {
                goto IL_001A;
            } else {
                goto IL_000F;
            }
            IL_000F: ;
            string v4 = __cil_ldstr_70004878("Required file map.yaml not present in this map");
            global::System.IO.FileNotFoundException v5 = __cil_newobj_0A000344(v4);
            throw v5;
            IL_001A: ;
            __cil_type_0100003C v6 = l0;
            __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd v7 = OpenRA.StreamExts.ReadAllLines(v6);
            __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v8 = __cil_callvirt_0A000034(v7);
            l1 = v8;
            try {
                IL_0026: ;
                goto IL_0070;
                IL_0028: ;
                __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v9 = l1;
                string v10 = __cil_callvirt_0A000033(v9);
                l2 = v10;
                string v11 = l2;
                string v12 = __cil_ldstr_700048D6("^MapFormat:\\s*(\\d*)\\s*$");
                __cil_type_0100008F v13 = System.Text.RegularExpressions.Regex.Match(v11, v12);
                l3 = v13;
                __cil_type_0100008F v14 = l3;
                int v15 = __cil_bool_load(__cil_callvirt_0A000352(v14));
                if (v15 == 0) {
                    goto IL_0070;
                } else {
                    goto IL_0043;
                }
                IL_0043: ;
                __cil_type_0100008F v16 = l3;
                __cil_type_0100013D v17 = __cil_callvirt_0A000353(v16);
                int v18 = __cil_callvirt_0A000354(v17);
                int v19 = 0;
                if (v18 <= v19) {
                    goto IL_0070;
                } else {
                    goto IL_0051;
                }
                IL_0051: ;
                string v20 = __cil_ldstr_70004906("MapFormat");
                __cil_type_0100008F v21 = l3;
                __cil_type_0100013D v22 = __cil_callvirt_0A000353(v21);
                int v23 = 1;
                __cil_type_0100013C v24 = __cil_callvirt_0A000355(v22, v23);
                string v25 = __cil_callvirt_0A000356(v24);
                int v26 = __cil_methodspec_call_2B00008A(v20, v25);
                l4 = v26;
                goto IL_0099;
                IL_0070: ;
                __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v27 = l1;
                int v28 = __cil_bool_load(__cil_callvirt_0A000018(v27));
                if (v28 != 0) {
                    goto IL_0028;
                } else {
                    goto IL_0078;
                }
                IL_0078: ;
                goto IL_008E;
            }
            finally {
                IL_007A: ;
                __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v29 = l1;
                if (v29 is null) {
                    goto IL_0083;
                } else {
                    goto IL_007D;
                }
                IL_007D: ;
                __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v30 = l1;
                __cil_callvirt_0A000017(v30);
                goto IL_0083;
                IL_0083: ;
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
        }
        finally {
            IL_0084: ;
            __cil_type_0100003C v31 = l0;
            if (v31 is null) {
                goto IL_008D;
            } else {
                goto IL_0087;
            }
            IL_0087: ;
            __cil_type_0100003C v32 = l0;
            __cil_callvirt_0A000017(v32);
            goto IL_008D;
            IL_008D: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_008E: ;
        string v33 = __cil_ldstr_7000491A("MapFormat is not defined");
        global::System.IO.InvalidDataException v34 = __cil_newobj_0A000078(v33);
        throw v34;
        IL_0099: ;
        int v35 = l4;
        return v35;
    }

    public Map(OpenRA.ModData modData, OpenRA.ITerrainInfo terrainInfo, int width, int height)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 18, 7D, 48, 02, 00, 04, 02, 17, 7D, 4F, 02, 00, 04, 02, 17, 8D, FE, 00, 00, 01, 25, 16, 72]
        // .code-bytes IL_0018: [4C, 49, 00, 70, A2, 7D, 50, 02, 00, 04, 02, 7E, 57, 03, 00, 0A, 8C, DF, 00, 00, 1B, 7D, 52, 02]
        // .code-bytes IL_0030: [00, 04, 02, 7E, 57, 03, 00, 0A, 8C, DF, 00, 00, 1B, 7D, 53, 02, 00, 04, 02, 73, 58, 03, 00, 0A]
        // .code-bytes IL_0048: [7D, 5C, 02, 00, 04, 02, 28, 5B, 00, 00, 0A, 02, 03, 7D, 6F, 02, 00, 04, 12, 00, 05, 0E, 04, 28]
        // .code-bytes IL_0060: [FD, 0B, 00, 06, 02, 03, 7B, 09, 03, 00, 04, 6F, 59, 00, 00, 2B, 7D, 5D, 02, 00, 04, 02, 72, 5E]
        // .code-bytes IL_0078: [49, 00, 70, 7D, 4A, 02, 00, 04, 02, 72, 84, 49, 00, 70, 7D, 4B, 02, 00, 04, 02, 06, 73, D4, 04]
        // .code-bytes IL_0090: [00, 06, 28, EC, 02, 00, 06, 02, 04, 6F, C5, 03, 00, 06, 7D, 4C, 02, 00, 04, 02, 72, EE, 05, 00]
        // .code-bytes IL_00A8: [70, 73, EC, 03, 00, 06, 7D, 54, 02, 00, 04, 02, 02, 7B, 5D, 02, 00, 04, 7B, 9D, 02, 00, 04, 06]
        // .code-bytes IL_00C0: [73, 59, 03, 00, 0A, 28, FE, 02, 00, 06, 02, 02, 7B, 5D, 02, 00, 04, 7B, 9D, 02, 00, 04, 06, 73]
        // .code-bytes IL_00D8: [5A, 03, 00, 0A, 28, 00, 03, 00, 06, 02, 02, 7B, 5D, 02, 00, 04, 7B, 9D, 02, 00, 04, 06, 73, 5B]
        // .code-bytes IL_00F0: [03, 00, 0A, 28, 02, 03, 00, 06, 02, 02, 7B, 5D, 02, 00, 04, 7B, 9D, 02, 00, 04, 06, 73, 5B, 03]
        // .code-bytes IL_0108: [00, 0A, 28, 04, 03, 00, 06, 02, 28, FD, 02, 00, 06, 04, 6F, CB, 03, 00, 06, 6F, 5C, 03, 00, 0A]
        // .code-bytes IL_0120: [02, 7B, 5D, 02, 00, 04, 7B, 9F, 02, 00, 04, 16, 31, 45, 02, 28, FD, 02, 00, 06, 02, FE, 06, 15]
        // .code-bytes IL_0138: [03, 00, 06, 73, 5D, 03, 00, 0A, 6F, 5E, 03, 00, 0A, 02, 28, FD, 02, 00, 06, 02, FE, 06, 17, 03]
        // .code-bytes IL_0150: [00, 06, 73, 5D, 03, 00, 0A, 6F, 5E, 03, 00, 0A, 02, 28, 01, 03, 00, 06, 02, FE, 06, 17, 03, 00]
        // .code-bytes IL_0168: [06, 73, 5D, 03, 00, 0A, 6F, 5F, 03, 00, 0A, 02, 28, 14, 03, 00, 06, 2A]
        // .local [0] valuetype OpenRA.Primitives.Size
        // IL_0000: ldarg.0 0
        // IL_0001: ldc.i4.2 2
        // IL_0002: stfld 0x04000248 OpenRA.Map::TileFormat
        // IL_0007: ldarg.0 0
        // IL_0008: ldc.i4.1 1
        // IL_0009: stfld 0x0400024F OpenRA.Map::Visibility
        // IL_000E: ldarg.0 0
        // IL_000F: ldc.i4.1 1
        // IL_0010: newarr 0x010000FE [System.Runtime]System.String
        // IL_0015: dup 
        // IL_0016: ldc.i4.0 0
        // IL_0017: ldstr 0x7000494C [67, 111, 110, 113, 117, 101, 115, 116] utf16-bytes=[43, 00, 6F, 00, 6E, 00, 71, 00, 75, 00, 65, 00, 73, 00, 74, 00] terminal-flag=Some(0)
        // IL_001C: stelem.ref 
        // IL_001D: stfld 0x04000250 OpenRA.Map::Categories
        // IL_0022: ldarg.0 0
        // IL_0023: ldsfld 0x0A000357 valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>::Empty
        // IL_0028: box 0x1B0000DF valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>
        // IL_002D: stfld 0x04000252 OpenRA.Map::PlayerDefinitions
        // IL_0032: ldarg.0 0
        // IL_0033: ldsfld 0x0A000357 valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>::Empty
        // IL_0038: box 0x1B0000DF valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>
        // IL_003D: stfld 0x04000253 OpenRA.Map::ActorDefinitions
        // IL_0042: ldarg.0 0
        // IL_0043: newobj 0x0A000358 class [System.Collections]System.Collections.Generic.Dictionary`2<valuetype OpenRA.CPos, valuetype OpenRA.TerrainTile>::.ctor
        // IL_0048: stfld 0x0400025C OpenRA.Map::ReplacedInvalidTerrainTiles
        // IL_004D: ldarg.0 0
        // IL_004E: call 0x0A00005B [System.Runtime]System.Object::.ctor
        // IL_0053: ldarg.0 0
        // IL_0054: ldarg.1 1
        // IL_0055: stfld 0x0400026F OpenRA.Map::modData
        // IL_005A: ldloca.s 0
        // IL_005C: ldarg.3 3
        // IL_005D: ldarg.s 4
        // IL_005F: call 0x06000BFD OpenRA.Primitives.Size::.ctor
        // IL_0064: ldarg.0 0
        // IL_0065: ldarg.1 1
        // IL_0066: ldfld 0x04000309 OpenRA.ModData::Manifest
        // IL_006B: callvirt 0x2B000059 OpenRA.Manifest::Get<class OpenRA.MapGrid>
        // IL_0070: stfld 0x0400025D OpenRA.Map::Grid
        // IL_0075: ldarg.0 0
        // IL_0076: ldstr 0x7000495E [78, 97, 109, 101, 32, 121, 111, 117, 114, 32, 109, 97, 112, 32, 104, 101, 114, 101] utf16-bytes=[4E, 00, 61, 00, 6D, 00, 65, 00, 20, 00, 79, 00, 6F, 00, 75, 00, 72, 00, 20, 00, 6D, 00, 61, 00, 70, 00, 20, 00, 68, 00, 65, 00, 72, 00, 65, 00] terminal-flag=Some(0)
        // IL_007B: stfld 0x0400024A OpenRA.Map::Title
        // IL_0080: ldarg.0 0
        // IL_0081: ldstr 0x70004984 [89, 111, 117, 114, 32, 110, 97, 109, 101, 32, 104, 101, 114, 101] utf16-bytes=[59, 00, 6F, 00, 75, 00, 72, 00, 20, 00, 6E, 00, 61, 00, 6D, 00, 65, 00, 20, 00, 68, 00, 65, 00, 72, 00, 65, 00] terminal-flag=Some(0)
        // IL_0086: stfld 0x0400024B OpenRA.Map::Author
        // IL_008B: ldarg.0 0
        // IL_008C: ldloc.0 0
        // IL_008D: newobj 0x060004D4 OpenRA.int2::.ctor
        // IL_0092: call 0x060002EC OpenRA.Map::set_MapSize
        // IL_0097: ldarg.0 0
        // IL_0098: ldarg.2 2
        // IL_0099: callvirt 0x060003C5 OpenRA.ITerrainInfo::get_Id
        // IL_009E: stfld 0x0400024C OpenRA.Map::Tileset
        // IL_00A3: ldarg.0 0
        // IL_00A4: ldstr 0x700005EE [] utf16-bytes=[] terminal-flag=Some(0)
        // IL_00A9: newobj 0x060003EC OpenRA.MiniYaml::.ctor
        // IL_00AE: stfld 0x04000254 OpenRA.Map::RuleDefinitions
        // IL_00B3: ldarg.0 0
        // IL_00B4: ldarg.0 0
        // IL_00B5: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_00BA: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_00BF: ldloc.0 0
        // IL_00C0: newobj 0x0A000359 class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::.ctor
        // IL_00C5: call 0x060002FE OpenRA.Map::set_Tiles
        // IL_00CA: ldarg.0 0
        // IL_00CB: ldarg.0 0
        // IL_00CC: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_00D1: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_00D6: ldloc.0 0
        // IL_00D7: newobj 0x0A00035A class OpenRA.CellLayer`1<valuetype OpenRA.ResourceTile>::.ctor
        // IL_00DC: call 0x06000300 OpenRA.Map::set_Resources
        // IL_00E1: ldarg.0 0
        // IL_00E2: ldarg.0 0
        // IL_00E3: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_00E8: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_00ED: ldloc.0 0
        // IL_00EE: newobj 0x0A00035B class OpenRA.CellLayer`1<uint8>::.ctor
        // IL_00F3: call 0x06000302 OpenRA.Map::set_Height
        // IL_00F8: ldarg.0 0
        // IL_00F9: ldarg.0 0
        // IL_00FA: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_00FF: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_0104: ldloc.0 0
        // IL_0105: newobj 0x0A00035B class OpenRA.CellLayer`1<uint8>::.ctor
        // IL_010A: call 0x06000304 OpenRA.Map::set_Ramp
        // IL_010F: ldarg.0 0
        // IL_0110: call 0x060002FD OpenRA.Map::get_Tiles
        // IL_0115: ldarg.2 2
        // IL_0116: callvirt 0x060003CB OpenRA.ITerrainInfo::get_DefaultTerrainTile
        // IL_011B: callvirt 0x0A00035C class OpenRA.CellLayerBase`1<valuetype OpenRA.TerrainTile>::Clear
        // IL_0120: ldarg.0 0
        // IL_0121: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_0126: ldfld 0x0400029F OpenRA.MapGrid::MaximumTerrainHeight
        // IL_012B: ldc.i4.0 0
        // IL_012C: ble.s IL_0173
        // IL_012E: ldarg.0 0
        // IL_012F: call 0x060002FD OpenRA.Map::get_Tiles
        // IL_0134: ldarg.0 0
        // IL_0135: ldftn 0x06000315 OpenRA.Map::UpdateRamp
        // IL_013B: newobj 0x0A00035D class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>::.ctor
        // IL_0140: callvirt 0x0A00035E class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::add_CellEntryChanged
        // IL_0145: ldarg.0 0
        // IL_0146: call 0x060002FD OpenRA.Map::get_Tiles
        // IL_014B: ldarg.0 0
        // IL_014C: ldftn 0x06000317 OpenRA.Map::UpdateProjection
        // IL_0152: newobj 0x0A00035D class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>::.ctor
        // IL_0157: callvirt 0x0A00035E class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::add_CellEntryChanged
        // IL_015C: ldarg.0 0
        // IL_015D: call 0x06000301 OpenRA.Map::get_Height
        // IL_0162: ldarg.0 0
        // IL_0163: ldftn 0x06000317 OpenRA.Map::UpdateProjection
        // IL_0169: newobj 0x0A00035D class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>::.ctor
        // IL_016E: callvirt 0x0A00035F class OpenRA.CellLayer`1<uint8>::add_CellEntryChanged
        // IL_0173: ldarg.0 0
        // IL_0174: call 0x06000314 OpenRA.Map::PostInit
        // IL_0179: ret 
    }

    public Map(OpenRA.ModData modData, OpenRA.FileSystem.IReadOnlyPackage package)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 18, 7D, 48, 02, 00, 04, 02, 17, 7D, 4F, 02, 00, 04, 02, 17, 8D, FE, 00, 00, 01, 25, 16, 72]
        // .code-bytes IL_0018: [4C, 49, 00, 70, A2, 7D, 50, 02, 00, 04, 02, 7E, 57, 03, 00, 0A, 8C, DF, 00, 00, 1B, 7D, 52, 02]
        // .code-bytes IL_0030: [00, 04, 02, 7E, 57, 03, 00, 0A, 8C, DF, 00, 00, 1B, 7D, 53, 02, 00, 04, 02, 73, 58, 03, 00, 0A]
        // .code-bytes IL_0048: [7D, 5C, 02, 00, 04, 02, 28, 5B, 00, 00, 0A, 02, 03, 7D, 6F, 02, 00, 04, 02, 04, 28, EE, 02, 00]
        // .code-bytes IL_0060: [06, 02, 28, ED, 02, 00, 06, 72, E2, 47, 00, 70, 6F, 05, 0F, 00, 06, 2C, 12, 02, 28, ED, 02, 00]
        // .code-bytes IL_0078: [06, 72, F4, 47, 00, 70, 6F, 05, 0F, 00, 06, 2D, 16, 72, A2, 49, 00, 70, 04, 6F, 02, 0F, 00, 06]
        // .code-bytes IL_0090: [28, 7B, 00, 00, 0A, 73, 78, 00, 00, 0A, 7A, 14, 02, 28, ED, 02, 00, 06, 72, E2, 47, 00, 70, 6F]
        // .code-bytes IL_00A8: [04, 0F, 00, 06, 04, 6F, 02, 0F, 00, 06, 72, D2, 49, 00, 70, 28, 7B, 00, 00, 0A, 17, 14, 28, F0]
        // .code-bytes IL_00C0: [03, 00, 06, 73, ED, 03, 00, 06, 0A, 7E, 46, 02, 00, 04, 0C, 16, 0D, 2B, 12, 08, 09, 9A, 13, 04]
        // .code-bytes IL_00D8: [11, 04, 02, 06, 6F, E7, 02, 00, 06, 09, 17, 58, 0D, 09, 08, 8E, 69, 32, E8, 02, 28, E9, 02, 00]
        // .code-bytes IL_00F0: [06, 1F, 0B, 2F, 49, 12, 05, 1F, 25, 18, 28, C4, 00, 00, 0A, 12, 05, 72, E6, 49, 00, 70, 28, C5]
        // .code-bytes IL_0108: [00, 00, 0A, 12, 05, 02, 28, E9, 02, 00, 06, 28, 13, 00, 00, 2B, 12, 05, 72, FE, 49, 00, 70, 28]
        // .code-bytes IL_0120: [C5, 00, 00, 0A, 12, 05, 04, 6F, 02, 0F, 00, 06, 28, D4, 00, 00, 0A, 12, 05, 28, C7, 00, 00, 0A]
        // .code-bytes IL_0138: [73, 78, 00, 00, 0A, 7A, 02, 06, 72, 34, 4A, 00, 70, 6F, E8, 03, 00, 06, 25, 2D, 08, 26, 7E, 57]
        // .code-bytes IL_0150: [03, 00, 0A, 2B, 0A, 7B, FB, 02, 00, 04, 7B, 02, 03, 00, 04, 8C, DF, 00, 00, 1B, 7D, 52, 02, 00]
        // .code-bytes IL_0168: [04, 02, 06, 72, 44, 4A, 00, 70, 6F, E8, 03, 00, 06, 25, 2D, 08, 26, 7E, 57, 03, 00, 0A, 2B, 0A]
        // .code-bytes IL_0180: [7B, FB, 02, 00, 04, 7B, 02, 03, 00, 04, 8C, DF, 00, 00, 1B, 7D, 53, 02, 00, 04, 02, 03, 7B, 09]
        // .code-bytes IL_0198: [03, 00, 04, 6F, 59, 00, 00, 2B, 7D, 5D, 02, 00, 04, 12, 01, 02, 28, EB, 02, 00, 06, 7B, 9F, 03]
        // .code-bytes IL_01B0: [00, 04, 02, 28, EB, 02, 00, 06, 7B, A0, 03, 00, 04, 28, FD, 0B, 00, 06, 02, 02, 7B, 5D, 02, 00]
        // .code-bytes IL_01C8: [04, 7B, 9D, 02, 00, 04, 07, 73, 59, 03, 00, 0A, 28, FE, 02, 00, 06, 02, 02, 7B, 5D, 02, 00, 04]
        // .code-bytes IL_01E0: [7B, 9D, 02, 00, 04, 07, 73, 5A, 03, 00, 0A, 28, 00, 03, 00, 06, 02, 02, 7B, 5D, 02, 00, 04, 7B]
        // .code-bytes IL_01F8: [9D, 02, 00, 04, 07, 73, 5B, 03, 00, 0A, 28, 02, 03, 00, 06, 02, 02, 7B, 5D, 02, 00, 04, 7B, 9D]
        // .code-bytes IL_0210: [02, 00, 04, 07, 73, 5B, 03, 00, 0A, 28, 04, 03, 00, 06, 02, 28, ED, 02, 00, 06, 72, F4, 47, 00]
        // .code-bytes IL_0228: [70, 6F, 04, 0F, 00, 06, 13, 06, 12, 07, 11, 06, 02, 28, EB, 02, 00, 06, 28, E5, 02, 00, 06, 11]
        // .code-bytes IL_0240: [07, 7B, 35, 02, 00, 04, 16, 43, 89, 00, 00, 00, 11, 06, 11, 07, 7B, 35, 02, 00, 04, 6E, 6F, EC]
        // .code-bytes IL_0258: [00, 00, 0A, 16, 13, 08, 2B, 66, 16, 13, 09, 2B, 4C, 11, 06, 28, 9E, 05, 00, 06, 13, 0A, 11, 06]
        // .code-bytes IL_0270: [28, 9D, 05, 00, 06, 13, 0B, 11, 0B, 20, FF, 00, 00, 00, 33, 0E, 11, 08, 1A, 5D, 11, 09, 1A, 5D]
        // .code-bytes IL_0288: [1A, 5A, 58, D2, 13, 0B, 02, 28, FD, 02, 00, 06, 11, 08, 11, 09, 73, 21, 04, 00, 06, 11, 0A, 11]
        // .code-bytes IL_02A0: [0B, 73, D3, 03, 00, 06, 6F, 60, 03, 00, 0A, 11, 09, 17, 58, 13, 09, 11, 09, 02, 28, EB, 02, 00]
        // .code-bytes IL_02B8: [06, 7B, A0, 03, 00, 04, 32, A5, 11, 08, 17, 58, 13, 08, 11, 08, 02, 28, EB, 02, 00, 06, 7B, 9F]
        // .code-bytes IL_02D0: [03, 00, 04, 32, 8B, 11, 07, 7B, 37, 02, 00, 04, 16, 36, 72, 11, 06, 11, 07, 7B, 37, 02, 00, 04]
        // .code-bytes IL_02E8: [6E, 6F, EC, 00, 00, 0A, 16, 13, 0C, 2B, 4F, 16, 13, 0D, 2B, 35, 11, 06, 28, 9D, 05, 00, 06, 13]
        // .code-bytes IL_0300: [0E, 11, 06, 28, 9D, 05, 00, 06, 13, 0F, 02, 28, FF, 02, 00, 06, 11, 0C, 11, 0D, 73, 21, 04, 00]
        // .code-bytes IL_0318: [06, 11, 0E, 11, 0F, 73, D6, 03, 00, 06, 6F, 61, 03, 00, 0A, 11, 0D, 17, 58, 13, 0D, 11, 0D, 02]
        // .code-bytes IL_0330: [28, EB, 02, 00, 06, 7B, A0, 03, 00, 04, 32, BC, 11, 0C, 17, 58, 13, 0C, 11, 0C, 02, 28, EB, 02]
        // .code-bytes IL_0348: [00, 06, 7B, 9F, 03, 00, 04, 32, A2, 11, 07, 7B, 36, 02, 00, 04, 16, 36, 6F, 11, 06, 11, 07, 7B]
        // .code-bytes IL_0360: [36, 02, 00, 04, 6E, 6F, EC, 00, 00, 0A, 16, 13, 10, 2B, 4C, 16, 13, 11, 2B, 32, 02, 28, 01, 03]
        // .code-bytes IL_0378: [00, 06, 11, 10, 11, 11, 73, 21, 04, 00, 06, 11, 06, 28, 9D, 05, 00, 06, 16, 02, 7B, 5D, 02, 00]
        // .code-bytes IL_0390: [04, 7B, 9F, 02, 00, 04, 28, A3, 00, 00, 2B, 6F, 62, 03, 00, 0A, 11, 11, 17, 58, 13, 11, 11, 11]
        // .code-bytes IL_03A8: [02, 28, EB, 02, 00, 06, 7B, A0, 03, 00, 04, 32, BF, 11, 10, 17, 58, 13, 10, 11, 10, 02, 28, EB]
        // .code-bytes IL_03C0: [02, 00, 06, 7B, 9F, 03, 00, 04, 32, A5, DE, 0C, 11, 06, 2C, 07, 11, 06, 6F, 17, 00, 00, 0A, DC]
        // .code-bytes IL_03D8: [02, 7B, 5D, 02, 00, 04, 7B, 9F, 02, 00, 04, 16, 31, 45, 02, 28, FD, 02, 00, 06, 02, FE, 06, 15]
        // .code-bytes IL_03F0: [03, 00, 06, 73, 5D, 03, 00, 0A, 6F, 5E, 03, 00, 0A, 02, 28, FD, 02, 00, 06, 02, FE, 06, 17, 03]
        // .code-bytes IL_0408: [00, 06, 73, 5D, 03, 00, 0A, 6F, 5E, 03, 00, 0A, 02, 28, 01, 03, 00, 06, 02, FE, 06, 17, 03, 00]
        // .code-bytes IL_0420: [06, 73, 5D, 03, 00, 0A, 6F, 5F, 03, 00, 0A, 02, 28, 14, 03, 00, 06, 02, 02, 28, ED, 02, 00, 06]
        // .code-bytes IL_0438: [02, 28, E9, 02, 00, 06, 28, 10, 03, 00, 06, 28, F0, 02, 00, 06, 2A]
        // .local [0] class OpenRA.MiniYaml
        // .local [1] valuetype OpenRA.Primitives.Size
        // .local [2] class OpenRA.MapField[]
        // .local [3] int32
        // .local [4] class OpenRA.MapField
        // .local [5] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // .local [6] class [System.Runtime]System.IO.Stream
        // .local [7] valuetype OpenRA.BinaryDataHeader
        // .local [8] int32
        // .local [9] int32
        // .local [10] uint16
        // .local [11] uint8
        // .local [12] int32
        // .local [13] int32
        // .local [14] uint8
        // .local [15] uint8
        // .local [16] int32
        // .local [17] int32
        // IL_0000: ldarg.0 0
        // IL_0001: ldc.i4.2 2
        // IL_0002: stfld 0x04000248 OpenRA.Map::TileFormat
        // IL_0007: ldarg.0 0
        // IL_0008: ldc.i4.1 1
        // IL_0009: stfld 0x0400024F OpenRA.Map::Visibility
        // IL_000E: ldarg.0 0
        // IL_000F: ldc.i4.1 1
        // IL_0010: newarr 0x010000FE [System.Runtime]System.String
        // IL_0015: dup 
        // IL_0016: ldc.i4.0 0
        // IL_0017: ldstr 0x7000494C [67, 111, 110, 113, 117, 101, 115, 116] utf16-bytes=[43, 00, 6F, 00, 6E, 00, 71, 00, 75, 00, 65, 00, 73, 00, 74, 00] terminal-flag=Some(0)
        // IL_001C: stelem.ref 
        // IL_001D: stfld 0x04000250 OpenRA.Map::Categories
        // IL_0022: ldarg.0 0
        // IL_0023: ldsfld 0x0A000357 valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>::Empty
        // IL_0028: box 0x1B0000DF valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>
        // IL_002D: stfld 0x04000252 OpenRA.Map::PlayerDefinitions
        // IL_0032: ldarg.0 0
        // IL_0033: ldsfld 0x0A000357 valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>::Empty
        // IL_0038: box 0x1B0000DF valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>
        // IL_003D: stfld 0x04000253 OpenRA.Map::ActorDefinitions
        // IL_0042: ldarg.0 0
        // IL_0043: newobj 0x0A000358 class [System.Collections]System.Collections.Generic.Dictionary`2<valuetype OpenRA.CPos, valuetype OpenRA.TerrainTile>::.ctor
        // IL_0048: stfld 0x0400025C OpenRA.Map::ReplacedInvalidTerrainTiles
        // IL_004D: ldarg.0 0
        // IL_004E: call 0x0A00005B [System.Runtime]System.Object::.ctor
        // IL_0053: ldarg.0 0
        // IL_0054: ldarg.1 1
        // IL_0055: stfld 0x0400026F OpenRA.Map::modData
        // IL_005A: ldarg.0 0
        // IL_005B: ldarg.2 2
        // IL_005C: call 0x060002EE OpenRA.Map::set_Package
        // IL_0061: ldarg.0 0
        // IL_0062: call 0x060002ED OpenRA.Map::get_Package
        // IL_0067: ldstr 0x700047E2 [109, 97, 112, 46, 121, 97, 109, 108] utf16-bytes=[6D, 00, 61, 00, 70, 00, 2E, 00, 79, 00, 61, 00, 6D, 00, 6C, 00] terminal-flag=Some(0)
        // IL_006C: callvirt 0x06000F05 OpenRA.FileSystem.IReadOnlyPackage::Contains
        // IL_0071: brfalse.s IL_0085
        // IL_0073: ldarg.0 0
        // IL_0074: call 0x060002ED OpenRA.Map::get_Package
        // IL_0079: ldstr 0x700047F4 [109, 97, 112, 46, 98, 105, 110] utf16-bytes=[6D, 00, 61, 00, 70, 00, 2E, 00, 62, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_007E: callvirt 0x06000F05 OpenRA.FileSystem.IReadOnlyPackage::Contains
        // IL_0083: brtrue.s IL_009B
        // IL_0085: ldstr 0x700049A2 [78, 111, 116, 32, 97, 32, 118, 97, 108, 105, 100, 32, 109, 97, 112, 10, 32, 70, 105, 108, 101, 58, 32] utf16-bytes=[4E, 00, 6F, 00, 74, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 6D, 00, 61, 00, 70, 00, 0A, 00, 20, 00, 46, 00, 69, 00, 6C, 00, 65, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_008A: ldarg.2 2
        // IL_008B: callvirt 0x06000F02 OpenRA.FileSystem.IReadOnlyPackage::get_Name
        // IL_0090: call 0x0A00007B [System.Runtime]System.String::Concat
        // IL_0095: newobj 0x0A000078 [System.Runtime]System.IO.InvalidDataException::.ctor
        // IL_009A: throw 
        // IL_009B: ldnull 
        // IL_009C: ldarg.0 0
        // IL_009D: call 0x060002ED OpenRA.Map::get_Package
        // IL_00A2: ldstr 0x700047E2 [109, 97, 112, 46, 121, 97, 109, 108] utf16-bytes=[6D, 00, 61, 00, 70, 00, 2E, 00, 79, 00, 61, 00, 6D, 00, 6C, 00] terminal-flag=Some(0)
        // IL_00A7: callvirt 0x06000F04 OpenRA.FileSystem.IReadOnlyPackage::GetStream
        // IL_00AC: ldarg.2 2
        // IL_00AD: callvirt 0x06000F02 OpenRA.FileSystem.IReadOnlyPackage::get_Name
        // IL_00B2: ldstr 0x700049D2 [58, 109, 97, 112, 46, 121, 97, 109, 108] utf16-bytes=[3A, 00, 6D, 00, 61, 00, 70, 00, 2E, 00, 79, 00, 61, 00, 6D, 00, 6C, 00] terminal-flag=Some(0)
        // IL_00B7: call 0x0A00007B [System.Runtime]System.String::Concat
        // IL_00BC: ldc.i4.1 1
        // IL_00BD: ldnull 
        // IL_00BE: call 0x060003F0 OpenRA.MiniYaml::FromStream
        // IL_00C3: newobj 0x060003ED OpenRA.MiniYaml::.ctor
        // IL_00C8: stloc.0 0
        // IL_00C9: ldsfld 0x04000246 OpenRA.Map::YamlFields
        // IL_00CE: stloc.2 2
        // IL_00CF: ldc.i4.0 0
        // IL_00D0: stloc.3 3
        // IL_00D1: br.s IL_00E5
        // IL_00D3: ldloc.2 2
        // IL_00D4: ldloc.3 3
        // IL_00D5: ldelem.ref 
        // IL_00D6: stloc.s 4
        // IL_00D8: ldloc.s 4
        // IL_00DA: ldarg.0 0
        // IL_00DB: ldloc.0 0
        // IL_00DC: callvirt 0x060002E7 OpenRA.MapField::Deserialize
        // IL_00E1: ldloc.3 3
        // IL_00E2: ldc.i4.1 1
        // IL_00E3: add 
        // IL_00E4: stloc.3 3
        // IL_00E5: ldloc.3 3
        // IL_00E6: ldloc.2 2
        // IL_00E7: ldlen 
        // IL_00E8: conv.i4 
        // IL_00E9: blt.s IL_00D3
        // IL_00EB: ldarg.0 0
        // IL_00EC: call 0x060002E9 OpenRA.Map::get_MapFormat
        // IL_00F1: ldc.i4.s 11
        // IL_00F3: bge.s IL_013E
        // IL_00F5: ldloca.s 5
        // IL_00F7: ldc.i4.s 37
        // IL_00F9: ldc.i4.2 2
        // IL_00FA: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_00FF: ldloca.s 5
        // IL_0101: ldstr 0x700049E6 [77, 97, 112, 32, 102, 111, 114, 109, 97, 116, 32] utf16-bytes=[4D, 00, 61, 00, 70, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 61, 00, 74, 00, 20, 00] terminal-flag=Some(0)
        // IL_0106: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_010B: ldloca.s 5
        // IL_010D: ldarg.0 0
        // IL_010E: call 0x060002E9 OpenRA.Map::get_MapFormat
        // IL_0113: call 0x2B000013 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_0118: ldloca.s 5
        // IL_011A: ldstr 0x700049FE [32, 105, 115, 32, 110, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 46, 10, 32, 70, 105, 108, 101, 58, 32] utf16-bytes=[20, 00, 69, 00, 73, 00, 20, 00, 6E, 00, 6F, 00, 74, 00, 20, 00, 73, 00, 75, 00, 70, 00, 70, 00, 6F, 00, 72, 00, 74, 00, 65, 00, 64, 00, 2E, 00, 0A, 00, 20, 00, 46, 00, 69, 00, 6C, 00, 65, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_011F: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0124: ldloca.s 5
        // IL_0126: ldarg.2 2
        // IL_0127: callvirt 0x06000F02 OpenRA.FileSystem.IReadOnlyPackage::get_Name
        // IL_012C: call 0x0A0000D4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted
        // IL_0131: ldloca.s 5
        // IL_0133: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0138: newobj 0x0A000078 [System.Runtime]System.IO.InvalidDataException::.ctor
        // IL_013D: throw 
        // IL_013E: ldarg.0 0
        // IL_013F: ldloc.0 0
        // IL_0140: ldstr 0x70004A34 [80, 108, 97, 121, 101, 114, 115] utf16-bytes=[50, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00, 73, 00] terminal-flag=Some(0)
        // IL_0145: callvirt 0x060003E8 OpenRA.MiniYaml::NodeWithKeyOrDefault
        // IL_014A: dup 
        // IL_014B: brtrue.s IL_0155
        // IL_014D: pop 
        // IL_014E: ldsfld 0x0A000357 valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>::Empty
        // IL_0153: br.s IL_015F
        // IL_0155: ldfld 0x040002FB OpenRA.MiniYamlNode::Value
        // IL_015A: ldfld 0x04000302 OpenRA.MiniYaml::Nodes
        // IL_015F: box 0x1B0000DF valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>
        // IL_0164: stfld 0x04000252 OpenRA.Map::PlayerDefinitions
        // IL_0169: ldarg.0 0
        // IL_016A: ldloc.0 0
        // IL_016B: ldstr 0x70004A44 [65, 99, 116, 111, 114, 115] utf16-bytes=[41, 00, 63, 00, 74, 00, 6F, 00, 72, 00, 73, 00] terminal-flag=Some(0)
        // IL_0170: callvirt 0x060003E8 OpenRA.MiniYaml::NodeWithKeyOrDefault
        // IL_0175: dup 
        // IL_0176: brtrue.s IL_0180
        // IL_0178: pop 
        // IL_0179: ldsfld 0x0A000357 valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>::Empty
        // IL_017E: br.s IL_018A
        // IL_0180: ldfld 0x040002FB OpenRA.MiniYamlNode::Value
        // IL_0185: ldfld 0x04000302 OpenRA.MiniYaml::Nodes
        // IL_018A: box 0x1B0000DF valuetype [System.Collections.Immutable]System.Collections.Immutable.ImmutableArray`1<class OpenRA.MiniYamlNode>
        // IL_018F: stfld 0x04000253 OpenRA.Map::ActorDefinitions
        // IL_0194: ldarg.0 0
        // IL_0195: ldarg.1 1
        // IL_0196: ldfld 0x04000309 OpenRA.ModData::Manifest
        // IL_019B: callvirt 0x2B000059 OpenRA.Manifest::Get<class OpenRA.MapGrid>
        // IL_01A0: stfld 0x0400025D OpenRA.Map::Grid
        // IL_01A5: ldloca.s 1
        // IL_01A7: ldarg.0 0
        // IL_01A8: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_01AD: ldfld 0x0400039F OpenRA.int2::X
        // IL_01B2: ldarg.0 0
        // IL_01B3: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_01B8: ldfld 0x040003A0 OpenRA.int2::Y
        // IL_01BD: call 0x06000BFD OpenRA.Primitives.Size::.ctor
        // IL_01C2: ldarg.0 0
        // IL_01C3: ldarg.0 0
        // IL_01C4: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_01C9: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_01CE: ldloc.1 1
        // IL_01CF: newobj 0x0A000359 class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::.ctor
        // IL_01D4: call 0x060002FE OpenRA.Map::set_Tiles
        // IL_01D9: ldarg.0 0
        // IL_01DA: ldarg.0 0
        // IL_01DB: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_01E0: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_01E5: ldloc.1 1
        // IL_01E6: newobj 0x0A00035A class OpenRA.CellLayer`1<valuetype OpenRA.ResourceTile>::.ctor
        // IL_01EB: call 0x06000300 OpenRA.Map::set_Resources
        // IL_01F0: ldarg.0 0
        // IL_01F1: ldarg.0 0
        // IL_01F2: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_01F7: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_01FC: ldloc.1 1
        // IL_01FD: newobj 0x0A00035B class OpenRA.CellLayer`1<uint8>::.ctor
        // IL_0202: call 0x06000302 OpenRA.Map::set_Height
        // IL_0207: ldarg.0 0
        // IL_0208: ldarg.0 0
        // IL_0209: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_020E: ldfld 0x0400029D OpenRA.MapGrid::Type
        // IL_0213: ldloc.1 1
        // IL_0214: newobj 0x0A00035B class OpenRA.CellLayer`1<uint8>::.ctor
        // IL_0219: call 0x06000304 OpenRA.Map::set_Ramp
        // IL_021E: ldarg.0 0
        // IL_021F: call 0x060002ED OpenRA.Map::get_Package
        // IL_0224: ldstr 0x700047F4 [109, 97, 112, 46, 98, 105, 110] utf16-bytes=[6D, 00, 61, 00, 70, 00, 2E, 00, 62, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_0229: callvirt 0x06000F04 OpenRA.FileSystem.IReadOnlyPackage::GetStream
        // IL_022E: stloc.s 6
        // IL_0230: ldloca.s 7
        // IL_0232: ldloc.s 6
        // IL_0234: ldarg.0 0
        // IL_0235: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_023A: call 0x060002E5 OpenRA.BinaryDataHeader::.ctor
        // IL_023F: ldloc.s 7
        // IL_0241: ldfld 0x04000235 OpenRA.BinaryDataHeader::TilesOffset
        // IL_0246: ldc.i4.0 0
        // IL_0247: ble.un IL_02D5
        // IL_024C: ldloc.s 6
        // IL_024E: ldloc.s 7
        // IL_0250: ldfld 0x04000235 OpenRA.BinaryDataHeader::TilesOffset
        // IL_0255: conv.u8 
        // IL_0256: callvirt 0x0A0000EC [System.Runtime]System.IO.Stream::set_Position
        // IL_025B: ldc.i4.0 0
        // IL_025C: stloc.s 8
        // IL_025E: br.s IL_02C6
        // IL_0260: ldc.i4.0 0
        // IL_0261: stloc.s 9
        // IL_0263: br.s IL_02B1
        // IL_0265: ldloc.s 6
        // IL_0267: call 0x0600059E OpenRA.StreamExts::ReadUInt16
        // IL_026C: stloc.s 10
        // IL_026E: ldloc.s 6
        // IL_0270: call 0x0600059D OpenRA.StreamExts::ReadUInt8
        // IL_0275: stloc.s 11
        // IL_0277: ldloc.s 11
        // IL_0279: ldc.i4 255
        // IL_027E: bne.un.s IL_028E
        // IL_0280: ldloc.s 8
        // IL_0282: ldc.i4.4 4
        // IL_0283: rem 
        // IL_0284: ldloc.s 9
        // IL_0286: ldc.i4.4 4
        // IL_0287: rem 
        // IL_0288: ldc.i4.4 4
        // IL_0289: mul 
        // IL_028A: add 
        // IL_028B: conv.u1 
        // IL_028C: stloc.s 11
        // IL_028E: ldarg.0 0
        // IL_028F: call 0x060002FD OpenRA.Map::get_Tiles
        // IL_0294: ldloc.s 8
        // IL_0296: ldloc.s 9
        // IL_0298: newobj 0x06000421 OpenRA.MPos::.ctor
        // IL_029D: ldloc.s 10
        // IL_029F: ldloc.s 11
        // IL_02A1: newobj 0x060003D3 OpenRA.TerrainTile::.ctor
        // IL_02A6: callvirt 0x0A000360 class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::set_Item
        // IL_02AB: ldloc.s 9
        // IL_02AD: ldc.i4.1 1
        // IL_02AE: add 
        // IL_02AF: stloc.s 9
        // IL_02B1: ldloc.s 9
        // IL_02B3: ldarg.0 0
        // IL_02B4: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_02B9: ldfld 0x040003A0 OpenRA.int2::Y
        // IL_02BE: blt.s IL_0265
        // IL_02C0: ldloc.s 8
        // IL_02C2: ldc.i4.1 1
        // IL_02C3: add 
        // IL_02C4: stloc.s 8
        // IL_02C6: ldloc.s 8
        // IL_02C8: ldarg.0 0
        // IL_02C9: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_02CE: ldfld 0x0400039F OpenRA.int2::X
        // IL_02D3: blt.s IL_0260
        // IL_02D5: ldloc.s 7
        // IL_02D7: ldfld 0x04000237 OpenRA.BinaryDataHeader::ResourcesOffset
        // IL_02DC: ldc.i4.0 0
        // IL_02DD: ble.un.s IL_0351
        // IL_02DF: ldloc.s 6
        // IL_02E1: ldloc.s 7
        // IL_02E3: ldfld 0x04000237 OpenRA.BinaryDataHeader::ResourcesOffset
        // IL_02E8: conv.u8 
        // IL_02E9: callvirt 0x0A0000EC [System.Runtime]System.IO.Stream::set_Position
        // IL_02EE: ldc.i4.0 0
        // IL_02EF: stloc.s 12
        // IL_02F1: br.s IL_0342
        // IL_02F3: ldc.i4.0 0
        // IL_02F4: stloc.s 13
        // IL_02F6: br.s IL_032D
        // IL_02F8: ldloc.s 6
        // IL_02FA: call 0x0600059D OpenRA.StreamExts::ReadUInt8
        // IL_02FF: stloc.s 14
        // IL_0301: ldloc.s 6
        // IL_0303: call 0x0600059D OpenRA.StreamExts::ReadUInt8
        // IL_0308: stloc.s 15
        // IL_030A: ldarg.0 0
        // IL_030B: call 0x060002FF OpenRA.Map::get_Resources
        // IL_0310: ldloc.s 12
        // IL_0312: ldloc.s 13
        // IL_0314: newobj 0x06000421 OpenRA.MPos::.ctor
        // IL_0319: ldloc.s 14
        // IL_031B: ldloc.s 15
        // IL_031D: newobj 0x060003D6 OpenRA.ResourceTile::.ctor
        // IL_0322: callvirt 0x0A000361 class OpenRA.CellLayer`1<valuetype OpenRA.ResourceTile>::set_Item
        // IL_0327: ldloc.s 13
        // IL_0329: ldc.i4.1 1
        // IL_032A: add 
        // IL_032B: stloc.s 13
        // IL_032D: ldloc.s 13
        // IL_032F: ldarg.0 0
        // IL_0330: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_0335: ldfld 0x040003A0 OpenRA.int2::Y
        // IL_033A: blt.s IL_02F8
        // IL_033C: ldloc.s 12
        // IL_033E: ldc.i4.1 1
        // IL_033F: add 
        // IL_0340: stloc.s 12
        // IL_0342: ldloc.s 12
        // IL_0344: ldarg.0 0
        // IL_0345: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_034A: ldfld 0x0400039F OpenRA.int2::X
        // IL_034F: blt.s IL_02F3
        // IL_0351: ldloc.s 7
        // IL_0353: ldfld 0x04000236 OpenRA.BinaryDataHeader::HeightsOffset
        // IL_0358: ldc.i4.0 0
        // IL_0359: ble.un.s IL_03CA
        // IL_035B: ldloc.s 6
        // IL_035D: ldloc.s 7
        // IL_035F: ldfld 0x04000236 OpenRA.BinaryDataHeader::HeightsOffset
        // IL_0364: conv.u8 
        // IL_0365: callvirt 0x0A0000EC [System.Runtime]System.IO.Stream::set_Position
        // IL_036A: ldc.i4.0 0
        // IL_036B: stloc.s 16
        // IL_036D: br.s IL_03BB
        // IL_036F: ldc.i4.0 0
        // IL_0370: stloc.s 17
        // IL_0372: br.s IL_03A6
        // IL_0374: ldarg.0 0
        // IL_0375: call 0x06000301 OpenRA.Map::get_Height
        // IL_037A: ldloc.s 16
        // IL_037C: ldloc.s 17
        // IL_037E: newobj 0x06000421 OpenRA.MPos::.ctor
        // IL_0383: ldloc.s 6
        // IL_0385: call 0x0600059D OpenRA.StreamExts::ReadUInt8
        // IL_038A: ldc.i4.0 0
        // IL_038B: ldarg.0 0
        // IL_038C: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_0391: ldfld 0x0400029F OpenRA.MapGrid::MaximumTerrainHeight
        // IL_0396: call 0x2B0000A3 OpenRA.Exts::Clamp<uint8>
        // IL_039B: callvirt 0x0A000362 class OpenRA.CellLayer`1<uint8>::set_Item
        // IL_03A0: ldloc.s 17
        // IL_03A2: ldc.i4.1 1
        // IL_03A3: add 
        // IL_03A4: stloc.s 17
        // IL_03A6: ldloc.s 17
        // IL_03A8: ldarg.0 0
        // IL_03A9: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_03AE: ldfld 0x040003A0 OpenRA.int2::Y
        // IL_03B3: blt.s IL_0374
        // IL_03B5: ldloc.s 16
        // IL_03B7: ldc.i4.1 1
        // IL_03B8: add 
        // IL_03B9: stloc.s 16
        // IL_03BB: ldloc.s 16
        // IL_03BD: ldarg.0 0
        // IL_03BE: call 0x060002EB OpenRA.Map::get_MapSize
        // IL_03C3: ldfld 0x0400039F OpenRA.int2::X
        // IL_03C8: blt.s IL_036F
        // IL_03CA: leave.s IL_03D8
        // IL_03CC: ldloc.s 6
        // IL_03CE: brfalse.s IL_03D7
        // IL_03D0: ldloc.s 6
        // IL_03D2: callvirt 0x0A000017 [System.Runtime]System.IDisposable::Dispose
        // IL_03D7: endfinally 
        // IL_03D8: ldarg.0 0
        // IL_03D9: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_03DE: ldfld 0x0400029F OpenRA.MapGrid::MaximumTerrainHeight
        // IL_03E3: ldc.i4.0 0
        // IL_03E4: ble.s IL_042B
        // IL_03E6: ldarg.0 0
        // IL_03E7: call 0x060002FD OpenRA.Map::get_Tiles
        // IL_03EC: ldarg.0 0
        // IL_03ED: ldftn 0x06000315 OpenRA.Map::UpdateRamp
        // IL_03F3: newobj 0x0A00035D class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>::.ctor
        // IL_03F8: callvirt 0x0A00035E class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::add_CellEntryChanged
        // IL_03FD: ldarg.0 0
        // IL_03FE: call 0x060002FD OpenRA.Map::get_Tiles
        // IL_0403: ldarg.0 0
        // IL_0404: ldftn 0x06000317 OpenRA.Map::UpdateProjection
        // IL_040A: newobj 0x0A00035D class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>::.ctor
        // IL_040F: callvirt 0x0A00035E class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::add_CellEntryChanged
        // IL_0414: ldarg.0 0
        // IL_0415: call 0x06000301 OpenRA.Map::get_Height
        // IL_041A: ldarg.0 0
        // IL_041B: ldftn 0x06000317 OpenRA.Map::UpdateProjection
        // IL_0421: newobj 0x0A00035D class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>::.ctor
        // IL_0426: callvirt 0x0A00035F class OpenRA.CellLayer`1<uint8>::add_CellEntryChanged
        // IL_042B: ldarg.0 0
        // IL_042C: call 0x06000314 OpenRA.Map::PostInit
        // IL_0431: ldarg.0 0
        // IL_0432: ldarg.0 0
        // IL_0433: call 0x060002ED OpenRA.Map::get_Package
        // IL_0438: ldarg.0 0
        // IL_0439: call 0x060002E9 OpenRA.Map::get_MapFormat
        // IL_043E: call 0x06000310 OpenRA.Map::ComputeUID
        // IL_0443: call 0x060002F0 OpenRA.Map::set_Uid
        // IL_0448: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 560, try_length: 412, handler_offset: 972, handler_length: 12, raw_flags: 2 }
        // .try IL_0230..IL_03CC finally IL_03CC..IL_03D8
    }

    private void PostInit()
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 bytes=1512809D011124: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da bytes=151281A9011124: class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 bytes=118A80: valuetype OpenRA.MapCoordsRegion/MapCoordsEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_299c0a9e4ee68e8e364bd6722ba42a1d4e71cf6b bytes=1181A4: valuetype OpenRA.MapCoordsRegion; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab bytes=1181F4: valuetype OpenRA.TerrainTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_e1730fa0938fb44d026fb96788a83cd116f28e7c bytes=151280890211241181F4: class [System.Collections]System.Collections.Generic.Dictionary`2<valuetype OpenRA.CPos, valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 l0 = default;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 l1 = default;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 l2 = default;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 l3 = default;
        OpenRA.ITerrainInfo l4 = default;
        System.Exception l5 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l6 = default;
        __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 l7 = default;
        __cil_value_299c0a9e4ee68e8e364bd6722ba42a1d4e71cf6b l8 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l9 = default;
        __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 l10 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l11 = default;
        OpenRA.TerrainTileInfo l12 = default;
        System.Exception s1_0 = default;
        try {
            IL_0000: ;
            global::OpenRA.Map v0 = this;
            global::OpenRA.Map v1 = this;
            global::OpenRA.ModData v2 = v1.modData;
            global::OpenRA.Map v3 = this;
            global::OpenRA.Map v4 = this;
            string v5 = v4.Tileset;
            global::OpenRA.Map v6 = this;
            global::OpenRA.MiniYaml v7 = v6.RuleDefinitions;
            global::OpenRA.Map v8 = this;
            global::OpenRA.MiniYaml v9 = v8.WeaponDefinitions;
            global::OpenRA.Map v10 = this;
            global::OpenRA.MiniYaml v11 = v10.VoiceDefinitions;
            global::OpenRA.Map v12 = this;
            global::OpenRA.MiniYaml v13 = v12.NotificationDefinitions;
            global::OpenRA.Map v14 = this;
            global::OpenRA.MiniYaml v15 = v14.MusicDefinitions;
            global::OpenRA.Map v16 = this;
            global::OpenRA.MiniYaml v17 = v16.ModelSequenceDefinitions;
            global::OpenRA.Ruleset v18 = OpenRA.Ruleset.Load(v2, ((OpenRA.FileSystem.IReadOnlyFileSystem)(v3)), v5, v7, v9, v11, v13, v15, v17);
            __cil_direct_060002F2(v0, v18);
            goto IL_0093;
        }
        catch (System.Exception __cil_exception_0) {
            IL_003E: ;
            s1_0 = __cil_exception_0;
            l5 = s1_0;
            string v19 = __cil_ldstr_7000061E("debug");
            string v20 = __cil_ldstr_70004A52("Failed to load rules for ");
            global::OpenRA.Map v21 = this;
            string v22 = v21.Title;
            string v23 = __cil_ldstr_70004A86(" with error");
            string v24 = System.String.Concat(v20, v22, v23);
            OpenRA.Log.Write(v19, v24);
            string v25 = __cil_ldstr_7000061E("debug");
            global::System.Exception v26 = l5;
            OpenRA.Log.Write(v25, v26);
            global::OpenRA.Map v27 = this;
            int v28 = 1;
            __cil_direct_060002F6(v27, __cil_bool_store(v28));
            global::OpenRA.Map v29 = this;
            global::System.Exception v30 = l5;
            __cil_direct_060002F8(v29, v30);
            global::OpenRA.Map v31 = this;
            global::OpenRA.Map v32 = this;
            global::OpenRA.ModData v33 = v32.modData;
            global::OpenRA.Map v34 = this;
            string v35 = v34.Tileset;
            global::OpenRA.Ruleset v36 = OpenRA.Ruleset.LoadDefaultsForTileSet(v33, v35);
            __cil_direct_060002F2(v31, v36);
            goto IL_0093;
        }
        IL_0093: ;
        global::OpenRA.Map v37 = this;
        global::OpenRA.Map v38 = this;
        global::OpenRA.Map v39 = this;
        global::OpenRA.ModData v40 = v39.modData;
        global::OpenRA.Map v41 = this;
        string v42 = v41.Tileset;
        global::OpenRA.Map v43 = this;
        global::OpenRA.MiniYaml v44 = v43.SequenceDefinitions;
        global::OpenRA.Graphics.SequenceSet v45 = __cil_newobj_06000DBF(v38, v40, v42, v44);
        __cil_direct_060002F4(v37, v45);
        int v46 = 0;
        int v47 = 0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v48 = __cil_value_newobj_06000421(v46, v47);
        l6 = v48;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v49 = ref l6;
        global::OpenRA.Map v50 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v51 = __cil_direct_06000429(ref v49, v50);
        l0 = v51;
        global::OpenRA.Map v52 = this;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v53 = __cil_direct_060002EB(v52);
        int v54 = v53.X;
        int v55 = 1;
        int v56 = unchecked(v54 - v55);
        global::OpenRA.Map v57 = this;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v58 = __cil_direct_060002EB(v57);
        int v59 = v58.Y;
        int v60 = 1;
        int v61 = unchecked(v59 - v60);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v62 = __cil_value_newobj_06000421(v56, v61);
        l6 = v62;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v63 = ref l6;
        global::OpenRA.Map v64 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v65 = __cil_direct_06000429(ref v63, v64);
        l1 = v65;
        global::OpenRA.Map v66 = this;
        global::OpenRA.Map v67 = this;
        global::OpenRA.MapGrid v68 = v67.Grid;
        int v69 = unchecked((int)(v68.Type));
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v70 = l0;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v71 = l1;
        global::OpenRA.CellRegion v72 = __cil_newobj_060002D9(v69, v70, v71);
        __cil_direct_0600030A(v66, v72);
        ref __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v73 = ref l2;
        global::OpenRA.Map v74 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v75 = ref v74.Bounds;
        int v76 = __cil_direct_06000BBA(ref v75);
        global::OpenRA.Map v77 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v78 = ref v77.Bounds;
        int v79 = __cil_direct_06000BBC(ref v78);
        __cil_value_ctor_0600042C(ref v73, v76, v79);
        ref __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v80 = ref l3;
        global::OpenRA.Map v81 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v82 = ref v81.Bounds;
        int v83 = __cil_direct_06000BBB(ref v82);
        int v84 = 1;
        int v85 = unchecked(v83 - v84);
        global::OpenRA.Map v86 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v87 = ref v86.Bounds;
        int v88 = __cil_direct_06000BBD(ref v87);
        int v89 = 1;
        int v90 = unchecked(v88 - v89);
        __cil_value_ctor_0600042C(ref v80, v85, v90);
        global::OpenRA.Map v91 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v92 = l2;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v93 = l3;
        __cil_direct_06000330(v91, v92, v93);
        global::OpenRA.Map v94 = this;
        global::OpenRA.Map v95 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v96 = __cil_newobj_0A000363(v95);
        __cil_direct_06000306(v94, v96);
        global::OpenRA.Map v97 = this;
        global::OpenRA.CellRegion v98 = __cil_direct_06000309(v97);
        __cil_value_299c0a9e4ee68e8e364bd6722ba42a1d4e71cf6b v99 = __cil_callvirt_060002E0(v98);
        l8 = v99;
        ref __cil_value_299c0a9e4ee68e8e364bd6722ba42a1d4e71cf6b v100 = ref l8;
        __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v101 = __cil_direct_06000364(ref v100);
        l7 = v101;
        try {
            IL_016D: ;
            goto IL_018A;
            IL_016F: ;
            ref __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v102 = ref l7;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v103 = __cil_direct_06001093(ref v102);
            l9 = v103;
            global::OpenRA.Map v104 = this;
            __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v105 = __cil_direct_06000305(v104);
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v106 = l9;
            int v107 = 255;
            v105.set_Item(v106, unchecked((byte)(v107)));
            goto IL_018A;
            IL_018A: ;
            ref __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v108 = ref l7;
            int v109 = __cil_bool_load(__cil_direct_06001091(ref v108));
            if (v109 != 0) {
                goto IL_016F;
            } else {
                goto IL_0193;
            }
            IL_0193: ;
            goto IL_01A3;
        }
        finally {
            IL_0195: ;
            ref __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v110 = ref l7;
            __cil_constrained_020002A0_0A000017(ref v110);
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_01A3: ;
        global::OpenRA.Map v111 = this;
        global::OpenRA.Ruleset v112 = __cil_direct_060002F1(v111);
        global::OpenRA.ITerrainInfo v113 = v112.TerrainInfo;
        l4 = v113;
        global::OpenRA.Map v114 = this;
        global::OpenRA.CellRegion v115 = __cil_direct_06000309(v114);
        __cil_value_299c0a9e4ee68e8e364bd6722ba42a1d4e71cf6b v116 = __cil_callvirt_060002E0(v115);
        l8 = v116;
        ref __cil_value_299c0a9e4ee68e8e364bd6722ba42a1d4e71cf6b v117 = ref l8;
        __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v118 = __cil_direct_06000364(ref v117);
        l10 = v118;
        try {
            IL_01C6: ;
            goto IL_0241;
            IL_01C8: ;
            ref __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v119 = ref l10;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v120 = __cil_direct_06001093(ref v119);
            l11 = v120;
            global::OpenRA.ITerrainInfo v121 = l4;
            global::OpenRA.Map v122 = this;
            __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v123 = __cil_direct_060002FD(v122);
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v124 = l11;
            __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v125 = v123.get_Item(v124);
            ref global::OpenRA.TerrainTileInfo v126 = ref l12;
            int v127 = __cil_bool_load(__cil_callvirt_060003C8(v121, v125, ref v126));
            if (v127 != 0) {
                goto IL_022D;
            } else {
                goto IL_01E9;
            }
            IL_01E9: ;
            global::OpenRA.Map v128 = this;
            __cil_ref_e1730fa0938fb44d026fb96788a83cd116f28e7c v129 = v128.ReplacedInvalidTerrainTiles;
            ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v130 = ref l11;
            global::OpenRA.Map v131 = this;
            __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v132 = __cil_direct_06000429(ref v130, v131);
            global::OpenRA.Map v133 = this;
            __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v134 = __cil_direct_060002FD(v133);
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v135 = l11;
            __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v136 = v134.get_Item(v135);
            __cil_callvirt_0A000365(v129, v132, v136);
            global::OpenRA.Map v137 = this;
            __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v138 = __cil_direct_060002FD(v137);
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v139 = l11;
            global::OpenRA.ITerrainInfo v140 = l4;
            __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v141 = __cil_callvirt_060003CB(v140);
            v138.set_Item(v139, v141);
            global::OpenRA.ITerrainInfo v142 = l4;
            global::OpenRA.ITerrainInfo v143 = l4;
            __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v144 = __cil_callvirt_060003CB(v143);
            global::OpenRA.TerrainTileInfo v145 = __cil_callvirt_060003C7(v142, v144);
            l12 = v145;
            goto IL_022D;
            IL_022D: ;
            global::OpenRA.Map v146 = this;
            __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v147 = __cil_direct_06000303(v146);
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v148 = l11;
            global::OpenRA.TerrainTileInfo v149 = l12;
            int v150 = unchecked((int)(v149.RampType));
            v147.set_Item(v148, unchecked((byte)(v150)));
            goto IL_0241;
            IL_0241: ;
            ref __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v151 = ref l10;
            int v152 = __cil_bool_load(__cil_direct_06001091(ref v151));
            if (v152 != 0) {
                goto IL_01C8;
            } else {
                goto IL_024D;
            }
            IL_024D: ;
            goto IL_025D;
        }
        finally {
            IL_024F: ;
            ref __cil_value_3abab9ccdf95b35784a0ce8d3b2a57bcf397f091 v153 = ref l10;
            __cil_constrained_020002A0_0A000017(ref v153);
            goto __cil_finally_end_2;
            __cil_finally_end_2: ;
        }
        IL_025D: ;
        global::OpenRA.Map v154 = this;
        global::OpenRA.Map v155 = this;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v156 = __cil_direct_0600033A(v155);
        __cil_direct_0600030C(v154, v156);
        global::OpenRA.Map v157 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v158 = __cil_direct_06000305(v157);
        global::OpenRA.Map v159 = this;
        nint v160 = __cil_ldftn_06000346;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v161 = __cil_newobj_0A00035D(v159, v160);
        v158.add_CellEntryChanged(v161);
        global::OpenRA.Map v162 = this;
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v163 = __cil_direct_060002FD(v162);
        global::OpenRA.Map v164 = this;
        nint v165 = __cil_ldftn_06000346;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v166 = __cil_newobj_0A00035D(v164, v165);
        v163.add_CellEntryChanged(v166);
        return;
    }

    private void UpdateRamp(OpenRA.CPos cell)
    {
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab bytes=1181F4: valuetype OpenRA.TerrainTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06000303 kept: property source signature requires exact type identities.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = __cil_direct_06000303(this);
        global::OpenRA.Ruleset v4 = this.Rules;
        global::OpenRA.ITerrainInfo v5 = v4.TerrainInfo;
        // Exact call 0x060002FD kept: property source signature requires exact type identities.
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v7 = __cil_direct_060002FD(this);
        __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v9 = v7.get_Item(cell);
        global::OpenRA.TerrainTileInfo v10 = __cil_callvirt_060003C7(v5, v9);
        int v11 = unchecked((int)(v10.RampType));
        v1.set_Item(cell, unchecked((byte)(v11)));
        return;
    }

    private void InitializeCellProjection()
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 bytes=118A3C: valuetype OpenRA.CellRegion/CellRegionEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 bytes=15128180011D118224: class OpenRA.CellLayer`1<valuetype OpenRA.PPos[]>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d435109e911734ac2943470065f35a64fd95de6f bytes=15128180011512809D01118220: class OpenRA.CellLayer`1<class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 bytes=1512809D01118220: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 l0 = default;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 l1 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l2 = default;
        __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 l3 = default;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 l4 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        int v1 = __cil_bool_load(v0.initializedCellProjection);
        if (v1 == 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        global::OpenRA.Map v2 = this;
        int v3 = 1;
        v2.initializedCellProjection = __cil_bool_store(v3);
        global::OpenRA.Map v4 = this;
        global::OpenRA.Map v5 = this;
        __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 v6 = __cil_newobj_0A000368(v5);
        v4.cellProjection = v6;
        global::OpenRA.Map v7 = this;
        global::OpenRA.Map v8 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v9 = __cil_newobj_0A000369(v8);
        v7.inverseCellProjection = v9;
        global::OpenRA.Map v10 = this;
        global::OpenRA.Map v11 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v12 = __cil_newobj_0A000363(v11);
        v10.projectedHeight = v12;
        global::OpenRA.Map v13 = this;
        global::OpenRA.CellRegion v14 = __cil_direct_06000309(v13);
        __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v15 = __cil_callvirt_060002E2(v14);
        l0 = v15;
        try {
            IL_0040: ;
            goto IL_0080;
            IL_0042: ;
            ref __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v16 = ref l0;
            __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v17 = __cil_direct_0600103F(ref v16);
            l1 = v17;
            ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v18 = ref l1;
            global::OpenRA.Map v19 = this;
            global::OpenRA.MapGrid v20 = v19.Grid;
            int v21 = unchecked((int)(v20.Type));
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v22 = __cil_direct_06000065(ref v18, unchecked((__cil_enum_0200006B)(v21)));
            l2 = v22;
            global::OpenRA.Map v23 = this;
            __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 v24 = v23.cellProjection;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v25 = l2;
            __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v26 = __cil_methodspec_call_2B0000A4();
            v24.set_Item(v25, v26);
            global::OpenRA.Map v27 = this;
            __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v28 = v27.inverseCellProjection;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v29 = l2;
            int v30 = 1;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v31 = __cil_newobj_0A00036B(v30);
            v28.set_Item(v29, v31);
            goto IL_0080;
            IL_0080: ;
            ref __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v32 = ref l0;
            int v33 = __cil_bool_load(__cil_direct_0600103D(ref v32));
            if (v33 != 0) {
                goto IL_0042;
            } else {
                goto IL_0089;
            }
            IL_0089: ;
            goto IL_0099;
        }
        finally {
            IL_008B: ;
            ref __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v34 = ref l0;
            __cil_constrained_0200028F_0A000017(ref v34);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0099: ;
        global::OpenRA.Map v35 = this;
        global::OpenRA.CellRegion v36 = __cil_direct_06000309(v35);
        __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v37 = __cil_callvirt_060002E2(v36);
        l3 = v37;
        try {
            IL_00A5: ;
            goto IL_00B8;
            IL_00A7: ;
            ref __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v38 = ref l3;
            __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v39 = __cil_direct_0600103F(ref v38);
            l4 = v39;
            global::OpenRA.Map v40 = this;
            __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v41 = l4;
            __cil_direct_06000317(v40, v41);
            goto IL_00B8;
            IL_00B8: ;
            ref __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v42 = ref l3;
            int v43 = __cil_bool_load(__cil_direct_0600103D(ref v42));
            if (v43 != 0) {
                goto IL_00A7;
            } else {
                goto IL_00C1;
            }
            IL_00C1: ;
            goto IL_00D1;
        }
        finally {
            IL_00C3: ;
            ref __cil_value_75238fdad09af0b8b91baef9d63ed0f9ac8e5b09 v44 = ref l3;
            __cil_constrained_0200028F_0A000017(ref v44);
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_00D1: ;
        return;
    }

    private void UpdateProjection(OpenRA.CPos cell)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da bytes=151281A9011124: class [System.Runtime]System.Action`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 bytes=15128180011D118224: class OpenRA.CellLayer`1<valuetype OpenRA.PPos[]>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d435109e911734ac2943470065f35a64fd95de6f bytes=15128180011512809D01118220: class OpenRA.CellLayer`1<class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 bytes=1512809D01118220: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l0 = default;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 l1 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 l2 = default;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 l3 = default;
        int l4 = default;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 l5 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l6 = default;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 l7 = default;
        int l8 = default;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 l9 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l10 = default;
        byte l11 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da s2_0 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da s3_0 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da s17_0 = default;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da s18_0 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        global::OpenRA.MapGrid v1 = v0.Grid;
        int v2 = unchecked((int)(v1.MaximumTerrainHeight));
        if (v2 != 0) {
            goto IL_006B;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v3 = ref cell;
        global::OpenRA.Map v4 = this;
        global::OpenRA.MapGrid v5 = v4.Grid;
        int v6 = unchecked((int)(v5.Type));
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v7 = __cil_direct_06000065(ref v3, unchecked((__cil_enum_0200006B)(v6)));
        l0 = v7;
        global::OpenRA.Map v8 = this;
        __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 v9 = v8.cellProjection;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v10 = cell;
        int v11 = 1;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v12 = __cil_newarr_02000089(v11);
        int v13 = 0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v14 = l0;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v15 = OpenRA.PPos.op_Explicit(v14);
        __cil_stelem_02000089(v12, v13, v15);
        v9.set_Item(v10, v12);
        global::OpenRA.Map v16 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v17 = v16.inverseCellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v18 = l0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v19 = v17.get_Item(v18);
        l2 = v19;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v20 = l2;
        __cil_callvirt_0A00036F(v20);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v21 = l2;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v22 = l0;
        __cil_callvirt_0A000370(v21, v22);
        global::OpenRA.Map v23 = this;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v24 = v23.CellProjectionChanged;
        if (v24 is not null) {
            __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da e1_3_0 = v24;
            s3_0 = e1_3_0;
            goto IL_0064;
        } else {
            __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da e1_2_0 = v24;
            s2_0 = e1_2_0;
            goto IL_0062;
        }
        IL_0062: ;
        return;
        IL_0064: ;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v25 = cell;
        __cil_callvirt_0A00032E(s3_0, v25);
        return;
        IL_006B: ;
        global::OpenRA.Map v26 = this;
        int v27 = __cil_bool_load(v26.initializedCellProjection);
        if (v27 != 0) {
            goto IL_0079;
        } else {
            goto IL_0073;
        }
        IL_0073: ;
        global::OpenRA.Map v28 = this;
        __cil_direct_06000316(v28);
        goto IL_0079;
        IL_0079: ;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v29 = ref cell;
        global::OpenRA.Map v30 = this;
        global::OpenRA.MapGrid v31 = v30.Grid;
        int v32 = unchecked((int)(v31.Type));
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v33 = __cil_direct_06000065(ref v29, unchecked((__cil_enum_0200006B)(v32)));
        l0 = v33;
        global::OpenRA.Map v34 = this;
        __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 v35 = v34.cellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v36 = l0;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v37 = v35.get_Item(v36);
        l3 = v37;
        int v38 = 0;
        l4 = v38;
        goto IL_00E0;
        IL_009E: ;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v39 = l3;
        int v40 = l4;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v41 = __cil_ldelem_02000089(v39, v40);
        l5 = v41;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v42 = l5;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v43 = OpenRA.PPos.op_Explicit(v42);
        l6 = v43;
        global::OpenRA.Map v44 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v45 = v44.inverseCellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v46 = l6;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v47 = v45.get_Item(v46);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v48 = l0;
        int v49 = __cil_bool_load(__cil_callvirt_0A000372(v47, v48));
        global::OpenRA.Map v50 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v51 = v50.projectedHeight;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v52 = l6;
        global::OpenRA.Map v53 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v54 = l5;
        int v55 = unchecked((int)(__cil_direct_06000318(v53, v54)));
        v51.set_Item(v52, unchecked((byte)(v55)));
        int v56 = l4;
        int v57 = 1;
        int v58 = unchecked(v56 + v57);
        l4 = v58;
        goto IL_00E0;
        IL_00E0: ;
        int v59 = l4;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v60 = l3;
        nint v61 = unchecked((nint)(v60.LongLength));
        int v62 = unchecked((int)(v61));
        if (v59 < v62) {
            goto IL_009E;
        } else {
            goto IL_00E7;
        }
        IL_00E7: ;
        global::OpenRA.Map v63 = this;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v64 = l0;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v65 = __cil_direct_06000319(v63, v64);
        l1 = v65;
        global::OpenRA.Map v66 = this;
        __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 v67 = v66.cellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v68 = l0;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v69 = l1;
        v67.set_Item(v68, v69);
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v70 = l1;
        l7 = v70;
        int v71 = 0;
        l8 = v71;
        goto IL_0199;
        IL_0107: ;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v72 = l7;
        int v73 = l8;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v74 = __cil_ldelem_02000089(v72, v73);
        l9 = v74;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v75 = l9;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v76 = OpenRA.PPos.op_Explicit(v75);
        l10 = v76;
        global::OpenRA.Map v77 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v78 = v77.inverseCellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v79 = l10;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v80 = v78.get_Item(v79);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v81 = l0;
        __cil_callvirt_0A000370(v80, v81);
        global::OpenRA.Map v82 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v83 = l9;
        int v84 = unchecked((int)(__cil_direct_06000318(v82, v83)));
        l11 = unchecked((byte)(v84));
        global::OpenRA.Map v85 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v86 = v85.projectedHeight;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v87 = l10;
        int v88 = unchecked((int)(l11));
        v86.set_Item(v87, unchecked((byte)(v88)));
        goto IL_0147;
        IL_0147: ;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v89 = ref l10;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v90 = l10;
        int v91 = v90.U;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v92 = l10;
        int v93 = v92.V;
        int v94 = 1;
        int v95 = unchecked(v93 - v94);
        __cil_value_ctor_06000421(ref v89, v91, v95);
        global::OpenRA.Map v96 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v97 = v96.inverseCellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v98 = l10;
        int v99 = __cil_bool_load(v97.Contains(v98));
        if (v99 == 0) {
            goto IL_0193;
        } else {
            goto IL_016D;
        }
        IL_016D: ;
        global::OpenRA.Map v100 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v101 = v100.inverseCellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v102 = l10;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v103 = v101.get_Item(v102);
        int v104 = __cil_callvirt_0A000374(v103);
        int v105 = 0;
        if (v104 > v105) {
            goto IL_0193;
        } else {
            goto IL_0182;
        }
        IL_0182: ;
        global::OpenRA.Map v106 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v107 = v106.projectedHeight;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v108 = l10;
        int v109 = unchecked((int)(l11));
        v107.set_Item(v108, unchecked((byte)(v109)));
        goto IL_0147;
        IL_0193: ;
        int v110 = l8;
        int v111 = 1;
        int v112 = unchecked(v110 + v111);
        l8 = v112;
        goto IL_0199;
        IL_0199: ;
        int v113 = l8;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v114 = l7;
        nint v115 = unchecked((nint)(v114.LongLength));
        int v116 = unchecked((int)(v115));
        if (v113 < v116) {
            goto IL_0107;
        } else {
            goto IL_01A4;
        }
        IL_01A4: ;
        global::OpenRA.Map v117 = this;
        __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da v118 = v117.CellProjectionChanged;
        if (v118 is not null) {
            __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da e16_18_0 = v118;
            s18_0 = e16_18_0;
            goto IL_01AF;
        } else {
            __cil_ref_abb7d4d4cb197b6bd3e4b114d0e3c39854fc89da e16_17_0 = v118;
            s17_0 = e16_17_0;
            goto IL_01AD;
        }
        IL_01AD: ;
        return;
        IL_01AF: ;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v119 = cell;
        __cil_callvirt_0A00032E(s18_0, v119);
        return;
    }

    private byte ProjectedCellHeightInner(OpenRA.PPos puv)
    {
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab bytes=1181F4: valuetype OpenRA.TerrainTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_d435109e911734ac2943470065f35a64fd95de6f bytes=15128180011512809D01118220: class OpenRA.CellLayer`1<class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 bytes=1512809D01118220: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e bytes=151280C90211822008: class [System.Runtime]System.Func`2<valuetype OpenRA.MPos, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4 bytes=1512808501118220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 l0 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l1 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s3_0 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s3_1 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s4_0 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s4_1 = default;
        IL_0000: ;
        goto IL_008B;
        IL_0005: ;
        global::OpenRA.Map v0 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v1 = v0.inverseCellProjection;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v2 = puv;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v3 = OpenRA.PPos.op_Explicit(v2);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v4 = v1.get_Item(v3);
        l0 = v4;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v5 = l0;
        int v6 = __cil_callvirt_0A000374(v5);
        int v7 = 0;
        if (v6 <= v7) {
            goto IL_0076;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v8 = l0;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v9 = OpenRA.Map.__name_3C3E63.__il_field_04000A20;
        if (v9 is not null) {
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e2_4_0 = v8;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e2_4_1 = v9;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0040;
        } else {
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e2_3_0 = v8;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e2_3_1 = v9;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_0029;
        }
        IL_0029: ;
        global::OpenRA.Map.__name_3C3E63 v10 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v11 = __cil_ldftn_06001045;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v12 = __cil_newobj_0A000375(v10, v11);
        OpenRA.Map.__name_3C3E63.__il_field_04000A20 = v12;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e3_4_0 = s3_0;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e3_4_1 = v12;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        goto IL_0040;
        IL_0040: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v13 = __cil_methodspec_call_2B0000A5(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s4_0)), s4_1);
        l1 = v13;
        global::OpenRA.Map v14 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v15 = __cil_direct_06000301(v14);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v16 = l1;
        int v17 = unchecked((int)(v15.get_Item(v16)));
        global::OpenRA.Map v18 = this;
        global::OpenRA.Ruleset v19 = __cil_direct_060002F1(v18);
        global::OpenRA.ITerrainInfo v20 = v19.TerrainInfo;
        global::OpenRA.Map v21 = this;
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v22 = __cil_direct_060002FD(v21);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v23 = l1;
        __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v24 = v22.get_Item(v23);
        global::OpenRA.TerrainTileInfo v25 = __cil_callvirt_060003C7(v20, v24);
        int v26 = unchecked((int)(v25.Height));
        int v27 = unchecked(v17 - v26);
        int v28 = unchecked((int)(unchecked((byte)(v27))));
        return unchecked((byte)(v28));
        IL_0076: ;
        ref __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v29 = ref puv;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v30 = puv;
        int v31 = v30.U;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v32 = puv;
        int v33 = v32.V;
        int v34 = 1;
        int v35 = unchecked(v33 + v34);
        __cil_value_ctor_0600042C(ref v29, v31, v35);
        goto IL_008B;
        IL_008B: ;
        global::OpenRA.Map v36 = this;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v37 = v36.inverseCellProjection;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v38 = puv;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v39 = OpenRA.PPos.op_Explicit(v38);
        int v40 = __cil_bool_load(v37.Contains(v39));
        if (v40 != 0) {
            goto IL_0005;
        } else {
            goto IL_00A1;
        }
        IL_00A1: ;
        int v41 = 0;
        return unchecked((byte)(v41));
    }

    private OpenRA.PPos[] ProjectCellInner(OpenRA.MPos uv)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d bytes=1512809D01118224: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.PPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2a45a48a630cd43fd3e1c957e18b72701fd2e83a bytes=151280C90211822402: class [System.Runtime]System.Func`2<valuetype OpenRA.PPos, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_55120a5a7023bb012876790b856f34422122d4c5 bytes=1512808501118224: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.PPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733131375F30 l0 = default;
        byte l1 = default;
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d l2 = default;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733131375F30 v0 = __cil_newobj_06001056();
        l0 = v0;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733131375F30 v1 = l0;
        // Exact call 0x06000301 kept: property source signature requires exact type identities.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v3 = __cil_direct_06000301(this);
        v1.mapHeight = v3;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733131375F30 v4 = l0;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v5 = v4.mapHeight;
        int v7 = __cil_bool_load(v5.Contains(uv));
        if (v7 != 0) {
            goto IL_0026;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v8 = OpenRA.Map.NoProjectedCells;
        return v8;
        IL_0026: ;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733131375F30 v9 = l0;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v10 = v9.mapHeight;
        int v12 = unchecked((int)(v10.get_Item(uv)));
        l1 = unchecked((byte)(v12));
        int v13 = unchecked((int)(l1));
        if (v13 != 0) {
            goto IL_004A;
        } else {
            goto IL_0036;
        }
        IL_0036: ;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v15 = __cil_newarr_02000089(1);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v18 = OpenRA.PPos.op_Explicit(uv);
        __cil_stelem_02000089(v15, 0, v18);
        return v15;
        IL_004A: ;
        int v19 = unchecked((int)(l1));
        int v21 = unchecked(v19 & 1);
        if (unchecked((uint)v21) != unchecked((uint)1)) {
            goto IL_0063;
        } else {
            goto IL_0050;
        }
        IL_0050: ;
        // Exact call 0x06000303 kept: property source signature requires exact type identities.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v24 = __cil_direct_06000303(this);
        int v26 = unchecked((int)(v24.get_Item(uv)));
        if (v26 == 0) {
            goto IL_0063;
        } else {
            goto IL_005E;
        }
        IL_005E: ;
        int v27 = unchecked((int)(l1));
        int v29 = unchecked(v27 + 1);
        int v30 = unchecked((int)(unchecked((byte)(v29))));
        l1 = unchecked((byte)(v30));
        IL_0063: ;
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v31 = __cil_newobj_0A000378();
        l2 = v31;
        int v32 = unchecked((int)(l1));
        int v34 = unchecked(v32 & 1);
        if (unchecked((uint)v34) != unchecked((uint)1)) {
            goto IL_0106;
        } else {
            goto IL_0072;
        }
        IL_0072: ;
        int v37 = uv.V;
        int v39 = unchecked(v37 & 1);
        if (unchecked((uint)v39) != unchecked((uint)1)) {
            goto IL_009A;
        } else {
            goto IL_007D;
        }
        IL_007D: ;
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v41 = l2;
        int v43 = uv.U;
        int v45 = unchecked(v43 + 1);
        int v47 = uv.V;
        int v48 = unchecked((int)(l1));
        int v49 = unchecked(v47 - v48);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v50 = __cil_value_newobj_0600042C(v45, v49);
        __cil_callvirt_0A000379(v41, v50);
        goto IL_00B5;
        IL_009A: ;
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v51 = l2;
        int v53 = uv.U;
        int v55 = unchecked(v53 - 1);
        int v57 = uv.V;
        int v58 = unchecked((int)(l1));
        int v59 = unchecked(v57 - v58);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v60 = __cil_value_newobj_0600042C(v55, v59);
        __cil_callvirt_0A000379(v51, v60);
        IL_00B5: ;
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v61 = l2;
        int v63 = uv.U;
        int v65 = uv.V;
        int v66 = unchecked((int)(l1));
        int v67 = unchecked(v65 - v66);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v68 = __cil_value_newobj_0600042C(v63, v67);
        __cil_callvirt_0A000379(v61, v68);
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v69 = l2;
        int v71 = uv.U;
        int v73 = uv.V;
        int v74 = unchecked((int)(l1));
        int v75 = unchecked(v73 - v74);
        int v77 = unchecked(v75 + 1);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v78 = __cil_value_newobj_0600042C(v71, v77);
        __cil_callvirt_0A000379(v69, v78);
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v79 = l2;
        int v81 = uv.U;
        int v83 = uv.V;
        int v84 = unchecked((int)(l1));
        int v85 = unchecked(v83 - v84);
        int v87 = unchecked(v85 - 1);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v88 = __cil_value_newobj_0600042C(v81, v87);
        __cil_callvirt_0A000379(v79, v88);
        goto IL_011F;
        IL_0106: ;
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v89 = l2;
        int v91 = uv.U;
        int v93 = uv.V;
        int v94 = unchecked((int)(l1));
        int v95 = unchecked(v93 - v94);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v96 = __cil_value_newobj_0600042C(v91, v95);
        __cil_callvirt_0A000379(v89, v96);
        IL_011F: ;
        __cil_ref_029ee3187994124535fc787f4a7ea41c9d84547d v97 = l2;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733131375F30 v98 = l0;
        nint v99 = __cil_ldftn_06001057;
        __cil_ref_2a45a48a630cd43fd3e1c957e18b72701fd2e83a v100 = __cil_newobj_0A00037A(v98, v99);
        __cil_ref_55120a5a7023bb012876790b856f34422122d4c5 v101 = __cil_methodspec_call_2B0000A6(((__cil_ref_55120a5a7023bb012876790b856f34422122d4c5)(v97)), v100);
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v102 = __cil_methodspec_call_2B0000A7(v101);
        return v102;
    }

    public void Save(OpenRA.FileSystem.IReadWritePackage toPackage)
    {
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerator`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd bytes=15128085010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_cde75719707a5c33439e7442f5014c6e79818f54 bytes=1D128198: class OpenRA.MapField[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 bytes=118A4C: valuetype OpenRA.Map/<>c__DisplayClass118_0; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed bytes=1512809D01128200: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.MiniYamlNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465 bytes=1512808501128200: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.MiniYamlNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 l0 = default;
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed l1 = default;
        __cil_ref_cde75719707a5c33439e7442f5014c6e79818f54 l2 = default;
        int l3 = default;
        OpenRA.MapField l4 = default;
        int l5 = default;
        __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 l6 = default;
        string l7 = default;
        IL_0000: ;
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v0 = ref l0;
        global::OpenRA.Map v1 = this;
        v0.__il_field_04000A32 = v1;
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v2 = ref l0;
        global::OpenRA.FileSystem.IReadWritePackage v3 = toPackage;
        v2.toPackage = v3;
        global::OpenRA.Map v4 = this;
        int v5 = 12;
        __cil_direct_060002EA(v4, v5);
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v6 = __cil_newobj_0A000123();
        l1 = v6;
        __cil_ref_cde75719707a5c33439e7442f5014c6e79818f54 v7 = OpenRA.Map.YamlFields;
        l2 = v7;
        int v8 = 0;
        l3 = v8;
        goto IL_003A;
        IL_0028: ;
        __cil_ref_cde75719707a5c33439e7442f5014c6e79818f54 v9 = l2;
        int v10 = l3;
        global::OpenRA.MapField v11 = v9[v10];
        l4 = v11;
        global::OpenRA.MapField v12 = l4;
        global::OpenRA.Map v13 = this;
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v14 = l1;
        __cil_callvirt_060002E8(v12, v13, v14);
        int v15 = l3;
        int v16 = 1;
        int v17 = unchecked(v15 + v16);
        l3 = v17;
        goto IL_003A;
        IL_003A: ;
        int v18 = l3;
        __cil_ref_cde75719707a5c33439e7442f5014c6e79818f54 v19 = l2;
        nint v20 = unchecked((nint)(v19.LongLength));
        int v21 = unchecked((int)(v20));
        if (v18 < v21) {
            goto IL_0028;
        } else {
            goto IL_0040;
        }
        IL_0040: ;
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v22 = l1;
        int v23 = __cil_callvirt_0A0002EE(v22);
        int v24 = 1;
        int v25 = unchecked(v23 - v24);
        l5 = v25;
        goto IL_006A;
        IL_004C: ;
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v26 = l1;
        int v27 = l5;
        string v28 = __cil_ldstr_700005EE("");
        string v29 = __cil_ldstr_700005EE("");
        global::OpenRA.MiniYamlNode v30 = __cil_newobj_060003E1(v28, v29, null);
        __cil_callvirt_0A00037B(v26, v27, v30);
        int v31 = l5;
        int v32 = 1;
        int v33 = unchecked(v31 - v32);
        l5 = v33;
        goto IL_006A;
        IL_006A: ;
        int v34 = l5;
        int v35 = 0;
        if (v34 > v35) {
            goto IL_004C;
        } else {
            goto IL_006F;
        }
        IL_006F: ;
        global::OpenRA.Map v36 = this;
        global::OpenRA.FileSystem.IReadOnlyPackage v37 = __cil_direct_060002ED(v36);
        if (v37 is null) {
            goto IL_00D8;
        } else {
            goto IL_0077;
        }
        IL_0077: ;
        __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v38 = l0;
        global::OpenRA.FileSystem.IReadWritePackage v39 = v38.toPackage;
        global::OpenRA.Map v40 = this;
        global::OpenRA.FileSystem.IReadOnlyPackage v41 = __cil_direct_060002ED(v40);
        if (System.Object.ReferenceEquals(v39, v41)) {
            goto IL_00D8;
        } else {
            goto IL_0085;
        }
        IL_0085: ;
        global::OpenRA.Map v42 = this;
        global::OpenRA.FileSystem.IReadOnlyPackage v43 = __cil_direct_060002ED(v42);
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd v44 = __cil_callvirt_06000F03(v43);
        __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v45 = __cil_callvirt_0A000034(v44);
        l6 = v45;
        try {
            IL_0097: ;
            goto IL_00C1;
            IL_0099: ;
            __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v46 = l6;
            string v47 = __cil_callvirt_0A000033(v46);
            l7 = v47;
            __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v48 = l0;
            global::OpenRA.FileSystem.IReadWritePackage v49 = v48.toPackage;
            string v50 = l7;
            global::OpenRA.Map v51 = this;
            global::OpenRA.FileSystem.IReadOnlyPackage v52 = __cil_direct_060002ED(v51);
            string v53 = l7;
            __cil_type_0100003C v54 = __cil_callvirt_06000F04(v52, v53);
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v55 = OpenRA.StreamExts.ReadAllBytes(v54);
            __cil_callvirt_06000F07(v49, v50, v55);
            goto IL_00C1;
            IL_00C1: ;
            __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v56 = l6;
            int v57 = __cil_bool_load(__cil_callvirt_0A000018(v56));
            if (v57 != 0) {
                goto IL_0099;
            } else {
                goto IL_00CA;
            }
            IL_00CA: ;
            goto IL_00D8;
        }
        finally {
            IL_00CC: ;
            __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v58 = l6;
            if (v58 is null) {
                goto IL_00D7;
            } else {
                goto IL_00D0;
            }
            IL_00D0: ;
            __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v59 = l6;
            __cil_callvirt_0A000017(v59);
            goto IL_00D7;
            IL_00D7: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00D8: ;
        global::OpenRA.Map v60 = this;
        int v61 = __cil_bool_load(v60.LockPreview);
        if (v61 != 0) {
            goto IL_00F3;
        } else {
            goto IL_00E0;
        }
        IL_00E0: ;
        global::OpenRA.Map v62 = this;
        string v63 = __cil_ldstr_70004868("map.png");
        global::OpenRA.Map v64 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v65 = __cil_direct_0600031D(v64);
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v66 = ref l0;
        __cil_direct_06000347(v62, v63, v65, ref v66);
        goto IL_00F3;
        IL_00F3: ;
        global::OpenRA.Map v67 = this;
        string v68 = __cil_ldstr_700047E2("map.yaml");
        __cil_type_010000A4 v69 = System.Text.Encoding.get_UTF8();
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v70 = l1;
        string v71 = OpenRA.MiniYamlExts.WriteToString(((__cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465)(v70)));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v72 = v69.GetBytes(v71);
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v73 = ref l0;
        __cil_direct_06000347(v67, v68, v72, ref v73);
        global::OpenRA.Map v74 = this;
        string v75 = __cil_ldstr_700047F4("map.bin");
        global::OpenRA.Map v76 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v77 = __cil_direct_0600031B(v76);
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v78 = ref l0;
        __cil_direct_06000347(v74, v75, v77, ref v78);
        global::OpenRA.Map v79 = this;
        __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v80 = l0;
        global::OpenRA.FileSystem.IReadWritePackage v81 = v80.toPackage;
        __cil_direct_060002EE(v79, ((OpenRA.FileSystem.IReadOnlyPackage)(v81)));
        global::OpenRA.Map v82 = this;
        __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v83 = l0;
        global::OpenRA.FileSystem.IReadWritePackage v84 = v83.toPackage;
        global::OpenRA.Map v85 = this;
        int v86 = __cil_direct_060002E9(v85);
        string v87 = OpenRA.Map.ComputeUID(((OpenRA.FileSystem.IReadOnlyPackage)(v84)), v86);
        __cil_direct_060002F0(v82, v87);
        return;
    }

    public byte[] SaveBinaryData()
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 bytes=15128180011181F8: class OpenRA.CellLayer`1<valuetype OpenRA.ResourceTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab bytes=1181F4: valuetype OpenRA.TerrainTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bf96b4f6908dd21d177916d74f9e282375a834a4 bytes=1181F8: valuetype OpenRA.ResourceTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_type_01000039 l0 = default;
        __cil_type_0100003B l1 = default;
        int l2 = default;
        int l3 = default;
        int l4 = default;
        int l5 = default;
        __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab l6 = default;
        int l7 = default;
        int l8 = default;
        int l9 = default;
        int l10 = default;
        __cil_value_bf96b4f6908dd21d177916d74f9e282375a834a4 l11 = default;
        int s4_0 = default;
        int s7_0 = default;
        IL_0000: ;
        __cil_type_01000039 v0 = __cil_newobj_0A0000EE();
        l0 = v0;
        __cil_type_01000039 v1 = l0;
        __cil_type_0100003B v2 = __cil_newobj_0A0000EF(v1);
        l1 = v2;
        try {
            IL_000D: ;
            __cil_type_0100003B v3 = l1;
            global::OpenRA.Map v4 = this;
            int v5 = unchecked((int)(v4.TileFormat));
            v3.Write(unchecked((byte)(v5)));
            __cil_type_0100003B v6 = l1;
            global::OpenRA.Map v7 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v8 = __cil_direct_060002EB(v7);
            int v9 = v8.X;
            int v10 = unchecked((int)(unchecked((ushort)(v9))));
            v6.Write(unchecked((ushort)(v10)));
            __cil_type_0100003B v11 = l1;
            global::OpenRA.Map v12 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v13 = __cil_direct_060002EB(v12);
            int v14 = v13.Y;
            int v15 = unchecked((int)(unchecked((ushort)(v14))));
            v11.Write(unchecked((ushort)(v15)));
            global::OpenRA.Map v16 = this;
            global::OpenRA.MapGrid v17 = v16.Grid;
            int v18 = unchecked((int)(v17.MaximumTerrainHeight));
            int v19 = 0;
            if (v18 > v19) {
                goto IL_004E;
            } else {
                goto IL_004B;
            }
            IL_004B: ;
            int v20 = 0;
            int e2_4_0 = v20;
            s4_0 = e2_4_0;
            goto IL_006A;
            IL_004E: ;
            int v21 = 3;
            global::OpenRA.Map v22 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v23 = __cil_direct_060002EB(v22);
            int v24 = v23.X;
            int v25 = unchecked(v21 * v24);
            global::OpenRA.Map v26 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v27 = __cil_direct_060002EB(v26);
            int v28 = v27.Y;
            int v29 = unchecked(v25 * v28);
            int v30 = 17;
            int v31 = unchecked(v29 + v30);
            int e3_4_0 = v31;
            s4_0 = e3_4_0;
            goto IL_006A;
            IL_006A: ;
            l2 = s4_0;
            global::OpenRA.Map v32 = this;
            global::OpenRA.MapGrid v33 = v32.Grid;
            int v34 = unchecked((int)(v33.MaximumTerrainHeight));
            int v35 = 0;
            if (v34 > v35) {
                goto IL_007C;
            } else {
                goto IL_0079;
            }
            IL_0079: ;
            int v36 = 3;
            int e5_7_0 = v36;
            s7_0 = e5_7_0;
            goto IL_007D;
            IL_007C: ;
            int v37 = 4;
            int e6_7_0 = v37;
            s7_0 = e6_7_0;
            goto IL_007D;
            IL_007D: ;
            global::OpenRA.Map v38 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v39 = __cil_direct_060002EB(v38);
            int v40 = v39.X;
            int v41 = unchecked(s7_0 * v40);
            global::OpenRA.Map v42 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v43 = __cil_direct_060002EB(v42);
            int v44 = v43.Y;
            int v45 = unchecked(v41 * v44);
            int v46 = 17;
            int v47 = unchecked(v45 + v46);
            l3 = v47;
            __cil_type_0100003B v48 = l1;
            int v49 = 17;
            v48.Write(unchecked((uint)(v49)));
            __cil_type_0100003B v50 = l1;
            int v51 = l2;
            v50.Write(unchecked((uint)(v51)));
            __cil_type_0100003B v52 = l1;
            int v53 = l3;
            v52.Write(unchecked((uint)(v53)));
            int v54 = 0;
            l4 = v54;
            goto IL_0104;
            IL_00B4: ;
            int v55 = 0;
            l5 = v55;
            goto IL_00EF;
            IL_00B9: ;
            global::OpenRA.Map v56 = this;
            __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v57 = __cil_direct_060002FD(v56);
            int v58 = l4;
            int v59 = l5;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v60 = __cil_value_newobj_06000421(v58, v59);
            __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v61 = v57.get_Item(v60);
            l6 = v61;
            __cil_type_0100003B v62 = l1;
            __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v63 = l6;
            int v64 = unchecked((int)(v63.Type));
            v62.Write(unchecked((ushort)(v64)));
            __cil_type_0100003B v65 = l1;
            __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v66 = l6;
            int v67 = unchecked((int)(v66.Index));
            v65.Write(unchecked((byte)(v67)));
            int v68 = l5;
            int v69 = 1;
            int v70 = unchecked(v68 + v69);
            l5 = v70;
            goto IL_00EF;
            IL_00EF: ;
            int v71 = l5;
            global::OpenRA.Map v72 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v73 = __cil_direct_060002EB(v72);
            int v74 = v73.Y;
            if (v71 < v74) {
                goto IL_00B9;
            } else {
                goto IL_00FE;
            }
            IL_00FE: ;
            int v75 = l4;
            int v76 = 1;
            int v77 = unchecked(v75 + v76);
            l4 = v77;
            goto IL_0104;
            IL_0104: ;
            int v78 = l4;
            global::OpenRA.Map v79 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v80 = __cil_direct_060002EB(v79);
            int v81 = v80.X;
            if (v78 < v81) {
                goto IL_00B4;
            } else {
                goto IL_0113;
            }
            IL_0113: ;
            int v82 = l2;
            if (v82 == 0) {
                goto IL_0164;
            } else {
                goto IL_0116;
            }
            IL_0116: ;
            int v83 = 0;
            l7 = v83;
            goto IL_0155;
            IL_011B: ;
            int v84 = 0;
            l8 = v84;
            goto IL_0140;
            IL_0120: ;
            __cil_type_0100003B v85 = l1;
            global::OpenRA.Map v86 = this;
            __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v87 = __cil_direct_06000301(v86);
            int v88 = l7;
            int v89 = l8;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v90 = __cil_value_newobj_06000421(v88, v89);
            int v91 = unchecked((int)(v87.get_Item(v90)));
            v85.Write(unchecked((byte)(v91)));
            int v92 = l8;
            int v93 = 1;
            int v94 = unchecked(v92 + v93);
            l8 = v94;
            goto IL_0140;
            IL_0140: ;
            int v95 = l8;
            global::OpenRA.Map v96 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v97 = __cil_direct_060002EB(v96);
            int v98 = v97.Y;
            if (v95 < v98) {
                goto IL_0120;
            } else {
                goto IL_014F;
            }
            IL_014F: ;
            int v99 = l7;
            int v100 = 1;
            int v101 = unchecked(v99 + v100);
            l7 = v101;
            goto IL_0155;
            IL_0155: ;
            int v102 = l7;
            global::OpenRA.Map v103 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v104 = __cil_direct_060002EB(v103);
            int v105 = v104.X;
            if (v102 < v105) {
                goto IL_011B;
            } else {
                goto IL_0164;
            }
            IL_0164: ;
            int v106 = l3;
            if (v106 == 0) {
                goto IL_01CB;
            } else {
                goto IL_0167;
            }
            IL_0167: ;
            int v107 = 0;
            l9 = v107;
            goto IL_01BC;
            IL_016C: ;
            int v108 = 0;
            l10 = v108;
            goto IL_01A7;
            IL_0171: ;
            global::OpenRA.Map v109 = this;
            __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 v110 = __cil_direct_060002FF(v109);
            int v111 = l9;
            int v112 = l10;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v113 = __cil_value_newobj_06000421(v111, v112);
            __cil_value_bf96b4f6908dd21d177916d74f9e282375a834a4 v114 = v110.get_Item(v113);
            l11 = v114;
            __cil_type_0100003B v115 = l1;
            __cil_value_bf96b4f6908dd21d177916d74f9e282375a834a4 v116 = l11;
            int v117 = unchecked((int)(v116.Type));
            v115.Write(unchecked((byte)(v117)));
            __cil_type_0100003B v118 = l1;
            __cil_value_bf96b4f6908dd21d177916d74f9e282375a834a4 v119 = l11;
            int v120 = unchecked((int)(v119.Index));
            v118.Write(unchecked((byte)(v120)));
            int v121 = l10;
            int v122 = 1;
            int v123 = unchecked(v121 + v122);
            l10 = v123;
            goto IL_01A7;
            IL_01A7: ;
            int v124 = l10;
            global::OpenRA.Map v125 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v126 = __cil_direct_060002EB(v125);
            int v127 = v126.Y;
            if (v124 < v127) {
                goto IL_0171;
            } else {
                goto IL_01B6;
            }
            IL_01B6: ;
            int v128 = l9;
            int v129 = 1;
            int v130 = unchecked(v128 + v129);
            l9 = v130;
            goto IL_01BC;
            IL_01BC: ;
            int v131 = l9;
            global::OpenRA.Map v132 = this;
            __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v133 = __cil_direct_060002EB(v132);
            int v134 = v133.X;
            if (v131 < v134) {
                goto IL_016C;
            } else {
                goto IL_01CB;
            }
            IL_01CB: ;
            goto IL_01D7;
        }
        finally {
            IL_01CD: ;
            __cil_type_0100003B v135 = l1;
            if (v135 is null) {
                goto IL_01D6;
            } else {
                goto IL_01D0;
            }
            IL_01D0: ;
            __cil_type_0100003B v136 = l1;
            __cil_callvirt_0A000017(v136);
            goto IL_01D6;
            IL_01D6: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_01D7: ;
        __cil_type_01000039 v137 = l0;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v138 = v137.ToArray();
        return v138;
    }

    public System.ValueTuple<OpenRA.Primitives.Color, OpenRA.Primitives.Color> GetTerrainColorPair(OpenRA.MPos uv)
    {
        // IL fallback: conv.i4 source category needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, F1, 02, 00, 06, 7B, 99, 00, 00, 04, 0A, 06, 02, 28, FD, 02, 00, 06, 03, 6F, 64, 03, 00]
        // .code-bytes IL_0018: [0A, 6F, C7, 03, 00, 06, 0B, 07, 7E, 6D, 00, 00, 04, 6F, D0, 03, 00, 06, 0C, 07, 7E, 6D, 00, 00]
        // .code-bytes IL_0030: [04, 6F, D0, 03, 00, 06, 0D, 06, 6F, CE, 03, 00, 06, 22, 00, 00, 80, 3F, 33, 10, 06, 6F, CF, 03]
        // .code-bytes IL_0048: [00, 06, 22, 00, 00, 80, 3F, 3B, E1, 00, 00, 00, 06, 6F, CE, 03, 00, 06, 06, 6F, CF, 03, 00, 06]
        // .code-bytes IL_0060: [02, 28, 01, 03, 00, 06, 03, 6F, 76, 03, 00, 0A, 6B, 22, 00, 00, 80, 3F, 5A, 02, 7B, 5D, 02, 00]
        // .code-bytes IL_0078: [04, 7B, 9F, 02, 00, 04, 6B, 5B, 28, A2, 04, 00, 06, 13, 04, 11, 04, 12, 02, 28, 51, 0A, 00, 06]
        // .code-bytes IL_0090: [6B, 5A, 22, 00, 00, 00, 00, 22, 00, 00, 7F, 43, 28, A8, 00, 00, 2B, 69, 11, 04, 12, 02, 28, 52]
        // .code-bytes IL_00A8: [0A, 00, 06, 6B, 5A, 22, 00, 00, 00, 00, 22, 00, 00, 7F, 43, 28, A8, 00, 00, 2B, 69, 11, 04, 12]
        // .code-bytes IL_00C0: [02, 28, 53, 0A, 00, 06, 6B, 5A, 22, 00, 00, 00, 00, 22, 00, 00, 7F, 43, 28, A8, 00, 00, 2B, 69]
        // .code-bytes IL_00D8: [28, 3B, 0A, 00, 06, 0C, 11, 04, 12, 03, 28, 51, 0A, 00, 06, 6B, 5A, 22, 00, 00, 00, 00, 22, 00]
        // .code-bytes IL_00F0: [00, 7F, 43, 28, A8, 00, 00, 2B, 69, 11, 04, 12, 03, 28, 52, 0A, 00, 06, 6B, 5A, 22, 00, 00, 00]
        // .code-bytes IL_0108: [00, 22, 00, 00, 7F, 43, 28, A8, 00, 00, 2B, 69, 11, 04, 12, 03, 28, 53, 0A, 00, 06, 6B, 5A, 22]
        // .code-bytes IL_0120: [00, 00, 00, 00, 22, 00, 00, 7F, 43, 28, A8, 00, 00, 2B, 69, 28, 3B, 0A, 00, 06, 0D, 08, 09, 73]
        // .code-bytes IL_0138: [7F, 03, 00, 0A, 2A]
        // .local [0] class OpenRA.ITerrainInfo
        // .local [1] class OpenRA.TerrainTileInfo
        // .local [2] valuetype OpenRA.Primitives.Color
        // .local [3] valuetype OpenRA.Primitives.Color
        // .local [4] float32
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x060002F1 OpenRA.Map::get_Rules
        // IL_0006: ldfld 0x04000099 OpenRA.Ruleset::TerrainInfo
        // IL_000B: stloc.0 0
        // IL_000C: ldloc.0 0
        // IL_000D: ldarg.0 0
        // IL_000E: call 0x060002FD OpenRA.Map::get_Tiles
        // IL_0013: ldarg.1 1
        // IL_0014: callvirt 0x0A000364 class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>::get_Item
        // IL_0019: callvirt 0x060003C7 OpenRA.ITerrainInfo::GetTerrainInfo
        // IL_001E: stloc.1 1
        // IL_001F: ldloc.1 1
        // IL_0020: ldsfld 0x0400006D OpenRA.Game::CosmeticRandom
        // IL_0025: callvirt 0x060003D0 OpenRA.TerrainTileInfo::GetColor
        // IL_002A: stloc.2 2
        // IL_002B: ldloc.1 1
        // IL_002C: ldsfld 0x0400006D OpenRA.Game::CosmeticRandom
        // IL_0031: callvirt 0x060003D0 OpenRA.TerrainTileInfo::GetColor
        // IL_0036: stloc.3 3
        // IL_0037: ldloc.0 0
        // IL_0038: callvirt 0x060003CE OpenRA.ITerrainInfo::get_MinHeightColorBrightness
        // IL_003D: ldc.r4 1.0
        // IL_0042: bne.un.s IL_0054
        // IL_0044: ldloc.0 0
        // IL_0045: callvirt 0x060003CF OpenRA.ITerrainInfo::get_MaxHeightColorBrightness
        // IL_004A: ldc.r4 1.0
        // IL_004F: beq IL_0135
        // IL_0054: ldloc.0 0
        // IL_0055: callvirt 0x060003CE OpenRA.ITerrainInfo::get_MinHeightColorBrightness
        // IL_005A: ldloc.0 0
        // IL_005B: callvirt 0x060003CF OpenRA.ITerrainInfo::get_MaxHeightColorBrightness
        // IL_0060: ldarg.0 0
        // IL_0061: call 0x06000301 OpenRA.Map::get_Height
        // IL_0066: ldarg.1 1
        // IL_0067: callvirt 0x0A000376 class OpenRA.CellLayer`1<uint8>::get_Item
        // IL_006C: conv.r4 
        // IL_006D: ldc.r4 1.0
        // IL_0072: mul 
        // IL_0073: ldarg.0 0
        // IL_0074: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_0079: ldfld 0x0400029F OpenRA.MapGrid::MaximumTerrainHeight
        // IL_007E: conv.r4 
        // IL_007F: div 
        // IL_0080: call 0x060004A2 OpenRA.float2::Lerp
        // IL_0085: stloc.s 4
        // IL_0087: ldloc.s 4
        // IL_0089: ldloca.s 2
        // IL_008B: call 0x06000A51 OpenRA.Primitives.Color::get_R
        // IL_0090: conv.r4 
        // IL_0091: mul 
        // IL_0092: ldc.r4 0.0
        // IL_0097: ldc.r4 255.0
        // IL_009C: call 0x2B0000A8 OpenRA.Exts::Clamp<float32>
        // IL_00A1: conv.i4 
        // IL_00A2: ldloc.s 4
        // IL_00A4: ldloca.s 2
        // IL_00A6: call 0x06000A52 OpenRA.Primitives.Color::get_G
        // IL_00AB: conv.r4 
        // IL_00AC: mul 
        // IL_00AD: ldc.r4 0.0
        // IL_00B2: ldc.r4 255.0
        // IL_00B7: call 0x2B0000A8 OpenRA.Exts::Clamp<float32>
        // IL_00BC: conv.i4 
        // IL_00BD: ldloc.s 4
        // IL_00BF: ldloca.s 2
        // IL_00C1: call 0x06000A53 OpenRA.Primitives.Color::get_B
        // IL_00C6: conv.r4 
        // IL_00C7: mul 
        // IL_00C8: ldc.r4 0.0
        // IL_00CD: ldc.r4 255.0
        // IL_00D2: call 0x2B0000A8 OpenRA.Exts::Clamp<float32>
        // IL_00D7: conv.i4 
        // IL_00D8: call 0x06000A3B OpenRA.Primitives.Color::FromArgb
        // IL_00DD: stloc.2 2
        // IL_00DE: ldloc.s 4
        // IL_00E0: ldloca.s 3
        // IL_00E2: call 0x06000A51 OpenRA.Primitives.Color::get_R
        // IL_00E7: conv.r4 
        // IL_00E8: mul 
        // IL_00E9: ldc.r4 0.0
        // IL_00EE: ldc.r4 255.0
        // IL_00F3: call 0x2B0000A8 OpenRA.Exts::Clamp<float32>
        // IL_00F8: conv.i4 
        // IL_00F9: ldloc.s 4
        // IL_00FB: ldloca.s 3
        // IL_00FD: call 0x06000A52 OpenRA.Primitives.Color::get_G
        // IL_0102: conv.r4 
        // IL_0103: mul 
        // IL_0104: ldc.r4 0.0
        // IL_0109: ldc.r4 255.0
        // IL_010E: call 0x2B0000A8 OpenRA.Exts::Clamp<float32>
        // IL_0113: conv.i4 
        // IL_0114: ldloc.s 4
        // IL_0116: ldloca.s 3
        // IL_0118: call 0x06000A53 OpenRA.Primitives.Color::get_B
        // IL_011D: conv.r4 
        // IL_011E: mul 
        // IL_011F: ldc.r4 0.0
        // IL_0124: ldc.r4 255.0
        // IL_0129: call 0x2B0000A8 OpenRA.Exts::Clamp<float32>
        // IL_012E: conv.i4 
        // IL_012F: call 0x06000A3B OpenRA.Primitives.Color::FromArgb
        // IL_0134: stloc.3 3
        // IL_0135: ldloc.2 2
        // IL_0136: ldloc.3 3
        // IL_0137: newobj 0x0A00037F valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.Primitives.Color, valuetype OpenRA.Primitives.Color>::.ctor
        // IL_013C: ret 
    }

    public byte[] SavePreview()
    {
        // structural signature __cil_ref_6f1c43c2e76f56114e0d49dbd5fe74e1baba800b bytes=1512811501128200: class [System.Runtime]System.Collections.Generic.IReadOnlyCollection`1<class OpenRA.MiniYamlNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465 bytes=1512808501128200: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.MiniYamlNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_726631b0bdcfb3e2db894c92edddc94b72286860 bytes=15118229021186D41186D4: valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.Primitives.Color, valuetype OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f bytes=1186D4: valuetype OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 bytes=1512809D0115118229021182201186D4: class [System.Collections]System.Collections.Generic.List`1<valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_10046ef59e9af67ac53c12a98d3389da20206adf bytes=1512811501128544: class [System.Runtime]System.Collections.Generic.IReadOnlyCollection`1<class OpenRA.Traits.IMapPreviewSignatureInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_580011c36ff80beae1f45c104efb341fb1370d8b bytes=15128089021182201186D4: class [System.Collections]System.Collections.Generic.Dictionary`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ca8f9a4324682cec9ec33a7c443b683b919ad67a bytes=151280A101128200: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.MiniYamlNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 bytes=151280A101128544: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.IMapPreviewSignatureInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_79714c84f79538c23179a2f0ec40c1a367b0050f bytes=1512811901128084: class [System.Runtime]System.Collections.Generic.ICollection`1<class OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 bytes=151280C90212808402: class [System.Runtime]System.Func`2<class OpenRA.ActorInfo, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ccea567f1b18a7c36170d4fe401f9076af7ad140 bytes=1512808501128084: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0a5754c4f454d339a123eda2e3ca34aeb5d17dc1 bytes=151280C90212820002: class [System.Runtime]System.Func`2<class OpenRA.MiniYamlNode, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_43a5edc74d7fec9cc05051d8adb2840f0112bb55 bytes=15128089020E128204: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class OpenRA.MiniYaml>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_932db6e405b74517db7e33795f917f1d03f9d0ee bytes=15118229020808: valuetype [System.Runtime]System.ValueTuple`2<int32, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 bytes=151280C90215118229021182201186D4118220: class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>, valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_eea3913484a2b076219384b02ad72b2f573758b0 bytes=151280850115118229021182201186D4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_968d1c518857d9e449963446776981759acaad0f bytes=1512808501151280950211822015118229021182201186D4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [System.Linq]System.Linq.IGrouping`2<valuetype OpenRA.MPos, valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b bytes=151280C902151280950211822015118229021182201186D4118220: class [System.Runtime]System.Func`2<class [System.Linq]System.Linq.IGrouping`2<valuetype OpenRA.MPos, valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>, valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bd2174d306a52826a722544d88d37718eb703105 bytes=151280C902151280950211822015118229021182201186D41186D4: class [System.Runtime]System.Func`2<class [System.Linq]System.Linq.IGrouping`2<valuetype OpenRA.MPos, valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>, valuetype OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7d43f1adc7c26606bbc9de37fbfd81e8f4eaf931 bytes=1D1186D4: valuetype OpenRA.Primitives.Color[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_1fc16ec745ba8978183fb58649485ed4b1541005 bytes=15128089020E0E: class [System.Collections]System.Collections.Generic.Dictionary`2<string, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000007 alias=__cil_enum_02000007 underlying=int: global::@OpenRA.@SystemActors; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200021F alias=__cil_enum_0200021F underlying=int: global::@OpenRA.@Graphics.@SpriteFrameType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 l0 = default;
        __cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465 l1 = default;
        __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 l2 = default;
        OpenRA.ActorInfo l3 = default;
        __cil_ref_10046ef59e9af67ac53c12a98d3389da20206adf l4 = default;
        bool l5 = default;
        int l6 = default;
        int l7 = default;
        int l8 = default;
        int l9 = default;
        int l10 = default;
        int l11 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 l12 = default;
        __cil_value_726631b0bdcfb3e2db894c92edddc94b72286860 l13 = default;
        __cil_ref_580011c36ff80beae1f45c104efb341fb1370d8b l14 = default;
        OpenRA.FileFormats.Png l15 = default;
        __cil_ref_ca8f9a4324682cec9ec33a7c443b683b919ad67a l16 = default;
        OpenRA.MiniYamlNode l17 = default;
        OpenRA.ActorReference l18 = default;
        OpenRA.ActorInfo l19 = default;
        __cil_ref_10046ef59e9af67ac53c12a98d3389da20206adf l20 = default;
        __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 l21 = default;
        OpenRA.Traits.IMapPreviewSignatureInfo l22 = default;
        __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 l23 = default;
        OpenRA.Traits.IMapPreviewSignatureInfo l24 = default;
        int l25 = default;
        int l26 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l27 = default;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f l28 = default;
        int l29 = default;
        int l30 = default;
        int l31 = default;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f l32 = default;
        int l33 = default;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f l34 = default;
        int l35 = default;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f l36 = default;
        OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 s1_0 = default;
        __cil_ref_79714c84f79538c23179a2f0ec40c1a367b0050f s1_1 = default;
        __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 s1_2 = default;
        OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 s2_0 = default;
        __cil_ref_79714c84f79538c23179a2f0ec40c1a367b0050f s2_1 = default;
        __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 s2_2 = default;
        __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 s33_0 = default;
        __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 s33_1 = default;
        __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 s34_0 = default;
        __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 s34_1 = default;
        __cil_ref_968d1c518857d9e449963446776981759acaad0f s35_0 = default;
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b s35_1 = default;
        __cil_ref_968d1c518857d9e449963446776981759acaad0f s36_0 = default;
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b s36_1 = default;
        __cil_ref_968d1c518857d9e449963446776981759acaad0f s37_0 = default;
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b s37_1 = default;
        __cil_ref_bd2174d306a52826a722544d88d37718eb703105 s37_2 = default;
        __cil_ref_968d1c518857d9e449963446776981759acaad0f s38_0 = default;
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b s38_1 = default;
        __cil_ref_bd2174d306a52826a722544d88d37718eb703105 s38_2 = default;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f s47_0 = default;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f s52_0 = default;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f s56_0 = default;
        IL_0000: ;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 v0 = __cil_newobj_06001058();
        l0 = v0;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 v1 = l0;
        global::OpenRA.Map v2 = this;
        global::OpenRA.Ruleset v3 = __cil_direct_060002F1(v2);
        global::OpenRA.ActorInfoDictionary v4 = v3.Actors;
        __cil_ref_79714c84f79538c23179a2f0ec40c1a367b0050f v5 = __cil_callvirt_06000498(v4);
        __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 v6 = OpenRA.Map.__name_3C3E63.__il_field_04000A21;
        if (v6 is not null) {
            OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 e0_2_0 = v1;
            __cil_ref_79714c84f79538c23179a2f0ec40c1a367b0050f e0_2_1 = v5;
            __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 e0_2_2 = v6;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            s2_2 = e0_2_2;
            goto IL_0036;
        } else {
            OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 e0_1_0 = v1;
            __cil_ref_79714c84f79538c23179a2f0ec40c1a367b0050f e0_1_1 = v5;
            __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 e0_1_2 = v6;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            s1_2 = e0_1_2;
            goto IL_001F;
        }
        IL_001F: ;
        global::OpenRA.Map.__name_3C3E63 v7 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v8 = __cil_ldftn_06001046;
        __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 v9 = __cil_newobj_0A000380(v7, v8);
        OpenRA.Map.__name_3C3E63.__il_field_04000A21 = v9;
        OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 e1_2_0 = s1_0;
        __cil_ref_79714c84f79538c23179a2f0ec40c1a367b0050f e1_2_1 = s1_1;
        __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 e1_2_2 = v9;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        s2_2 = e1_2_2;
        goto IL_0036;
        IL_0036: ;
        __cil_ref_ccea567f1b18a7c36170d4fe401f9076af7ad140 v10 = __cil_methodspec_call_2B0000A9(((__cil_ref_ccea567f1b18a7c36170d4fe401f9076af7ad140)(s2_1)), s2_2);
        s2_0.actorTypes = v10;
        global::OpenRA.Map v11 = this;
        __cil_ref_6f1c43c2e76f56114e0d49dbd5fe74e1baba800b v12 = v11.ActorDefinitions;
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F30 v13 = l0;
        nint v14 = __cil_ldftn_06001059;
        __cil_ref_0a5754c4f454d339a123eda2e3ca34aeb5d17dc1 v15 = __cil_newobj_0A00028A(v13, v14);
        __cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465 v16 = __cil_methodspec_call_2B00007B(((__cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465)(v12)), v15);
        l1 = v16;
        __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 v17 = __cil_newobj_0A000381();
        l2 = v17;
        __cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465 v18 = l1;
        __cil_ref_ca8f9a4324682cec9ec33a7c443b683b919ad67a v19 = __cil_callvirt_0A000293(v18);
        l16 = v19;
        try {
            IL_0066: ;
            goto IL_00F2;
            IL_006B: ;
            __cil_ref_ca8f9a4324682cec9ec33a7c443b683b919ad67a v20 = l16;
            global::OpenRA.MiniYamlNode v21 = __cil_callvirt_0A000294(v20);
            l17 = v21;
            global::OpenRA.MiniYamlNode v22 = l17;
            global::OpenRA.MiniYaml v23 = v22.Value;
            string v24 = v23.Value;
            global::OpenRA.MiniYamlNode v25 = l17;
            global::OpenRA.MiniYaml v26 = v25.Value;
            __cil_ref_43a5edc74d7fec9cc05051d8adb2840f0112bb55 v27 = __cil_callvirt_060003E9(v26);
            global::OpenRA.ActorReference v28 = __cil_newobj_060002A2(v24, v27);
            l18 = v28;
            global::OpenRA.Map v29 = this;
            global::OpenRA.Ruleset v30 = __cil_direct_060002F1(v29);
            global::OpenRA.ActorInfoDictionary v31 = v30.Actors;
            global::OpenRA.MiniYamlNode v32 = l17;
            global::OpenRA.MiniYaml v33 = v32.Value;
            string v34 = v33.Value;
            global::OpenRA.ActorInfo v35 = __cil_callvirt_06000493(v31, v34);
            l19 = v35;
            global::OpenRA.ActorInfo v36 = l19;
            __cil_ref_10046ef59e9af67ac53c12a98d3389da20206adf v37 = __cil_callvirt_2B0000AA(v36);
            l20 = v37;
            __cil_ref_10046ef59e9af67ac53c12a98d3389da20206adf v38 = l20;
            __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v39 = __cil_callvirt_0A000382(v38);
            l21 = v39;
            try {
                IL_00C3: ;
                goto IL_00DB;
                IL_00C5: ;
                __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v40 = l21;
                global::OpenRA.Traits.IMapPreviewSignatureInfo v41 = __cil_callvirt_0A000383(v40);
                l22 = v41;
                global::OpenRA.Traits.IMapPreviewSignatureInfo v42 = l22;
                global::OpenRA.Map v43 = this;
                global::OpenRA.ActorInfo v44 = l19;
                global::OpenRA.ActorReference v45 = l18;
                __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 v46 = l2;
                __cil_callvirt_06000927(v42, v43, v44, v45, v46);
                goto IL_00DB;
                IL_00DB: ;
                __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v47 = l21;
                int v48 = __cil_bool_load(__cil_callvirt_0A000018(v47));
                if (v48 != 0) {
                    goto IL_00C5;
                } else {
                    goto IL_00E4;
                }
                IL_00E4: ;
                goto IL_00F2;
            }
            finally {
                IL_00E6: ;
                __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v49 = l21;
                if (v49 is null) {
                    goto IL_00F1;
                } else {
                    goto IL_00EA;
                }
                IL_00EA: ;
                __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v50 = l21;
                __cil_callvirt_0A000017(v50);
                goto IL_00F1;
                IL_00F1: ;
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_00F2: ;
            __cil_ref_ca8f9a4324682cec9ec33a7c443b683b919ad67a v51 = l16;
            int v52 = __cil_bool_load(__cil_callvirt_0A000018(v51));
            if (v52 != 0) {
                goto IL_006B;
            } else {
                goto IL_00FE;
            }
            IL_00FE: ;
            goto IL_010C;
        }
        finally {
            IL_0100: ;
            __cil_ref_ca8f9a4324682cec9ec33a7c443b683b919ad67a v53 = l16;
            if (v53 is null) {
                goto IL_010B;
            } else {
                goto IL_0104;
            }
            IL_0104: ;
            __cil_ref_ca8f9a4324682cec9ec33a7c443b683b919ad67a v54 = l16;
            __cil_callvirt_0A000017(v54);
            goto IL_010B;
            IL_010B: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_010C: ;
        global::OpenRA.Map v55 = this;
        global::OpenRA.Ruleset v56 = __cil_direct_060002F1(v55);
        global::OpenRA.ActorInfoDictionary v57 = v56.Actors;
        int v58 = 2;
        global::OpenRA.ActorInfo v59 = __cil_callvirt_06000494(v57, unchecked((__cil_enum_02000007)(v58)));
        l3 = v59;
        global::OpenRA.ActorInfo v60 = l3;
        __cil_ref_10046ef59e9af67ac53c12a98d3389da20206adf v61 = __cil_callvirt_2B0000AA(v60);
        l4 = v61;
        __cil_ref_10046ef59e9af67ac53c12a98d3389da20206adf v62 = l4;
        __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v63 = __cil_callvirt_0A000382(v62);
        l23 = v63;
        try {
            IL_012F: ;
            goto IL_0145;
            IL_0131: ;
            __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v64 = l23;
            global::OpenRA.Traits.IMapPreviewSignatureInfo v65 = __cil_callvirt_0A000383(v64);
            l24 = v65;
            global::OpenRA.Traits.IMapPreviewSignatureInfo v66 = l24;
            global::OpenRA.Map v67 = this;
            global::OpenRA.ActorInfo v68 = l3;
            __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 v69 = l2;
            __cil_callvirt_06000927(v66, v67, v68, ((OpenRA.ActorReference)(null)), v69);
            goto IL_0145;
            IL_0145: ;
            __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v70 = l23;
            int v71 = __cil_bool_load(__cil_callvirt_0A000018(v70));
            if (v71 != 0) {
                goto IL_0131;
            } else {
                goto IL_014E;
            }
            IL_014E: ;
            goto IL_015C;
        }
        finally {
            IL_0150: ;
            __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v72 = l23;
            if (v72 is null) {
                goto IL_015B;
            } else {
                goto IL_0154;
            }
            IL_0154: ;
            __cil_ref_9326339d0ca5997156e98a246956521daaafedc8 v73 = l23;
            __cil_callvirt_0A000017(v73);
            goto IL_015B;
            IL_015B: ;
            goto __cil_finally_end_2;
            __cil_finally_end_2: ;
        }
        IL_015C: ;
        global::OpenRA.Map v74 = this;
        global::OpenRA.MapGrid v75 = v74.Grid;
        int v76 = unchecked((int)(v75.Type));
        int v77 = 1;
        int v78 = (v76 == v77 ? 1 : 0);
        l5 = __cil_bool_store(v78);
        int v79 = 2147483647;
        l6 = v79;
        int v80 = -2147483648;
        l7 = v80;
        global::OpenRA.Map v81 = this;
        global::OpenRA.MapGrid v82 = v81.Grid;
        int v83 = unchecked((int)(v82.MaximumTerrainHeight));
        int v84 = 0;
        if (v83 <= v84) {
            goto IL_01BA;
        } else {
            goto IL_0188;
        }
        IL_0188: ;
        global::OpenRA.Map v85 = this;
        __cil_value_932db6e405b74517db7e33795f917f1d03f9d0ee v86 = __cil_direct_0600031E(v85);
        int v87 = v86.Item1;
        l6 = v87;
        int v88 = v86.Item2;
        l7 = v88;
        int v89 = l6;
        int v90 = 2147483647;
        if (v89 == v90) {
            goto IL_01AF;
        } else {
            goto IL_01A6;
        }
        IL_01A6: ;
        int v91 = l7;
        int v92 = -2147483648;
        if (unchecked((uint)v91) != unchecked((uint)v92)) {
            goto IL_01D4;
        } else {
            goto IL_01AF;
        }
        IL_01AF: ;
        string v93 = __cil_ldstr_70004A9E("The map has invalid boundaries");
        global::System.IO.InvalidDataException v94 = __cil_newobj_0A000078(v93);
        throw v94;
        IL_01BA: ;
        global::OpenRA.Map v95 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v96 = ref v95.Bounds;
        int v97 = __cil_direct_06000BBC(ref v96);
        l6 = v97;
        global::OpenRA.Map v98 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v99 = ref v98.Bounds;
        int v100 = __cil_direct_06000BBD(ref v99);
        l7 = v100;
        goto IL_01D4;
        IL_01D4: ;
        global::OpenRA.Map v101 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v102 = ref v101.Bounds;
        int v103 = v102.Width;
        l8 = v103;
        int v104 = l7;
        int v105 = l6;
        int v106 = unchecked(v104 - v105);
        l9 = v106;
        int v107 = l8;
        l10 = v107;
        int v108 = __cil_bool_load(l5);
        if (v108 == 0) {
            goto IL_01F8;
        } else {
            goto IL_01F0;
        }
        IL_01F0: ;
        int v109 = 2;
        int v110 = l10;
        int v111 = unchecked(v109 * v110);
        int v112 = 1;
        int v113 = unchecked(v111 - v112);
        l10 = v113;
        goto IL_01F8;
        IL_01F8: ;
        int v114 = l10;
        int v115 = 4;
        int v116 = unchecked(v114 * v115);
        l11 = v116;
        int v117 = l11;
        int v118 = l9;
        int v119 = unchecked(v117 * v118);
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v120 = __cil_newarr_01000100(v119);
        l12 = v120;
        ref __cil_value_726631b0bdcfb3e2db894c92edddc94b72286860 v121 = ref l13;
        v121 = default;
        __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 v122 = l2;
        __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 v123 = OpenRA.Map.__name_3C3E63.__il_field_04000A22;
        if (v123 is not null) {
            __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 e32_34_0 = v122;
            __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 e32_34_1 = v123;
            s34_0 = e32_34_0;
            s34_1 = e32_34_1;
            goto IL_0232;
        } else {
            __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 e32_33_0 = v122;
            __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 e32_33_1 = v123;
            s33_0 = e32_33_0;
            s33_1 = e32_33_1;
            goto IL_021B;
        }
        IL_021B: ;
        global::OpenRA.Map.__name_3C3E63 v124 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v125 = __cil_ldftn_06001047;
        __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 v126 = __cil_newobj_0A000386(v124, v125);
        OpenRA.Map.__name_3C3E63.__il_field_04000A22 = v126;
        __cil_ref_4f12104f5801fd62c11b2968c066dcc96c3d1f11 e33_34_0 = s33_0;
        __cil_ref_6d1d06dbd7db30f1e40ade3f6f10eda794a03e30 e33_34_1 = v126;
        s34_0 = e33_34_0;
        s34_1 = e33_34_1;
        goto IL_0232;
        IL_0232: ;
        __cil_ref_968d1c518857d9e449963446776981759acaad0f v127 = __cil_methodspec_call_2B0000AB(((__cil_ref_eea3913484a2b076219384b02ad72b2f573758b0)(s34_0)), s34_1);
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b v128 = OpenRA.Map.__name_3C3E63.__il_field_04000A23;
        if (v128 is not null) {
            __cil_ref_968d1c518857d9e449963446776981759acaad0f e34_36_0 = v127;
            __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b e34_36_1 = v128;
            s36_0 = e34_36_0;
            s36_1 = e34_36_1;
            goto IL_0256;
        } else {
            __cil_ref_968d1c518857d9e449963446776981759acaad0f e34_35_0 = v127;
            __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b e34_35_1 = v128;
            s35_0 = e34_35_0;
            s35_1 = e34_35_1;
            goto IL_023F;
        }
        IL_023F: ;
        global::OpenRA.Map.__name_3C3E63 v129 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v130 = __cil_ldftn_06001048;
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b v131 = __cil_newobj_0A000387(v129, v130);
        OpenRA.Map.__name_3C3E63.__il_field_04000A23 = v131;
        __cil_ref_968d1c518857d9e449963446776981759acaad0f e35_36_0 = s35_0;
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b e35_36_1 = v131;
        s36_0 = e35_36_0;
        s36_1 = e35_36_1;
        goto IL_0256;
        IL_0256: ;
        __cil_ref_bd2174d306a52826a722544d88d37718eb703105 v132 = OpenRA.Map.__name_3C3E63.__il_field_04000A24;
        if (v132 is not null) {
            __cil_ref_968d1c518857d9e449963446776981759acaad0f e36_38_0 = s36_0;
            __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b e36_38_1 = s36_1;
            __cil_ref_bd2174d306a52826a722544d88d37718eb703105 e36_38_2 = v132;
            s38_0 = e36_38_0;
            s38_1 = e36_38_1;
            s38_2 = e36_38_2;
            goto IL_0275;
        } else {
            __cil_ref_968d1c518857d9e449963446776981759acaad0f e36_37_0 = s36_0;
            __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b e36_37_1 = s36_1;
            __cil_ref_bd2174d306a52826a722544d88d37718eb703105 e36_37_2 = v132;
            s37_0 = e36_37_0;
            s37_1 = e36_37_1;
            s37_2 = e36_37_2;
            goto IL_025E;
        }
        IL_025E: ;
        global::OpenRA.Map.__name_3C3E63 v133 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v134 = __cil_ldftn_06001049;
        __cil_ref_bd2174d306a52826a722544d88d37718eb703105 v135 = __cil_newobj_0A000388(v133, v134);
        OpenRA.Map.__name_3C3E63.__il_field_04000A24 = v135;
        __cil_ref_968d1c518857d9e449963446776981759acaad0f e37_38_0 = s37_0;
        __cil_ref_ad5876235d5dc040c8653ee3230491dbd549994b e37_38_1 = s37_1;
        __cil_ref_bd2174d306a52826a722544d88d37718eb703105 e37_38_2 = v135;
        s38_0 = e37_38_0;
        s38_1 = e37_38_1;
        s38_2 = e37_38_2;
        goto IL_0275;
        IL_0275: ;
        __cil_ref_580011c36ff80beae1f45c104efb341fb1370d8b v136 = __cil_methodspec_call_2B0000AC(s38_0, s38_1, s38_2);
        l14 = v136;
        int v137 = 0;
        l25 = v137;
        goto IL_042B;
        IL_0284: ;
        int v138 = 0;
        l26 = v138;
        goto IL_041C;
        IL_028C: ;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v139 = ref l27;
        int v140 = l26;
        global::OpenRA.Map v141 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v142 = ref v141.Bounds;
        int v143 = __cil_direct_06000BBA(ref v142);
        int v144 = unchecked(v140 + v143);
        int v145 = l25;
        int v146 = l6;
        int v147 = unchecked(v145 + v146);
        __cil_value_ctor_06000421(ref v139, v144, v147);
        __cil_ref_580011c36ff80beae1f45c104efb341fb1370d8b v148 = l14;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v149 = l27;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v150 = ref l28;
        int v151 = __cil_bool_load(__cil_callvirt_0A00038A(v148, v149, ref v150));
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v152 = ref l28;
        int v153 = unchecked((int)(__cil_direct_06000A50(ref v152)));
        if (v153 != 0) {
            goto IL_02C5;
        } else {
            goto IL_02BB;
        }
        IL_02BB: ;
        global::OpenRA.Map v154 = this;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v155 = l27;
        __cil_value_726631b0bdcfb3e2db894c92edddc94b72286860 v156 = __cil_direct_0600031C(v154, v155);
        l13 = v156;
        goto IL_02C5;
        IL_02C5: ;
        int v157 = __cil_bool_load(l5);
        if (v157 == 0) {
            goto IL_03B5;
        } else {
            goto IL_02CC;
        }
        IL_02CC: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v158 = l27;
        int v159 = v158.V;
        int v160 = 1;
        int v161 = unchecked(v159 & v160);
        l29 = v161;
        int v162 = 4;
        int v163 = 2;
        int v164 = l26;
        int v165 = unchecked(v163 * v164);
        int v166 = l29;
        int v167 = unchecked(v165 + v166);
        int v168 = unchecked(v162 * v167);
        l30 = v168;
        int v169 = l26;
        int v170 = l29;
        int v171 = unchecked(v169 + v170);
        int v172 = 0;
        if (v171 <= v172) {
            goto IL_034B;
        } else {
            goto IL_02EA;
        }
        IL_02EA: ;
        int v173 = l25;
        int v174 = l11;
        int v175 = unchecked(v173 * v174);
        int v176 = l30;
        int v177 = unchecked(v175 + v176);
        int v178 = 4;
        int v179 = unchecked(v177 - v178);
        l31 = v179;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v180 = ref l28;
        int v181 = unchecked((int)(__cil_direct_06000A50(ref v180)));
        if (v181 == 0) {
            goto IL_0303;
        } else {
            goto IL_02FF;
        }
        IL_02FF: ;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v182 = l28;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f e45_47_0 = v182;
        s47_0 = e45_47_0;
        goto IL_030A;
        IL_0303: ;
        __cil_value_726631b0bdcfb3e2db894c92edddc94b72286860 v183 = l13;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v184 = v183.Item1;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f e46_47_0 = v184;
        s47_0 = e46_47_0;
        goto IL_030A;
        IL_030A: ;
        l32 = s47_0;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v185 = l12;
        int v186 = l31;
        int v187 = 1;
        int v188 = unchecked(v186 + v187);
        l31 = v188;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v189 = ref l32;
        int v190 = unchecked((int)(__cil_direct_06000A51(ref v189)));
        v185[v186] = unchecked((byte)(v190));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v191 = l12;
        int v192 = l31;
        int v193 = 1;
        int v194 = unchecked(v192 + v193);
        l31 = v194;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v195 = ref l32;
        int v196 = unchecked((int)(__cil_direct_06000A52(ref v195)));
        v191[v192] = unchecked((byte)(v196));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v197 = l12;
        int v198 = l31;
        int v199 = 1;
        int v200 = unchecked(v198 + v199);
        l31 = v200;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v201 = ref l32;
        int v202 = unchecked((int)(__cil_direct_06000A53(ref v201)));
        v197[v198] = unchecked((byte)(v202));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v203 = l12;
        int v204 = l31;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v205 = ref l32;
        int v206 = unchecked((int)(__cil_direct_06000A50(ref v205)));
        v203[v204] = unchecked((byte)(v206));
        goto IL_034B;
        IL_034B: ;
        int v207 = l30;
        int v208 = l11;
        if (v207 >= v208) {
            goto IL_0416;
        } else {
            goto IL_0354;
        }
        IL_0354: ;
        int v209 = l25;
        int v210 = l11;
        int v211 = unchecked(v209 * v210);
        int v212 = l30;
        int v213 = unchecked(v211 + v212);
        l33 = v213;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v214 = ref l28;
        int v215 = unchecked((int)(__cil_direct_06000A50(ref v214)));
        if (v215 == 0) {
            goto IL_036B;
        } else {
            goto IL_0367;
        }
        IL_0367: ;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v216 = l28;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f e50_52_0 = v216;
        s52_0 = e50_52_0;
        goto IL_0372;
        IL_036B: ;
        __cil_value_726631b0bdcfb3e2db894c92edddc94b72286860 v217 = l13;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v218 = v217.Item2;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f e51_52_0 = v218;
        s52_0 = e51_52_0;
        goto IL_0372;
        IL_0372: ;
        l34 = s52_0;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v219 = l12;
        int v220 = l33;
        int v221 = 1;
        int v222 = unchecked(v220 + v221);
        l33 = v222;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v223 = ref l34;
        int v224 = unchecked((int)(__cil_direct_06000A51(ref v223)));
        v219[v220] = unchecked((byte)(v224));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v225 = l12;
        int v226 = l33;
        int v227 = 1;
        int v228 = unchecked(v226 + v227);
        l33 = v228;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v229 = ref l34;
        int v230 = unchecked((int)(__cil_direct_06000A52(ref v229)));
        v225[v226] = unchecked((byte)(v230));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v231 = l12;
        int v232 = l33;
        int v233 = 1;
        int v234 = unchecked(v232 + v233);
        l33 = v234;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v235 = ref l34;
        int v236 = unchecked((int)(__cil_direct_06000A53(ref v235)));
        v231[v232] = unchecked((byte)(v236));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v237 = l12;
        int v238 = l33;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v239 = ref l34;
        int v240 = unchecked((int)(__cil_direct_06000A50(ref v239)));
        v237[v238] = unchecked((byte)(v240));
        goto IL_0416;
        IL_03B5: ;
        int v241 = l25;
        int v242 = l11;
        int v243 = unchecked(v241 * v242);
        int v244 = 4;
        int v245 = l26;
        int v246 = unchecked(v244 * v245);
        int v247 = unchecked(v243 + v246);
        l35 = v247;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v248 = ref l28;
        int v249 = unchecked((int)(__cil_direct_06000A50(ref v248)));
        if (v249 == 0) {
            goto IL_03CE;
        } else {
            goto IL_03CA;
        }
        IL_03CA: ;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v250 = l28;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f e54_56_0 = v250;
        s56_0 = e54_56_0;
        goto IL_03D5;
        IL_03CE: ;
        __cil_value_726631b0bdcfb3e2db894c92edddc94b72286860 v251 = l13;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v252 = v251.Item1;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f e55_56_0 = v252;
        s56_0 = e55_56_0;
        goto IL_03D5;
        IL_03D5: ;
        l36 = s56_0;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v253 = l12;
        int v254 = l35;
        int v255 = 1;
        int v256 = unchecked(v254 + v255);
        l35 = v256;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v257 = ref l36;
        int v258 = unchecked((int)(__cil_direct_06000A51(ref v257)));
        v253[v254] = unchecked((byte)(v258));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v259 = l12;
        int v260 = l35;
        int v261 = 1;
        int v262 = unchecked(v260 + v261);
        l35 = v262;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v263 = ref l36;
        int v264 = unchecked((int)(__cil_direct_06000A52(ref v263)));
        v259[v260] = unchecked((byte)(v264));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v265 = l12;
        int v266 = l35;
        int v267 = 1;
        int v268 = unchecked(v266 + v267);
        l35 = v268;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v269 = ref l36;
        int v270 = unchecked((int)(__cil_direct_06000A53(ref v269)));
        v265[v266] = unchecked((byte)(v270));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v271 = l12;
        int v272 = l35;
        ref __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v273 = ref l36;
        int v274 = unchecked((int)(__cil_direct_06000A50(ref v273)));
        v271[v272] = unchecked((byte)(v274));
        goto IL_0416;
        IL_0416: ;
        int v275 = l26;
        int v276 = 1;
        int v277 = unchecked(v275 + v276);
        l26 = v277;
        goto IL_041C;
        IL_041C: ;
        int v278 = l26;
        int v279 = l8;
        if (v278 < v279) {
            goto IL_028C;
        } else {
            goto IL_0425;
        }
        IL_0425: ;
        int v280 = l25;
        int v281 = 1;
        int v282 = unchecked(v280 + v281);
        l25 = v282;
        goto IL_042B;
        IL_042B: ;
        int v283 = l25;
        int v284 = l9;
        if (v283 < v284) {
            goto IL_0284;
        } else {
            goto IL_0434;
        }
        IL_0434: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v285 = l12;
        int v286 = 3;
        int v287 = l10;
        int v288 = l9;
        global::OpenRA.FileFormats.Png v289 = __cil_newobj_06000F14(v285, v286, v287, v288, null, null);
        l15 = v289;
        global::OpenRA.FileFormats.Png v290 = l15;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v291 = __cil_callvirt_06000F18(v290);
        return v291;
    }

    public System.ValueTuple<int, int> GetCellSpaceBounds()
    {
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 bytes=1512809D01118220: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e bytes=151280C90211822008: class [System.Runtime]System.Func`2<valuetype OpenRA.MPos, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4 bytes=1512808501118220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_932db6e405b74517db7e33795f917f1d03f9d0ee bytes=15118229020808: valuetype [System.Runtime]System.ValueTuple`2<int32, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        int l0 = default;
        int l1 = default;
        int l2 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 l3 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 l4 = default;
        int s3_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s3_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s3_2 = default;
        int s4_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s4_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s4_2 = default;
        int s7_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s7_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s7_2 = default;
        int s8_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s8_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s8_2 = default;
        IL_0000: ;
        int v0 = 2147483647;
        l0 = v0;
        int v1 = -2147483648;
        l1 = v1;
        global::OpenRA.Map v2 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v3 = ref v2.Bounds;
        int v4 = __cil_direct_06000BBA(ref v3);
        l2 = v4;
        goto IL_00C8;
        IL_001D: ;
        global::OpenRA.Map v5 = this;
        int v6 = l2;
        global::OpenRA.Map v7 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v8 = ref v7.Bounds;
        int v9 = __cil_direct_06000BBC(ref v8);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v10 = __cil_value_newobj_0600042C(v6, v9);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v11 = __cil_direct_0600032C(v5, v10);
        l3 = v11;
        global::OpenRA.Map v12 = this;
        int v13 = l2;
        global::OpenRA.Map v14 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v15 = ref v14.Bounds;
        int v16 = __cil_direct_06000BBD(ref v15);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v17 = __cil_value_newobj_0600042C(v13, v16);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v18 = __cil_direct_0600032C(v12, v17);
        l4 = v18;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v19 = l3;
        int v20 = __cil_callvirt_0A000374(v19);
        int v21 = 0;
        if (v20 <= v21) {
            goto IL_0088;
        } else {
            goto IL_0057;
        }
        IL_0057: ;
        int v22 = l0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v23 = l3;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v24 = OpenRA.Map.__name_3C3E63.__il_field_04000A25;
        if (v24 is not null) {
            int e2_4_0 = v22;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e2_4_1 = v23;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e2_4_2 = v24;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            s4_2 = e2_4_2;
            goto IL_0078;
        } else {
            int e2_3_0 = v22;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e2_3_1 = v23;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e2_3_2 = v24;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            s3_2 = e2_3_2;
            goto IL_0061;
        }
        IL_0061: ;
        global::OpenRA.Map.__name_3C3E63 v25 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v26 = __cil_ldftn_0600104A;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v27 = __cil_newobj_0A000375(v25, v26);
        OpenRA.Map.__name_3C3E63.__il_field_04000A25 = v27;
        int e3_4_0 = s3_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e3_4_1 = s3_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e3_4_2 = v27;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        s4_2 = e3_4_2;
        goto IL_0078;
        IL_0078: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v28 = __cil_methodspec_call_2B0000AD(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s4_1)), s4_2);
        int v29 = v28.V;
        int v30 = System.Math.Min(s4_0, v29);
        l0 = v30;
        goto IL_0088;
        IL_0088: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v31 = l4;
        int v32 = __cil_callvirt_0A000374(v31);
        int v33 = 0;
        if (v32 <= v33) {
            goto IL_00C4;
        } else {
            goto IL_0092;
        }
        IL_0092: ;
        int v34 = l1;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v35 = l4;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v36 = OpenRA.Map.__name_3C3E63.__il_field_04000A26;
        if (v36 is not null) {
            int e6_8_0 = v34;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e6_8_1 = v35;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e6_8_2 = v36;
            s8_0 = e6_8_0;
            s8_1 = e6_8_1;
            s8_2 = e6_8_2;
            goto IL_00B4;
        } else {
            int e6_7_0 = v34;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e6_7_1 = v35;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e6_7_2 = v36;
            s7_0 = e6_7_0;
            s7_1 = e6_7_1;
            s7_2 = e6_7_2;
            goto IL_009D;
        }
        IL_009D: ;
        global::OpenRA.Map.__name_3C3E63 v37 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v38 = __cil_ldftn_0600104B;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v39 = __cil_newobj_0A000375(v37, v38);
        OpenRA.Map.__name_3C3E63.__il_field_04000A26 = v39;
        int e7_8_0 = s7_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e7_8_1 = s7_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e7_8_2 = v39;
        s8_0 = e7_8_0;
        s8_1 = e7_8_1;
        s8_2 = e7_8_2;
        goto IL_00B4;
        IL_00B4: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v40 = __cil_methodspec_call_2B0000A5(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s8_1)), s8_2);
        int v41 = v40.V;
        int v42 = System.Math.Max(s8_0, v41);
        l1 = v42;
        goto IL_00C4;
        IL_00C4: ;
        int v43 = l2;
        int v44 = 1;
        int v45 = unchecked(v43 + v44);
        l2 = v45;
        goto IL_00C8;
        IL_00C8: ;
        int v46 = l2;
        global::OpenRA.Map v47 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v48 = ref v47.Bounds;
        int v49 = __cil_direct_06000BBB(ref v48);
        if (v46 < v49) {
            goto IL_001D;
        } else {
            goto IL_00D9;
        }
        IL_00D9: ;
        int v50 = l0;
        int v51 = l1;
        __cil_value_932db6e405b74517db7e33795f917f1d03f9d0ee v52 = __cil_value_newobj_0A00038D(v50, v51);
        return v52;
    }

    public bool Contains(OpenRA.CPos cell)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        global::OpenRA.MapGrid v1 = v0.Grid;
        int v2 = unchecked((int)(v1.Type));
        int v3 = 1;
        if (unchecked((uint)v2) != unchecked((uint)v3)) {
            goto IL_0020;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v4 = ref cell;
        int v5 = __cil_direct_06000053(ref v4);
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v6 = ref cell;
        int v7 = __cil_direct_06000054(ref v6);
        if (v5 >= v7) {
            goto IL_0047;
        } else {
            goto IL_001E;
        }
        IL_001E: ;
        int v8 = 0;
        return __cil_bool_store(v8);
        IL_0020: ;
        global::OpenRA.Map v9 = this;
        global::OpenRA.MapGrid v10 = v9.Grid;
        int v11 = unchecked((int)(v10.MaximumTerrainHeight));
        if (v11 != 0) {
            goto IL_0047;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        global::OpenRA.Map v12 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v13 = ref v12.Bounds;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v14 = ref cell;
        int v15 = __cil_direct_06000053(ref v14);
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v16 = ref cell;
        int v17 = __cil_direct_06000054(ref v16);
        int v18 = __cil_bool_load(__cil_direct_06000BC5(ref v13, v15, v17));
        return __cil_bool_store(v18);
        IL_0047: ;
        global::OpenRA.Map v19 = this;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v20 = ref cell;
        global::OpenRA.Map v21 = this;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v22 = __cil_direct_06000064(ref v20, v21);
        int v23 = __cil_bool_load(__cil_direct_06000320(v19, v22));
        return __cil_bool_store(v23);
    }

    public bool Contains(OpenRA.MPos uv)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06000305 kept: property source signature requires exact type identities.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = __cil_direct_06000305(this);
        int v3 = __cil_bool_load(v1.Contains(uv));
        if (v3 == 0) {
            return false;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        return __cil_direct_06000321(this, uv);
    }

    private bool ContainsAllProjectedCellsCovering(OpenRA.MPos uv)
    {
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 l0 = default;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 l1 = default;
        int l2 = default;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 l3 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        global::OpenRA.MapGrid v1 = v0.Grid;
        int v2 = unchecked((int)(v1.MaximumTerrainHeight));
        if (v2 != 0) {
            goto IL_0025;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        global::OpenRA.Map v3 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v4 = ref v3.Bounds;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v5 = uv;
        int v6 = v5.U;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v7 = uv;
        int v8 = v7.V;
        int v9 = __cil_bool_load(__cil_direct_06000BC5(ref v4, v6, v8));
        return __cil_bool_store(v9);
        IL_0025: ;
        global::OpenRA.Map v10 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v11 = ref v10.projectionSafeBounds;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v12 = uv;
        int v13 = v12.U;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v14 = uv;
        int v15 = v14.V;
        int v16 = __cil_bool_load(__cil_direct_06000BC5(ref v11, v13, v15));
        if (v16 == 0) {
            goto IL_0040;
        } else {
            goto IL_003E;
        }
        IL_003E: ;
        int v17 = 1;
        return __cil_bool_store(v17);
        IL_0040: ;
        global::OpenRA.Map v18 = this;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v19 = uv;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v20 = __cil_direct_0600032B(v18, v19);
        l0 = v20;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v21 = l0;
        nint v22 = unchecked((nint)(v21.LongLength));
        if (v22 != 0) {
            goto IL_004E;
        } else {
            goto IL_004C;
        }
        IL_004C: ;
        int v23 = 0;
        return __cil_bool_store(v23);
        IL_004E: ;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v24 = l0;
        l1 = v24;
        int v25 = 0;
        l2 = v25;
        goto IL_006B;
        IL_0054: ;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v26 = l1;
        int v27 = l2;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v28 = __cil_ldelem_02000089(v26, v27);
        l3 = v28;
        global::OpenRA.Map v29 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v30 = l3;
        int v31 = __cil_bool_load(__cil_direct_06000322(v29, v30));
        if (v31 != 0) {
            goto IL_0067;
        } else {
            goto IL_0065;
        }
        IL_0065: ;
        int v32 = 0;
        return __cil_bool_store(v32);
        IL_0067: ;
        int v33 = l2;
        int v34 = 1;
        int v35 = unchecked(v33 + v34);
        l2 = v35;
        goto IL_006B;
        IL_006B: ;
        int v36 = l2;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v37 = l1;
        nint v38 = unchecked((nint)(v37.LongLength));
        int v39 = unchecked((int)(v38));
        if (v36 < v39) {
            goto IL_0054;
        } else {
            goto IL_0071;
        }
        IL_0071: ;
        int v40 = 1;
        return __cil_bool_store(v40);
    }

    public bool Contains(OpenRA.PPos puv)
    {
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v1 = ref v0.Bounds;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v2 = puv;
        int v3 = v2.U;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v4 = puv;
        int v5 = v4.V;
        int v6 = __cil_bool_load(__cil_direct_06000BC5(ref v1, v3, v5));
        return __cil_bool_store(v6);
    }

    public OpenRA.WPos CenterOfCell(OpenRA.CPos cell)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype OpenRA.CellRamp[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype OpenRA.CellRamp; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        byte l1 = default;
        int s5_0 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        global::OpenRA.MapGrid v1 = v0.Grid;
        int v2 = unchecked((int)(v1.Type));
        if (v2 != 0) {
            goto IL_003A;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v3 = 1024;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v4 = ref cell;
        int v5 = __cil_direct_06000053(ref v4);
        int v6 = unchecked(v3 * v5);
        int v7 = 512;
        int v8 = unchecked(v6 + v7);
        int v9 = 1024;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v10 = ref cell;
        int v11 = __cil_direct_06000054(ref v10);
        int v12 = unchecked(v9 * v11);
        int v13 = 512;
        int v14 = unchecked(v12 + v13);
        int v15 = 0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v16 = __cil_value_newobj_060006AE(v8, v14, v15);
        return v16;
        IL_003A: ;
        global::OpenRA.Map v17 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v18 = __cil_direct_06000301(v17);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v19 = cell;
        ref byte v20 = ref l1;
        int v21 = __cil_bool_load(v18.TryGetValue(v19, ref v20));
        if (v21 != 0) {
            goto IL_004D;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        int v22 = 0;
        int e3_5_0 = v22;
        s5_0 = e3_5_0;
        goto IL_0076;
        IL_004D: ;
        int v23 = 724;
        int v24 = unchecked((int)(l1));
        int v25 = unchecked(v23 * v24);
        global::OpenRA.Map v26 = this;
        global::OpenRA.MapGrid v27 = v26.Grid;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v28 = __cil_callvirt_06000374(v27);
        global::OpenRA.Map v29 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v30 = __cil_direct_06000303(v29);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v31 = cell;
        int v32 = unchecked((int)(v30.get_Item(v31)));
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v33 = ref __cil_ldelema_0200006E(v28, v32);
        int v34 = v33.CenterHeightOffset;
        int v35 = unchecked(v25 + v34);
        int e4_5_0 = v35;
        s5_0 = e4_5_0;
        goto IL_0076;
        IL_0076: ;
        l0 = s5_0;
        int v36 = 724;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v37 = ref cell;
        int v38 = __cil_direct_06000053(ref v37);
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v39 = ref cell;
        int v40 = __cil_direct_06000054(ref v39);
        int v41 = unchecked(v38 - v40);
        int v42 = 1;
        int v43 = unchecked(v41 + v42);
        int v44 = unchecked(v36 * v43);
        int v45 = 724;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v46 = ref cell;
        int v47 = __cil_direct_06000053(ref v46);
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v48 = ref cell;
        int v49 = __cil_direct_06000054(ref v48);
        int v50 = unchecked(v47 + v49);
        int v51 = 1;
        int v52 = unchecked(v50 + v51);
        int v53 = unchecked(v45 * v52);
        int v54 = l0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v55 = __cil_value_newobj_060006AE(v44, v53, v54);
        return v55;
    }

    public OpenRA.WPos CenterOfSubCell(OpenRA.CPos cell, OpenRA.Traits.SubCell subCell)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype OpenRA.CellRamp[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype OpenRA.CellRamp; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 bytes=118344: valuetype OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_c18500ecc51439bfa060b4384ce29c224d5a5b57 bytes=1D118344: valuetype OpenRA.WVec[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d l1 = default;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 l2 = default;
        byte l3 = default;
        __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea l4 = default;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 l5 = default;
        IL_0000: ;
        int v0 = unchecked((int)(unchecked((byte)(subCell))));
        l0 = v0;
        int v1 = l0;
        int v2 = 0;
        if (v1 < v2) {
            goto IL_0091;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        int v3 = l0;
        global::OpenRA.Map v4 = this;
        global::OpenRA.MapGrid v5 = v4.Grid;
        __cil_ref_c18500ecc51439bfa060b4384ce29c224d5a5b57 v6 = v5.SubCellOffsets;
        nint v7 = unchecked((nint)(v6.LongLength));
        int v8 = unchecked((int)(v7));
        if (v3 >= v8) {
            goto IL_0091;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        global::OpenRA.Map v9 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v10 = cell;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v11 = __cil_direct_06000323(v9, v10);
        l1 = v11;
        global::OpenRA.Map v12 = this;
        global::OpenRA.MapGrid v13 = v12.Grid;
        __cil_ref_c18500ecc51439bfa060b4384ce29c224d5a5b57 v14 = v13.SubCellOffsets;
        int v15 = l0;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v16 = __cil_ldelem_020000D1(v14, v15);
        l2 = v16;
        global::OpenRA.Map v17 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v18 = __cil_direct_06000303(v17);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v19 = cell;
        ref byte v20 = ref l3;
        int v21 = __cil_bool_load(v18.TryGetValue(v19, ref v20));
        if (v21 == 0) {
            goto IL_0087;
        } else {
            goto IL_0043;
        }
        IL_0043: ;
        int v22 = unchecked((int)(l3));
        if (v22 == 0) {
            goto IL_0087;
        } else {
            goto IL_0046;
        }
        IL_0046: ;
        global::OpenRA.Map v23 = this;
        global::OpenRA.MapGrid v24 = v23.Grid;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v25 = __cil_callvirt_06000374(v24);
        int v26 = unchecked((int)(l3));
        __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v27 = __cil_ldelem_0200006E(v25, v26);
        l4 = v27;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v28 = ref l2;
        int v29 = 0;
        int v30 = 0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v31 = ref l4;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v32 = l2;
        int v33 = v32.X;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v34 = l2;
        int v35 = v34.Y;
        int v36 = __cil_direct_06000373(ref v31, v33, v35);
        __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v37 = l4;
        int v38 = v37.CenterHeightOffset;
        int v39 = unchecked(v36 - v38);
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v40 = __cil_value_newobj_060006DD(v29, v30, v39);
        l5 = v40;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v41 = ref l5;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v42 = OpenRA.WVec.op_Addition(ref v28, ref v41);
        l2 = v42;
        goto IL_0087;
        IL_0087: ;
        ref __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v43 = ref l1;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v44 = ref l2;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v45 = OpenRA.WPos.op_Addition(ref v43, ref v44);
        return v45;
        IL_0091: ;
        global::OpenRA.Map v46 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v47 = cell;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v48 = __cil_direct_06000323(v46, v47);
        return v48;
    }

    public OpenRA.WDist DistanceAboveTerrain(OpenRA.WPos pos)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype OpenRA.CellRamp[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype OpenRA.CellRamp; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 bytes=118344: valuetype OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd bytes=11831C: valuetype OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 l0 = default;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 l1 = default;
        byte l2 = default;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d l3 = default;
        __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea l4 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        global::OpenRA.MapGrid v1 = v0.Grid;
        int v2 = unchecked((int)(v1.Type));
        if (v2 != 0) {
            goto IL_0019;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v3 = pos;
        int v4 = v3.Z;
        __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd v5 = __cil_value_newobj_06000628(v4);
        return v5;
        IL_0019: ;
        global::OpenRA.Map v6 = this;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v7 = pos;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v8 = __cil_direct_06000329(v6, v7);
        l0 = v8;
        ref __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v9 = ref pos;
        global::OpenRA.Map v10 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v11 = l0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v12 = __cil_direct_06000323(v10, v11);
        l3 = v12;
        ref __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v13 = ref l3;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v14 = OpenRA.WPos.op_Subtraction(ref v9, ref v13);
        l1 = v14;
        global::OpenRA.Map v15 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v16 = __cil_direct_06000303(v15);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v17 = l0;
        ref byte v18 = ref l2;
        int v19 = __cil_bool_load(v16.TryGetValue(v17, ref v18));
        if (v19 == 0) {
            goto IL_0081;
        } else {
            goto IL_0043;
        }
        IL_0043: ;
        int v20 = unchecked((int)(l2));
        if (v20 == 0) {
            goto IL_0081;
        } else {
            goto IL_0046;
        }
        IL_0046: ;
        global::OpenRA.Map v21 = this;
        global::OpenRA.MapGrid v22 = v21.Grid;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v23 = __cil_callvirt_06000374(v22);
        int v24 = unchecked((int)(l2));
        __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v25 = __cil_ldelem_0200006E(v23, v24);
        l4 = v25;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v26 = l1;
        int v27 = v26.Z;
        __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v28 = l4;
        int v29 = v28.CenterHeightOffset;
        int v30 = unchecked(v27 + v29);
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v31 = ref l4;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v32 = l1;
        int v33 = v32.X;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v34 = l1;
        int v35 = v34.Y;
        int v36 = __cil_direct_06000373(ref v31, v33, v35);
        int v37 = unchecked(v30 - v36);
        __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd v38 = __cil_value_newobj_06000628(v37);
        return v38;
        IL_0081: ;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v39 = l1;
        int v40 = v39.Z;
        __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd v41 = __cil_value_newobj_06000628(v40);
        return v41;
    }

    public OpenRA.WRot TerrainOrientation(OpenRA.CPos cell)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype OpenRA.CellRamp[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype OpenRA.CellRamp; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2bd80a14ff0ddfc3a957cd46afaa9ec2c0393bac bytes=118340: valuetype OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        byte l0 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = __cil_direct_06000303(v0);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v2 = cell;
        ref byte v3 = ref l0;
        int v4 = __cil_bool_load(v1.TryGetValue(v2, ref v3));
        if (v4 == 0) {
            goto IL_0027;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Map v5 = this;
        global::OpenRA.MapGrid v6 = v5.Grid;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v7 = __cil_callvirt_06000374(v6);
        int v8 = unchecked((int)(l0));
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v9 = ref __cil_ldelema_0200006E(v7, v8);
        __cil_value_2bd80a14ff0ddfc3a957cd46afaa9ec2c0393bac v10 = v9.Orientation;
        return v10;
        IL_0027: ;
        __cil_value_2bd80a14ff0ddfc3a957cd46afaa9ec2c0393bac v11 = OpenRA.WRot.None;
        return v11;
    }

    public OpenRA.WVec Offset(OpenRA.CVec delta, int dz)
    {
        // structural signature __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 bytes=118344: valuetype OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b3dfeee160a12bf543a4a53eb3d0e0d3471ac19a bytes=112C: valuetype OpenRA.CVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.MapGrid v1 = this.Grid;
        int v2 = unchecked((int)(v1.Type));
        if (v2 != 0) {
            goto IL_002C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v5 = delta.X;
        int v6 = unchecked(1024 * v5);
        int v9 = delta.Y;
        int v10 = unchecked(1024 * v9);
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v12 = __cil_value_newobj_060006DD(v6, v10, 0);
        return v12;
        IL_002C: ;
        int v15 = delta.X;
        int v17 = delta.Y;
        int v18 = unchecked(v15 - v17);
        int v19 = unchecked(724 * v18);
        int v22 = delta.X;
        int v24 = delta.Y;
        int v25 = unchecked(v22 + v24);
        int v26 = unchecked(724 * v25);
        int v29 = unchecked(724 * dz);
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v30 = __cil_value_newobj_060006DD(v19, v26, v29);
        return v30;
    }

    public OpenRA.WDist get_CellHeightStep()
    {
        // structural signature __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd bytes=11831C: valuetype OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int s3_0 = default;
        global::OpenRA.MapGrid v1 = this.Grid;
        int v2 = unchecked((int)(v1.Type));
        if (v2 == 1) {
            goto IL_0015;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int e1_3_0 = 512;
        s3_0 = e1_3_0;
        goto IL_001A;
        IL_0015: ;
        int e2_3_0 = 724;
        s3_0 = e2_3_0;
        IL_001A: ;
        __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd v6 = __cil_value_newobj_06000628(s3_0);
        return v6;
    }

    public OpenRA.CPos CellContaining(OpenRA.WPos pos)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        int s3_0 = default;
        int s4_0 = default;
        int s5_0 = default;
        int s5_1 = default;
        global::OpenRA.MapGrid v1 = this.Grid;
        int v2 = unchecked((int)(v1.Type));
        if (v2 != 0) {
            goto IL_002B;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v4 = pos.X;
        int v6 = unchecked(v4 / 1024);
        int v8 = pos.Y;
        int v10 = unchecked(v8 / 1024);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v11 = __cil_value_newobj_06000057(v6, v10);
        return v11;
        IL_002B: ;
        int v13 = pos.Y;
        int v15 = pos.X;
        int v16 = unchecked(v13 + v15);
        int v18 = unchecked(v16 - 724);
        int v20 = unchecked(v18 / 1448);
        l0 = v20;
        int v22 = pos.Y;
        int v24 = pos.X;
        int v25 = unchecked(v22 - v24);
        int v27 = pos.Y;
        int v29 = pos.X;
        if (v27 > v29) {
            int e2_4_0 = v25;
            s4_0 = e2_4_0;
            goto IL_0067;
        } else {
            int e2_3_0 = v25;
            s3_0 = e2_3_0;
            goto IL_0060;
        }
        IL_0060: ;
        int e3_5_0 = s3_0;
        int e3_5_1 = -724;
        s5_0 = e3_5_0;
        s5_1 = e3_5_1;
        goto IL_006C;
        IL_0067: ;
        int e4_5_0 = s4_0;
        int e4_5_1 = 724;
        s5_0 = e4_5_0;
        s5_1 = e4_5_1;
        IL_006C: ;
        int v32 = unchecked(s5_0 + s5_1);
        int v34 = unchecked(v32 / 1448);
        int v35 = l0;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v37 = __cil_value_newobj_06000057(v35, v34);
        return v37;
    }

    public OpenRA.PPos ProjectedCellCovering(OpenRA.WPos pos)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 bytes=118344: valuetype OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d l0 = default;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 l1 = default;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 l2 = default;
        IL_0000: ;
        ref __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v0 = ref pos;
        int v1 = 0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v2 = pos;
        int v3 = v2.Z;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v4 = pos;
        int v5 = v4.Z;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v6 = __cil_value_newobj_060006DD(v1, v3, v5);
        l1 = v6;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v7 = ref l1;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v8 = OpenRA.WPos.op_Subtraction(ref v0, ref v7);
        l0 = v8;
        global::OpenRA.Map v9 = this;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v10 = l0;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v11 = __cil_direct_06000329(v9, v10);
        l2 = v11;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v12 = ref l2;
        global::OpenRA.Map v13 = this;
        global::OpenRA.MapGrid v14 = v13.Grid;
        int v15 = unchecked((int)(v14.Type));
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v16 = __cil_direct_06000065(ref v12, unchecked((__cil_enum_0200006B)(v15)));
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v17 = OpenRA.PPos.op_Explicit(v16);
        return v17;
    }

    public OpenRA.PPos[] ProjectedCellsCovering(OpenRA.MPos uv)
    {
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 bytes=15128180011D118224: class OpenRA.CellLayer`1<valuetype OpenRA.PPos[]>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(this.initializedCellProjection);
        if (v1 != 0) {
            goto IL_000E;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        __cil_direct_06000316(this);
        IL_000E: ;
        __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 v4 = this.cellProjection;
        int v6 = __cil_bool_load(v4.Contains(uv));
        if (v6 != 0) {
            goto IL_0022;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v7 = OpenRA.Map.NoProjectedCells;
        return v7;
        IL_0022: ;
        __cil_ref_992eaca0c48d4fa8e37191aa0e5ccb898e7126b2 v9 = this.cellProjection;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v11 = v9.get_Item(uv);
        return v11;
    }

    public System.Collections.Generic.List<OpenRA.MPos> Unproject(OpenRA.PPos puv)
    {
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_d435109e911734ac2943470065f35a64fd95de6f bytes=15128180011512809D01118220: class OpenRA.CellLayer`1<class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 bytes=1512809D01118220: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l0 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v1 = OpenRA.PPos.op_Explicit(puv);
        l0 = v1;
        int v3 = __cil_bool_load(this.initializedCellProjection);
        if (v3 != 0) {
            goto IL_0015;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        __cil_direct_06000316(this);
        IL_0015: ;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v6 = this.inverseCellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v7 = l0;
        int v8 = __cil_bool_load(v6.Contains(v7));
        if (v8 != 0) {
            goto IL_0029;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v9 = __cil_newobj_0A000391();
        return v9;
        IL_0029: ;
        __cil_ref_d435109e911734ac2943470065f35a64fd95de6f v11 = this.inverseCellProjection;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v12 = l0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v13 = v11.get_Item(v12);
        return v13;
    }

    public byte ProjectedHeight(OpenRA.PPos puv)
    {
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = this.projectedHeight;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v3 = OpenRA.PPos.op_Explicit(puv);
        int v4 = unchecked((int)(v1.get_Item(v3)));
        return unchecked((byte)(v4));
    }

    public OpenRA.WAngle FacingBetween(OpenRA.CPos cell, OpenRA.CPos towards, OpenRA.WAngle fallbackfacing)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 bytes=118344: valuetype OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_07a2507d1d471100ca84ea2f8ed0cc97a474680e bytes=118318: valuetype OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 l0 = default;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d l1 = default;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d l2 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v1 = towards;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v2 = __cil_direct_06000323(v0, v1);
        l1 = v2;
        ref __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v3 = ref l1;
        global::OpenRA.Map v4 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v5 = cell;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v6 = __cil_direct_06000323(v4, v5);
        l2 = v6;
        ref __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v7 = ref l2;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v8 = OpenRA.WPos.op_Subtraction(ref v3, ref v7);
        l0 = v8;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v9 = ref l0;
        long v10 = __cil_direct_060006EA(ref v9);
        if (v10 != 0) {
            goto IL_0025;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        __cil_value_07a2507d1d471100ca84ea2f8ed0cc97a474680e v11 = fallbackfacing;
        return v11;
        IL_0025: ;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v12 = ref l0;
        __cil_value_07a2507d1d471100ca84ea2f8ed0cc97a474680e v13 = __cil_direct_060006F0(ref v12);
        return v13;
    }

    public void Resize(int width, int height)
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 bytes=15128180011181F8: class OpenRA.CellLayer`1<valuetype OpenRA.ResourceTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd bytes=118724: valuetype OpenRA.Primitives.Size; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab bytes=1181F4: valuetype OpenRA.TerrainTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf96b4f6908dd21d177916d74f9e282375a834a4 bytes=1181F8: valuetype OpenRA.ResourceTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca l0 = default;
        __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 l1 = default;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b l2 = default;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b l3 = default;
        __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd l4 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l5 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l6 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v1 = __cil_direct_060002FD(v0);
        l0 = v1;
        global::OpenRA.Map v2 = this;
        __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 v3 = __cil_direct_060002FF(v2);
        l1 = v3;
        global::OpenRA.Map v4 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v5 = __cil_direct_06000301(v4);
        l2 = v5;
        global::OpenRA.Map v6 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v7 = __cil_direct_06000303(v6);
        l3 = v7;
        ref __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd v8 = ref l4;
        int v9 = width;
        int v10 = height;
        __cil_value_ctor_06000BFD(ref v8, v9, v10);
        global::OpenRA.Map v11 = this;
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v12 = l0;
        __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd v13 = l4;
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v14 = l0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v15 = OpenRA.MPos.Zero;
        __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v16 = v14.get_Item(v15);
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v17 = __cil_methodspec_call_2B0000AE(v12, v13, v16);
        __cil_direct_060002FE(v11, v17);
        global::OpenRA.Map v18 = this;
        __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 v19 = l1;
        __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd v20 = l4;
        __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 v21 = l1;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v22 = OpenRA.MPos.Zero;
        __cil_value_bf96b4f6908dd21d177916d74f9e282375a834a4 v23 = v21.get_Item(v22);
        __cil_ref_142b5d5dc2fa442e34c0299d53b02fec15fd5667 v24 = __cil_methodspec_call_2B0000AF(v19, v20, v23);
        __cil_direct_06000300(v18, v24);
        global::OpenRA.Map v25 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v26 = l2;
        __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd v27 = l4;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v28 = l2;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v29 = OpenRA.MPos.Zero;
        int v30 = unchecked((int)(v28.get_Item(v29)));
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v31 = __cil_methodspec_call_2B0000B0(v26, v27, unchecked((byte)(v30)));
        __cil_direct_06000302(v25, v31);
        global::OpenRA.Map v32 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v33 = l3;
        __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd v34 = l4;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v35 = l3;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v36 = OpenRA.MPos.Zero;
        int v37 = unchecked((int)(v35.get_Item(v36)));
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v38 = __cil_methodspec_call_2B0000B0(v33, v34, unchecked((byte)(v37)));
        __cil_direct_06000304(v32, v38);
        global::OpenRA.Map v39 = this;
        __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd v40 = l4;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v41 = __cil_value_newobj_060004D4(v40);
        __cil_direct_060002EC(v39, v41);
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v42 = ref l5;
        int v43 = 0;
        int v44 = 0;
        __cil_value_ctor_06000421(ref v42, v43, v44);
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v45 = ref l6;
        global::OpenRA.Map v46 = this;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v47 = __cil_direct_060002EB(v46);
        int v48 = v47.X;
        int v49 = 1;
        int v50 = unchecked(v48 - v49);
        global::OpenRA.Map v51 = this;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v52 = __cil_direct_060002EB(v51);
        int v53 = v52.Y;
        int v54 = 1;
        int v55 = unchecked(v53 - v54);
        __cil_value_ctor_06000421(ref v45, v50, v55);
        global::OpenRA.Map v56 = this;
        global::OpenRA.Map v57 = this;
        global::OpenRA.MapGrid v58 = v57.Grid;
        int v59 = unchecked((int)(v58.Type));
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v60 = ref l5;
        global::OpenRA.Map v61 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v62 = __cil_direct_06000429(ref v60, v61);
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v63 = ref l6;
        global::OpenRA.Map v64 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v65 = __cil_direct_06000429(ref v63, v64);
        global::OpenRA.CellRegion v66 = __cil_newobj_060002D9(v59, v62, v65);
        __cil_direct_0600030A(v56, v66);
        global::OpenRA.Map v67 = this;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v68 = l5;
        int v69 = v68.U;
        int v70 = 1;
        int v71 = unchecked(v69 + v70);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v72 = l5;
        int v73 = v72.V;
        int v74 = 1;
        int v75 = unchecked(v73 + v74);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v76 = __cil_value_newobj_0600042C(v71, v75);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v77 = l6;
        int v78 = v77.U;
        int v79 = 1;
        int v80 = unchecked(v78 - v79);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v81 = l6;
        int v82 = v81.V;
        int v83 = 1;
        int v84 = unchecked(v82 - v83);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v85 = __cil_value_newobj_0600042C(v80, v84);
        __cil_direct_06000330(v67, v76, v85);
        return;
    }

    public void SetBounds(OpenRA.PPos tl, OpenRA.PPos br)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_55120a5a7023bb012876790b856f34422122d4c5 bytes=1512808501118224: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.PPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        byte l0 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v1 = tl;
        int v2 = v1.U;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v3 = tl;
        int v4 = v3.V;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v5 = br;
        int v6 = v5.U;
        int v7 = 1;
        int v8 = unchecked(v6 + v7);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v9 = br;
        int v10 = v9.V;
        int v11 = 1;
        int v12 = unchecked(v10 + v11);
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v13 = OpenRA.Primitives.Rectangle.FromLTRB(v2, v4, v8, v12);
        v0.Bounds = v13;
        global::OpenRA.Map v14 = this;
        global::OpenRA.MapGrid v15 = v14.Grid;
        int v16 = unchecked((int)(v15.MaximumTerrainHeight));
        l0 = unchecked((byte)(v16));
        int v17 = unchecked((int)(l0));
        int v18 = 1;
        int v19 = unchecked(v17 & v18);
        int v20 = 1;
        if (unchecked((uint)v19) != unchecked((uint)v20)) {
            goto IL_003E;
        } else {
            goto IL_0039;
        }
        IL_0039: ;
        int v21 = unchecked((int)(l0));
        int v22 = 2;
        int v23 = unchecked(v21 + v22);
        int v24 = unchecked((int)(unchecked((byte)(v23))));
        l0 = unchecked((byte)(v24));
        goto IL_003E;
        IL_003E: ;
        global::OpenRA.Map v25 = this;
        global::OpenRA.Map v26 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v27 = ref v26.Bounds;
        int v28 = __cil_direct_06000BBA(ref v27);
        int v29 = 1;
        int v30 = unchecked(v28 + v29);
        global::OpenRA.Map v31 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v32 = ref v31.Bounds;
        int v33 = __cil_direct_06000BBC(ref v32);
        int v34 = unchecked((int)(l0));
        int v35 = unchecked(v33 + v34);
        global::OpenRA.Map v36 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v37 = ref v36.Bounds;
        int v38 = __cil_direct_06000BBB(ref v37);
        int v39 = 1;
        int v40 = unchecked(v38 - v39);
        global::OpenRA.Map v41 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v42 = ref v41.Bounds;
        int v43 = __cil_direct_06000BBD(ref v42);
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v44 = OpenRA.Primitives.Rectangle.FromLTRB(v30, v35, v40, v43);
        v25.projectionSafeBounds = v44;
        global::OpenRA.Map v45 = this;
        global::OpenRA.MapGrid v46 = v45.Grid;
        int v47 = unchecked((int)(v46.Type));
        int v48 = 1;
        if (unchecked((uint)v47) != unchecked((uint)v48)) {
            goto IL_00D9;
        } else {
            goto IL_0089;
        }
        IL_0089: ;
        global::OpenRA.Map v49 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v50 = tl;
        int v51 = v50.U;
        int v52 = 1448;
        int v53 = unchecked(v51 * v52);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v54 = tl;
        int v55 = v54.V;
        int v56 = 724;
        int v57 = unchecked(v55 * v56);
        int v58 = 0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v59 = __cil_value_newobj_060006AE(v53, v57, v58);
        __cil_direct_060002FA(v49, v59);
        global::OpenRA.Map v60 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v61 = br;
        int v62 = v61.U;
        int v63 = 1448;
        int v64 = unchecked(v62 * v63);
        int v65 = 1;
        int v66 = unchecked(v64 - v65);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v67 = br;
        int v68 = v67.V;
        int v69 = 1;
        int v70 = unchecked(v68 + v69);
        int v71 = 724;
        int v72 = unchecked(v70 * v71);
        int v73 = 1;
        int v74 = unchecked(v72 - v73);
        int v75 = 0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v76 = __cil_value_newobj_060006AE(v66, v74, v75);
        __cil_direct_060002FC(v60, v76);
        goto IL_0127;
        IL_00D9: ;
        global::OpenRA.Map v77 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v78 = tl;
        int v79 = v78.U;
        int v80 = 1024;
        int v81 = unchecked(v79 * v80);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v82 = tl;
        int v83 = v82.V;
        int v84 = 1024;
        int v85 = unchecked(v83 * v84);
        int v86 = 0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v87 = __cil_value_newobj_060006AE(v81, v85, v86);
        __cil_direct_060002FA(v77, v87);
        global::OpenRA.Map v88 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v89 = br;
        int v90 = v89.U;
        int v91 = 1024;
        int v92 = unchecked(v90 * v91);
        int v93 = 1;
        int v94 = unchecked(v92 - v93);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v95 = br;
        int v96 = v95.V;
        int v97 = 1;
        int v98 = unchecked(v96 + v97);
        int v99 = 1024;
        int v100 = unchecked(v98 * v99);
        int v101 = 1;
        int v102 = unchecked(v100 - v101);
        int v103 = 0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v104 = __cil_value_newobj_060006AE(v94, v102, v103);
        __cil_direct_060002FC(v88, v104);
        goto IL_0127;
        IL_0127: ;
        global::OpenRA.Map v105 = this;
        global::OpenRA.Map v106 = this;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v107 = tl;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v108 = br;
        global::OpenRA.ProjectedCellRegion v109 = __cil_newobj_060003BE(v106, v107, v108);
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v110 = __cil_methodspec_call_2B0000A7(((__cil_ref_55120a5a7023bb012876790b856f34422122d4c5)(v109)));
        __cil_direct_06000308(v105, v110);
        return;
    }

    public byte GetTerrainIndex(OpenRA.CPos cell)
    {
        // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab bytes=1181F4: valuetype OpenRA.TerrainTile; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 bytes=151281800106: class OpenRA.CellLayer`1<int16>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l0 = default;
        short l1 = default;
        byte l2 = default;
        short l3 = default;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 s4_0 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 s4_1 = default;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 s5_0 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 s5_1 = default;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 s6_0 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 s6_1 = default;
        int s6_2 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 v1 = v0.cachedTerrainIndexes;
        if (v1 is not null) {
            goto IL_0020;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Map v2 = this;
        global::OpenRA.Map v3 = this;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 v4 = __cil_newobj_0A000392(v3);
        v2.cachedTerrainIndexes = v4;
        global::OpenRA.Map v5 = this;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 v6 = v5.cachedTerrainIndexes;
        int v7 = -1;
        v6.Clear(unchecked((short)(v7)));
        goto IL_0020;
        IL_0020: ;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v8 = ref cell;
        global::OpenRA.Map v9 = this;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v10 = __cil_direct_06000064(ref v8, v9);
        l0 = v10;
        global::OpenRA.Map v11 = this;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 v12 = v11.cachedTerrainIndexes;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v13 = l0;
        int v14 = unchecked((int)(v12.get_Item(v13)));
        l1 = unchecked((short)(v14));
        int v15 = unchecked((int)(l1));
        int v16 = -1;
        if (unchecked((uint)v15) != unchecked((uint)v16)) {
            goto IL_0083;
        } else {
            goto IL_003A;
        }
        IL_003A: ;
        global::OpenRA.Map v17 = this;
        __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v18 = __cil_direct_06000305(v17);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v19 = l0;
        int v20 = unchecked((int)(v18.get_Item(v19)));
        l2 = unchecked((byte)(v20));
        global::OpenRA.Map v21 = this;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 v22 = v21.cachedTerrainIndexes;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v23 = l0;
        int v24 = unchecked((int)(l2));
        int v25 = 255;
        if (unchecked((uint)v24) != unchecked((uint)v25)) {
            __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 e3_5_0 = v22;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e3_5_1 = v23;
            s5_0 = e3_5_0;
            s5_1 = e3_5_1;
            goto IL_0079;
        } else {
            __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 e3_4_0 = v22;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e3_4_1 = v23;
            s4_0 = e3_4_0;
            s4_1 = e3_4_1;
            goto IL_0056;
        }
        IL_0056: ;
        global::OpenRA.Map v26 = this;
        global::OpenRA.Ruleset v27 = __cil_direct_060002F1(v26);
        global::OpenRA.ITerrainInfo v28 = v27.TerrainInfo;
        global::OpenRA.Map v29 = this;
        __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v30 = __cil_direct_060002FD(v29);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v31 = l0;
        __cil_value_7506b4e21674ab9ea0f31e80f63fb098fa4f56ab v32 = v30.get_Item(v31);
        global::OpenRA.TerrainTileInfo v33 = __cil_callvirt_060003C7(v28, v32);
        int v34 = unchecked((int)(v33.TerrainType));
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 e4_6_0 = s4_0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e4_6_1 = s4_1;
        int e4_6_2 = v34;
        s6_0 = e4_6_0;
        s6_1 = e4_6_1;
        s6_2 = e4_6_2;
        goto IL_007A;
        IL_0079: ;
        int v35 = unchecked((int)(l2));
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 e5_6_0 = s5_0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e5_6_1 = s5_1;
        int e5_6_2 = v35;
        s6_0 = e5_6_0;
        s6_1 = e5_6_1;
        s6_2 = e5_6_2;
        goto IL_007A;
        IL_007A: ;
        l3 = unchecked((short)(s6_2));
        s6_0.set_Item(s6_1, unchecked((short)(s6_2)));
        int v36 = unchecked((int)(l3));
        l1 = unchecked((short)(v36));
        goto IL_0083;
        IL_0083: ;
        int v37 = unchecked((int)(l1));
        int v38 = unchecked((int)(unchecked((byte)(v37))));
        return unchecked((byte)(v38));
    }

    public OpenRA.TerrainTypeInfo GetTerrainInfo(OpenRA.CPos cell)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_9d5046d1330bed1c15773124d3da945341833d0d bytes=1D1281EC: class OpenRA.TerrainTypeInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Ruleset v1 = this.Rules;
        global::OpenRA.ITerrainInfo v2 = v1.TerrainInfo;
        __cil_ref_9d5046d1330bed1c15773124d3da945341833d0d v3 = __cil_callvirt_060003C6(v2);
        int v6 = unchecked((int)(__cil_direct_06000331(this, cell)));
        global::OpenRA.TerrainTypeInfo v7 = v3[v6];
        return v7;
    }

    public OpenRA.CPos Clamp(OpenRA.CPos cell)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l0 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v1 = ref cell;
        global::OpenRA.Map v2 = this;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v3 = __cil_direct_06000064(ref v1, v2);
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v4 = __cil_direct_06000334(v0, v3);
        l0 = v4;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v5 = ref l0;
        global::OpenRA.Map v6 = this;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v7 = __cil_direct_06000429(ref v5, v6);
        return v7;
    }

    public OpenRA.MPos Clamp(OpenRA.MPos uv)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 5D, 02, 00, 04, 7B, 9F, 02, 00, 04, 2D, 12, 02, 03, 28, 30, 04, 00, 06, 28, 35, 03, 00]
        // .code-bytes IL_0018: [06, 28, 2F, 04, 00, 06, 2A, 02, 03, 28, 21, 03, 00, 06, 2C, 02, 03, 2A, 02, 7B, 72, 02, 00, 04]
        // .code-bytes IL_0030: [03, 7B, 1C, 03, 00, 04, 02, 7C, 4E, 02, 00, 04, 28, BA, 0B, 00, 06, 02, 7C, 4E, 02, 00, 04, 28]
        // .code-bytes IL_0048: [BB, 0B, 00, 06, 28, 5F, 00, 00, 2B, 03, 7B, 1D, 03, 00, 04, 73, 21, 04, 00, 06, 6F, 96, 03, 00]
        // .code-bytes IL_0060: [0A, 10, 01, 02, 03, 28, 2B, 03, 00, 06, 0A, 06, 8E, 2D, 2E, 03, 7B, 1C, 03, 00, 04, 03, 7B, 1D]
        // .code-bytes IL_0078: [03, 00, 04, 02, 7C, 4E, 02, 00, 04, 28, BC, 0B, 00, 06, 02, 7C, 4E, 02, 00, 04, 28, BD, 0B, 00]
        // .code-bytes IL_0090: [06, 28, 5F, 00, 00, 2B, 73, 2C, 04, 00, 06, 2B, 07, 06, 16, A3, 89, 00, 00, 02, 0B, 02, 07, 28]
        // .code-bytes IL_00A8: [35, 03, 00, 06, 0B, 02, 07, 28, 2C, 03, 00, 06, 0C, 08, 6F, 74, 03, 00, 0A, 3A, 9F, 00, 00, 00]
        // .code-bytes IL_00C0: [18, 0D, 2B, 46, 09, 17, 5F, 17, 2E, 03, 15, 2B, 01, 17, 09, 5A, 18, 5B, 13, 04, 12, 05, 07, 7B]
        // .code-bytes IL_00D8: [1F, 03, 00, 04, 07, 7B, 20, 03, 00, 04, 11, 04, 58, 28, 2C, 04, 00, 06, 02, 11, 05, 28, 22, 03]
        // .code-bytes IL_00F0: [00, 06, 2C, 12, 02, 11, 05, 28, 2C, 03, 00, 06, 0C, 08, 6F, 74, 03, 00, 0A, 16, 30, 14, 09, 17]
        // .code-bytes IL_0108: [58, 0D, 09, 18, 02, 7B, 5D, 02, 00, 04, 7B, 9F, 02, 00, 04, 5A, 31, AA, 08, 6F, 74, 03, 00, 0A]
        // .code-bytes IL_0120: [2D, 3D, 72, 1E, 06, 00, 70, 12, 06, 1F, 27, 17, 28, C4, 00, 00, 0A, 12, 06, 72, DC, 4A, 00, 70]
        // .code-bytes IL_0138: [28, C5, 00, 00, 0A, 12, 06, 03, 28, B1, 00, 00, 2B, 12, 06, 72, 10, 4B, 00, 70, 28, C5, 00, 00]
        // .code-bytes IL_0150: [0A, 12, 06, 28, C7, 00, 00, 0A, 28, C4, 05, 00, 06, 03, 2A, 07, 7B, 20, 03, 00, 04, 02, 7C, 4E]
        // .code-bytes IL_0168: [02, 00, 04, 28, BD, 0B, 00, 06, 2E, 26, 08, 7E, 28, 0A, 00, 04, 25, 2D, 17, 26, 7E, 1F, 0A, 00]
        // .code-bytes IL_0180: [04, FE, 06, 4D, 10, 00, 06, 73, 75, 03, 00, 0A, 25, 80, 28, 0A, 00, 04, 28, AD, 00, 00, 2B, 2A]
        // .code-bytes IL_0198: [08, 7E, 27, 0A, 00, 04, 25, 2D, 17, 26, 7E, 1F, 0A, 00, 04, FE, 06, 4C, 10, 00, 06, 73, 75, 03]
        // .code-bytes IL_01B0: [00, 0A, 25, 80, 27, 0A, 00, 04, 28, A5, 00, 00, 2B, 2A]
        // .local [0] valuetype OpenRA.PPos[]
        // .local [1] valuetype OpenRA.PPos
        // .local [2] class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>
        // .local [3] int32
        // .local [4] int32
        // .local [5] valuetype OpenRA.PPos
        // .local [6] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_0006: ldfld 0x0400029F OpenRA.MapGrid::MaximumTerrainHeight
        // IL_000B: brtrue.s IL_001F
        // IL_000D: ldarg.0 0
        // IL_000E: ldarg.1 1
        // IL_000F: call 0x06000430 OpenRA.PPos::op_Explicit
        // IL_0014: call 0x06000335 OpenRA.Map::Clamp
        // IL_0019: call 0x0600042F OpenRA.PPos::op_Explicit
        // IL_001E: ret 
        // IL_001F: ldarg.0 0
        // IL_0020: ldarg.1 1
        // IL_0021: call 0x06000321 OpenRA.Map::ContainsAllProjectedCellsCovering
        // IL_0026: brfalse.s IL_002A
        // IL_0028: ldarg.1 1
        // IL_0029: ret 
        // IL_002A: ldarg.0 0
        // IL_002B: ldfld 0x04000272 OpenRA.Map::cellProjection
        // IL_0030: ldarg.1 1
        // IL_0031: ldfld 0x0400031C OpenRA.MPos::U
        // IL_0036: ldarg.0 0
        // IL_0037: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_003C: call 0x06000BBA OpenRA.Primitives.Rectangle::get_Left
        // IL_0041: ldarg.0 0
        // IL_0042: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_0047: call 0x06000BBB OpenRA.Primitives.Rectangle::get_Right
        // IL_004C: call 0x2B00005F OpenRA.Exts::Clamp<int32>
        // IL_0051: ldarg.1 1
        // IL_0052: ldfld 0x0400031D OpenRA.MPos::V
        // IL_0057: newobj 0x06000421 OpenRA.MPos::.ctor
        // IL_005C: callvirt 0x0A000396 class OpenRA.CellLayer`1<valuetype OpenRA.PPos[]>::Clamp
        // IL_0061: starg.s 1
        // IL_0063: ldarg.0 0
        // IL_0064: ldarg.1 1
        // IL_0065: call 0x0600032B OpenRA.Map::ProjectedCellsCovering
        // IL_006A: stloc.0 0
        // IL_006B: ldloc.0 0
        // IL_006C: ldlen 
        // IL_006D: brtrue.s IL_009D
        // IL_006F: ldarg.1 1
        // IL_0070: ldfld 0x0400031C OpenRA.MPos::U
        // IL_0075: ldarg.1 1
        // IL_0076: ldfld 0x0400031D OpenRA.MPos::V
        // IL_007B: ldarg.0 0
        // IL_007C: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_0081: call 0x06000BBC OpenRA.Primitives.Rectangle::get_Top
        // IL_0086: ldarg.0 0
        // IL_0087: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_008C: call 0x06000BBD OpenRA.Primitives.Rectangle::get_Bottom
        // IL_0091: call 0x2B00005F OpenRA.Exts::Clamp<int32>
        // IL_0096: newobj 0x0600042C OpenRA.PPos::.ctor
        // IL_009B: br.s IL_00A4
        // IL_009D: ldloc.0 0
        // IL_009E: ldc.i4.0 0
        // IL_009F: ldelem 0x02000089 OpenRA.PPos
        // IL_00A4: stloc.1 1
        // IL_00A5: ldarg.0 0
        // IL_00A6: ldloc.1 1
        // IL_00A7: call 0x06000335 OpenRA.Map::Clamp
        // IL_00AC: stloc.1 1
        // IL_00AD: ldarg.0 0
        // IL_00AE: ldloc.1 1
        // IL_00AF: call 0x0600032C OpenRA.Map::Unproject
        // IL_00B4: stloc.2 2
        // IL_00B5: ldloc.2 2
        // IL_00B6: callvirt 0x0A000374 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>::get_Count
        // IL_00BB: brtrue IL_015F
        // IL_00C0: ldc.i4.2 2
        // IL_00C1: stloc.3 3
        // IL_00C2: br.s IL_010A
        // IL_00C4: ldloc.3 3
        // IL_00C5: ldc.i4.1 1
        // IL_00C6: and 
        // IL_00C7: ldc.i4.1 1
        // IL_00C8: beq.s IL_00CD
        // IL_00CA: ldc.i4.m1 -1
        // IL_00CB: br.s IL_00CE
        // IL_00CD: ldc.i4.1 1
        // IL_00CE: ldloc.3 3
        // IL_00CF: mul 
        // IL_00D0: ldc.i4.2 2
        // IL_00D1: div 
        // IL_00D2: stloc.s 4
        // IL_00D4: ldloca.s 5
        // IL_00D6: ldloc.1 1
        // IL_00D7: ldfld 0x0400031F OpenRA.PPos::U
        // IL_00DC: ldloc.1 1
        // IL_00DD: ldfld 0x04000320 OpenRA.PPos::V
        // IL_00E2: ldloc.s 4
        // IL_00E4: add 
        // IL_00E5: call 0x0600042C OpenRA.PPos::.ctor
        // IL_00EA: ldarg.0 0
        // IL_00EB: ldloc.s 5
        // IL_00ED: call 0x06000322 OpenRA.Map::Contains
        // IL_00F2: brfalse.s IL_0106
        // IL_00F4: ldarg.0 0
        // IL_00F5: ldloc.s 5
        // IL_00F7: call 0x0600032C OpenRA.Map::Unproject
        // IL_00FC: stloc.2 2
        // IL_00FD: ldloc.2 2
        // IL_00FE: callvirt 0x0A000374 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>::get_Count
        // IL_0103: ldc.i4.0 0
        // IL_0104: bgt.s IL_011A
        // IL_0106: ldloc.3 3
        // IL_0107: ldc.i4.1 1
        // IL_0108: add 
        // IL_0109: stloc.3 3
        // IL_010A: ldloc.3 3
        // IL_010B: ldc.i4.2 2
        // IL_010C: ldarg.0 0
        // IL_010D: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_0112: ldfld 0x0400029F OpenRA.MapGrid::MaximumTerrainHeight
        // IL_0117: mul 
        // IL_0118: ble.s IL_00C4
        // IL_011A: ldloc.2 2
        // IL_011B: callvirt 0x0A000374 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>::get_Count
        // IL_0120: brtrue.s IL_015F
        // IL_0122: ldstr 0x7000061E [100, 101, 98, 117, 103] utf16-bytes=[64, 00, 65, 00, 62, 00, 75, 00, 67, 00] terminal-flag=Some(0)
        // IL_0127: ldloca.s 6
        // IL_0129: ldc.i4.s 39
        // IL_012B: ldc.i4.1 1
        // IL_012C: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0131: ldloca.s 6
        // IL_0133: ldstr 0x70004ADC [70, 97, 105, 108, 101, 100, 32, 116, 111, 32, 99, 108, 97, 109, 112, 32, 109, 97, 112, 32, 99, 101, 108, 108, 32] utf16-bytes=[46, 00, 61, 00, 69, 00, 6C, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 63, 00, 6C, 00, 61, 00, 6D, 00, 70, 00, 20, 00, 6D, 00, 61, 00, 70, 00, 20, 00, 63, 00, 65, 00, 6C, 00, 6C, 00, 20, 00] terminal-flag=Some(0)
        // IL_0138: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_013D: ldloca.s 6
        // IL_013F: ldarg.1 1
        // IL_0140: call 0x2B0000B1 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<valuetype OpenRA.MPos>
        // IL_0145: ldloca.s 6
        // IL_0147: ldstr 0x70004B10 [32, 116, 111, 32, 109, 97, 112, 32, 98, 111, 117, 110, 100, 115] utf16-bytes=[20, 00, 74, 00, 6F, 00, 20, 00, 6D, 00, 61, 00, 70, 00, 20, 00, 62, 00, 6F, 00, 75, 00, 6E, 00, 64, 00, 73, 00] terminal-flag=Some(0)
        // IL_014C: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0151: ldloca.s 6
        // IL_0153: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0158: call 0x060005C4 OpenRA.Log::Write
        // IL_015D: ldarg.1 1
        // IL_015E: ret 
        // IL_015F: ldloc.1 1
        // IL_0160: ldfld 0x04000320 OpenRA.PPos::V
        // IL_0165: ldarg.0 0
        // IL_0166: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_016B: call 0x06000BBD OpenRA.Primitives.Rectangle::get_Bottom
        // IL_0170: beq.s IL_0198
        // IL_0172: ldloc.2 2
        // IL_0173: ldsfld 0x04000A28 OpenRA.Map/<>c::<>9__146_1
        // IL_0178: dup 
        // IL_0179: brtrue.s IL_0192
        // IL_017B: pop 
        // IL_017C: ldsfld 0x04000A1F OpenRA.Map/<>c::<>9
        // IL_0181: ldftn 0x0600104D OpenRA.Map/<>c::<Clamp>b__146_1
        // IL_0187: newobj 0x0A000375 class [System.Runtime]System.Func`2<valuetype OpenRA.MPos, int32>::.ctor
        // IL_018C: dup 
        // IL_018D: stsfld 0x04000A28 OpenRA.Map/<>c::<>9__146_1
        // IL_0192: call 0x2B0000AD OpenRA.Exts::MinBy<valuetype OpenRA.MPos, int32>
        // IL_0197: ret 
        // IL_0198: ldloc.2 2
        // IL_0199: ldsfld 0x04000A27 OpenRA.Map/<>c::<>9__146_0
        // IL_019E: dup 
        // IL_019F: brtrue.s IL_01B8
        // IL_01A1: pop 
        // IL_01A2: ldsfld 0x04000A1F OpenRA.Map/<>c::<>9
        // IL_01A7: ldftn 0x0600104C OpenRA.Map/<>c::<Clamp>b__146_0
        // IL_01AD: newobj 0x0A000375 class [System.Runtime]System.Func`2<valuetype OpenRA.MPos, int32>::.ctor
        // IL_01B2: dup 
        // IL_01B3: stsfld 0x04000A27 OpenRA.Map/<>c::<>9__146_0
        // IL_01B8: call 0x2B0000A5 OpenRA.Exts::MaxBy<valuetype OpenRA.MPos, int32>
        // IL_01BD: ret 
    }

    public OpenRA.PPos Clamp(OpenRA.PPos puv)
    {
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 l0 = default;
        IL_0000: ;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v0 = ref l0;
        global::OpenRA.Map v1 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v2 = ref v1.Bounds;
        int v3 = v2.X;
        global::OpenRA.Map v4 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v5 = ref v4.Bounds;
        int v6 = v5.Y;
        global::OpenRA.Map v7 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v8 = ref v7.Bounds;
        int v9 = v8.Width;
        int v10 = 1;
        int v11 = unchecked(v9 - v10);
        global::OpenRA.Map v12 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v13 = ref v12.Bounds;
        int v14 = v13.Height;
        int v15 = 1;
        int v16 = unchecked(v14 - v15);
        __cil_value_ctor_06000BB8(ref v0, v3, v6, v11, v16);
        ref __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v17 = ref puv;
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v18 = l0;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v19 = __cil_direct_06000431(ref v17, v18);
        return v19;
    }

    public OpenRA.CPos ChooseRandomCell(OpenRA.Support.MersenneTwister rand)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 bytes=1512809D01118220: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4 bytes=1512808501118220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 l0 = default;
        int l1 = default;
        int l2 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l3 = default;
        IL_0000: ;
        global::OpenRA.Support.MersenneTwister v0 = rand;
        global::OpenRA.Map v1 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v2 = ref v1.Bounds;
        int v3 = __cil_direct_06000BBA(ref v2);
        global::OpenRA.Map v4 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v5 = ref v4.Bounds;
        int v6 = __cil_direct_06000BBB(ref v5);
        int v7 = __cil_callvirt_060007A0(v0, v3, v6);
        l1 = v7;
        global::OpenRA.Support.MersenneTwister v8 = rand;
        global::OpenRA.Map v9 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v10 = ref v9.Bounds;
        int v11 = __cil_direct_06000BBC(ref v10);
        global::OpenRA.Map v12 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v13 = ref v12.Bounds;
        int v14 = __cil_direct_06000BBD(ref v13);
        int v15 = __cil_callvirt_060007A0(v8, v11, v14);
        l2 = v15;
        global::OpenRA.Map v16 = this;
        int v17 = l1;
        int v18 = l2;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v19 = __cil_value_newobj_0600042C(v17, v18);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v20 = __cil_direct_0600032C(v16, v19);
        l0 = v20;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v21 = l0;
        int v22 = __cil_callvirt_0A000374(v21);
        if (v22 == 0) {
            goto IL_0000;
        } else {
            goto IL_0050;
        }
        IL_0050: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v23 = l0;
        global::OpenRA.Support.MersenneTwister v24 = rand;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v25 = __cil_methodspec_call_2B0000B2(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(v23)), v24);
        l3 = v25;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v26 = ref l3;
        global::OpenRA.Map v27 = this;
        global::OpenRA.MapGrid v28 = v27.Grid;
        int v29 = unchecked((int)(v28.Type));
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v30 = __cil_direct_0600042A(ref v26, unchecked((__cil_enum_0200006B)(v29)));
        return v30;
    }

    public OpenRA.CPos ChooseClosestEdgeCell(OpenRA.CPos cell)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l0 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        ref __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v1 = ref cell;
        global::OpenRA.Map v2 = this;
        global::OpenRA.MapGrid v3 = v2.Grid;
        int v4 = unchecked((int)(v3.Type));
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v5 = __cil_direct_06000065(ref v1, unchecked((__cil_enum_0200006B)(v4)));
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v6 = __cil_direct_06000338(v0, v5);
        l0 = v6;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v7 = ref l0;
        global::OpenRA.Map v8 = this;
        global::OpenRA.MapGrid v9 = v8.Grid;
        int v10 = unchecked((int)(v9.Type));
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v11 = __cil_direct_0600042A(ref v7, unchecked((__cil_enum_0200006B)(v10)));
        return v11;
    }

    public OpenRA.MPos ChooseClosestEdgeCell(OpenRA.MPos uv)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 03, 28, 2B, 03, 00, 06, 0A, 06, 8E, 39, C3, 00, 00, 00, 06, 16, A3, 89, 00, 00, 02, 0D, 09]
        // .code-bytes IL_0018: [7B, 1F, 03, 00, 04, 02, 7C, 4E, 02, 00, 04, 28, BA, 0B, 00, 06, 59, 02, 7C, 4E, 02, 00, 04, 7B]
        // .code-bytes IL_0030: [E2, 06, 00, 04, 18, 5B, 32, 0D, 02, 7C, 4E, 02, 00, 04, 28, BB, 0B, 00, 06, 2B, 0B, 02, 7C, 4E]
        // .code-bytes IL_0048: [02, 00, 04, 28, BA, 0B, 00, 06, 13, 04, 09, 7B, 20, 03, 00, 04, 02, 7C, 4E, 02, 00, 04, 28, BC]
        // .code-bytes IL_0060: [0B, 00, 06, 59, 02, 7C, 4E, 02, 00, 04, 7B, E3, 06, 00, 04, 18, 5B, 32, 0D, 02, 7C, 4E, 02, 00]
        // .code-bytes IL_0078: [04, 28, BD, 0B, 00, 06, 2B, 0B, 02, 7C, 4E, 02, 00, 04, 28, BC, 0B, 00, 06, 13, 05, 11, 04, 09]
        // .code-bytes IL_0090: [7B, 1F, 03, 00, 04, 59, 28, 17, 01, 00, 0A, 13, 06, 11, 05, 09, 7B, 20, 03, 00, 04, 59, 28, 17]
        // .code-bytes IL_00A8: [01, 00, 0A, 13, 07, 11, 06, 11, 07, 32, 0F, 09, 7B, 1F, 03, 00, 04, 11, 05, 73, 2C, 04, 00, 06]
        // .code-bytes IL_00C0: [2B, 0D, 11, 04, 09, 7B, 20, 03, 00, 04, 73, 2C, 04, 00, 06, 0B, 2B, 1D, 12, 01, 02, 7C, 4E, 02]
        // .code-bytes IL_00D8: [00, 04, 28, BA, 0B, 00, 06, 02, 7C, 4E, 02, 00, 04, 28, BC, 0B, 00, 06, 28, 2C, 04, 00, 06, 02]
        // .code-bytes IL_00F0: [07, 28, 2C, 03, 00, 06, 0C, 08, 6F, 74, 03, 00, 0A, 3A, 99, 00, 00, 00, 18, 13, 08, 2B, 4A, 11]
        // .code-bytes IL_0108: [08, 17, 5F, 17, 2E, 03, 15, 2B, 01, 17, 11, 08, 5A, 18, 5B, 13, 09, 12, 0A, 07, 7B, 1F, 03, 00]
        // .code-bytes IL_0120: [04, 07, 7B, 20, 03, 00, 04, 11, 09, 58, 28, 2C, 04, 00, 06, 02, 11, 0A, 28, 22, 03, 00, 06, 2C]
        // .code-bytes IL_0138: [12, 02, 11, 0A, 28, 2C, 03, 00, 06, 0C, 08, 6F, 74, 03, 00, 0A, 16, 30, 17, 11, 08, 17, 58, 13]
        // .code-bytes IL_0150: [08, 11, 08, 18, 02, 7B, 5D, 02, 00, 04, 7B, 9F, 02, 00, 04, 5A, 31, A5, 08, 6F, 74, 03, 00, 0A]
        // .code-bytes IL_0168: [2D, 31, 72, 1E, 06, 00, 70, 12, 0B, 1F, 29, 17, 28, C4, 00, 00, 0A, 12, 0B, 72, 2E, 4B, 00, 70]
        // .code-bytes IL_0180: [28, C5, 00, 00, 0A, 12, 0B, 03, 28, B1, 00, 00, 2B, 12, 0B, 28, C7, 00, 00, 0A, 28, C4, 05, 00]
        // .code-bytes IL_0198: [06, 03, 2A, 07, 7B, 20, 03, 00, 04, 02, 7C, 4E, 02, 00, 04, 28, BD, 0B, 00, 06, 2E, 26, 08, 7E]
        // .code-bytes IL_01B0: [2A, 0A, 00, 04, 25, 2D, 17, 26, 7E, 1F, 0A, 00, 04, FE, 06, 4F, 10, 00, 06, 73, 75, 03, 00, 0A]
        // .code-bytes IL_01C8: [25, 80, 2A, 0A, 00, 04, 28, AD, 00, 00, 2B, 2A, 08, 7E, 29, 0A, 00, 04, 25, 2D, 17, 26, 7E, 1F]
        // .code-bytes IL_01E0: [0A, 00, 04, FE, 06, 4E, 10, 00, 06, 73, 75, 03, 00, 0A, 25, 80, 29, 0A, 00, 04, 28, A5, 00, 00]
        // .code-bytes IL_01F8: [2B, 2A]
        // .local [0] valuetype OpenRA.PPos[]
        // .local [1] valuetype OpenRA.PPos
        // .local [2] class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>
        // .local [3] valuetype OpenRA.PPos
        // .local [4] int32
        // .local [5] int32
        // .local [6] int32
        // .local [7] int32
        // .local [8] int32
        // .local [9] int32
        // .local [10] valuetype OpenRA.PPos
        // .local [11] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: call 0x0600032B OpenRA.Map::ProjectedCellsCovering
        // IL_0007: stloc.0 0
        // IL_0008: ldloc.0 0
        // IL_0009: ldlen 
        // IL_000A: brfalse IL_00D2
        // IL_000F: ldloc.0 0
        // IL_0010: ldc.i4.0 0
        // IL_0011: ldelem 0x02000089 OpenRA.PPos
        // IL_0016: stloc.3 3
        // IL_0017: ldloc.3 3
        // IL_0018: ldfld 0x0400031F OpenRA.PPos::U
        // IL_001D: ldarg.0 0
        // IL_001E: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_0023: call 0x06000BBA OpenRA.Primitives.Rectangle::get_Left
        // IL_0028: sub 
        // IL_0029: ldarg.0 0
        // IL_002A: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_002F: ldfld 0x040006E2 OpenRA.Primitives.Rectangle::Width
        // IL_0034: ldc.i4.2 2
        // IL_0035: div 
        // IL_0036: blt.s IL_0045
        // IL_0038: ldarg.0 0
        // IL_0039: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_003E: call 0x06000BBB OpenRA.Primitives.Rectangle::get_Right
        // IL_0043: br.s IL_0050
        // IL_0045: ldarg.0 0
        // IL_0046: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_004B: call 0x06000BBA OpenRA.Primitives.Rectangle::get_Left
        // IL_0050: stloc.s 4
        // IL_0052: ldloc.3 3
        // IL_0053: ldfld 0x04000320 OpenRA.PPos::V
        // IL_0058: ldarg.0 0
        // IL_0059: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_005E: call 0x06000BBC OpenRA.Primitives.Rectangle::get_Top
        // IL_0063: sub 
        // IL_0064: ldarg.0 0
        // IL_0065: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_006A: ldfld 0x040006E3 OpenRA.Primitives.Rectangle::Height
        // IL_006F: ldc.i4.2 2
        // IL_0070: div 
        // IL_0071: blt.s IL_0080
        // IL_0073: ldarg.0 0
        // IL_0074: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_0079: call 0x06000BBD OpenRA.Primitives.Rectangle::get_Bottom
        // IL_007E: br.s IL_008B
        // IL_0080: ldarg.0 0
        // IL_0081: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_0086: call 0x06000BBC OpenRA.Primitives.Rectangle::get_Top
        // IL_008B: stloc.s 5
        // IL_008D: ldloc.s 4
        // IL_008F: ldloc.3 3
        // IL_0090: ldfld 0x0400031F OpenRA.PPos::U
        // IL_0095: sub 
        // IL_0096: call 0x0A000117 [System.Runtime]System.Math::Abs
        // IL_009B: stloc.s 6
        // IL_009D: ldloc.s 5
        // IL_009F: ldloc.3 3
        // IL_00A0: ldfld 0x04000320 OpenRA.PPos::V
        // IL_00A5: sub 
        // IL_00A6: call 0x0A000117 [System.Runtime]System.Math::Abs
        // IL_00AB: stloc.s 7
        // IL_00AD: ldloc.s 6
        // IL_00AF: ldloc.s 7
        // IL_00B1: blt.s IL_00C2
        // IL_00B3: ldloc.3 3
        // IL_00B4: ldfld 0x0400031F OpenRA.PPos::U
        // IL_00B9: ldloc.s 5
        // IL_00BB: newobj 0x0600042C OpenRA.PPos::.ctor
        // IL_00C0: br.s IL_00CF
        // IL_00C2: ldloc.s 4
        // IL_00C4: ldloc.3 3
        // IL_00C5: ldfld 0x04000320 OpenRA.PPos::V
        // IL_00CA: newobj 0x0600042C OpenRA.PPos::.ctor
        // IL_00CF: stloc.1 1
        // IL_00D0: br.s IL_00EF
        // IL_00D2: ldloca.s 1
        // IL_00D4: ldarg.0 0
        // IL_00D5: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_00DA: call 0x06000BBA OpenRA.Primitives.Rectangle::get_Left
        // IL_00DF: ldarg.0 0
        // IL_00E0: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_00E5: call 0x06000BBC OpenRA.Primitives.Rectangle::get_Top
        // IL_00EA: call 0x0600042C OpenRA.PPos::.ctor
        // IL_00EF: ldarg.0 0
        // IL_00F0: ldloc.1 1
        // IL_00F1: call 0x0600032C OpenRA.Map::Unproject
        // IL_00F6: stloc.2 2
        // IL_00F7: ldloc.2 2
        // IL_00F8: callvirt 0x0A000374 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>::get_Count
        // IL_00FD: brtrue IL_019B
        // IL_0102: ldc.i4.2 2
        // IL_0103: stloc.s 8
        // IL_0105: br.s IL_0151
        // IL_0107: ldloc.s 8
        // IL_0109: ldc.i4.1 1
        // IL_010A: and 
        // IL_010B: ldc.i4.1 1
        // IL_010C: beq.s IL_0111
        // IL_010E: ldc.i4.m1 -1
        // IL_010F: br.s IL_0112
        // IL_0111: ldc.i4.1 1
        // IL_0112: ldloc.s 8
        // IL_0114: mul 
        // IL_0115: ldc.i4.2 2
        // IL_0116: div 
        // IL_0117: stloc.s 9
        // IL_0119: ldloca.s 10
        // IL_011B: ldloc.1 1
        // IL_011C: ldfld 0x0400031F OpenRA.PPos::U
        // IL_0121: ldloc.1 1
        // IL_0122: ldfld 0x04000320 OpenRA.PPos::V
        // IL_0127: ldloc.s 9
        // IL_0129: add 
        // IL_012A: call 0x0600042C OpenRA.PPos::.ctor
        // IL_012F: ldarg.0 0
        // IL_0130: ldloc.s 10
        // IL_0132: call 0x06000322 OpenRA.Map::Contains
        // IL_0137: brfalse.s IL_014B
        // IL_0139: ldarg.0 0
        // IL_013A: ldloc.s 10
        // IL_013C: call 0x0600032C OpenRA.Map::Unproject
        // IL_0141: stloc.2 2
        // IL_0142: ldloc.2 2
        // IL_0143: callvirt 0x0A000374 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>::get_Count
        // IL_0148: ldc.i4.0 0
        // IL_0149: bgt.s IL_0162
        // IL_014B: ldloc.s 8
        // IL_014D: ldc.i4.1 1
        // IL_014E: add 
        // IL_014F: stloc.s 8
        // IL_0151: ldloc.s 8
        // IL_0153: ldc.i4.2 2
        // IL_0154: ldarg.0 0
        // IL_0155: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_015A: ldfld 0x0400029F OpenRA.MapGrid::MaximumTerrainHeight
        // IL_015F: mul 
        // IL_0160: ble.s IL_0107
        // IL_0162: ldloc.2 2
        // IL_0163: callvirt 0x0A000374 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>::get_Count
        // IL_0168: brtrue.s IL_019B
        // IL_016A: ldstr 0x7000061E [100, 101, 98, 117, 103] utf16-bytes=[64, 00, 65, 00, 62, 00, 75, 00, 67, 00] terminal-flag=Some(0)
        // IL_016F: ldloca.s 11
        // IL_0171: ldc.i4.s 41
        // IL_0173: ldc.i4.1 1
        // IL_0174: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0179: ldloca.s 11
        // IL_017B: ldstr 0x70004B2E [70, 97, 105, 108, 101, 100, 32, 116, 111, 32, 102, 105, 110, 100, 32, 99, 108, 111, 115, 101, 115, 116, 32, 101, 100, 103, 101, 32, 102, 111, 114, 32, 109, 97, 112, 32, 99, 101, 108, 108, 32] utf16-bytes=[46, 00, 61, 00, 69, 00, 6C, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 66, 00, 69, 00, 6E, 00, 64, 00, 20, 00, 63, 00, 6C, 00, 6F, 00, 73, 00, 65, 00, 73, 00, 74, 00, 20, 00, 65, 00, 64, 00, 67, 00, 65, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 6D, 00, 61, 00, 70, 00, 20, 00, 63, 00, 65, 00, 6C, 00, 6C, 00, 20, 00] terminal-flag=Some(0)
        // IL_0180: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0185: ldloca.s 11
        // IL_0187: ldarg.1 1
        // IL_0188: call 0x2B0000B1 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<valuetype OpenRA.MPos>
        // IL_018D: ldloca.s 11
        // IL_018F: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0194: call 0x060005C4 OpenRA.Log::Write
        // IL_0199: ldarg.1 1
        // IL_019A: ret 
        // IL_019B: ldloc.1 1
        // IL_019C: ldfld 0x04000320 OpenRA.PPos::V
        // IL_01A1: ldarg.0 0
        // IL_01A2: ldflda 0x0400024E OpenRA.Map::Bounds
        // IL_01A7: call 0x06000BBD OpenRA.Primitives.Rectangle::get_Bottom
        // IL_01AC: beq.s IL_01D4
        // IL_01AE: ldloc.2 2
        // IL_01AF: ldsfld 0x04000A2A OpenRA.Map/<>c::<>9__150_1
        // IL_01B4: dup 
        // IL_01B5: brtrue.s IL_01CE
        // IL_01B7: pop 
        // IL_01B8: ldsfld 0x04000A1F OpenRA.Map/<>c::<>9
        // IL_01BD: ldftn 0x0600104F OpenRA.Map/<>c::<ChooseClosestEdgeCell>b__150_1
        // IL_01C3: newobj 0x0A000375 class [System.Runtime]System.Func`2<valuetype OpenRA.MPos, int32>::.ctor
        // IL_01C8: dup 
        // IL_01C9: stsfld 0x04000A2A OpenRA.Map/<>c::<>9__150_1
        // IL_01CE: call 0x2B0000AD OpenRA.Exts::MinBy<valuetype OpenRA.MPos, int32>
        // IL_01D3: ret 
        // IL_01D4: ldloc.2 2
        // IL_01D5: ldsfld 0x04000A29 OpenRA.Map/<>c::<>9__150_0
        // IL_01DA: dup 
        // IL_01DB: brtrue.s IL_01F4
        // IL_01DD: pop 
        // IL_01DE: ldsfld 0x04000A1F OpenRA.Map/<>c::<>9
        // IL_01E3: ldftn 0x0600104E OpenRA.Map/<>c::<ChooseClosestEdgeCell>b__150_0
        // IL_01E9: newobj 0x0A000375 class [System.Runtime]System.Func`2<valuetype OpenRA.MPos, int32>::.ctor
        // IL_01EE: dup 
        // IL_01EF: stsfld 0x04000A29 OpenRA.Map/<>c::<>9__150_0
        // IL_01F4: call 0x2B0000A5 OpenRA.Exts::MaxBy<valuetype OpenRA.MPos, int32>
        // IL_01F9: ret 
    }

    public OpenRA.CPos ChooseClosestMatchingEdgeCell(OpenRA.CPos cell, System.Func<OpenRA.CPos, bool> match)
    {
        // structural signature __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 bytes=1512809D011124: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_d1691f4089c3e5687c6115fbc860ca02f01171d6 bytes=151280C902112402: class [System.Runtime]System.Func`2<valuetype OpenRA.CPos, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_19e5b3a2fb3a68ee79040d7ae76ed33e9b23c854 bytes=151280C902112408: class [System.Runtime]System.Func`2<valuetype OpenRA.CPos, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_67f823354d0ba68522054fc40647ce206e6b1320 bytes=15128085011124: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ac11cbca856e43067e4e01b48b48cd6cacab8840 bytes=151283D5011124: class [System.Linq]System.Linq.IOrderedEnumerable`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135315F30 v0 = __cil_newobj_0600105C();
        v0.cell = cell;
        v0.match = match;
        // Exact call 0x0600030B kept: property source signature requires exact type identities.
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v6 = __cil_direct_0600030B(this);
        nint v8 = __cil_ldftn_0600105D;
        __cil_ref_19e5b3a2fb3a68ee79040d7ae76ed33e9b23c854 v9 = __cil_newobj_0A000397(v0, v8);
        __cil_ref_ac11cbca856e43067e4e01b48b48cd6cacab8840 v10 = __cil_methodspec_call_2B0000B3(((__cil_ref_67f823354d0ba68522054fc40647ce206e6b1320)(v6)), v9);
        nint v12 = __cil_ldftn_0600105E;
        __cil_ref_d1691f4089c3e5687c6115fbc860ca02f01171d6 v13 = __cil_newobj_0A000399(v0, v12);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v14 = __cil_methodspec_call_2B0000B4(((__cil_ref_67f823354d0ba68522054fc40647ce206e6b1320)(v10)), v13);
        return v14;
    }

    private System.Collections.Generic.List<OpenRA.CPos> UpdateEdgeCells()
    {
        // structural signature __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 bytes=1512809D011124: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 bytes=1512809D01118220: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e bytes=151280C90211822008: class [System.Runtime]System.Func`2<valuetype OpenRA.MPos, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4 bytes=1512808501118220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.MPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006B alias=__cil_enum_0200006B underlying=int: global::@OpenRA.@MapGridType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 l0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 l1 = default;
        int l2 = default;
        int l3 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 l4 = default;
        int l5 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s3_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s3_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s3_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s4_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s4_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s4_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s7_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s7_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s7_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s8_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s8_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s8_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s14_0 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s15_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s15_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s15_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s16_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s16_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s16_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s17_0 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s18_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s18_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s18_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s19_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s19_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s19_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s20_0 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 s20_1 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s23_0 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s24_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s24_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s24_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s25_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s25_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s25_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s26_0 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s27_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s27_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s27_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s28_0 = default;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 s28_1 = default;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e s28_2 = default;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 s29_0 = default;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 s29_1 = default;
        IL_0000: ;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v0 = __cil_newobj_0A00039A();
        l0 = v0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v1 = __cil_newobj_0A000391();
        l1 = v1;
        global::OpenRA.Map v2 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v3 = ref v2.Bounds;
        int v4 = __cil_direct_06000BBD(ref v3);
        int v5 = 1;
        int v6 = unchecked(v4 - v5);
        l2 = v6;
        global::OpenRA.Map v7 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v8 = ref v7.Bounds;
        int v9 = __cil_direct_06000BBA(ref v8);
        l3 = v9;
        goto IL_00E5;
        IL_002B: ;
        global::OpenRA.Map v10 = this;
        int v11 = l3;
        global::OpenRA.Map v12 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v13 = ref v12.Bounds;
        int v14 = __cil_direct_06000BBC(ref v13);
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v15 = __cil_value_newobj_0600042C(v11, v14);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v16 = __cil_direct_0600032C(v10, v15);
        l1 = v16;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v17 = l1;
        int v18 = __cil_callvirt_0A000374(v17);
        int v19 = 0;
        if (v18 <= v19) {
            goto IL_008B;
        } else {
            goto IL_004C;
        }
        IL_004C: ;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v20 = l0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v21 = l1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v22 = OpenRA.Map.__name_3C3E63.__il_field_04000A2B;
        if (v22 is not null) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e2_4_0 = v20;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e2_4_1 = v21;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e2_4_2 = v22;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            s4_2 = e2_4_2;
            goto IL_006D;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e2_3_0 = v20;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e2_3_1 = v21;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e2_3_2 = v22;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            s3_2 = e2_3_2;
            goto IL_0056;
        }
        IL_0056: ;
        global::OpenRA.Map.__name_3C3E63 v23 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v24 = __cil_ldftn_06001050;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v25 = __cil_newobj_0A000375(v23, v24);
        OpenRA.Map.__name_3C3E63.__il_field_04000A2B = v25;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e3_4_0 = s3_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e3_4_1 = s3_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e3_4_2 = v25;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        s4_2 = e3_4_2;
        goto IL_006D;
        IL_006D: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v26 = __cil_methodspec_call_2B0000AD(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s4_1)), s4_2);
        l4 = v26;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v27 = ref l4;
        global::OpenRA.Map v28 = this;
        global::OpenRA.MapGrid v29 = v28.Grid;
        int v30 = unchecked((int)(v29.Type));
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v31 = __cil_direct_0600042A(ref v27, unchecked((__cil_enum_0200006B)(v30)));
        __cil_callvirt_0A00039B(s4_0, v31);
        goto IL_008B;
        IL_008B: ;
        global::OpenRA.Map v32 = this;
        int v33 = l3;
        int v34 = l2;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v35 = __cil_value_newobj_0600042C(v33, v34);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v36 = __cil_direct_0600032C(v32, v35);
        l1 = v36;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v37 = l1;
        int v38 = __cil_callvirt_0A000374(v37);
        int v39 = 0;
        if (v38 <= v39) {
            goto IL_00E1;
        } else {
            goto IL_00A2;
        }
        IL_00A2: ;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v40 = l0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v41 = l1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v42 = OpenRA.Map.__name_3C3E63.__il_field_04000A2C;
        if (v42 is not null) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e6_8_0 = v40;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e6_8_1 = v41;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e6_8_2 = v42;
            s8_0 = e6_8_0;
            s8_1 = e6_8_1;
            s8_2 = e6_8_2;
            goto IL_00C3;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e6_7_0 = v40;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e6_7_1 = v41;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e6_7_2 = v42;
            s7_0 = e6_7_0;
            s7_1 = e6_7_1;
            s7_2 = e6_7_2;
            goto IL_00AC;
        }
        IL_00AC: ;
        global::OpenRA.Map.__name_3C3E63 v43 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v44 = __cil_ldftn_06001051;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v45 = __cil_newobj_0A000375(v43, v44);
        OpenRA.Map.__name_3C3E63.__il_field_04000A2C = v45;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e7_8_0 = s7_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e7_8_1 = s7_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e7_8_2 = v45;
        s8_0 = e7_8_0;
        s8_1 = e7_8_1;
        s8_2 = e7_8_2;
        goto IL_00C3;
        IL_00C3: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v46 = __cil_methodspec_call_2B0000A5(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s8_1)), s8_2);
        l4 = v46;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v47 = ref l4;
        global::OpenRA.Map v48 = this;
        global::OpenRA.MapGrid v49 = v48.Grid;
        int v50 = unchecked((int)(v49.Type));
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v51 = __cil_direct_0600042A(ref v47, unchecked((__cil_enum_0200006B)(v50)));
        __cil_callvirt_0A00039B(s8_0, v51);
        goto IL_00E1;
        IL_00E1: ;
        int v52 = l3;
        int v53 = 1;
        int v54 = unchecked(v52 + v53);
        l3 = v54;
        goto IL_00E5;
        IL_00E5: ;
        int v55 = l3;
        global::OpenRA.Map v56 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v57 = ref v56.Bounds;
        int v58 = __cil_direct_06000BBB(ref v57);
        if (v55 < v58) {
            goto IL_002B;
        } else {
            goto IL_00F6;
        }
        IL_00F6: ;
        global::OpenRA.Map v59 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v60 = ref v59.Bounds;
        int v61 = __cil_direct_06000BBC(ref v60);
        l5 = v61;
        goto IL_022A;
        IL_0108: ;
        global::OpenRA.Map v62 = this;
        global::OpenRA.Map v63 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v64 = ref v63.Bounds;
        int v65 = __cil_direct_06000BBA(ref v64);
        int v66 = l5;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v67 = __cil_value_newobj_0600042C(v65, v66);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v68 = __cil_direct_0600032C(v62, v67);
        l1 = v68;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v69 = l1;
        int v70 = __cil_callvirt_0A000374(v69);
        int v71 = 0;
        if (v70 <= v71) {
            goto IL_0195;
        } else {
            goto IL_012A;
        }
        IL_012A: ;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v72 = l0;
        int v73 = l5;
        int v74 = l2;
        if (v73 == v74) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e13_17_0 = v72;
            s17_0 = e13_17_0;
            goto IL_0157;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e13_14_0 = v72;
            s14_0 = e13_14_0;
            goto IL_0130;
        }
        IL_0130: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v75 = l1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v76 = OpenRA.Map.__name_3C3E63.__il_field_04000A2E;
        if (v76 is not null) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e14_16_0 = s14_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e14_16_1 = v75;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e14_16_2 = v76;
            s16_0 = e14_16_0;
            s16_1 = e14_16_1;
            s16_2 = e14_16_2;
            goto IL_0150;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e14_15_0 = s14_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e14_15_1 = v75;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e14_15_2 = v76;
            s15_0 = e14_15_0;
            s15_1 = e14_15_1;
            s15_2 = e14_15_2;
            goto IL_0139;
        }
        IL_0139: ;
        global::OpenRA.Map.__name_3C3E63 v77 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v78 = __cil_ldftn_06001053;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v79 = __cil_newobj_0A000375(v77, v78);
        OpenRA.Map.__name_3C3E63.__il_field_04000A2E = v79;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e15_16_0 = s15_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e15_16_1 = s15_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e15_16_2 = v79;
        s16_0 = e15_16_0;
        s16_1 = e15_16_1;
        s16_2 = e15_16_2;
        goto IL_0150;
        IL_0150: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v80 = __cil_methodspec_call_2B0000AD(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s16_1)), s16_2);
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e16_20_0 = s16_0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e16_20_1 = v80;
        s20_0 = e16_20_0;
        s20_1 = e16_20_1;
        goto IL_017C;
        IL_0157: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v81 = l1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v82 = OpenRA.Map.__name_3C3E63.__il_field_04000A2D;
        if (v82 is not null) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e17_19_0 = s17_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e17_19_1 = v81;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e17_19_2 = v82;
            s19_0 = e17_19_0;
            s19_1 = e17_19_1;
            s19_2 = e17_19_2;
            goto IL_0177;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e17_18_0 = s17_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e17_18_1 = v81;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e17_18_2 = v82;
            s18_0 = e17_18_0;
            s18_1 = e17_18_1;
            s18_2 = e17_18_2;
            goto IL_0160;
        }
        IL_0160: ;
        global::OpenRA.Map.__name_3C3E63 v83 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v84 = __cil_ldftn_06001052;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v85 = __cil_newobj_0A000375(v83, v84);
        OpenRA.Map.__name_3C3E63.__il_field_04000A2D = v85;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e18_19_0 = s18_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e18_19_1 = s18_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e18_19_2 = v85;
        s19_0 = e18_19_0;
        s19_1 = e18_19_1;
        s19_2 = e18_19_2;
        goto IL_0177;
        IL_0177: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v86 = __cil_methodspec_call_2B0000A5(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s19_1)), s19_2);
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e19_20_0 = s19_0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e19_20_1 = v86;
        s20_0 = e19_20_0;
        s20_1 = e19_20_1;
        goto IL_017C;
        IL_017C: ;
        l4 = s20_1;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v87 = ref l4;
        global::OpenRA.Map v88 = this;
        global::OpenRA.MapGrid v89 = v88.Grid;
        int v90 = unchecked((int)(v89.Type));
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v91 = __cil_direct_0600042A(ref v87, unchecked((__cil_enum_0200006B)(v90)));
        __cil_callvirt_0A00039B(s20_0, v91);
        goto IL_0195;
        IL_0195: ;
        global::OpenRA.Map v92 = this;
        global::OpenRA.Map v93 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v94 = ref v93.Bounds;
        int v95 = __cil_direct_06000BBB(ref v94);
        int v96 = 1;
        int v97 = unchecked(v95 - v96);
        int v98 = l5;
        __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 v99 = __cil_value_newobj_0600042C(v97, v98);
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v100 = __cil_direct_0600032C(v92, v99);
        l1 = v100;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v101 = l1;
        int v102 = __cil_callvirt_0A000374(v101);
        int v103 = 0;
        if (v102 <= v103) {
            goto IL_0224;
        } else {
            goto IL_01B9;
        }
        IL_01B9: ;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v104 = l0;
        int v105 = l5;
        int v106 = l2;
        if (v105 == v106) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e22_26_0 = v104;
            s26_0 = e22_26_0;
            goto IL_01E6;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e22_23_0 = v104;
            s23_0 = e22_23_0;
            goto IL_01BF;
        }
        IL_01BF: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v107 = l1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v108 = OpenRA.Map.__name_3C3E63.__il_field_04000A30;
        if (v108 is not null) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e23_25_0 = s23_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e23_25_1 = v107;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e23_25_2 = v108;
            s25_0 = e23_25_0;
            s25_1 = e23_25_1;
            s25_2 = e23_25_2;
            goto IL_01DF;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e23_24_0 = s23_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e23_24_1 = v107;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e23_24_2 = v108;
            s24_0 = e23_24_0;
            s24_1 = e23_24_1;
            s24_2 = e23_24_2;
            goto IL_01C8;
        }
        IL_01C8: ;
        global::OpenRA.Map.__name_3C3E63 v109 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v110 = __cil_ldftn_06001055;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v111 = __cil_newobj_0A000375(v109, v110);
        OpenRA.Map.__name_3C3E63.__il_field_04000A30 = v111;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e24_25_0 = s24_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e24_25_1 = s24_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e24_25_2 = v111;
        s25_0 = e24_25_0;
        s25_1 = e24_25_1;
        s25_2 = e24_25_2;
        goto IL_01DF;
        IL_01DF: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v112 = __cil_methodspec_call_2B0000AD(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s25_1)), s25_2);
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e25_29_0 = s25_0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e25_29_1 = v112;
        s29_0 = e25_29_0;
        s29_1 = e25_29_1;
        goto IL_020B;
        IL_01E6: ;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 v113 = l1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v114 = OpenRA.Map.__name_3C3E63.__il_field_04000A2F;
        if (v114 is not null) {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e26_28_0 = s26_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e26_28_1 = v113;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e26_28_2 = v114;
            s28_0 = e26_28_0;
            s28_1 = e26_28_1;
            s28_2 = e26_28_2;
            goto IL_0206;
        } else {
            __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e26_27_0 = s26_0;
            __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e26_27_1 = v113;
            __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e26_27_2 = v114;
            s27_0 = e26_27_0;
            s27_1 = e26_27_1;
            s27_2 = e26_27_2;
            goto IL_01EF;
        }
        IL_01EF: ;
        global::OpenRA.Map.__name_3C3E63 v115 = OpenRA.Map.__name_3C3E63.__il_field_04000A1F;
        nint v116 = __cil_ldftn_06001054;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e v117 = __cil_newobj_0A000375(v115, v116);
        OpenRA.Map.__name_3C3E63.__il_field_04000A2F = v117;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e27_28_0 = s27_0;
        __cil_ref_8a9e9e9dd97483ade5f1e19bbebe0f7414e58b51 e27_28_1 = s27_1;
        __cil_ref_e5c6b9fd36e2da693e9c44c1cf81ad3a46ec890e e27_28_2 = v117;
        s28_0 = e27_28_0;
        s28_1 = e27_28_1;
        s28_2 = e27_28_2;
        goto IL_0206;
        IL_0206: ;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v118 = __cil_methodspec_call_2B0000A5(((__cil_ref_24a3ac8fe67b291ddf3d28d3807dc05a980b9fa4)(s28_1)), s28_2);
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 e28_29_0 = s28_0;
        __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 e28_29_1 = v118;
        s29_0 = e28_29_0;
        s29_1 = e28_29_1;
        goto IL_020B;
        IL_020B: ;
        l4 = s29_1;
        ref __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v119 = ref l4;
        global::OpenRA.Map v120 = this;
        global::OpenRA.MapGrid v121 = v120.Grid;
        int v122 = unchecked((int)(v121.Type));
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v123 = __cil_direct_0600042A(ref v119, unchecked((__cil_enum_0200006B)(v122)));
        __cil_callvirt_0A00039B(s29_0, v123);
        goto IL_0224;
        IL_0224: ;
        int v124 = l5;
        int v125 = 1;
        int v126 = unchecked(v124 + v125);
        l5 = v126;
        goto IL_022A;
        IL_022A: ;
        int v127 = l5;
        global::OpenRA.Map v128 = this;
        ref __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v129 = ref v128.Bounds;
        int v130 = __cil_direct_06000BBD(ref v129);
        if (v127 < v130) {
            goto IL_0108;
        } else {
            goto IL_023C;
        }
        IL_023C: ;
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v131 = l0;
        return v131;
    }

    public OpenRA.CPos ChooseRandomEdgeCell(OpenRA.Support.MersenneTwister rand)
    {
        // structural signature __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 bytes=1512809D011124: class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_67f823354d0ba68522054fc40647ce206e6b1320 bytes=15128085011124: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // Exact call 0x0600030B kept: property source signature requires exact type identities.
        __cil_ref_498f09b18b3f7956d06530f4706993ee72006bf6 v1 = __cil_direct_0600030B(this);
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v3 = __cil_methodspec_call_2B0000B5(((__cil_ref_67f823354d0ba68522054fc40647ce206e6b1320)(v1)), rand);
        return v3;
    }

    public OpenRA.WDist DistanceToEdge(OpenRA.WPos pos, ref OpenRA.WVec dir)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 bytes=118344: valuetype OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd bytes=11831C: valuetype OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d l0 = default;
        int l1 = default;
        int l2 = default;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 l3 = default;
        int s4_0 = default;
        int s6_0 = default;
        int s10_0 = default;
        int s12_0 = default;
        IL_0000: ;
        ref __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v0 = ref pos;
        int v1 = 0;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v2 = pos;
        int v3 = v2.Z;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v4 = pos;
        int v5 = v4.Z;
        __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v6 = __cil_value_newobj_060006DD(v1, v3, v5);
        l3 = v6;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v7 = ref l3;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v8 = OpenRA.WPos.op_Subtraction(ref v0, ref v7);
        l0 = v8;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v9 = ref dir;
        int v10 = v9.X;
        if (v10 == 0) {
            goto IL_0056;
        } else {
            goto IL_0025;
        }
        IL_0025: ;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v11 = ref dir;
        int v12 = v11.X;
        int v13 = 0;
        if (v12 < v13) {
            goto IL_003B;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        global::OpenRA.Map v14 = this;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v15 = __cil_direct_060002FB(v14);
        int v16 = v15.X;
        int e2_4_0 = v16;
        s4_0 = e2_4_0;
        goto IL_0046;
        IL_003B: ;
        global::OpenRA.Map v17 = this;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v18 = __cil_direct_060002F9(v17);
        int v19 = v18.X;
        int e3_4_0 = v19;
        s4_0 = e3_4_0;
        goto IL_0046;
        IL_0046: ;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v20 = l0;
        int v21 = v20.X;
        int v22 = unchecked(s4_0 - v21);
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v23 = ref dir;
        int v24 = v23.X;
        int v25 = unchecked(v22 / v24);
        int e4_6_0 = v25;
        s6_0 = e4_6_0;
        goto IL_005B;
        IL_0056: ;
        int v26 = 2147483647;
        int e5_6_0 = v26;
        s6_0 = e5_6_0;
        goto IL_005B;
        IL_005B: ;
        l1 = s6_0;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v27 = ref dir;
        int v28 = v27.Y;
        if (v28 == 0) {
            goto IL_0095;
        } else {
            goto IL_0064;
        }
        IL_0064: ;
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v29 = ref dir;
        int v30 = v29.Y;
        int v31 = 0;
        if (v30 < v31) {
            goto IL_007A;
        } else {
            goto IL_006D;
        }
        IL_006D: ;
        global::OpenRA.Map v32 = this;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v33 = __cil_direct_060002FB(v32);
        int v34 = v33.Y;
        int e8_10_0 = v34;
        s10_0 = e8_10_0;
        goto IL_0085;
        IL_007A: ;
        global::OpenRA.Map v35 = this;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v36 = __cil_direct_060002F9(v35);
        int v37 = v36.Y;
        int e9_10_0 = v37;
        s10_0 = e9_10_0;
        goto IL_0085;
        IL_0085: ;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v38 = l0;
        int v39 = v38.Y;
        int v40 = unchecked(s10_0 - v39);
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v41 = ref dir;
        int v42 = v41.Y;
        int v43 = unchecked(v40 / v42);
        int e10_12_0 = v43;
        s12_0 = e10_12_0;
        goto IL_009A;
        IL_0095: ;
        int v44 = 2147483647;
        int e11_12_0 = v44;
        s12_0 = e11_12_0;
        goto IL_009A;
        IL_009A: ;
        l2 = s12_0;
        int v45 = l1;
        int v46 = l2;
        int v47 = System.Math.Min(v45, v46);
        ref __cil_value_ae4dafeeab15f3d459af8994a19eb4f238f86a21 v48 = ref dir;
        int v49 = __cil_direct_060006E9(ref v48);
        int v50 = unchecked(v47 * v49);
        __cil_value_d619f246591f9d39f51160ea318c5bbd43a77cfd v51 = __cil_value_newobj_06000628(v50);
        return v51;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.CPos> FindTilesInAnnulus(OpenRA.CPos center, int minRange, int maxRange, bool allowOutsideBounds = false)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [73, 5F, 10, 00, 06, 0A, 06, 04, 7D, 38, 0A, 00, 04, 06, 02, 7D, 39, 0A, 00, 04, 06, 03, 7D, 3A]
        // .code-bytes IL_0018: [0A, 00, 04, 06, 0E, 04, 7D, 3B, 0A, 00, 04, 06, 05, 7D, 3C, 0A, 00, 04, 06, 7B, 3C, 0A, 00, 04]
        // .code-bytes IL_0030: [06, 7B, 38, 0A, 00, 04, 2F, 10, 72, 82, 4B, 00, 70, 72, 94, 4B, 00, 70, 73, 9C, 03, 00, 0A, 7A]
        // .code-bytes IL_0048: [06, 7B, 3C, 0A, 00, 04, 02, 7B, 5D, 02, 00, 04, 7B, A5, 02, 00, 04, 8E, 69, 32, 5F, 72, 82, 4B]
        // .code-bytes IL_0060: [00, 70, 12, 01, 1F, 4B, 18, 28, C4, 00, 00, 0A, 12, 01, 72, F0, 4B, 00, 70, 28, C5, 00, 00, 0A]
        // .code-bytes IL_0078: [12, 01, 06, 7B, 3C, 0A, 00, 04, 28, 13, 00, 00, 2B, 12, 01, 72, 1C, 4C, 00, 70, 28, C5, 00, 00]
        // .code-bytes IL_0090: [0A, 12, 01, 02, 7B, 5D, 02, 00, 04, 7B, A1, 02, 00, 04, 28, 13, 00, 00, 2B, 12, 01, 72, 9F, 03]
        // .code-bytes IL_00A8: [00, 70, 28, C5, 00, 00, 0A, 12, 01, 28, C7, 00, 00, 0A, 73, 9C, 03, 00, 0A, 7A, 06, 6F, 60, 10]
        // .code-bytes IL_00C0: [00, 06, 2A]
        // .local [0] class OpenRA.Map/<>c__DisplayClass155_0
        // .local [1] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: newobj 0x0600105F OpenRA.Map/<>c__DisplayClass155_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.2 2
        // IL_0008: stfld 0x04000A38 OpenRA.Map/<>c__DisplayClass155_0::minRange
        // IL_000D: ldloc.0 0
        // IL_000E: ldarg.0 0
        // IL_000F: stfld 0x04000A39 OpenRA.Map/<>c__DisplayClass155_0::<>4__this
        // IL_0014: ldloc.0 0
        // IL_0015: ldarg.1 1
        // IL_0016: stfld 0x04000A3A OpenRA.Map/<>c__DisplayClass155_0::center
        // IL_001B: ldloc.0 0
        // IL_001C: ldarg.s 4
        // IL_001E: stfld 0x04000A3B OpenRA.Map/<>c__DisplayClass155_0::allowOutsideBounds
        // IL_0023: ldloc.0 0
        // IL_0024: ldarg.3 3
        // IL_0025: stfld 0x04000A3C OpenRA.Map/<>c__DisplayClass155_0::maxRange
        // IL_002A: ldloc.0 0
        // IL_002B: ldfld 0x04000A3C OpenRA.Map/<>c__DisplayClass155_0::maxRange
        // IL_0030: ldloc.0 0
        // IL_0031: ldfld 0x04000A38 OpenRA.Map/<>c__DisplayClass155_0::minRange
        // IL_0036: bge.s IL_0048
        // IL_0038: ldstr 0x70004B82 [109, 97, 120, 82, 97, 110, 103, 101] utf16-bytes=[6D, 00, 61, 00, 78, 00, 52, 00, 61, 00, 6E, 00, 67, 00, 65, 00] terminal-flag=Some(0)
        // IL_003D: ldstr 0x70004B94 [77, 97, 120, 105, 109, 117, 109, 32, 114, 97, 110, 103, 101, 32, 105, 115, 32, 108, 101, 115, 115, 32, 116, 104, 97, 110, 32, 116, 104, 101, 32, 109, 105, 110, 105, 109, 117, 109, 32, 114, 97, 110, 103, 101, 46] utf16-bytes=[4D, 00, 61, 00, 78, 00, 69, 00, 6D, 00, 75, 00, 6D, 00, 20, 00, 72, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 20, 00, 69, 00, 73, 00, 20, 00, 6C, 00, 65, 00, 73, 00, 73, 00, 20, 00, 74, 00, 68, 00, 61, 00, 6E, 00, 20, 00, 74, 00, 68, 00, 65, 00, 20, 00, 6D, 00, 69, 00, 6E, 00, 69, 00, 6D, 00, 75, 00, 6D, 00, 20, 00, 72, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 2E, 00] terminal-flag=Some(0)
        // IL_0042: newobj 0x0A00039C [System.Runtime]System.ArgumentOutOfRangeException::.ctor
        // IL_0047: throw 
        // IL_0048: ldloc.0 0
        // IL_0049: ldfld 0x04000A3C OpenRA.Map/<>c__DisplayClass155_0::maxRange
        // IL_004E: ldarg.0 0
        // IL_004F: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_0054: ldfld 0x040002A5 OpenRA.MapGrid::TilesByDistance
        // IL_0059: ldlen 
        // IL_005A: conv.i4 
        // IL_005B: blt.s IL_00BC
        // IL_005D: ldstr 0x70004B82 [109, 97, 120, 82, 97, 110, 103, 101] utf16-bytes=[6D, 00, 61, 00, 78, 00, 52, 00, 61, 00, 6E, 00, 67, 00, 65, 00] terminal-flag=Some(0)
        // IL_0062: ldloca.s 1
        // IL_0064: ldc.i4.s 75
        // IL_0066: ldc.i4.2 2
        // IL_0067: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_006C: ldloca.s 1
        // IL_006E: ldstr 0x70004BF0 [84, 104, 101, 32, 114, 101, 113, 117, 101, 115, 116, 101, 100, 32, 114, 97, 110, 103, 101, 32, 40] utf16-bytes=[54, 00, 68, 00, 65, 00, 20, 00, 72, 00, 65, 00, 71, 00, 75, 00, 65, 00, 73, 00, 74, 00, 65, 00, 64, 00, 20, 00, 72, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 20, 00, 28, 00] terminal-flag=Some(0)
        // IL_0073: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0078: ldloca.s 1
        // IL_007A: ldloc.0 0
        // IL_007B: ldfld 0x04000A3C OpenRA.Map/<>c__DisplayClass155_0::maxRange
        // IL_0080: call 0x2B000013 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_0085: ldloca.s 1
        // IL_0087: ldstr 0x70004C1C [41, 32, 99, 97, 110, 110, 111, 116, 32, 101, 120, 99, 101, 101, 100, 32, 116, 104, 101, 32, 118, 97, 108, 117, 101, 32, 111, 102, 32, 77, 97, 120, 105, 109, 117, 109, 84, 105, 108, 101, 83, 101, 97, 114, 99, 104, 82, 97, 110, 103, 101, 32, 40] utf16-bytes=[29, 00, 20, 00, 63, 00, 61, 00, 6E, 00, 6E, 00, 6F, 00, 74, 00, 20, 00, 65, 00, 78, 00, 63, 00, 65, 00, 65, 00, 64, 00, 20, 00, 74, 00, 68, 00, 65, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 6F, 00, 66, 00, 20, 00, 4D, 00, 61, 00, 78, 00, 69, 00, 6D, 00, 75, 00, 6D, 00, 54, 00, 69, 00, 6C, 00, 65, 00, 53, 00, 65, 00, 61, 00, 72, 00, 63, 00, 68, 00, 52, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 20, 00, 28, 00] terminal-flag=Some(0)
        // IL_008C: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0091: ldloca.s 1
        // IL_0093: ldarg.0 0
        // IL_0094: ldfld 0x0400025D OpenRA.Map::Grid
        // IL_0099: ldfld 0x040002A1 OpenRA.MapGrid::MaximumTileSearchRange
        // IL_009E: call 0x2B000013 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_00A3: ldloca.s 1
        // IL_00A5: ldstr 0x7000039F [41] utf16-bytes=[29, 00] terminal-flag=Some(0)
        // IL_00AA: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_00AF: ldloca.s 1
        // IL_00B1: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_00B6: newobj 0x0A00039C [System.Runtime]System.ArgumentOutOfRangeException::.ctor
        // IL_00BB: throw 
        // IL_00BC: ldloc.0 0
        // IL_00BD: callvirt 0x06001060 OpenRA.Map/<>c__DisplayClass155_0::<FindTilesInAnnulus>g__FindTilesInAnnulus|0
        // IL_00C2: ret 
    }

    public System.Collections.Generic.IEnumerable<OpenRA.CPos> FindTilesInCircle(OpenRA.CPos center, int maxRange, bool allowOutsideBounds = false)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_67f823354d0ba68522054fc40647ce206e6b1320 bytes=15128085011124: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v4 = __cil_bool_load(allowOutsideBounds);
        __cil_ref_67f823354d0ba68522054fc40647ce206e6b1320 v5 = __cil_direct_0600033D(this, center, 0, maxRange, __cil_bool_store(v4));
        return v5;
    }

    public virtual System.IO.Stream Open(string filename)
    {
        int v2 = __cil_bool_load(filename.Contains(unchecked((char)(124))));
        if (v2 != 0) {
            goto IL_0025;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::OpenRA.FileSystem.IReadOnlyPackage v4 = this.Package;
        int v6 = __cil_bool_load(__cil_callvirt_06000F05(v4, filename));
        if (v6 == 0) {
            goto IL_0025;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::OpenRA.FileSystem.IReadOnlyPackage v8 = this.Package;
        __cil_type_0100003C v10 = __cil_callvirt_06000F04(v8, filename);
        return v10;
        IL_0025: ;
        global::OpenRA.ModData v12 = this.modData;
        global::OpenRA.FileSystem.IReadOnlyFileSystem v13 = __cil_callvirt_0600040F(v12);
        __cil_type_0100003C v15 = __cil_callvirt_06000EE2(v13, filename);
        return v15;
    }

    public virtual bool TryGetPackageContaining(string path, out OpenRA.FileSystem.IReadOnlyPackage package, out string filename)
    {
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        global::OpenRA.ModData v1 = v0.modData;
        global::OpenRA.FileSystem.IReadOnlyFileSystem v2 = __cil_callvirt_0600040F(v1);
        string v3 = path;
        ref global::OpenRA.FileSystem.IReadOnlyPackage v4 = ref package;
        ref string v5 = ref filename;
        int v6 = __cil_bool_load(__cil_callvirt_06000EE3(v2, v3, ref v4, ref v5));
        return __cil_bool_store(v6);
    }

    public virtual bool TryOpen(string filename, out System.IO.Stream s)
    {
        IL_0000: ;
        string v0 = filename;
        int v1 = 124;
        int v2 = __cil_bool_load(v0.Contains(unchecked((char)(v1))));
        if (v2 != 0) {
            goto IL_001E;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref __cil_type_0100003C v3 = ref s;
        global::OpenRA.Map v4 = this;
        global::OpenRA.FileSystem.IReadOnlyPackage v5 = __cil_direct_060002ED(v4);
        string v6 = filename;
        __cil_type_0100003C v7 = __cil_callvirt_06000F04(v5, v6);
        v3 = v7;
        ref __cil_type_0100003C v8 = ref s;
        __cil_type_0100003C v9 = v8;
        if (v9 is null) {
            goto IL_001E;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        int v10 = 1;
        return __cil_bool_store(v10);
        IL_001E: ;
        global::OpenRA.Map v11 = this;
        global::OpenRA.ModData v12 = v11.modData;
        global::OpenRA.FileSystem.IReadOnlyFileSystem v13 = __cil_callvirt_0600040F(v12);
        string v14 = filename;
        ref __cil_type_0100003C v15 = ref s;
        int v16 = __cil_bool_load(__cil_callvirt_06000EE4(v13, v14, ref v15));
        return __cil_bool_store(v16);
    }

    public virtual bool Exists(string filename)
    {
        int v2 = __cil_bool_load(filename.Contains(unchecked((char)(124))));
        if (v2 != 0) {
            goto IL_001A;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::OpenRA.FileSystem.IReadOnlyPackage v4 = this.Package;
        int v6 = __cil_bool_load(__cil_callvirt_06000F05(v4, filename));
        if (v6 == 0) {
            goto IL_001A;
        } else {
            return true;
        }
        IL_001A: ;
        global::OpenRA.ModData v9 = this.modData;
        global::OpenRA.FileSystem.IReadOnlyFileSystem v10 = __cil_callvirt_0600040F(v9);
        return __cil_callvirt_06000EE5(v10, filename);
    }

    public virtual bool IsExternalFile(string filename)
    {
        int v2 = __cil_bool_load(filename.Contains(unchecked((char)(124))));
        if (v2 == 0) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::OpenRA.ModData v4 = this.modData;
        global::OpenRA.FileSystem.IReadOnlyFileSystem v5 = __cil_callvirt_0600040F(v4);
        return __cil_callvirt_06000EE6(v5, filename);
    }

    public virtual void Dispose()
    {
        global::OpenRA.Graphics.SequenceSet v1 = this.Sequences;
        __cil_callvirt_06000DC6(v1);
        return;
    }

    static Map()
    {
        // structural signature __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 bytes=1D118224: valuetype OpenRA.PPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_cde75719707a5c33439e7442f5014c6e79818f54 bytes=1D128198: class OpenRA.MapField[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_cde75719707a5c33439e7442f5014c6e79818f54 v1 = __cil_newarr_02000066(20);
        string v3 = __cil_ldstr_70004906("MapFormat");
        global::OpenRA.MapField v5 = __cil_newobj_060002E6(v3, null, 1, null);
        v1[0] = v5;
        string v7 = __cil_ldstr_70004C88("RequiresMod");
        global::OpenRA.MapField v9 = __cil_newobj_060002E6(v7, null, 1, null);
        v1[1] = v9;
        string v11 = __cil_ldstr_70004CA0("Title");
        global::OpenRA.MapField v13 = __cil_newobj_060002E6(v11, null, 1, null);
        v1[2] = v13;
        string v15 = __cil_ldstr_70004CAC("Author");
        global::OpenRA.MapField v17 = __cil_newobj_060002E6(v15, null, 1, null);
        v1[3] = v17;
        string v19 = __cil_ldstr_70004CBA("Tileset");
        global::OpenRA.MapField v21 = __cil_newobj_060002E6(v19, null, 1, null);
        v1[4] = v21;
        string v23 = __cil_ldstr_70004CCA("MapSize");
        global::OpenRA.MapField v25 = __cil_newobj_060002E6(v23, null, 1, null);
        v1[5] = v25;
        string v27 = __cil_ldstr_70004CDA("Bounds");
        global::OpenRA.MapField v29 = __cil_newobj_060002E6(v27, null, 1, null);
        v1[6] = v29;
        string v31 = __cil_ldstr_70004CE8("Visibility");
        global::OpenRA.MapField v33 = __cil_newobj_060002E6(v31, null, 1, null);
        v1[7] = v33;
        string v35 = __cil_ldstr_70004CFE("Categories");
        global::OpenRA.MapField v37 = __cil_newobj_060002E6(v35, null, 1, null);
        v1[8] = v37;
        string v39 = __cil_ldstr_70004D14("LockPreview");
        string v41 = __cil_ldstr_70004D2C("False");
        global::OpenRA.MapField v42 = __cil_newobj_060002E6(v39, null, 0, v41);
        v1[9] = v42;
        string v44 = __cil_ldstr_70004A34("Players");
        string v45 = __cil_ldstr_70004D38("PlayerDefinitions");
        global::OpenRA.MapField v47 = __cil_newobj_060002E6(v44, v45, 1, null);
        v1[10] = v47;
        string v49 = __cil_ldstr_70004A44("Actors");
        string v50 = __cil_ldstr_70004D5C("ActorDefinitions");
        global::OpenRA.MapField v52 = __cil_newobj_060002E6(v49, v50, 1, null);
        v1[11] = v52;
        string v54 = __cil_ldstr_70003EC0("Rules");
        string v55 = __cil_ldstr_70004D7E("RuleDefinitions");
        global::OpenRA.MapField v57 = __cil_newobj_060002E6(v54, v55, 0, null);
        v1[12] = v57;
        string v59 = __cil_ldstr_70003F92("FluentMessages");
        string v60 = __cil_ldstr_70004D9E("FluentMessageDefinitions");
        global::OpenRA.MapField v62 = __cil_newobj_060002E6(v59, v60, 0, null);
        v1[13] = v62;
        string v64 = __cil_ldstr_70003ECC("Sequences");
        string v65 = __cil_ldstr_70004DD0("SequenceDefinitions");
        global::OpenRA.MapField v67 = __cil_newobj_060002E6(v64, v65, 0, null);
        v1[14] = v67;
        string v69 = __cil_ldstr_70003EE0("ModelSequences");
        string v70 = __cil_ldstr_70004DF8("ModelSequenceDefinitions");
        global::OpenRA.MapField v72 = __cil_newobj_060002E6(v69, v70, 0, null);
        v1[15] = v72;
        string v74 = __cil_ldstr_70003F4C("Weapons");
        string v75 = __cil_ldstr_70004E2A("WeaponDefinitions");
        global::OpenRA.MapField v77 = __cil_newobj_060002E6(v74, v75, 0, null);
        v1[16] = v77;
        string v79 = __cil_ldstr_70003F5C("Voices");
        string v80 = __cil_ldstr_70004E4E("VoiceDefinitions");
        global::OpenRA.MapField v82 = __cil_newobj_060002E6(v79, v80, 0, null);
        v1[17] = v82;
        string v84 = __cil_ldstr_70003F86("Music");
        string v85 = __cil_ldstr_70004E70("MusicDefinitions");
        global::OpenRA.MapField v87 = __cil_newobj_060002E6(v84, v85, 0, null);
        v1[18] = v87;
        string v89 = __cil_ldstr_70003F6A("Notifications");
        string v90 = __cil_ldstr_70004E92("NotificationDefinitions");
        global::OpenRA.MapField v92 = __cil_newobj_060002E6(v89, v90, 0, null);
        v1[19] = v92;
        OpenRA.Map.YamlFields = v1;
        __cil_ref_9190b692fc27749994470ab2c91ed8de1f7fab10 v93 = __cil_methodspec_call_2B0000A4();
        OpenRA.Map.NoProjectedCells = v93;
        return;
    }

    private void __name_3C506F7374496E69743E675F5F496E76616C69646174655465727261696E496E6465787C3131325F30(OpenRA.CPos c)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 bytes=151281800106: class OpenRA.CellLayer`1<int16>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 v1 = this.cachedTerrainIndexes;
        if (v1 is null) {
            goto IL_0015;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        __cil_ref_aea1d2855f204d1626832c2f6f6092fdbae8cc03 v3 = this.cachedTerrainIndexes;
        v3.set_Item(c, unchecked((short)(-1)));
        IL_0015: ;
        return;
    }

    private void __name_3C536176653E675F5F5570646174655061636B6167657C3131385F30(string filename, byte[] data, ref OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733131385F30 arg2)
    {
        // structural signature __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 bytes=118A4C: valuetype OpenRA.Map/<>c__DisplayClass118_0; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_561eb7df5c9ab87d83795762fded854f9a223cb3 bytes=151280850105: class [System.Runtime]System.Collections.Generic.IEnumerable`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100003C l0 = default;
        IL_0000: ;
        global::OpenRA.Map v0 = this;
        global::OpenRA.FileSystem.IReadOnlyPackage v1 = __cil_direct_060002ED(v0);
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v2 = ref arg2;
        global::OpenRA.FileSystem.IReadWritePackage v3 = v2.toPackage;
        if (System.Object.ReferenceEquals(v1, v3)) {
            goto IL_001C;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v4 = ref arg2;
        global::OpenRA.FileSystem.IReadWritePackage v5 = v4.toPackage;
        string v6 = filename;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v7 = data;
        __cil_callvirt_06000F07(v5, v6, v7);
        return;
        IL_001C: ;
        global::OpenRA.Map v8 = this;
        global::OpenRA.FileSystem.IReadOnlyPackage v9 = __cil_direct_060002ED(v8);
        string v10 = filename;
        __cil_type_0100003C v11 = __cil_callvirt_06000F04(v9, v10);
        l0 = v11;
        __cil_type_0100003C v12 = l0;
        if (v12 is null) {
            goto IL_003A;
        } else {
            goto IL_002C;
        }
        IL_002C: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v13 = data;
        __cil_type_0100003C v14 = l0;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v15 = OpenRA.StreamExts.ReadAllBytes(v14);
        int v16 = __cil_bool_load(__cil_methodspec_call_2B0000B6(((__cil_ref_561eb7df5c9ab87d83795762fded854f9a223cb3)(v13)), ((__cil_ref_561eb7df5c9ab87d83795762fded854f9a223cb3)(v15))));
        if (v16 != 0) {
            goto IL_0047;
        } else {
            goto IL_003A;
        }
        IL_003A: ;
        ref __cil_value_47e2573ba402a2fa7a2f5b78404ae251a2be4cf5 v17 = ref arg2;
        global::OpenRA.FileSystem.IReadWritePackage v18 = v17.toPackage;
        string v19 = filename;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v20 = data;
        __cil_callvirt_06000F07(v18, v19, v20);
        goto IL_0047;
        IL_0047: ;
        return;
    }
    // property int MapFormat { get: get_MapFormat; set: set_MapFormat; }
    // property OpenRA.int2 MapSize { get: get_MapSize; set: set_MapSize; }
    // property OpenRA.FileSystem.IReadOnlyPackage Package { get: get_Package; set: set_Package; }
    // property string Uid { get: get_Uid; set: set_Uid; }
    // property OpenRA.Ruleset Rules { get: get_Rules; set: set_Rules; }
    // property OpenRA.Graphics.SequenceSet Sequences { get: get_Sequences; set: set_Sequences; }
    // property bool InvalidCustomRules { get: get_InvalidCustomRules; set: set_InvalidCustomRules; }
    // property System.Exception InvalidCustomRulesException { get: get_InvalidCustomRulesException; set: set_InvalidCustomRulesException; }
    // property OpenRA.WPos ProjectedTopLeft { get: get_ProjectedTopLeft; set: set_ProjectedTopLeft; }
    // property OpenRA.WPos ProjectedBottomRight { get: get_ProjectedBottomRight; set: set_ProjectedBottomRight; }
    // property OpenRA.CellLayer<OpenRA.TerrainTile> Tiles { get: get_Tiles; set: set_Tiles; }
    // property OpenRA.CellLayer<OpenRA.ResourceTile> Resources { get: get_Resources; set: set_Resources; }
    // property OpenRA.CellLayer<byte> Height { get: get_Height; set: set_Height; }
    // property OpenRA.CellLayer<byte> Ramp { get: get_Ramp; set: set_Ramp; }
    // property OpenRA.CellLayer<byte> CustomTerrain { get: get_CustomTerrain; set: set_CustomTerrain; }
    // property OpenRA.PPos[] ProjectedCells { get: get_ProjectedCells; set: set_ProjectedCells; }
    // property OpenRA.CellRegion AllCells { get: get_AllCells; set: set_AllCells; }
    // property System.Collections.Generic.List<OpenRA.CPos> AllEdgeCells { get: get_AllEdgeCells; set: set_AllEdgeCells; }
    // property OpenRA.WDist CellHeightStep { get: get_CellHeightStep; }
    // event System.Action<OpenRA.CPos> CellProjectionChanged { add: add_CellProjectionChanged; remove: remove_CellProjectionChanged; }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Map.__name_3C3E63 __il_field_04000A1F;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A20;
        public static System.Func<OpenRA.ActorInfo, bool> __il_field_04000A21;
        public static System.Func<System.ValueTuple<OpenRA.MPos, OpenRA.Primitives.Color>, OpenRA.MPos> __il_field_04000A22;
        public static System.Func<System.Linq.IGrouping<OpenRA.MPos, System.ValueTuple<OpenRA.MPos, OpenRA.Primitives.Color>>, OpenRA.MPos> __il_field_04000A23;
        public static System.Func<System.Linq.IGrouping<OpenRA.MPos, System.ValueTuple<OpenRA.MPos, OpenRA.Primitives.Color>>, OpenRA.Primitives.Color> __il_field_04000A24;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A25;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A26;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A27;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A28;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A29;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A2A;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A2B;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A2C;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A2D;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A2E;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A2F;
        public static System.Func<OpenRA.MPos, int> __il_field_04000A30;

        static __name_3C3E63()
        {
            global::OpenRA.Map.__name_3C3E63 v0 = __cil_newobj_06001044();
            OpenRA.Map.__name_3C3E63.__il_field_04000A1F = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <ProjectedCellHeightInner>b__116_0
        internal int ProjectedCellHeightInnerLambda116_0(OpenRA.MPos uv)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = uv.V;
            return v1;
        }

        // Metadata name: <SavePreview>b__121_0
        internal bool SavePreviewLambda121_0(OpenRA.ActorInfo a)
        {
            return __cil_callvirt_2B000273(a);
        }

        // Metadata name: <SavePreview>b__121_2
        internal OpenRA.MPos SavePreviewLambda121_2(System.ValueTuple<OpenRA.MPos, OpenRA.Primitives.Color> p)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ae04b87e93bcaa8bfb1e08c532e6f32247b8d070 bytes=15118229021182201186D4: valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v1 = p.Item1;
            return v1;
        }

        // Metadata name: <SavePreview>b__121_3
        internal OpenRA.MPos SavePreviewLambda121_3(System.Linq.IGrouping<OpenRA.MPos, System.ValueTuple<OpenRA.MPos, OpenRA.Primitives.Color>> g)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_61597c052f5e36ce496e1116fa87139118a99ab9 bytes=151280950211822015118229021182201186D4: class [System.Linq]System.Linq.IGrouping`2<valuetype OpenRA.MPos, valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v1 = __cil_callvirt_0A000BA7(g);
            return v1;
        }

        // Metadata name: <SavePreview>b__121_4
        internal OpenRA.Primitives.Color SavePreviewLambda121_4(System.Linq.IGrouping<OpenRA.MPos, System.ValueTuple<OpenRA.MPos, OpenRA.Primitives.Color>> g)
        {
            // structural signature __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f bytes=1186D4: valuetype OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ae04b87e93bcaa8bfb1e08c532e6f32247b8d070 bytes=15118229021182201186D4: valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_eea3913484a2b076219384b02ad72b2f573758b0 bytes=151280850115118229021182201186D4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_61597c052f5e36ce496e1116fa87139118a99ab9 bytes=151280950211822015118229021182201186D4: class [System.Linq]System.Linq.IGrouping`2<valuetype OpenRA.MPos, valuetype [System.Runtime]System.ValueTuple`2<valuetype OpenRA.MPos, valuetype OpenRA.Primitives.Color>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_value_ae04b87e93bcaa8bfb1e08c532e6f32247b8d070 v1 = __cil_methodspec_call_2B000274(((__cil_ref_eea3913484a2b076219384b02ad72b2f573758b0)(g)));
            __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v2 = v1.Item2;
            return v2;
        }

        // Metadata name: <GetCellSpaceBounds>b__122_0
        internal int GetCellSpaceBoundsLambda122_0(OpenRA.MPos uv)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = uv.V;
            return v1;
        }

        // Metadata name: <GetCellSpaceBounds>b__122_1
        internal int GetCellSpaceBoundsLambda122_1(OpenRA.MPos uv)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = uv.V;
            return v1;
        }

        // Metadata name: <Clamp>b__146_0
        internal int ClampLambda146_0(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <Clamp>b__146_1
        internal int ClampLambda146_1(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <ChooseClosestEdgeCell>b__150_0
        internal int ChooseClosestEdgeCellLambda150_0(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <ChooseClosestEdgeCell>b__150_1
        internal int ChooseClosestEdgeCellLambda150_1(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <UpdateEdgeCells>b__152_0
        internal int UpdateEdgeCellsLambda152_0(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <UpdateEdgeCells>b__152_1
        internal int UpdateEdgeCellsLambda152_1(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <UpdateEdgeCells>b__152_2
        internal int UpdateEdgeCellsLambda152_2(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <UpdateEdgeCells>b__152_3
        internal int UpdateEdgeCellsLambda152_3(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <UpdateEdgeCells>b__152_4
        internal int UpdateEdgeCellsLambda152_4(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }

        // Metadata name: <UpdateEdgeCells>b__152_5
        internal int UpdateEdgeCellsLambda152_5(OpenRA.MPos x)
        {
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int v1 = x.V;
            return v1;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733131375F30
    {
        public OpenRA.CellLayer<byte> mapHeight;

        public __name_3C3E635F5F446973706C6179436C6173733131375F30() : base()
        {
            return;
        }

        // Metadata name: <ProjectCellInner>b__0
        internal bool ProjectCellInnerLambda0(OpenRA.PPos c)
        {
            // structural signature __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b bytes=151281800105: class OpenRA.CellLayer`1<uint8>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_ref_51f6069415c3610f5f8b31cea24a065b6975a91b v1 = this.mapHeight;
            __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 v3 = OpenRA.PPos.op_Explicit(c);
            return v1.Contains(v3);
        }
    }

    private struct __name_3C3E635F5F446973706C6179436C6173733131385F30
    {
        public OpenRA.Map __il_field_04000A32;
        public OpenRA.FileSystem.IReadWritePackage toPackage;
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733132315F30
    {
        public System.Collections.Generic.IEnumerable<OpenRA.ActorInfo> actorTypes;

        public __name_3C3E635F5F446973706C6179436C6173733132315F30() : base()
        {
            return;
        }

        // Metadata name: <SavePreview>b__1
        internal bool SavePreviewLambda1(OpenRA.MiniYamlNode a)
        {
            // structural signature __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 bytes=151280C90212808402: class [System.Runtime]System.Func`2<class OpenRA.ActorInfo, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_ccea567f1b18a7c36170d4fe401f9076af7ad140 bytes=1512808501128084: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733132315F31 v0 = __cil_newobj_0600105A();
            v0.a = a;
            __cil_ref_ccea567f1b18a7c36170d4fe401f9076af7ad140 v4 = this.actorTypes;
            nint v6 = __cil_ldftn_0600105B;
            __cil_ref_9ce74247626075d1220ed1729f4789d317ea47d5 v7 = __cil_newobj_0A000380(v0, v6);
            return __cil_methodspec_call_2B000275(v4, v7);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733132315F31
    {
        public OpenRA.MiniYamlNode a;

        public __name_3C3E635F5F446973706C6179436C6173733132315F31() : base()
        {
            return;
        }

        // Metadata name: <SavePreview>b__5
        internal bool SavePreviewLambda5(OpenRA.ActorInfo ai)
        {
            string v1 = ai.Name;
            global::OpenRA.MiniYamlNode v3 = this.a;
            global::OpenRA.MiniYaml v4 = v3.Value;
            string v5 = v4.Value;
            return System.String.op_Equality(v1, v5);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733135315F30
    {
        public OpenRA.CPos cell;
        public System.Func<OpenRA.CPos, bool> match;

        public __name_3C3E635F5F446973706C6179436C6173733135315F30() : base()
        {
            return;
        }

        // Metadata name: <ChooseClosestMatchingEdgeCell>b__0
        internal int ChooseClosestMatchingEdgeCellLambda0(OpenRA.CPos c)
        {
            // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_b3dfeee160a12bf543a4a53eb3d0e0d3471ac19a bytes=112C: valuetype OpenRA.CVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_b3dfeee160a12bf543a4a53eb3d0e0d3471ac19a l0 = default;
            IL_0000: ;
            global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135315F30 v0 = this;
            __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v1 = v0.cell;
            __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v2 = c;
            __cil_value_b3dfeee160a12bf543a4a53eb3d0e0d3471ac19a v3 = OpenRA.CPos.op_Subtraction(v1, v2);
            l0 = v3;
            ref __cil_value_b3dfeee160a12bf543a4a53eb3d0e0d3471ac19a v4 = ref l0;
            int v5 = __cil_direct_0600008E(ref v4);
            return v5;
        }

        // Metadata name: <ChooseClosestMatchingEdgeCell>b__1
        internal bool ChooseClosestMatchingEdgeCellLambda1(OpenRA.CPos c)
        {
            // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_d1691f4089c3e5687c6115fbc860ca02f01171d6 bytes=151280C902112402: class [System.Runtime]System.Func`2<valuetype OpenRA.CPos, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_d1691f4089c3e5687c6115fbc860ca02f01171d6 v1 = this.match;
            return __cil_callvirt_0A000BA9(v1, c);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733135355F30
    {
        public int minRange;
        public OpenRA.Map __il_field_04000A39;
        public OpenRA.CPos center;
        public bool allowOutsideBounds;
        public int maxRange;

        public __name_3C3E635F5F446973706C6179436C6173733135355F30() : base()
        {
            return;
        }

        internal System.Collections.Generic.IEnumerable<OpenRA.CPos> __name_3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C30()
        {
            // structural signature __cil_ref_67f823354d0ba68522054fc40647ce206e6b1320 bytes=15128085011124: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30.__name_3C3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C303E64 v1 = __cil_newobj_06001432(-2);
            v1.__il_field_04000DF0 = this;
            return v1;
        }

        private sealed class __name_3C3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C303E64 : System.Collections.Generic.IEnumerable<OpenRA.CPos>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.CPos>, System.Collections.IEnumerator, System.IDisposable
        {
            private int __il_field_04000DED;
            private OpenRA.CPos __il_field_04000DEE;
            private int __il_field_04000DEF;
            public OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 __il_field_04000DF0;
            private int __il_field_04000DF1;
            private OpenRA.CVec[] __il_field_04000DF2;
            private int __il_field_04000DF3;

            public __name_3C3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C303E64(int __name_3C3E315F5F7374617465) : base()
            {
                this.__il_field_04000DED = __name_3C3E315F5F7374617465;
                int v4 = System.Environment.get_CurrentManagedThreadId();
                this.__il_field_04000DEF = v4;
                return;
            }

            private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
            {
                // structural signature __cil_ref_710053c9f6f6b9aec0d4941f04ca82daa57940e3 bytes=1D112C: valuetype OpenRA.CVec[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                this.__il_field_04000DF2 = null;
                this.__il_field_04000DED = -2;
                return;
            }

            private virtual bool MoveNext()
            {
                // structural signature __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca bytes=15128180011181F4: class OpenRA.CellLayer`1<valuetype OpenRA.TerrainTile>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                // structural signature __cil_value_b3dfeee160a12bf543a4a53eb3d0e0d3471ac19a bytes=112C: valuetype OpenRA.CVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                // structural signature __cil_ref_7cfc910d57ef34fbe4eb69f79419406abf863386 bytes=1D1D112C: valuetype OpenRA.CVec[][]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                // structural signature __cil_ref_710053c9f6f6b9aec0d4941f04ca82daa57940e3 bytes=1D112C: valuetype OpenRA.CVec[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                int l0 = default;
                OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 l1 = default;
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 l3 = default;
                int s8_0 = default;
                int v1 = this.__il_field_04000DED;
                l0 = v1;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v3 = this.__il_field_04000DF0;
                l1 = v3;
                int v4 = l0;
                if (v4 == 0) {
                    goto IL_001A;
                } else {
                    goto IL_0011;
                }
                IL_0011: ;
                int v5 = l0;
                if (v5 == 1) {
                    goto IL_00B0;
                } else {
                    return false;
                }
                IL_001A: ;
                this.__il_field_04000DED = -1;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v11 = l1;
                int v12 = v11.minRange;
                this.__il_field_04000DF1 = v12;
                goto IL_00EE;
                IL_0032: ;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v14 = l1;
                global::OpenRA.Map v15 = v14.__il_field_04000A39;
                global::OpenRA.MapGrid v16 = v15.Grid;
                __cil_ref_7cfc910d57ef34fbe4eb69f79419406abf863386 v17 = v16.TilesByDistance;
                int v19 = this.__il_field_04000DF1;
                __cil_ref_710053c9f6f6b9aec0d4941f04ca82daa57940e3 v20 = v17[v19];
                this.__il_field_04000DF2 = v20;
                this.__il_field_04000DF3 = 0;
                goto IL_00C5;
                IL_0058: ;
                __cil_ref_710053c9f6f6b9aec0d4941f04ca82daa57940e3 v24 = this.__il_field_04000DF2;
                int v26 = this.__il_field_04000DF3;
                __cil_value_b3dfeee160a12bf543a4a53eb3d0e0d3471ac19a v27 = __cil_ldelem_0200000B(v24, v26);
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v29 = l1;
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v30 = v29.center;
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v31 = OpenRA.CPos.op_Addition(v27, v30);
                l3 = v31;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v32 = l1;
                int v33 = __cil_bool_load(v32.allowOutsideBounds);
                if (v33 != 0) {
                    goto IL_008D;
                } else {
                    goto IL_007F;
                }
                IL_007F: ;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v34 = l1;
                global::OpenRA.Map v35 = v34.__il_field_04000A39;
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v36 = l3;
                int v37 = __cil_bool_load(__cil_direct_0600031F(v35, v36));
                int e6_8_0 = v37;
                s8_0 = e6_8_0;
                goto IL_009E;
                IL_008D: ;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v38 = l1;
                global::OpenRA.Map v39 = v38.__il_field_04000A39;
                __cil_ref_abdb7c3bba1770c707de15d43f89e92a4e6f4fca v40 = __cil_direct_060002FD(v39);
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v41 = l3;
                int v42 = __cil_bool_load(v40.Contains(v41));
                int e7_8_0 = v42;
                s8_0 = e7_8_0;
                IL_009E: ;
                if (s8_0 == 0) {
                    goto IL_00B7;
                } else {
                    goto IL_00A0;
                }
                IL_00A0: ;
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v44 = l3;
                this.__il_field_04000DEE = v44;
                this.__il_field_04000DED = 1;
                return true;
                IL_00B0: ;
                this.__il_field_04000DED = -1;
                IL_00B7: ;
                int v52 = this.__il_field_04000DF3;
                this.__il_field_04000DF3 = unchecked(v52 + 1);
                IL_00C5: ;
                int v56 = this.__il_field_04000DF3;
                __cil_ref_710053c9f6f6b9aec0d4941f04ca82daa57940e3 v58 = this.__il_field_04000DF2;
                nint v59 = unchecked((nint)(v58.LongLength));
                int v60 = unchecked((int)(v59));
                if (v56 < v60) {
                    goto IL_0058;
                } else {
                    goto IL_00D5;
                }
                IL_00D5: ;
                this.__il_field_04000DF2 = null;
                int v63 = this.__il_field_04000DF1;
                this.__il_field_04000DF1 = unchecked(v63 + 1);
                IL_00EE: ;
                int v69 = this.__il_field_04000DF1;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v70 = l1;
                int v71 = v70.maxRange;
                if (v69 <= v71) {
                    goto IL_0032;
                } else {
                    return false;
                }
            }

            private virtual OpenRA.CPos __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E43506F733E2E6765745F43757272656E74()
            {
                // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v1 = this.__il_field_04000DEE;
                return v1;
            }

            private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
            {
                global::System.NotSupportedException v0 = __cil_newobj_0A000870();
                throw v0;
            }

            private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
            {
                // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v1 = this.__il_field_04000DEE;
                object v2 = ((object)((__cil_value_30059ebebb961282a8c4af28277466cac453b6d7)(v1)));
                return v2;
            }

            private virtual System.Collections.Generic.IEnumerator<OpenRA.CPos> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E43506F733E2E476574456E756D657261746F72()
            {
                // structural signature __cil_ref_5c63daf63d59c96f173cacb2ece36e6fb15c3539 bytes=151280A1011124: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30.__name_3C3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C303E64 l0 = default;
                int v1 = this.__il_field_04000DED;
                if (unchecked((uint)v1) != unchecked((uint)-2)) {
                    goto IL_0022;
                } else {
                    goto IL_000A;
                }
                IL_000A: ;
                int v4 = this.__il_field_04000DEF;
                int v5 = System.Environment.get_CurrentManagedThreadId();
                if (unchecked((uint)v4) != unchecked((uint)v5)) {
                    goto IL_0022;
                } else {
                    goto IL_0017;
                }
                IL_0017: ;
                this.__il_field_04000DED = 0;
                l0 = this;
                goto IL_0035;
                IL_0022: ;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30.__name_3C3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C303E64 v10 = __cil_newobj_06001432(0);
                l0 = v10;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30.__name_3C3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C303E64 v11 = l0;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30 v13 = this.__il_field_04000DF0;
                v11.__il_field_04000DF0 = v13;
                IL_0035: ;
                global::OpenRA.Map.__name_3C3E635F5F446973706C6179436C6173733135355F30.__name_3C3C46696E6454696C6573496E416E6E756C75733E675F5F46696E6454696C6573496E416E6E756C75737C303E64 v14 = l0;
                return v14;
            }

            private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
            {
                // structural signature __cil_ref_5c63daf63d59c96f173cacb2ece36e6fb15c3539 bytes=151280A1011124: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                __cil_ref_5c63daf63d59c96f173cacb2ece36e6fb15c3539 v1 = __cil_direct_06001438(this);
                return v1;
            }
            // property OpenRA.CPos __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E43506F733E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E43506F733E2E6765745F43757272656E74; }
            // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
        }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Algorithms, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Algorithms, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Csp, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Csp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.Process, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.Process, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.Watcher, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.Watcher, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Channels, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Threading.Channels, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.ILGeneration, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.ILGeneration, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.Lightweight, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.Lightweight, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Loader, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Loader, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq.Expressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq.Expressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Sockets, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Sockets, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Numerics, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Numerics, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.StackTrace, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.StackTrace, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.NameResolution, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.NameResolution, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 7; exact references retained; see --details for identities and provenance.
