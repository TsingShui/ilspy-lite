using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using OpenRA.FileFormats;
using OpenRA.FileSystem;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Support;
using OpenRA.Traits;

namespace OpenRA;

public sealed class Map : IReadOnlyFileSystem, IDisposable
{
	public const int SupportedMapFormat = 11;

	public const int CurrentMapFormat = 12;

	private const short InvalidCachedTerrainIndex = -1;

	private static readonly MapField[] YamlFields = new MapField[20]
	{
		new MapField("MapFormat"),
		new MapField("RequiresMod"),
		new MapField("Title"),
		new MapField("Author"),
		new MapField("Tileset"),
		new MapField("MapSize"),
		new MapField("Bounds"),
		new MapField("Visibility"),
		new MapField("Categories"),
		new MapField("LockPreview", null, required: false, "False"),
		new MapField("Players", "PlayerDefinitions"),
		new MapField("Actors", "ActorDefinitions"),
		new MapField("Rules", "RuleDefinitions", required: false),
		new MapField("FluentMessages", "FluentMessageDefinitions", required: false),
		new MapField("Sequences", "SequenceDefinitions", required: false),
		new MapField("ModelSequences", "ModelSequenceDefinitions", required: false),
		new MapField("Weapons", "WeaponDefinitions", required: false),
		new MapField("Voices", "VoiceDefinitions", required: false),
		new MapField("Music", "MusicDefinitions", required: false),
		new MapField("Notifications", "NotificationDefinitions", required: false)
	};

	public readonly byte TileFormat = 2;

	public string RequiresMod;

	public string Title;

	public string Author;

	public string Tileset;

	public bool LockPreview;

	public Rectangle Bounds;

	public MapVisibility Visibility = MapVisibility.Lobby;

	public string[] Categories = new string[1] { "Conquest" };

	public IReadOnlyCollection<MiniYamlNode> PlayerDefinitions = ImmutableArray<MiniYamlNode>.Empty;

	public IReadOnlyCollection<MiniYamlNode> ActorDefinitions = ImmutableArray<MiniYamlNode>.Empty;

	public MiniYaml RuleDefinitions;

	public MiniYaml FluentMessageDefinitions;

	public MiniYaml SequenceDefinitions;

	public MiniYaml ModelSequenceDefinitions;

	public MiniYaml WeaponDefinitions;

	public MiniYaml VoiceDefinitions;

	public MiniYaml MusicDefinitions;

	public MiniYaml NotificationDefinitions;

	public readonly Dictionary<CPos, TerrainTile> ReplacedInvalidTerrainTiles = new Dictionary<CPos, TerrainTile>();

	public readonly MapGrid Grid;

	private readonly ModData modData;

	private CellLayer<short> cachedTerrainIndexes;

	private bool initializedCellProjection;

	private CellLayer<PPos[]> cellProjection;

	private CellLayer<List<MPos>> inverseCellProjection;

	private CellLayer<byte> projectedHeight;

	private Rectangle projectionSafeBounds;

	private static readonly PPos[] NoProjectedCells = Array.Empty<PPos>();

	public int MapFormat { get; private set; }

	public int2 MapSize { get; private set; }

	public IReadOnlyPackage Package { get; private set; }

	public string Uid { get; private set; }

	public Ruleset Rules { get; private set; }

	public SequenceSet Sequences { get; private set; }

	public bool InvalidCustomRules { get; private set; }

	public Exception InvalidCustomRulesException { get; private set; }

	public WPos ProjectedTopLeft { get; private set; }

	public WPos ProjectedBottomRight { get; private set; }

	public CellLayer<TerrainTile> Tiles { get; private set; }

	public CellLayer<ResourceTile> Resources { get; private set; }

	public CellLayer<byte> Height { get; private set; }

	public CellLayer<byte> Ramp { get; private set; }

	public CellLayer<byte> CustomTerrain { get; private set; }

	public PPos[] ProjectedCells { get; private set; }

	public CellRegion AllCells { get; private set; }

	public List<CPos> AllEdgeCells { get; private set; }

	public WDist CellHeightStep => new WDist((Grid.Type == MapGridType.RectangularIsometric) ? 724 : 512);

	public event Action<CPos> CellProjectionChanged;

	public static string ComputeUID(IReadOnlyPackage package)
	{
		return ComputeUID(package, GetMapFormat(package));
	}

	private static string ComputeUID(IReadOnlyPackage package, int format)
	{
		string[] array = new string[2] { "map.yaml", "map.bin" };
		List<string> list = package.Contents.ToList();
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (!list.Contains(text))
			{
				throw new FileNotFoundException("Required file " + text + " not present in this map");
			}
		}
		List<Stream> list2 = new List<Stream>();
		try
		{
			foreach (string item in list)
			{
				if (item.EndsWith(".yaml", StringComparison.Ordinal) || item.EndsWith(".bin", StringComparison.Ordinal) || item.EndsWith(".lua", StringComparison.Ordinal) || (format >= 12 && item == "map.png"))
				{
					list2.Add(package.GetStream(item));
				}
			}
			if (list2.Count == 0)
			{
				return CryptoUtil.SHA1Hash(Array.Empty<byte>());
			}
			Stream stream = list2[0];
			for (int j = 1; j < list2.Count; j++)
			{
				stream = new MergedStream(stream, list2[j]);
			}
			return CryptoUtil.SHA1Hash(stream);
		}
		finally
		{
			foreach (Stream item2 in list2)
			{
				item2.Dispose();
			}
		}
	}

	private static int GetMapFormat(IReadOnlyPackage p)
	{
		using (Stream stream = p.GetStream("map.yaml"))
		{
			if (stream == null)
			{
				throw new FileNotFoundException("Required file map.yaml not present in this map");
			}
			foreach (string item in stream.ReadAllLines())
			{
				Match match = Regex.Match(item, "^MapFormat:\\s*(\\d*)\\s*$");
				if (match.Success && match.Groups.Count > 0)
				{
					return FieldLoader.GetValue<int>("MapFormat", match.Groups[1].Value);
				}
			}
		}
		throw new InvalidDataException("MapFormat is not defined");
	}

	public Map(ModData modData, ITerrainInfo terrainInfo, int width, int height)
	{
		this.modData = modData;
		Size size = new Size(width, height);
		Grid = modData.Manifest.Get<MapGrid>();
		Title = "Name your map here";
		Author = "Your name here";
		MapSize = new int2(size);
		Tileset = terrainInfo.Id;
		RuleDefinitions = new MiniYaml("");
		Tiles = new CellLayer<TerrainTile>(Grid.Type, size);
		Resources = new CellLayer<ResourceTile>(Grid.Type, size);
		Height = new CellLayer<byte>(Grid.Type, size);
		Ramp = new CellLayer<byte>(Grid.Type, size);
		Tiles.Clear(terrainInfo.DefaultTerrainTile);
		if (Grid.MaximumTerrainHeight > 0)
		{
			Tiles.CellEntryChanged += UpdateRamp;
			Tiles.CellEntryChanged += UpdateProjection;
			Height.CellEntryChanged += UpdateProjection;
		}
		PostInit();
	}

	public Map(ModData modData, IReadOnlyPackage package)
	{
		this.modData = modData;
		Package = package;
		if (!Package.Contains("map.yaml") || !Package.Contains("map.bin"))
		{
			throw new InvalidDataException("Not a valid map\n File: " + package.Name);
		}
		MiniYaml miniYaml = new MiniYaml(null, MiniYaml.FromStream(Package.GetStream("map.yaml"), package.Name + ":map.yaml"));
		MapField[] yamlFields = YamlFields;
		foreach (MapField mapField in yamlFields)
		{
			mapField.Deserialize(this, miniYaml);
		}
		if (MapFormat < 11)
		{
			throw new InvalidDataException($"Map format {MapFormat} is not supported.\n File: {package.Name}");
		}
		PlayerDefinitions = miniYaml.NodeWithKeyOrDefault("Players")?.Value.Nodes ?? ImmutableArray<MiniYamlNode>.Empty;
		ActorDefinitions = miniYaml.NodeWithKeyOrDefault("Actors")?.Value.Nodes ?? ImmutableArray<MiniYamlNode>.Empty;
		Grid = modData.Manifest.Get<MapGrid>();
		Size size = new Size(MapSize.X, MapSize.Y);
		Tiles = new CellLayer<TerrainTile>(Grid.Type, size);
		Resources = new CellLayer<ResourceTile>(Grid.Type, size);
		Height = new CellLayer<byte>(Grid.Type, size);
		Ramp = new CellLayer<byte>(Grid.Type, size);
		using (Stream stream = Package.GetStream("map.bin"))
		{
			BinaryDataHeader binaryDataHeader = new BinaryDataHeader(stream, MapSize);
			if (binaryDataHeader.TilesOffset != 0)
			{
				stream.Position = binaryDataHeader.TilesOffset;
				for (int j = 0; j < MapSize.X; j++)
				{
					for (int k = 0; k < MapSize.Y; k++)
					{
						ushort type = stream.ReadUInt16();
						byte b = stream.ReadUInt8();
						if (b == byte.MaxValue)
						{
							b = (byte)(j % 4 + k % 4 * 4);
						}
						Tiles[new MPos(j, k)] = new TerrainTile(type, b);
					}
				}
			}
			if (binaryDataHeader.ResourcesOffset != 0)
			{
				stream.Position = binaryDataHeader.ResourcesOffset;
				for (int l = 0; l < MapSize.X; l++)
				{
					for (int m = 0; m < MapSize.Y; m++)
					{
						byte type2 = stream.ReadUInt8();
						byte index = stream.ReadUInt8();
						Resources[new MPos(l, m)] = new ResourceTile(type2, index);
					}
				}
			}
			if (binaryDataHeader.HeightsOffset != 0)
			{
				stream.Position = binaryDataHeader.HeightsOffset;
				for (int n = 0; n < MapSize.X; n++)
				{
					for (int num = 0; num < MapSize.Y; num++)
					{
						Height[new MPos(n, num)] = stream.ReadUInt8().Clamp((byte)0, Grid.MaximumTerrainHeight);
					}
				}
			}
		}
		if (Grid.MaximumTerrainHeight > 0)
		{
			Tiles.CellEntryChanged += UpdateRamp;
			Tiles.CellEntryChanged += UpdateProjection;
			Height.CellEntryChanged += UpdateProjection;
		}
		PostInit();
		Uid = ComputeUID(Package, MapFormat);
	}

	private void PostInit()
	{
		try
		{
			Rules = Ruleset.Load(modData, this, Tileset, RuleDefinitions, WeaponDefinitions, VoiceDefinitions, NotificationDefinitions, MusicDefinitions, ModelSequenceDefinitions);
		}
		catch (Exception ex)
		{
			Log.Write("debug", "Failed to load rules for " + Title + " with error");
			Log.Write("debug", ex);
			InvalidCustomRules = true;
			InvalidCustomRulesException = ex;
			Rules = Ruleset.LoadDefaultsForTileSet(modData, Tileset);
		}
		Sequences = new SequenceSet(this, modData, Tileset, SequenceDefinitions);
		CPos topLeft = new MPos(0, 0).ToCPos(this);
		CPos bottomRight = new MPos(MapSize.X - 1, MapSize.Y - 1).ToCPos(this);
		AllCells = new CellRegion(Grid.Type, topLeft, bottomRight);
		PPos tl = new PPos(Bounds.Left, Bounds.Top);
		PPos br = new PPos(Bounds.Right - 1, Bounds.Bottom - 1);
		SetBounds(tl, br);
		CustomTerrain = new CellLayer<byte>(this);
		foreach (MPos mapCoord in AllCells.MapCoords)
		{
			CustomTerrain[mapCoord] = byte.MaxValue;
		}
		ITerrainInfo terrainInfo = Rules.TerrainInfo;
		foreach (MPos mapCoord2 in AllCells.MapCoords)
		{
			if (!terrainInfo.TryGetTerrainInfo(Tiles[mapCoord2], out var info))
			{
				ReplacedInvalidTerrainTiles[mapCoord2.ToCPos(this)] = Tiles[mapCoord2];
				Tiles[mapCoord2] = terrainInfo.DefaultTerrainTile;
				info = terrainInfo.GetTerrainInfo(terrainInfo.DefaultTerrainTile);
			}
			Ramp[mapCoord2] = info.RampType;
		}
		AllEdgeCells = UpdateEdgeCells();
		CustomTerrain.CellEntryChanged += InvalidateTerrainIndex;
		Tiles.CellEntryChanged += InvalidateTerrainIndex;
		void InvalidateTerrainIndex(CPos c)
		{
			if (cachedTerrainIndexes != null)
			{
				cachedTerrainIndexes[c] = -1;
			}
		}
	}

	private void UpdateRamp(CPos cell)
	{
		Ramp[cell] = Rules.TerrainInfo.GetTerrainInfo(Tiles[cell]).RampType;
	}

	private void InitializeCellProjection()
	{
		if (initializedCellProjection)
		{
			return;
		}
		initializedCellProjection = true;
		cellProjection = new CellLayer<PPos[]>(this);
		inverseCellProjection = new CellLayer<List<MPos>>(this);
		projectedHeight = new CellLayer<byte>(this);
		foreach (CPos allCell in AllCells)
		{
			MPos uv = allCell.ToMPos(Grid.Type);
			cellProjection[uv] = Array.Empty<PPos>();
			inverseCellProjection[uv] = new List<MPos>(1);
		}
		foreach (CPos allCell2 in AllCells)
		{
			UpdateProjection(allCell2);
		}
	}

	private void UpdateProjection(CPos cell)
	{
		MPos mPos;
		if (Grid.MaximumTerrainHeight == 0)
		{
			mPos = cell.ToMPos(Grid.Type);
			cellProjection[cell] = new PPos[1] { (PPos)mPos };
			List<MPos> list = inverseCellProjection[mPos];
			list.Clear();
			list.Add(mPos);
			CellProjectionChanged?.Invoke(cell);
			return;
		}
		if (!initializedCellProjection)
		{
			InitializeCellProjection();
		}
		mPos = cell.ToMPos(Grid.Type);
		PPos[] array = cellProjection[mPos];
		foreach (PPos pPos in array)
		{
			MPos uv = (MPos)pPos;
			inverseCellProjection[uv].Remove(mPos);
			projectedHeight[uv] = ProjectedCellHeightInner(pPos);
		}
		PPos[] array2 = ProjectCellInner(mPos);
		cellProjection[mPos] = array2;
		PPos[] array3 = array2;
		foreach (PPos pPos2 in array3)
		{
			MPos uv2 = (MPos)pPos2;
			inverseCellProjection[uv2].Add(mPos);
			byte value = ProjectedCellHeightInner(pPos2);
			projectedHeight[uv2] = value;
			while (true)
			{
				uv2 = new MPos(uv2.U, uv2.V - 1);
				if (!inverseCellProjection.Contains(uv2) || inverseCellProjection[uv2].Count > 0)
				{
					break;
				}
				projectedHeight[uv2] = value;
			}
		}
		CellProjectionChanged?.Invoke(cell);
	}

	private byte ProjectedCellHeightInner(PPos puv)
	{
		while (inverseCellProjection.Contains((MPos)puv))
		{
			List<MPos> list = inverseCellProjection[(MPos)puv];
			if (list.Count > 0)
			{
				MPos uv = list.MaxBy((MPos mPos) => mPos.V);
				return (byte)(Height[uv] - Rules.TerrainInfo.GetTerrainInfo(Tiles[uv]).Height);
			}
			puv = new PPos(puv.U, puv.V + 1);
		}
		return 0;
	}

	private PPos[] ProjectCellInner(MPos uv)
	{
		CellLayer<byte> mapHeight = Height;
		if (!mapHeight.Contains(uv))
		{
			return NoProjectedCells;
		}
		byte b = mapHeight[uv];
		if (b == 0)
		{
			return new PPos[1] { (PPos)uv };
		}
		if ((b & 1) == 1 && Ramp[uv] != 0)
		{
			b++;
		}
		List<PPos> list = new List<PPos>();
		if ((b & 1) == 1)
		{
			if ((uv.V & 1) == 1)
			{
				list.Add(new PPos(uv.U + 1, uv.V - b));
			}
			else
			{
				list.Add(new PPos(uv.U - 1, uv.V - b));
			}
			list.Add(new PPos(uv.U, uv.V - b));
			list.Add(new PPos(uv.U, uv.V - b + 1));
			list.Add(new PPos(uv.U, uv.V - b - 1));
		}
		else
		{
			list.Add(new PPos(uv.U, uv.V - b));
		}
		return list.Where((PPos c) => mapHeight.Contains((MPos)c)).ToArray();
	}

	public void Save(IReadWritePackage toPackage)
	{
		MapFormat = 12;
		List<MiniYamlNode> list = new List<MiniYamlNode>();
		MapField[] yamlFields = YamlFields;
		foreach (MapField mapField in yamlFields)
		{
			mapField.Serialize(this, list);
		}
		for (int num = list.Count - 1; num > 0; num--)
		{
			list.Insert(num, new MiniYamlNode("", ""));
		}
		if (Package != null && toPackage != Package)
		{
			foreach (string content in Package.Contents)
			{
				toPackage.Update(content, Package.GetStream(content).ReadAllBytes());
			}
		}
		if (!LockPreview)
		{
			UpdatePackage("map.png", SavePreview());
		}
		UpdatePackage("map.yaml", Encoding.UTF8.GetBytes(list.WriteToString()));
		UpdatePackage("map.bin", SaveBinaryData());
		Package = toPackage;
		Uid = ComputeUID(toPackage, MapFormat);
		void UpdatePackage(string filename, byte[] data)
		{
			if (Package != toPackage)
			{
				toPackage.Update(filename, data);
			}
			else
			{
				Stream stream = Package.GetStream(filename);
				if (stream == null || !Enumerable.SequenceEqual(data, stream.ReadAllBytes()))
				{
					toPackage.Update(filename, data);
				}
			}
		}
	}

	public byte[] SaveBinaryData()
	{
		MemoryStream memoryStream = new MemoryStream();
		using (BinaryWriter binaryWriter = new BinaryWriter(memoryStream))
		{
			binaryWriter.Write(TileFormat);
			binaryWriter.Write((ushort)MapSize.X);
			binaryWriter.Write((ushort)MapSize.Y);
			int num = ((Grid.MaximumTerrainHeight > 0) ? (3 * MapSize.X * MapSize.Y + 17) : 0);
			int num2 = ((Grid.MaximumTerrainHeight > 0) ? 4 : 3) * MapSize.X * MapSize.Y + 17;
			binaryWriter.Write(17u);
			binaryWriter.Write((uint)num);
			binaryWriter.Write((uint)num2);
			for (int i = 0; i < MapSize.X; i++)
			{
				for (int j = 0; j < MapSize.Y; j++)
				{
					TerrainTile terrainTile = Tiles[new MPos(i, j)];
					binaryWriter.Write(terrainTile.Type);
					binaryWriter.Write(terrainTile.Index);
				}
			}
			if (num != 0)
			{
				for (int k = 0; k < MapSize.X; k++)
				{
					for (int l = 0; l < MapSize.Y; l++)
					{
						binaryWriter.Write(Height[new MPos(k, l)]);
					}
				}
			}
			if (num2 != 0)
			{
				for (int m = 0; m < MapSize.X; m++)
				{
					for (int n = 0; n < MapSize.Y; n++)
					{
						ResourceTile resourceTile = Resources[new MPos(m, n)];
						binaryWriter.Write(resourceTile.Type);
						binaryWriter.Write(resourceTile.Index);
					}
				}
			}
		}
		return memoryStream.ToArray();
	}

	public (Color Left, Color Right) GetTerrainColorPair(MPos uv)
	{
		ITerrainInfo terrainInfo = Rules.TerrainInfo;
		TerrainTileInfo terrainInfo2 = terrainInfo.GetTerrainInfo(Tiles[uv]);
		Color item = terrainInfo2.GetColor(Game.CosmeticRandom);
		Color item2 = terrainInfo2.GetColor(Game.CosmeticRandom);
		if (terrainInfo.MinHeightColorBrightness != 1f || terrainInfo.MaxHeightColorBrightness != 1f)
		{
			float num = float2.Lerp(terrainInfo.MinHeightColorBrightness, terrainInfo.MaxHeightColorBrightness, (float)(int)Height[uv] * 1f / (float)(int)Grid.MaximumTerrainHeight);
			item = Color.FromArgb((int)(num * (float)(int)item.R).Clamp(0f, 255f), (int)(num * (float)(int)item.G).Clamp(0f, 255f), (int)(num * (float)(int)item.B).Clamp(0f, 255f));
			item2 = Color.FromArgb((int)(num * (float)(int)item2.R).Clamp(0f, 255f), (int)(num * (float)(int)item2.G).Clamp(0f, 255f), (int)(num * (float)(int)item2.B).Clamp(0f, 255f));
		}
		return (Left: item, Right: item2);
	}

	public byte[] SavePreview()
	{
		IEnumerable<ActorInfo> actorTypes = Rules.Actors.Values.Where((ActorInfo a) => a.HasTraitInfo<IMapPreviewSignatureInfo>());
		IEnumerable<MiniYamlNode> enumerable = ActorDefinitions.Where((MiniYamlNode a) => actorTypes.Any((ActorInfo ai) => ai.Name == a.Value.Value));
		List<(MPos, Color)> list = new List<(MPos, Color)>();
		foreach (MiniYamlNode item in enumerable)
		{
			ActorReference s = new ActorReference(item.Value.Value, item.Value.ToDictionary());
			ActorInfo actorInfo = Rules.Actors[item.Value.Value];
			IReadOnlyCollection<IMapPreviewSignatureInfo> readOnlyCollection = actorInfo.TraitInfos<IMapPreviewSignatureInfo>();
			foreach (IMapPreviewSignatureInfo item2 in readOnlyCollection)
			{
				item2.PopulateMapPreviewSignatureCells(this, actorInfo, s, list);
			}
		}
		ActorInfo actorInfo2 = Rules.Actors[SystemActors.World];
		IReadOnlyCollection<IMapPreviewSignatureInfo> readOnlyCollection2 = actorInfo2.TraitInfos<IMapPreviewSignatureInfo>();
		foreach (IMapPreviewSignatureInfo item3 in readOnlyCollection2)
		{
			item3.PopulateMapPreviewSignatureCells(this, actorInfo2, null, list);
		}
		bool flag = Grid.Type == MapGridType.RectangularIsometric;
		int num = int.MaxValue;
		int num2 = int.MinValue;
		if (Grid.MaximumTerrainHeight > 0)
		{
			(num, num2) = GetCellSpaceBounds();
			if (num == int.MaxValue || num2 == int.MinValue)
			{
				throw new InvalidDataException("The map has invalid boundaries");
			}
		}
		else
		{
			num = Bounds.Top;
			num2 = Bounds.Bottom;
		}
		int width = Bounds.Width;
		int num3 = num2 - num;
		int num4 = width;
		if (flag)
		{
			num4 = 2 * num4 - 1;
		}
		int num5 = num4 * 4;
		byte[] array = new byte[num5 * num3];
		(Color, Color) tuple2 = default;
		Dictionary<MPos, Color> dictionary = list.GroupBy(((MPos Uv, Color Color) p) => p.Uv).ToDictionary((IGrouping<MPos, (MPos Uv, Color Color)> g) => g.Key, (IGrouping<MPos, (MPos Uv, Color Color)> g) => g.First().Color);
		for (int num6 = 0; num6 < num3; num6++)
		{
			for (int num7 = 0; num7 < width; num7++)
			{
				MPos mPos = new MPos(num7 + Bounds.Left, num6 + num);
				dictionary.TryGetValue(mPos, out var value);
				if (value.A == 0)
				{
					tuple2 = GetTerrainColorPair(mPos);
				}
				if (flag)
				{
					int num8 = mPos.V & 1;
					int num9 = 4 * (2 * num7 + num8);
					if (num7 + num8 > 0)
					{
						int num10 = num6 * num5 + num9 - 4;
						Color color;
						if (value.A == 0)
						{
							(color, _) = tuple2;
						}
						else
						{
							color = value;
						}
						Color color2 = color;
						array[num10++] = color2.R;
						array[num10++] = color2.G;
						array[num10++] = color2.B;
						array[num10] = color2.A;
					}
					if (num9 < num5)
					{
						int num11 = num6 * num5 + num9;
						Color color3 = ((value.A == 0) ? tuple2.Item2 : value);
						array[num11++] = color3.R;
						array[num11++] = color3.G;
						array[num11++] = color3.B;
						array[num11] = color3.A;
					}
				}
				else
				{
					int num12 = num6 * num5 + 4 * num7;
					Color color4;
					if (value.A == 0)
					{
						(color4, _) = tuple2;
					}
					else
					{
						color4 = value;
					}
					Color color5 = color4;
					array[num12++] = color5.R;
					array[num12++] = color5.G;
					array[num12++] = color5.B;
					array[num12] = color5.A;
				}
			}
		}
		Png png = new Png(array, SpriteFrameType.Rgba32, num4, num3);
		return png.Save();
	}

	public (int Top, int Bottom) GetCellSpaceBounds()
	{
		int num = int.MaxValue;
		int num2 = int.MinValue;
		for (int i = Bounds.Left; i < Bounds.Right; i++)
		{
			List<MPos> list = Unproject(new PPos(i, Bounds.Top));
			List<MPos> list2 = Unproject(new PPos(i, Bounds.Bottom));
			if (list.Count > 0)
			{
				num = Math.Min(num, list.MinBy((MPos uv) => uv.V).V);
			}
			if (list2.Count > 0)
			{
				num2 = Math.Max(num2, list2.MaxBy((MPos uv) => uv.V).V);
			}
		}
		return (Top: num, Bottom: num2);
	}

	public bool Contains(CPos cell)
	{
		if (Grid.Type == MapGridType.RectangularIsometric)
		{
			if (cell.X < cell.Y)
			{
				return false;
			}
		}
		else if (Grid.MaximumTerrainHeight == 0)
		{
			return Bounds.Contains(cell.X, cell.Y);
		}
		return Contains(cell.ToMPos(this));
	}

	public bool Contains(MPos uv)
	{
		if (CustomTerrain.Contains(uv))
		{
			return ContainsAllProjectedCellsCovering(uv);
		}
		return false;
	}

	private bool ContainsAllProjectedCellsCovering(MPos uv)
	{
		if (Grid.MaximumTerrainHeight == 0)
		{
			return Bounds.Contains(uv.U, uv.V);
		}
		if (projectionSafeBounds.Contains(uv.U, uv.V))
		{
			return true;
		}
		PPos[] array = ProjectedCellsCovering(uv);
		if (array.Length == 0)
		{
			return false;
		}
		PPos[] array2 = array;
		foreach (PPos puv in array2)
		{
			if (!Contains(puv))
			{
				return false;
			}
		}
		return true;
	}

	public bool Contains(PPos puv)
	{
		return Bounds.Contains(puv.U, puv.V);
	}

	public WPos CenterOfCell(CPos cell)
	{
		if (Grid.Type == MapGridType.Rectangular)
		{
			return new WPos(1024 * cell.X + 512, 1024 * cell.Y + 512, 0);
		}
		int z = (Height.TryGetValue(cell, out var value) ? (724 * value + Grid.Ramps[Ramp[cell]].CenterHeightOffset) : 0);
		return new WPos(724 * (cell.X - cell.Y + 1), 724 * (cell.X + cell.Y + 1), z);
	}

	public WPos CenterOfSubCell(CPos cell, SubCell subCell)
	{
		if ((int)subCell >= 0 && (int)subCell < Grid.SubCellOffsets.Length)
		{
			WPos a = CenterOfCell(cell);
			WVec a2 = Grid.SubCellOffsets[(uint)subCell];
			if (Ramp.TryGetValue(cell, out var value) && value != 0)
			{
				CellRamp cellRamp = Grid.Ramps[value];
				a2 += new WVec(0, 0, cellRamp.HeightOffset(a2.X, a2.Y) - cellRamp.CenterHeightOffset);
			}
			return a + a2;
		}
		return CenterOfCell(cell);
	}

	public WDist DistanceAboveTerrain(WPos pos)
	{
		if (Grid.Type == MapGridType.Rectangular)
		{
			return new WDist(pos.Z);
		}
		CPos cell = CellContaining(pos);
		WVec wVec = pos - CenterOfCell(cell);
		if (Ramp.TryGetValue(cell, out var value) && value != 0)
		{
			CellRamp cellRamp = Grid.Ramps[value];
			return new WDist(wVec.Z + cellRamp.CenterHeightOffset - cellRamp.HeightOffset(wVec.X, wVec.Y));
		}
		return new WDist(wVec.Z);
	}

	public WRot TerrainOrientation(CPos cell)
	{
		if (Ramp.TryGetValue(cell, out var value))
		{
			return Grid.Ramps[value].Orientation;
		}
		return WRot.None;
	}

	public WVec Offset(CVec delta, int dz)
	{
		if (Grid.Type == MapGridType.Rectangular)
		{
			return new WVec(1024 * delta.X, 1024 * delta.Y, 0);
		}
		return new WVec(724 * (delta.X - delta.Y), 724 * (delta.X + delta.Y), 724 * dz);
	}

	public CPos CellContaining(WPos pos)
	{
		if (Grid.Type == MapGridType.Rectangular)
		{
			return new CPos(pos.X / 1024, pos.Y / 1024);
		}
		int x = (pos.Y + pos.X - 724) / 1448;
		int y = (pos.Y - pos.X + ((pos.Y > pos.X) ? 724 : (-724))) / 1448;
		return new CPos(x, y);
	}

	public PPos ProjectedCellCovering(WPos pos)
	{
		WPos pos2 = pos - ILSpyHelper_AsRefReadOnly(new WVec(0, pos.Z, pos.Z));
		return (PPos)CellContaining(pos2).ToMPos(Grid.Type);
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	public PPos[] ProjectedCellsCovering(MPos uv)
	{
		if (!initializedCellProjection)
		{
			InitializeCellProjection();
		}
		if (!cellProjection.Contains(uv))
		{
			return NoProjectedCells;
		}
		return cellProjection[uv];
	}

	public List<MPos> Unproject(PPos puv)
	{
		MPos uv = (MPos)puv;
		if (!initializedCellProjection)
		{
			InitializeCellProjection();
		}
		if (!inverseCellProjection.Contains(uv))
		{
			return new List<MPos>();
		}
		return inverseCellProjection[uv];
	}

	public byte ProjectedHeight(PPos puv)
	{
		return projectedHeight[(MPos)puv];
	}

	public WAngle FacingBetween(CPos cell, CPos towards, WAngle fallbackfacing)
	{
		WVec wVec = CenterOfCell(towards) - CenterOfCell(cell);
		if (wVec.HorizontalLengthSquared == 0L)
		{
			return fallbackfacing;
		}
		return wVec.Yaw;
	}

	public void Resize(int width, int height)
	{
		CellLayer<TerrainTile> tiles = Tiles;
		CellLayer<ResourceTile> resources = Resources;
		CellLayer<byte> height2 = Height;
		CellLayer<byte> ramp = Ramp;
		Size size = new Size(width, height);
		Tiles = CellLayer.Resize(tiles, size, tiles[MPos.Zero]);
		Resources = CellLayer.Resize(resources, size, resources[MPos.Zero]);
		Height = CellLayer.Resize(height2, size, height2[MPos.Zero]);
		Ramp = CellLayer.Resize(ramp, size, ramp[MPos.Zero]);
		MapSize = new int2(size);
		MPos mPos = new MPos(0, 0);
		MPos mPos2 = new MPos(MapSize.X - 1, MapSize.Y - 1);
		AllCells = new CellRegion(Grid.Type, mPos.ToCPos(this), mPos2.ToCPos(this));
		SetBounds(new PPos(mPos.U + 1, mPos.V + 1), new PPos(mPos2.U - 1, mPos2.V - 1));
	}

	public void SetBounds(PPos tl, PPos br)
	{
		Bounds = Rectangle.FromLTRB(tl.U, tl.V, br.U + 1, br.V + 1);
		byte b = Grid.MaximumTerrainHeight;
		if ((b & 1) == 1)
		{
			b += 2;
		}
		projectionSafeBounds = Rectangle.FromLTRB(Bounds.Left + 1, Bounds.Top + b, Bounds.Right - 1, Bounds.Bottom);
		if (Grid.Type == MapGridType.RectangularIsometric)
		{
			ProjectedTopLeft = new WPos(tl.U * 1448, tl.V * 724, 0);
			ProjectedBottomRight = new WPos(br.U * 1448 - 1, (br.V + 1) * 724 - 1, 0);
		}
		else
		{
			ProjectedTopLeft = new WPos(tl.U * 1024, tl.V * 1024, 0);
			ProjectedBottomRight = new WPos(br.U * 1024 - 1, (br.V + 1) * 1024 - 1, 0);
		}
		ProjectedCells = new ProjectedCellRegion(this, tl, br).ToArray();
	}

	public byte GetTerrainIndex(CPos cell)
	{
		if (cachedTerrainIndexes == null)
		{
			cachedTerrainIndexes = new CellLayer<short>(this);
			cachedTerrainIndexes.Clear(-1);
		}
		MPos uv = cell.ToMPos(this);
		short num = cachedTerrainIndexes[uv];
		if (num == -1)
		{
			byte b = CustomTerrain[uv];
			CellLayer<short> cellLayer = cachedTerrainIndexes;
			byte b2 = ((b != byte.MaxValue) ? b : Rules.TerrainInfo.GetTerrainInfo(Tiles[uv]).TerrainType);
			short num2 = b2;
			cellLayer[uv] = b2;
			num = num2;
		}
		return (byte)num;
	}

	public TerrainTypeInfo GetTerrainInfo(CPos cell)
	{
		return Rules.TerrainInfo.TerrainTypes[GetTerrainIndex(cell)];
	}

	public CPos Clamp(CPos cell)
	{
		return Clamp(cell.ToMPos(this)).ToCPos(this);
	}

	public MPos Clamp(MPos uv)
	{
		if (Grid.MaximumTerrainHeight == 0)
		{
			return (MPos)Clamp((PPos)uv);
		}
		if (ContainsAllProjectedCellsCovering(uv))
		{
			return uv;
		}
		uv = cellProjection.Clamp(new MPos(uv.U.Clamp(Bounds.Left, Bounds.Right), uv.V));
		PPos[] array = ProjectedCellsCovering(uv);
		PPos puv = ((array.Length != 0) ? array[0] : new PPos(uv.U, uv.V.Clamp(Bounds.Top, Bounds.Bottom)));
		puv = Clamp(puv);
		List<MPos> list = Unproject(puv);
		if (list.Count == 0)
		{
			for (int i = 2; i <= 2 * Grid.MaximumTerrainHeight; i++)
			{
				int num = (((i & 1) == 1) ? 1 : (-1)) * i / 2;
				PPos puv2 = new PPos(puv.U, puv.V + num);
				if (Contains(puv2))
				{
					list = Unproject(puv2);
					if (list.Count > 0)
					{
						break;
					}
				}
			}
			if (list.Count == 0)
			{
				Log.Write("debug", $"Failed to clamp map cell {uv} to map bounds");
				return uv;
			}
		}
		if (puv.V != Bounds.Bottom)
		{
			return list.MinBy((MPos x) => x.V);
		}
		return list.MaxBy((MPos x) => x.V);
	}

	public PPos Clamp(PPos puv)
	{
		Rectangle r = new Rectangle(Bounds.X, Bounds.Y, Bounds.Width - 1, Bounds.Height - 1);
		return puv.Clamp(r);
	}

	public CPos ChooseRandomCell(MersenneTwister rand)
	{
		List<MPos> list;
		do
		{
			int u = rand.Next(Bounds.Left, Bounds.Right);
			int v = rand.Next(Bounds.Top, Bounds.Bottom);
			list = Unproject(new PPos(u, v));
		}
		while (list.Count == 0);
		return list.Random(rand).ToCPos(Grid.Type);
	}

	public CPos ChooseClosestEdgeCell(CPos cell)
	{
		return ChooseClosestEdgeCell(cell.ToMPos(Grid.Type)).ToCPos(Grid.Type);
	}

	public MPos ChooseClosestEdgeCell(MPos uv)
	{
		PPos[] array = ProjectedCellsCovering(uv);
		PPos puv;
		if (array.Length != 0)
		{
			PPos pPos = array[0];
			int num = ((pPos.U - Bounds.Left < Bounds.Width / 2) ? Bounds.Left : Bounds.Right);
			int num2 = ((pPos.V - Bounds.Top < Bounds.Height / 2) ? Bounds.Top : Bounds.Bottom);
			int num3 = Math.Abs(num - pPos.U);
			int num4 = Math.Abs(num2 - pPos.V);
			puv = ((num3 < num4) ? new PPos(num, pPos.V) : new PPos(pPos.U, num2));
		}
		else
		{
			puv = new PPos(Bounds.Left, Bounds.Top);
		}
		List<MPos> list = Unproject(puv);
		if (list.Count == 0)
		{
			for (int i = 2; i <= 2 * Grid.MaximumTerrainHeight; i++)
			{
				int num5 = (((i & 1) == 1) ? 1 : (-1)) * i / 2;
				PPos puv2 = new PPos(puv.U, puv.V + num5);
				if (Contains(puv2))
				{
					list = Unproject(puv2);
					if (list.Count > 0)
					{
						break;
					}
				}
			}
			if (list.Count == 0)
			{
				Log.Write("debug", $"Failed to find closest edge for map cell {uv}");
				return uv;
			}
		}
		if (puv.V != Bounds.Bottom)
		{
			return list.MinBy((MPos x) => x.V);
		}
		return list.MaxBy((MPos x) => x.V);
	}

	public CPos ChooseClosestMatchingEdgeCell(CPos cell, Func<CPos, bool> match)
	{
		return AllEdgeCells.OrderBy((CPos c) => (cell - c).Length).FirstOrDefault((CPos c) => match(c));
	}

	private List<CPos> UpdateEdgeCells()
	{
		List<CPos> list = new List<CPos>();
		List<MPos> list2 = new List<MPos>();
		int num = Bounds.Bottom - 1;
		for (int i = Bounds.Left; i < Bounds.Right; i++)
		{
			list2 = Unproject(new PPos(i, Bounds.Top));
			if (list2.Count > 0)
			{
				list.Add(list2.MinBy((MPos x) => x.V).ToCPos(Grid.Type));
			}
			list2 = Unproject(new PPos(i, num));
			if (list2.Count > 0)
			{
				list.Add(list2.MaxBy((MPos x) => x.V).ToCPos(Grid.Type));
			}
		}
		for (int num2 = Bounds.Top; num2 < Bounds.Bottom; num2++)
		{
			list2 = Unproject(new PPos(Bounds.Left, num2));
			if (list2.Count > 0)
			{
				list.Add(((num2 == num) ? list2.MaxBy((MPos x) => x.V) : list2.MinBy((MPos x) => x.V)).ToCPos(Grid.Type));
			}
			list2 = Unproject(new PPos(Bounds.Right - 1, num2));
			if (list2.Count > 0)
			{
				list.Add(((num2 == num) ? list2.MaxBy((MPos x) => x.V) : list2.MinBy((MPos x) => x.V)).ToCPos(Grid.Type));
			}
		}
		return list;
	}

	public CPos ChooseRandomEdgeCell(MersenneTwister rand)
	{
		return AllEdgeCells.Random(rand);
	}

	public WDist DistanceToEdge(WPos pos, in WVec dir)
	{
		WPos wPos = pos - ILSpyHelper_AsRefReadOnly(new WVec(0, pos.Z, pos.Z));
		int val = ((dir.X == 0) ? int.MaxValue : ((((dir.X < 0) ? ProjectedTopLeft.X : ProjectedBottomRight.X) - wPos.X) / dir.X));
		int val2 = ((dir.Y == 0) ? int.MaxValue : ((((dir.Y < 0) ? ProjectedTopLeft.Y : ProjectedBottomRight.Y) - wPos.Y) / dir.Y));
		return new WDist(Math.Min(val, val2) * dir.Length);
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	public IEnumerable<CPos> FindTilesInAnnulus(CPos center, int minRange, int maxRange, bool allowOutsideBounds = false)
	{
		if (maxRange < minRange)
		{
			throw new ArgumentOutOfRangeException("maxRange", "Maximum range is less than the minimum range.");
		}
		if (maxRange >= Grid.TilesByDistance.Length)
		{
			throw new ArgumentOutOfRangeException("maxRange", $"The requested range ({maxRange}) cannot exceed the value of MaximumTileSearchRange ({Grid.MaximumTileSearchRange})");
		}
		return FindTilesInAnnulus();
		IEnumerable<CPos> FindTilesInAnnulus()
		{
			for (int i = minRange; i <= maxRange; i++)
			{
				CVec[] array = Grid.TilesByDistance[i];
				foreach (CVec cVec in array)
				{
					CPos cPos = cVec + center;
					if (allowOutsideBounds ? Tiles.Contains(cPos) : Contains(cPos))
					{
						yield return cPos;
					}
				}
			}
		}
	}

	public IEnumerable<CPos> FindTilesInCircle(CPos center, int maxRange, bool allowOutsideBounds = false)
	{
		return FindTilesInAnnulus(center, 0, maxRange, allowOutsideBounds);
	}

	public Stream Open(string filename)
	{
		if (!filename.Contains('|') && Package.Contains(filename))
		{
			return Package.GetStream(filename);
		}
		return modData.DefaultFileSystem.Open(filename);
	}

	public bool TryGetPackageContaining(string path, out IReadOnlyPackage package, out string filename)
	{
		return modData.DefaultFileSystem.TryGetPackageContaining(path, out package, out filename);
	}

	public bool TryOpen(string filename, out Stream s)
	{
		if (!filename.Contains('|'))
		{
			s = Package.GetStream(filename);
			if (s != null)
			{
				return true;
			}
		}
		return modData.DefaultFileSystem.TryOpen(filename, out s);
	}

	public bool Exists(string filename)
	{
		if (!filename.Contains('|') && Package.Contains(filename))
		{
			return true;
		}
		return modData.DefaultFileSystem.Exists(filename);
	}

	public bool IsExternalFile(string filename)
	{
		if (filename.Contains('|'))
		{
			return modData.DefaultFileSystem.IsExternalFile(filename);
		}
		return false;
	}

	public void Dispose()
	{
		Sequences.Dispose();
	}
}
