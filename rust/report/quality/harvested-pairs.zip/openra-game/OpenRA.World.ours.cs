namespace OpenRA;

public sealed class World : System.IDisposable
{
    internal readonly OpenRA.TraitDictionary TraitDict;
    private readonly System.Collections.Generic.SortedDictionary<uint, OpenRA.Actor> actors;
    private readonly System.Collections.Generic.List<OpenRA.Effects.IEffect> effects;
    private readonly System.Collections.Generic.List<OpenRA.Effects.IEffect> unpartitionedEffects;
    private readonly System.Collections.Generic.List<OpenRA.ISync> syncedEffects;
    private readonly OpenRA.GameSettings gameSettings;
    private readonly OpenRA.ModData modData;
    private readonly System.Collections.Generic.Queue<System.Action<OpenRA.World>> frameEndActions;
    public readonly OpenRA.GameSpeed GameSpeed;
    public readonly int Timestep;
    public int ReplayTimestep;
    internal readonly OpenRA.Network.OrderManager OrderManager;
    public readonly OpenRA.Support.MersenneTwister SharedRandom;
    public readonly OpenRA.Support.MersenneTwister LocalRandom;
    public OpenRA.Primitives.LongBitSet<OpenRA.PlayerBitMask> AllPlayersMask;
    public readonly OpenRA.Primitives.LongBitSet<OpenRA.PlayerBitMask> NoPlayersMask;
    public OpenRA.Player[] Players;
    private System.Action<OpenRA.Player> RenderPlayerChanged;
    private OpenRA.Player __il_field_040004C0;
    private System.Action GameOver;
    private bool __il_field_040004C2;
    private OpenRA.Player renderPlayer;
    public readonly OpenRA.Actor WorldActor;
    public readonly OpenRA.Map Map;
    public readonly OpenRA.Traits.IActorMap ActorMap;
    public readonly OpenRA.Traits.ScreenMap ScreenMap;
    public readonly OpenRA.WorldType Type;
    public readonly OpenRA.Traits.IValidateOrder[] OrderValidators;
    private readonly OpenRA.Traits.INotifyPlayerDisconnected[] notifyDisconnected;
    private readonly OpenRA.GameInformation gameInfo;
    private readonly System.Type defaultOrderGeneratorType;
    private OpenRA.Orders.IOrderGenerator orderGenerator;
    public readonly OpenRA.Traits.ISelection Selection;
    public readonly OpenRA.Traits.IControlGroups ControlGroups;
    private readonly bool __il_field_040004D0;
    private bool wasLoadingGameSave;
    private System.Action<OpenRA.Actor> ActorAdded;
    private System.Action<OpenRA.Actor> ActorRemoved;
    private bool __il_field_040004D4;
    private bool __il_field_040004D5;
    private int __il_field_040004D6;
    private readonly System.Collections.Generic.Dictionary<int, OpenRA.MiniYaml> gameSaveTraitData;
    private uint nextAID;
    public bool Disposing;

    public OpenRA.Network.Session get_LobbyInfo()
    {
        global::OpenRA.Network.OrderManager v1 = this.OrderManager;
        global::OpenRA.Network.Session v2 = v1.LobbyInfo;
        return v2;
    }

    public void add_RenderPlayerChanged(System.Action<OpenRA.Player> value)
    {
        // structural signature __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 bytes=151281A901128254: class [System.Runtime]System.Action`1<class OpenRA.Player>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 l0 = default;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 l1 = default;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v1 = v0.RenderPlayerChanged;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v2 = l0;
        l1 = v2;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v3 = l1;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Combine(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v6 = ((__cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v8 = ref v7.RenderPlayerChanged;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v9 = l2;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v10 = l1;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v11 = __cil_methodspec_call_2B00014C(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v12 = l0;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public void remove_RenderPlayerChanged(System.Action<OpenRA.Player> value)
    {
        // structural signature __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 bytes=151281A901128254: class [System.Runtime]System.Action`1<class OpenRA.Player>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 l0 = default;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 l1 = default;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v1 = v0.RenderPlayerChanged;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v2 = l0;
        l1 = v2;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v3 = l1;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Remove(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v6 = ((__cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v8 = ref v7.RenderPlayerChanged;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v9 = l2;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v10 = l1;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v11 = __cil_methodspec_call_2B00014C(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v12 = l0;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public void SetPlayers(System.Collections.Generic.IEnumerable<OpenRA.Player> players, OpenRA.Player localPlayer)
    {
        // structural signature __cil_ref_4d4cf0f5bdcc68db8d5ce0220793e384cdf0a85d bytes=1512808501128254: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Player>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e bytes=1D128254: class OpenRA.Player[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v1 = this.Players;
        nint v2 = unchecked((nint)(v1.LongLength));
        if (v2 == 0) {
            goto IL_0014;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = __cil_ldstr_7000731E("Players are fixed once they have been set.");
        global::System.InvalidOperationException v4 = __cil_newobj_0A00006E(v3);
        throw v4;
        IL_0014: ;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v7 = __cil_methodspec_call_2B00011C(players);
        this.Players = v7;
        __cil_direct_06000665(this, localPlayer);
        return;
    }

    public OpenRA.Player get_LocalPlayer()
    {
        global::OpenRA.Player v1 = this.__il_field_040004C0;
        return v1;
    }

    private void set_LocalPlayer(OpenRA.Player value)
    {
        this.__il_field_040004C0 = value;
        return;
    }

    public void add_GameOver(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_type_01000072 v1 = v0.GameOver;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_type_01000072 v2 = l0;
        l1 = v2;
        __cil_type_01000072 v3 = l1;
        __cil_type_01000072 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Combine(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_type_01000072 v6 = ((__cil_type_01000072)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_type_01000072 v8 = ref v7.GameOver;
        __cil_type_01000072 v9 = l2;
        __cil_type_01000072 v10 = l1;
        __cil_type_01000072 v11 = __cil_methodspec_call_2B00004E(ref v8, v9, v10);
        l0 = v11;
        __cil_type_01000072 v12 = l0;
        __cil_type_01000072 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public void remove_GameOver(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_type_01000072 v1 = v0.GameOver;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_type_01000072 v2 = l0;
        l1 = v2;
        __cil_type_01000072 v3 = l1;
        __cil_type_01000072 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Remove(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_type_01000072 v6 = ((__cil_type_01000072)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_type_01000072 v8 = ref v7.GameOver;
        __cil_type_01000072 v9 = l2;
        __cil_type_01000072 v10 = l1;
        __cil_type_01000072 v11 = __cil_methodspec_call_2B00004E(ref v8, v9, v10);
        l0 = v11;
        __cil_type_01000072 v12 = l0;
        __cil_type_01000072 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public bool get_IsGameOver()
    {
        return this.__il_field_040004C2;
    }

    private void set_IsGameOver(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040004C2 = __cil_bool_store(v1);
        return;
    }

    public void EndGame()
    {
        // structural signature __cil_ref_ac0f9816cfd0ea8b2533b6b2bd8554db93410562 bytes=151280A101128614: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.IGameOver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_84ce89692cd0cb0b5570023c4d0b0ffc77b43873 bytes=1512808501128614: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.IGameOver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_ac0f9816cfd0ea8b2533b6b2bd8554db93410562 l0 = default;
        OpenRA.Traits.IGameOver l1 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000656(v0));
        if (v1 != 0) {
            goto IL_0067;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.World v2 = this;
        int v3 = 1;
        __cil_direct_06000687(v2, __cil_bool_store(v3));
        global::OpenRA.World v4 = this;
        int v5 = 1;
        __cil_direct_06000657(v4, __cil_bool_store(v5));
        global::OpenRA.World v6 = this;
        global::OpenRA.Actor v7 = v6.WorldActor;
        __cil_ref_84ce89692cd0cb0b5570023c4d0b0ffc77b43873 v8 = __cil_callvirt_2B00014D(v7);
        __cil_ref_ac0f9816cfd0ea8b2533b6b2bd8554db93410562 v9 = __cil_callvirt_0A0005A5(v8);
        l0 = v9;
        try {
            IL_0027: ;
            goto IL_0037;
            IL_0029: ;
            __cil_ref_ac0f9816cfd0ea8b2533b6b2bd8554db93410562 v10 = l0;
            global::OpenRA.Traits.IGameOver v11 = __cil_callvirt_0A0005A6(v10);
            l1 = v11;
            global::OpenRA.Traits.IGameOver v12 = l1;
            global::OpenRA.World v13 = this;
            __cil_callvirt_0600097E(v12, v13);
            goto IL_0037;
            IL_0037: ;
            __cil_ref_ac0f9816cfd0ea8b2533b6b2bd8554db93410562 v14 = l0;
            int v15 = __cil_bool_load(__cil_callvirt_0A000018(v14));
            if (v15 != 0) {
                goto IL_0029;
            } else {
                goto IL_003F;
            }
            IL_003F: ;
            goto IL_004B;
        }
        finally {
            IL_0041: ;
            __cil_ref_ac0f9816cfd0ea8b2533b6b2bd8554db93410562 v16 = l0;
            if (v16 is null) {
                goto IL_004A;
            } else {
                goto IL_0044;
            }
            IL_0044: ;
            __cil_ref_ac0f9816cfd0ea8b2533b6b2bd8554db93410562 v17 = l0;
            __cil_callvirt_0A000017(v17);
            goto IL_004A;
            IL_004A: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_004B: ;
        global::OpenRA.World v18 = this;
        global::OpenRA.GameInformation v19 = v18.gameInfo;
        global::OpenRA.World v20 = this;
        int v21 = __cil_direct_06000684(v20);
        v19.FinalGameTick = v21;
        global::OpenRA.World v22 = this;
        __cil_type_01000072 v23 = v22.GameOver;
        v23.Invoke();
        goto IL_0067;
        IL_0067: ;
        return;
    }

    public OpenRA.Player get_RenderPlayer()
    {
        global::OpenRA.Player v1 = this.renderPlayer;
        return v1;
    }

    public void set_RenderPlayer(OpenRA.Player value)
    {
        // structural signature __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 bytes=151281A901128254: class [System.Runtime]System.Action`1<class OpenRA.Player>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 s3_0 = default;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 s4_0 = default;
        global::OpenRA.Player v1 = this.LocalPlayer;
        if (v1 is null) {
            goto IL_0015;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v3 = this.LocalPlayer;
        int v4 = __cil_bool_load(__cil_callvirt_06000470(v3));
        if (v4 == 0) {
            goto IL_002D;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        this.renderPlayer = value;
        __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 v8 = this.RenderPlayerChanged;
        if (v8 is not null) {
            __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 e2_4_0 = v8;
            s4_0 = e2_4_0;
            goto IL_0027;
        } else {
            __cil_ref_71c9361f9d37b0c5c9445aebef684151a70b1fc2 e2_3_0 = v8;
            s3_0 = e2_3_0;
            goto IL_0025;
        }
        IL_0025: ;
        return;
        IL_0027: ;
        __cil_callvirt_0A0005A7(s4_0, value);
        IL_002D: ;
        return;
    }

    public bool FogObscures(OpenRA.Actor a)
    {
        global::OpenRA.Player v1 = this.RenderPlayer;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v4 = this.RenderPlayer;
        int v5 = __cil_bool_load(__cil_callvirt_06000042(a, v4));
        return (v5 == 0);
    }

    public bool FogObscures(OpenRA.CPos p)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Player v1 = this.RenderPlayer;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v3 = this.RenderPlayer;
        global::OpenRA.Traits.Shroud v4 = v3.Shroud;
        int v6 = __cil_bool_load(__cil_callvirt_060008A2(v4, p));
        return (v6 == 0);
    }

    public bool FogObscures(OpenRA.WPos pos)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Player v1 = this.RenderPlayer;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v3 = this.RenderPlayer;
        global::OpenRA.Traits.Shroud v4 = v3.Shroud;
        int v6 = __cil_bool_load(__cil_callvirt_060008A1(v4, pos));
        return (v6 == 0);
    }

    public bool ShroudObscures(OpenRA.CPos p)
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Player v1 = this.RenderPlayer;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v3 = this.RenderPlayer;
        global::OpenRA.Traits.Shroud v4 = v3.Shroud;
        int v6 = __cil_bool_load(__cil_callvirt_0600089E(v4, p));
        return (v6 == 0);
    }

    public bool ShroudObscures(OpenRA.MPos uv)
    {
        // structural signature __cil_value_5cf6185e44282f3d06aa7495519324f2fc541662 bytes=118220: valuetype OpenRA.MPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Player v1 = this.RenderPlayer;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v3 = this.RenderPlayer;
        global::OpenRA.Traits.Shroud v4 = v3.Shroud;
        int v6 = __cil_bool_load(__cil_callvirt_0600089F(v4, uv));
        return (v6 == 0);
    }

    public bool ShroudObscures(OpenRA.WPos pos)
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Player v1 = this.RenderPlayer;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v3 = this.RenderPlayer;
        global::OpenRA.Traits.Shroud v4 = v3.Shroud;
        int v6 = __cil_bool_load(__cil_callvirt_0600089D(v4, pos));
        return (v6 == 0);
    }

    public bool ShroudObscures(OpenRA.PPos uv)
    {
        // structural signature __cil_value_bb111f24fa8779c3e01028689b10d2c13e0f80c5 bytes=118224: valuetype OpenRA.PPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Player v1 = this.RenderPlayer;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Player v3 = this.RenderPlayer;
        global::OpenRA.Traits.Shroud v4 = v3.Shroud;
        int v6 = __cil_bool_load(__cil_callvirt_060008A0(v4, uv));
        return (v6 == 0);
    }

    public bool get_IsReplay()
    {
        global::OpenRA.Network.OrderManager v1 = this.OrderManager;
        global::OpenRA.Network.IConnection v2 = __cil_callvirt_06000C99(v1);
        global::OpenRA.Network.ReplayConnection v3 = ((object)v2 as OpenRA.Network.ReplayConnection);
        return (!System.Object.ReferenceEquals(v3, null));
    }

    public bool get_IsLoadingGameSave()
    {
        global::OpenRA.Network.OrderManager v1 = this.OrderManager;
        int v2 = __cil_callvirt_06000C96(v1);
        global::OpenRA.Network.OrderManager v4 = this.OrderManager;
        int v5 = v4.GameSaveLastFrame;
        int v6 = (v2 > v5 ? 1 : 0);
        return (v6 == 0);
    }

    public int get_GameSaveLoadingPercentage()
    {
        global::OpenRA.Network.OrderManager v1 = this.OrderManager;
        int v2 = __cil_callvirt_06000C96(v1);
        int v4 = unchecked(v2 * 100);
        global::OpenRA.Network.OrderManager v6 = this.OrderManager;
        int v7 = v6.GameSaveLastFrame;
        int v8 = unchecked(v4 / v7);
        return v8;
    }

    private void SetLocalPlayer(OpenRA.Player localPlayer)
    {
        // structural signature __cil_ref_4d4cf0f5bdcc68db8d5ce0220793e384cdf0a85d bytes=1512808501128254: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Player>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e bytes=1D128254: class OpenRA.Player[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        if (localPlayer is not null) {
            goto IL_0004;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        return;
        IL_0004: ;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v2 = this.Players;
        int v4 = __cil_bool_load(__cil_methodspec_call_2B00014E(((__cil_ref_4d4cf0f5bdcc68db8d5ce0220793e384cdf0a85d)(v2)), localPlayer));
        if (v4 != 0) {
            goto IL_0022;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        string v5 = __cil_ldstr_70007374("The local player must be one of the players in the world.");
        string v6 = __cil_ldstr_700073E8("localPlayer");
        global::System.ArgumentException v7 = __cil_newobj_0A000151(v5, v6);
        throw v7;
        IL_0022: ;
        int v9 = __cil_bool_load(this.IsReplay);
        if (v9 == 0) {
            goto IL_002B;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        return;
        IL_002B: ;
        this.LocalPlayer = localPlayer;
        global::OpenRA.Player v14 = this.LocalPlayer;
        this.renderPlayer = v14;
        return;
    }

    public void IssueOrder(OpenRA.Order o)
    {
        global::OpenRA.Network.OrderManager v1 = this.OrderManager;
        __cil_callvirt_06000CA0(v1, o);
        return;
    }

    public OpenRA.Orders.IOrderGenerator get_OrderGenerator()
    {
        global::OpenRA.Orders.IOrderGenerator v1 = this.orderGenerator;
        return v1;
    }

    public void set_OrderGenerator(OpenRA.Orders.IOrderGenerator value)
    {
        OpenRA.Orders.IOrderGenerator s1_0 = default;
        OpenRA.Orders.IOrderGenerator s2_0 = default;
        string v0 = __cil_ldstr_70007400("The current order generator may not be changed from synced code");
        OpenRA.Sync.AssertUnsynced(v0);
        global::OpenRA.Orders.IOrderGenerator v2 = this.orderGenerator;
        if (v2 is not null) {
            OpenRA.Orders.IOrderGenerator e0_2_0 = v2;
            s2_0 = e0_2_0;
            goto IL_0016;
        } else {
            OpenRA.Orders.IOrderGenerator e0_1_0 = v2;
            s1_0 = e0_1_0;
            goto IL_0013;
        }
        IL_0013: ;
        goto IL_001B;
        IL_0016: ;
        __cil_callvirt_06000C28(s2_0);
        IL_001B: ;
        this.orderGenerator = value;
        return;
    }

    public void CancelInputMode()
    {
        global::OpenRA.ModData v2 = this.modData;
        global::OpenRA.ObjectCreator v3 = v2.ObjectCreator;
        __cil_type_01000026 v5 = this.defaultOrderGeneratorType;
        object v6 = __cil_callvirt_06000453(v3, v5);
        global::OpenRA.Orders.IOrderGenerator v7 = ((OpenRA.Orders.IOrderGenerator)(object)v6);
        this.OrderGenerator = v7;
        return;
    }

    public bool ToggleInputMode<T>() where T : OpenRA.Orders.IOrderGenerator, new()
    {
        // IL fallback: cast TypeSpec needs a proved reference shape
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 28, 67, 06, 00, 06, 75, BA, 00, 00, 1B, 2C, 08, 02, 28, 69, 06, 00, 06, 16, 2A, 02, 28, 40]
        // .code-bytes IL_0018: [00, 00, 2B, 8C, BA, 00, 00, 1B, 28, 68, 06, 00, 06, 17, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x06000667 OpenRA.World::get_OrderGenerator
        // IL_0006: isinst 0x1B0000BA !!0
        // IL_000B: brfalse.s IL_0015
        // IL_000D: ldarg.0 0
        // IL_000E: call 0x06000669 OpenRA.World::CancelInputMode
        // IL_0013: ldc.i4.0 0
        // IL_0014: ret 
        // IL_0015: ldarg.0 0
        // IL_0016: call 0x2B000040 [System.Runtime]System.Activator::CreateInstance<!!0>
        // IL_001B: box 0x1B0000BA !!0
        // IL_0020: call 0x06000668 OpenRA.World::set_OrderGenerator
        // IL_0025: ldc.i4.1 1
        // IL_0026: ret 
    }

    public bool get_RulesContainTemporaryBlocker()
    {
        return this.__il_field_040004D0;
    }

    internal World(string mapUID, OpenRA.ModData modData, OpenRA.Network.OrderManager orderManager, OpenRA.WorldType type)
    {
        // structural signature __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e bytes=1D128254: class OpenRA.Player[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_44dc96a2823894fb95a34e1f78dbbc3eb75038bd bytes=151280A1011285A0: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.ICreatePlayers>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc bytes=151282E102091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 bytes=1512809D01128910: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 bytes=1512809D011282F8: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 bytes=1512824501151281A901128328: class [System.Collections]System.Collections.Generic.Queue`1<class [System.Runtime]System.Action`1<class OpenRA.World>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 bytes=151281A9011220: class [System.Runtime]System.Action`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3ba3c2eb4b45baaaf28f22f74207c21f78b76303 bytes=151280890208128204: class [System.Collections]System.Collections.Generic.Dictionary`2<int32, class OpenRA.MiniYaml>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_843b5287169a5b06cc68fd84a087fc911535bd6a bytes=15128089020E12808C: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class OpenRA.GameSpeed>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_aaac214924b9ece2a8b720a6d8cae583586c4cd0 bytes=15128085011284C8: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.IValidateOrder>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_64493d3206ff0c5e732673c64b5cb34035ecbb98 bytes=1D1284C8: class OpenRA.Traits.IValidateOrder[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_82340df91261aac2132ed9d14cfe80a8bcec3102 bytes=1512808501128648: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyPlayerDisconnected>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_557db442904a745f0b670309064abd91f74946d5 bytes=1D128648: class OpenRA.Traits.INotifyPlayerDisconnected[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f79d83968fb9c52a7ac889786e7fd5907e97d1b1 bytes=15128085011285A0: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.ICreatePlayers>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 bytes=151280C90215118111020E12808402: class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ActorInfo>, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5cf5512ca7dc82793997bc37568bcaeb049866ca bytes=151280850115118111020E128084: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ActorInfo>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000007 alias=__cil_enum_02000007 underlying=int: global::@OpenRA.@SystemActors; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000C9 alias=__cil_enum_020000C9 underlying=int: global::@OpenRA.@WorldType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.GameSpeeds l0 = default;
        string l1 = default;
        __cil_enum_02000007 l2 = default;
        OpenRA.Support.MersenneTwister l3 = default;
        OpenRA.Support.PerfTimer l4 = default;
        int l5 = default;
        __cil_ref_44dc96a2823894fb95a34e1f78dbbc3eb75038bd l6 = default;
        OpenRA.Traits.ICreatePlayers l7 = default;
        OpenRA.World s1_0 = default;
        __cil_type_01000072 s1_1 = default;
        OpenRA.World s2_0 = default;
        __cil_type_01000072 s2_1 = default;
        OpenRA.World s3_0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 s3_1 = default;
        OpenRA.World s4_0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 s4_1 = default;
        OpenRA.World s5_0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 s5_1 = default;
        OpenRA.World s6_0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 s6_1 = default;
        int s18_0 = default;
        OpenRA.World s27_0 = default;
        OpenRA.ActorInfoDictionary s27_1 = default;
        __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 s27_2 = default;
        OpenRA.World s28_0 = default;
        OpenRA.ActorInfoDictionary s28_1 = default;
        __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 s28_2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        global::OpenRA.TraitDictionary v1 = __cil_newobj_06000600();
        v0.TraitDict = v1;
        global::OpenRA.World v2 = this;
        __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc v3 = __cil_newobj_0A0005A8();
        v2.actors = v3;
        global::OpenRA.World v4 = this;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v5 = __cil_newobj_0A0005A9();
        v4.effects = v5;
        global::OpenRA.World v6 = this;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v7 = __cil_newobj_0A0005A9();
        v6.unpartitionedEffects = v7;
        global::OpenRA.World v8 = this;
        __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 v9 = __cil_newobj_0A0005AA();
        v8.syncedEffects = v9;
        global::OpenRA.World v10 = this;
        __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 v11 = __cil_newobj_0A0005AB();
        v10.frameEndActions = v11;
        global::OpenRA.World v12 = this;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v13 = __cil_methodspec_call_2B00014F();
        v12.Players = v13;
        global::OpenRA.World v14 = this;
        __cil_type_01000072 v15 = OpenRA.World.__name_3C3E63.__il_field_04000B4F;
        if (v15 is not null) {
            OpenRA.World e0_2_0 = v14;
            __cil_type_01000072 e0_2_1 = v15;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_006D;
        } else {
            OpenRA.World e0_1_0 = v14;
            __cil_type_01000072 e0_1_1 = v15;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_0056;
        }
        IL_0056: ;
        global::OpenRA.World.__name_3C3E63 v16 = OpenRA.World.__name_3C3E63.__il_field_04000B4D;
        nint v17 = __cil_ldftn_06001191;
        __cil_type_01000072 v18 = __cil_newobj_0A000232(v16, v17);
        OpenRA.World.__name_3C3E63.__il_field_04000B4F = v18;
        OpenRA.World e1_2_0 = s1_0;
        __cil_type_01000072 e1_2_1 = v18;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        goto IL_006D;
        IL_006D: ;
        s2_0.GameOver = s2_1;
        global::OpenRA.World v19 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v20 = OpenRA.World.__name_3C3E63.__il_field_04000B50;
        if (v20 is not null) {
            OpenRA.World e2_4_0 = v19;
            __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 e2_4_1 = v20;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0092;
        } else {
            OpenRA.World e2_3_0 = v19;
            __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 e2_3_1 = v20;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_007B;
        }
        IL_007B: ;
        global::OpenRA.World.__name_3C3E63 v21 = OpenRA.World.__name_3C3E63.__il_field_04000B4D;
        nint v22 = __cil_ldftn_06001192;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v23 = __cil_newobj_0A0005AC(v21, v22);
        OpenRA.World.__name_3C3E63.__il_field_04000B50 = v23;
        OpenRA.World e3_4_0 = s3_0;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 e3_4_1 = v23;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        goto IL_0092;
        IL_0092: ;
        s4_0.ActorAdded = s4_1;
        global::OpenRA.World v24 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v25 = OpenRA.World.__name_3C3E63.__il_field_04000B51;
        if (v25 is not null) {
            OpenRA.World e4_6_0 = v24;
            __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 e4_6_1 = v25;
            s6_0 = e4_6_0;
            s6_1 = e4_6_1;
            goto IL_00B7;
        } else {
            OpenRA.World e4_5_0 = v24;
            __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 e4_5_1 = v25;
            s5_0 = e4_5_0;
            s5_1 = e4_5_1;
            goto IL_00A0;
        }
        IL_00A0: ;
        global::OpenRA.World.__name_3C3E63 v26 = OpenRA.World.__name_3C3E63.__il_field_04000B4D;
        nint v27 = __cil_ldftn_06001193;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v28 = __cil_newobj_0A0005AC(v26, v27);
        OpenRA.World.__name_3C3E63.__il_field_04000B51 = v28;
        OpenRA.World e5_6_0 = s5_0;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 e5_6_1 = v28;
        s6_0 = e5_6_0;
        s6_1 = e5_6_1;
        goto IL_00B7;
        IL_00B7: ;
        s6_0.ActorRemoved = s6_1;
        global::OpenRA.World v29 = this;
        __cil_ref_3ba3c2eb4b45baaaf28f22f74207c21f78b76303 v30 = __cil_newobj_0A0005AD();
        v29.gameSaveTraitData = v30;
        global::OpenRA.World v31 = this;
        __cil_core_object_ctor_0A00005B(v31);
        global::OpenRA.World v32 = this;
        global::OpenRA.ModData v33 = modData;
        v32.modData = v33;
        global::OpenRA.World v34 = this;
        int v35 = unchecked((int)(type));
        v34.Type = unchecked((__cil_enum_020000C9)(v35));
        global::OpenRA.World v36 = this;
        global::OpenRA.Network.OrderManager v37 = orderManager;
        v36.OrderManager = v37;
        string v38 = __cil_ldstr_70007480("PrepareMap");
        __cil_F v39 = __cil_ldc_r4_bits(0x00000000u);
        global::OpenRA.Support.PerfTimer v40 = __cil_newobj_060007B3(v38, v39);
        l4 = v40;
        try {
            IL_00F4: ;
            global::OpenRA.World v41 = this;
            global::OpenRA.ModData v42 = modData;
            string v43 = mapUID;
            global::OpenRA.Map v44 = __cil_callvirt_06000417(v42, v43);
            v41.Map = v44;
            goto IL_010F;
        }
        finally {
            IL_0103: ;
            global::OpenRA.Support.PerfTimer v45 = l4;
            if (v45 is null) {
                goto IL_010E;
            } else {
                goto IL_0107;
            }
            IL_0107: ;
            global::OpenRA.Support.PerfTimer v46 = l4;
            __cil_callvirt_0A000017(v46);
            goto IL_010E;
            IL_010E: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_010F: ;
        global::OpenRA.ModData v47 = modData;
        global::OpenRA.Manifest v48 = v47.Manifest;
        string v49 = v48.DefaultOrderGenerator;
        int v50 = __cil_bool_load(System.String.IsNullOrEmpty(v49));
        if (v50 == 0) {
            goto IL_012C;
        } else {
            goto IL_0121;
        }
        IL_0121: ;
        string v51 = __cil_ldstr_70007496("mod.yaml must define a DefaultOrderGenerator");
        global::System.IO.InvalidDataException v52 = __cil_newobj_0A000078(v51);
        throw v52;
        IL_012C: ;
        global::OpenRA.World v53 = this;
        global::OpenRA.ModData v54 = modData;
        global::OpenRA.ObjectCreator v55 = v54.ObjectCreator;
        global::OpenRA.ModData v56 = modData;
        global::OpenRA.Manifest v57 = v56.Manifest;
        string v58 = v57.DefaultOrderGenerator;
        __cil_type_01000026 v59 = __cil_callvirt_06000451(v55, v58);
        v53.defaultOrderGeneratorType = v59;
        global::OpenRA.World v60 = this;
        __cil_type_01000026 v61 = v60.defaultOrderGeneratorType;
        int v62 = __cil_bool_load(System.Type.op_Equality(v61, ((__cil_type_01000026)(null))));
        if (v62 == 0) {
            goto IL_0171;
        } else {
            goto IL_0156;
        }
        IL_0156: ;
        global::OpenRA.ModData v63 = modData;
        global::OpenRA.Manifest v64 = v63.Manifest;
        string v65 = v64.DefaultOrderGenerator;
        string v66 = __cil_ldstr_700074F0(" is not a valid DefaultOrderGenerator");
        string v67 = System.String.Concat(v65, v66);
        global::System.IO.InvalidDataException v68 = __cil_newobj_0A000078(v67);
        throw v68;
        IL_0171: ;
        global::OpenRA.World v69 = this;
        global::OpenRA.ModData v70 = modData;
        global::OpenRA.ObjectCreator v71 = v70.ObjectCreator;
        global::OpenRA.World v72 = this;
        __cil_type_01000026 v73 = v72.defaultOrderGeneratorType;
        object v74 = __cil_callvirt_06000453(v71, v73);
        global::OpenRA.Orders.IOrderGenerator v75 = ((OpenRA.Orders.IOrderGenerator)(object)v74);
        v69.orderGenerator = v75;
        global::OpenRA.ModData v76 = modData;
        global::OpenRA.Manifest v77 = v76.Manifest;
        global::OpenRA.GameSpeeds v78 = __cil_callvirt_2B000150(v77);
        l0 = v78;
        global::OpenRA.Network.OrderManager v79 = orderManager;
        global::OpenRA.Network.Session v80 = v79.LobbyInfo;
        global::OpenRA.Network.Session.Global v81 = v80.GlobalSettings;
        string v82 = __cil_ldstr_7000753C("gamespeed");
        global::OpenRA.GameSpeeds v83 = l0;
        string v84 = v83.DefaultSpeed;
        string v85 = __cil_callvirt_06001347(v81, v82, v84);
        l1 = v85;
        global::OpenRA.World v86 = this;
        global::OpenRA.GameSpeeds v87 = l0;
        __cil_ref_843b5287169a5b06cc68fd84a087fc911535bd6a v88 = v87.Speeds;
        string v89 = l1;
        global::OpenRA.GameSpeed v90 = __cil_callvirt_0A0005AE(v88, v89);
        v86.GameSpeed = v90;
        global::OpenRA.World v91 = this;
        global::OpenRA.World v92 = this;
        global::OpenRA.World v93 = this;
        global::OpenRA.GameSpeed v94 = v93.GameSpeed;
        int v95 = v94.Timestep;
        l5 = v95;
        v92.ReplayTimestep = v95;
        int v96 = l5;
        v91.Timestep = v96;
        global::OpenRA.World v97 = this;
        global::OpenRA.Network.OrderManager v98 = orderManager;
        global::OpenRA.Network.Session v99 = v98.LobbyInfo;
        global::OpenRA.Network.Session.Global v100 = v99.GlobalSettings;
        int v101 = v100.RandomSeed;
        global::OpenRA.Support.MersenneTwister v102 = __cil_newobj_0600079E(v101);
        v97.SharedRandom = v102;
        global::OpenRA.World v103 = this;
        global::OpenRA.Support.MersenneTwister v104 = __cil_newobj_0600079D();
        v103.LocalRandom = v104;
        int v105 = unchecked((int)(type));
        int v106 = 2;
        if (v105 == v106) {
            goto IL_0211;
        } else {
            goto IL_020E;
        }
        IL_020E: ;
        int v107 = 2;
        int e16_18_0 = v107;
        s18_0 = e16_18_0;
        goto IL_0212;
        IL_0211: ;
        int v108 = 4;
        int e17_18_0 = v108;
        s18_0 = e17_18_0;
        goto IL_0212;
        IL_0212: ;
        l2 = unchecked((__cil_enum_02000007)(s18_0));
        global::OpenRA.World v109 = this;
        global::OpenRA.World v110 = this;
        ref __cil_enum_02000007 v111 = ref l2;
        string v112 = __cil_constrained_02000007_0A000068(ref v111);
        global::OpenRA.Primitives.TypeDictionary v113 = __cil_newobj_06000C1F();
        global::OpenRA.Actor v114 = __cil_direct_06000673(v110, v112, v113);
        v109.WorldActor = v114;
        global::OpenRA.World v115 = this;
        global::OpenRA.World v116 = this;
        global::OpenRA.Actor v117 = v116.WorldActor;
        global::OpenRA.Traits.IActorMap v118 = __cil_callvirt_2B000151(v117);
        v115.ActorMap = v118;
        global::OpenRA.World v119 = this;
        global::OpenRA.World v120 = this;
        global::OpenRA.Actor v121 = v120.WorldActor;
        global::OpenRA.Traits.ScreenMap v122 = __cil_callvirt_2B000152(v121);
        v119.ScreenMap = v122;
        global::OpenRA.World v123 = this;
        global::OpenRA.World v124 = this;
        global::OpenRA.Actor v125 = v124.WorldActor;
        global::OpenRA.Traits.ISelection v126 = __cil_callvirt_2B000153(v125);
        v123.Selection = v126;
        global::OpenRA.World v127 = this;
        global::OpenRA.World v128 = this;
        global::OpenRA.Actor v129 = v128.WorldActor;
        global::OpenRA.Traits.IControlGroups v130 = __cil_callvirt_2B000154(v129);
        v127.ControlGroups = v130;
        global::OpenRA.World v131 = this;
        global::OpenRA.World v132 = this;
        global::OpenRA.Actor v133 = v132.WorldActor;
        __cil_ref_aaac214924b9ece2a8b720a6d8cae583586c4cd0 v134 = __cil_callvirt_2B000155(v133);
        __cil_ref_64493d3206ff0c5e732673c64b5cb34035ecbb98 v135 = __cil_methodspec_call_2B000156(v134);
        v131.OrderValidators = v135;
        global::OpenRA.World v136 = this;
        global::OpenRA.World v137 = this;
        global::OpenRA.Actor v138 = v137.WorldActor;
        __cil_ref_82340df91261aac2132ed9d14cfe80a8bcec3102 v139 = __cil_callvirt_2B000118(v138);
        __cil_ref_557db442904a745f0b670309064abd91f74946d5 v140 = __cil_methodspec_call_2B000119(v139);
        v136.notifyDisconnected = v140;
        __cil_value_call_0A0005AF();
        global::OpenRA.Network.OrderManager v141 = orderManager;
        global::OpenRA.Network.Session v142 = v141.LobbyInfo;
        global::OpenRA.Network.Session.Global v143 = v142.GlobalSettings;
        int v144 = v143.RandomSeed;
        global::OpenRA.Support.MersenneTwister v145 = __cil_newobj_0600079E(v144);
        l3 = v145;
        global::OpenRA.World v146 = this;
        global::OpenRA.Actor v147 = v146.WorldActor;
        __cil_ref_f79d83968fb9c52a7ac889786e7fd5907e97d1b1 v148 = __cil_callvirt_2B000157(v147);
        __cil_ref_44dc96a2823894fb95a34e1f78dbbc3eb75038bd v149 = __cil_callvirt_0A0005B0(v148);
        l6 = v149;
        try {
            IL_02CE: ;
            goto IL_02E2;
            IL_02D0: ;
            __cil_ref_44dc96a2823894fb95a34e1f78dbbc3eb75038bd v150 = l6;
            global::OpenRA.Traits.ICreatePlayers v151 = __cil_callvirt_0A0005B1(v150);
            l7 = v151;
            global::OpenRA.Traits.ICreatePlayers v152 = l7;
            global::OpenRA.World v153 = this;
            global::OpenRA.Support.MersenneTwister v154 = l3;
            __cil_callvirt_06000941(v152, v153, v154);
            goto IL_02E2;
            IL_02E2: ;
            __cil_ref_44dc96a2823894fb95a34e1f78dbbc3eb75038bd v155 = l6;
            int v156 = __cil_bool_load(__cil_callvirt_0A000018(v155));
            if (v156 != 0) {
                goto IL_02D0;
            } else {
                goto IL_02EB;
            }
            IL_02EB: ;
            goto IL_02F9;
        }
        finally {
            IL_02ED: ;
            __cil_ref_44dc96a2823894fb95a34e1f78dbbc3eb75038bd v157 = l6;
            if (v157 is null) {
                goto IL_02F8;
            } else {
                goto IL_02F1;
            }
            IL_02F1: ;
            __cil_ref_44dc96a2823894fb95a34e1f78dbbc3eb75038bd v158 = l6;
            __cil_callvirt_0A000017(v158);
            goto IL_02F8;
            IL_02F8: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_02F9: ;
        global::OpenRA.Sound v159 = OpenRA.Game.Sound;
        __cil_F v160 = __cil_ldc_r4_bits(0x3F800000u);
        __cil_callvirt_06000574(v159, __cil_call_arg_r4(v160));
        global::OpenRA.World v161 = this;
        global::OpenRA.GameInformation v162 = __cil_newobj_0600019D();
        global::OpenRA.ModData v163 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v164 = v163.Manifest;
        string v165 = v164.Id;
        v162.Mod = v165;
        global::OpenRA.ModData v166 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v167 = v166.Manifest;
        global::OpenRA.ModMetadata v168 = v167.Metadata;
        string v169 = v168.Version;
        v162.Version = v169;
        global::OpenRA.World v170 = this;
        global::OpenRA.Map v171 = v170.Map;
        string v172 = __cil_callvirt_060002EF(v171);
        v162.MapUid = v172;
        global::OpenRA.World v173 = this;
        global::OpenRA.Map v174 = v173.Map;
        string v175 = v174.Title;
        v162.MapTitle = v175;
        v161.gameInfo = v162;
        global::OpenRA.World v176 = this;
        global::OpenRA.World v177 = this;
        global::OpenRA.Map v178 = v177.Map;
        global::OpenRA.Ruleset v179 = __cil_callvirt_060002F1(v178);
        global::OpenRA.ActorInfoDictionary v180 = v179.Actors;
        __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 v181 = OpenRA.World.__name_3C3E63.__il_field_04000B4E;
        if (v181 is not null) {
            OpenRA.World e26_28_0 = v176;
            OpenRA.ActorInfoDictionary e26_28_1 = v180;
            __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 e26_28_2 = v181;
            s28_0 = e26_28_0;
            s28_1 = e26_28_1;
            s28_2 = e26_28_2;
            goto IL_0394;
        } else {
            OpenRA.World e26_27_0 = v176;
            OpenRA.ActorInfoDictionary e26_27_1 = v180;
            __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 e26_27_2 = v181;
            s27_0 = e26_27_0;
            s27_1 = e26_27_1;
            s27_2 = e26_27_2;
            goto IL_037D;
        }
        IL_037D: ;
        global::OpenRA.World.__name_3C3E63 v182 = OpenRA.World.__name_3C3E63.__il_field_04000B4D;
        nint v183 = __cil_ldftn_06001190;
        __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 v184 = __cil_newobj_0A0005B2(v182, v183);
        OpenRA.World.__name_3C3E63.__il_field_04000B4E = v184;
        OpenRA.World e27_28_0 = s27_0;
        OpenRA.ActorInfoDictionary e27_28_1 = s27_1;
        __cil_ref_168168ef052f2629503b42cdd549ccc5909f39c9 e27_28_2 = v184;
        s28_0 = e27_28_0;
        s28_1 = e27_28_1;
        s28_2 = e27_28_2;
        goto IL_0394;
        IL_0394: ;
        int v185 = __cil_bool_load(__cil_methodspec_call_2B000158(((__cil_ref_5cf5512ca7dc82793997bc37568bcaeb049866ca)(s28_1)), s28_2));
        s28_0.__il_field_040004D0 = __cil_bool_store(v185);
        global::OpenRA.World v186 = this;
        global::OpenRA.Settings v187 = OpenRA.Game.Settings;
        global::OpenRA.GameSettings v188 = v187.Game;
        v186.gameSettings = v188;
        return;
    }

    public void AddToMaps(OpenRA.Actor self, OpenRA.Traits.IOccupySpace ios)
    {
        global::OpenRA.Traits.IActorMap v1 = this.ActorMap;
        __cil_callvirt_06000909(v1, self, ios);
        global::OpenRA.Traits.IActorMap v5 = this.ActorMap;
        __cil_callvirt_06000911(v5, self, ios);
        global::OpenRA.Traits.ScreenMap v9 = this.ScreenMap;
        __cil_callvirt_060009AA(v9, self);
        return;
    }

    public void UpdateMaps(OpenRA.Actor self, OpenRA.Traits.IOccupySpace ios)
    {
        int v1 = __cil_bool_load(__cil_callvirt_06000015(self));
        if (v1 != 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        global::OpenRA.Traits.ScreenMap v3 = this.ScreenMap;
        __cil_callvirt_060009AA(v3, self);
        global::OpenRA.Traits.IActorMap v6 = this.ActorMap;
        __cil_callvirt_06000913(v6, self, ios);
        return;
    }

    public void RemoveFromMaps(OpenRA.Actor self, OpenRA.Traits.IOccupySpace ios)
    {
        global::OpenRA.Traits.IActorMap v1 = this.ActorMap;
        __cil_callvirt_0600090A(v1, self, ios);
        global::OpenRA.Traits.IActorMap v5 = this.ActorMap;
        __cil_callvirt_06000912(v5, self, ios);
        global::OpenRA.Traits.ScreenMap v9 = this.ScreenMap;
        __cil_callvirt_060009AB(v9, self);
        return;
    }

    public void LoadComplete(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e bytes=1D128254: class OpenRA.Player[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde bytes=118165: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_0033a5955763d881ebbd48fca1e39ec7c8e1b61d bytes=151280A101128590: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.INotifyGameLoading>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 bytes=151280A101128588: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.IWorldLoaded>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9a306d68a229f7ee6fc3e02479c9205a9d01cfab bytes=1512808501128590: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyGameLoading>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b6a6aa8b4bc980b8528880fe1057dc83e1a60273 bytes=1512808501128588: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.IWorldLoaded>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 bytes=151280A50108: class [System.Collections]System.Collections.Generic.HashSet`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Network.NetworkConnection l0 = default;
        __cil_ref_0033a5955763d881ebbd48fca1e39ec7c8e1b61d l1 = default;
        OpenRA.Traits.INotifyGameLoading l2 = default;
        OpenRA.Support.PerfTimer l3 = default;
        __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 l4 = default;
        OpenRA.Traits.IWorldLoaded l5 = default;
        OpenRA.Support.PerfTimer l6 = default;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e l7 = default;
        int l8 = default;
        OpenRA.Player l9 = default;
        __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 l10 = default;
        OpenRA.Traits.IWorldLoaded l11 = default;
        OpenRA.Support.PerfTimer l12 = default;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e l13 = default;
        int l14 = default;
        OpenRA.Player l15 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000663(v0));
        if (v1 == 0) {
            goto IL_004F;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.World v2 = this;
        int v3 = 1;
        v2.wasLoadingGameSave = __cil_bool_store(v3);
        global::OpenRA.Sound v4 = OpenRA.Game.Sound;
        int v5 = 1;
        __cil_callvirt_06000555(v4, __cil_bool_store(v5));
        global::OpenRA.World v6 = this;
        global::OpenRA.Actor v7 = v6.WorldActor;
        __cil_ref_9a306d68a229f7ee6fc3e02479c9205a9d01cfab v8 = __cil_callvirt_2B000159(v7);
        __cil_ref_0033a5955763d881ebbd48fca1e39ec7c8e1b61d v9 = __cil_callvirt_0A0005B3(v8);
        l1 = v9;
        try {
            IL_002B: ;
            goto IL_003B;
            IL_002D: ;
            __cil_ref_0033a5955763d881ebbd48fca1e39ec7c8e1b61d v10 = l1;
            global::OpenRA.Traits.INotifyGameLoading v11 = __cil_callvirt_0A0005B4(v10);
            l2 = v11;
            global::OpenRA.Traits.INotifyGameLoading v12 = l2;
            global::OpenRA.World v13 = this;
            __cil_callvirt_0600093C(v12, v13);
            goto IL_003B;
            IL_003B: ;
            __cil_ref_0033a5955763d881ebbd48fca1e39ec7c8e1b61d v14 = l1;
            int v15 = __cil_bool_load(__cil_callvirt_0A000018(v14));
            if (v15 != 0) {
                goto IL_002D;
            } else {
                goto IL_0043;
            }
            IL_0043: ;
            goto IL_004F;
        }
        finally {
            IL_0045: ;
            __cil_ref_0033a5955763d881ebbd48fca1e39ec7c8e1b61d v16 = l1;
            if (v16 is null) {
                goto IL_004E;
            } else {
                goto IL_0048;
            }
            IL_0048: ;
            __cil_ref_0033a5955763d881ebbd48fca1e39ec7c8e1b61d v17 = l1;
            __cil_callvirt_0A000017(v17);
            goto IL_004E;
            IL_004E: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_004F: ;
        string v18 = __cil_ldstr_70007550("ScreenMap.WorldLoaded");
        __cil_F v19 = __cil_ldc_r4_bits(0x00000000u);
        global::OpenRA.Support.PerfTimer v20 = __cil_newobj_060007B3(v18, v19);
        l3 = v20;
        try {
            IL_005F: ;
            global::OpenRA.World v21 = this;
            global::OpenRA.Traits.ScreenMap v22 = v21.ScreenMap;
            global::OpenRA.World v23 = this;
            global::OpenRA.Graphics.WorldRenderer v24 = wr;
            __cil_callvirt_060009A7(v22, v23, v24);
            goto IL_0078;
        }
        finally {
            IL_006E: ;
            global::OpenRA.Support.PerfTimer v25 = l3;
            if (v25 is null) {
                goto IL_0077;
            } else {
                goto IL_0071;
            }
            IL_0071: ;
            global::OpenRA.Support.PerfTimer v26 = l3;
            __cil_callvirt_0A000017(v26);
            goto IL_0077;
            IL_0077: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_0078: ;
        global::OpenRA.World v27 = this;
        global::OpenRA.Actor v28 = v27.WorldActor;
        __cil_ref_b6a6aa8b4bc980b8528880fe1057dc83e1a60273 v29 = __cil_callvirt_2B00015A(v28);
        __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v30 = __cil_callvirt_0A0005B5(v29);
        l4 = v30;
        try {
            IL_008A: ;
            goto IL_00D8;
            IL_008C: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v31 = l4;
            global::OpenRA.Traits.IWorldLoaded v32 = __cil_callvirt_0A0005B6(v31);
            l5 = v32;
            global::OpenRA.Traits.IWorldLoaded v33 = l5;
            global::OpenRA.World v34 = this;
            global::OpenRA.Traits.ScreenMap v35 = v34.ScreenMap;
            if (System.Object.ReferenceEquals(v33, v35)) {
                goto IL_00D8;
            } else {
                goto IL_009F;
            }
            IL_009F: ;
            global::OpenRA.Traits.IWorldLoaded v36 = l5;
            __cil_type_01000026 v37 = v36.GetType();
            string v38 = __cil_callvirt_0A000077(v37);
            string v39 = __cil_ldstr_7000757C(".WorldLoaded");
            string v40 = System.String.Concat(v38, v39);
            __cil_F v41 = __cil_ldc_r4_bits(0x00000000u);
            global::OpenRA.Support.PerfTimer v42 = __cil_newobj_060007B3(v40, v41);
            l6 = v42;
            try {
                IL_00C1: ;
                global::OpenRA.Traits.IWorldLoaded v43 = l5;
                global::OpenRA.World v44 = this;
                global::OpenRA.Graphics.WorldRenderer v45 = wr;
                __cil_callvirt_0600093A(v43, v44, v45);
                goto IL_00D8;
            }
            finally {
                IL_00CC: ;
                global::OpenRA.Support.PerfTimer v46 = l6;
                if (v46 is null) {
                    goto IL_00D7;
                } else {
                    goto IL_00D0;
                }
                IL_00D0: ;
                global::OpenRA.Support.PerfTimer v47 = l6;
                __cil_callvirt_0A000017(v47);
                goto IL_00D7;
                IL_00D7: ;
                goto __cil_finally_end_2;
                __cil_finally_end_2: ;
            }
            IL_00D8: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v48 = l4;
            int v49 = __cil_bool_load(__cil_callvirt_0A000018(v48));
            if (v49 != 0) {
                goto IL_008C;
            } else {
                goto IL_00E1;
            }
            IL_00E1: ;
            goto IL_00EF;
        }
        finally {
            IL_00E3: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v50 = l4;
            if (v50 is null) {
                goto IL_00EE;
            } else {
                goto IL_00E7;
            }
            IL_00E7: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v51 = l4;
            __cil_callvirt_0A000017(v51);
            goto IL_00EE;
            IL_00EE: ;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_00EF: ;
        global::OpenRA.World v52 = this;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v53 = v52.Players;
        l7 = v53;
        int v54 = 0;
        l8 = v54;
        goto IL_0177;
        IL_00FC: ;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v55 = l7;
        int v56 = l8;
        global::OpenRA.Player v57 = v55[v56];
        l9 = v57;
        global::OpenRA.Player v58 = l9;
        global::OpenRA.Actor v59 = v58.PlayerActor;
        __cil_ref_b6a6aa8b4bc980b8528880fe1057dc83e1a60273 v60 = __cil_callvirt_2B00015A(v59);
        __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v61 = __cil_callvirt_0A0005B5(v60);
        l10 = v61;
        try {
            IL_0116: ;
            goto IL_015A;
            IL_0118: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v62 = l10;
            global::OpenRA.Traits.IWorldLoaded v63 = __cil_callvirt_0A0005B6(v62);
            l11 = v63;
            global::OpenRA.Traits.IWorldLoaded v64 = l11;
            __cil_type_01000026 v65 = v64.GetType();
            string v66 = __cil_callvirt_0A000077(v65);
            string v67 = __cil_ldstr_7000757C(".WorldLoaded");
            string v68 = System.String.Concat(v66, v67);
            __cil_F v69 = __cil_ldc_r4_bits(0x00000000u);
            global::OpenRA.Support.PerfTimer v70 = __cil_newobj_060007B3(v68, v69);
            l12 = v70;
            try {
                IL_0143: ;
                global::OpenRA.Traits.IWorldLoaded v71 = l11;
                global::OpenRA.World v72 = this;
                global::OpenRA.Graphics.WorldRenderer v73 = wr;
                __cil_callvirt_0600093A(v71, v72, v73);
                goto IL_015A;
            }
            finally {
                IL_014E: ;
                global::OpenRA.Support.PerfTimer v74 = l12;
                if (v74 is null) {
                    goto IL_0159;
                } else {
                    goto IL_0152;
                }
                IL_0152: ;
                global::OpenRA.Support.PerfTimer v75 = l12;
                __cil_callvirt_0A000017(v75);
                goto IL_0159;
                IL_0159: ;
                goto __cil_finally_end_4;
                __cil_finally_end_4: ;
            }
            IL_015A: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v76 = l10;
            int v77 = __cil_bool_load(__cil_callvirt_0A000018(v76));
            if (v77 != 0) {
                goto IL_0118;
            } else {
                goto IL_0163;
            }
            IL_0163: ;
            goto IL_0171;
        }
        finally {
            IL_0165: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v78 = l10;
            if (v78 is null) {
                goto IL_0170;
            } else {
                goto IL_0169;
            }
            IL_0169: ;
            __cil_ref_73340d1298dda9ea537934480f548b788bdd9444 v79 = l10;
            __cil_callvirt_0A000017(v79);
            goto IL_0170;
            IL_0170: ;
            goto __cil_finally_end_5;
            __cil_finally_end_5: ;
        }
        IL_0171: ;
        int v80 = l8;
        int v81 = 1;
        int v82 = unchecked(v80 + v81);
        l8 = v82;
        goto IL_0177;
        IL_0177: ;
        int v83 = l8;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v84 = l7;
        nint v85 = unchecked((nint)(v84.LongLength));
        int v86 = unchecked((int)(v85));
        if (v83 < v86) {
            goto IL_00FC;
        } else {
            goto IL_0182;
        }
        IL_0182: ;
        global::OpenRA.World v87 = this;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v88 = v87.Players;
        l13 = v88;
        int v89 = 0;
        l14 = v89;
        goto IL_01B4;
        IL_018F: ;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v90 = l13;
        int v91 = l14;
        global::OpenRA.Player v92 = v90[v91];
        l15 = v92;
        global::OpenRA.World v93 = this;
        global::OpenRA.GameInformation v94 = v93.gameInfo;
        global::OpenRA.Player v95 = l15;
        global::OpenRA.World v96 = this;
        global::OpenRA.Network.OrderManager v97 = v96.OrderManager;
        global::OpenRA.Network.Session v98 = v97.LobbyInfo;
        __cil_callvirt_060001A0(v94, v95, v98);
        int v99 = l14;
        int v100 = 1;
        int v101 = unchecked(v99 + v100);
        l14 = v101;
        goto IL_01B4;
        IL_01B4: ;
        int v102 = l14;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v103 = l13;
        nint v104 = unchecked((nint)(v103.LongLength));
        int v105 = unchecked((int)(v104));
        if (v102 < v105) {
            goto IL_018F;
        } else {
            goto IL_01BC;
        }
        IL_01BC: ;
        global::OpenRA.World v106 = this;
        global::OpenRA.GameInformation v107 = v106.gameInfo;
        global::OpenRA.World v108 = this;
        global::OpenRA.Network.OrderManager v109 = v108.OrderManager;
        global::OpenRA.Network.Session v110 = v109.LobbyInfo;
        __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 v111 = v110.DisabledSpawnPoints;
        v107.DisabledSpawnPoints = v111;
        global::OpenRA.World v112 = this;
        global::OpenRA.GameInformation v113 = v112.gameInfo;
        __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde v114 = System.DateTime.get_UtcNow();
        v113.StartTimeUtc = v114;
        global::OpenRA.World v115 = this;
        global::OpenRA.Network.OrderManager v116 = v115.OrderManager;
        global::OpenRA.Network.IConnection v117 = __cil_callvirt_06000C99(v116);
        global::OpenRA.Network.NetworkConnection v118 = ((object)v117 as OpenRA.Network.NetworkConnection);
        l0 = v118;
        global::OpenRA.Network.NetworkConnection v119 = l0;
        if (v119 is null) {
            goto IL_0219;
        } else {
            goto IL_01FB;
        }
        IL_01FB: ;
        global::OpenRA.Network.NetworkConnection v120 = l0;
        global::OpenRA.Network.ReplayRecorder v121 = __cil_callvirt_06000C39(v120);
        if (v121 is null) {
            goto IL_0219;
        } else {
            goto IL_0203;
        }
        IL_0203: ;
        global::OpenRA.Network.NetworkConnection v122 = l0;
        global::OpenRA.Network.ReplayRecorder v123 = __cil_callvirt_06000C39(v122);
        global::OpenRA.World v124 = this;
        global::OpenRA.GameInformation v125 = v124.gameInfo;
        global::OpenRA.FileFormats.ReplayMetadata v126 = __cil_newobj_06000F1F(v125);
        v123.Metadata = v126;
        goto IL_0219;
        IL_0219: ;
        return;
    }

    public void PostLoadComplete(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e bytes=1D128254: class OpenRA.Player[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 bytes=151280A10112858C: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.IPostWorldLoaded>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c51aa9ac9455cbbb4b9376e3ae4b05a3c7311c8b bytes=151280850112858C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.IPostWorldLoaded>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 l0 = default;
        OpenRA.Traits.IPostWorldLoaded l1 = default;
        OpenRA.Support.PerfTimer l2 = default;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e l3 = default;
        int l4 = default;
        OpenRA.Player l5 = default;
        __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 l6 = default;
        OpenRA.Traits.IPostWorldLoaded l7 = default;
        OpenRA.Support.PerfTimer l8 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        global::OpenRA.Actor v1 = v0.WorldActor;
        __cil_ref_c51aa9ac9455cbbb4b9376e3ae4b05a3c7311c8b v2 = __cil_callvirt_2B00015B(v1);
        __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v3 = __cil_callvirt_0A0005B7(v2);
        l0 = v3;
        try {
            IL_0011: ;
            goto IL_004E;
            IL_0013: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v4 = l0;
            global::OpenRA.Traits.IPostWorldLoaded v5 = __cil_callvirt_0A0005B8(v4);
            l1 = v5;
            global::OpenRA.Traits.IPostWorldLoaded v6 = l1;
            __cil_type_01000026 v7 = v6.GetType();
            string v8 = __cil_callvirt_0A000077(v7);
            string v9 = __cil_ldstr_70007596(".PostWorldLoaded");
            string v10 = System.String.Concat(v8, v9);
            __cil_F v11 = __cil_ldc_r4_bits(0x00000000u);
            global::OpenRA.Support.PerfTimer v12 = __cil_newobj_060007B3(v10, v11);
            l2 = v12;
            try {
                IL_003A: ;
                global::OpenRA.Traits.IPostWorldLoaded v13 = l1;
                global::OpenRA.World v14 = this;
                global::OpenRA.Graphics.WorldRenderer v15 = wr;
                __cil_callvirt_0600093B(v13, v14, v15);
                goto IL_004E;
            }
            finally {
                IL_0044: ;
                global::OpenRA.Support.PerfTimer v16 = l2;
                if (v16 is null) {
                    goto IL_004D;
                } else {
                    goto IL_0047;
                }
                IL_0047: ;
                global::OpenRA.Support.PerfTimer v17 = l2;
                __cil_callvirt_0A000017(v17);
                goto IL_004D;
                IL_004D: ;
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_004E: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v18 = l0;
            int v19 = __cil_bool_load(__cil_callvirt_0A000018(v18));
            if (v19 != 0) {
                goto IL_0013;
            } else {
                goto IL_0056;
            }
            IL_0056: ;
            goto IL_0062;
        }
        finally {
            IL_0058: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v20 = l0;
            if (v20 is null) {
                goto IL_0061;
            } else {
                goto IL_005B;
            }
            IL_005B: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v21 = l0;
            __cil_callvirt_0A000017(v21);
            goto IL_0061;
            IL_0061: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_0062: ;
        global::OpenRA.World v22 = this;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v23 = v22.Players;
        l3 = v23;
        int v24 = 0;
        l4 = v24;
        goto IL_00E8;
        IL_006E: ;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v25 = l3;
        int v26 = l4;
        global::OpenRA.Player v27 = v25[v26];
        l5 = v27;
        global::OpenRA.Player v28 = l5;
        global::OpenRA.Actor v29 = v28.PlayerActor;
        __cil_ref_c51aa9ac9455cbbb4b9376e3ae4b05a3c7311c8b v30 = __cil_callvirt_2B00015B(v29);
        __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v31 = __cil_callvirt_0A0005B7(v30);
        l6 = v31;
        try {
            IL_0087: ;
            goto IL_00CB;
            IL_0089: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v32 = l6;
            global::OpenRA.Traits.IPostWorldLoaded v33 = __cil_callvirt_0A0005B8(v32);
            l7 = v33;
            global::OpenRA.Traits.IPostWorldLoaded v34 = l7;
            __cil_type_01000026 v35 = v34.GetType();
            string v36 = __cil_callvirt_0A000077(v35);
            string v37 = __cil_ldstr_70007596(".PostWorldLoaded");
            string v38 = System.String.Concat(v36, v37);
            __cil_F v39 = __cil_ldc_r4_bits(0x00000000u);
            global::OpenRA.Support.PerfTimer v40 = __cil_newobj_060007B3(v38, v39);
            l8 = v40;
            try {
                IL_00B4: ;
                global::OpenRA.Traits.IPostWorldLoaded v41 = l7;
                global::OpenRA.World v42 = this;
                global::OpenRA.Graphics.WorldRenderer v43 = wr;
                __cil_callvirt_0600093B(v41, v42, v43);
                goto IL_00CB;
            }
            finally {
                IL_00BF: ;
                global::OpenRA.Support.PerfTimer v44 = l8;
                if (v44 is null) {
                    goto IL_00CA;
                } else {
                    goto IL_00C3;
                }
                IL_00C3: ;
                global::OpenRA.Support.PerfTimer v45 = l8;
                __cil_callvirt_0A000017(v45);
                goto IL_00CA;
                IL_00CA: ;
                goto __cil_finally_end_2;
                __cil_finally_end_2: ;
            }
            IL_00CB: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v46 = l6;
            int v47 = __cil_bool_load(__cil_callvirt_0A000018(v46));
            if (v47 != 0) {
                goto IL_0089;
            } else {
                goto IL_00D4;
            }
            IL_00D4: ;
            goto IL_00E2;
        }
        finally {
            IL_00D6: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v48 = l6;
            if (v48 is null) {
                goto IL_00E1;
            } else {
                goto IL_00DA;
            }
            IL_00DA: ;
            __cil_ref_6996c963af26c7ec7e5a4d00fd93ad4b499baf19 v49 = l6;
            __cil_callvirt_0A000017(v49);
            goto IL_00E1;
            IL_00E1: ;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_00E2: ;
        int v50 = l4;
        int v51 = 1;
        int v52 = unchecked(v50 + v51);
        l4 = v52;
        goto IL_00E8;
        IL_00E8: ;
        int v53 = l4;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v54 = l3;
        nint v55 = unchecked((nint)(v54.LongLength));
        int v56 = unchecked((int)(v55));
        if (v53 < v56) {
            goto IL_006E;
        } else {
            goto IL_00F2;
        }
        IL_00F2: ;
        return;
    }

    public void SetWorldOwner(OpenRA.Player p)
    {
        global::OpenRA.Actor v1 = this.WorldActor;
        __cil_callvirt_06000014(v1, p);
        return;
    }

    public OpenRA.Actor CreateActor(string name, OpenRA.Primitives.TypeDictionary initDict)
    {
        global::OpenRA.Actor v4 = __cil_direct_06000675(this, __cil_bool_store(1), name, initDict);
        return v4;
    }

    public OpenRA.Actor CreateActor(bool addToWorld, OpenRA.ActorReference reference)
    {
        int v1 = __cil_bool_load(addToWorld);
        string v3 = reference.Type;
        global::OpenRA.Primitives.TypeDictionary v5 = __cil_callvirt_060002A0(reference);
        global::OpenRA.Actor v6 = __cil_direct_06000675(this, __cil_bool_store(v1), v3, v5);
        return v6;
    }

    public OpenRA.Actor CreateActor(bool addToWorld, string name, OpenRA.Primitives.TypeDictionary initDict)
    {
        global::OpenRA.Actor v3 = __cil_newobj_06000028(this, name, initDict);
        int v5 = __cil_bool_load(addToWorld);
        __cil_callvirt_06000029(v3, __cil_bool_store(v5));
        return v3;
    }

    public void Add(OpenRA.Actor a)
    {
        // structural signature __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc bytes=151282E102091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 bytes=151281A9011220: class [System.Runtime]System.Action`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_79d909606f7376cd9dfac4a5203c4a361bb2b527 bytes=151280A1011284D4: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.INotifyAddedToWorld>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_1d743ee048a850ef26731cd80685410c909304e7 bytes=15128085011284D4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyAddedToWorld>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_79d909606f7376cd9dfac4a5203c4a361bb2b527 l0 = default;
        OpenRA.Traits.INotifyAddedToWorld l1 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = a;
        int v1 = 1;
        __cil_callvirt_06000016(v0, __cil_bool_store(v1));
        global::OpenRA.World v2 = this;
        __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc v3 = v2.actors;
        global::OpenRA.Actor v4 = a;
        int v5 = unchecked((int)(v4.ActorID));
        global::OpenRA.Actor v6 = a;
        __cil_callvirt_0A0005B9(v3, unchecked((uint)(v5)), v6);
        global::OpenRA.World v7 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v8 = v7.ActorAdded;
        global::OpenRA.Actor v9 = a;
        __cil_callvirt_0A0005BA(v8, v9);
        global::OpenRA.Actor v10 = a;
        __cil_ref_1d743ee048a850ef26731cd80685410c909304e7 v11 = __cil_callvirt_2B00015C(v10);
        __cil_ref_79d909606f7376cd9dfac4a5203c4a361bb2b527 v12 = __cil_callvirt_0A0005BB(v11);
        l0 = v12;
        try {
            IL_0031: ;
            goto IL_0041;
            IL_0033: ;
            __cil_ref_79d909606f7376cd9dfac4a5203c4a361bb2b527 v13 = l0;
            global::OpenRA.Traits.INotifyAddedToWorld v14 = __cil_callvirt_0A0005BC(v13);
            l1 = v14;
            global::OpenRA.Traits.INotifyAddedToWorld v15 = l1;
            global::OpenRA.Actor v16 = a;
            __cil_callvirt_060008E4(v15, v16);
            goto IL_0041;
            IL_0041: ;
            __cil_ref_79d909606f7376cd9dfac4a5203c4a361bb2b527 v17 = l0;
            int v18 = __cil_bool_load(__cil_callvirt_0A000018(v17));
            if (v18 != 0) {
                goto IL_0033;
            } else {
                goto IL_0049;
            }
            IL_0049: ;
            goto IL_0055;
        }
        finally {
            IL_004B: ;
            __cil_ref_79d909606f7376cd9dfac4a5203c4a361bb2b527 v19 = l0;
            if (v19 is null) {
                goto IL_0054;
            } else {
                goto IL_004E;
            }
            IL_004E: ;
            __cil_ref_79d909606f7376cd9dfac4a5203c4a361bb2b527 v20 = l0;
            __cil_callvirt_0A000017(v20);
            goto IL_0054;
            IL_0054: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0055: ;
        return;
    }

    public void Remove(OpenRA.Actor a)
    {
        // structural signature __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc bytes=151282E102091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 bytes=151281A9011220: class [System.Runtime]System.Action`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_dc9f7ce595d3c6b6cb8ea62ae5ba094e8f3eec06 bytes=151280A1011284D8: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.INotifyRemovedFromWorld>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a1352d6b4a1c6392cb0fa01d7efacf596931afb6 bytes=15128085011284D8: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyRemovedFromWorld>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_dc9f7ce595d3c6b6cb8ea62ae5ba094e8f3eec06 l0 = default;
        OpenRA.Traits.INotifyRemovedFromWorld l1 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = a;
        int v1 = 0;
        __cil_callvirt_06000016(v0, __cil_bool_store(v1));
        global::OpenRA.World v2 = this;
        __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc v3 = v2.actors;
        global::OpenRA.Actor v4 = a;
        int v5 = unchecked((int)(v4.ActorID));
        int v6 = __cil_bool_load(__cil_callvirt_0A0005BD(v3, unchecked((uint)(v5))));
        global::OpenRA.World v7 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v8 = v7.ActorRemoved;
        global::OpenRA.Actor v9 = a;
        __cil_callvirt_0A0005BA(v8, v9);
        global::OpenRA.Actor v10 = a;
        __cil_ref_a1352d6b4a1c6392cb0fa01d7efacf596931afb6 v11 = __cil_callvirt_2B00015D(v10);
        __cil_ref_dc9f7ce595d3c6b6cb8ea62ae5ba094e8f3eec06 v12 = __cil_callvirt_0A0005BE(v11);
        l0 = v12;
        try {
            IL_0031: ;
            goto IL_0041;
            IL_0033: ;
            __cil_ref_dc9f7ce595d3c6b6cb8ea62ae5ba094e8f3eec06 v13 = l0;
            global::OpenRA.Traits.INotifyRemovedFromWorld v14 = __cil_callvirt_0A0005BF(v13);
            l1 = v14;
            global::OpenRA.Traits.INotifyRemovedFromWorld v15 = l1;
            global::OpenRA.Actor v16 = a;
            __cil_callvirt_060008E5(v15, v16);
            goto IL_0041;
            IL_0041: ;
            __cil_ref_dc9f7ce595d3c6b6cb8ea62ae5ba094e8f3eec06 v17 = l0;
            int v18 = __cil_bool_load(__cil_callvirt_0A000018(v17));
            if (v18 != 0) {
                goto IL_0033;
            } else {
                goto IL_0049;
            }
            IL_0049: ;
            goto IL_0055;
        }
        finally {
            IL_004B: ;
            __cil_ref_dc9f7ce595d3c6b6cb8ea62ae5ba094e8f3eec06 v19 = l0;
            if (v19 is null) {
                goto IL_0054;
            } else {
                goto IL_004E;
            }
            IL_004E: ;
            __cil_ref_dc9f7ce595d3c6b6cb8ea62ae5ba094e8f3eec06 v20 = l0;
            __cil_callvirt_0A000017(v20);
            goto IL_0054;
            IL_0054: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0055: ;
        return;
    }

    public void Add(OpenRA.Effects.IEffect e)
    {
        // structural signature __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 bytes=1512809D01128910: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 bytes=1512809D011282F8: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.ISync l0 = default;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v1 = this.effects;
        __cil_callvirt_0A0005C0(v1, e);
        global::OpenRA.Effects.ISpatiallyPartitionable v4 = ((object)e as OpenRA.Effects.ISpatiallyPartitionable);
        if (v4 is not null) {
            goto IL_0020;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v6 = this.unpartitionedEffects;
        __cil_callvirt_0A0005C0(v6, e);
        IL_0020: ;
        global::OpenRA.ISync v9 = ((object)e as OpenRA.ISync);
        l0 = v9;
        global::OpenRA.ISync v10 = l0;
        if (v10 is null) {
            goto IL_0036;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 v12 = this.syncedEffects;
        global::OpenRA.ISync v13 = l0;
        __cil_callvirt_0A0005C1(v12, v13);
        IL_0036: ;
        return;
    }

    public void Remove(OpenRA.Effects.IEffect e)
    {
        // structural signature __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 bytes=1512809D01128910: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 bytes=1512809D011282F8: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.ISync l0 = default;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v1 = this.effects;
        int v3 = __cil_bool_load(__cil_callvirt_0A0005C2(v1, e));
        global::OpenRA.Effects.ISpatiallyPartitionable v5 = ((object)e as OpenRA.Effects.ISpatiallyPartitionable);
        if (v5 is not null) {
            goto IL_0022;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v7 = this.unpartitionedEffects;
        int v9 = __cil_bool_load(__cil_callvirt_0A0005C2(v7, e));
        IL_0022: ;
        global::OpenRA.ISync v11 = ((object)e as OpenRA.ISync);
        l0 = v11;
        global::OpenRA.ISync v12 = l0;
        if (v12 is null) {
            goto IL_0039;
        } else {
            goto IL_002C;
        }
        IL_002C: ;
        __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 v14 = this.syncedEffects;
        global::OpenRA.ISync v15 = l0;
        int v16 = __cil_bool_load(__cil_callvirt_0A0005C3(v14, v15));
        IL_0039: ;
        return;
    }

    public void RemoveAll(System.Predicate<OpenRA.Effects.IEffect> predicate)
    {
        // structural signature __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 bytes=1512809D01128910: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 bytes=1512809D011282F8: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_438fe102c1a53b6f419389c4011aa2a95f13a59f bytes=1512813101128910: class [System.Runtime]System.Predicate`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2b718a30f58c7ab79f4d0d51bf2ae9ee6b5749fd bytes=15128131011282F8: class [System.Runtime]System.Predicate`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.World.__name_3C3E635F5F446973706C6179436C61737338395F30 v0 = __cil_newobj_06001199();
        v0.predicate = predicate;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v4 = this.effects;
        __cil_ref_438fe102c1a53b6f419389c4011aa2a95f13a59f v6 = v0.predicate;
        int v7 = __cil_callvirt_0A0005C4(v4, v6);
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v9 = this.unpartitionedEffects;
        nint v11 = __cil_ldftn_0600119A;
        __cil_ref_438fe102c1a53b6f419389c4011aa2a95f13a59f v12 = __cil_newobj_0A0005C5(v0, v11);
        int v13 = __cil_callvirt_0A0005C4(v9, v12);
        __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 v15 = this.syncedEffects;
        nint v17 = __cil_ldftn_0600119B;
        __cil_ref_2b718a30f58c7ab79f4d0d51bf2ae9ee6b5749fd v18 = __cil_newobj_0A0005C6(v0, v17);
        int v19 = __cil_callvirt_0A0005C7(v15, v18);
        return;
    }

    public void AddFrameEndTask(System.Action<OpenRA.World> a)
    {
        // structural signature __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 bytes=1512824501151281A901128328: class [System.Collections]System.Collections.Generic.Queue`1<class [System.Runtime]System.Action`1<class OpenRA.World>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 bytes=151281A901128328: class [System.Runtime]System.Action`1<class OpenRA.World>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 v1 = this.frameEndActions;
        __cil_callvirt_0A0005C8(v1, a);
        return;
    }

    public void add_ActorAdded(System.Action<OpenRA.Actor> value)
    {
        // structural signature __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 bytes=151281A9011220: class [System.Runtime]System.Action`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l1 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v1 = v0.ActorAdded;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v2 = l0;
        l1 = v2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v3 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Combine(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v6 = ((__cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v8 = ref v7.ActorAdded;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v9 = l2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v10 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v11 = __cil_methodspec_call_2B00015E(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v12 = l0;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public void remove_ActorAdded(System.Action<OpenRA.Actor> value)
    {
        // structural signature __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 bytes=151281A9011220: class [System.Runtime]System.Action`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l1 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v1 = v0.ActorAdded;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v2 = l0;
        l1 = v2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v3 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Remove(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v6 = ((__cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v8 = ref v7.ActorAdded;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v9 = l2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v10 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v11 = __cil_methodspec_call_2B00015E(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v12 = l0;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public void add_ActorRemoved(System.Action<OpenRA.Actor> value)
    {
        // structural signature __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 bytes=151281A9011220: class [System.Runtime]System.Action`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l1 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v1 = v0.ActorRemoved;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v2 = l0;
        l1 = v2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v3 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Combine(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v6 = ((__cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v8 = ref v7.ActorRemoved;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v9 = l2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v10 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v11 = __cil_methodspec_call_2B00015E(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v12 = l0;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public void remove_ActorRemoved(System.Action<OpenRA.Actor> value)
    {
        // structural signature __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 bytes=151281A9011220: class [System.Runtime]System.Action`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l0 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l1 = default;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 l2 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v1 = v0.ActorRemoved;
        l0 = v1;
        goto IL_0007;
        IL_0007: ;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v2 = l0;
        l1 = v2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v3 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v4 = value;
        __cil_type_01000131 v5 = System.Delegate.Remove(((__cil_type_01000131)(v3)), ((__cil_type_01000131)(v4)));
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v6 = ((__cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92)(object)v5);
        l2 = v6;
        global::OpenRA.World v7 = this;
        ref __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v8 = ref v7.ActorRemoved;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v9 = l2;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v10 = l1;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v11 = __cil_methodspec_call_2B00015E(ref v8, v9, v10);
        l0 = v11;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v12 = l0;
        __cil_ref_b909e15b15ed00226936b4ba5bd590abcd000f92 v13 = l1;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0007;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        return;
    }

    public bool get_Paused()
    {
        return this.__il_field_040004D4;
    }

    internal void set_Paused(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040004D4 = __cil_bool_store(v1);
        return;
    }

    public bool get_PredictedPaused()
    {
        return this.__il_field_040004D5;
    }

    internal void set_PredictedPaused(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040004D5 = __cil_bool_store(v1);
        return;
    }

    public int get_WorldTick()
    {
        int v1 = this.__il_field_040004D6;
        return v1;
    }

    private void set_WorldTick(int value)
    {
        this.__il_field_040004D6 = value;
        return;
    }

    internal void AddGameSaveTraitData(int traitIndex, OpenRA.MiniYaml yaml)
    {
        // structural signature __cil_ref_3ba3c2eb4b45baaaf28f22f74207c21f78b76303 bytes=151280890208128204: class [System.Collections]System.Collections.Generic.Dictionary`2<int32, class OpenRA.MiniYaml>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_3ba3c2eb4b45baaaf28f22f74207c21f78b76303 v1 = this.gameSaveTraitData;
        __cil_callvirt_0A0005C9(v1, traitIndex, yaml);
        return;
    }

    public void SetPauseState(bool paused)
    {
        OpenRA.World s3_0 = default;
        string s3_1 = default;
        OpenRA.World s4_0 = default;
        string s4_1 = default;
        OpenRA.World s5_0 = default;
        string s5_1 = default;
        string s5_2 = default;
        int v1 = __cil_bool_load(this.IsGameOver);
        if (v1 == 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        string v3 = __cil_ldstr_700075B8("PauseGame");
        int v4 = __cil_bool_load(paused);
        if (v4 != 0) {
            OpenRA.World e2_4_0 = this;
            string e2_4_1 = v3;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0019;
        } else {
            OpenRA.World e2_3_0 = this;
            string e2_3_1 = v3;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_0012;
        }
        IL_0012: ;
        string v5 = __cil_ldstr_700075CC("UnPause");
        OpenRA.World e3_5_0 = s3_0;
        string e3_5_1 = s3_1;
        string e3_5_2 = v5;
        s5_0 = e3_5_0;
        s5_1 = e3_5_1;
        s5_2 = e3_5_2;
        goto IL_001E;
        IL_0019: ;
        string v6 = __cil_ldstr_700075DC("Pause");
        OpenRA.World e4_5_0 = s4_0;
        string e4_5_1 = s4_1;
        string e4_5_2 = v6;
        s5_0 = e4_5_0;
        s5_1 = e4_5_1;
        s5_2 = e4_5_2;
        IL_001E: ;
        global::OpenRA.Order v8 = OpenRA.Order.FromTargetString(s5_1, s5_2, __cil_bool_store(0));
        __cil_direct_06000666(s5_0, v8);
        int v10 = __cil_bool_load(paused);
        this.PredictedPaused = __cil_bool_store(v10);
        return;
    }

    public void SetLocalPauseState(bool paused)
    {
        bool l0 = default;
        int v2 = __cil_bool_load(paused);
        l0 = __cil_bool_store(v2);
        this.PredictedPaused = __cil_bool_store(v2);
        int v3 = __cil_bool_load(l0);
        this.Paused = __cil_bool_store(v3);
        return;
    }

    public void Tick()
    {
        // structural signature __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc bytes=151282E102091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 bytes=1512809D01128910: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 bytes=1512824501151281A901128328: class [System.Collections]System.Collections.Generic.Queue`1<class [System.Runtime]System.Action`1<class OpenRA.World>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3ba3c2eb4b45baaaf28f22f74207c21f78b76303 bytes=151280890208128204: class [System.Collections]System.Collections.Generic.Dictionary`2<int32, class OpenRA.MiniYaml>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 bytes=151281A901128328: class [System.Runtime]System.Action`1<class OpenRA.World>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_b2a3341ad4f9fb9989a2be7eac7e4765a174f46b bytes=151181390208128204: valuetype [System.Collections]System.Collections.Generic.Dictionary`2/Enumerator<int32, class OpenRA.MiniYaml>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_0f9f8b6c038f49cd0feda53d742c9538bf9ef7fb bytes=151181110208128204: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<int32, class OpenRA.MiniYaml>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_d20abd862a03743d203318a38b489e656a2528c2 bytes=1511832C0112859C: valuetype OpenRA.TraitPair`1<class OpenRA.Traits.IGameSaveTraitData>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_08e2d05e1f41a42b2d6f96158df60e52680247bc bytes=151280A101128594: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.INotifyGameLoaded>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b bytes=1183AC: valuetype OpenRA.Support.PerfSample; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_c56200844a5aed0412f63930e21c022bc3cd126a bytes=151182E902091220: valuetype [System.Collections]System.Collections.Generic.SortedDictionary`2/ValueCollection/Enumerator<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_623ecb98a404eb317a998ca9197576d67d8fc6db bytes=151282E502091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2/ValueCollection<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c754051744aaeee86414e4ed910782a2bf342639 bytes=15128085011511832C0112859C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.TraitPair`1<class OpenRA.Traits.IGameSaveTraitData>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c79e9d012087cedb04af2f47fc9ff956203eacfd bytes=1512808501128594: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyGameLoaded>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 bytes=1512814D02122012849C: class [System.Runtime]System.Action`2<class OpenRA.Actor, class OpenRA.Traits.ITick>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_1f75606911d843cc345e932ad1f46cbc9f5bcd64 bytes=151281A901128910: class [System.Runtime]System.Action`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_038114041f9396d53bde85322ac2f427ccb8b18b bytes=1512808501128910: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C9 alias=__cil_enum_020000C9 underlying=int: global::@OpenRA.@WorldType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_b2a3341ad4f9fb9989a2be7eac7e4765a174f46b l0 = default;
        __cil_value_0f9f8b6c038f49cd0feda53d742c9538bf9ef7fb l1 = default;
        __cil_value_d20abd862a03743d203318a38b489e656a2528c2 l2 = default;
        __cil_ref_08e2d05e1f41a42b2d6f96158df60e52680247bc l3 = default;
        OpenRA.Traits.INotifyGameLoaded l4 = default;
        int l5 = default;
        __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b l6 = default;
        __cil_value_c56200844a5aed0412f63930e21c022bc3cd126a l7 = default;
        OpenRA.Actor l8 = default;
        OpenRA.World s32_0 = default;
        __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 s32_1 = default;
        OpenRA.World s33_0 = default;
        __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 s33_1 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        int v1 = __cil_bool_load(v0.wasLoadingGameSave);
        if (v1 == 0) {
            goto IL_00D8;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        global::OpenRA.World v2 = this;
        int v3 = __cil_bool_load(__cil_direct_06000663(v2));
        if (v3 != 0) {
            goto IL_00D8;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        global::OpenRA.World v4 = this;
        __cil_ref_3ba3c2eb4b45baaaf28f22f74207c21f78b76303 v5 = v4.gameSaveTraitData;
        __cil_value_b2a3341ad4f9fb9989a2be7eac7e4765a174f46b v6 = __cil_callvirt_0A0005CA(v5);
        l0 = v6;
        try {
            IL_0022: ;
            goto IL_006B;
            IL_0024: ;
            ref __cil_value_b2a3341ad4f9fb9989a2be7eac7e4765a174f46b v7 = ref l0;
            __cil_value_0f9f8b6c038f49cd0feda53d742c9538bf9ef7fb v8 = __cil_value_call_0A0005CB(ref v7);
            l1 = v8;
            global::OpenRA.World v9 = this;
            global::OpenRA.TraitDictionary v10 = v9.TraitDict;
            __cil_ref_c754051744aaeee86414e4ed910782a2bf342639 v11 = __cil_callvirt_2B00015F(v10);
            ref __cil_value_0f9f8b6c038f49cd0feda53d742c9538bf9ef7fb v12 = ref l1;
            int v13 = __cil_value_call_0A0005CC(ref v12);
            __cil_ref_c754051744aaeee86414e4ed910782a2bf342639 v14 = __cil_methodspec_call_2B000160(v11, v13);
            __cil_value_d20abd862a03743d203318a38b489e656a2528c2 v15 = __cil_methodspec_call_2B000161(v14);
            l2 = v15;
            __cil_value_d20abd862a03743d203318a38b489e656a2528c2 v16 = l2;
            global::OpenRA.Actor v17 = v16.Actor;
            if (v17 is not null) {
                goto IL_0053;
            } else {
                goto IL_0051;
            }
            IL_0051: ;
            goto IL_0084;
            IL_0053: ;
            __cil_value_d20abd862a03743d203318a38b489e656a2528c2 v18 = l2;
            global::OpenRA.Traits.IGameSaveTraitData v19 = v18.Trait;
            __cil_value_d20abd862a03743d203318a38b489e656a2528c2 v20 = l2;
            global::OpenRA.Actor v21 = v20.Actor;
            ref __cil_value_0f9f8b6c038f49cd0feda53d742c9538bf9ef7fb v22 = ref l1;
            global::OpenRA.MiniYaml v23 = __cil_value_call_0A0005CF(ref v22);
            __cil_callvirt_06000940(v19, v21, v23);
            goto IL_006B;
            IL_006B: ;
            ref __cil_value_b2a3341ad4f9fb9989a2be7eac7e4765a174f46b v24 = ref l0;
            int v25 = __cil_bool_load(__cil_value_call_0A0005D0(ref v24));
            if (v25 != 0) {
                goto IL_0024;
            } else {
                goto IL_0074;
            }
            IL_0074: ;
            goto IL_0084;
        }
        finally {
            IL_0076: ;
            ref __cil_value_b2a3341ad4f9fb9989a2be7eac7e4765a174f46b v26 = ref l0;
            __cil_constrained_1B000248_0A000017(ref v26);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0084: ;
        global::OpenRA.World v27 = this;
        __cil_ref_3ba3c2eb4b45baaaf28f22f74207c21f78b76303 v28 = v27.gameSaveTraitData;
        __cil_callvirt_0A0005D1(v28);
        global::OpenRA.Sound v29 = OpenRA.Game.Sound;
        int v30 = 0;
        __cil_callvirt_06000555(v29, __cil_bool_store(v30));
        global::OpenRA.World v31 = this;
        global::OpenRA.Actor v32 = v31.WorldActor;
        __cil_ref_c79e9d012087cedb04af2f47fc9ff956203eacfd v33 = __cil_callvirt_2B000162(v32);
        __cil_ref_08e2d05e1f41a42b2d6f96158df60e52680247bc v34 = __cil_callvirt_0A0005D2(v33);
        l3 = v34;
        try {
            IL_00AB: ;
            goto IL_00BD;
            IL_00AD: ;
            __cil_ref_08e2d05e1f41a42b2d6f96158df60e52680247bc v35 = l3;
            global::OpenRA.Traits.INotifyGameLoaded v36 = __cil_callvirt_0A0005D3(v35);
            l4 = v36;
            global::OpenRA.Traits.INotifyGameLoaded v37 = l4;
            global::OpenRA.World v38 = this;
            __cil_callvirt_0600093D(v37, v38);
            goto IL_00BD;
            IL_00BD: ;
            __cil_ref_08e2d05e1f41a42b2d6f96158df60e52680247bc v39 = l3;
            int v40 = __cil_bool_load(__cil_callvirt_0A000018(v39));
            if (v40 != 0) {
                goto IL_00AD;
            } else {
                goto IL_00C5;
            }
            IL_00C5: ;
            goto IL_00D1;
        }
        finally {
            IL_00C7: ;
            __cil_ref_08e2d05e1f41a42b2d6f96158df60e52680247bc v41 = l3;
            if (v41 is null) {
                goto IL_00D0;
            } else {
                goto IL_00CA;
            }
            IL_00CA: ;
            __cil_ref_08e2d05e1f41a42b2d6f96158df60e52680247bc v42 = l3;
            __cil_callvirt_0A000017(v42);
            goto IL_00D0;
            IL_00D0: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_00D1: ;
        global::OpenRA.World v43 = this;
        int v44 = 0;
        v43.wasLoadingGameSave = __cil_bool_store(v44);
        goto IL_00D8;
        IL_00D8: ;
        global::OpenRA.World v45 = this;
        int v46 = __cil_bool_load(__cil_direct_06000680(v45));
        if (v46 != 0) {
            goto IL_01C6;
        } else {
            goto IL_00E3;
        }
        IL_00E3: ;
        global::OpenRA.World v47 = this;
        int v48 = unchecked((int)(v47.Type));
        int v49 = 1;
        if (unchecked((uint)v48) != unchecked((uint)v49)) {
            goto IL_0104;
        } else {
            goto IL_00EC;
        }
        IL_00EC: ;
        global::OpenRA.World v50 = this;
        global::OpenRA.GameSettings v51 = v50.gameSettings;
        int v52 = __cil_bool_load(v51.PauseShellmap);
        if (v52 == 0) {
            goto IL_0104;
        } else {
            goto IL_00F9;
        }
        IL_00F9: ;
        global::OpenRA.World v53 = this;
        int v54 = __cil_direct_06000684(v53);
        if (v54 != 0) {
            goto IL_01C6;
        } else {
            goto IL_0104;
        }
        IL_0104: ;
        global::OpenRA.World v55 = this;
        int v56 = __cil_direct_06000684(v55);
        l5 = v56;
        global::OpenRA.World v57 = this;
        int v58 = l5;
        int v59 = 1;
        int v60 = unchecked(v58 + v59);
        __cil_direct_06000685(v57, v60);
        ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v61 = ref l6;
        string v62 = __cil_ldstr_700075E8("tick_actors");
        __cil_value_ctor_060007AE(ref v61, v62);
        try {
            IL_0122: ;
            global::OpenRA.World v63 = this;
            __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc v64 = v63.actors;
            __cil_ref_623ecb98a404eb317a998ca9197576d67d8fc6db v65 = __cil_callvirt_0A0005D4(v64);
            __cil_value_c56200844a5aed0412f63930e21c022bc3cd126a v66 = __cil_callvirt_0A0005D5(v65);
            l7 = v66;
            try {
                IL_0134: ;
                goto IL_0146;
                IL_0136: ;
                ref __cil_value_c56200844a5aed0412f63930e21c022bc3cd126a v67 = ref l7;
                global::OpenRA.Actor v68 = __cil_value_call_0A0005D6(ref v67);
                l8 = v68;
                global::OpenRA.Actor v69 = l8;
                __cil_callvirt_0600002A(v69);
                goto IL_0146;
                IL_0146: ;
                ref __cil_value_c56200844a5aed0412f63930e21c022bc3cd126a v70 = ref l7;
                int v71 = __cil_bool_load(__cil_value_call_0A0005D7(ref v70));
                if (v71 != 0) {
                    goto IL_0136;
                } else {
                    goto IL_014F;
                }
                IL_014F: ;
                goto IL_016D;
            }
            finally {
                IL_0151: ;
                ref __cil_value_c56200844a5aed0412f63930e21c022bc3cd126a v72 = ref l7;
                __cil_constrained_1B00024E_0A000017(ref v72);
                goto __cil_finally_end_2;
                __cil_finally_end_2: ;
            }
        }
        finally {
            IL_015F: ;
            ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v73 = ref l6;
            __cil_constrained_020000EB_0A000017(ref v73);
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_016D: ;
        global::OpenRA.World v74 = this;
        __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 v75 = OpenRA.World.__name_3C3E63.__il_field_04000B52;
        if (v75 is not null) {
            OpenRA.World e31_33_0 = v74;
            __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 e31_33_1 = v75;
            s33_0 = e31_33_0;
            s33_1 = e31_33_1;
            goto IL_018D;
        } else {
            OpenRA.World e31_32_0 = v74;
            __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 e31_32_1 = v75;
            s32_0 = e31_32_0;
            s32_1 = e31_32_1;
            goto IL_0176;
        }
        IL_0176: ;
        global::OpenRA.World.__name_3C3E63 v76 = OpenRA.World.__name_3C3E63.__il_field_04000B4D;
        nint v77 = __cil_ldftn_06001194;
        __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 v78 = __cil_newobj_0A0005D8(v76, v77);
        OpenRA.World.__name_3C3E63.__il_field_04000B52 = v78;
        OpenRA.World e32_33_0 = s32_0;
        __cil_ref_80077e6c74554e5d660233b896f8dbb94f461d92 e32_33_1 = v78;
        s33_0 = e32_33_0;
        s33_1 = e32_33_1;
        goto IL_018D;
        IL_018D: ;
        string v79 = __cil_ldstr_70007600("Trait");
        __cil_methodspec_call_2B000163(s33_0, s33_1, v79);
        global::OpenRA.World v80 = this;
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v81 = v80.effects;
        global::OpenRA.World v82 = this;
        nint v83 = __cil_ldftn_0600069C;
        __cil_ref_1f75606911d843cc345e932ad1f46cbc9f5bcd64 v84 = __cil_newobj_0A0005D9(v82, v83);
        string v85 = __cil_ldstr_7000760C("Effect");
        __cil_methodspec_call_2B000164(((__cil_ref_038114041f9396d53bde85322ac2f427ccb8b18b)(v81)), v84, v85);
        goto IL_01C6;
        IL_01B5: ;
        global::OpenRA.World v86 = this;
        __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 v87 = v86.frameEndActions;
        __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 v88 = __cil_callvirt_0A0005DA(v87);
        global::OpenRA.World v89 = this;
        __cil_callvirt_0A0005DB(v88, v89);
        goto IL_01C6;
        IL_01C6: ;
        global::OpenRA.World v90 = this;
        __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 v91 = v90.frameEndActions;
        int v92 = __cil_callvirt_0A0005DC(v91);
        if (v92 != 0) {
            goto IL_01B5;
        } else {
            goto IL_01D3;
        }
        IL_01D3: ;
        return;
    }

    public void TickRender(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_ref_97898cd1e04d5dd5db42b0136bf97d57c4e7a86c bytes=1512814D0212201284A0: class [System.Runtime]System.Action`2<class OpenRA.Actor, class OpenRA.Traits.ITickRender>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.World.__name_3C3E635F5F446973706C6179436C6173733131345F30 v0 = __cil_newobj_06001195();
        v0.wr = wr;
        nint v5 = __cil_ldftn_06001196;
        __cil_ref_97898cd1e04d5dd5db42b0136bf97d57c4e7a86c v6 = __cil_newobj_0A0005DD(v0, v5);
        string v7 = __cil_ldstr_7000761A("Render");
        __cil_methodspec_call_2B000165(this, v6, v7);
        global::OpenRA.Traits.ScreenMap v9 = this.ScreenMap;
        __cil_callvirt_060009BC(v9);
        return;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Actor> get_Actors()
    {
        // structural signature __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc bytes=151282E102091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_623ecb98a404eb317a998ca9197576d67d8fc6db bytes=151282E502091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2/ValueCollection<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b bytes=15128085011220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc v1 = this.actors;
        __cil_ref_623ecb98a404eb317a998ca9197576d67d8fc6db v2 = __cil_callvirt_0A0005D4(v1);
        return v2;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Effects.IEffect> get_Effects()
    {
        // structural signature __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 bytes=1512809D01128910: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_038114041f9396d53bde85322ac2f427ccb8b18b bytes=1512808501128910: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v1 = this.effects;
        return v1;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Effects.IEffect> get_UnpartitionedEffects()
    {
        // structural signature __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 bytes=1512809D01128910: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_038114041f9396d53bde85322ac2f427ccb8b18b bytes=1512808501128910: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_732fd7fdaad4c18a8479d12a6c65f43ea3b7f2c0 v1 = this.unpartitionedEffects;
        return v1;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.ISync> get_SyncedEffects()
    {
        // structural signature __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 bytes=1512809D011282F8: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e6e5be7244330e9178d9ba97abe8633ef175a994 bytes=15128085011282F8: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_f6cc96cf76939fe1cf5f20aaff2d7a00f11447e5 v1 = this.syncedEffects;
        return v1;
    }

    public OpenRA.Actor GetActorById(uint actorId)
    {
        // structural signature __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc bytes=151282E102091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Actor l0 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc v1 = v0.actors;
        int v2 = unchecked((int)(actorId));
        ref global::OpenRA.Actor v3 = ref l0;
        int v4 = __cil_bool_load(__cil_callvirt_0A0005DE(v1, unchecked((uint)(v2)), ref v3));
        if (v4 == 0) {
            goto IL_0012;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Actor v5 = l0;
        return v5;
        IL_0012: ;
        return null;
    }

    internal uint NextAID()
    {
        uint l0 = default;
        int v2 = unchecked((int)(this.nextAID));
        l0 = unchecked((uint)(v2));
        int v3 = unchecked((int)(l0));
        int v5 = unchecked(v3 + 1);
        this.nextAID = unchecked((uint)(v5));
        int v6 = unchecked((int)(l0));
        return unchecked((uint)(v6));
    }

    public int SyncHash()
    {
        // structural signature __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e bytes=1D128254: class OpenRA.Player[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b bytes=15128085011220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e6e5be7244330e9178d9ba97abe8633ef175a994 bytes=15128085011282F8: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 bytes=151280A1011220: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_966c27db6b3c1777f8c062d1f2bd991caa46f8b4 bytes=1D118934: valuetype OpenRA.Actor/SyncHash[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 bytes=118934: valuetype OpenRA.Actor/SyncHash; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7eca42789813071368d706e5ac9f7e41e5aadbad bytes=151280A1011282F8: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.ISync>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        int l1 = default;
        __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 l2 = default;
        OpenRA.Actor l3 = default;
        __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 l4 = default;
        OpenRA.Actor l5 = default;
        __cil_ref_966c27db6b3c1777f8c062d1f2bd991caa46f8b4 l6 = default;
        int l7 = default;
        __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 l8 = default;
        __cil_ref_7eca42789813071368d706e5ac9f7e41e5aadbad l9 = default;
        OpenRA.ISync l10 = default;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e l11 = default;
        int l12 = default;
        OpenRA.Player l13 = default;
        IL_0000: ;
        int v0 = 0;
        l0 = v0;
        int v1 = 0;
        l1 = v1;
        global::OpenRA.World v2 = this;
        __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b v3 = __cil_direct_0600068B(v2);
        __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v4 = __cil_callvirt_0A00003B(v3);
        l2 = v4;
        try {
            IL_0010: ;
            goto IL_0031;
            IL_0012: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v5 = l2;
            global::OpenRA.Actor v6 = __cil_callvirt_0A00003A(v5);
            l3 = v6;
            int v7 = l1;
            int v8 = l0;
            int v9 = 1;
            int v10 = unchecked(v8 + v9);
            l0 = v10;
            int v11 = 1;
            global::OpenRA.Actor v12 = l3;
            int v13 = unchecked((int)(v12.ActorID));
            int v14 = unchecked(v11 + v13);
            int v15 = unchecked(v8 * v14);
            global::OpenRA.Actor v16 = l3;
            int v17 = OpenRA.Sync.HashActor(v16);
            int v18 = unchecked(v15 * v17);
            int v19 = unchecked(v7 + v18);
            l1 = v19;
            goto IL_0031;
            IL_0031: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v20 = l2;
            int v21 = __cil_bool_load(__cil_callvirt_0A000018(v20));
            if (v21 != 0) {
                goto IL_0012;
            } else {
                goto IL_0039;
            }
            IL_0039: ;
            goto IL_0045;
        }
        finally {
            IL_003B: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v22 = l2;
            if (v22 is null) {
                goto IL_0044;
            } else {
                goto IL_003E;
            }
            IL_003E: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v23 = l2;
            __cil_callvirt_0A000017(v23);
            goto IL_0044;
            IL_0044: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0045: ;
        global::OpenRA.World v24 = this;
        __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b v25 = __cil_methodspec_call_2B000166(v24);
        __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v26 = __cil_callvirt_0A00003B(v25);
        l4 = v26;
        try {
            IL_0052: ;
            goto IL_009E;
            IL_0054: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v27 = l4;
            global::OpenRA.Actor v28 = __cil_callvirt_0A00003A(v27);
            l5 = v28;
            global::OpenRA.Actor v29 = l5;
            __cil_ref_966c27db6b3c1777f8c062d1f2bd991caa46f8b4 v30 = __cil_callvirt_06000027(v29);
            l6 = v30;
            int v31 = 0;
            l7 = v31;
            goto IL_0096;
            IL_006B: ;
            __cil_ref_966c27db6b3c1777f8c062d1f2bd991caa46f8b4 v32 = l6;
            int v33 = l7;
            __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 v34 = __cil_ldelem_0200024D(v32, v33);
            l8 = v34;
            int v35 = l1;
            int v36 = l0;
            int v37 = 1;
            int v38 = unchecked(v36 + v37);
            l0 = v38;
            int v39 = 1;
            global::OpenRA.Actor v40 = l5;
            int v41 = unchecked((int)(v40.ActorID));
            int v42 = unchecked(v39 + v41);
            int v43 = unchecked(v36 * v42);
            ref __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 v44 = ref l8;
            int v45 = __cil_direct_06000F51(ref v44);
            int v46 = unchecked(v43 * v45);
            int v47 = unchecked(v35 + v46);
            l1 = v47;
            int v48 = l7;
            int v49 = 1;
            int v50 = unchecked(v48 + v49);
            l7 = v50;
            goto IL_0096;
            IL_0096: ;
            int v51 = l7;
            __cil_ref_966c27db6b3c1777f8c062d1f2bd991caa46f8b4 v52 = l6;
            nint v53 = unchecked((nint)(v52.LongLength));
            int v54 = unchecked((int)(v53));
            if (v51 < v54) {
                goto IL_006B;
            } else {
                goto IL_009E;
            }
            IL_009E: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v55 = l4;
            int v56 = __cil_bool_load(__cil_callvirt_0A000018(v55));
            if (v56 != 0) {
                goto IL_0054;
            } else {
                goto IL_00A7;
            }
            IL_00A7: ;
            goto IL_00B5;
        }
        finally {
            IL_00A9: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v57 = l4;
            if (v57 is null) {
                goto IL_00B4;
            } else {
                goto IL_00AD;
            }
            IL_00AD: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v58 = l4;
            __cil_callvirt_0A000017(v58);
            goto IL_00B4;
            IL_00B4: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_00B5: ;
        global::OpenRA.World v59 = this;
        __cil_ref_e6e5be7244330e9178d9ba97abe8633ef175a994 v60 = __cil_direct_0600068E(v59);
        __cil_ref_7eca42789813071368d706e5ac9f7e41e5aadbad v61 = __cil_callvirt_0A0005DF(v60);
        l9 = v61;
        try {
            IL_00C2: ;
            goto IL_00DD;
            IL_00C4: ;
            __cil_ref_7eca42789813071368d706e5ac9f7e41e5aadbad v62 = l9;
            global::OpenRA.ISync v63 = __cil_callvirt_0A0005E0(v62);
            l10 = v63;
            int v64 = l1;
            int v65 = l0;
            int v66 = 1;
            int v67 = unchecked(v65 + v66);
            l0 = v67;
            global::OpenRA.ISync v68 = l10;
            int v69 = OpenRA.Sync.Hash(v68);
            int v70 = unchecked(v65 * v69);
            int v71 = unchecked(v64 + v70);
            l1 = v71;
            goto IL_00DD;
            IL_00DD: ;
            __cil_ref_7eca42789813071368d706e5ac9f7e41e5aadbad v72 = l9;
            int v73 = __cil_bool_load(__cil_callvirt_0A000018(v72));
            if (v73 != 0) {
                goto IL_00C4;
            } else {
                goto IL_00E6;
            }
            IL_00E6: ;
            goto IL_00F4;
        }
        finally {
            IL_00E8: ;
            __cil_ref_7eca42789813071368d706e5ac9f7e41e5aadbad v74 = l9;
            if (v74 is null) {
                goto IL_00F3;
            } else {
                goto IL_00EC;
            }
            IL_00EC: ;
            __cil_ref_7eca42789813071368d706e5ac9f7e41e5aadbad v75 = l9;
            __cil_callvirt_0A000017(v75);
            goto IL_00F3;
            IL_00F3: ;
            goto __cil_finally_end_2;
            __cil_finally_end_2: ;
        }
        IL_00F4: ;
        int v76 = l1;
        global::OpenRA.World v77 = this;
        global::OpenRA.Support.MersenneTwister v78 = v77.SharedRandom;
        int v79 = v78.Last;
        int v80 = unchecked(v76 + v79);
        l1 = v80;
        global::OpenRA.World v81 = this;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v82 = v81.Players;
        l11 = v82;
        int v83 = 0;
        l12 = v83;
        goto IL_012F;
        IL_010F: ;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v84 = l11;
        int v85 = l12;
        global::OpenRA.Player v86 = v84[v85];
        l13 = v86;
        global::OpenRA.Player v87 = l13;
        int v88 = __cil_bool_load(__cil_callvirt_06000470(v87));
        if (v88 == 0) {
            goto IL_0129;
        } else {
            goto IL_011F;
        }
        IL_011F: ;
        int v89 = l1;
        global::OpenRA.Player v90 = l13;
        int v91 = OpenRA.Sync.HashPlayer(v90);
        int v92 = unchecked(v89 + v91);
        l1 = v92;
        goto IL_0129;
        IL_0129: ;
        int v93 = l12;
        int v94 = 1;
        int v95 = unchecked(v93 + v94);
        l12 = v95;
        goto IL_012F;
        IL_012F: ;
        int v96 = l12;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v97 = l11;
        nint v98 = unchecked((nint)(v97.LongLength));
        int v99 = unchecked((int)(v98));
        if (v96 < v99) {
            goto IL_010F;
        } else {
            goto IL_0137;
        }
        IL_0137: ;
        int v100 = l1;
        return v100;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.TraitPair<T>> ActorsWithTrait<T>()
    {
        // generic body context type-owner=0x020000CA type-arity=0 method-owner=0x06000692 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_ae7c77d91b84d9c6930f45c646dde307b1be55d3 bytes=15128085011511832C011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.TraitPair`1<!!0>>; type-owner=0x00000000 method-owner=0x06000692; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.TraitDictionary v1 = this.TraitDict;
        __cil_ref_ae7c77d91b84d9c6930f45c646dde307b1be55d3 v2 = __cil_callvirt_2B000167(v1);
        return v2;
    }

    public void ApplyToActorsWithTraitTimed<T>(System.Action<OpenRA.Actor, T> action, string text)
    {
        // generic body context type-owner=0x020000CA type-arity=0 method-owner=0x06000693 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_ae38f085610b95d0f5f5c26076f668754cea41f4 bytes=1512814D0212201E00: class [System.Runtime]System.Action`2<class OpenRA.Actor, !!0>; type-owner=0x00000000 method-owner=0x06000693; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.TraitDictionary v1 = this.TraitDict;
        __cil_callvirt_2B000168(v1, action, text);
        return;
    }

    public void ApplyToActorsWithTrait<T>(System.Action<OpenRA.Actor, T> action)
    {
        // generic body context type-owner=0x020000CA type-arity=0 method-owner=0x06000694 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_5ce2992737918382b7aca13775936a775ae09815 bytes=1512814D0212201E00: class [System.Runtime]System.Action`2<class OpenRA.Actor, !!0>; type-owner=0x00000000 method-owner=0x06000694; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.TraitDictionary v1 = this.TraitDict;
        __cil_callvirt_2B000169(v1, action);
        return;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Actor> ActorsHavingTrait<T>()
    {
        // generic body context type-owner=0x020000CA type-arity=0 method-owner=0x06000695 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b bytes=15128085011220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.TraitDictionary v1 = this.TraitDict;
        __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b v2 = __cil_callvirt_2B00016A(v1);
        return v2;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Actor> ActorsHavingTrait<T>(System.Func<T, bool> predicate)
    {
        // generic body context type-owner=0x020000CA type-arity=0 method-owner=0x06000696 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b bytes=15128085011220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_414ab30eeeb39adb42fb5aad1380168ecfaf5022 bytes=151280C9021E0002: class [System.Runtime]System.Func`2<!!0, bool>; type-owner=0x00000000 method-owner=0x06000696; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.TraitDictionary v1 = this.TraitDict;
        __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b v3 = __cil_callvirt_2B00016B(v1, predicate);
        return v3;
    }

    public void OnPlayerWinStateChanged(OpenRA.Player player)
    {
        // structural signature __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde bytes=118165: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000093 alias=__cil_enum_02000093 underlying=int: global::@OpenRA.@WinState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.GameInformation.Player l0 = default;
        global::OpenRA.GameInformation v1 = this.gameInfo;
        global::OpenRA.GameInformation.Player v3 = __cil_callvirt_060001A1(v1, player);
        l0 = v3;
        global::OpenRA.GameInformation.Player v4 = l0;
        if (v4 is null) {
            goto IL_0027;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.GameInformation.Player v5 = l0;
        int v7 = unchecked((int)(player.WinState));
        v5.Outcome = unchecked((__cil_enum_02000093)(v7));
        global::OpenRA.GameInformation.Player v8 = l0;
        __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde v9 = System.DateTime.get_UtcNow();
        v8.OutcomeTimestampUtc = v9;
        IL_0027: ;
        return;
    }

    internal void OnClientDisconnected(int clientId)
    {
        // structural signature __cil_ref_4d4cf0f5bdcc68db8d5ce0220793e384cdf0a85d bytes=1512808501128254: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Player>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e bytes=1D128254: class OpenRA.Player[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_557db442904a745f0b670309064abd91f74946d5 bytes=1D128648: class OpenRA.Traits.INotifyPlayerDisconnected[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3ad532436e80196729fcd2ec50d9c1c293f561e2 bytes=151280A101128254: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Player>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 bytes=151280C90212825402: class [System.Runtime]System.Func`2<class OpenRA.Player, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.World.__name_3C3E635F5F446973706C6179436C6173733133335F30 l0 = default;
        __cil_ref_3ad532436e80196729fcd2ec50d9c1c293f561e2 l1 = default;
        __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 l2 = default;
        OpenRA.Player l3 = default;
        OpenRA.GameInformation.Player l4 = default;
        __cil_ref_557db442904a745f0b670309064abd91f74946d5 l5 = default;
        int l6 = default;
        OpenRA.Traits.INotifyPlayerDisconnected l7 = default;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e l8 = default;
        int l9 = default;
        OpenRA.Player l10 = default;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e s1_0 = default;
        __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 s1_1 = default;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e s2_0 = default;
        __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 s2_1 = default;
        IL_0000: ;
        global::OpenRA.World.__name_3C3E635F5F446973706C6179436C6173733133335F30 v0 = __cil_newobj_06001197();
        l0 = v0;
        global::OpenRA.World.__name_3C3E635F5F446973706C6179436C6173733133335F30 v1 = l0;
        int v2 = clientId;
        v1.clientId = v2;
        global::OpenRA.World v3 = this;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v4 = v3.Players;
        global::OpenRA.World.__name_3C3E635F5F446973706C6179436C6173733133335F30 v5 = l0;
        __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 v6 = v5.__il_field_04000B55;
        if (v6 is not null) {
            __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e e0_2_0 = v4;
            __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 e0_2_1 = v6;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_0032;
        } else {
            __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e e0_1_0 = v4;
            __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 e0_1_1 = v6;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_001C;
        }
        IL_001C: ;
        global::OpenRA.World.__name_3C3E635F5F446973706C6179436C6173733133335F30 v7 = l0;
        global::OpenRA.World.__name_3C3E635F5F446973706C6179436C6173733133335F30 v8 = l0;
        nint v9 = __cil_ldftn_06001198;
        __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 v10 = __cil_newobj_0A000310(v8, v9);
        l2 = v10;
        v7.__il_field_04000B55 = v10;
        __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 v11 = l2;
        __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e e1_2_0 = s1_0;
        __cil_ref_588c826c59555bc098149c6c8ef178d5ef9e0650 e1_2_1 = v11;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        goto IL_0032;
        IL_0032: ;
        __cil_ref_4d4cf0f5bdcc68db8d5ce0220793e384cdf0a85d v12 = __cil_methodspec_call_2B00011B(((__cil_ref_4d4cf0f5bdcc68db8d5ce0220793e384cdf0a85d)(s2_0)), s2_1);
        __cil_ref_3ad532436e80196729fcd2ec50d9c1c293f561e2 v13 = __cil_callvirt_0A0005E1(v12);
        l1 = v13;
        try {
            IL_003D: ;
            goto IL_00C7;
            IL_0042: ;
            __cil_ref_3ad532436e80196729fcd2ec50d9c1c293f561e2 v14 = l1;
            global::OpenRA.Player v15 = __cil_callvirt_0A0005E2(v14);
            l3 = v15;
            global::OpenRA.World v16 = this;
            __cil_ref_557db442904a745f0b670309064abd91f74946d5 v17 = v16.notifyDisconnected;
            l5 = v17;
            int v18 = 0;
            l6 = v18;
            goto IL_0071;
            IL_0056: ;
            __cil_ref_557db442904a745f0b670309064abd91f74946d5 v19 = l5;
            int v20 = l6;
            global::OpenRA.Traits.INotifyPlayerDisconnected v21 = v19[v20];
            l7 = v21;
            global::OpenRA.Traits.INotifyPlayerDisconnected v22 = l7;
            global::OpenRA.World v23 = this;
            global::OpenRA.Actor v24 = v23.WorldActor;
            global::OpenRA.Player v25 = l3;
            __cil_callvirt_06000992(v22, v24, v25);
            int v26 = l6;
            int v27 = 1;
            int v28 = unchecked(v26 + v27);
            l6 = v28;
            goto IL_0071;
            IL_0071: ;
            int v29 = l6;
            __cil_ref_557db442904a745f0b670309064abd91f74946d5 v30 = l5;
            nint v31 = unchecked((nint)(v30.LongLength));
            int v32 = unchecked((int)(v31));
            if (v29 < v32) {
                goto IL_0056;
            } else {
                goto IL_0079;
            }
            IL_0079: ;
            global::OpenRA.World v33 = this;
            __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v34 = v33.Players;
            l8 = v34;
            int v35 = 0;
            l9 = v35;
            goto IL_009B;
            IL_0086: ;
            __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v36 = l8;
            int v37 = l9;
            global::OpenRA.Player v38 = v36[v37];
            l10 = v38;
            global::OpenRA.Player v39 = l10;
            global::OpenRA.Player v40 = l3;
            __cil_callvirt_0600047D(v39, v40);
            int v41 = l9;
            int v42 = 1;
            int v43 = unchecked(v41 + v42);
            l9 = v43;
            goto IL_009B;
            IL_009B: ;
            int v44 = l9;
            __cil_ref_e7b714f58024a9b56579bf3b4cf2ccf95d80ab8e v45 = l8;
            nint v46 = unchecked((nint)(v45.LongLength));
            int v47 = unchecked((int)(v46));
            if (v44 < v47) {
                goto IL_0086;
            } else {
                goto IL_00A3;
            }
            IL_00A3: ;
            global::OpenRA.World v48 = this;
            global::OpenRA.GameInformation v49 = v48.gameInfo;
            global::OpenRA.Player v50 = l3;
            global::OpenRA.GameInformation.Player v51 = __cil_callvirt_060001A1(v49, v50);
            l4 = v51;
            global::OpenRA.GameInformation.Player v52 = l4;
            if (v52 is null) {
                goto IL_00C7;
            } else {
                goto IL_00B5;
            }
            IL_00B5: ;
            global::OpenRA.GameInformation.Player v53 = l4;
            global::OpenRA.World v54 = this;
            global::OpenRA.Network.OrderManager v55 = v54.OrderManager;
            int v56 = __cil_callvirt_06000C96(v55);
            v53.DisconnectFrame = v56;
            goto IL_00C7;
            IL_00C7: ;
            __cil_ref_3ad532436e80196729fcd2ec50d9c1c293f561e2 v57 = l1;
            int v58 = __cil_bool_load(__cil_callvirt_0A000018(v57));
            if (v58 != 0) {
                goto IL_0042;
            } else {
                goto IL_00D2;
            }
            IL_00D2: ;
            goto IL_00DE;
        }
        finally {
            IL_00D4: ;
            __cil_ref_3ad532436e80196729fcd2ec50d9c1c293f561e2 v59 = l1;
            if (v59 is null) {
                goto IL_00DD;
            } else {
                goto IL_00D7;
            }
            IL_00D7: ;
            __cil_ref_3ad532436e80196729fcd2ec50d9c1c293f561e2 v60 = l1;
            __cil_callvirt_0A000017(v60);
            goto IL_00DD;
            IL_00DD: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00DE: ;
        return;
    }

    public void RequestGameSave(string filename)
    {
        // structural signature __cil_value_d20abd862a03743d203318a38b489e656a2528c2 bytes=1511832C0112859C: valuetype OpenRA.TraitPair`1<class OpenRA.Traits.IGameSaveTraitData>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_c754051744aaeee86414e4ed910782a2bf342639 bytes=15128085011511832C0112859C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.TraitPair`1<class OpenRA.Traits.IGameSaveTraitData>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5f433ed43b4ab3892b07614c25293492708593b5 bytes=151280A1011511832C0112859C: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.TraitPair`1<class OpenRA.Traits.IGameSaveTraitData>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed bytes=1512809D01128200: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.MiniYamlNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465 bytes=1512808501128200: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.MiniYamlNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        __cil_ref_5f433ed43b4ab3892b07614c25293492708593b5 l1 = default;
        __cil_value_d20abd862a03743d203318a38b489e656a2528c2 l2 = default;
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed l3 = default;
        __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed l4 = default;
        IL_0000: ;
        int v0 = 0;
        l0 = v0;
        global::OpenRA.World v1 = this;
        global::OpenRA.TraitDictionary v2 = v1.TraitDict;
        __cil_ref_c754051744aaeee86414e4ed910782a2bf342639 v3 = __cil_callvirt_2B00015F(v2);
        __cil_ref_5f433ed43b4ab3892b07614c25293492708593b5 v4 = __cil_callvirt_0A0005E3(v3);
        l1 = v4;
        try {
            IL_0013: ;
            goto IL_0071;
            IL_0015: ;
            __cil_ref_5f433ed43b4ab3892b07614c25293492708593b5 v5 = l1;
            __cil_value_d20abd862a03743d203318a38b489e656a2528c2 v6 = __cil_callvirt_0A0005E4(v5);
            l2 = v6;
            __cil_value_d20abd862a03743d203318a38b489e656a2528c2 v7 = l2;
            global::OpenRA.Traits.IGameSaveTraitData v8 = v7.Trait;
            __cil_value_d20abd862a03743d203318a38b489e656a2528c2 v9 = l2;
            global::OpenRA.Actor v10 = v9.Actor;
            __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v11 = __cil_callvirt_0600093F(v8, v10);
            l3 = v11;
            __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v12 = l3;
            if (v12 is null) {
                goto IL_006D;
            } else {
                goto IL_0031;
            }
            IL_0031: ;
            __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v13 = __cil_newobj_0A000123();
            int v14 = l0;
            string v15 = OpenRA.Exts.ToStringInvariant(v14);
            string v16 = __cil_ldstr_700005EE("");
            __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v17 = l3;
            global::OpenRA.MiniYaml v18 = __cil_newobj_060003ED(v16, v17);
            global::OpenRA.MiniYamlNode v19 = __cil_newobj_060003DF(v15, v18, null);
            __cil_callvirt_0A000124(v13, v19);
            l4 = v13;
            global::OpenRA.World v20 = this;
            string v21 = __cil_ldstr_70007628("GameSaveTraitData");
            __cil_ref_f220f2744e081cfe29899ff190afa332490a39ed v22 = l4;
            string v23 = OpenRA.MiniYamlExts.WriteToString(((__cil_ref_4c96ecbee9280009c682cfbb5832e82e0a518465)(v22)));
            int v24 = 1;
            global::OpenRA.Order v25 = OpenRA.Order.FromTargetString(v21, v23, __cil_bool_store(v24));
            __cil_direct_06000666(v20, v25);
            goto IL_006D;
            IL_006D: ;
            int v26 = l0;
            int v27 = 1;
            int v28 = unchecked(v26 + v27);
            l0 = v28;
            goto IL_0071;
            IL_0071: ;
            __cil_ref_5f433ed43b4ab3892b07614c25293492708593b5 v29 = l1;
            int v30 = __cil_bool_load(__cil_callvirt_0A000018(v29));
            if (v30 != 0) {
                goto IL_0015;
            } else {
                goto IL_0079;
            }
            IL_0079: ;
            goto IL_0085;
        }
        finally {
            IL_007B: ;
            __cil_ref_5f433ed43b4ab3892b07614c25293492708593b5 v31 = l1;
            if (v31 is null) {
                goto IL_0084;
            } else {
                goto IL_007E;
            }
            IL_007E: ;
            __cil_ref_5f433ed43b4ab3892b07614c25293492708593b5 v32 = l1;
            __cil_callvirt_0A000017(v32);
            goto IL_0084;
            IL_0084: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0085: ;
        global::OpenRA.World v33 = this;
        string v34 = __cil_ldstr_7000764C("CreateGameSave");
        string v35 = filename;
        int v36 = 1;
        global::OpenRA.Order v37 = OpenRA.Order.FromTargetString(v34, v35, __cil_bool_store(v36));
        __cil_direct_06000666(v33, v37);
        return;
    }

    public virtual void Dispose()
    {
        // structural signature __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc bytes=151282E102091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 bytes=1512824501151281A901128328: class [System.Collections]System.Collections.Generic.Queue`1<class [System.Runtime]System.Action`1<class OpenRA.World>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 bytes=151281A901128328: class [System.Runtime]System.Action`1<class OpenRA.World>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_623ecb98a404eb317a998ca9197576d67d8fc6db bytes=151282E502091220: class [System.Collections]System.Collections.Generic.SortedDictionary`2/ValueCollection<uint32, class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b bytes=15128085011220: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 bytes=151280A1011220: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C9 alias=__cil_enum_020000C9 underlying=int: global::@OpenRA.@WorldType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 l0 = default;
        OpenRA.Actor l1 = default;
        OpenRA.Orders.IOrderGenerator s1_0 = default;
        OpenRA.Orders.IOrderGenerator s2_0 = default;
        IL_0000: ;
        global::OpenRA.World v0 = this;
        int v1 = 1;
        v0.Disposing = __cil_bool_store(v1);
        global::OpenRA.World v2 = this;
        global::OpenRA.Orders.IOrderGenerator v3 = __cil_direct_06000667(v2);
        if (v3 is not null) {
            OpenRA.Orders.IOrderGenerator e0_2_0 = v3;
            s2_0 = e0_2_0;
            goto IL_0013;
        } else {
            OpenRA.Orders.IOrderGenerator e0_1_0 = v3;
            s1_0 = e0_1_0;
            goto IL_0010;
        }
        IL_0010: ;
        goto IL_0018;
        IL_0013: ;
        __cil_callvirt_06000C28(s2_0);
        goto IL_0018;
        IL_0018: ;
        global::OpenRA.World v4 = this;
        __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 v5 = v4.frameEndActions;
        __cil_callvirt_0A0005E5(v5);
        global::OpenRA.Sound v6 = OpenRA.Game.Sound;
        __cil_callvirt_0600054E(v6);
        global::OpenRA.Sound v7 = OpenRA.Game.Sound;
        __cil_callvirt_06000567(v7);
        global::OpenRA.World v8 = this;
        int v9 = __cil_bool_load(__cil_direct_06000663(v8));
        if (v9 == 0) {
            goto IL_004A;
        } else {
            goto IL_003F;
        }
        IL_003F: ;
        global::OpenRA.Sound v10 = OpenRA.Game.Sound;
        int v11 = 0;
        __cil_callvirt_06000555(v10, __cil_bool_store(v11));
        goto IL_004A;
        IL_004A: ;
        global::OpenRA.World v12 = this;
        __cil_ref_e81202458430bd7741d3854e2abcc1061de01ffc v13 = v12.actors;
        __cil_ref_623ecb98a404eb317a998ca9197576d67d8fc6db v14 = __cil_callvirt_0A0005D4(v13);
        __cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b v15 = __cil_methodspec_call_2B00016C(((__cil_ref_a6ec2f6981000c2a99ef19fea467b24f9612653b)(v14)));
        __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v16 = __cil_callvirt_0A00003B(v15);
        l0 = v16;
        try {
            IL_0060: ;
            goto IL_006F;
            IL_0062: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v17 = l0;
            global::OpenRA.Actor v18 = __cil_callvirt_0A00003A(v17);
            l1 = v18;
            global::OpenRA.Actor v19 = l1;
            __cil_callvirt_0600003B(v19);
            goto IL_006F;
            IL_006F: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v20 = l0;
            int v21 = __cil_bool_load(__cil_callvirt_0A000018(v20));
            if (v21 != 0) {
                goto IL_0062;
            } else {
                goto IL_0077;
            }
            IL_0077: ;
            goto IL_0094;
        }
        finally {
            IL_0079: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v22 = l0;
            if (v22 is null) {
                goto IL_0082;
            } else {
                goto IL_007C;
            }
            IL_007C: ;
            __cil_ref_708646de4343f50a8e221cb9ff712bc05d2134a5 v23 = l0;
            __cil_callvirt_0A000017(v23);
            goto IL_0082;
            IL_0082: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0083: ;
        global::OpenRA.World v24 = this;
        __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 v25 = v24.frameEndActions;
        __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 v26 = __cil_callvirt_0A0005DA(v25);
        global::OpenRA.World v27 = this;
        __cil_callvirt_0A0005DB(v26, v27);
        goto IL_0094;
        IL_0094: ;
        global::OpenRA.World v28 = this;
        __cil_ref_bc5f79cd55640d08514be02e5be4ab5ca1d4ea30 v29 = v28.frameEndActions;
        int v30 = __cil_callvirt_0A0005DC(v29);
        if (v30 != 0) {
            goto IL_0083;
        } else {
            goto IL_00A1;
        }
        IL_00A1: ;
        global::OpenRA.World v31 = this;
        int v32 = unchecked((int)(v31.Type));
        int v33 = 1;
        if (unchecked((uint)v32) != unchecked((uint)v33)) {
            goto IL_00B5;
        } else {
            goto IL_00AA;
        }
        IL_00AA: ;
        global::OpenRA.World v34 = this;
        global::OpenRA.Network.OrderManager v35 = v34.OrderManager;
        __cil_callvirt_06000CAC(v35);
        goto IL_00B5;
        IL_00B5: ;
        global::OpenRA.World v36 = this;
        global::OpenRA.Map v37 = v36.Map;
        __cil_callvirt_06000344(v37);
        OpenRA.Game.FinishBenchmark();
        return;
    }

    public void OutOfSync()
    {
        __cil_direct_06000658(this);
        this.ReplayTimestep = 0;
        return;
    }

    // Metadata name: <Tick>b__113_1
    private void TickLambda113_1(OpenRA.Effects.IEffect e)
    {
        __cil_callvirt_06000F2C(e, this);
        return;
    }
    // property OpenRA.Network.Session LobbyInfo { get: get_LobbyInfo; }
    // property OpenRA.Player LocalPlayer { get: get_LocalPlayer; set: set_LocalPlayer; }
    // property bool IsGameOver { get: get_IsGameOver; set: set_IsGameOver; }
    // property OpenRA.Player RenderPlayer { get: get_RenderPlayer; set: set_RenderPlayer; }
    // property bool IsReplay { get: get_IsReplay; }
    // property bool IsLoadingGameSave { get: get_IsLoadingGameSave; }
    // property int GameSaveLoadingPercentage { get: get_GameSaveLoadingPercentage; }
    // property OpenRA.Orders.IOrderGenerator OrderGenerator { get: get_OrderGenerator; set: set_OrderGenerator; }
    // property bool RulesContainTemporaryBlocker { get: get_RulesContainTemporaryBlocker; }
    // property bool Paused { get: get_Paused; set: set_Paused; }
    // property bool PredictedPaused { get: get_PredictedPaused; set: set_PredictedPaused; }
    // property int WorldTick { get: get_WorldTick; set: set_WorldTick; }
    // property System.Collections.Generic.IEnumerable<OpenRA.Actor> Actors { get: get_Actors; }
    // property System.Collections.Generic.IEnumerable<OpenRA.Effects.IEffect> Effects { get: get_Effects; }
    // property System.Collections.Generic.IEnumerable<OpenRA.Effects.IEffect> UnpartitionedEffects { get: get_UnpartitionedEffects; }
    // property System.Collections.Generic.IEnumerable<OpenRA.ISync> SyncedEffects { get: get_SyncedEffects; }
    // event System.Action<OpenRA.Player> RenderPlayerChanged { add: add_RenderPlayerChanged; remove: remove_RenderPlayerChanged; }
    // event System.Action GameOver { add: add_GameOver; remove: remove_GameOver; }
    // event System.Action<OpenRA.Actor> ActorAdded { add: add_ActorAdded; remove: remove_ActorAdded; }
    // event System.Action<OpenRA.Actor> ActorRemoved { add: add_ActorRemoved; remove: remove_ActorRemoved; }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.World.__name_3C3E63 __il_field_04000B4D;
        public static System.Func<System.Collections.Generic.KeyValuePair<string, OpenRA.ActorInfo>, bool> __il_field_04000B4E;
        public static System.Action __il_field_04000B4F;
        public static System.Action<OpenRA.Actor> __il_field_04000B50;
        public static System.Action<OpenRA.Actor> __il_field_04000B51;
        public static System.Action<OpenRA.Actor, OpenRA.Traits.ITick> __il_field_04000B52;

        static __name_3C3E63()
        {
            global::OpenRA.World.__name_3C3E63 v0 = __cil_newobj_0600118F();
            OpenRA.World.__name_3C3E63.__il_field_04000B4D = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <.ctor>b__75_0
        internal bool CtorLambda75_0(System.Collections.Generic.KeyValuePair<string, OpenRA.ActorInfo> a)
        {
            // structural signature __cil_value_f7197820921af6d8a7121851c0cd045781e3c1d1 bytes=15118111020E128084: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_f7197820921af6d8a7121851c0cd045781e3c1d1 v0 = ref a;
            global::OpenRA.ActorInfo v1 = __cil_value_call_0A000BDF(ref v0);
            int v2 = __cil_bool_load(__cil_callvirt_2B000283(v1));
            return __cil_bool_store(v2);
        }

        // Metadata name: <.ctor>b__75_1
        internal void CtorLambda75_1()
        {
            return;
        }

        // Metadata name: <.ctor>b__75_2
        internal void CtorLambda75_2(OpenRA.Actor _)
        {
            return;
        }

        // Metadata name: <.ctor>b__75_3
        internal void CtorLambda75_3(OpenRA.Actor _)
        {
            return;
        }

        // Metadata name: <Tick>b__113_0
        internal void TickLambda113_0(OpenRA.Actor actor, OpenRA.Traits.ITick trait)
        {
            __cil_callvirt_060008D2(trait, actor);
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733131345F30
    {
        public OpenRA.Graphics.WorldRenderer wr;

        public __name_3C3E635F5F446973706C6179436C6173733131345F30() : base()
        {
            return;
        }

        // Metadata name: <TickRender>b__0
        internal void TickRenderLambda0(OpenRA.Actor actor, OpenRA.Traits.ITickRender trait)
        {
            global::OpenRA.Graphics.WorldRenderer v2 = this.wr;
            __cil_callvirt_060008D3(trait, v2, actor);
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733133335F30
    {
        public int clientId;
        public System.Func<OpenRA.Player, bool> __il_field_04000B55;

        public __name_3C3E635F5F446973706C6179436C6173733133335F30() : base()
        {
            return;
        }

        // Metadata name: <OnClientDisconnected>b__0
        internal bool OnClientDisconnectedLambda0(OpenRA.Player p)
        {
            int v1 = p.ClientIndex;
            int v3 = this.clientId;
            if (unchecked((uint)v1) != unchecked((uint)v3)) {
                return false;
            } else {
                goto IL_000E;
            }
            IL_000E: ;
            global::OpenRA.PlayerReference v5 = p.PlayerReference;
            return v5.Playable;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737338395F30
    {
        public System.Predicate<OpenRA.Effects.IEffect> predicate;

        public __name_3C3E635F5F446973706C6179436C61737338395F30() : base()
        {
            return;
        }

        // Metadata name: <RemoveAll>b__0
        internal bool RemoveAllLambda0(OpenRA.Effects.IEffect e)
        {
            // structural signature __cil_ref_438fe102c1a53b6f419389c4011aa2a95f13a59f bytes=1512813101128910: class [System.Runtime]System.Predicate`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_438fe102c1a53b6f419389c4011aa2a95f13a59f v1 = this.predicate;
            return __cil_callvirt_0A000BE0(v1, e);
        }

        // Metadata name: <RemoveAll>b__1
        internal bool RemoveAllLambda1(OpenRA.ISync e)
        {
            // structural signature __cil_ref_438fe102c1a53b6f419389c4011aa2a95f13a59f bytes=1512813101128910: class [System.Runtime]System.Predicate`1<class OpenRA.Effects.IEffect>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_438fe102c1a53b6f419389c4011aa2a95f13a59f v1 = this.predicate;
            global::OpenRA.Effects.IEffect v3 = ((OpenRA.Effects.IEffect)(object)e);
            return __cil_callvirt_0A000BE0(v1, v3);
        }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Algorithms, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Algorithms, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Csp, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Csp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.Process, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.Process, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.Watcher, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.Watcher, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Channels, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Threading.Channels, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.ILGeneration, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.ILGeneration, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.Lightweight, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.Lightweight, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Loader, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Loader, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq.Expressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq.Expressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Sockets, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Sockets, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Numerics, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Numerics, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.StackTrace, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.StackTrace, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.NameResolution, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.NameResolution, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 7; exact references retained; see --details for identities and provenance.
