namespace OpenRA;

public sealed class Actor : OpenRA.Scripting.IScriptBindable, OpenRA.Scripting.IScriptNotifyBind, Eluant.ObjectBinding.ILuaTableBinding, Eluant.ObjectBinding.ILuaEqualityBinding, Eluant.ObjectBinding.ILuaToStringBinding, System.IEquatable<OpenRA.Actor>, System.IDisposable
{
    public const int InvalidConditionToken = -1;
    public readonly OpenRA.ActorInfo Info;
    public readonly OpenRA.World World;
    public readonly uint ActorID;
    private OpenRA.Player __il_field_04000012;
    private bool __il_field_04000013;
    private bool __il_field_04000014;
    private bool __il_field_04000015;
    private OpenRA.Activities.Activity currentActivity;
    public int Generation;
    public OpenRA.Actor ReplacedByActor;
    private readonly OpenRA.Traits.IEffectiveOwner __il_field_04000019;
    private readonly OpenRA.Traits.IOccupySpace __il_field_0400001A;
    private readonly OpenRA.Traits.ITargetable[] __il_field_0400001B;
    private readonly System.Collections.Generic.IEnumerable<OpenRA.Traits.ITargetablePositions> __il_field_0400001C;
    private readonly OpenRA.Traits.ICrushable[] crushables;
    private readonly System.Collections.Generic.Dictionary<string, OpenRA.Actor.ConditionState> conditionStates;
    private readonly System.Collections.Generic.Dictionary<int, string> conditionTokens;
    private int nextConditionToken;
    private readonly System.Collections.Generic.Dictionary<string, int> conditionCache;
    private readonly System.Collections.Generic.IReadOnlyDictionary<string, int> readOnlyConditionCache;
    private readonly OpenRA.Actor.SyncHash[] __il_field_04000023;
    private readonly OpenRA.Traits.IFacing facing;
    private readonly OpenRA.Traits.IHealth health;
    private readonly OpenRA.Traits.IResolveOrder[] resolveOrders;
    private readonly OpenRA.Traits.IRenderModifier[] renderModifiers;
    private readonly OpenRA.Traits.IRender[] renders;
    private readonly OpenRA.Traits.IMouseBounds[] mouseBounds;
    private readonly OpenRA.Traits.IVisibilityModifier[] visibilityModifiers;
    private readonly OpenRA.Traits.IDefaultVisibility defaultVisibility;
    private readonly OpenRA.Traits.INotifyBecomingIdle[] becomingIdles;
    private readonly OpenRA.Traits.INotifyIdle[] tickIdles;
    private readonly System.Collections.Generic.IEnumerable<OpenRA.WPos> enabledTargetableWorldPositions;
    private bool created;
    private System.Lazy<OpenRA.Scripting.ScriptActorInterface> luaInterface;

    public OpenRA.Player get_Owner()
    {
        global::OpenRA.Player v1 = this.__il_field_04000012;
        return v1;
    }

    internal void set_Owner(OpenRA.Player value)
    {
        this.__il_field_04000012 = value;
        return;
    }

    public bool get_IsInWorld()
    {
        return this.__il_field_04000013;
    }

    internal void set_IsInWorld(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000013 = __cil_bool_store(v1);
        return;
    }

    public bool get_WillDispose()
    {
        return this.__il_field_04000014;
    }

    private void set_WillDispose(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000014 = __cil_bool_store(v1);
        return;
    }

    public bool get_Disposed()
    {
        return this.__il_field_04000015;
    }

    private void set_Disposed(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000015 = __cil_bool_store(v1);
        return;
    }

    public OpenRA.Activities.Activity get_CurrentActivity()
    {
        global::OpenRA.Activities.Activity v1 = this.currentActivity;
        global::OpenRA.Activities.Activity v2 = OpenRA.Activities.Activity.SkipDoneActivities(v1);
        return v2;
    }

    private void set_CurrentActivity(OpenRA.Activities.Activity value)
    {
        this.currentActivity = value;
        return;
    }

    public OpenRA.Traits.IEffectiveOwner get_EffectiveOwner()
    {
        global::OpenRA.Traits.IEffectiveOwner v1 = this.__il_field_04000019;
        return v1;
    }

    public OpenRA.Traits.IOccupySpace get_OccupiesSpace()
    {
        global::OpenRA.Traits.IOccupySpace v1 = this.__il_field_0400001A;
        return v1;
    }

    public OpenRA.Traits.ITargetable[] get_Targetables()
    {
        // structural signature __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 bytes=1D128608: class OpenRA.Traits.ITargetable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v1 = this.__il_field_0400001B;
        return v1;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Traits.ITargetablePositions> get_EnabledTargetablePositions()
    {
        // structural signature __cil_ref_2346978f7494e8bf84b6d50d0622e3173e1d839a bytes=151280850112860C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.ITargetablePositions>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_2346978f7494e8bf84b6d50d0622e3173e1d839a v1 = this.__il_field_0400001C;
        return v1;
    }

    public OpenRA.Traits.ICrushable[] get_Crushables()
    {
        // structural signature __cil_ref_ad5ecc0125aa991b1999f94321e70044752ce38f bytes=1D128650: class OpenRA.Traits.ICrushable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_ad5ecc0125aa991b1999f94321e70044752ce38f s1_0 = default;
        __cil_ref_ad5ecc0125aa991b1999f94321e70044752ce38f s2_0 = default;
        __cil_ref_ad5ecc0125aa991b1999f94321e70044752ce38f v1 = this.crushables;
        if (v1 is not null) {
            __cil_ref_ad5ecc0125aa991b1999f94321e70044752ce38f e0_2_0 = v1;
            s2_0 = e0_2_0;
            goto IL_002A;
        } else {
            __cil_ref_ad5ecc0125aa991b1999f94321e70044752ce38f e0_1_0 = v1;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        string v2 = __cil_ldstr_700000E8("Crushables for ");
        global::OpenRA.ActorInfo v4 = this.Info;
        string v5 = v4.Name;
        string v6 = __cil_ldstr_70000108(" are not initialized.");
        string v7 = System.String.Concat(v2, v5, v6);
        global::System.InvalidOperationException v8 = __cil_newobj_0A00006E(v7);
        throw v8;
        IL_002A: ;
        return s2_0;
    }

    public bool get_IsIdle()
    {
        global::OpenRA.Activities.Activity v1 = this.CurrentActivity;
        return (System.Object.ReferenceEquals(v1, null));
    }

    public bool get_IsDead()
    {
        int v1 = __cil_bool_load(this.Disposed);
        if (v1 != 0) {
            return true;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Traits.IHealth v3 = this.health;
        if (v3 is null) {
            return false;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Traits.IHealth v5 = this.health;
        return __cil_callvirt_060008CB(v5);
    }

    public OpenRA.CPos get_Location()
    {
        // structural signature __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 bytes=1124: valuetype OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Traits.IOccupySpace v1 = this.OccupiesSpace;
        __cil_value_30059ebebb961282a8c4af28277466cac453b6d7 v2 = __cil_callvirt_0600092B(v1);
        return v2;
    }

    public OpenRA.WPos get_CenterPosition()
    {
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Traits.IOccupySpace v1 = this.OccupiesSpace;
        __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v2 = __cil_callvirt_0600092A(v1);
        return v2;
    }

    public OpenRA.WRot get_Orientation()
    {
        // structural signature __cil_value_2bd80a14ff0ddfc3a957cd46afaa9ec2c0393bac bytes=118340: valuetype OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        OpenRA.Traits.IFacing s1_0 = default;
        OpenRA.Traits.IFacing s2_0 = default;
        global::OpenRA.Traits.IFacing v1 = this.facing;
        if (v1 is not null) {
            OpenRA.Traits.IFacing e0_2_0 = v1;
            s2_0 = e0_2_0;
            goto IL_0010;
        } else {
            OpenRA.Traits.IFacing e0_1_0 = v1;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        __cil_value_2bd80a14ff0ddfc3a957cd46afaa9ec2c0393bac v2 = OpenRA.WRot.None;
        return v2;
        IL_0010: ;
        __cil_value_2bd80a14ff0ddfc3a957cd46afaa9ec2c0393bac v3 = __cil_callvirt_06000932(s2_0);
        return v3;
    }

    internal OpenRA.Actor.SyncHash[] get_SyncHashes()
    {
        // structural signature __cil_ref_966c27db6b3c1777f8c062d1f2bd991caa46f8b4 bytes=1D118934: valuetype OpenRA.Actor/SyncHash[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_966c27db6b3c1777f8c062d1f2bd991caa46f8b4 v1 = this.__il_field_04000023;
        return v1;
    }

    internal Actor(OpenRA.World world, string name, OpenRA.Primitives.TypeDictionary initDict)
    {
        // IL fallback: generic virtual dispatch needs runtime lookup-order modeling
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 73, 6F, 00, 00, 0A, 7D, 1E, 00, 00, 04, 02, 73, 70, 00, 00, 0A, 7D, 1F, 00, 00, 04, 02, 17]
        // .code-bytes IL_0018: [7D, 20, 00, 00, 04, 02, 73, 71, 00, 00, 0A, 7D, 21, 00, 00, 04, 02, 28, 5B, 00, 00, 0A, 05, 6F]
        // .code-bytes IL_0030: [01, 00, 00, 2B, 7E, 38, 09, 00, 04, 25, 2D, 17, 26, 7E, 37, 09, 00, 04, FE, 06, 55, 0F, 00, 06]
        // .code-bytes IL_0048: [73, 72, 00, 00, 0A, 25, 80, 38, 09, 00, 04, 28, 02, 00, 00, 2B, 7E, 39, 09, 00, 04, 25, 2D, 17]
        // .code-bytes IL_0060: [26, 7E, 37, 09, 00, 04, FE, 06, 56, 0F, 00, 06, 73, 74, 00, 00, 0A, 25, 80, 39, 09, 00, 04, 28]
        // .code-bytes IL_0078: [03, 00, 00, 2B, 0A, 06, 2C, 20, 72, 34, 01, 00, 70, 06, 6F, 76, 00, 00, 0A, 6F, 77, 00, 00, 0A]
        // .code-bytes IL_0090: [72, 64, 01, 00, 70, 28, 6D, 00, 00, 0A, 73, 78, 00, 00, 0A, 7A, 02, 05, 73, 7B, 02, 00, 06, 0B]
        // .code-bytes IL_00A8: [02, 02, 7B, 21, 00, 00, 04, 73, 79, 00, 00, 0A, 7D, 22, 00, 00, 04, 02, 03, 7D, 10, 00, 00, 04]
        // .code-bytes IL_00C0: [02, 03, 6F, 90, 06, 00, 06, 7D, 11, 00, 00, 04, 07, 6F, 04, 00, 00, 2B, 0C, 08, 2C, 0D, 02, 08]
        // .code-bytes IL_00D8: [03, 6F, 99, 02, 00, 06, 28, 14, 00, 00, 06, 04, 39, 04, 03, 00, 00, 04, 6F, 7A, 00, 00, 0A, 10]
        // .code-bytes IL_00F0: [02, 03, 7B, C5, 04, 00, 04, 6F, F1, 02, 00, 06, 7B, 94, 00, 00, 04, 04, 6F, 90, 04, 00, 06, 2D]
        // .code-bytes IL_0108: [11, 72, 68, 01, 00, 70, 04, 28, 7B, 00, 00, 0A, 73, 7C, 00, 00, 0A, 7A, 02, 03, 7B, C5, 04, 00]
        // .code-bytes IL_0120: [04, 6F, F1, 02, 00, 06, 7B, 94, 00, 00, 04, 04, 6F, 93, 04, 00, 06, 7D, 0F, 00, 00, 04, 73, 7D]
        // .code-bytes IL_0138: [00, 00, 0A, 0D, 73, 7E, 00, 00, 0A, 13, 04, 73, 7F, 00, 00, 0A, 13, 05, 73, 80, 00, 00, 0A, 13]
        // .code-bytes IL_0150: [06, 73, 81, 00, 00, 0A, 13, 07, 73, 82, 00, 00, 0A, 13, 08, 73, 83, 00, 00, 0A, 13, 09, 73, 84]
        // .code-bytes IL_0168: [00, 00, 0A, 13, 0A, 73, 85, 00, 00, 0A, 13, 0B, 73, 86, 00, 00, 0A, 13, 0C, 73, 87, 00, 00, 0A]
        // .code-bytes IL_0180: [13, 0D, 02, 7B, 0F, 00, 00, 04, 6F, A6, 01, 00, 06, 6F, 88, 00, 00, 0A, 13, 0F, 38, 7A, 01, 00]
        // .code-bytes IL_0198: [00, 11, 0F, 6F, 89, 00, 00, 0A, 13, 10, 11, 10, 07, 6F, 34, 09, 00, 06, 13, 11, 02, 11, 11, 28]
        // .code-bytes IL_01B0: [3A, 00, 00, 06, 11, 11, 75, 53, 01, 00, 02, 13, 12, 11, 12, 2C, 08, 02, 11, 12, 7D, 1A, 00, 00]
        // .code-bytes IL_01C8: [04, 11, 11, 75, 3E, 01, 00, 02, 13, 13, 11, 13, 2C, 08, 02, 11, 13, 7D, 19, 00, 00, 04, 11, 11]
        // .code-bytes IL_01E0: [75, 57, 01, 00, 02, 13, 14, 11, 14, 2C, 08, 02, 11, 14, 7D, 24, 00, 00, 04, 11, 11, 75, 22, 01]
        // .code-bytes IL_01F8: [00, 02, 13, 15, 11, 15, 2C, 08, 02, 11, 15, 7D, 25, 00, 00, 04, 11, 11, 75, 31, 01, 00, 02, 13]
        // .code-bytes IL_0210: [16, 11, 16, 2C, 08, 09, 11, 16, 6F, 8A, 00, 00, 0A, 11, 11, 75, 47, 01, 00, 02, 13, 17, 11, 17]
        // .code-bytes IL_0228: [2C, 09, 11, 04, 11, 17, 6F, 8B, 00, 00, 0A, 11, 11, 75, 29, 01, 00, 02, 13, 18, 11, 18, 2C, 09]
        // .code-bytes IL_0240: [11, 05, 11, 18, 6F, 8C, 00, 00, 0A, 11, 11, 75, 2A, 01, 00, 02, 13, 19, 11, 19, 2C, 09, 11, 06]
        // .code-bytes IL_0258: [11, 19, 6F, 8D, 00, 00, 0A, 11, 11, 75, 45, 01, 00, 02, 13, 1A, 11, 1A, 2C, 09, 11, 07, 11, 1A]
        // .code-bytes IL_0270: [6F, 8E, 00, 00, 0A, 11, 11, 75, 44, 01, 00, 02, 13, 1B, 11, 1B, 2C, 08, 02, 11, 1B, 7D, 2B, 00]
        // .code-bytes IL_0288: [00, 04, 11, 11, 75, 6F, 01, 00, 02, 13, 1C, 11, 1C, 2C, 09, 11, 08, 11, 1C, 6F, 8F, 00, 00, 0A]
        // .code-bytes IL_02A0: [11, 11, 75, 70, 01, 00, 02, 13, 1D, 11, 1D, 2C, 09, 11, 09, 11, 1D, 6F, 90, 00, 00, 0A, 11, 11]
        // .code-bytes IL_02B8: [75, 82, 01, 00, 02, 13, 1E, 11, 1E, 2C, 09, 11, 0A, 11, 1E, 6F, 91, 00, 00, 0A, 11, 11, 75, 83]
        // .code-bytes IL_02D0: [01, 00, 02, 13, 1F, 11, 1F, 2C, 09, 11, 0B, 11, 1F, 6F, 92, 00, 00, 0A, 11, 11, 75, BE, 00, 00]
        // .code-bytes IL_02E8: [02, 13, 20, 11, 20, 2C, 0E, 11, 0C, 11, 20, 73, 50, 0F, 00, 06, 6F, 93, 00, 00, 0A, 11, 11, 75]
        // .code-bytes IL_0300: [94, 01, 00, 02, 13, 21, 11, 21, 2C, 09, 11, 0D, 11, 21, 6F, 94, 00, 00, 0A, 11, 0F, 6F, 18, 00]
        // .code-bytes IL_0318: [00, 0A, 3A, 7A, FE, FF, FF, DE, 0C, 11, 0F, 2C, 07, 11, 0F, 6F, 17, 00, 00, 0A, DC, 02, 09, 6F]
        // .code-bytes IL_0330: [95, 00, 00, 0A, 7D, 26, 00, 00, 04, 02, 11, 04, 6F, 96, 00, 00, 0A, 7D, 27, 00, 00, 04, 02, 11]
        // .code-bytes IL_0348: [05, 6F, 97, 00, 00, 0A, 7D, 28, 00, 00, 04, 02, 11, 06, 6F, 98, 00, 00, 0A, 7D, 29, 00, 00, 04]
        // .code-bytes IL_0360: [02, 11, 07, 6F, 99, 00, 00, 0A, 7D, 2A, 00, 00, 04, 02, 11, 08, 6F, 9A, 00, 00, 0A, 7D, 2C, 00]
        // .code-bytes IL_0378: [00, 04, 02, 11, 09, 6F, 9B, 00, 00, 0A, 7D, 2D, 00, 00, 04, 02, 11, 0A, 6F, 9C, 00, 00, 0A, 7D]
        // .code-bytes IL_0390: [1B, 00, 00, 04, 11, 0B, 6F, 9D, 00, 00, 0A, 13, 0E, 02, 11, 0E, 14, FE, 06, 05, 00, 00, 2B, 73]
        // .code-bytes IL_03A8: [9E, 00, 00, 0A, 28, 06, 00, 00, 2B, 7D, 1C, 00, 00, 04, 02, 02, 28, 20, 00, 00, 06, 02, FE, 06]
        // .code-bytes IL_03C0: [51, 00, 00, 06, 73, A0, 00, 00, 0A, 28, 07, 00, 00, 2B, 7D, 2E, 00, 00, 04, 02, 11, 0C, 6F, A2]
        // .code-bytes IL_03D8: [00, 00, 0A, 7D, 23, 00, 00, 04, 02, 11, 0D, 6F, A3, 00, 00, 0A, 7D, 1D, 00, 00, 04, 2A]
        // .local [0] class [System.Linq]System.Linq.IGrouping`2<class [System.Runtime]System.Type, class OpenRA.ISingleInstanceInit>
        // .local [1] class OpenRA.ActorInitializer
        // .local [2] class OpenRA.OwnerInit
        // .local [3] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IResolveOrder>
        // .local [4] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRenderModifier>
        // .local [5] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRender>
        // .local [6] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IMouseBounds>
        // .local [7] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IVisibilityModifier>
        // .local [8] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyBecomingIdle>
        // .local [9] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyIdle>
        // .local [10] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetable>
        // .local [11] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetablePositions>
        // .local [12] class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.Actor/SyncHash>
        // .local [13] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ICrushable>
        // .local [14] class OpenRA.Traits.ITargetablePositions[]
        // .local [15] class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.TraitInfo>
        // .local [16] class OpenRA.Traits.TraitInfo
        // .local [17] object
        // .local [18] class OpenRA.Traits.IOccupySpace
        // .local [19] class OpenRA.Traits.IEffectiveOwner
        // .local [20] class OpenRA.Traits.IFacing
        // .local [21] class OpenRA.Traits.IHealth
        // .local [22] class OpenRA.Traits.IResolveOrder
        // .local [23] class OpenRA.Traits.IRenderModifier
        // .local [24] class OpenRA.Traits.IRender
        // .local [25] class OpenRA.Traits.IMouseBounds
        // .local [26] class OpenRA.Traits.IVisibilityModifier
        // .local [27] class OpenRA.Traits.IDefaultVisibility
        // .local [28] class OpenRA.Traits.INotifyBecomingIdle
        // .local [29] class OpenRA.Traits.INotifyIdle
        // .local [30] class OpenRA.Traits.ITargetable
        // .local [31] class OpenRA.Traits.ITargetablePositions
        // .local [32] class OpenRA.ISync
        // .local [33] class OpenRA.Traits.ICrushable
        // IL_0000: ldarg.0 0
        // IL_0001: newobj 0x0A00006F class [System.Collections]System.Collections.Generic.Dictionary`2<string, class OpenRA.Actor/ConditionState>::.ctor
        // IL_0006: stfld 0x0400001E OpenRA.Actor::conditionStates
        // IL_000B: ldarg.0 0
        // IL_000C: newobj 0x0A000070 class [System.Collections]System.Collections.Generic.Dictionary`2<int32, string>::.ctor
        // IL_0011: stfld 0x0400001F OpenRA.Actor::conditionTokens
        // IL_0016: ldarg.0 0
        // IL_0017: ldc.i4.1 1
        // IL_0018: stfld 0x04000020 OpenRA.Actor::nextConditionToken
        // IL_001D: ldarg.0 0
        // IL_001E: newobj 0x0A000071 class [System.Collections]System.Collections.Generic.Dictionary`2<string, int32>::.ctor
        // IL_0023: stfld 0x04000021 OpenRA.Actor::conditionCache
        // IL_0028: ldarg.0 0
        // IL_0029: call 0x0A00005B [System.Runtime]System.Object::.ctor
        // IL_002E: ldarg.3 3
        // IL_002F: callvirt 0x2B000001 OpenRA.Primitives.TypeDictionary::WithInterface<class OpenRA.ISingleInstanceInit>
        // IL_0034: ldsfld 0x04000938 OpenRA.Actor/<>c::<>9__73_0
        // IL_0039: dup 
        // IL_003A: brtrue.s IL_0053
        // IL_003C: pop 
        // IL_003D: ldsfld 0x04000937 OpenRA.Actor/<>c::<>9
        // IL_0042: ldftn 0x06000F55 OpenRA.Actor/<>c::<.ctor>b__73_0
        // IL_0048: newobj 0x0A000072 class [System.Runtime]System.Func`2<class OpenRA.ISingleInstanceInit, class [System.Runtime]System.Type>::.ctor
        // IL_004D: dup 
        // IL_004E: stsfld 0x04000938 OpenRA.Actor/<>c::<>9__73_0
        // IL_0053: call 0x2B000002 [System.Linq]System.Linq.Enumerable::GroupBy<class OpenRA.ISingleInstanceInit, class [System.Runtime]System.Type>
        // IL_0058: ldsfld 0x04000939 OpenRA.Actor/<>c::<>9__73_1
        // IL_005D: dup 
        // IL_005E: brtrue.s IL_0077
        // IL_0060: pop 
        // IL_0061: ldsfld 0x04000937 OpenRA.Actor/<>c::<>9
        // IL_0066: ldftn 0x06000F56 OpenRA.Actor/<>c::<.ctor>b__73_1
        // IL_006C: newobj 0x0A000074 class [System.Runtime]System.Func`2<class [System.Linq]System.Linq.IGrouping`2<class [System.Runtime]System.Type, class OpenRA.ISingleInstanceInit>, bool>::.ctor
        // IL_0071: dup 
        // IL_0072: stsfld 0x04000939 OpenRA.Actor/<>c::<>9__73_1
        // IL_0077: call 0x2B000003 [System.Linq]System.Linq.Enumerable::FirstOrDefault<class [System.Linq]System.Linq.IGrouping`2<class [System.Runtime]System.Type, class OpenRA.ISingleInstanceInit>>
        // IL_007C: stloc.0 0
        // IL_007D: ldloc.0 0
        // IL_007E: brfalse.s IL_00A0
        // IL_0080: ldstr 0x70000134 [68, 117, 112, 108, 105, 99, 97, 116, 101, 32, 105, 110, 105, 116, 105, 97, 108, 105, 122, 101, 114, 32, 39] utf16-bytes=[44, 00, 75, 00, 70, 00, 6C, 00, 69, 00, 63, 00, 61, 00, 74, 00, 65, 00, 20, 00, 69, 00, 6E, 00, 69, 00, 74, 00, 69, 00, 61, 00, 6C, 00, 69, 00, 7A, 00, 65, 00, 72, 00, 20, 00, 27, 00] terminal-flag=Some(1)
        // IL_0085: ldloc.0 0
        // IL_0086: callvirt 0x0A000076 class [System.Linq]System.Linq.IGrouping`2<class [System.Runtime]System.Type, class OpenRA.ISingleInstanceInit>::get_Key
        // IL_008B: callvirt 0x0A000077 [System.Runtime]System.Reflection.MemberInfo::get_Name
        // IL_0090: ldstr 0x70000164 [39] utf16-bytes=[27, 00] terminal-flag=Some(1)
        // IL_0095: call 0x0A00006D [System.Runtime]System.String::Concat
        // IL_009A: newobj 0x0A000078 [System.Runtime]System.IO.InvalidDataException::.ctor
        // IL_009F: throw 
        // IL_00A0: ldarg.0 0
        // IL_00A1: ldarg.3 3
        // IL_00A2: newobj 0x0600027B OpenRA.ActorInitializer::.ctor
        // IL_00A7: stloc.1 1
        // IL_00A8: ldarg.0 0
        // IL_00A9: ldarg.0 0
        // IL_00AA: ldfld 0x04000021 OpenRA.Actor::conditionCache
        // IL_00AF: newobj 0x0A000079 class [System.ObjectModel]System.Collections.ObjectModel.ReadOnlyDictionary`2<string, int32>::.ctor
        // IL_00B4: stfld 0x04000022 OpenRA.Actor::readOnlyConditionCache
        // IL_00B9: ldarg.0 0
        // IL_00BA: ldarg.1 1
        // IL_00BB: stfld 0x04000010 OpenRA.Actor::World
        // IL_00C0: ldarg.0 0
        // IL_00C1: ldarg.1 1
        // IL_00C2: callvirt 0x06000690 OpenRA.World::NextAID
        // IL_00C7: stfld 0x04000011 OpenRA.Actor::ActorID
        // IL_00CC: ldloc.1 1
        // IL_00CD: callvirt 0x2B000004 OpenRA.ActorInitializer::GetOrDefault<class OpenRA.OwnerInit>
        // IL_00D2: stloc.2 2
        // IL_00D3: ldloc.2 2
        // IL_00D4: brfalse.s IL_00E3
        // IL_00D6: ldarg.0 0
        // IL_00D7: ldloc.2 2
        // IL_00D8: ldarg.1 1
        // IL_00D9: callvirt 0x06000299 OpenRA.OwnerInit::Value
        // IL_00DE: call 0x06000014 OpenRA.Actor::set_Owner
        // IL_00E3: ldarg.2 2
        // IL_00E4: brfalse IL_03ED
        // IL_00E9: ldarg.2 2
        // IL_00EA: callvirt 0x0A00007A [System.Runtime]System.String::ToLowerInvariant
        // IL_00EF: starg.s 2
        // IL_00F1: ldarg.1 1
        // IL_00F2: ldfld 0x040004C5 OpenRA.World::Map
        // IL_00F7: callvirt 0x060002F1 OpenRA.Map::get_Rules
        // IL_00FC: ldfld 0x04000094 OpenRA.Ruleset::Actors
        // IL_0101: ldarg.2 2
        // IL_0102: callvirt 0x06000490 OpenRA.ActorInfoDictionary::ContainsKey
        // IL_0107: brtrue.s IL_011A
        // IL_0109: ldstr 0x70000168 [78, 111, 32, 114, 117, 108, 101, 115, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 102, 111, 114, 32, 117, 110, 105, 116, 32] utf16-bytes=[4E, 00, 6F, 00, 20, 00, 72, 00, 75, 00, 6C, 00, 65, 00, 73, 00, 20, 00, 64, 00, 65, 00, 66, 00, 69, 00, 6E, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 75, 00, 6E, 00, 69, 00, 74, 00, 20, 00] terminal-flag=Some(0)
        // IL_010E: ldarg.2 2
        // IL_010F: call 0x0A00007B [System.Runtime]System.String::Concat
        // IL_0114: newobj 0x0A00007C [System.Runtime]System.NotImplementedException::.ctor
        // IL_0119: throw 
        // IL_011A: ldarg.0 0
        // IL_011B: ldarg.1 1
        // IL_011C: ldfld 0x040004C5 OpenRA.World::Map
        // IL_0121: callvirt 0x060002F1 OpenRA.Map::get_Rules
        // IL_0126: ldfld 0x04000094 OpenRA.Ruleset::Actors
        // IL_012B: ldarg.2 2
        // IL_012C: callvirt 0x06000493 OpenRA.ActorInfoDictionary::get_Item
        // IL_0131: stfld 0x0400000F OpenRA.Actor::Info
        // IL_0136: newobj 0x0A00007D class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IResolveOrder>::.ctor
        // IL_013B: stloc.3 3
        // IL_013C: newobj 0x0A00007E class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRenderModifier>::.ctor
        // IL_0141: stloc.s 4
        // IL_0143: newobj 0x0A00007F class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRender>::.ctor
        // IL_0148: stloc.s 5
        // IL_014A: newobj 0x0A000080 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IMouseBounds>::.ctor
        // IL_014F: stloc.s 6
        // IL_0151: newobj 0x0A000081 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IVisibilityModifier>::.ctor
        // IL_0156: stloc.s 7
        // IL_0158: newobj 0x0A000082 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyBecomingIdle>::.ctor
        // IL_015D: stloc.s 8
        // IL_015F: newobj 0x0A000083 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyIdle>::.ctor
        // IL_0164: stloc.s 9
        // IL_0166: newobj 0x0A000084 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetable>::.ctor
        // IL_016B: stloc.s 10
        // IL_016D: newobj 0x0A000085 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetablePositions>::.ctor
        // IL_0172: stloc.s 11
        // IL_0174: newobj 0x0A000086 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.Actor/SyncHash>::.ctor
        // IL_0179: stloc.s 12
        // IL_017B: newobj 0x0A000087 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ICrushable>::.ctor
        // IL_0180: stloc.s 13
        // IL_0182: ldarg.0 0
        // IL_0183: ldfld 0x0400000F OpenRA.Actor::Info
        // IL_0188: callvirt 0x060001A6 OpenRA.ActorInfo::TraitsInConstructOrder
        // IL_018D: callvirt 0x0A000088 class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.TraitInfo>::GetEnumerator
        // IL_0192: stloc.s 15
        // IL_0194: br IL_0313
        // IL_0199: ldloc.s 15
        // IL_019B: callvirt 0x0A000089 class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.TraitInfo>::get_Current
        // IL_01A0: stloc.s 16
        // IL_01A2: ldloc.s 16
        // IL_01A4: ldloc.1 1
        // IL_01A5: callvirt 0x06000934 OpenRA.Traits.TraitInfo::Create
        // IL_01AA: stloc.s 17
        // IL_01AC: ldarg.0 0
        // IL_01AD: ldloc.s 17
        // IL_01AF: call 0x0600003A OpenRA.Actor::AddTrait
        // IL_01B4: ldloc.s 17
        // IL_01B6: isinst 0x02000153 OpenRA.Traits.IOccupySpace
        // IL_01BB: stloc.s 18
        // IL_01BD: ldloc.s 18
        // IL_01BF: brfalse.s IL_01C9
        // IL_01C1: ldarg.0 0
        // IL_01C2: ldloc.s 18
        // IL_01C4: stfld 0x0400001A OpenRA.Actor::<OccupiesSpace>k__BackingField
        // IL_01C9: ldloc.s 17
        // IL_01CB: isinst 0x0200013E OpenRA.Traits.IEffectiveOwner
        // IL_01D0: stloc.s 19
        // IL_01D2: ldloc.s 19
        // IL_01D4: brfalse.s IL_01DE
        // IL_01D6: ldarg.0 0
        // IL_01D7: ldloc.s 19
        // IL_01D9: stfld 0x04000019 OpenRA.Actor::<EffectiveOwner>k__BackingField
        // IL_01DE: ldloc.s 17
        // IL_01E0: isinst 0x02000157 OpenRA.Traits.IFacing
        // IL_01E5: stloc.s 20
        // IL_01E7: ldloc.s 20
        // IL_01E9: brfalse.s IL_01F3
        // IL_01EB: ldarg.0 0
        // IL_01EC: ldloc.s 20
        // IL_01EE: stfld 0x04000024 OpenRA.Actor::facing
        // IL_01F3: ldloc.s 17
        // IL_01F5: isinst 0x02000122 OpenRA.Traits.IHealth
        // IL_01FA: stloc.s 21
        // IL_01FC: ldloc.s 21
        // IL_01FE: brfalse.s IL_0208
        // IL_0200: ldarg.0 0
        // IL_0201: ldloc.s 21
        // IL_0203: stfld 0x04000025 OpenRA.Actor::health
        // IL_0208: ldloc.s 17
        // IL_020A: isinst 0x02000131 OpenRA.Traits.IResolveOrder
        // IL_020F: stloc.s 22
        // IL_0211: ldloc.s 22
        // IL_0213: brfalse.s IL_021D
        // IL_0215: ldloc.3 3
        // IL_0216: ldloc.s 22
        // IL_0218: callvirt 0x0A00008A class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IResolveOrder>::Add
        // IL_021D: ldloc.s 17
        // IL_021F: isinst 0x02000147 OpenRA.Traits.IRenderModifier
        // IL_0224: stloc.s 23
        // IL_0226: ldloc.s 23
        // IL_0228: brfalse.s IL_0233
        // IL_022A: ldloc.s 4
        // IL_022C: ldloc.s 23
        // IL_022E: callvirt 0x0A00008B class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRenderModifier>::Add
        // IL_0233: ldloc.s 17
        // IL_0235: isinst 0x02000129 OpenRA.Traits.IRender
        // IL_023A: stloc.s 24
        // IL_023C: ldloc.s 24
        // IL_023E: brfalse.s IL_0249
        // IL_0240: ldloc.s 5
        // IL_0242: ldloc.s 24
        // IL_0244: callvirt 0x0A00008C class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRender>::Add
        // IL_0249: ldloc.s 17
        // IL_024B: isinst 0x0200012A OpenRA.Traits.IMouseBounds
        // IL_0250: stloc.s 25
        // IL_0252: ldloc.s 25
        // IL_0254: brfalse.s IL_025F
        // IL_0256: ldloc.s 6
        // IL_0258: ldloc.s 25
        // IL_025A: callvirt 0x0A00008D class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IMouseBounds>::Add
        // IL_025F: ldloc.s 17
        // IL_0261: isinst 0x02000145 OpenRA.Traits.IVisibilityModifier
        // IL_0266: stloc.s 26
        // IL_0268: ldloc.s 26
        // IL_026A: brfalse.s IL_0275
        // IL_026C: ldloc.s 7
        // IL_026E: ldloc.s 26
        // IL_0270: callvirt 0x0A00008E class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IVisibilityModifier>::Add
        // IL_0275: ldloc.s 17
        // IL_0277: isinst 0x02000144 OpenRA.Traits.IDefaultVisibility
        // IL_027C: stloc.s 27
        // IL_027E: ldloc.s 27
        // IL_0280: brfalse.s IL_028A
        // IL_0282: ldarg.0 0
        // IL_0283: ldloc.s 27
        // IL_0285: stfld 0x0400002B OpenRA.Actor::defaultVisibility
        // IL_028A: ldloc.s 17
        // IL_028C: isinst 0x0200016F OpenRA.Traits.INotifyBecomingIdle
        // IL_0291: stloc.s 28
        // IL_0293: ldloc.s 28
        // IL_0295: brfalse.s IL_02A0
        // IL_0297: ldloc.s 8
        // IL_0299: ldloc.s 28
        // IL_029B: callvirt 0x0A00008F class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyBecomingIdle>::Add
        // IL_02A0: ldloc.s 17
        // IL_02A2: isinst 0x02000170 OpenRA.Traits.INotifyIdle
        // IL_02A7: stloc.s 29
        // IL_02A9: ldloc.s 29
        // IL_02AB: brfalse.s IL_02B6
        // IL_02AD: ldloc.s 9
        // IL_02AF: ldloc.s 29
        // IL_02B1: callvirt 0x0A000090 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyIdle>::Add
        // IL_02B6: ldloc.s 17
        // IL_02B8: isinst 0x02000182 OpenRA.Traits.ITargetable
        // IL_02BD: stloc.s 30
        // IL_02BF: ldloc.s 30
        // IL_02C1: brfalse.s IL_02CC
        // IL_02C3: ldloc.s 10
        // IL_02C5: ldloc.s 30
        // IL_02C7: callvirt 0x0A000091 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetable>::Add
        // IL_02CC: ldloc.s 17
        // IL_02CE: isinst 0x02000183 OpenRA.Traits.ITargetablePositions
        // IL_02D3: stloc.s 31
        // IL_02D5: ldloc.s 31
        // IL_02D7: brfalse.s IL_02E2
        // IL_02D9: ldloc.s 11
        // IL_02DB: ldloc.s 31
        // IL_02DD: callvirt 0x0A000092 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetablePositions>::Add
        // IL_02E2: ldloc.s 17
        // IL_02E4: isinst 0x020000BE OpenRA.ISync
        // IL_02E9: stloc.s 32
        // IL_02EB: ldloc.s 32
        // IL_02ED: brfalse.s IL_02FD
        // IL_02EF: ldloc.s 12
        // IL_02F1: ldloc.s 32
        // IL_02F3: newobj 0x06000F50 OpenRA.Actor/SyncHash::.ctor
        // IL_02F8: callvirt 0x0A000093 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.Actor/SyncHash>::Add
        // IL_02FD: ldloc.s 17
        // IL_02FF: isinst 0x02000194 OpenRA.Traits.ICrushable
        // IL_0304: stloc.s 33
        // IL_0306: ldloc.s 33
        // IL_0308: brfalse.s IL_0313
        // IL_030A: ldloc.s 13
        // IL_030C: ldloc.s 33
        // IL_030E: callvirt 0x0A000094 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ICrushable>::Add
        // IL_0313: ldloc.s 15
        // IL_0315: callvirt 0x0A000018 [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_031A: brtrue IL_0199
        // IL_031F: leave.s IL_032D
        // IL_0321: ldloc.s 15
        // IL_0323: brfalse.s IL_032C
        // IL_0325: ldloc.s 15
        // IL_0327: callvirt 0x0A000017 [System.Runtime]System.IDisposable::Dispose
        // IL_032C: endfinally 
        // IL_032D: ldarg.0 0
        // IL_032E: ldloc.3 3
        // IL_032F: callvirt 0x0A000095 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IResolveOrder>::ToArray
        // IL_0334: stfld 0x04000026 OpenRA.Actor::resolveOrders
        // IL_0339: ldarg.0 0
        // IL_033A: ldloc.s 4
        // IL_033C: callvirt 0x0A000096 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRenderModifier>::ToArray
        // IL_0341: stfld 0x04000027 OpenRA.Actor::renderModifiers
        // IL_0346: ldarg.0 0
        // IL_0347: ldloc.s 5
        // IL_0349: callvirt 0x0A000097 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IRender>::ToArray
        // IL_034E: stfld 0x04000028 OpenRA.Actor::renders
        // IL_0353: ldarg.0 0
        // IL_0354: ldloc.s 6
        // IL_0356: callvirt 0x0A000098 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IMouseBounds>::ToArray
        // IL_035B: stfld 0x04000029 OpenRA.Actor::mouseBounds
        // IL_0360: ldarg.0 0
        // IL_0361: ldloc.s 7
        // IL_0363: callvirt 0x0A000099 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.IVisibilityModifier>::ToArray
        // IL_0368: stfld 0x0400002A OpenRA.Actor::visibilityModifiers
        // IL_036D: ldarg.0 0
        // IL_036E: ldloc.s 8
        // IL_0370: callvirt 0x0A00009A class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyBecomingIdle>::ToArray
        // IL_0375: stfld 0x0400002C OpenRA.Actor::becomingIdles
        // IL_037A: ldarg.0 0
        // IL_037B: ldloc.s 9
        // IL_037D: callvirt 0x0A00009B class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.INotifyIdle>::ToArray
        // IL_0382: stfld 0x0400002D OpenRA.Actor::tickIdles
        // IL_0387: ldarg.0 0
        // IL_0388: ldloc.s 10
        // IL_038A: callvirt 0x0A00009C class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetable>::ToArray
        // IL_038F: stfld 0x0400001B OpenRA.Actor::<Targetables>k__BackingField
        // IL_0394: ldloc.s 11
        // IL_0396: callvirt 0x0A00009D class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ITargetablePositions>::ToArray
        // IL_039B: stloc.s 14
        // IL_039D: ldarg.0 0
        // IL_039E: ldloc.s 14
        // IL_03A0: ldnull 
        // IL_03A1: ldftn 0x2B000005 OpenRA.Exts::IsTraitEnabled<class OpenRA.Traits.ITargetablePositions>
        // IL_03A7: newobj 0x0A00009E class [System.Runtime]System.Func`2<class OpenRA.Traits.ITargetablePositions, bool>::.ctor
        // IL_03AC: call 0x2B000006 [System.Linq]System.Linq.Enumerable::Where<class OpenRA.Traits.ITargetablePositions>
        // IL_03B1: stfld 0x0400001C OpenRA.Actor::<EnabledTargetablePositions>k__BackingField
        // IL_03B6: ldarg.0 0
        // IL_03B7: ldarg.0 0
        // IL_03B8: call 0x06000020 OpenRA.Actor::get_EnabledTargetablePositions
        // IL_03BD: ldarg.0 0
        // IL_03BE: ldftn 0x06000051 OpenRA.Actor::<.ctor>b__73_2
        // IL_03C4: newobj 0x0A0000A0 class [System.Runtime]System.Func`2<class OpenRA.Traits.ITargetablePositions, class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.WPos>>::.ctor
        // IL_03C9: call 0x2B000007 [System.Linq]System.Linq.Enumerable::SelectMany<class OpenRA.Traits.ITargetablePositions, valuetype OpenRA.WPos>
        // IL_03CE: stfld 0x0400002E OpenRA.Actor::enabledTargetableWorldPositions
        // IL_03D3: ldarg.0 0
        // IL_03D4: ldloc.s 12
        // IL_03D6: callvirt 0x0A0000A2 class [System.Collections]System.Collections.Generic.List`1<valuetype OpenRA.Actor/SyncHash>::ToArray
        // IL_03DB: stfld 0x04000023 OpenRA.Actor::<SyncHashes>k__BackingField
        // IL_03E0: ldarg.0 0
        // IL_03E1: ldloc.s 13
        // IL_03E3: callvirt 0x0A0000A3 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.ICrushable>::ToArray
        // IL_03E8: stfld 0x0400001D OpenRA.Actor::crushables
        // IL_03ED: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 404, try_length: 397, handler_offset: 801, handler_length: 12, raw_flags: 2 }
        // .try IL_0194..IL_0321 finally IL_0321..IL_032D
    }

    internal void Initialize(bool addToWorld = true)
    {
        // structural signature __cil_ref_994f258d44cd2a45fafb56581e971dbaa7cc0f03 bytes=15128089020E128938: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class OpenRA.Actor/ConditionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_eec013517b90d5508f5e51243380678839fdeb8b bytes=15128089020E08: class [System.Collections]System.Collections.Generic.Dictionary`2<string, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9b143d154984ea532d76d79bbe450e82a18101b7 bytes=1512808D020E08: class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c7f9a6e2a5343199679ac3a18eebe325755858a9 bytes=151280A50112863C: class [System.Collections]System.Collections.Generic.HashSet`1<class OpenRA.Traits.VariableObserverNotifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_dc3a3c2320f33846fe475c2deeabc4c29b00ca3e bytes=151280A1011284D0: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.INotifyCreated>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_68ea44eeb53db932b28625048e1207a0660d82f6 bytes=151280A101128644: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.IObservesVariables>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9b0a31b6443b4a61aa7551ff5c621142b9a07d40 bytes=151280A101118640: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_b17529c6847974ec0d6d608fed88af08f91b344c bytes=118640: valuetype OpenRA.Traits.VariableObserver; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerator`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_c27d304f9b12bd9abf5bade2dea69c6fc0d1d9ac bytes=151180A90112863C: valuetype [System.Collections]System.Collections.Generic.HashSet`1/Enumerator<class OpenRA.Traits.VariableObserverNotifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_293563df0553d6d94b7001c193c129fdde9bd619 bytes=151280A101128634: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.ICreationActivity>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3c46c3128bf439a32b949bdde81a927ef978daea bytes=15128085011284D0: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyCreated>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_15d1813b339dca8504777c0a3e43374bd5716bb3 bytes=1512808501128644: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.IObservesVariables>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ed0a16d1be51ba942326b32cc1edd3233dd54e02 bytes=1512808501118640: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd bytes=15128085010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_953cc23588d1206f6325483e5e73bb78ac7d9233 bytes=1512808501128634: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.ICreationActivity>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a1ea5588599d5fbda2d095f51c608645b87ddf94 bytes=1512809D0112863C: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.VariableObserverNotifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 bytes=151280A50108: class [System.Collections]System.Collections.Generic.HashSet`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_c7f9a6e2a5343199679ac3a18eebe325755858a9 l0 = default;
        OpenRA.Traits.ICreationActivity l1 = default;
        __cil_ref_dc3a3c2320f33846fe475c2deeabc4c29b00ca3e l2 = default;
        OpenRA.Traits.INotifyCreated l3 = default;
        __cil_ref_68ea44eeb53db932b28625048e1207a0660d82f6 l4 = default;
        OpenRA.Traits.IObservesVariables l5 = default;
        __cil_ref_9b0a31b6443b4a61aa7551ff5c621142b9a07d40 l6 = default;
        __cil_value_b17529c6847974ec0d6d608fed88af08f91b344c l7 = default;
        __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 l8 = default;
        string l9 = default;
        OpenRA.Actor.ConditionState l10 = default;
        __cil_value_c27d304f9b12bd9abf5bade2dea69c6fc0d1d9ac l11 = default;
        OpenRA.Traits.VariableObserverNotifier l12 = default;
        __cil_ref_293563df0553d6d94b7001c193c129fdde9bd619 l13 = default;
        OpenRA.Traits.ICreationActivity l14 = default;
        OpenRA.Activities.Activity l15 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = this;
        int v1 = 1;
        v0.created = __cil_bool_store(v1);
        global::OpenRA.Actor v2 = this;
        __cil_ref_3c46c3128bf439a32b949bdde81a927ef978daea v3 = __cil_methodspec_call_2B000008(v2);
        __cil_ref_dc3a3c2320f33846fe475c2deeabc4c29b00ca3e v4 = __cil_callvirt_0A0000A4(v3);
        l2 = v4;
        try {
            IL_0013: ;
            goto IL_0023;
            IL_0015: ;
            __cil_ref_dc3a3c2320f33846fe475c2deeabc4c29b00ca3e v5 = l2;
            global::OpenRA.Traits.INotifyCreated v6 = __cil_callvirt_0A0000A5(v5);
            l3 = v6;
            global::OpenRA.Traits.INotifyCreated v7 = l3;
            global::OpenRA.Actor v8 = this;
            __cil_callvirt_060008E3(v7, v8);
            goto IL_0023;
            IL_0023: ;
            __cil_ref_dc3a3c2320f33846fe475c2deeabc4c29b00ca3e v9 = l2;
            int v10 = __cil_bool_load(__cil_callvirt_0A000018(v9));
            if (v10 != 0) {
                goto IL_0015;
            } else {
                goto IL_002B;
            }
            IL_002B: ;
            goto IL_0037;
        }
        finally {
            IL_002D: ;
            __cil_ref_dc3a3c2320f33846fe475c2deeabc4c29b00ca3e v11 = l2;
            if (v11 is null) {
                goto IL_0036;
            } else {
                goto IL_0030;
            }
            IL_0030: ;
            __cil_ref_dc3a3c2320f33846fe475c2deeabc4c29b00ca3e v12 = l2;
            __cil_callvirt_0A000017(v12);
            goto IL_0036;
            IL_0036: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0037: ;
        __cil_ref_c7f9a6e2a5343199679ac3a18eebe325755858a9 v13 = __cil_newobj_0A0000A6();
        l0 = v13;
        global::OpenRA.Actor v14 = this;
        __cil_ref_15d1813b339dca8504777c0a3e43374bd5716bb3 v15 = __cil_methodspec_call_2B000009(v14);
        __cil_ref_68ea44eeb53db932b28625048e1207a0660d82f6 v16 = __cil_callvirt_0A0000A7(v15);
        l4 = v16;
        try {
            IL_004A: ;
            goto IL_0107;
            IL_004F: ;
            __cil_ref_68ea44eeb53db932b28625048e1207a0660d82f6 v17 = l4;
            global::OpenRA.Traits.IObservesVariables v18 = __cil_callvirt_0A0000A8(v17);
            l5 = v18;
            global::OpenRA.Traits.IObservesVariables v19 = l5;
            __cil_ref_ed0a16d1be51ba942326b32cc1edd3233dd54e02 v20 = __cil_callvirt_06000991(v19);
            __cil_ref_9b0a31b6443b4a61aa7551ff5c621142b9a07d40 v21 = __cil_callvirt_0A0000A9(v20);
            l6 = v21;
            try {
                IL_0066: ;
                goto IL_00ED;
                IL_006B: ;
                __cil_ref_9b0a31b6443b4a61aa7551ff5c621142b9a07d40 v22 = l6;
                __cil_value_b17529c6847974ec0d6d608fed88af08f91b344c v23 = __cil_callvirt_0A0000AA(v22);
                l7 = v23;
                __cil_ref_c7f9a6e2a5343199679ac3a18eebe325755858a9 v24 = l0;
                __cil_value_b17529c6847974ec0d6d608fed88af08f91b344c v25 = l7;
                global::OpenRA.Traits.VariableObserverNotifier v26 = v25.Notifier;
                int v27 = __cil_bool_load(__cil_callvirt_0A0000AB(v24, v26));
                __cil_value_b17529c6847974ec0d6d608fed88af08f91b344c v28 = l7;
                __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd v29 = v28.Variables;
                __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v30 = __cil_callvirt_0A000034(v29);
                l8 = v30;
                try {
                    IL_0090: ;
                    goto IL_00D6;
                    IL_0092: ;
                    __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v31 = l8;
                    string v32 = __cil_callvirt_0A000033(v31);
                    l9 = v32;
                    global::OpenRA.Actor v33 = this;
                    __cil_ref_994f258d44cd2a45fafb56581e971dbaa7cc0f03 v34 = v33.conditionStates;
                    string v35 = l9;
                    global::OpenRA.Actor.ConditionState v36 = __cil_methodspec_call_2B00000A(v34, v35);
                    l10 = v36;
                    global::OpenRA.Actor.ConditionState v37 = l10;
                    __cil_ref_a1ea5588599d5fbda2d095f51c608645b87ddf94 v38 = v37.Notifiers;
                    __cil_value_b17529c6847974ec0d6d608fed88af08f91b344c v39 = l7;
                    global::OpenRA.Traits.VariableObserverNotifier v40 = v39.Notifier;
                    __cil_callvirt_0A0000AC(v38, v40);
                    global::OpenRA.Actor v41 = this;
                    __cil_ref_eec013517b90d5508f5e51243380678839fdeb8b v42 = v41.conditionCache;
                    string v43 = l9;
                    global::OpenRA.Actor.ConditionState v44 = l10;
                    __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 v45 = v44.Tokens;
                    int v46 = __cil_callvirt_0A0000AD(v45);
                    __cil_callvirt_0A0000AE(v42, v43, v46);
                    goto IL_00D6;
                    IL_00D6: ;
                    __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v47 = l8;
                    int v48 = __cil_bool_load(__cil_callvirt_0A000018(v47));
                    if (v48 != 0) {
                        goto IL_0092;
                    } else {
                        goto IL_00DF;
                    }
                    IL_00DF: ;
                    goto IL_00ED;
                }
                finally {
                    IL_00E1: ;
                    __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v49 = l8;
                    if (v49 is null) {
                        goto IL_00EC;
                    } else {
                        goto IL_00E5;
                    }
                    IL_00E5: ;
                    __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v50 = l8;
                    __cil_callvirt_0A000017(v50);
                    goto IL_00EC;
                    IL_00EC: ;
                    goto __cil_finally_end_1;
                    __cil_finally_end_1: ;
                }
                IL_00ED: ;
                __cil_ref_9b0a31b6443b4a61aa7551ff5c621142b9a07d40 v51 = l6;
                int v52 = __cil_bool_load(__cil_callvirt_0A000018(v51));
                if (v52 != 0) {
                    goto IL_006B;
                } else {
                    goto IL_00F9;
                }
                IL_00F9: ;
                goto IL_0107;
            }
            finally {
                IL_00FB: ;
                __cil_ref_9b0a31b6443b4a61aa7551ff5c621142b9a07d40 v53 = l6;
                if (v53 is null) {
                    goto IL_0106;
                } else {
                    goto IL_00FF;
                }
                IL_00FF: ;
                __cil_ref_9b0a31b6443b4a61aa7551ff5c621142b9a07d40 v54 = l6;
                __cil_callvirt_0A000017(v54);
                goto IL_0106;
                IL_0106: ;
                goto __cil_finally_end_2;
                __cil_finally_end_2: ;
            }
            IL_0107: ;
            __cil_ref_68ea44eeb53db932b28625048e1207a0660d82f6 v55 = l4;
            int v56 = __cil_bool_load(__cil_callvirt_0A000018(v55));
            if (v56 != 0) {
                goto IL_004F;
            } else {
                goto IL_0113;
            }
            IL_0113: ;
            goto IL_0121;
        }
        finally {
            IL_0115: ;
            __cil_ref_68ea44eeb53db932b28625048e1207a0660d82f6 v57 = l4;
            if (v57 is null) {
                goto IL_0120;
            } else {
                goto IL_0119;
            }
            IL_0119: ;
            __cil_ref_68ea44eeb53db932b28625048e1207a0660d82f6 v58 = l4;
            __cil_callvirt_0A000017(v58);
            goto IL_0120;
            IL_0120: ;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_0121: ;
        __cil_ref_c7f9a6e2a5343199679ac3a18eebe325755858a9 v59 = l0;
        __cil_value_c27d304f9b12bd9abf5bade2dea69c6fc0d1d9ac v60 = __cil_callvirt_0A0000AF(v59);
        l11 = v60;
        try {
            IL_0129: ;
            goto IL_0142;
            IL_012B: ;
            ref __cil_value_c27d304f9b12bd9abf5bade2dea69c6fc0d1d9ac v61 = ref l11;
            global::OpenRA.Traits.VariableObserverNotifier v62 = __cil_value_call_0A0000B0(ref v61);
            l12 = v62;
            global::OpenRA.Traits.VariableObserverNotifier v63 = l12;
            global::OpenRA.Actor v64 = this;
            global::OpenRA.Actor v65 = this;
            __cil_ref_9b143d154984ea532d76d79bbe450e82a18101b7 v66 = v65.readOnlyConditionCache;
            __cil_callvirt_0600098D(v63, v64, v66);
            goto IL_0142;
            IL_0142: ;
            ref __cil_value_c27d304f9b12bd9abf5bade2dea69c6fc0d1d9ac v67 = ref l11;
            int v68 = __cil_bool_load(__cil_value_call_0A0000B1(ref v67));
            if (v68 != 0) {
                goto IL_012B;
            } else {
                goto IL_014B;
            }
            IL_014B: ;
            goto IL_015B;
        }
        finally {
            IL_014D: ;
            ref __cil_value_c27d304f9b12bd9abf5bade2dea69c6fc0d1d9ac v69 = ref l11;
            __cil_constrained_1B0000A0_0A000017(ref v69);
            goto __cil_finally_end_4;
            __cil_finally_end_4: ;
        }
        IL_015B: ;
        l1 = null;
        global::OpenRA.Actor v70 = this;
        __cil_ref_953cc23588d1206f6325483e5e73bb78ac7d9233 v71 = __cil_methodspec_call_2B00000B(v70);
        __cil_ref_293563df0553d6d94b7001c193c129fdde9bd619 v72 = __cil_callvirt_0A0000B2(v71);
        l13 = v72;
        try {
            IL_016A: ;
            goto IL_01D2;
            IL_016C: ;
            __cil_ref_293563df0553d6d94b7001c193c129fdde9bd619 v73 = l13;
            global::OpenRA.Traits.ICreationActivity v74 = __cil_callvirt_0A0000B3(v73);
            l14 = v74;
            global::OpenRA.Traits.ICreationActivity v75 = l14;
            int v76 = __cil_bool_load(__cil_methodspec_call_2B00000C(v75));
            if (v76 == 0) {
                goto IL_01D2;
            } else {
                goto IL_017E;
            }
            IL_017E: ;
            global::OpenRA.Traits.ICreationActivity v77 = l1;
            if (v77 is null) {
                goto IL_01AD;
            } else {
                goto IL_0181;
            }
            IL_0181: ;
            string v78 = __cil_ldstr_700001A4("More than one enabled ICreationActivity trait: ");
            global::OpenRA.Traits.ICreationActivity v79 = l1;
            __cil_type_01000026 v80 = v79.GetType();
            string v81 = __cil_callvirt_0A000077(v80);
            string v82 = __cil_ldstr_70000204(" and ");
            global::OpenRA.Traits.ICreationActivity v83 = l14;
            __cil_type_01000026 v84 = v83.GetType();
            string v85 = __cil_callvirt_0A000077(v84);
            string v86 = System.String.Concat(v78, v81, v82, v85);
            global::System.InvalidOperationException v87 = __cil_newobj_0A00006E(v86);
            throw v87;
            IL_01AD: ;
            global::OpenRA.Traits.ICreationActivity v88 = l14;
            global::OpenRA.Activities.Activity v89 = __cil_callvirt_0600098B(v88);
            l15 = v89;
            global::OpenRA.Activities.Activity v90 = l15;
            if (v90 is null) {
                goto IL_01D2;
            } else {
                goto IL_01BA;
            }
            IL_01BA: ;
            global::OpenRA.Traits.ICreationActivity v91 = l14;
            l1 = v91;
            global::OpenRA.Activities.Activity v92 = l15;
            global::OpenRA.Actor v93 = this;
            global::OpenRA.Activities.Activity v94 = __cil_direct_0600001B(v93);
            __cil_callvirt_06000F46(v92, v94);
            global::OpenRA.Actor v95 = this;
            global::OpenRA.Activities.Activity v96 = l15;
            __cil_direct_0600001C(v95, v96);
            goto IL_01D2;
            IL_01D2: ;
            __cil_ref_293563df0553d6d94b7001c193c129fdde9bd619 v97 = l13;
            int v98 = __cil_bool_load(__cil_callvirt_0A000018(v97));
            if (v98 != 0) {
                goto IL_016C;
            } else {
                goto IL_01DB;
            }
            IL_01DB: ;
            goto IL_01E9;
        }
        finally {
            IL_01DD: ;
            __cil_ref_293563df0553d6d94b7001c193c129fdde9bd619 v99 = l13;
            if (v99 is null) {
                goto IL_01E8;
            } else {
                goto IL_01E1;
            }
            IL_01E1: ;
            __cil_ref_293563df0553d6d94b7001c193c129fdde9bd619 v100 = l13;
            __cil_callvirt_0A000017(v100);
            goto IL_01E8;
            IL_01E8: ;
            goto __cil_finally_end_5;
            __cil_finally_end_5: ;
        }
        IL_01E9: ;
        int v101 = __cil_bool_load(addToWorld);
        if (v101 == 0) {
            goto IL_01F8;
        } else {
            goto IL_01EC;
        }
        IL_01EC: ;
        global::OpenRA.Actor v102 = this;
        global::OpenRA.World v103 = v102.World;
        global::OpenRA.Actor v104 = this;
        __cil_callvirt_06000676(v103, v104);
        goto IL_01F8;
        IL_01F8: ;
        return;
    }

    public void Tick()
    {
        // structural signature __cil_ref_20782a3b0b009c37188ff89bc589f02b0cba6980 bytes=1D1285BC: class OpenRA.Traits.INotifyBecomingIdle[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5e041eb37bdac9f2e1c815dc770fe862806bc03b bytes=1D1285C0: class OpenRA.Traits.INotifyIdle[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        __cil_ref_20782a3b0b009c37188ff89bc589f02b0cba6980 l1 = default;
        int l2 = default;
        __cil_ref_5e041eb37bdac9f2e1c815dc770fe862806bc03b l4 = default;
        int l5 = default;
        int v1 = __cil_bool_load(this.IsIdle);
        l0 = __cil_bool_store(v1);
        global::OpenRA.Activities.Activity v5 = this.CurrentActivity;
        global::OpenRA.Activities.Activity v6 = OpenRA.Traits.ActivityUtils.RunActivity(this, v5);
        this.CurrentActivity = v6;
        int v7 = __cil_bool_load(l0);
        if (v7 != 0) {
            goto IL_0057;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        int v9 = __cil_bool_load(this.IsIdle);
        if (v9 == 0) {
            goto IL_0057;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        __cil_ref_20782a3b0b009c37188ff89bc589f02b0cba6980 v11 = this.becomingIdles;
        l1 = v11;
        l2 = 0;
        goto IL_003E;
        IL_002F: ;
        __cil_ref_20782a3b0b009c37188ff89bc589f02b0cba6980 v13 = l1;
        int v14 = l2;
        global::OpenRA.Traits.INotifyBecomingIdle v15 = v13[v14];
        __cil_callvirt_0600094E(v15, this);
        int v18 = l2;
        l2 = unchecked(v18 + 1);
        IL_003E: ;
        int v21 = l2;
        __cil_ref_20782a3b0b009c37188ff89bc589f02b0cba6980 v22 = l1;
        nint v23 = unchecked((nint)(v22.LongLength));
        int v24 = unchecked((int)(v23));
        if (v21 < v24) {
            goto IL_002F;
        } else {
            goto IL_0044;
        }
        IL_0044: ;
        global::OpenRA.Activities.Activity v28 = this.CurrentActivity;
        global::OpenRA.Activities.Activity v29 = OpenRA.Traits.ActivityUtils.RunActivity(this, v28);
        this.CurrentActivity = v29;
        return;
        IL_0057: ;
        int v30 = __cil_bool_load(l0);
        if (v30 == 0) {
            goto IL_0084;
        } else {
            goto IL_005A;
        }
        IL_005A: ;
        __cil_ref_5e041eb37bdac9f2e1c815dc770fe862806bc03b v32 = this.tickIdles;
        l4 = v32;
        l5 = 0;
        goto IL_007C;
        IL_0067: ;
        __cil_ref_5e041eb37bdac9f2e1c815dc770fe862806bc03b v34 = l4;
        int v35 = l5;
        global::OpenRA.Traits.INotifyIdle v36 = v34[v35];
        __cil_callvirt_0600094F(v36, this);
        int v39 = l5;
        l5 = unchecked(v39 + 1);
        IL_007C: ;
        int v42 = l5;
        __cil_ref_5e041eb37bdac9f2e1c815dc770fe862806bc03b v43 = l4;
        nint v44 = unchecked((nint)(v43.LongLength));
        int v45 = unchecked((int)(v44));
        if (v42 < v45) {
            goto IL_0067;
        } else {
            goto IL_0084;
        }
        IL_0084: ;
        return;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Graphics.IRenderable> Render(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 bytes=151280850112880C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Graphics.IRenderable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 bytes=1D12851C: class OpenRA.Traits.IRenderModifier[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 l0 = default;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 l1 = default;
        int l2 = default;
        __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v2 = __cil_direct_0600002C(this, wr);
        l0 = v2;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 v4 = this.renderModifiers;
        l1 = v4;
        l2 = 0;
        goto IL_0025;
        IL_0013: ;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 v6 = l1;
        int v7 = l2;
        global::OpenRA.Traits.IRenderModifier v8 = v6[v7];
        __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v12 = l0;
        __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v13 = __cil_callvirt_0600091A(v8, this, wr, v12);
        l0 = v13;
        int v14 = l2;
        l2 = unchecked(v14 + 1);
        IL_0025: ;
        int v17 = l2;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 v18 = l1;
        nint v19 = unchecked((nint)(v18.LongLength));
        int v20 = unchecked((int)(v19));
        if (v17 < v20) {
            goto IL_0013;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v21 = l0;
        return v21;
    }

    private System.Collections.Generic.IEnumerable<OpenRA.Graphics.IRenderable> Renderables(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 bytes=151280850112880C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Graphics.IRenderable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v1 = __cil_newobj_06000F64(-2);
        v1.__il_field_0400094A = this;
        v1.__il_field_0400094C = wr;
        return v1;
    }

    public System.Collections.Generic.IEnumerable<OpenRA.Primitives.Rectangle> ScreenBounds(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 bytes=1D12851C: class OpenRA.Traits.IRenderModifier[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2745b003c8defa48e628bba26e60343007031f0a bytes=1512808501118718: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_2745b003c8defa48e628bba26e60343007031f0a l0 = default;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 l1 = default;
        int l2 = default;
        __cil_ref_2745b003c8defa48e628bba26e60343007031f0a v2 = __cil_direct_0600002E(this, wr);
        l0 = v2;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 v4 = this.renderModifiers;
        l1 = v4;
        l2 = 0;
        goto IL_0025;
        IL_0013: ;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 v6 = l1;
        int v7 = l2;
        global::OpenRA.Traits.IRenderModifier v8 = v6[v7];
        __cil_ref_2745b003c8defa48e628bba26e60343007031f0a v12 = l0;
        __cil_ref_2745b003c8defa48e628bba26e60343007031f0a v13 = __cil_callvirt_0600091B(v8, this, wr, v12);
        l0 = v13;
        int v14 = l2;
        l2 = unchecked(v14 + 1);
        IL_0025: ;
        int v17 = l2;
        __cil_ref_4cca9814969f8861604741d8a6d239d3da895f47 v18 = l1;
        nint v19 = unchecked((nint)(v18.LongLength));
        int v20 = unchecked((int)(v19));
        if (v17 < v20) {
            goto IL_0013;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        __cil_ref_2745b003c8defa48e628bba26e60343007031f0a v21 = l0;
        return v21;
    }

    private System.Collections.Generic.IEnumerable<OpenRA.Primitives.Rectangle> Bounds(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_ref_2745b003c8defa48e628bba26e60343007031f0a bytes=1512808501118718: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v1 = __cil_newobj_06000F5B(-2);
        v1.__il_field_04000941 = this;
        v1.__il_field_04000943 = wr;
        return v1;
    }

    public OpenRA.Primitives.Polygon MouseBounds(OpenRA.Graphics.WorldRenderer wr)
    {
        // structural signature __cil_value_d0fb75fb98038f5c6ee381e6b8170223f616c586 bytes=118704: valuetype OpenRA.Primitives.Polygon; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_83368deccde0bac6f939d30ebe7be4e43f111f5b bytes=1D1284A8: class OpenRA.Traits.IMouseBounds[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_83368deccde0bac6f939d30ebe7be4e43f111f5b l0 = default;
        int l1 = default;
        OpenRA.Traits.IMouseBounds l2 = default;
        __cil_value_d0fb75fb98038f5c6ee381e6b8170223f616c586 l3 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = this;
        __cil_ref_83368deccde0bac6f939d30ebe7be4e43f111f5b v1 = v0.mouseBounds;
        l0 = v1;
        int v2 = 0;
        l1 = v2;
        goto IL_0027;
        IL_000B: ;
        __cil_ref_83368deccde0bac6f939d30ebe7be4e43f111f5b v3 = l0;
        int v4 = l1;
        global::OpenRA.Traits.IMouseBounds v5 = v3[v4];
        l2 = v5;
        global::OpenRA.Traits.IMouseBounds v6 = l2;
        global::OpenRA.Actor v7 = this;
        global::OpenRA.Graphics.WorldRenderer v8 = wr;
        __cil_value_d0fb75fb98038f5c6ee381e6b8170223f616c586 v9 = __cil_callvirt_060008D6(v6, v7, v8);
        l3 = v9;
        ref __cil_value_d0fb75fb98038f5c6ee381e6b8170223f616c586 v10 = ref l3;
        int v11 = __cil_bool_load(__cil_direct_06000B8C(ref v10));
        if (v11 != 0) {
            goto IL_0023;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        __cil_value_d0fb75fb98038f5c6ee381e6b8170223f616c586 v12 = l3;
        return v12;
        IL_0023: ;
        int v13 = l1;
        int v14 = 1;
        int v15 = unchecked(v13 + v14);
        l1 = v15;
        goto IL_0027;
        IL_0027: ;
        int v16 = l1;
        __cil_ref_83368deccde0bac6f939d30ebe7be4e43f111f5b v17 = l0;
        nint v18 = unchecked((nint)(v17.LongLength));
        int v19 = unchecked((int)(v18));
        if (v16 < v19) {
            goto IL_000B;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        __cil_value_d0fb75fb98038f5c6ee381e6b8170223f616c586 v20 = OpenRA.Primitives.Polygon.Empty;
        return v20;
    }

    public void QueueActivity(bool queued, OpenRA.Activities.Activity nextActivity)
    {
        int v0 = __cil_bool_load(queued);
        if (v0 != 0) {
            goto IL_0009;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        __cil_direct_06000032(this);
        IL_0009: ;
        __cil_direct_06000031(this, nextActivity);
        return;
    }

    public void QueueActivity(OpenRA.Activities.Activity nextActivity)
    {
        int v1 = __cil_bool_load(this.created);
        if (v1 != 0) {
            goto IL_0013;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        string v2 = __cil_ldstr_70000210("An activity was queued before the actor was created. Queue it inside the INotifyCreated.Created callback instead.");
        global::System.InvalidOperationException v3 = __cil_newobj_0A00006E(v2);
        throw v3;
        IL_0013: ;
        global::OpenRA.Activities.Activity v5 = this.CurrentActivity;
        if (v5 is not null) {
            goto IL_0023;
        } else {
            goto IL_001B;
        }
        IL_001B: ;
        this.CurrentActivity = nextActivity;
        return;
        IL_0023: ;
        global::OpenRA.Activities.Activity v9 = this.CurrentActivity;
        __cil_callvirt_06000F46(v9, nextActivity);
        return;
    }

    public void CancelActivity()
    {
        OpenRA.Activities.Activity s1_0 = default;
        OpenRA.Activities.Activity s2_0 = default;
        global::OpenRA.Activities.Activity v1 = this.CurrentActivity;
        if (v1 is not null) {
            OpenRA.Activities.Activity e0_2_0 = v1;
            s2_0 = e0_2_0;
            goto IL_000B;
        } else {
            OpenRA.Activities.Activity e0_1_0 = v1;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        return;
        IL_000B: ;
        __cil_callvirt_06000F45(s2_0, this, __cil_bool_store(0));
        return;
    }

    public override int GetHashCode()
    {
        int v1 = unchecked((int)(this.ActorID));
        return v1;
    }

    public override bool Equals(object obj)
    {
        OpenRA.Actor l0 = default;
        global::OpenRA.Actor v1 = ((object)obj as OpenRA.Actor);
        l0 = v1;
        global::OpenRA.Actor v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::OpenRA.Actor v4 = l0;
        // Exact call 0x06000035 kept: type binding requires a resolved assembly: Eluant, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null, ContentType=0x0.
        return __cil_direct_06000035(this, v4);
    }

    public virtual bool Equals(OpenRA.Actor other)
    {
        int v1 = unchecked((int)(this.ActorID));
        int v3 = unchecked((int)(other.ActorID));
        return (v1 == v3);
    }

    public override string ToString()
    {
        string l0 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = this;
        global::OpenRA.ActorInfo v1 = v0.Info;
        string v2 = v1.Name;
        string v3 = __cil_ldstr_700002F5(" ");
        global::OpenRA.Actor v4 = this;
        ref uint v5 = ref __cil_ldflda_04000011(v4);
        string v6 = __cil_memberref_call_0A0000B6(ref v5);
        string v7 = System.String.Concat(v2, v3, v6);
        l0 = v7;
        global::OpenRA.Actor v8 = this;
        int v9 = __cil_bool_load(__cil_direct_06000015(v8));
        if (v9 != 0) {
            goto IL_0035;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        string v10 = l0;
        string v11 = __cil_ldstr_700002F9(" (not in world)");
        string v12 = System.String.Concat(v10, v11);
        l0 = v12;
        goto IL_0035;
        IL_0035: ;
        string v13 = l0;
        return v13;
    }

    public T Trait<T>()
    {
        // generic body context type-owner=0x02000008 type-arity=0 method-owner=0x06000037 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_generic_e539a7d10cad55563cfb10b7118241a1d52878ba bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x06000037; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        global::OpenRA.World v1 = this.World;
        global::OpenRA.TraitDictionary v2 = v1.TraitDict;
        __cil_generic_e539a7d10cad55563cfb10b7118241a1d52878ba v4 = __cil_callvirt_2B00000D(v2, this);
        return v4;
    }

    public T TraitOrDefault<T>()
    {
        // generic body context type-owner=0x02000008 type-arity=0 method-owner=0x06000038 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_generic_cd48c764e5e0cf08e3e64c75a03cd6e4a4f68a38 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x06000038; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        global::OpenRA.World v1 = this.World;
        global::OpenRA.TraitDictionary v2 = v1.TraitDict;
        __cil_generic_cd48c764e5e0cf08e3e64c75a03cd6e4a4f68a38 v4 = __cil_callvirt_2B00000E(v2, this);
        return v4;
    }

    public System.Collections.Generic.IEnumerable<T> TraitsImplementing<T>()
    {
        // generic body context type-owner=0x02000008 type-arity=0 method-owner=0x06000039 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_c4d87657a8c920e1598cfdd895fe93d6518d3937 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x06000039; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.World v1 = this.World;
        global::OpenRA.TraitDictionary v2 = v1.TraitDict;
        __cil_ref_c4d87657a8c920e1598cfdd895fe93d6518d3937 v4 = __cil_callvirt_2B00000F(v2, this);
        return v4;
    }

    public void AddTrait(object trait)
    {
        global::OpenRA.World v1 = this.World;
        global::OpenRA.TraitDictionary v2 = v1.TraitDict;
        __cil_callvirt_060005F4(v2, this, trait);
        return;
    }

    public virtual void Dispose()
    {
        // structural signature __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 bytes=151281A901128328: class [System.Runtime]System.Action`1<class OpenRA.World>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Activities.Activity s1_0 = default;
        OpenRA.Activities.Activity s2_0 = default;
        global::OpenRA.Activities.Activity v1 = this.CurrentActivity;
        if (v1 is not null) {
            OpenRA.Activities.Activity e0_2_0 = v1;
            s2_0 = e0_2_0;
            goto IL_000C;
        } else {
            OpenRA.Activities.Activity e0_1_0 = v1;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        goto IL_0012;
        IL_000C: ;
        __cil_direct_06000F44(s2_0, this);
        IL_0012: ;
        this.WillDispose = __cil_bool_store(1);
        global::OpenRA.World v6 = this.World;
        nint v8 = __cil_ldftn_06000052;
        __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 v9 = __cil_newobj_0A0000B7(this, v8);
        __cil_callvirt_0600067B(v6, v9);
        return;
    }

    public void ResolveOrder(OpenRA.Order order)
    {
        // structural signature __cil_ref_102205b57a530b5f4cdcb6f02a567c7318673966 bytes=1D1284C4: class OpenRA.Traits.IResolveOrder[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_102205b57a530b5f4cdcb6f02a567c7318673966 l0 = default;
        int l1 = default;
        __cil_ref_102205b57a530b5f4cdcb6f02a567c7318673966 v1 = this.resolveOrders;
        l0 = v1;
        l1 = 0;
        goto IL_001B;
        IL_000B: ;
        __cil_ref_102205b57a530b5f4cdcb6f02a567c7318673966 v3 = l0;
        int v4 = l1;
        global::OpenRA.Traits.IResolveOrder v5 = v3[v4];
        __cil_callvirt_060008E0(v5, this, order);
        int v9 = l1;
        l1 = unchecked(v9 + 1);
        IL_001B: ;
        int v12 = l1;
        __cil_ref_102205b57a530b5f4cdcb6f02a567c7318673966 v13 = l0;
        nint v14 = unchecked((nint)(v13.LongLength));
        int v15 = unchecked((int)(v14));
        if (v12 < v15) {
            goto IL_000B;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        return;
    }

    public void ChangeOwner(OpenRA.Player newOwner)
    {
        // structural signature __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 bytes=151281A901128328: class [System.Runtime]System.Action`1<class OpenRA.World>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Actor.__name_3C3E635F5F446973706C6179436C61737339345F30 v0 = __cil_newobj_06000F59();
        v0.__il_field_0400093C = this;
        v0.newOwner = newOwner;
        global::OpenRA.World v6 = this.World;
        nint v8 = __cil_ldftn_06000F5A;
        __cil_ref_0a5c321135ecdf089774401346fb2953a1693579 v9 = __cil_newobj_0A0000B7(v0, v8);
        __cil_callvirt_0600067B(v6, v9);
        return;
    }

    public void ChangeOwnerSync(OpenRA.Player newOwner)
    {
        // structural signature __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c bytes=151280A1011284E0: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.INotifyOwnerChanged>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_34e265f2d21f719aa61b9348b8f2e8eacd284f4c bytes=15128085011284E0: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyOwnerChanged>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Player l0 = default;
        bool l1 = default;
        __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c l2 = default;
        OpenRA.Traits.INotifyOwnerChanged l3 = default;
        __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c l4 = default;
        OpenRA.Traits.INotifyOwnerChanged l5 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000019(v0));
        if (v1 == 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        global::OpenRA.Actor v2 = this;
        global::OpenRA.Player v3 = __cil_direct_06000013(v2);
        l0 = v3;
        global::OpenRA.Actor v4 = this;
        int v5 = __cil_bool_load(__cil_direct_06000015(v4));
        l1 = __cil_bool_store(v5);
        int v6 = __cil_bool_load(l1);
        if (v6 == 0) {
            goto IL_0026;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        global::OpenRA.Actor v7 = this;
        global::OpenRA.World v8 = v7.World;
        global::OpenRA.Actor v9 = this;
        __cil_callvirt_06000677(v8, v9);
        goto IL_0026;
        IL_0026: ;
        global::OpenRA.Actor v10 = this;
        global::OpenRA.Player v11 = newOwner;
        __cil_direct_06000014(v10, v11);
        global::OpenRA.Actor v12 = this;
        global::OpenRA.Actor v13 = this;
        int v14 = v13.Generation;
        int v15 = 1;
        int v16 = unchecked(v14 + v15);
        v12.Generation = v16;
        global::OpenRA.Actor v17 = this;
        __cil_ref_34e265f2d21f719aa61b9348b8f2e8eacd284f4c v18 = __cil_methodspec_call_2B000010(v17);
        __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v19 = __cil_callvirt_0A0000B8(v18);
        l2 = v19;
        try {
            IL_0047: ;
            goto IL_0059;
            IL_0049: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v20 = l2;
            global::OpenRA.Traits.INotifyOwnerChanged v21 = __cil_callvirt_0A0000B9(v20);
            l3 = v21;
            global::OpenRA.Traits.INotifyOwnerChanged v22 = l3;
            global::OpenRA.Actor v23 = this;
            global::OpenRA.Player v24 = l0;
            global::OpenRA.Player v25 = newOwner;
            __cil_callvirt_060008E7(v22, v23, v24, v25);
            goto IL_0059;
            IL_0059: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v26 = l2;
            int v27 = __cil_bool_load(__cil_callvirt_0A000018(v26));
            if (v27 != 0) {
                goto IL_0049;
            } else {
                goto IL_0061;
            }
            IL_0061: ;
            goto IL_006D;
        }
        finally {
            IL_0063: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v28 = l2;
            if (v28 is null) {
                goto IL_006C;
            } else {
                goto IL_0066;
            }
            IL_0066: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v29 = l2;
            __cil_callvirt_0A000017(v29);
            goto IL_006C;
            IL_006C: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_006D: ;
        global::OpenRA.Actor v30 = this;
        global::OpenRA.World v31 = v30.World;
        global::OpenRA.Actor v32 = v31.WorldActor;
        __cil_ref_34e265f2d21f719aa61b9348b8f2e8eacd284f4c v33 = __cil_callvirt_2B000010(v32);
        __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v34 = __cil_callvirt_0A0000B8(v33);
        l4 = v34;
        try {
            IL_0084: ;
            goto IL_0099;
            IL_0086: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v35 = l4;
            global::OpenRA.Traits.INotifyOwnerChanged v36 = __cil_callvirt_0A0000B9(v35);
            l5 = v36;
            global::OpenRA.Traits.INotifyOwnerChanged v37 = l5;
            global::OpenRA.Actor v38 = this;
            global::OpenRA.Player v39 = l0;
            global::OpenRA.Player v40 = newOwner;
            __cil_callvirt_060008E7(v37, v38, v39, v40);
            goto IL_0099;
            IL_0099: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v41 = l4;
            int v42 = __cil_bool_load(__cil_callvirt_0A000018(v41));
            if (v42 != 0) {
                goto IL_0086;
            } else {
                goto IL_00A2;
            }
            IL_00A2: ;
            goto IL_00B0;
        }
        finally {
            IL_00A4: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v43 = l4;
            if (v43 is null) {
                goto IL_00AF;
            } else {
                goto IL_00A8;
            }
            IL_00A8: ;
            __cil_ref_22a6dc9601b2561b41294750671d8d37e65a654c v44 = l4;
            __cil_callvirt_0A000017(v44);
            goto IL_00AF;
            IL_00AF: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_00B0: ;
        int v45 = __cil_bool_load(l1);
        if (v45 == 0) {
            goto IL_00BF;
        } else {
            goto IL_00B3;
        }
        IL_00B3: ;
        global::OpenRA.Actor v46 = this;
        global::OpenRA.World v47 = v46.World;
        global::OpenRA.Actor v48 = this;
        __cil_callvirt_06000676(v47, v48);
        goto IL_00BF;
        IL_00BF: ;
        return;
    }

    public OpenRA.Traits.DamageState GetDamageState()
    {
        // enum storage token=0x0200011F alias=__cil_enum_0200011F underlying=int: global::@OpenRA.@Traits.@DamageState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = __cil_bool_load(this.Disposed);
        if (v1 == 0) {
            goto IL_000B;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return unchecked((__cil_enum_0200011F)(32));
        IL_000B: ;
        global::OpenRA.Traits.IHealth v4 = this.health;
        if (v4 is null) {
            goto IL_001F;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        global::OpenRA.Traits.IHealth v6 = this.health;
        int v7 = unchecked((int)(__cil_callvirt_060008C7(v6)));
        return unchecked((__cil_enum_0200011F)(v7));
        IL_001F: ;
        return unchecked((__cil_enum_0200011F)(1));
    }

    public void InflictDamage(OpenRA.Actor attacker, OpenRA.Traits.Damage damage)
    {
        int v1 = __cil_bool_load(this.Disposed);
        if (v1 != 0) {
            goto IL_0010;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Traits.IHealth v3 = this.health;
        if (v3 is not null) {
            goto IL_0011;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        return;
        IL_0011: ;
        global::OpenRA.Traits.IHealth v5 = this.health;
        __cil_callvirt_060008CC(v5, this, attacker, damage, __cil_bool_store(0));
        return;
    }

    public void Kill(OpenRA.Actor attacker, OpenRA.Primitives.BitSet<OpenRA.Traits.DamageType> damageTypes = null)
    {
        // structural signature __cil_value_19f2996dd131e61e657894cf2568b0d092c98ff1 bytes=151186C801128480: valuetype OpenRA.Primitives.BitSet`1<class OpenRA.Traits.DamageType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        int v1 = __cil_bool_load(this.Disposed);
        if (v1 != 0) {
            goto IL_0010;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Traits.IHealth v3 = this.health;
        if (v3 is not null) {
            goto IL_0011;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        return;
        IL_0011: ;
        global::OpenRA.Traits.IHealth v5 = this.health;
        __cil_callvirt_060008CD(v5, this, attacker, damageTypes);
        return;
    }

    public bool CanBeViewedByPlayer(OpenRA.Player player)
    {
        // structural signature __cil_ref_9f1b90dfa0455ec70dedc556855e3c919d4d9475 bytes=1D128514: class OpenRA.Traits.IVisibilityModifier[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_9f1b90dfa0455ec70dedc556855e3c919d4d9475 l0 = default;
        int l1 = default;
        __cil_ref_9f1b90dfa0455ec70dedc556855e3c919d4d9475 v1 = this.visibilityModifiers;
        l0 = v1;
        l1 = 0;
        goto IL_001F;
        IL_000B: ;
        __cil_ref_9f1b90dfa0455ec70dedc556855e3c919d4d9475 v3 = l0;
        int v4 = l1;
        global::OpenRA.Traits.IVisibilityModifier v5 = v3[v4];
        int v9 = __cil_bool_load(__cil_callvirt_060008FF(v5, this, player));
        if (!(v9 != 0)) {
            return false;
        }
        int v11 = l1;
        l1 = unchecked(v11 + 1);
        IL_001F: ;
        int v14 = l1;
        __cil_ref_9f1b90dfa0455ec70dedc556855e3c919d4d9475 v15 = l0;
        nint v16 = unchecked((nint)(v15.LongLength));
        int v17 = unchecked((int)(v16));
        if (v14 < v17) {
            goto IL_000B;
        } else {
            goto IL_0025;
        }
        IL_0025: ;
        global::OpenRA.Traits.IDefaultVisibility v19 = this.defaultVisibility;
        return __cil_callvirt_060008FE(v19, this, player);
    }

    public OpenRA.Primitives.BitSet<OpenRA.Traits.TargetableType> GetAllTargetTypes()
    {
        // structural signature __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 bytes=1D128608: class OpenRA.Traits.ITargetable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 bytes=151186C801128600: valuetype OpenRA.Primitives.BitSet`1<class OpenRA.Traits.TargetableType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 l0 = default;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 l1 = default;
        int l2 = default;
        OpenRA.Traits.ITargetable l3 = default;
        IL_0000: ;
        ref __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v0 = ref l0;
        v0 = default;
        global::OpenRA.Actor v1 = this;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v2 = __cil_direct_0600001F(v1);
        l1 = v2;
        int v3 = 0;
        l2 = v3;
        goto IL_0029;
        IL_0013: ;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v4 = l1;
        int v5 = l2;
        global::OpenRA.Traits.ITargetable v6 = v4[v5];
        l3 = v6;
        ref __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v7 = ref l0;
        global::OpenRA.Traits.ITargetable v8 = l3;
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v9 = __cil_callvirt_06000979(v8);
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v10 = __cil_value_call_0A0000BA(ref v7, v9);
        l0 = v10;
        int v11 = l2;
        int v12 = 1;
        int v13 = unchecked(v11 + v12);
        l2 = v13;
        goto IL_0029;
        IL_0029: ;
        int v14 = l2;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v15 = l1;
        nint v16 = unchecked((nint)(v15.LongLength));
        int v17 = unchecked((int)(v16));
        if (v14 < v17) {
            goto IL_0013;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v18 = l0;
        return v18;
    }

    public OpenRA.Primitives.BitSet<OpenRA.Traits.TargetableType> GetEnabledTargetTypes()
    {
        // structural signature __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 bytes=1D128608: class OpenRA.Traits.ITargetable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 bytes=151186C801128600: valuetype OpenRA.Primitives.BitSet`1<class OpenRA.Traits.TargetableType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 l0 = default;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 l1 = default;
        int l2 = default;
        OpenRA.Traits.ITargetable l3 = default;
        IL_0000: ;
        ref __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v0 = ref l0;
        v0 = default;
        global::OpenRA.Actor v1 = this;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v2 = __cil_direct_0600001F(v1);
        l1 = v2;
        int v3 = 0;
        l2 = v3;
        goto IL_0031;
        IL_0013: ;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v4 = l1;
        int v5 = l2;
        global::OpenRA.Traits.ITargetable v6 = v4[v5];
        l3 = v6;
        global::OpenRA.Traits.ITargetable v7 = l3;
        int v8 = __cil_bool_load(__cil_methodspec_call_2B000011(v7));
        if (v8 == 0) {
            goto IL_002D;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        ref __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v9 = ref l0;
        global::OpenRA.Traits.ITargetable v10 = l3;
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v11 = __cil_callvirt_06000979(v10);
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v12 = __cil_value_call_0A0000BA(ref v9, v11);
        l0 = v12;
        goto IL_002D;
        IL_002D: ;
        int v13 = l2;
        int v14 = 1;
        int v15 = unchecked(v13 + v14);
        l2 = v15;
        goto IL_0031;
        IL_0031: ;
        int v16 = l2;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v17 = l1;
        nint v18 = unchecked((nint)(v17.LongLength));
        int v19 = unchecked((int)(v18));
        if (v16 < v19) {
            goto IL_0013;
        } else {
            goto IL_0037;
        }
        IL_0037: ;
        __cil_value_634ec5d110dd59273d195e80d061bdef1a2649c7 v20 = l0;
        return v20;
    }

    public bool IsTargetableBy(OpenRA.Actor byActor)
    {
        // structural signature __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 bytes=1D128608: class OpenRA.Traits.ITargetable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 l0 = default;
        int l1 = default;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v1 = this.Targetables;
        l0 = v1;
        l1 = 0;
        goto IL_001F;
        IL_000B: ;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v3 = l0;
        int v4 = l1;
        global::OpenRA.Traits.ITargetable v5 = v3[v4];
        int v9 = __cil_bool_load(__cil_callvirt_0600097A(v5, this, byActor));
        if (!(v9 == 0)) {
            return true;
        }
        int v11 = l1;
        l1 = unchecked(v11 + 1);
        IL_001F: ;
        int v14 = l1;
        __cil_ref_d7b97ef8e45022ffa4d3bb99a077c6aeba38e084 v15 = l0;
        nint v16 = unchecked((nint)(v15.LongLength));
        int v17 = unchecked((int)(v16));
        if (v14 < v17) {
            goto IL_000B;
        } else {
            return false;
        }
    }

    public System.Collections.Generic.IEnumerable<OpenRA.WPos> GetTargetablePositions()
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 28, 20, 00, 00, 06, 28, 12, 00, 00, 2B, 2C, 07, 02, 7B, 2E, 00, 00, 04, 2A, 17, 8D, CE, 00]
        // .code-bytes IL_0018: [00, 02, 25, 16, 02, 28, 25, 00, 00, 06, A4, CE, 00, 00, 02, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x06000020 OpenRA.Actor::get_EnabledTargetablePositions
        // IL_0006: call 0x2B000012 [System.Linq]System.Linq.Enumerable::Any<class OpenRA.Traits.ITargetablePositions>
        // IL_000B: brfalse.s IL_0014
        // IL_000D: ldarg.0 0
        // IL_000E: ldfld 0x0400002E OpenRA.Actor::enabledTargetableWorldPositions
        // IL_0013: ret 
        // IL_0014: ldc.i4.1 1
        // IL_0015: newarr 0x020000CE OpenRA.WPos
        // IL_001A: dup 
        // IL_001B: ldc.i4.0 0
        // IL_001C: ldarg.0 0
        // IL_001D: call 0x06000025 OpenRA.Actor::get_CenterPosition
        // IL_0022: stelem 0x020000CE OpenRA.WPos
        // IL_0027: ret 
    }

    private void UpdateConditionState(string condition, int token, bool isRevoke)
    {
        // structural signature __cil_ref_994f258d44cd2a45fafb56581e971dbaa7cc0f03 bytes=15128089020E128938: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class OpenRA.Actor/ConditionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_eec013517b90d5508f5e51243380678839fdeb8b bytes=15128089020E08: class [System.Collections]System.Collections.Generic.Dictionary`2<string, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9b143d154984ea532d76d79bbe450e82a18101b7 bytes=1512808D020E08: class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a1ea5588599d5fbda2d095f51c608645b87ddf94 bytes=1512809D0112863C: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.VariableObserverNotifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 bytes=151280A50108: class [System.Collections]System.Collections.Generic.HashSet`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_f9f6e0785a87646ee03812f16447441f10a5e25b bytes=151180B10112863C: valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class OpenRA.Traits.VariableObserverNotifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        OpenRA.Actor.ConditionState l0 = default;
        __cil_value_f9f6e0785a87646ee03812f16447441f10a5e25b l1 = default;
        OpenRA.Traits.VariableObserverNotifier l2 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = this;
        __cil_ref_994f258d44cd2a45fafb56581e971dbaa7cc0f03 v1 = v0.conditionStates;
        string v2 = condition;
        global::OpenRA.Actor.ConditionState v3 = __cil_methodspec_call_2B00000A(v1, v2);
        l0 = v3;
        int v4 = __cil_bool_load(isRevoke);
        if (v4 == 0) {
            goto IL_001F;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Actor.ConditionState v5 = l0;
        __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 v6 = v5.Tokens;
        int v7 = token;
        int v8 = __cil_bool_load(__cil_callvirt_0A0000BC(v6, v7));
        goto IL_002C;
        IL_001F: ;
        global::OpenRA.Actor.ConditionState v9 = l0;
        __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 v10 = v9.Tokens;
        int v11 = token;
        int v12 = __cil_bool_load(__cil_callvirt_0A0000BD(v10, v11));
        goto IL_002C;
        IL_002C: ;
        global::OpenRA.Actor v13 = this;
        __cil_ref_eec013517b90d5508f5e51243380678839fdeb8b v14 = v13.conditionCache;
        string v15 = condition;
        global::OpenRA.Actor.ConditionState v16 = l0;
        __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 v17 = v16.Tokens;
        int v18 = __cil_callvirt_0A0000AD(v17);
        __cil_callvirt_0A0000AE(v14, v15, v18);
        global::OpenRA.Actor v19 = this;
        int v20 = __cil_bool_load(v19.created);
        if (v20 == 0) {
            goto IL_0087;
        } else {
            goto IL_004B;
        }
        IL_004B: ;
        global::OpenRA.Actor.ConditionState v21 = l0;
        __cil_ref_a1ea5588599d5fbda2d095f51c608645b87ddf94 v22 = v21.Notifiers;
        __cil_value_f9f6e0785a87646ee03812f16447441f10a5e25b v23 = __cil_callvirt_0A0000BE(v22);
        l1 = v23;
        try {
            IL_0057: ;
            goto IL_006E;
            IL_0059: ;
            ref __cil_value_f9f6e0785a87646ee03812f16447441f10a5e25b v24 = ref l1;
            global::OpenRA.Traits.VariableObserverNotifier v25 = __cil_value_call_0A0000BF(ref v24);
            l2 = v25;
            global::OpenRA.Traits.VariableObserverNotifier v26 = l2;
            global::OpenRA.Actor v27 = this;
            global::OpenRA.Actor v28 = this;
            __cil_ref_9b143d154984ea532d76d79bbe450e82a18101b7 v29 = v28.readOnlyConditionCache;
            __cil_callvirt_0600098D(v26, v27, v29);
            goto IL_006E;
            IL_006E: ;
            ref __cil_value_f9f6e0785a87646ee03812f16447441f10a5e25b v30 = ref l1;
            int v31 = __cil_bool_load(__cil_value_call_0A0000C0(ref v30));
            if (v31 != 0) {
                goto IL_0059;
            } else {
                goto IL_0077;
            }
            IL_0077: ;
            goto IL_0087;
        }
        finally {
            IL_0079: ;
            ref __cil_value_f9f6e0785a87646ee03812f16447441f10a5e25b v32 = ref l1;
            __cil_constrained_1B0000A7_0A000017(ref v32);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0087: ;
        return;
    }

    public int GrantCondition(string condition)
    {
        // structural signature __cil_ref_8835d10e39f00716fe41d3d63b0fc44e94205284 bytes=1512808902080E: class [System.Collections]System.Collections.Generic.Dictionary`2<int32, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(System.String.IsNullOrEmpty(condition));
        if (!(v1 == 0)) {
            return -1;
        }
        int v5 = this.nextConditionToken;
        this.nextConditionToken = unchecked(v5 + 1);
        __cil_ref_8835d10e39f00716fe41d3d63b0fc44e94205284 v11 = this.conditionTokens;
        __cil_callvirt_0A0000C2(v11, v5, condition);
        __cil_direct_06000047(this, condition, v5, __cil_bool_store(0));
        return v5;
    }

    public int RevokeCondition(int token)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 1F, 00, 00, 04, 03, 12, 00, 6F, C3, 00, 00, 0A, 2D, 4B, 12, 01, 1F, 38, 18, 28, C4, 00]
        // .code-bytes IL_0018: [00, 0A, 12, 01, 72, 19, 03, 00, 70, 28, C5, 00, 00, 0A, 12, 01, 03, 28, 13, 00, 00, 2B, 12, 01]
        // .code-bytes IL_0030: [72, 7F, 03, 00, 70, 28, C5, 00, 00, 0A, 12, 01, 02, 28, 14, 00, 00, 2B, 12, 01, 72, 8B, 03, 00]
        // .code-bytes IL_0048: [70, 28, C5, 00, 00, 0A, 12, 01, 28, C7, 00, 00, 0A, 73, 6E, 00, 00, 0A, 7A, 02, 7B, 1F, 00, 00]
        // .code-bytes IL_0060: [04, 03, 6F, C8, 00, 00, 0A, 26, 02, 06, 03, 17, 28, 47, 00, 00, 06, 15, 2A]
        // .local [0] string
        // .local [1] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0400001F OpenRA.Actor::conditionTokens
        // IL_0006: ldarg.1 1
        // IL_0007: ldloca.s 0
        // IL_0009: callvirt 0x0A0000C3 class [System.Collections]System.Collections.Generic.Dictionary`2<int32, string>::TryGetValue
        // IL_000E: brtrue.s IL_005B
        // IL_0010: ldloca.s 1
        // IL_0012: ldc.i4.s 56
        // IL_0014: ldc.i4.2 2
        // IL_0015: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_001A: ldloca.s 1
        // IL_001C: ldstr 0x70000319 [65, 116, 116, 101, 109, 112, 116, 105, 110, 103, 32, 116, 111, 32, 114, 101, 118, 111, 107, 101, 32, 99, 111, 110, 100, 105, 116, 105, 111, 110, 32, 119, 105, 116, 104, 32, 105, 110, 118, 97, 108, 105, 100, 32, 116, 111, 107, 101, 110, 32] utf16-bytes=[41, 00, 74, 00, 74, 00, 65, 00, 6D, 00, 70, 00, 74, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 72, 00, 65, 00, 76, 00, 6F, 00, 6B, 00, 65, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 64, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 77, 00, 69, 00, 74, 00, 68, 00, 20, 00, 69, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 6B, 00, 65, 00, 6E, 00, 20, 00] terminal-flag=Some(0)
        // IL_0021: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0026: ldloca.s 1
        // IL_0028: ldarg.1 1
        // IL_0029: call 0x2B000013 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_002E: ldloca.s 1
        // IL_0030: ldstr 0x7000037F [32, 102, 111, 114, 32] utf16-bytes=[20, 00, 66, 00, 6F, 00, 72, 00, 20, 00] terminal-flag=Some(0)
        // IL_0035: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_003A: ldloca.s 1
        // IL_003C: ldarg.0 0
        // IL_003D: call 0x2B000014 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<class OpenRA.Actor>
        // IL_0042: ldloca.s 1
        // IL_0044: ldstr 0x7000038B [46] utf16-bytes=[2E, 00] terminal-flag=Some(0)
        // IL_0049: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_004E: ldloca.s 1
        // IL_0050: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0055: newobj 0x0A00006E [System.Runtime]System.InvalidOperationException::.ctor
        // IL_005A: throw 
        // IL_005B: ldarg.0 0
        // IL_005C: ldfld 0x0400001F OpenRA.Actor::conditionTokens
        // IL_0061: ldarg.1 1
        // IL_0062: callvirt 0x0A0000C8 class [System.Collections]System.Collections.Generic.Dictionary`2<int32, string>::Remove
        // IL_0067: pop 
        // IL_0068: ldarg.0 0
        // IL_0069: ldloc.0 0
        // IL_006A: ldarg.1 1
        // IL_006B: ldc.i4.1 1
        // IL_006C: call 0x06000047 OpenRA.Actor::UpdateConditionState
        // IL_0071: ldc.i4.m1 -1
        // IL_0072: ret 
    }

    public bool TokenValid(int token)
    {
        // structural signature __cil_ref_8835d10e39f00716fe41d3d63b0fc44e94205284 bytes=1512808902080E: class [System.Collections]System.Collections.Generic.Dictionary`2<int32, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_8835d10e39f00716fe41d3d63b0fc44e94205284 v1 = this.conditionTokens;
        return __cil_callvirt_0A0000C9(v1, token);
    }

    public virtual void OnScriptBind(OpenRA.Scripting.ScriptContext context)
    {
        // structural signature __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 bytes=151280910112867C: class [System.Runtime]System.Lazy`1<class OpenRA.Scripting.ScriptActorInterface>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_94c1ce2189f22b7ceea5ff2dccea3886afc0bca9 bytes=151281210112867C: class [System.Runtime]System.Func`1<class OpenRA.Scripting.ScriptActorInterface>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Actor.__name_3C3E635F5F446973706C6179436C6173733130395F30 l0 = default;
        global::OpenRA.Actor.__name_3C3E635F5F446973706C6179436C6173733130395F30 v0 = __cil_newobj_06000F57();
        l0 = v0;
        global::OpenRA.Actor.__name_3C3E635F5F446973706C6179436C6173733130395F30 v1 = l0;
        v1.context = context;
        global::OpenRA.Actor.__name_3C3E635F5F446973706C6179436C6173733130395F30 v3 = l0;
        v3.__il_field_0400093B = this;
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 v6 = this.luaInterface;
        if (v6 is not null) {
            goto IL_0033;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        global::OpenRA.Actor.__name_3C3E635F5F446973706C6179436C6173733130395F30 v8 = l0;
        nint v9 = __cil_ldftn_06000F58;
        __cil_ref_94c1ce2189f22b7ceea5ff2dccea3886afc0bca9 v10 = __cil_newobj_0A0000CA(v8, v9);
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 v11 = __cil_methodspec_call_2B000015(v10);
        this.luaInterface = v11;
        IL_0033: ;
        return;
    }

    public virtual Eluant.LuaValue get_Item(Eluant.LuaRuntime runtime, Eluant.LuaValue keyValue)
    {
        // structural signature __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 bytes=151280910112867C: class [System.Runtime]System.Lazy`1<class OpenRA.Scripting.ScriptActorInterface>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 v1 = this.luaInterface;
        global::OpenRA.Scripting.ScriptActorInterface v2 = __cil_callvirt_0A0000CB(v1);
        __cil_type_0100002E v5 = __cil_callvirt_060009FF(v2, runtime, keyValue);
        return v5;
    }

    public virtual void set_Item(Eluant.LuaRuntime runtime, Eluant.LuaValue keyValue, Eluant.LuaValue value)
    {
        // structural signature __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 bytes=151280910112867C: class [System.Runtime]System.Lazy`1<class OpenRA.Scripting.ScriptActorInterface>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 v1 = this.luaInterface;
        global::OpenRA.Scripting.ScriptActorInterface v2 = __cil_callvirt_0A0000CB(v1);
        __cil_callvirt_06000A00(v2, runtime, keyValue, value);
        return;
    }

    public virtual Eluant.LuaValue Equals(Eluant.LuaRuntime runtime, Eluant.LuaValue left, Eluant.LuaValue right)
    {
        OpenRA.Actor l0 = default;
        OpenRA.Actor l1 = default;
        IL_0000: ;
        __cil_type_0100002E v0 = left;
        ref global::OpenRA.Actor v1 = ref l0;
        int v2 = __cil_bool_load(__cil_methodspec_call_2B000016(v0, ref v1));
        if (v2 == 0) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        __cil_type_0100002E v3 = right;
        ref global::OpenRA.Actor v4 = ref l1;
        int v5 = __cil_bool_load(__cil_methodspec_call_2B000016(v3, ref v4));
        if (v5 != 0) {
            goto IL_001B;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        int v6 = 0;
        __cil_type_0100002E v7 = Eluant.LuaValue.op_Implicit(__cil_bool_store(v6));
        return v7;
        IL_001B: ;
        global::OpenRA.Actor v8 = l0;
        global::OpenRA.Actor v9 = l1;
        int v10 = (System.Object.ReferenceEquals(v8, v9) ? 1 : 0);
        __cil_type_0100002E v11 = Eluant.LuaValue.op_Implicit(__cil_bool_store(v10));
        return v11;
    }

    public virtual Eluant.LuaValue ToString(Eluant.LuaRuntime runtime)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [12, 00, 1E, 17, 28, C4, 00, 00, 0A, 12, 00, 72, 8F, 03, 00, 70, 28, C5, 00, 00, 0A, 12, 00, 02]
        // .code-bytes IL_0018: [28, 14, 00, 00, 2B, 12, 00, 72, 9F, 03, 00, 70, 28, C5, 00, 00, 0A, 12, 00, 28, C7, 00, 00, 0A]
        // .code-bytes IL_0030: [28, CD, 00, 00, 0A, 2A]
        // .local [0] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldloca.s 0
        // IL_0002: ldc.i4.8 8
        // IL_0003: ldc.i4.1 1
        // IL_0004: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0009: ldloca.s 0
        // IL_000B: ldstr 0x7000038F [65, 99, 116, 111, 114, 32, 40] utf16-bytes=[41, 00, 63, 00, 74, 00, 6F, 00, 72, 00, 20, 00, 28, 00] terminal-flag=Some(0)
        // IL_0010: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0015: ldloca.s 0
        // IL_0017: ldarg.0 0
        // IL_0018: call 0x2B000014 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<class OpenRA.Actor>
        // IL_001D: ldloca.s 0
        // IL_001F: ldstr 0x7000039F [41] utf16-bytes=[29, 00] terminal-flag=Some(0)
        // IL_0024: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0029: ldloca.s 0
        // IL_002B: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0030: call 0x0A0000CD [Eluant]Eluant.LuaValue::op_Implicit
        // IL_0035: ret 
    }

    public bool HasScriptProperty(string name)
    {
        // structural signature __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 bytes=151280910112867C: class [System.Runtime]System.Lazy`1<class OpenRA.Scripting.ScriptActorInterface>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 v1 = this.luaInterface;
        global::OpenRA.Scripting.ScriptActorInterface v2 = __cil_callvirt_0A0000CB(v1);
        return __cil_callvirt_060009FE(v2, name);
    }

    // Metadata name: <.ctor>b__73_2
    private System.Collections.Generic.IEnumerable<OpenRA.WPos> CtorLambda73_2(OpenRA.Traits.ITargetablePositions tp)
    {
        // structural signature __cil_ref_2252aeb1ccc162eb7ab9aad45cdf6c598e000244 bytes=1512808501118338: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_2252aeb1ccc162eb7ab9aad45cdf6c598e000244 v2 = __cil_callvirt_0600097C(tp, this);
        return v2;
    }

    // Metadata name: <Dispose>b__92_0
    private void DisposeLambda92_0(OpenRA.World w)
    {
        // structural signature __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 bytes=151280910112867C: class [System.Runtime]System.Lazy`1<class OpenRA.Scripting.ScriptActorInterface>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b750902138fed736ab4c51ef9abf2c67ddae6d3e bytes=151280A1011284DC: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Traits.INotifyActorDisposing>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_cfd30e44338dd48b9f6d4c4f2db5c26c050f1bda bytes=15128085011284DC: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Traits.INotifyActorDisposing>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_b750902138fed736ab4c51ef9abf2c67ddae6d3e l0 = default;
        OpenRA.Traits.INotifyActorDisposing l1 = default;
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 s13_0 = default;
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 s14_0 = default;
        IL_0000: ;
        global::OpenRA.Actor v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000019(v0));
        if (v1 == 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        global::OpenRA.Actor v2 = this;
        int v3 = __cil_bool_load(__cil_direct_06000015(v2));
        if (v3 == 0) {
            goto IL_001D;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        global::OpenRA.Actor v4 = this;
        global::OpenRA.World v5 = v4.World;
        global::OpenRA.Actor v6 = this;
        __cil_callvirt_06000677(v5, v6);
        goto IL_001D;
        IL_001D: ;
        global::OpenRA.Actor v7 = this;
        __cil_ref_cfd30e44338dd48b9f6d4c4f2db5c26c050f1bda v8 = __cil_methodspec_call_2B000017(v7);
        __cil_ref_b750902138fed736ab4c51ef9abf2c67ddae6d3e v9 = __cil_callvirt_0A0000CE(v8);
        l0 = v9;
        try {
            IL_0029: ;
            goto IL_0039;
            IL_002B: ;
            __cil_ref_b750902138fed736ab4c51ef9abf2c67ddae6d3e v10 = l0;
            global::OpenRA.Traits.INotifyActorDisposing v11 = __cil_callvirt_0A0000CF(v10);
            l1 = v11;
            global::OpenRA.Traits.INotifyActorDisposing v12 = l1;
            global::OpenRA.Actor v13 = this;
            __cil_callvirt_060008E6(v12, v13);
            goto IL_0039;
            IL_0039: ;
            __cil_ref_b750902138fed736ab4c51ef9abf2c67ddae6d3e v14 = l0;
            int v15 = __cil_bool_load(__cil_callvirt_0A000018(v14));
            if (v15 != 0) {
                goto IL_002B;
            } else {
                goto IL_0041;
            }
            IL_0041: ;
            goto IL_004D;
        }
        finally {
            IL_0043: ;
            __cil_ref_b750902138fed736ab4c51ef9abf2c67ddae6d3e v16 = l0;
            if (v16 is null) {
                goto IL_004C;
            } else {
                goto IL_0046;
            }
            IL_0046: ;
            __cil_ref_b750902138fed736ab4c51ef9abf2c67ddae6d3e v17 = l0;
            __cil_callvirt_0A000017(v17);
            goto IL_004C;
            IL_004C: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_004D: ;
        global::OpenRA.Actor v18 = this;
        global::OpenRA.World v19 = v18.World;
        global::OpenRA.TraitDictionary v20 = v19.TraitDict;
        global::OpenRA.Actor v21 = this;
        __cil_callvirt_060005FD(v20, v21);
        global::OpenRA.Actor v22 = this;
        int v23 = 1;
        __cil_direct_0600001A(v22, __cil_bool_store(v23));
        global::OpenRA.Actor v24 = this;
        __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 v25 = v24.luaInterface;
        if (v25 is not null) {
            __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 e12_14_0 = v25;
            s14_0 = e12_14_0;
            goto IL_0070;
        } else {
            __cil_ref_a5c6644525e41dc527538bdf184f8a89a906f702 e12_13_0 = v25;
            s13_0 = e12_13_0;
            goto IL_006E;
        }
        IL_006E: ;
        return;
        IL_0070: ;
        global::OpenRA.Scripting.ScriptActorInterface v26 = __cil_reference_call_0A0000CB(s14_0);
        __cil_callvirt_060009CF(v26);
        return;
    }
    // property OpenRA.Player Owner { get: get_Owner; set: set_Owner; }
    // property bool IsInWorld { get: get_IsInWorld; set: set_IsInWorld; }
    // property bool WillDispose { get: get_WillDispose; set: set_WillDispose; }
    // property bool Disposed { get: get_Disposed; set: set_Disposed; }
    // property OpenRA.Activities.Activity CurrentActivity { get: get_CurrentActivity; set: set_CurrentActivity; }
    // property OpenRA.Traits.IEffectiveOwner EffectiveOwner { get: get_EffectiveOwner; }
    // property OpenRA.Traits.IOccupySpace OccupiesSpace { get: get_OccupiesSpace; }
    // property OpenRA.Traits.ITargetable[] Targetables { get: get_Targetables; }
    // property System.Collections.Generic.IEnumerable<OpenRA.Traits.ITargetablePositions> EnabledTargetablePositions { get: get_EnabledTargetablePositions; }
    // property OpenRA.Traits.ICrushable[] Crushables { get: get_Crushables; }
    // property bool IsIdle { get: get_IsIdle; }
    // property bool IsDead { get: get_IsDead; }
    // property OpenRA.CPos Location { get: get_Location; }
    // property OpenRA.WPos CenterPosition { get: get_CenterPosition; }
    // property OpenRA.WRot Orientation { get: get_Orientation; }
    // property OpenRA.Actor.SyncHash[] SyncHashes { get: get_SyncHashes; }
    // property Eluant.LuaValue this[Eluant.LuaRuntime index0, Eluant.LuaValue index1] { get: get_Item; set: set_Item; }

    internal struct SyncHash
    {
        public readonly OpenRA.ISync Trait;
        private readonly System.Func<object, int> hashFunction;

        public SyncHash(OpenRA.ISync trait)
        {
            // structural signature __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 bytes=118934: valuetype OpenRA.Actor/SyncHash; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_a27a363be3eb26a48336e4982333b975268da739 bytes=151280C9021C08: class [System.Runtime]System.Func`2<object, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            IL_0000: ;
            ref __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 v0 = ref this;
            global::OpenRA.ISync v1 = trait;
            v0.Trait = v1;
            ref __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 v2 = ref this;
            global::OpenRA.ISync v3 = trait;
            __cil_ref_a27a363be3eb26a48336e4982333b975268da739 v4 = OpenRA.Sync.GetHashFunction(v3);
            v2.hashFunction = v4;
            return;
        }

        public int Hash()
        {
            // structural signature __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 bytes=118934: valuetype OpenRA.Actor/SyncHash; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_a27a363be3eb26a48336e4982333b975268da739 bytes=151280C9021C08: class [System.Runtime]System.Func`2<object, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            IL_0000: ;
            ref __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 v0 = ref this;
            __cil_ref_a27a363be3eb26a48336e4982333b975268da739 v1 = v0.hashFunction;
            ref __cil_value_51c81d3efeaee076a2690bb6351cdbdebaff8c39 v2 = ref this;
            global::OpenRA.ISync v3 = v2.Trait;
            int v4 = __cil_callvirt_0A000545(v1, ((object)(v3)));
            return v4;
        }
    }

    private sealed class ConditionState
    {
        public readonly System.Collections.Generic.List<OpenRA.Traits.VariableObserverNotifier> Notifiers;
        public readonly System.Collections.Generic.HashSet<int> Tokens;

        public ConditionState()
        {
            // structural signature __cil_ref_a1ea5588599d5fbda2d095f51c608645b87ddf94 bytes=1512809D0112863C: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Traits.VariableObserverNotifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 bytes=151280A50108: class [System.Collections]System.Collections.Generic.HashSet`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_a1ea5588599d5fbda2d095f51c608645b87ddf94 v1 = __cil_newobj_0A000B61();
            this.Notifiers = v1;
            __cil_ref_7a4e97a744979afdaa422d20ad8129c65f532f65 v3 = __cil_newobj_0A000259();
            this.Tokens = v3;
            __cil_core_object_ctor_0A00005B(this);
            return;
        }
    }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Actor.__name_3C3E63 __il_field_04000937;
        public static System.Func<OpenRA.ISingleInstanceInit, System.Type> __il_field_04000938;
        public static System.Func<System.Linq.IGrouping<System.Type, OpenRA.ISingleInstanceInit>, bool> __il_field_04000939;

        static __name_3C3E63()
        {
            global::OpenRA.Actor.__name_3C3E63 v0 = __cil_newobj_06000F54();
            OpenRA.Actor.__name_3C3E63.__il_field_04000937 = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <.ctor>b__73_0
        internal System.Type CtorLambda73_0(OpenRA.ISingleInstanceInit i)
        {
            __cil_type_01000026 v1 = i.GetType();
            return v1;
        }

        // Metadata name: <.ctor>b__73_1
        internal bool CtorLambda73_1(System.Linq.IGrouping<System.Type, OpenRA.ISingleInstanceInit> i)
        {
            // structural signature __cil_ref_f90f5e89654f7f2c90ad53d6bcfb2198b802887b bytes=151280950212809912815C: class [System.Linq]System.Linq.IGrouping`2<class [System.Runtime]System.Type, class OpenRA.ISingleInstanceInit>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_3068a8a095bb7abd67532866d38907a458e13efd bytes=151280850112815C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.ISingleInstanceInit>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            int v1 = __cil_methodspec_call_2B000265(((__cil_ref_3068a8a095bb7abd67532866d38907a458e13efd)(i)));
            return (v1 > 1);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733130395F30
    {
        public OpenRA.Scripting.ScriptContext context;
        public OpenRA.Actor __il_field_0400093B;

        public __name_3C3E635F5F446973706C6179436C6173733130395F30() : base()
        {
            return;
        }

        // Metadata name: <OnScriptBind>b__0
        internal OpenRA.Scripting.ScriptActorInterface OnScriptBindLambda0()
        {
            global::OpenRA.Scripting.ScriptContext v1 = this.context;
            global::OpenRA.Actor v3 = this.__il_field_0400093B;
            global::OpenRA.Scripting.ScriptActorInterface v4 = __cil_newobj_060009CD(v1, v3);
            return v4;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737339345F30
    {
        public OpenRA.Actor __il_field_0400093C;
        public OpenRA.Player newOwner;

        public __name_3C3E635F5F446973706C6179436C61737339345F30() : base()
        {
            return;
        }

        // Metadata name: <ChangeOwner>b__0
        internal void ChangeOwnerLambda0(OpenRA.World _)
        {
            global::OpenRA.Actor v1 = this.__il_field_0400093C;
            global::OpenRA.Player v3 = this.newOwner;
            __cil_direct_0600003E(v1, v3);
            return;
        }
    }

    private sealed class __name_3C426F756E64733E645F5F3739 : System.Collections.Generic.IEnumerable<OpenRA.Primitives.Rectangle>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Primitives.Rectangle>, System.Collections.IEnumerator, System.IDisposable
    {
        private int __il_field_0400093E;
        private OpenRA.Primitives.Rectangle __il_field_0400093F;
        private int __il_field_04000940;
        public OpenRA.Actor __il_field_04000941;
        private OpenRA.Graphics.WorldRenderer wr;
        public OpenRA.Graphics.WorldRenderer __il_field_04000943;
        private OpenRA.Traits.IRender[] __il_field_04000944;
        private int __il_field_04000945;
        private System.Collections.Generic.IEnumerator<OpenRA.Primitives.Rectangle> __il_field_04000946;

        public __name_3C426F756E64733E645F5F3739(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_0400093E = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04000940 = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            // structural signature __cil_ref_f2189fbae1088f92ed01372332e33af0e257a590 bytes=1D1284A4: class OpenRA.Traits.IRender[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f bytes=151280A101118718: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            int l0 = default;
            IL_0000: ;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v0 = this;
            int v1 = v0.__il_field_0400093E;
            l0 = v1;
            int v2 = l0;
            int v3 = -3;
            if (v2 == v3) {
                goto IL_0010;
            } else {
                goto IL_000C;
            }
            IL_000C: ;
            int v4 = l0;
            int v5 = 1;
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_001A;
            } else {
                goto IL_0010;
            }
            IL_0010: ;
            try {
                IL_0011: ;
                goto IL_001A;
            }
            finally {
                IL_0013: ;
                global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v6 = this;
                __cil_direct_06000F5E(v6);
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_001A: ;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v7 = this;
            v7.__il_field_04000944 = null;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v8 = this;
            v8.__il_field_04000946 = null;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v9 = this;
            int v10 = -2;
            v9.__il_field_0400093E = v10;
            return;
        }

        private virtual bool MoveNext()
        {
            // IL fallback: EH fault handlers need exceptional-only cleanup
            // .maxstack 4
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, 3E, 09, 00, 04, 0B, 02, 7B, 41, 09, 00, 04, 0C, 07, 2C, 0B, 07, 17, 2E, 7F, 16, 0A, DD]
            // .code-bytes IL_0018: [CD, 00, 00, 00, 02, 15, 7D, 3E, 09, 00, 04, 02, 08, 7B, 28, 00, 00, 04, 7D, 44, 09, 00, 04, 02]
            // .code-bytes IL_0030: [16, 7D, 45, 09, 00, 04, 38, 89, 00, 00, 00, 02, 7B, 44, 09, 00, 04, 02, 7B, 45, 09, 00, 04, 9A]
            // .code-bytes IL_0048: [0D, 02, 09, 08, 02, 7B, 42, 09, 00, 04, 6F, D5, 08, 00, 06, 6F, 1C, 00, 00, 0A, 7D, 46, 09, 00]
            // .code-bytes IL_0060: [04, 02, 1F, FD, 7D, 3E, 09, 00, 04, 2B, 31, 02, 7B, 46, 09, 00, 04, 6F, 19, 00, 00, 0A, 13, 04]
            // .code-bytes IL_0078: [12, 04, 28, BE, 0B, 00, 06, 2D, 1B, 02, 11, 04, 7D, 3F, 09, 00, 04, 02, 17, 7D, 3E, 09, 00, 04]
            // .code-bytes IL_0090: [17, 0A, DE, 55, 02, 1F, FD, 7D, 3E, 09, 00, 04, 02, 7B, 46, 09, 00, 04, 6F, 18, 00, 00, 0A, 2D]
            // .code-bytes IL_00A8: [C2, 02, 28, 5E, 0F, 00, 06, 02, 14, 7D, 46, 09, 00, 04, 02, 02, 7B, 45, 09, 00, 04, 17, 58, 7D]
            // .code-bytes IL_00C0: [45, 09, 00, 04, 02, 7B, 45, 09, 00, 04, 02, 7B, 44, 09, 00, 04, 8E, 69, 3F, 64, FF, FF, FF, 02]
            // .code-bytes IL_00D8: [14, 7D, 44, 09, 00, 04, 16, 0A, DE, 07, 02, 28, 5C, 0F, 00, 06, DC, 06, 2A]
            // .local [0] bool
            // .local [1] int32
            // .local [2] class OpenRA.Actor
            // .local [3] class OpenRA.Traits.IRender
            // .local [4] valuetype OpenRA.Primitives.Rectangle
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x0400093E OpenRA.Actor/<Bounds>d__79::<>1__state
            // IL_0006: stloc.1 1
            // IL_0007: ldarg.0 0
            // IL_0008: ldfld 0x04000941 OpenRA.Actor/<Bounds>d__79::<>4__this
            // IL_000D: stloc.2 2
            // IL_000E: ldloc.1 1
            // IL_000F: brfalse.s IL_001C
            // IL_0011: ldloc.1 1
            // IL_0012: ldc.i4.1 1
            // IL_0013: beq.s IL_0094
            // IL_0015: ldc.i4.0 0
            // IL_0016: stloc.0 0
            // IL_0017: leave IL_00E9
            // IL_001C: ldarg.0 0
            // IL_001D: ldc.i4.m1 -1
            // IL_001E: stfld 0x0400093E OpenRA.Actor/<Bounds>d__79::<>1__state
            // IL_0023: ldarg.0 0
            // IL_0024: ldloc.2 2
            // IL_0025: ldfld 0x04000028 OpenRA.Actor::renders
            // IL_002A: stfld 0x04000944 OpenRA.Actor/<Bounds>d__79::<>7__wrap1
            // IL_002F: ldarg.0 0
            // IL_0030: ldc.i4.0 0
            // IL_0031: stfld 0x04000945 OpenRA.Actor/<Bounds>d__79::<>7__wrap2
            // IL_0036: br IL_00C4
            // IL_003B: ldarg.0 0
            // IL_003C: ldfld 0x04000944 OpenRA.Actor/<Bounds>d__79::<>7__wrap1
            // IL_0041: ldarg.0 0
            // IL_0042: ldfld 0x04000945 OpenRA.Actor/<Bounds>d__79::<>7__wrap2
            // IL_0047: ldelem.ref 
            // IL_0048: stloc.3 3
            // IL_0049: ldarg.0 0
            // IL_004A: ldloc.3 3
            // IL_004B: ldloc.2 2
            // IL_004C: ldarg.0 0
            // IL_004D: ldfld 0x04000942 OpenRA.Actor/<Bounds>d__79::wr
            // IL_0052: callvirt 0x060008D5 OpenRA.Traits.IRender::ScreenBounds
            // IL_0057: callvirt 0x0A00001C class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.Primitives.Rectangle>::GetEnumerator
            // IL_005C: stfld 0x04000946 OpenRA.Actor/<Bounds>d__79::<>7__wrap3
            // IL_0061: ldarg.0 0
            // IL_0062: ldc.i4.s -3
            // IL_0064: stfld 0x0400093E OpenRA.Actor/<Bounds>d__79::<>1__state
            // IL_0069: br.s IL_009C
            // IL_006B: ldarg.0 0
            // IL_006C: ldfld 0x04000946 OpenRA.Actor/<Bounds>d__79::<>7__wrap3
            // IL_0071: callvirt 0x0A000019 class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.Primitives.Rectangle>::get_Current
            // IL_0076: stloc.s 4
            // IL_0078: ldloca.s 4
            // IL_007A: call 0x06000BBE OpenRA.Primitives.Rectangle::get_IsEmpty
            // IL_007F: brtrue.s IL_009C
            // IL_0081: ldarg.0 0
            // IL_0082: ldloc.s 4
            // IL_0084: stfld 0x0400093F OpenRA.Actor/<Bounds>d__79::<>2__current
            // IL_0089: ldarg.0 0
            // IL_008A: ldc.i4.1 1
            // IL_008B: stfld 0x0400093E OpenRA.Actor/<Bounds>d__79::<>1__state
            // IL_0090: ldc.i4.1 1
            // IL_0091: stloc.0 0
            // IL_0092: leave.s IL_00E9
            // IL_0094: ldarg.0 0
            // IL_0095: ldc.i4.s -3
            // IL_0097: stfld 0x0400093E OpenRA.Actor/<Bounds>d__79::<>1__state
            // IL_009C: ldarg.0 0
            // IL_009D: ldfld 0x04000946 OpenRA.Actor/<Bounds>d__79::<>7__wrap3
            // IL_00A2: callvirt 0x0A000018 [System.Runtime]System.Collections.IEnumerator::MoveNext
            // IL_00A7: brtrue.s IL_006B
            // IL_00A9: ldarg.0 0
            // IL_00AA: call 0x06000F5E OpenRA.Actor/<Bounds>d__79::<>m__Finally1
            // IL_00AF: ldarg.0 0
            // IL_00B0: ldnull 
            // IL_00B1: stfld 0x04000946 OpenRA.Actor/<Bounds>d__79::<>7__wrap3
            // IL_00B6: ldarg.0 0
            // IL_00B7: ldarg.0 0
            // IL_00B8: ldfld 0x04000945 OpenRA.Actor/<Bounds>d__79::<>7__wrap2
            // IL_00BD: ldc.i4.1 1
            // IL_00BE: add 
            // IL_00BF: stfld 0x04000945 OpenRA.Actor/<Bounds>d__79::<>7__wrap2
            // IL_00C4: ldarg.0 0
            // IL_00C5: ldfld 0x04000945 OpenRA.Actor/<Bounds>d__79::<>7__wrap2
            // IL_00CA: ldarg.0 0
            // IL_00CB: ldfld 0x04000944 OpenRA.Actor/<Bounds>d__79::<>7__wrap1
            // IL_00D0: ldlen 
            // IL_00D1: conv.i4 
            // IL_00D2: blt IL_003B
            // IL_00D7: ldarg.0 0
            // IL_00D8: ldnull 
            // IL_00D9: stfld 0x04000944 OpenRA.Actor/<Bounds>d__79::<>7__wrap1
            // IL_00DE: ldc.i4.0 0
            // IL_00DF: stloc.0 0
            // IL_00E0: leave.s IL_00E9
            // IL_00E2: ldarg.0 0
            // IL_00E3: call 0x06000F5C OpenRA.Actor/<Bounds>d__79::System.IDisposable.Dispose
            // IL_00E8: endfinally 
            // IL_00E9: ldloc.0 0
            // IL_00EA: ret 
            // .eh-raw ExceptionHandler { kind: Fault, try_offset: 0, try_length: 226, handler_offset: 226, handler_length: 7, raw_flags: 4 }
            // .try IL_0000..IL_00E2 fault IL_00E2..IL_00E9
        }

        private void __name_3C3E6D5F5F46696E616C6C7931()
        {
            // structural signature __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f bytes=151280A101118718: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            this.__il_field_0400093E = -1;
            __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v3 = this.__il_field_04000946;
            if (v3 is null) {
                goto IL_001A;
            } else {
                goto IL_000F;
            }
            IL_000F: ;
            __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v5 = this.__il_field_04000946;
            __cil_callvirt_0A000017(v5);
            IL_001A: ;
            return;
        }

        private virtual OpenRA.Primitives.Rectangle __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5072696D6974697665732E52656374616E676C653E2E6765745F43757272656E74()
        {
            // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v1 = this.__il_field_0400093F;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A000870();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v1 = this.__il_field_0400093F;
            object v2 = ((object)((__cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73)(v1)));
            return v2;
        }

        private virtual System.Collections.Generic.IEnumerator<OpenRA.Primitives.Rectangle> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E5072696D6974697665732E52656374616E676C653E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f bytes=151280A101118718: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            OpenRA.Actor.__name_3C426F756E64733E645F5F3739 l0 = default;
            int v1 = this.__il_field_0400093E;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04000940;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_0400093E = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v10 = __cil_newobj_06000F5B(0);
            l0 = v10;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v11 = l0;
            global::OpenRA.Actor v13 = this.__il_field_04000941;
            v11.__il_field_04000941 = v13;
            IL_0035: ;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v14 = l0;
            global::OpenRA.Graphics.WorldRenderer v16 = this.__il_field_04000943;
            v14.wr = v16;
            global::OpenRA.Actor.__name_3C426F756E64733E645F5F3739 v17 = l0;
            return v17;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f bytes=151280A101118718: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v1 = __cil_direct_06000F62(this);
            return v1;
        }
        // property OpenRA.Primitives.Rectangle __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5072696D6974697665732E52656374616E676C653E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5072696D6974697665732E52656374616E676C653E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }

    private sealed class __name_3C52656E64657261626C65733E645F5F3737 : System.Collections.Generic.IEnumerable<OpenRA.Graphics.IRenderable>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Graphics.IRenderable>, System.Collections.IEnumerator, System.IDisposable
    {
        private int __il_field_04000947;
        private OpenRA.Graphics.IRenderable __il_field_04000948;
        private int __il_field_04000949;
        public OpenRA.Actor __il_field_0400094A;
        private OpenRA.Graphics.WorldRenderer wr;
        public OpenRA.Graphics.WorldRenderer __il_field_0400094C;
        private OpenRA.Traits.IRender[] __il_field_0400094D;
        private int __il_field_0400094E;
        private System.Collections.Generic.IEnumerator<OpenRA.Graphics.IRenderable> __il_field_0400094F;

        public __name_3C52656E64657261626C65733E645F5F3737(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_04000947 = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04000949 = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            // structural signature __cil_ref_f2189fbae1088f92ed01372332e33af0e257a590 bytes=1D1284A4: class OpenRA.Traits.IRender[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_e48ccfba4f0ef4e5ffd37a8d6c15e33e7cdc81b5 bytes=151280A10112880C: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Graphics.IRenderable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            int l0 = default;
            IL_0000: ;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v0 = this;
            int v1 = v0.__il_field_04000947;
            l0 = v1;
            int v2 = l0;
            int v3 = -3;
            if (v2 == v3) {
                goto IL_0010;
            } else {
                goto IL_000C;
            }
            IL_000C: ;
            int v4 = l0;
            int v5 = 1;
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_001A;
            } else {
                goto IL_0010;
            }
            IL_0010: ;
            try {
                IL_0011: ;
                goto IL_001A;
            }
            finally {
                IL_0013: ;
                global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v6 = this;
                __cil_direct_06000F67(v6);
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_001A: ;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v7 = this;
            v7.__il_field_0400094D = null;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v8 = this;
            v8.__il_field_0400094F = null;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v9 = this;
            int v10 = -2;
            v9.__il_field_04000947 = v10;
            return;
        }

        private virtual bool MoveNext()
        {
            // IL fallback: EH fault handlers need exceptional-only cleanup
            // .maxstack 4
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, 47, 09, 00, 04, 0B, 02, 7B, 4A, 09, 00, 04, 0C, 07, 2C, 0B, 07, 17, 2E, 76, 16, 0A, DD]
            // .code-bytes IL_0018: [C4, 00, 00, 00, 02, 15, 7D, 47, 09, 00, 04, 02, 08, 7B, 28, 00, 00, 04, 7D, 4D, 09, 00, 04, 02]
            // .code-bytes IL_0030: [16, 7D, 4E, 09, 00, 04, 38, 80, 00, 00, 00, 02, 7B, 4D, 09, 00, 04, 02, 7B, 4E, 09, 00, 04, 9A]
            // .code-bytes IL_0048: [0D, 02, 09, 08, 02, 7B, 4B, 09, 00, 04, 6F, D4, 08, 00, 06, 6F, 1F, 00, 00, 0A, 7D, 4F, 09, 00]
            // .code-bytes IL_0060: [04, 02, 1F, FD, 7D, 47, 09, 00, 04, 2B, 28, 02, 7B, 4F, 09, 00, 04, 6F, 1E, 00, 00, 0A, 13, 04]
            // .code-bytes IL_0078: [02, 11, 04, 7D, 48, 09, 00, 04, 02, 17, 7D, 47, 09, 00, 04, 17, 0A, DE, 55, 02, 1F, FD, 7D, 47]
            // .code-bytes IL_0090: [09, 00, 04, 02, 7B, 4F, 09, 00, 04, 6F, 18, 00, 00, 0A, 2D, CB, 02, 28, 67, 0F, 00, 06, 02, 14]
            // .code-bytes IL_00A8: [7D, 4F, 09, 00, 04, 02, 02, 7B, 4E, 09, 00, 04, 17, 58, 7D, 4E, 09, 00, 04, 02, 7B, 4E, 09, 00]
            // .code-bytes IL_00C0: [04, 02, 7B, 4D, 09, 00, 04, 8E, 69, 3F, 6D, FF, FF, FF, 02, 14, 7D, 4D, 09, 00, 04, 16, 0A, DE]
            // .code-bytes IL_00D8: [07, 02, 28, 65, 0F, 00, 06, DC, 06, 2A]
            // .local [0] bool
            // .local [1] int32
            // .local [2] class OpenRA.Actor
            // .local [3] class OpenRA.Traits.IRender
            // .local [4] class OpenRA.Graphics.IRenderable
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04000947 OpenRA.Actor/<Renderables>d__77::<>1__state
            // IL_0006: stloc.1 1
            // IL_0007: ldarg.0 0
            // IL_0008: ldfld 0x0400094A OpenRA.Actor/<Renderables>d__77::<>4__this
            // IL_000D: stloc.2 2
            // IL_000E: ldloc.1 1
            // IL_000F: brfalse.s IL_001C
            // IL_0011: ldloc.1 1
            // IL_0012: ldc.i4.1 1
            // IL_0013: beq.s IL_008B
            // IL_0015: ldc.i4.0 0
            // IL_0016: stloc.0 0
            // IL_0017: leave IL_00E0
            // IL_001C: ldarg.0 0
            // IL_001D: ldc.i4.m1 -1
            // IL_001E: stfld 0x04000947 OpenRA.Actor/<Renderables>d__77::<>1__state
            // IL_0023: ldarg.0 0
            // IL_0024: ldloc.2 2
            // IL_0025: ldfld 0x04000028 OpenRA.Actor::renders
            // IL_002A: stfld 0x0400094D OpenRA.Actor/<Renderables>d__77::<>7__wrap1
            // IL_002F: ldarg.0 0
            // IL_0030: ldc.i4.0 0
            // IL_0031: stfld 0x0400094E OpenRA.Actor/<Renderables>d__77::<>7__wrap2
            // IL_0036: br IL_00BB
            // IL_003B: ldarg.0 0
            // IL_003C: ldfld 0x0400094D OpenRA.Actor/<Renderables>d__77::<>7__wrap1
            // IL_0041: ldarg.0 0
            // IL_0042: ldfld 0x0400094E OpenRA.Actor/<Renderables>d__77::<>7__wrap2
            // IL_0047: ldelem.ref 
            // IL_0048: stloc.3 3
            // IL_0049: ldarg.0 0
            // IL_004A: ldloc.3 3
            // IL_004B: ldloc.2 2
            // IL_004C: ldarg.0 0
            // IL_004D: ldfld 0x0400094B OpenRA.Actor/<Renderables>d__77::wr
            // IL_0052: callvirt 0x060008D4 OpenRA.Traits.IRender::Render
            // IL_0057: callvirt 0x0A00001F class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Graphics.IRenderable>::GetEnumerator
            // IL_005C: stfld 0x0400094F OpenRA.Actor/<Renderables>d__77::<>7__wrap3
            // IL_0061: ldarg.0 0
            // IL_0062: ldc.i4.s -3
            // IL_0064: stfld 0x04000947 OpenRA.Actor/<Renderables>d__77::<>1__state
            // IL_0069: br.s IL_0093
            // IL_006B: ldarg.0 0
            // IL_006C: ldfld 0x0400094F OpenRA.Actor/<Renderables>d__77::<>7__wrap3
            // IL_0071: callvirt 0x0A00001E class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Graphics.IRenderable>::get_Current
            // IL_0076: stloc.s 4
            // IL_0078: ldarg.0 0
            // IL_0079: ldloc.s 4
            // IL_007B: stfld 0x04000948 OpenRA.Actor/<Renderables>d__77::<>2__current
            // IL_0080: ldarg.0 0
            // IL_0081: ldc.i4.1 1
            // IL_0082: stfld 0x04000947 OpenRA.Actor/<Renderables>d__77::<>1__state
            // IL_0087: ldc.i4.1 1
            // IL_0088: stloc.0 0
            // IL_0089: leave.s IL_00E0
            // IL_008B: ldarg.0 0
            // IL_008C: ldc.i4.s -3
            // IL_008E: stfld 0x04000947 OpenRA.Actor/<Renderables>d__77::<>1__state
            // IL_0093: ldarg.0 0
            // IL_0094: ldfld 0x0400094F OpenRA.Actor/<Renderables>d__77::<>7__wrap3
            // IL_0099: callvirt 0x0A000018 [System.Runtime]System.Collections.IEnumerator::MoveNext
            // IL_009E: brtrue.s IL_006B
            // IL_00A0: ldarg.0 0
            // IL_00A1: call 0x06000F67 OpenRA.Actor/<Renderables>d__77::<>m__Finally1
            // IL_00A6: ldarg.0 0
            // IL_00A7: ldnull 
            // IL_00A8: stfld 0x0400094F OpenRA.Actor/<Renderables>d__77::<>7__wrap3
            // IL_00AD: ldarg.0 0
            // IL_00AE: ldarg.0 0
            // IL_00AF: ldfld 0x0400094E OpenRA.Actor/<Renderables>d__77::<>7__wrap2
            // IL_00B4: ldc.i4.1 1
            // IL_00B5: add 
            // IL_00B6: stfld 0x0400094E OpenRA.Actor/<Renderables>d__77::<>7__wrap2
            // IL_00BB: ldarg.0 0
            // IL_00BC: ldfld 0x0400094E OpenRA.Actor/<Renderables>d__77::<>7__wrap2
            // IL_00C1: ldarg.0 0
            // IL_00C2: ldfld 0x0400094D OpenRA.Actor/<Renderables>d__77::<>7__wrap1
            // IL_00C7: ldlen 
            // IL_00C8: conv.i4 
            // IL_00C9: blt IL_003B
            // IL_00CE: ldarg.0 0
            // IL_00CF: ldnull 
            // IL_00D0: stfld 0x0400094D OpenRA.Actor/<Renderables>d__77::<>7__wrap1
            // IL_00D5: ldc.i4.0 0
            // IL_00D6: stloc.0 0
            // IL_00D7: leave.s IL_00E0
            // IL_00D9: ldarg.0 0
            // IL_00DA: call 0x06000F65 OpenRA.Actor/<Renderables>d__77::System.IDisposable.Dispose
            // IL_00DF: endfinally 
            // IL_00E0: ldloc.0 0
            // IL_00E1: ret 
            // .eh-raw ExceptionHandler { kind: Fault, try_offset: 0, try_length: 217, handler_offset: 217, handler_length: 7, raw_flags: 4 }
            // .try IL_0000..IL_00D9 fault IL_00D9..IL_00E0
        }

        private void __name_3C3E6D5F5F46696E616C6C7931()
        {
            // structural signature __cil_ref_e48ccfba4f0ef4e5ffd37a8d6c15e33e7cdc81b5 bytes=151280A10112880C: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Graphics.IRenderable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            this.__il_field_04000947 = -1;
            __cil_ref_e48ccfba4f0ef4e5ffd37a8d6c15e33e7cdc81b5 v3 = this.__il_field_0400094F;
            if (v3 is null) {
                goto IL_001A;
            } else {
                goto IL_000F;
            }
            IL_000F: ;
            __cil_ref_e48ccfba4f0ef4e5ffd37a8d6c15e33e7cdc81b5 v5 = this.__il_field_0400094F;
            __cil_callvirt_0A000017(v5);
            IL_001A: ;
            return;
        }

        private virtual OpenRA.Graphics.IRenderable __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E47726170686963732E4952656E64657261626C653E2E6765745F43757272656E74()
        {
            global::OpenRA.Graphics.IRenderable v1 = this.__il_field_04000948;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A000870();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            global::OpenRA.Graphics.IRenderable v1 = this.__il_field_04000948;
            return v1;
        }

        private virtual System.Collections.Generic.IEnumerator<OpenRA.Graphics.IRenderable> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E47726170686963732E4952656E64657261626C653E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_e48ccfba4f0ef4e5ffd37a8d6c15e33e7cdc81b5 bytes=151280A10112880C: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Graphics.IRenderable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 l0 = default;
            int v1 = this.__il_field_04000947;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04000949;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_04000947 = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v10 = __cil_newobj_06000F64(0);
            l0 = v10;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v11 = l0;
            global::OpenRA.Actor v13 = this.__il_field_0400094A;
            v11.__il_field_0400094A = v13;
            IL_0035: ;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v14 = l0;
            global::OpenRA.Graphics.WorldRenderer v16 = this.__il_field_0400094C;
            v14.wr = v16;
            global::OpenRA.Actor.__name_3C52656E64657261626C65733E645F5F3737 v17 = l0;
            return v17;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_e48ccfba4f0ef4e5ffd37a8d6c15e33e7cdc81b5 bytes=151280A10112880C: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Graphics.IRenderable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_e48ccfba4f0ef4e5ffd37a8d6c15e33e7cdc81b5 v1 = __cil_direct_06000F6B(this);
            return v1;
        }
        // property OpenRA.Graphics.IRenderable __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E47726170686963732E4952656E64657261626C653E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E47726170686963732E4952656E64657261626C653E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Algorithms, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Algorithms, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Csp, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Csp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.Process, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.Process, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.Watcher, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.Watcher, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Channels, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Threading.Channels, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.ILGeneration, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.ILGeneration, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.Lightweight, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.Lightweight, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Loader, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Loader, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq.Expressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq.Expressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Sockets, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Sockets, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Numerics, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Numerics, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.StackTrace, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.StackTrace, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.NameResolution, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.NameResolution, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 7; exact references retained; see --details for identities and provenance.
