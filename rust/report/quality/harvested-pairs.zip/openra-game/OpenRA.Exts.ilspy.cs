using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using OpenRA.Primitives;
using OpenRA.Support;
using OpenRA.Traits;

namespace OpenRA;

public static class Exts
{
	public enum ISqrtRoundMode
	{
		Floor,
		Nearest,
		Ceiling
	}

	public static Color OwnerColor(this Actor actor)
	{
		IEffectiveOwner effectiveOwner = actor.EffectiveOwner;
		if (effectiveOwner != null && effectiveOwner.Disguised && actor.World.RenderPlayer != null)
		{
			return effectiveOwner.Owner.Color;
		}
		return actor.Owner.Color;
	}

	public static string FormatInvariant(this string format, params object[] args)
	{
		return string.Format(CultureInfo.InvariantCulture, format, args);
	}

	public static string FormatCurrent(this string format, params object[] args)
	{
		return string.Format(CultureInfo.CurrentCulture, format, args);
	}

	public static Lazy<T> Lazy<T>(Func<T> p)
	{
		return new Lazy<T>(p);
	}

	public static IEnumerable<string> GetNamespaces(this Assembly a)
	{
		return from n in (from t in a.GetTypes()
				select t.Namespace).Distinct()
			where n != null
			select n;
	}

	public static bool HasAttribute<TAttribute>(this MemberInfo mi) where TAttribute : Attribute
	{
		return Attribute.IsDefined(mi, typeof(TAttribute));
	}

	public static TAttribute[] GetCustomAttributes<TAttribute>(this MemberInfo mi, bool inherit) where TAttribute : Attribute
	{
		return (TAttribute[])mi.GetCustomAttributes(typeof(TAttribute), inherit);
	}

	public static T Clamp<T>(this T val, T min, T max) where T : IComparable<T>
	{
		if (val.CompareTo(min) < 0)
		{
			return min;
		}
		if (val.CompareTo(max) > 0)
		{
			return max;
		}
		return val;
	}

	private static int WindingDirectionTest(int2 v0, int2 v1, int2 p)
	{
		return Math.Sign((v1.X - v0.X) * (p.Y - v0.Y) - (p.X - v0.X) * (v1.Y - v0.Y));
	}

	public static bool PolygonContains(this int2[] polygon, int2 p)
	{
		int num = 0;
		for (int i = 0; i < polygon.Length; i++)
		{
			int2 v = polygon[i];
			int2 v2 = polygon[(i + 1) % polygon.Length];
			if (v.Y <= p.Y && v2.Y > p.Y && WindingDirectionTest(v, v2, p) > 0)
			{
				num++;
			}
			else if (v.Y > p.Y && v2.Y <= p.Y && WindingDirectionTest(v, v2, p) < 0)
			{
				num--;
			}
		}
		return num != 0;
	}

	public static bool LinesIntersect(int2 a, int2 b, int2 c, int2 d)
	{
		if (WindingDirectionTest(c, d, a) != WindingDirectionTest(c, d, b))
		{
			return WindingDirectionTest(a, b, c) != WindingDirectionTest(a, b, d);
		}
		return false;
	}

	public static bool HasModifier(this Modifiers k, Modifiers mod)
	{
		return (k & mod) == mod;
	}

	public static V GetOrAdd<K, V>(this Dictionary<K, V> d, K k) where V : new()
	{
		return d.GetOrAdd(k, new V());
	}

	public static V GetOrAdd<K, V>(this Dictionary<K, V> d, K k, V v)
	{
		ref V valueRefOrAddDefault = ref CollectionsMarshal.GetValueRefOrAddDefault(d, k, out var exists);
		if (!exists)
		{
			valueRefOrAddDefault = v;
		}
		return valueRefOrAddDefault;
	}

	public static V GetOrAdd<K, V>(this Dictionary<K, V> d, K k, Func<K, V> createFn)
	{
		if (!d.TryGetValue(k, out var value))
		{
			d.Add(k, value = createFn(k));
		}
		return value;
	}

	public static T GetOrAdd<T>(this HashSet<T> set, T value)
	{
		if (!set.TryGetValue(value, out var actualValue))
		{
			set.Add(actualValue = value);
		}
		return actualValue;
	}

	public static T GetOrAdd<T>(this HashSet<T> set, T value, Func<T, T> createFn)
	{
		if (!set.TryGetValue(value, out var actualValue))
		{
			set.Add(actualValue = createFn(value));
		}
		return actualValue;
	}

	public static int IndexOf<T>(this T[] array, T value)
	{
		return Array.IndexOf(array, value);
	}

	public static T FirstOrDefault<T>(this T[] array, Predicate<T> match)
	{
		return Array.Find(array, match);
	}

	public static T FirstOrDefault<T>(this List<T> list, Predicate<T> match)
	{
		return list.Find(match);
	}

	public static T Random<T>(this IEnumerable<T> ts, MersenneTwister r)
	{
		return Random(ts, r, throws: true);
	}

	public static T RandomOrDefault<T>(this IEnumerable<T> ts, MersenneTwister r)
	{
		return Random(ts, r, throws: false);
	}

	private static T Random<T>(IEnumerable<T> ts, MersenneTwister r, bool throws)
	{
		IReadOnlyCollection<T> readOnlyCollection = ts as IReadOnlyCollection<T>;
		if (readOnlyCollection == null)
		{
			readOnlyCollection = ts.ToList();
		}
		if (readOnlyCollection.Count == 0)
		{
			if (throws)
			{
				throw new ArgumentException("Collection must not be empty.", "ts");
			}
			return default;
		}
		return readOnlyCollection.ElementAt(r.Next(readOnlyCollection.Count));
	}

	public static Rectangle Union(this IEnumerable<Rectangle> rects)
	{
		bool flag = true;
		Rectangle rectangle = Rectangle.Empty;
		foreach (Rectangle rect in rects)
		{
			if (flag)
			{
				flag = false;
				rectangle = rect;
			}
			else
			{
				rectangle = Rectangle.Union(rect, rectangle);
			}
		}
		return rectangle;
	}

	public static float Product(this IEnumerable<float> xs)
	{
		return xs.Aggregate(1f, (float a, float x) => a * x);
	}

	public static IEnumerable<T> SymmetricDifference<T>(this IEnumerable<T> xs, IEnumerable<T> ys)
	{
		return xs.Except(ys).Concat(ys.Except(xs));
	}

	public static IEnumerable<T> Iterate<T>(this T t, Func<T, T> f)
	{
		while (true)
		{
			yield return t;
			t = f(t);
		}
	}

	public static T MinBy<T, U>(this IEnumerable<T> ts, Func<T, U> selector)
	{
		return ts.CompareBy(selector, 1, throws: true);
	}

	public static T MaxBy<T, U>(this IEnumerable<T> ts, Func<T, U> selector)
	{
		return ts.CompareBy(selector, -1, throws: true);
	}

	public static T MinByOrDefault<T, U>(this IEnumerable<T> ts, Func<T, U> selector)
	{
		return ts.CompareBy(selector, 1, throws: false);
	}

	public static T MaxByOrDefault<T, U>(this IEnumerable<T> ts, Func<T, U> selector)
	{
		return ts.CompareBy(selector, -1, throws: false);
	}

	private static T CompareBy<T, U>(this IEnumerable<T> ts, Func<T, U> selector, int modifier, bool throws)
	{
		Comparer<U> comparer = Comparer<U>.Default;
		using IEnumerator<T> enumerator = ts.GetEnumerator();
		if (!enumerator.MoveNext())
		{
			if (throws)
			{
				throw new ArgumentException("Collection must not be empty.", "ts");
			}
			return default;
		}
		T val = enumerator.Current;
		U y = selector(val);
		while (enumerator.MoveNext())
		{
			T current = enumerator.Current;
			U val2 = selector(current);
			if (comparer.Compare(val2, y) * modifier < 0)
			{
				val = current;
				y = val2;
			}
		}
		return val;
	}

	public static int NextPowerOf2(int v)
	{
		v--;
		v |= v >> 1;
		v |= v >> 2;
		v |= v >> 4;
		v |= v >> 8;
		v++;
		return v;
	}

	public static bool IsPowerOf2(int v)
	{
		return (v & (v - 1)) == 0;
	}

	public static Size NextPowerOf2(this Size s)
	{
		return new Size(NextPowerOf2(s.Width), NextPowerOf2(s.Height));
	}

	public static int ISqrt(int number, ISqrtRoundMode round = ISqrtRoundMode.Floor)
	{
		if (number < 0)
		{
			throw new InvalidOperationException($"Attempted to calculate the square root of a negative integer: {number}");
		}
		return (int)ISqrt((uint)number, round);
	}

	public static uint ISqrt(uint number, ISqrtRoundMode round = ISqrtRoundMode.Floor)
	{
		uint num = 1073741824u;
		uint num2 = 0u;
		uint num3 = number;
		while (num > number)
		{
			num >>= 2;
		}
		while (num != 0)
		{
			if (num2 + num <= num3)
			{
				num3 -= num2 + num;
				num2 += 2 * num;
			}
			num2 >>= 1;
			num >>= 2;
		}
		if (round == ISqrtRoundMode.Nearest && num3 > num2)
		{
			num2++;
		}
		else if (round == ISqrtRoundMode.Ceiling && num2 * num2 < number)
		{
			num2++;
		}
		return num2;
	}

	public static long ISqrt(long number, ISqrtRoundMode round = ISqrtRoundMode.Floor)
	{
		if (number < 0)
		{
			throw new InvalidOperationException($"Attempted to calculate the square root of a negative integer: {number}");
		}
		return (long)ISqrt((ulong)number, round);
	}

	public static ulong ISqrt(ulong number, ISqrtRoundMode round = ISqrtRoundMode.Floor)
	{
		ulong num = 4611686018427387904uL;
		ulong num2 = 0uL;
		ulong num3 = number;
		while (num > number)
		{
			num >>= 2;
		}
		while (num != 0L)
		{
			if (num2 + num <= num3)
			{
				num3 -= num2 + num;
				num2 += 2 * num;
			}
			num2 >>= 1;
			num >>= 2;
		}
		if (round == ISqrtRoundMode.Nearest && num3 > num2)
		{
			num2++;
		}
		else if (round == ISqrtRoundMode.Ceiling && num2 * num2 < number)
		{
			num2++;
		}
		return num2;
	}

	public static int MultiplyBySqrtTwo(short number)
	{
		return number * 46341 / 32768;
	}

	public static int MultiplyBySqrtTwoOverTwo(int number)
	{
		return (int)((long)number * 23170L / 32768);
	}

	public static int IntegerDivisionRoundingAwayFromZero(int dividend, int divisor)
	{
		int num = Math.DivRem(dividend, divisor, out var result);
		if (result == 0)
		{
			return num;
		}
		return num + ((Math.Sign(dividend) == Math.Sign(divisor)) ? 1 : (-1));
	}

	public static string JoinWith<T>(this IEnumerable<T> ts, string j)
	{
		return string.Join(j, ts);
	}

	public static IEnumerable<T> Append<T>(this IEnumerable<T> ts, params T[] moreTs)
	{
		return ts.Concat(moreTs);
	}

	public static IEnumerable<T> Exclude<T>(this IEnumerable<T> ts, params T[] exclusions)
	{
		return ts.Except(exclusions);
	}

	public static HashSet<T> ToHashSet<T>(this IEnumerable<T> source)
	{
		return new HashSet<T>(source);
	}

	public static Dictionary<TKey, TSource> ToDictionaryWithConflictLog<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector, string debugName, Func<TKey, string> logKey, Func<TSource, string> logValue)
	{
		return source.ToDictionaryWithConflictLog(keySelector, (TSource x) => x, debugName, logKey, logValue);
	}

	public static Dictionary<TKey, TElement> ToDictionaryWithConflictLog<TSource, TKey, TElement>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector, Func<TSource, TElement> elementSelector, string debugName, Func<TKey, string> logKey = null, Func<TElement, string> logValue = null)
	{
		Dictionary<TKey, TElement> dictionary = new Dictionary<TKey, TElement>();
		source.IntoDictionaryWithConflictLog(keySelector, elementSelector, debugName, dictionary, logKey, logValue);
		return dictionary;
	}

	public static void IntoDictionaryWithConflictLog<TSource, TKey, TElement>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector, Func<TSource, TElement> elementSelector, string debugName, Dictionary<TKey, TElement> output, Func<TKey, string> logKey = null, Func<TElement, string> logValue = null)
	{
		if (logKey == null)
		{
			logKey = (TKey s) => s.ToString();
		}
		if (logValue == null)
		{
			logValue = (TElement s) => s.ToString();
		}
		Dictionary<TKey, List<string>> dictionary = null;
		int capacity = ((source is ICollection<TSource> collection) ? collection.Count : 0);
		output.Clear();
		output.EnsureCapacity(capacity);
		foreach (TSource item in source)
		{
			TKey val = keySelector(item);
			TElement val2 = elementSelector(item);
			if ((typeof(TKey).IsValueType || val != null) && !output.TryAdd(val, val2))
			{
				if (dictionary == null)
				{
					dictionary = new Dictionary<TKey, List<string>>();
				}
				if (!dictionary.TryGetValue(val, out var value))
				{
					value = new List<string> { logValue(output[val]) };
					dictionary.Add(val, value);
				}
				value.Add(logValue(val2));
			}
		}
		if (dictionary == null)
		{
			return;
		}
		StringBuilder stringBuilder = new StringBuilder(debugName + ", duplicate values found for the following keys: ");
		foreach (KeyValuePair<TKey, List<string>> item2 in dictionary)
		{
			stringBuilder.Append(logKey(item2.Key) + ": [" + string.Join(",", item2.Value) + "]");
		}
		throw new ArgumentException(stringBuilder.ToString());
	}

	public static Color ColorLerp(float t, Color c1, Color c2)
	{
		return Color.FromArgb((int)(t * (float)(int)c2.A + (1f - t) * (float)(int)c1.A), (int)(t * (float)(int)c2.R + (1f - t) * (float)(int)c1.R), (int)(t * (float)(int)c2.G + (1f - t) * (float)(int)c1.G), (int)(t * (float)(int)c2.B + (1f - t) * (float)(int)c1.B));
	}

	public static T[] MakeArray<T>(int count, Func<int, T> f)
	{
		T[] array = new T[count];
		for (int i = 0; i < count; i++)
		{
			array[i] = f(i);
		}
		return array;
	}

	public static T[,] ResizeArray<T>(T[,] ts, T t, int width, int height)
	{
		T[,] array = new T[width, height];
		for (int i = 0; i < width; i++)
		{
			for (int j = 0; j < height; j++)
			{
				if (i <= ts.GetUpperBound(0) && j <= ts.GetUpperBound(1))
				{
					array[i, j] = ts[i, j];
				}
				else
				{
					array[i, j] = t;
				}
			}
		}
		return array;
	}

	public static int ToBits(this IEnumerable<bool> bits)
	{
		int num = 0;
		int num2 = 0;
		foreach (bool bit in bits)
		{
			if (bit)
			{
				num2 |= 1 << num++;
			}
			else
			{
				num++;
			}
		}
		if (num > 33)
		{
			throw new InvalidOperationException("ToBits only accepts up to 32 values.");
		}
		return num2;
	}

	public static byte ParseByteInvariant(string s)
	{
		return byte.Parse(s, NumberStyles.Integer, NumberFormatInfo.InvariantInfo);
	}

	public static short ParseInt16Invariant(string s)
	{
		return short.Parse(s, NumberStyles.Integer, NumberFormatInfo.InvariantInfo);
	}

	public static int ParseInt32Invariant(string s)
	{
		return int.Parse(s, NumberStyles.Integer, NumberFormatInfo.InvariantInfo);
	}

	public static bool TryParseInt32Invariant(string s, out int i)
	{
		return int.TryParse(s, NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out i);
	}

	public static bool TryParseInt64Invariant(string s, out long i)
	{
		return long.TryParse(s, NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out i);
	}

	public static string ToStringInvariant(this byte i)
	{
		return i.ToString(NumberFormatInfo.InvariantInfo);
	}

	public static string ToStringInvariant(this byte i, string format)
	{
		return i.ToString(format, NumberFormatInfo.InvariantInfo);
	}

	public static string ToStringInvariant(this int i)
	{
		return i.ToString(NumberFormatInfo.InvariantInfo);
	}

	public static string ToStringInvariant(this int i, string format)
	{
		return i.ToString(format, NumberFormatInfo.InvariantInfo);
	}

	public static bool IsTraitEnabled<T>(this T trait)
	{
		if (trait is IDisabledTrait disabledTrait)
		{
			return !disabledTrait.IsTraitDisabled;
		}
		return true;
	}

	public static T FirstEnabledTraitOrDefault<T>(this IEnumerable<T> ts)
	{
		foreach (T t in ts)
		{
			if (t.IsTraitEnabled())
			{
				return t;
			}
		}
		return default;
	}

	public static T FirstEnabledTraitOrDefault<T>(this T[] ts)
	{
		foreach (T val in ts)
		{
			if (val.IsTraitEnabled())
			{
				return val;
			}
		}
		return default;
	}

	public static T FirstEnabledConditionalTraitOrDefault<T>(this IEnumerable<T> ts) where T : IDisabledTrait
	{
		foreach (T t in ts)
		{
			if (!t.IsTraitDisabled)
			{
				return t;
			}
		}
		return default;
	}

	public static T FirstEnabledConditionalTraitOrDefault<T>(this T[] ts) where T : IDisabledTrait
	{
		for (int i = 0; i < ts.Length; i++)
		{
			T result = ts[i];
			if (!result.IsTraitDisabled)
			{
				return result;
			}
		}
		return default;
	}

	public static LineSplitEnumerator SplitLines(this string str, char separator)
	{
		return new LineSplitEnumerator(str, separator);
	}
}
