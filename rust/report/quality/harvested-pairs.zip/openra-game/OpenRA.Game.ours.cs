namespace OpenRA;

public static class Game
{
    private const string SavedScreenshot = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0073\u0061\u0076\u0065\u0064\u002D\u0073\u0063\u0072\u0065\u0065\u006E\u0073\u0068\u006F\u0074";
    public const int TimestepJankThreshold = 250;
    private static OpenRA.InstalledMods __il_field_04000063;
    private static OpenRA.ExternalMods __il_field_04000064;
    public static OpenRA.ModData ModData;
    public static OpenRA.Settings Settings;
    public static OpenRA.Graphics.CursorManager Cursor;
    public static bool HideCursor;
    private static OpenRA.Graphics.WorldRenderer worldRenderer;
    private static string modLaunchWrapper;
    internal static OpenRA.Network.OrderManager OrderManager;
    private static OpenRA.Server.Server server;
    public static OpenRA.Support.MersenneTwister CosmeticRandom;
    public static OpenRA.Renderer Renderer;
    public static OpenRA.Sound Sound;
    private static string __il_field_04000070;
    public static OpenRA.LocalPlayerProfile LocalPlayerProfile;
    private static bool takeScreenshot;
    private static OpenRA.Support.Benchmark benchmark;
    private static System.Action OnShellmapLoaded;
    private static readonly System.Diagnostics.Stopwatch Stopwatch;
    public static int RenderFrame;
    private static System.Action<OpenRA.Network.ConnectionTarget> OnRemoteDirectConnect;
    private static System.Action<OpenRA.Network.OrderManager, string, OpenRA.Network.NetworkConnection> ConnectionStateChanged;
    private static OpenRA.Network.ConnectionState lastConnectionState;
    private static System.Action LobbyInfoChanged;
    private static System.Action BeforeGameStart;
    private static System.Action AfterGameStart;
    private static OpenRA.Modifiers modifiers;
    private static OpenRA.RunStatus state;
    private static System.Action OnQuit;
    private static OpenRA.Primitives.ActionQueue delayedActions;

    public static OpenRA.InstalledMods get_Mods()
    {
        global::OpenRA.InstalledMods v0 = OpenRA.Game.__il_field_04000063;
        return v0;
    }

    private static void set_Mods(OpenRA.InstalledMods value)
    {
        OpenRA.Game.__il_field_04000063 = value;
        return;
    }

    public static OpenRA.ExternalMods get_ExternalMods()
    {
        global::OpenRA.ExternalMods v0 = OpenRA.Game.__il_field_04000064;
        return v0;
    }

    private static void set_ExternalMods(OpenRA.ExternalMods value)
    {
        OpenRA.Game.__il_field_04000064 = value;
        return;
    }

    public static string get_EngineVersion()
    {
        string v0 = OpenRA.Game.__il_field_04000070;
        return v0;
    }

    private static void set_EngineVersion(string value)
    {
        OpenRA.Game.__il_field_04000070 = value;
        return;
    }

    public static void add_OnShellmapLoaded(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.OnShellmapLoaded;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Combine(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.OnShellmapLoaded;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void remove_OnShellmapLoaded(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.OnShellmapLoaded;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Remove(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.OnShellmapLoaded;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static OpenRA.Network.OrderManager JoinServer(OpenRA.Network.ConnectionTarget endpoint, string password, bool recordReplay = true)
    {
        // structural signature __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec bytes=151281CD031287800E128744: class [System.Runtime]System.Action`3<class OpenRA.Network.OrderManager, string, class OpenRA.Network.NetworkConnection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_096b49171fce839f3775407fcb8080b00420be63 bytes=15128121010E: class [System.Runtime]System.Func`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001CE alias=__cil_enum_020001CE underlying=int: global::@OpenRA.@Network.@ConnectionState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Network.NetworkConnection l0 = default;
        OpenRA.Network.NetworkConnection s2_0 = default;
        __cil_ref_096b49171fce839f3775407fcb8080b00420be63 s2_1 = default;
        OpenRA.Network.NetworkConnection s3_0 = default;
        __cil_ref_096b49171fce839f3775407fcb8080b00420be63 s3_1 = default;
        global::OpenRA.Network.NetworkConnection v1 = __cil_newobj_06000C3B(endpoint);
        l0 = v1;
        int v2 = __cil_bool_load(recordReplay);
        if (v2 == 0) {
            goto IL_002F;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::OpenRA.Network.NetworkConnection v3 = l0;
        __cil_ref_096b49171fce839f3775407fcb8080b00420be63 v4 = OpenRA.Game.__name_3C3E63.__il_field_04000985;
        if (v4 is not null) {
            OpenRA.Network.NetworkConnection e1_3_0 = v3;
            __cil_ref_096b49171fce839f3775407fcb8080b00420be63 e1_3_1 = v4;
            s3_0 = e1_3_0;
            s3_1 = e1_3_1;
            goto IL_002A;
        } else {
            OpenRA.Network.NetworkConnection e1_2_0 = v3;
            __cil_ref_096b49171fce839f3775407fcb8080b00420be63 e1_2_1 = v4;
            s2_0 = e1_2_0;
            s2_1 = e1_2_1;
            goto IL_0013;
        }
        IL_0013: ;
        global::OpenRA.Game.__name_3C3E63 v5 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v6 = __cil_ldftn_06000FAD;
        __cil_ref_096b49171fce839f3775407fcb8080b00420be63 v7 = __cil_newobj_0A00022A(v5, v6);
        OpenRA.Game.__name_3C3E63.__il_field_04000985 = v7;
        OpenRA.Network.NetworkConnection e2_3_0 = s2_0;
        __cil_ref_096b49171fce839f3775407fcb8080b00420be63 e2_3_1 = v7;
        s3_0 = e2_3_0;
        s3_1 = e2_3_1;
        IL_002A: ;
        __cil_callvirt_06000C4A(s3_0, s3_1);
        IL_002F: ;
        global::OpenRA.Network.NetworkConnection v8 = l0;
        global::OpenRA.Network.OrderManager v9 = __cil_newobj_06000C9E(v8);
        OpenRA.Game.JoinInner(v9);
        OpenRA.CurrentServerSettings.Password = password;
        OpenRA.CurrentServerSettings.Target = endpoint;
        OpenRA.Game.lastConnectionState = unchecked((__cil_enum_020001CE)(0));
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v14 = OpenRA.Game.ConnectionStateChanged;
        global::OpenRA.Network.OrderManager v15 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.NetworkConnection v17 = l0;
        __cil_callvirt_0A00022B(v14, v15, password, v17);
        return v9;
    }

    public static string TimestampedFilename(bool includemilliseconds = false, string extra = "")
    {
        // structural signature __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde bytes=118165: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string l0 = default;
        __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde l1 = default;
        string s3_0 = default;
        IL_0000: ;
        int v0 = __cil_bool_load(includemilliseconds);
        if (v0 != 0) {
            goto IL_000A;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = __cil_ldstr_700010CD("yyyy-MM-ddTHHmmssZ");
        string e1_3_0 = v1;
        s3_0 = e1_3_0;
        goto IL_000F;
        IL_000A: ;
        string v2 = __cil_ldstr_700010F3("yyyy-MM-ddTHHmmssfffZ");
        string e2_3_0 = v2;
        s3_0 = e2_3_0;
        goto IL_000F;
        IL_000F: ;
        l0 = s3_0;
        global::OpenRA.ModData v3 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v4 = v3.Manifest;
        string v5 = v4.Id;
        string v6 = extra;
        string v7 = __cil_ldstr_70000A56("-");
        __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde v8 = System.DateTime.get_UtcNow();
        l1 = v8;
        ref __cil_value_526addb1020dabfefa7c28d5d9b65adf6df73cde v9 = ref l1;
        string v10 = l0;
        __cil_type_01000113 v11 = System.Globalization.CultureInfo.get_InvariantCulture();
        string v12 = __cil_memberref_call_0A000202(ref v9, v10, ((__cil_type_010000FF)(v11)));
        string v13 = System.String.Concat(v5, v6, v7, v12);
        return v13;
    }

    private static void JoinInner(OpenRA.Network.OrderManager om)
    {
        // enum storage token=0x020000C9 alias=__cil_enum_020000C9 underlying=int: global::@OpenRA.@WorldType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Network.OrderManager s1_0 = default;
        OpenRA.Network.OrderManager s2_0 = default;
        OpenRA.World s3_0 = default;
        OpenRA.Network.OrderManager s6_0 = default;
        OpenRA.Network.OrderManager s7_0 = default;
        OpenRA.TextNotificationsManager.Clear();
        OpenRA.Network.UnitOrders.Clear();
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        if (v0 is not null) {
            OpenRA.Network.OrderManager e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0016;
        } else {
            OpenRA.Network.OrderManager e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0012;
        }
        IL_0012: ;
        OpenRA.World e1_3_0 = null;
        s3_0 = e1_3_0;
        goto IL_001B;
        IL_0016: ;
        global::OpenRA.World v1 = s2_0.World;
        OpenRA.World e2_3_0 = v1;
        s3_0 = e2_3_0;
        IL_001B: ;
        if (s3_0 is null) {
            goto IL_002F;
        } else {
            goto IL_001D;
        }
        IL_001D: ;
        global::OpenRA.Network.OrderManager v2 = OpenRA.Game.OrderManager;
        global::OpenRA.World v3 = v2.World;
        int v4 = unchecked((int)(v3.Type));
        if (v4 == 1) {
            goto IL_003F;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        global::OpenRA.Network.OrderManager v6 = OpenRA.Game.OrderManager;
        if (v6 is not null) {
            OpenRA.Network.OrderManager e5_7_0 = v6;
            s7_0 = e5_7_0;
            goto IL_003A;
        } else {
            OpenRA.Network.OrderManager e5_6_0 = v6;
            s6_0 = e5_6_0;
            goto IL_0037;
        }
        IL_0037: ;
        goto IL_003F;
        IL_003A: ;
        __cil_direct_06000CAC(s7_0);
        IL_003F: ;
        OpenRA.Game.OrderManager = om;
        return;
    }

    public static void JoinReplay(string replayFile)
    {
        global::OpenRA.Network.ReplayConnection v1 = __cil_newobj_06000CB2(replayFile);
        global::OpenRA.Network.OrderManager v2 = __cil_newobj_06000C9E(v1);
        OpenRA.Game.JoinInner(v2);
        return;
    }

    private static void JoinLocal()
    {
        // structural signature __cil_ref_570acefc1796d5c8706c38753f0867ba855b9457 bytes=1512809D01128D5C: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Network.Session/Client>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f bytes=1186D4: valuetype OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000355 alias=__cil_enum_02000355 underlying=int: global::@OpenRA.@Network.@Session.@ClientState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.Network.EchoConnection v0 = __cil_newobj_06000C38();
        global::OpenRA.Network.OrderManager v1 = __cil_newobj_06000C9E(v0);
        OpenRA.Game.JoinInner(v1);
        global::OpenRA.Network.OrderManager v2 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.Session v3 = v2.LobbyInfo;
        __cil_ref_570acefc1796d5c8706c38753f0867ba855b9457 v4 = v3.Clients;
        global::OpenRA.Network.Session.Client v5 = __cil_newobj_0600133E();
        global::OpenRA.Network.OrderManager v6 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.IConnection v7 = __cil_callvirt_06000C99(v6);
        int v8 = __cil_callvirt_06000C2B(v7);
        v5.Index = v8;
        global::OpenRA.Settings v9 = OpenRA.Game.Settings;
        global::OpenRA.PlayerSettings v10 = v9.Player;
        string v11 = v10.Name;
        v5.Name = v11;
        global::OpenRA.Settings v12 = OpenRA.Game.Settings;
        global::OpenRA.PlayerSettings v13 = v12.Player;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v14 = v13.Color;
        v5.PreferredColor = v14;
        global::OpenRA.Settings v15 = OpenRA.Game.Settings;
        global::OpenRA.PlayerSettings v16 = v15.Player;
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v17 = v16.Color;
        v5.Color = v17;
        string v18 = __cil_ldstr_7000111F("Random");
        v5.Faction = v18;
        v5.SpawnPoint = 0;
        v5.Team = 0;
        v5.State = unchecked((__cil_enum_02000355)(2));
        __cil_callvirt_0A00022D(v4, v5);
        return;
    }

    public static long get_RunTime()
    {
        __cil_type_01000074 v0 = OpenRA.Game.Stopwatch;
        long v1 = __cil_callvirt_0A00022E(v0);
        return v1;
    }

    public static int get_NetFrameNumber()
    {
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        int v1 = __cil_callvirt_06000C96(v0);
        return v1;
    }

    public static int get_LocalTick()
    {
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        int v1 = v0.LocalFrameNumber;
        return v1;
    }

    public static void add_OnRemoteDirectConnect(System.Action<OpenRA.Network.ConnectionTarget> value)
    {
        // structural signature __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 bytes=151281A901128748: class [System.Runtime]System.Action`1<class OpenRA.Network.ConnectionTarget>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 l0 = default;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 l1 = default;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 l2 = default;
        IL_0000: ;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v0 = OpenRA.Game.OnRemoteDirectConnect;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v1 = l0;
        l1 = v1;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v2 = l1;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Combine(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v5 = ((__cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04)(object)v4);
        l2 = v5;
        ref __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v6 = ref OpenRA.Game.OnRemoteDirectConnect;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v7 = l2;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v8 = l1;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v9 = __cil_methodspec_call_2B00004F(ref v6, v7, v8);
        l0 = v9;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v10 = l0;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void remove_OnRemoteDirectConnect(System.Action<OpenRA.Network.ConnectionTarget> value)
    {
        // structural signature __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 bytes=151281A901128748: class [System.Runtime]System.Action`1<class OpenRA.Network.ConnectionTarget>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 l0 = default;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 l1 = default;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 l2 = default;
        IL_0000: ;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v0 = OpenRA.Game.OnRemoteDirectConnect;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v1 = l0;
        l1 = v1;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v2 = l1;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Remove(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v5 = ((__cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04)(object)v4);
        l2 = v5;
        ref __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v6 = ref OpenRA.Game.OnRemoteDirectConnect;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v7 = l2;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v8 = l1;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v9 = __cil_methodspec_call_2B00004F(ref v6, v7, v8);
        l0 = v9;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v10 = l0;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void add_ConnectionStateChanged(System.Action<OpenRA.Network.OrderManager, string, OpenRA.Network.NetworkConnection> value)
    {
        // structural signature __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec bytes=151281CD031287800E128744: class [System.Runtime]System.Action`3<class OpenRA.Network.OrderManager, string, class OpenRA.Network.NetworkConnection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec l0 = default;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec l1 = default;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec l2 = default;
        IL_0000: ;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v0 = OpenRA.Game.ConnectionStateChanged;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v1 = l0;
        l1 = v1;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v2 = l1;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Combine(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v5 = ((__cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec)(object)v4);
        l2 = v5;
        ref __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v6 = ref OpenRA.Game.ConnectionStateChanged;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v7 = l2;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v8 = l1;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v9 = __cil_methodspec_call_2B000050(ref v6, v7, v8);
        l0 = v9;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v10 = l0;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void remove_ConnectionStateChanged(System.Action<OpenRA.Network.OrderManager, string, OpenRA.Network.NetworkConnection> value)
    {
        // structural signature __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec bytes=151281CD031287800E128744: class [System.Runtime]System.Action`3<class OpenRA.Network.OrderManager, string, class OpenRA.Network.NetworkConnection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec l0 = default;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec l1 = default;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec l2 = default;
        IL_0000: ;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v0 = OpenRA.Game.ConnectionStateChanged;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v1 = l0;
        l1 = v1;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v2 = l1;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Remove(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v5 = ((__cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec)(object)v4);
        l2 = v5;
        ref __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v6 = ref OpenRA.Game.ConnectionStateChanged;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v7 = l2;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v8 = l1;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v9 = __cil_methodspec_call_2B000050(ref v6, v7, v8);
        l0 = v9;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v10 = l0;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static int get_LocalClientId()
    {
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.IConnection v1 = __cil_callvirt_06000C99(v0);
        int v2 = __cil_callvirt_06000C2B(v1);
        return v2;
    }

    public static void RemoteDirectConnect(OpenRA.Network.ConnectionTarget endpoint)
    {
        // structural signature __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 bytes=151281A901128748: class [System.Runtime]System.Action`1<class OpenRA.Network.ConnectionTarget>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v0 = OpenRA.Game.OnRemoteDirectConnect;
        __cil_callvirt_0A00022F(v0, endpoint);
        return;
    }

    public static OpenRA.Widgets.Widget OpenWindow(OpenRA.World world, string widget)
    {
        global::OpenRA.Widgets.WidgetArgs v1 = __cil_newobj_0600075C();
        string v2 = __cil_ldstr_7000112D("world");
        __cil_callvirt_0A000230(v1, v2, ((object)(world)));
        string v4 = __cil_ldstr_70001139("orderManager");
        global::OpenRA.Network.OrderManager v5 = OpenRA.Game.OrderManager;
        __cil_callvirt_0A000230(v1, v4, ((object)(v5)));
        string v6 = __cil_ldstr_70001153("worldRenderer");
        global::OpenRA.Graphics.WorldRenderer v7 = OpenRA.Game.worldRenderer;
        __cil_callvirt_0A000230(v1, v6, ((object)(v7)));
        global::OpenRA.Widgets.Widget v8 = OpenRA.Widgets.Ui.OpenWindow(widget, v1);
        return v8;
    }

    public static OpenRA.Widgets.Widget OpenWindow(string widget, OpenRA.Widgets.WidgetArgs args)
    {
        // structural signature __cil_ref_c763ca7be82c9952db8520c4a15ddd081740c9af bytes=15128089020E1C: class [System.Collections]System.Collections.Generic.Dictionary`2<string, object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Widgets.WidgetArgs v2 = __cil_newobj_0600075D(args);
        string v3 = __cil_ldstr_7000112D("world");
        global::OpenRA.Graphics.WorldRenderer v4 = OpenRA.Game.worldRenderer;
        global::OpenRA.World v5 = v4.World;
        __cil_callvirt_0A000230(v2, v3, ((object)(v5)));
        string v6 = __cil_ldstr_70001139("orderManager");
        global::OpenRA.Network.OrderManager v7 = OpenRA.Game.OrderManager;
        __cil_callvirt_0A000230(v2, v6, ((object)(v7)));
        string v8 = __cil_ldstr_70001153("worldRenderer");
        global::OpenRA.Graphics.WorldRenderer v9 = OpenRA.Game.worldRenderer;
        __cil_callvirt_0A000230(v2, v8, ((object)(v9)));
        global::OpenRA.Widgets.Widget v10 = OpenRA.Widgets.Ui.OpenWindow(widget, v2);
        return v10;
    }

    public static OpenRA.Widgets.Widget LoadWidget(OpenRA.World world, string id, OpenRA.Widgets.Widget parent, OpenRA.Widgets.WidgetArgs args)
    {
        // structural signature __cil_ref_c763ca7be82c9952db8520c4a15ddd081740c9af bytes=15128089020E1C: class [System.Collections]System.Collections.Generic.Dictionary`2<string, object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.ModData v0 = OpenRA.Game.ModData;
        global::OpenRA.WidgetLoader v1 = v0.WidgetLoader;
        global::OpenRA.Widgets.WidgetArgs v3 = __cil_newobj_0600075D(args);
        string v4 = __cil_ldstr_7000112D("world");
        __cil_callvirt_0A000230(v3, v4, ((object)(world)));
        string v6 = __cil_ldstr_70001139("orderManager");
        global::OpenRA.Network.OrderManager v7 = OpenRA.Game.OrderManager;
        __cil_callvirt_0A000230(v3, v6, ((object)(v7)));
        string v8 = __cil_ldstr_70001153("worldRenderer");
        global::OpenRA.Graphics.WorldRenderer v9 = OpenRA.Game.worldRenderer;
        __cil_callvirt_0A000230(v3, v8, ((object)(v9)));
        global::OpenRA.Widgets.Widget v12 = __cil_callvirt_0600064B(v1, v3, parent, id);
        return v12;
    }

    public static void add_LobbyInfoChanged(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.LobbyInfoChanged;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Combine(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.LobbyInfoChanged;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void remove_LobbyInfoChanged(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.LobbyInfoChanged;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Remove(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.LobbyInfoChanged;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    internal static void SyncLobbyInfo()
    {
        __cil_type_01000072 v0 = OpenRA.Game.LobbyInfoChanged;
        v0.Invoke();
        return;
    }

    public static void add_BeforeGameStart(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.BeforeGameStart;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Combine(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.BeforeGameStart;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void remove_BeforeGameStart(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.BeforeGameStart;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Remove(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.BeforeGameStart;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void add_AfterGameStart(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.AfterGameStart;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Combine(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.AfterGameStart;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void remove_AfterGameStart(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.AfterGameStart;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Remove(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.AfterGameStart;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    internal static void StartGame(string mapUID, OpenRA.WorldType type)
    {
        // enum storage token=0x020000C9 alias=__cil_enum_020000C9 underlying=int: global::@OpenRA.@WorldType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020004E5 alias=__cil_enum_020004E5 underlying=int: global::@System.@Runtime.@GCLargeObjectHeapCompactionMode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Support.PerfTimer l0 = default;
        OpenRA.Support.PerfTimer l1 = default;
        OpenRA.Graphics.WorldRenderer s1_0 = default;
        OpenRA.Graphics.WorldRenderer s2_0 = default;
        IL_0000: ;
        global::OpenRA.Graphics.WorldRenderer v0 = OpenRA.Game.worldRenderer;
        if (v0 is not null) {
            OpenRA.Graphics.WorldRenderer e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_000B;
        } else {
            OpenRA.Graphics.WorldRenderer e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0008;
        }
        IL_0008: ;
        goto IL_0010;
        IL_000B: ;
        __cil_direct_06000EC2(s2_0);
        goto IL_0010;
        IL_0010: ;
        global::OpenRA.Graphics.CursorManager v1 = OpenRA.Game.Cursor;
        __cil_callvirt_06000D23(v1, ((string)(null)));
        __cil_type_01000072 v2 = OpenRA.Game.BeforeGameStart;
        v2.Invoke();
        string v3 = __cil_ldstr_7000116F("NewWorld");
        __cil_F v4 = __cil_ldc_r4_bits(0x00000000u);
        global::OpenRA.Support.PerfTimer v5 = __cil_newobj_060007B3(v3, v4);
        l0 = v5;
        try {
            IL_0035: ;
            global::OpenRA.Network.OrderManager v6 = OpenRA.Game.OrderManager;
            string v7 = mapUID;
            global::OpenRA.ModData v8 = OpenRA.Game.ModData;
            global::OpenRA.Network.OrderManager v9 = OpenRA.Game.OrderManager;
            int v10 = unchecked((int)(type));
            global::OpenRA.World v11 = __cil_newobj_0600066C(v7, v8, v9, v10);
            v6.World = v11;
            goto IL_005C;
        }
        finally {
            IL_0052: ;
            global::OpenRA.Support.PerfTimer v12 = l0;
            if (v12 is null) {
                goto IL_005B;
            } else {
                goto IL_0055;
            }
            IL_0055: ;
            global::OpenRA.Support.PerfTimer v13 = l0;
            __cil_callvirt_0A000017(v13);
            goto IL_005B;
            IL_005B: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_005C: ;
        global::OpenRA.Network.OrderManager v14 = OpenRA.Game.OrderManager;
        global::OpenRA.World v15 = v14.World;
        nint v16 = __cil_ldftn_06000196;
        __cil_type_01000072 v17 = __cil_newobj_0A000232(null, v16);
        __cil_callvirt_06000654(v15, v17);
        global::OpenRA.ModData v18 = OpenRA.Game.ModData;
        global::OpenRA.Network.OrderManager v19 = OpenRA.Game.OrderManager;
        global::OpenRA.World v20 = v19.World;
        global::OpenRA.Graphics.WorldRenderer v21 = __cil_newobj_06000EA9(v18, v20);
        OpenRA.Game.worldRenderer = v21;
        System.GC.Collect();
        string v22 = __cil_ldstr_70001181("LoadComplete");
        __cil_F v23 = __cil_ldc_r4_bits(0x00000000u);
        global::OpenRA.Support.PerfTimer v24 = __cil_newobj_060007B3(v22, v23);
        l1 = v24;
        try {
            IL_00A5: ;
            global::OpenRA.Network.OrderManager v25 = OpenRA.Game.OrderManager;
            global::OpenRA.World v26 = v25.World;
            global::OpenRA.Graphics.WorldRenderer v27 = OpenRA.Game.worldRenderer;
            __cil_callvirt_06000670(v26, v27);
            goto IL_00C5;
        }
        finally {
            IL_00BB: ;
            global::OpenRA.Support.PerfTimer v28 = l1;
            if (v28 is null) {
                goto IL_00C4;
            } else {
                goto IL_00BE;
            }
            IL_00BE: ;
            global::OpenRA.Support.PerfTimer v29 = l1;
            __cil_callvirt_0A000017(v29);
            goto IL_00C4;
            IL_00C4: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_00C5: ;
        System.GC.Collect();
        global::OpenRA.Network.OrderManager v30 = OpenRA.Game.OrderManager;
        int v31 = __cil_bool_load(__cil_callvirt_06000C98(v30));
        if (v31 == 0) {
            goto IL_00D7;
        } else {
            goto IL_00D6;
        }
        IL_00D6: ;
        return;
        IL_00D7: ;
        OpenRA.Widgets.Ui.MouseFocusWidget = null;
        OpenRA.Widgets.Ui.KeyboardFocusWidget = null;
        global::OpenRA.Network.OrderManager v32 = OpenRA.Game.OrderManager;
        __cil_callvirt_06000C9D(v32);
        global::OpenRA.Graphics.WorldRenderer v33 = OpenRA.Game.worldRenderer;
        __cil_callvirt_06000EB9(v33);
        global::OpenRA.Graphics.CursorManager v34 = OpenRA.Game.Cursor;
        string v35 = __cil_ldstr_7000119B("DefaultCursor");
        string v36 = __cil_methodspec_call_2B000051(v35);
        __cil_callvirt_06000D23(v34, v36);
        int v37 = 2;
        System.Runtime.GCSettings.set_LargeObjectHeapCompactionMode(unchecked((System.Runtime.GCLargeObjectHeapCompactionMode)(v37)));
        System.GC.Collect();
        global::OpenRA.Network.OrderManager v38 = OpenRA.Game.OrderManager;
        global::OpenRA.World v39 = v38.World;
        global::OpenRA.Graphics.WorldRenderer v40 = OpenRA.Game.worldRenderer;
        __cil_callvirt_06000671(v39, v40);
        __cil_type_01000072 v41 = OpenRA.Game.AfterGameStart;
        v41.Invoke();
        return;
    }

    public static void RestartGame()
    {
        // structural signature __cil_ref_fe6160cf971c780d56dbeed3d1b418637f3e7dc4 bytes=1D128234: class OpenRA.Order[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fcc908830936c12388832257baf21a5941e2b618 bytes=1512808501128234: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Order>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Network.ReplayConnection l0 = default;
        string l1 = default;
        OpenRA.Network.Session l2 = default;
        __cil_ref_fe6160cf971c780d56dbeed3d1b418637f3e7dc4 l3 = default;
        string s3_0 = default;
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.IConnection v1 = __cil_callvirt_06000C99(v0);
        global::OpenRA.Network.ReplayConnection v2 = ((object)v1 as OpenRA.Network.ReplayConnection);
        l0 = v2;
        global::OpenRA.Network.ReplayConnection v3 = l0;
        if (v3 is not null) {
            goto IL_0016;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        string e1_3_0 = null;
        s3_0 = e1_3_0;
        goto IL_001C;
        IL_0016: ;
        global::OpenRA.Network.ReplayConnection v4 = l0;
        string v5 = v4.Filename;
        string e2_3_0 = v5;
        s3_0 = e2_3_0;
        IL_001C: ;
        l1 = s3_0;
        global::OpenRA.Network.OrderManager v6 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.Session v7 = v6.LobbyInfo;
        l2 = v7;
        global::OpenRA.Network.Session v8 = l2;
        global::OpenRA.Network.Session.Global v9 = v8.GlobalSettings;
        global::OpenRA.Support.MersenneTwister v10 = OpenRA.Game.CosmeticRandom;
        int v11 = __cil_callvirt_0600079F(v10);
        v9.RandomSeed = v11;
        global::OpenRA.Network.Session v12 = l2;
        global::OpenRA.Network.Session.Global v13 = v12.GlobalSettings;
        global::OpenRA.ModData v14 = OpenRA.Game.ModData;
        global::OpenRA.MapCache v15 = v14.MapCache;
        global::OpenRA.Network.Session v16 = l2;
        global::OpenRA.Network.Session.Global v17 = v16.GlobalSettings;
        string v18 = v17.Map;
        string v19 = __cil_callvirt_06000357(v15, v18);
        v13.Map = v19;
        global::OpenRA.Network.Session v20 = l2;
        global::OpenRA.Network.Session.Global v21 = v20.GlobalSettings;
        string v22 = v21.Map;
        if (v22 is not null) {
            goto IL_007F;
        } else {
            goto IL_006F;
        }
        IL_006F: ;
        OpenRA.Game.Disconnect();
        OpenRA.Widgets.Ui.ResetAll();
        OpenRA.Game.LoadShellMap();
        return;
        IL_007F: ;
        __cil_ref_fe6160cf971c780d56dbeed3d1b418637f3e7dc4 v24 = __cil_newarr_0200008D(2);
        string v26 = __cil_ldstr_700011B7("sync_lobby ");
        global::OpenRA.Network.Session v27 = l2;
        string v28 = __cil_callvirt_06000CC8(v27);
        string v29 = System.String.Concat(v26, v28);
        global::OpenRA.Order v30 = OpenRA.Order.Command(v29);
        v24[0] = v30;
        string v32 = __cil_ldstr_700011CF("startgame");
        global::OpenRA.Order v33 = OpenRA.Order.Command(v32);
        v24[1] = v33;
        l3 = v24;
        OpenRA.Game.Disconnect();
        OpenRA.Widgets.Ui.ResetAll();
        global::OpenRA.Network.ReplayConnection v34 = l0;
        if (v34 is null) {
            goto IL_00BF;
        } else {
            goto IL_00B8;
        }
        IL_00B8: ;
        string v35 = l1;
        OpenRA.Game.JoinReplay(v35);
        return;
        IL_00BF: ;
        global::OpenRA.Network.Session v36 = l2;
        global::OpenRA.Network.Session.Global v37 = v36.GlobalSettings;
        string v38 = v37.Map;
        __cil_ref_fe6160cf971c780d56dbeed3d1b418637f3e7dc4 v39 = l3;
        OpenRA.Game.CreateAndStartLocalServer(v38, ((__cil_ref_fcc908830936c12388832257baf21a5941e2b618)(v39)));
        return;
    }

    public static void CreateAndStartLocalServer(string mapUID, System.Collections.Generic.IEnumerable<OpenRA.Order> setupOrders)
    {
        // structural signature __cil_ref_fcc908830936c12388832257baf21a5941e2b618 bytes=1512808501128234: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Order>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737336395F30 v0 = __cil_newobj_06000FBF();
        v0.setupOrders = setupOrders;
        v0.om = null;
        nint v5 = __cil_ldftn_06000FC0;
        __cil_type_01000072 v6 = __cil_newobj_0A000232(v0, v5);
        OpenRA.Game.add_LobbyInfoChanged(v6);
        global::OpenRA.Network.ConnectionTarget v10 = OpenRA.Game.CreateLocalServer(mapUID, __cil_bool_store(0));
        string v11 = __cil_ldstr_700005EE("");
        global::OpenRA.Network.OrderManager v13 = OpenRA.Game.JoinServer(v10, v11, __cil_bool_store(1));
        v0.om = v13;
        return;
    }

    public static bool get_IsHost()
    {
        OpenRA.Network.Session.Client l1 = default;
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.IConnection v1 = __cil_callvirt_06000C99(v0);
        int v2 = __cil_callvirt_06000C2B(v1);
        global::OpenRA.Network.OrderManager v3 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.Session v4 = v3.LobbyInfo;
        global::OpenRA.Network.Session.Client v6 = __cil_callvirt_06000CC2(v4, v2);
        l1 = v6;
        global::OpenRA.Network.Session.Client v7 = l1;
        if (v7 is null) {
            return false;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        global::OpenRA.Network.Session.Client v8 = l1;
        return v8.IsAdmin;
    }

    public static OpenRA.Modifiers GetModifierKeys()
    {
        // enum storage token=0x02000042 alias=__cil_enum_02000042 underlying=int: global::@OpenRA.@Modifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(OpenRA.Game.modifiers));
        return unchecked((__cil_enum_02000042)(v0));
    }

    internal static void HandleModifierKeys(OpenRA.Modifiers mods)
    {
        // enum storage token=0x02000042 alias=__cil_enum_02000042 underlying=int: global::@OpenRA.@Modifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(mods));
        OpenRA.Game.modifiers = unchecked((__cil_enum_02000042)(v0));
        return;
    }

    public static void InitializeSettings(OpenRA.Arguments args)
    {
        string v0 = OpenRA.Platform.get_SupportDir();
        string v1 = __cil_ldstr_700011E3("settings.yaml");
        string v2 = System.IO.Path.Combine(v0, v1);
        global::OpenRA.Settings v4 = __cil_newobj_0600053B(v2, args);
        OpenRA.Game.Settings = v4;
        return;
    }

    public static OpenRA.RunStatus InitializeAndRun(string[] args)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@OpenRA.@RunStatus; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.Arguments v1 = __cil_newobj_060005B1(args);
        OpenRA.Game.Initialize(v1);
        System.GC.Collect();
        int v2 = unchecked((int)(OpenRA.Game.Run()));
        return unchecked((__cil_enum_020000BC)(v2));
    }

    private static void Initialize(OpenRA.Arguments args)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 72, FF, 11, 00, 70, 14, 6F, B3, 05, 00, 06, 0A, 06, 28, C1, 00, 00, 0A, 2D, 06, 06, 28, 67]
        // .code-bytes IL_0018: [04, 00, 06, 02, 72, 21, 12, 00, 70, 14, 6F, B3, 05, 00, 06, 0B, 07, 28, C1, 00, 00, 0A, 2D, 06]
        // .code-bytes IL_0030: [07, 28, 65, 04, 00, 06, 12, 07, 1F, 0F, 18, 28, C4, 00, 00, 0A, 12, 07, 72, 45, 12, 00, 70, 28]
        // .code-bytes IL_0048: [C5, 00, 00, 0A, 12, 07, 28, 5D, 04, 00, 06, 28, 52, 00, 00, 2B, 12, 07, 72, 5F, 12, 00, 70, 28]
        // .code-bytes IL_0060: [C5, 00, 00, 0A, 12, 07, 28, 5E, 04, 00, 06, 28, 53, 00, 00, 2B, 12, 07, 72, 9F, 03, 00, 70, 28]
        // .code-bytes IL_0078: [C5, 00, 00, 0A, 12, 07, 28, C7, 00, 00, 0A, 28, 01, 01, 00, 0A, 28, 66, 04, 00, 06, 72, 65, 12]
        // .code-bytes IL_0090: [00, 70, 28, 1B, 01, 00, 0A, 28, 35, 02, 00, 0A, 6F, BB, 01, 00, 0A, 28, 56, 01, 00, 06, DE, 03]
        // .code-bytes IL_00A8: [26, DE, 00, 28, 55, 01, 00, 06, 28, C1, 00, 00, 0A, 2C, 0A, 72, 75, 12, 00, 70, 28, 56, 01, 00]
        // .code-bytes IL_00C0: [06, 72, 85, 12, 00, 70, 28, 55, 01, 00, 06, 28, 7B, 00, 00, 0A, 28, 01, 01, 00, 0A, 72, AB, 12]
        // .code-bytes IL_00D8: [00, 70, 28, 60, 04, 00, 06, 28, 7B, 00, 00, 0A, 28, 01, 01, 00, 0A, 02, 72, BF, 12, 00, 70, 14]
        // .code-bytes IL_00F0: [6F, B3, 05, 00, 06, 0C, 28, 4B, 00, 00, 2B, 0D, 08, 2C, 22, 08, 28, 1F, 01, 00, 0A, 2D, 08, 08]
        // .code-bytes IL_0108: [28, 1C, 01, 00, 0A, 2C, 12, 17, 8D, FE, 00, 00, 01, 25, 16, 08, A2, 0D, 08, 28, 20, 01, 00, 0A]
        // .code-bytes IL_0120: [0C, 02, 28, 77, 01, 00, 06, 72, D1, 12, 00, 70, 72, DB, 12, 00, 70, 16, 28, C3, 05, 00, 06, 72]
        // .code-bytes IL_0138: [1E, 06, 00, 70, 72, ED, 12, 00, 70, 16, 28, C3, 05, 00, 06, 72, 01, 13, 00, 70, 72, 0F, 13, 00]
        // .code-bytes IL_0150: [70, 17, 28, C3, 05, 00, 06, 72, 25, 13, 00, 70, 72, 31, 13, 00, 70, 16, 28, C3, 05, 00, 06, 72]
        // .code-bytes IL_0168: [45, 13, 00, 70, 72, 57, 13, 00, 70, 16, 28, C3, 05, 00, 06, 72, 71, 13, 00, 70, 72, 7D, 13, 00]
        // .code-bytes IL_0180: [70, 16, 28, C3, 05, 00, 06, 72, 91, 13, 00, 70, 72, 99, 13, 00, 70, 16, 28, C3, 05, 00, 06, 72]
        // .code-bytes IL_0198: [A9, 13, 00, 70, 72, B7, 13, 00, 70, 16, 28, C3, 05, 00, 06, 19, 8D, FE, 00, 00, 01, 25, 16, 7E]
        // .code-bytes IL_01B0: [66, 00, 00, 04, 7B, 54, 04, 00, 04, 7B, 38, 04, 00, 04, A2, 25, 17, 72, CD, 13, 00, 70, A2, 13]
        // .code-bytes IL_01C8: [04, 11, 04, 13, 08, 16, 13, 09, 38, B5, 00, 00, 00, 11, 08, 11, 09, 9A, 13, 0A, 11, 0A, 2D, 0B]
        // .code-bytes IL_01E0: [72, DD, 13, 00, 70, 73, 6E, 00, 00, 0A, 7A, 7E, 66, 00, 00, 04, 7B, 54, 04, 00, 04, 11, 0A, 7D]
        // .code-bytes IL_01F8: [38, 04, 00, 04, 11, 0A, 28, 7A, 01, 00, 06, 13, 0B, 11, 0B, 7E, 66, 00, 00, 04, 7B, 56, 04, 00]
        // .code-bytes IL_0210: [04, 73, 09, 05, 00, 06, 80, 6E, 00, 00, 04, 11, 0B, 7E, 66, 00, 00, 04, 7B, 55, 04, 00, 04, 73]
        // .code-bytes IL_0228: [48, 05, 00, 06, 80, 6F, 00, 00, 04, DE, 62, 13, 0C, 72, 45, 13, 00, 70, 12, 07, 16, 17, 28, C4]
        // .code-bytes IL_0240: [00, 00, 0A, 12, 07, 11, 0C, 28, 54, 00, 00, 2B, 12, 07, 28, C7, 00, 00, 0A, 28, C4, 05, 00, 06]
        // .code-bytes IL_0258: [72, 84, 14, 00, 70, 28, 01, 01, 00, 0A, 7E, 6E, 00, 00, 04, 25, 2D, 03, 26, 2B, 05, 28, 2D, 05]
        // .code-bytes IL_0270: [00, 06, 7E, 6F, 00, 00, 04, 25, 2D, 03, 26, 2B, 05, 28, 80, 05, 00, 06, DE, 00, 11, 09, 17, 58]
        // .code-bytes IL_0288: [13, 09, 11, 09, 11, 08, 8E, 69, 3F, 40, FF, FF, FF, 28, 81, 0C, 00, 06, 02, 72, 04, 15, 00, 70]
        // .code-bytes IL_02A0: [14, 6F, B3, 05, 00, 06, 13, 05, 11, 05, 2D, 1A, 17, 8D, FE, 00, 00, 01, 25, 16, 28, 66, 04, 00]
        // .code-bytes IL_02B8: [06, 72, 30, 15, 00, 70, 28, 1B, 01, 00, 0A, A2, 2B, 0C, 72, 3A, 15, 00, 70, 11, 05, 28, 4C, 00]
        // .code-bytes IL_02D0: [00, 2B, 13, 06, 11, 06, 09, 73, 43, 02, 00, 06, 28, 52, 01, 00, 06, 72, 5A, 15, 00, 70, 28, 01]
        // .code-bytes IL_02E8: [01, 00, 0A, 28, 51, 01, 00, 06, 6F, 4C, 02, 00, 06, 13, 0D, 2B, 68, 11, 0D, 6F, 36, 02, 00, 0A]
        // .code-bytes IL_0300: [13, 0E, 1A, 18, 73, C4, 00, 00, 0A, 13, 07, 12, 07, 72, 78, 15, 00, 70, 28, C5, 00, 00, 0A, 12]
        // .code-bytes IL_0318: [07, 12, 0E, 28, 37, 02, 00, 0A, 28, D4, 00, 00, 0A, 12, 07, 72, 5F, 12, 00, 70, 28, C5, 00, 00]
        // .code-bytes IL_0330: [0A, 12, 07, 12, 0E, 28, 38, 02, 00, 0A, 7B, FD, 01, 00, 04, 7B, F6, 01, 00, 04, 28, D4, 00, 00]
        // .code-bytes IL_0348: [0A, 12, 07, 72, 9F, 03, 00, 70, 28, C5, 00, 00, 0A, 12, 07, 28, C7, 00, 00, 0A, 28, 01, 01, 00]
        // .code-bytes IL_0360: [0A, 11, 0D, 6F, 18, 00, 00, 0A, 2D, 8F, DE, 0C, 11, 0D, 2C, 07, 11, 0D, 6F, 17, 00, 00, 0A, DC]
        // .code-bytes IL_0378: [02, 72, 7C, 15, 00, 70, 14, 6F, B3, 05, 00, 06, 80, 6A, 00, 00, 04, 73, AA, 00, 00, 06, 28, 54]
        // .code-bytes IL_0390: [01, 00, 06, 08, 39, 81, 00, 00, 00, 28, 51, 01, 00, 06, 08, 12, 0F, 6F, 4D, 02, 00, 06, 2C, 72]
        // .code-bytes IL_03A8: [02, 72, A6, 15, 00, 70, 14, 6F, B3, 05, 00, 06, 13, 10, 73, 74, 01, 00, 0A, 13, 11, 11, 10, 2C]
        // .code-bytes IL_03C0: [30, 11, 10, 16, 6F, 39, 02, 00, 0A, 1F, 22, 33, 24, 11, 10, 28, 55, 00, 00, 2B, 1F, 22, 33, 19]
        // .code-bytes IL_03D8: [11, 10, 13, 12, 11, 12, 17, 11, 12, 6F, E2, 00, 00, 0A, 17, 59, 17, 59, 6F, E4, 00, 00, 0A, 13]
        // .code-bytes IL_03F0: [10, 11, 10, 2C, 1A, 28, 53, 01, 00, 06, 28, 51, 01, 00, 06, 08, 6F, 47, 02, 00, 06, 11, 10, 11]
        // .code-bytes IL_0408: [11, 17, 6F, AC, 00, 00, 06, 28, 53, 01, 00, 06, 17, 6F, AD, 00, 00, 06, 72, CA, 15, 00, 70, 28]
        // .code-bytes IL_0420: [01, 01, 00, 0A, 28, 53, 01, 00, 06, 6F, B7, 00, 00, 06, 13, 13, 2B, 63, 11, 13, 6F, 3B, 02, 00]
        // .code-bytes IL_0438: [0A, 13, 14, 1A, 18, 73, C4, 00, 00, 0A, 13, 07, 12, 07, 72, 78, 15, 00, 70, 28, C5, 00, 00, 0A]
        // .code-bytes IL_0450: [12, 07, 12, 14, 28, 3C, 02, 00, 0A, 28, D4, 00, 00, 0A, 12, 07, 72, 5F, 12, 00, 70, 28, C5, 00]
        // .code-bytes IL_0468: [00, 0A, 12, 07, 12, 14, 28, 3D, 02, 00, 0A, 7B, 3F, 00, 00, 04, 28, D4, 00, 00, 0A, 12, 07, 72]
        // .code-bytes IL_0480: [9F, 03, 00, 70, 28, C5, 00, 00, 0A, 12, 07, 28, C7, 00, 00, 0A, 28, 01, 01, 00, 0A, 11, 13, 6F]
        // .code-bytes IL_0498: [18, 00, 00, 0A, 2D, 94, DE, 0C, 11, 13, 2C, 07, 11, 13, 6F, 17, 00, 00, 0A, DC, 08, 02, 28, 7B]
        // .code-bytes IL_04B0: [01, 00, 06, 2A]
        // .local [0] string
        // .local [1] string
        // .local [2] string
        // .local [3] string[]
        // .local [4] string[]
        // .local [5] string
        // .local [6] string[]
        // .local [7] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // .local [8] string[]
        // .local [9] int32
        // .local [10] string
        // .local [11] class OpenRA.IPlatform
        // .local [12] class [System.Runtime]System.Exception
        // .local [13] class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.Manifest>>
        // .local [14] valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.Manifest>
        // .local [15] class OpenRA.Manifest
        // .local [16] string
        // .local [17] class [System.Collections]System.Collections.Generic.List`1<string>
        // .local [18] string
        // .local [19] class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ExternalMod>>
        // .local [20] valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ExternalMod>
        // IL_0000: ldarg.0 0
        // IL_0001: ldstr 0x700011FF [69, 110, 103, 105, 110, 101, 46, 69, 110, 103, 105, 110, 101, 68, 105, 114] utf16-bytes=[45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 2E, 00, 45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 44, 00, 69, 00, 72, 00] terminal-flag=Some(0)
        // IL_0006: ldnull 
        // IL_0007: callvirt 0x060005B3 OpenRA.Arguments::GetValue
        // IL_000C: stloc.0 0
        // IL_000D: ldloc.0 0
        // IL_000E: call 0x0A0000C1 [System.Runtime]System.String::IsNullOrEmpty
        // IL_0013: brtrue.s IL_001B
        // IL_0015: ldloc.0 0
        // IL_0016: call 0x06000467 OpenRA.Platform::OverrideEngineDir
        // IL_001B: ldarg.0 0
        // IL_001C: ldstr 0x70001221 [69, 110, 103, 105, 110, 101, 46, 83, 117, 112, 112, 111, 114, 116, 68, 105, 114] utf16-bytes=[45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 2E, 00, 53, 00, 75, 00, 70, 00, 70, 00, 6F, 00, 72, 00, 74, 00, 44, 00, 69, 00, 72, 00] terminal-flag=Some(0)
        // IL_0021: ldnull 
        // IL_0022: callvirt 0x060005B3 OpenRA.Arguments::GetValue
        // IL_0027: stloc.1 1
        // IL_0028: ldloc.1 1
        // IL_0029: call 0x0A0000C1 [System.Runtime]System.String::IsNullOrEmpty
        // IL_002E: brtrue.s IL_0036
        // IL_0030: ldloc.1 1
        // IL_0031: call 0x06000465 OpenRA.Platform::OverrideSupportDir
        // IL_0036: ldloca.s 7
        // IL_0038: ldc.i4.s 15
        // IL_003A: ldc.i4.2 2
        // IL_003B: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0040: ldloca.s 7
        // IL_0042: ldstr 0x70001245 [80, 108, 97, 116, 102, 111, 114, 109, 32, 105, 115, 32] utf16-bytes=[50, 00, 6C, 00, 61, 00, 74, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 20, 00, 69, 00, 73, 00, 20, 00] terminal-flag=Some(0)
        // IL_0047: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_004C: ldloca.s 7
        // IL_004E: call 0x0600045D OpenRA.Platform::get_CurrentPlatform
        // IL_0053: call 0x2B000052 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<valuetype OpenRA.PlatformType>
        // IL_0058: ldloca.s 7
        // IL_005A: ldstr 0x7000125F [32, 40] utf16-bytes=[20, 00, 28, 00] terminal-flag=Some(0)
        // IL_005F: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0064: ldloca.s 7
        // IL_0066: call 0x0600045E OpenRA.Platform::get_CurrentArchitecture
        // IL_006B: call 0x2B000053 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<valuetype [System.Runtime.InteropServices.RuntimeInformation]System.Runtime.InteropServices.Architecture>
        // IL_0070: ldloca.s 7
        // IL_0072: ldstr 0x7000039F [41] utf16-bytes=[29, 00] terminal-flag=Some(0)
        // IL_0077: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_007C: ldloca.s 7
        // IL_007E: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0083: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_0088: call 0x06000466 OpenRA.Platform::get_EngineDir
        // IL_008D: ldstr 0x70001265 [86, 69, 82, 83, 73, 79, 78] utf16-bytes=[56, 00, 45, 00, 52, 00, 53, 00, 49, 00, 4F, 00, 4E, 00] terminal-flag=Some(0)
        // IL_0092: call 0x0A00011B [System.Runtime]System.IO.Path::Combine
        // IL_0097: call 0x0A000235 [System.Runtime]System.IO.File::ReadAllText
        // IL_009C: callvirt 0x0A0001BB [System.Runtime]System.String::Trim
        // IL_00A1: call 0x06000156 OpenRA.Game::set_EngineVersion
        // IL_00A6: leave.s IL_00AB
        // IL_00A8: pop 
        // IL_00A9: leave.s IL_00AB
        // IL_00AB: call 0x06000155 OpenRA.Game::get_EngineVersion
        // IL_00B0: call 0x0A0000C1 [System.Runtime]System.String::IsNullOrEmpty
        // IL_00B5: brfalse.s IL_00C1
        // IL_00B7: ldstr 0x70001275 [85, 110, 107, 110, 111, 119, 110] utf16-bytes=[55, 00, 6E, 00, 6B, 00, 6E, 00, 6F, 00, 77, 00, 6E, 00] terminal-flag=Some(0)
        // IL_00BC: call 0x06000156 OpenRA.Game::set_EngineVersion
        // IL_00C1: ldstr 0x70001285 [69, 110, 103, 105, 110, 101, 32, 118, 101, 114, 115, 105, 111, 110, 32, 105, 115, 32] utf16-bytes=[45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 76, 00, 65, 00, 72, 00, 73, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 69, 00, 73, 00, 20, 00] terminal-flag=Some(0)
        // IL_00C6: call 0x06000155 OpenRA.Game::get_EngineVersion
        // IL_00CB: call 0x0A00007B [System.Runtime]System.String::Concat
        // IL_00D0: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_00D5: ldstr 0x700012AB [82, 117, 110, 116, 105, 109, 101, 58, 32] utf16-bytes=[52, 00, 75, 00, 6E, 00, 74, 00, 69, 00, 6D, 00, 65, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_00DA: call 0x06000460 OpenRA.Platform::get_RuntimeVersion
        // IL_00DF: call 0x0A00007B [System.Runtime]System.String::Concat
        // IL_00E4: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_00E9: ldarg.0 0
        // IL_00EA: ldstr 0x700012BF [71, 97, 109, 101, 46, 77, 111, 100] utf16-bytes=[47, 00, 61, 00, 6D, 00, 65, 00, 2E, 00, 4D, 00, 6F, 00, 64, 00] terminal-flag=Some(0)
        // IL_00EF: ldnull 
        // IL_00F0: callvirt 0x060005B3 OpenRA.Arguments::GetValue
        // IL_00F5: stloc.2 2
        // IL_00F6: call 0x2B00004B [System.Runtime]System.Array::Empty<string>
        // IL_00FB: stloc.3 3
        // IL_00FC: ldloc.2 2
        // IL_00FD: brfalse.s IL_0121
        // IL_00FF: ldloc.2 2
        // IL_0100: call 0x0A00011F [System.Runtime]System.IO.File::Exists
        // IL_0105: brtrue.s IL_010F
        // IL_0107: ldloc.2 2
        // IL_0108: call 0x0A00011C [System.Runtime]System.IO.Directory::Exists
        // IL_010D: brfalse.s IL_0121
        // IL_010F: ldc.i4.1 1
        // IL_0110: newarr 0x010000FE [System.Runtime]System.String
        // IL_0115: dup 
        // IL_0116: ldc.i4.0 0
        // IL_0117: ldloc.2 2
        // IL_0118: stelem.ref 
        // IL_0119: stloc.3 3
        // IL_011A: ldloc.2 2
        // IL_011B: call 0x0A000120 [System.Runtime]System.IO.Path::GetFileNameWithoutExtension
        // IL_0120: stloc.2 2
        // IL_0121: ldarg.0 0
        // IL_0122: call 0x06000177 OpenRA.Game::InitializeSettings
        // IL_0127: ldstr 0x700012D1 [112, 101, 114, 102] utf16-bytes=[70, 00, 65, 00, 72, 00, 66, 00] terminal-flag=Some(0)
        // IL_012C: ldstr 0x700012DB [112, 101, 114, 102, 46, 108, 111, 103] utf16-bytes=[70, 00, 65, 00, 72, 00, 66, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_0131: ldc.i4.0 0
        // IL_0132: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_0137: ldstr 0x7000061E [100, 101, 98, 117, 103] utf16-bytes=[64, 00, 65, 00, 62, 00, 75, 00, 67, 00] terminal-flag=Some(0)
        // IL_013C: ldstr 0x700012ED [100, 101, 98, 117, 103, 46, 108, 111, 103] utf16-bytes=[64, 00, 65, 00, 62, 00, 75, 00, 67, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_0141: ldc.i4.0 0
        // IL_0142: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_0147: ldstr 0x70001301 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_014C: ldstr 0x7000130F [115, 101, 114, 118, 101, 114, 46, 108, 111, 103] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_0151: ldc.i4.1 1
        // IL_0152: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_0157: ldstr 0x70001325 [115, 111, 117, 110, 100] utf16-bytes=[73, 00, 6F, 00, 75, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_015C: ldstr 0x70001331 [115, 111, 117, 110, 100, 46, 108, 111, 103] utf16-bytes=[73, 00, 6F, 00, 75, 00, 6E, 00, 64, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_0161: ldc.i4.0 0
        // IL_0162: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_0167: ldstr 0x70001345 [103, 114, 97, 112, 104, 105, 99, 115] utf16-bytes=[67, 00, 72, 00, 61, 00, 70, 00, 68, 00, 69, 00, 63, 00, 73, 00] terminal-flag=Some(0)
        // IL_016C: ldstr 0x70001357 [103, 114, 97, 112, 104, 105, 99, 115, 46, 108, 111, 103] utf16-bytes=[67, 00, 72, 00, 61, 00, 70, 00, 68, 00, 69, 00, 63, 00, 73, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_0171: ldc.i4.0 0
        // IL_0172: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_0177: ldstr 0x70001371 [103, 101, 111, 105, 112] utf16-bytes=[67, 00, 65, 00, 6F, 00, 69, 00, 70, 00] terminal-flag=Some(0)
        // IL_017C: ldstr 0x7000137D [103, 101, 111, 105, 112, 46, 108, 111, 103] utf16-bytes=[67, 00, 65, 00, 6F, 00, 69, 00, 70, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_0181: ldc.i4.0 0
        // IL_0182: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_0187: ldstr 0x70001391 [110, 97, 116] utf16-bytes=[6E, 00, 61, 00, 74, 00] terminal-flag=Some(0)
        // IL_018C: ldstr 0x70001399 [110, 97, 116, 46, 108, 111, 103] utf16-bytes=[6E, 00, 61, 00, 74, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_0191: ldc.i4.0 0
        // IL_0192: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_0197: ldstr 0x700013A9 [99, 108, 105, 101, 110, 116] utf16-bytes=[63, 00, 6C, 00, 69, 00, 65, 00, 6E, 00, 74, 00] terminal-flag=Some(0)
        // IL_019C: ldstr 0x700013B7 [99, 108, 105, 101, 110, 116, 46, 108, 111, 103] utf16-bytes=[63, 00, 6C, 00, 69, 00, 65, 00, 6E, 00, 74, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00] terminal-flag=Some(0)
        // IL_01A1: ldc.i4.0 0
        // IL_01A2: call 0x060005C3 OpenRA.Log::AddChannel
        // IL_01A7: ldc.i4.3 3
        // IL_01A8: newarr 0x010000FE [System.Runtime]System.String
        // IL_01AD: dup 
        // IL_01AE: ldc.i4.0 0
        // IL_01AF: ldsfld 0x04000066 OpenRA.Game::Settings
        // IL_01B4: ldfld 0x04000454 OpenRA.Settings::Game
        // IL_01B9: ldfld 0x04000438 OpenRA.GameSettings::Platform
        // IL_01BE: stelem.ref 
        // IL_01BF: dup 
        // IL_01C0: ldc.i4.1 1
        // IL_01C1: ldstr 0x700013CD [68, 101, 102, 97, 117, 108, 116] utf16-bytes=[44, 00, 65, 00, 66, 00, 61, 00, 75, 00, 6C, 00, 74, 00] terminal-flag=Some(0)
        // IL_01C6: stelem.ref 
        // IL_01C7: stloc.s 4
        // IL_01C9: ldloc.s 4
        // IL_01CB: stloc.s 8
        // IL_01CD: ldc.i4.0 0
        // IL_01CE: stloc.s 9
        // IL_01D0: br IL_028A
        // IL_01D5: ldloc.s 8
        // IL_01D7: ldloc.s 9
        // IL_01D9: ldelem.ref 
        // IL_01DA: stloc.s 10
        // IL_01DC: ldloc.s 10
        // IL_01DE: brtrue.s IL_01EB
        // IL_01E0: ldstr 0x700013DD [70, 97, 105, 108, 101, 100, 32, 116, 111, 32, 105, 110, 105, 116, 105, 97, 108, 105, 122, 101, 32, 112, 108, 97, 116, 102, 111, 114, 109, 45, 105, 110, 116, 101, 103, 114, 97, 116, 105, 111, 110, 32, 108, 105, 98, 114, 97, 114, 121, 46, 32, 67, 104, 101, 99, 107, 32, 103, 114, 97, 112, 104, 105, 99, 115, 46, 108, 111, 103, 32, 102, 111, 114, 32, 100, 101, 116, 97, 105, 108, 115, 46] utf16-bytes=[46, 00, 61, 00, 69, 00, 6C, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 69, 00, 6E, 00, 69, 00, 74, 00, 69, 00, 61, 00, 6C, 00, 69, 00, 7A, 00, 65, 00, 20, 00, 70, 00, 6C, 00, 61, 00, 74, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 2D, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 72, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 6C, 00, 69, 00, 62, 00, 72, 00, 61, 00, 72, 00, 79, 00, 2E, 00, 20, 00, 43, 00, 68, 00, 65, 00, 63, 00, 6B, 00, 20, 00, 67, 00, 72, 00, 61, 00, 70, 00, 68, 00, 69, 00, 63, 00, 73, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 64, 00, 65, 00, 74, 00, 61, 00, 69, 00, 6C, 00, 73, 00, 2E, 00] terminal-flag=Some(1)
        // IL_01E5: newobj 0x0A00006E [System.Runtime]System.InvalidOperationException::.ctor
        // IL_01EA: throw 
        // IL_01EB: ldsfld 0x04000066 OpenRA.Game::Settings
        // IL_01F0: ldfld 0x04000454 OpenRA.Settings::Game
        // IL_01F5: ldloc.s 10
        // IL_01F7: stfld 0x04000438 OpenRA.GameSettings::Platform
        // IL_01FC: ldloc.s 10
        // IL_01FE: call 0x0600017A OpenRA.Game::CreatePlatform
        // IL_0203: stloc.s 11
        // IL_0205: ldloc.s 11
        // IL_0207: ldsfld 0x04000066 OpenRA.Game::Settings
        // IL_020C: ldfld 0x04000456 OpenRA.Settings::Graphics
        // IL_0211: newobj 0x06000509 OpenRA.Renderer::.ctor
        // IL_0216: stsfld 0x0400006E OpenRA.Game::Renderer
        // IL_021B: ldloc.s 11
        // IL_021D: ldsfld 0x04000066 OpenRA.Game::Settings
        // IL_0222: ldfld 0x04000455 OpenRA.Settings::Sound
        // IL_0227: newobj 0x06000548 OpenRA.Sound::.ctor
        // IL_022C: stsfld 0x0400006F OpenRA.Game::Sound
        // IL_0231: leave.s IL_0295
        // IL_0233: stloc.s 12
        // IL_0235: ldstr 0x70001345 [103, 114, 97, 112, 104, 105, 99, 115] utf16-bytes=[67, 00, 72, 00, 61, 00, 70, 00, 68, 00, 69, 00, 63, 00, 73, 00] terminal-flag=Some(0)
        // IL_023A: ldloca.s 7
        // IL_023C: ldc.i4.0 0
        // IL_023D: ldc.i4.1 1
        // IL_023E: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0243: ldloca.s 7
        // IL_0245: ldloc.s 12
        // IL_0247: call 0x2B000054 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<class [System.Runtime]System.Exception>
        // IL_024C: ldloca.s 7
        // IL_024E: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0253: call 0x060005C4 OpenRA.Log::Write
        // IL_0258: ldstr 0x70001484 [82, 101, 110, 100, 101, 114, 101, 114, 32, 105, 110, 105, 116, 105, 97, 108, 105, 122, 97, 116, 105, 111, 110, 32, 102, 97, 105, 108, 101, 100, 46, 32, 67, 104, 101, 99, 107, 32, 103, 114, 97, 112, 104, 105, 99, 115, 46, 108, 111, 103, 32, 102, 111, 114, 32, 100, 101, 116, 97, 105, 108, 115, 46] utf16-bytes=[52, 00, 65, 00, 6E, 00, 64, 00, 65, 00, 72, 00, 65, 00, 72, 00, 20, 00, 69, 00, 6E, 00, 69, 00, 74, 00, 69, 00, 61, 00, 6C, 00, 69, 00, 7A, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 66, 00, 61, 00, 69, 00, 6C, 00, 65, 00, 64, 00, 2E, 00, 20, 00, 43, 00, 68, 00, 65, 00, 63, 00, 6B, 00, 20, 00, 67, 00, 72, 00, 61, 00, 70, 00, 68, 00, 69, 00, 63, 00, 73, 00, 2E, 00, 6C, 00, 6F, 00, 67, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 64, 00, 65, 00, 74, 00, 61, 00, 69, 00, 6C, 00, 73, 00, 2E, 00] terminal-flag=Some(0)
        // IL_025D: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_0262: ldsfld 0x0400006E OpenRA.Game::Renderer
        // IL_0267: dup 
        // IL_0268: brtrue.s IL_026D
        // IL_026A: pop 
        // IL_026B: br.s IL_0272
        // IL_026D: call 0x0600052D OpenRA.Renderer::Dispose
        // IL_0272: ldsfld 0x0400006F OpenRA.Game::Sound
        // IL_0277: dup 
        // IL_0278: brtrue.s IL_027D
        // IL_027A: pop 
        // IL_027B: br.s IL_0282
        // IL_027D: call 0x06000580 OpenRA.Sound::Dispose
        // IL_0282: leave.s IL_0284
        // IL_0284: ldloc.s 9
        // IL_0286: ldc.i4.1 1
        // IL_0287: add 
        // IL_0288: stloc.s 9
        // IL_028A: ldloc.s 9
        // IL_028C: ldloc.s 8
        // IL_028E: ldlen 
        // IL_028F: conv.i4 
        // IL_0290: blt IL_01D5
        // IL_0295: call 0x06000C81 OpenRA.Network.Nat::Initialize
        // IL_029A: ldarg.0 0
        // IL_029B: ldstr 0x70001504 [69, 110, 103, 105, 110, 101, 46, 77, 111, 100, 83, 101, 97, 114, 99, 104, 80, 97, 116, 104, 115] utf16-bytes=[45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 2E, 00, 4D, 00, 6F, 00, 64, 00, 53, 00, 65, 00, 61, 00, 72, 00, 63, 00, 68, 00, 50, 00, 61, 00, 74, 00, 68, 00, 73, 00] terminal-flag=Some(0)
        // IL_02A0: ldnull 
        // IL_02A1: callvirt 0x060005B3 OpenRA.Arguments::GetValue
        // IL_02A6: stloc.s 5
        // IL_02A8: ldloc.s 5
        // IL_02AA: brtrue.s IL_02C6
        // IL_02AC: ldc.i4.1 1
        // IL_02AD: newarr 0x010000FE [System.Runtime]System.String
        // IL_02B2: dup 
        // IL_02B3: ldc.i4.0 0
        // IL_02B4: call 0x06000466 OpenRA.Platform::get_EngineDir
        // IL_02B9: ldstr 0x70001530 [109, 111, 100, 115] utf16-bytes=[6D, 00, 6F, 00, 64, 00, 73, 00] terminal-flag=Some(0)
        // IL_02BE: call 0x0A00011B [System.Runtime]System.IO.Path::Combine
        // IL_02C3: stelem.ref 
        // IL_02C4: br.s IL_02D2
        // IL_02C6: ldstr 0x7000153A [69, 110, 103, 105, 110, 101, 46, 77, 111, 100, 115, 80, 97, 116, 104] utf16-bytes=[45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 2E, 00, 4D, 00, 6F, 00, 64, 00, 73, 00, 50, 00, 61, 00, 74, 00, 68, 00] terminal-flag=Some(0)
        // IL_02CB: ldloc.s 5
        // IL_02CD: call 0x2B00004C OpenRA.FieldLoader::GetValue<string[]>
        // IL_02D2: stloc.s 6
        // IL_02D4: ldloc.s 6
        // IL_02D6: ldloc.3 3
        // IL_02D7: newobj 0x06000243 OpenRA.InstalledMods::.ctor
        // IL_02DC: call 0x06000152 OpenRA.Game::set_Mods
        // IL_02E1: ldstr 0x7000155A [73, 110, 116, 101, 114, 110, 97, 108, 32, 109, 111, 100, 115, 58] utf16-bytes=[49, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 6E, 00, 61, 00, 6C, 00, 20, 00, 6D, 00, 6F, 00, 64, 00, 73, 00, 3A, 00] terminal-flag=Some(0)
        // IL_02E6: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_02EB: call 0x06000151 OpenRA.Game::get_Mods
        // IL_02F0: callvirt 0x0600024C OpenRA.InstalledMods::GetEnumerator
        // IL_02F5: stloc.s 13
        // IL_02F7: br.s IL_0361
        // IL_02F9: ldloc.s 13
        // IL_02FB: callvirt 0x0A000236 class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.Manifest>>::get_Current
        // IL_0300: stloc.s 14
        // IL_0302: ldc.i4.4 4
        // IL_0303: ldc.i4.2 2
        // IL_0304: newobj 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0309: stloc.s 7
        // IL_030B: ldloca.s 7
        // IL_030D: ldstr 0x70001578 [9] utf16-bytes=[09, 00] terminal-flag=Some(0)
        // IL_0312: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0317: ldloca.s 7
        // IL_0319: ldloca.s 14
        // IL_031B: call 0x0A000237 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.Manifest>::get_Key
        // IL_0320: call 0x0A0000D4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted
        // IL_0325: ldloca.s 7
        // IL_0327: ldstr 0x7000125F [32, 40] utf16-bytes=[20, 00, 28, 00] terminal-flag=Some(0)
        // IL_032C: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0331: ldloca.s 7
        // IL_0333: ldloca.s 14
        // IL_0335: call 0x0A000238 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.Manifest>::get_Value
        // IL_033A: ldfld 0x040001FD OpenRA.Manifest::Metadata
        // IL_033F: ldfld 0x040001F6 OpenRA.ModMetadata::Version
        // IL_0344: call 0x0A0000D4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted
        // IL_0349: ldloca.s 7
        // IL_034B: ldstr 0x7000039F [41] utf16-bytes=[29, 00] terminal-flag=Some(0)
        // IL_0350: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0355: ldloca.s 7
        // IL_0357: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_035C: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_0361: ldloc.s 13
        // IL_0363: callvirt 0x0A000018 [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_0368: brtrue.s IL_02F9
        // IL_036A: leave.s IL_0378
        // IL_036C: ldloc.s 13
        // IL_036E: brfalse.s IL_0377
        // IL_0370: ldloc.s 13
        // IL_0372: callvirt 0x0A000017 [System.Runtime]System.IDisposable::Dispose
        // IL_0377: endfinally 
        // IL_0378: ldarg.0 0
        // IL_0379: ldstr 0x7000157C [69, 110, 103, 105, 110, 101, 46, 76, 97, 117, 110, 99, 104, 87, 114, 97, 112, 112, 101, 114] utf16-bytes=[45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 2E, 00, 4C, 00, 61, 00, 75, 00, 6E, 00, 63, 00, 68, 00, 57, 00, 72, 00, 61, 00, 70, 00, 70, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_037E: ldnull 
        // IL_037F: callvirt 0x060005B3 OpenRA.Arguments::GetValue
        // IL_0384: stsfld 0x0400006A OpenRA.Game::modLaunchWrapper
        // IL_0389: newobj 0x060000AA OpenRA.ExternalMods::.ctor
        // IL_038E: call 0x06000154 OpenRA.Game::set_ExternalMods
        // IL_0393: ldloc.2 2
        // IL_0394: brfalse IL_041A
        // IL_0399: call 0x06000151 OpenRA.Game::get_Mods
        // IL_039E: ldloc.2 2
        // IL_039F: ldloca.s 15
        // IL_03A1: callvirt 0x0600024D OpenRA.InstalledMods::TryGetValue
        // IL_03A6: brfalse.s IL_041A
        // IL_03A8: ldarg.0 0
        // IL_03A9: ldstr 0x700015A6 [69, 110, 103, 105, 110, 101, 46, 76, 97, 117, 110, 99, 104, 80, 97, 116, 104] utf16-bytes=[45, 00, 6E, 00, 67, 00, 69, 00, 6E, 00, 65, 00, 2E, 00, 4C, 00, 61, 00, 75, 00, 6E, 00, 63, 00, 68, 00, 50, 00, 61, 00, 74, 00, 68, 00] terminal-flag=Some(0)
        // IL_03AE: ldnull 
        // IL_03AF: callvirt 0x060005B3 OpenRA.Arguments::GetValue
        // IL_03B4: stloc.s 16
        // IL_03B6: newobj 0x0A000174 class [System.Collections]System.Collections.Generic.List`1<string>::.ctor
        // IL_03BB: stloc.s 17
        // IL_03BD: ldloc.s 16
        // IL_03BF: brfalse.s IL_03F1
        // IL_03C1: ldloc.s 16
        // IL_03C3: ldc.i4.0 0
        // IL_03C4: callvirt 0x0A000239 [System.Runtime]System.String::get_Chars
        // IL_03C9: ldc.i4.s 34
        // IL_03CB: bne.un.s IL_03F1
        // IL_03CD: ldloc.s 16
        // IL_03CF: call 0x2B000055 [System.Linq]System.Linq.Enumerable::Last<char>
        // IL_03D4: ldc.i4.s 34
        // IL_03D6: bne.un.s IL_03F1
        // IL_03D8: ldloc.s 16
        // IL_03DA: stloc.s 18
        // IL_03DC: ldloc.s 18
        // IL_03DE: ldc.i4.1 1
        // IL_03DF: ldloc.s 18
        // IL_03E1: callvirt 0x0A0000E2 [System.Runtime]System.String::get_Length
        // IL_03E6: ldc.i4.1 1
        // IL_03E7: sub 
        // IL_03E8: ldc.i4.1 1
        // IL_03E9: sub 
        // IL_03EA: callvirt 0x0A0000E4 [System.Runtime]System.String::Substring
        // IL_03EF: stloc.s 16
        // IL_03F1: ldloc.s 16
        // IL_03F3: brfalse.s IL_040F
        // IL_03F5: call 0x06000153 OpenRA.Game::get_ExternalMods
        // IL_03FA: call 0x06000151 OpenRA.Game::get_Mods
        // IL_03FF: ldloc.2 2
        // IL_0400: callvirt 0x06000247 OpenRA.InstalledMods::get_Item
        // IL_0405: ldloc.s 16
        // IL_0407: ldloc.s 17
        // IL_0409: ldc.i4.1 1
        // IL_040A: callvirt 0x060000AC OpenRA.ExternalMods::Register
        // IL_040F: call 0x06000153 OpenRA.Game::get_ExternalMods
        // IL_0414: ldc.i4.1 1
        // IL_0415: callvirt 0x060000AD OpenRA.ExternalMods::ClearInvalidRegistrations
        // IL_041A: ldstr 0x700015CA [69, 120, 116, 101, 114, 110, 97, 108, 32, 109, 111, 100, 115, 58] utf16-bytes=[45, 00, 78, 00, 74, 00, 65, 00, 72, 00, 6E, 00, 61, 00, 6C, 00, 20, 00, 6D, 00, 6F, 00, 64, 00, 73, 00, 3A, 00] terminal-flag=Some(0)
        // IL_041F: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_0424: call 0x06000153 OpenRA.Game::get_ExternalMods
        // IL_0429: callvirt 0x060000B7 OpenRA.ExternalMods::GetEnumerator
        // IL_042E: stloc.s 19
        // IL_0430: br.s IL_0495
        // IL_0432: ldloc.s 19
        // IL_0434: callvirt 0x0A00023B class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ExternalMod>>::get_Current
        // IL_0439: stloc.s 20
        // IL_043B: ldc.i4.4 4
        // IL_043C: ldc.i4.2 2
        // IL_043D: newobj 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0442: stloc.s 7
        // IL_0444: ldloca.s 7
        // IL_0446: ldstr 0x70001578 [9] utf16-bytes=[09, 00] terminal-flag=Some(0)
        // IL_044B: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0450: ldloca.s 7
        // IL_0452: ldloca.s 20
        // IL_0454: call 0x0A00023C valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ExternalMod>::get_Key
        // IL_0459: call 0x0A0000D4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted
        // IL_045E: ldloca.s 7
        // IL_0460: ldstr 0x7000125F [32, 40] utf16-bytes=[20, 00, 28, 00] terminal-flag=Some(0)
        // IL_0465: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_046A: ldloca.s 7
        // IL_046C: ldloca.s 20
        // IL_046E: call 0x0A00023D valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class OpenRA.ExternalMod>::get_Value
        // IL_0473: ldfld 0x0400003F OpenRA.ExternalMod::Version
        // IL_0478: call 0x0A0000D4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted
        // IL_047D: ldloca.s 7
        // IL_047F: ldstr 0x7000039F [41] utf16-bytes=[29, 00] terminal-flag=Some(0)
        // IL_0484: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0489: ldloca.s 7
        // IL_048B: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0490: call 0x0A000101 [System.Console]System.Console::WriteLine
        // IL_0495: ldloc.s 19
        // IL_0497: callvirt 0x0A000018 [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_049C: brtrue.s IL_0432
        // IL_049E: leave.s IL_04AC
        // IL_04A0: ldloc.s 19
        // IL_04A2: brfalse.s IL_04AB
        // IL_04A4: ldloc.s 19
        // IL_04A6: callvirt 0x0A000017 [System.Runtime]System.IDisposable::Dispose
        // IL_04AB: endfinally 
        // IL_04AC: ldloc.2 2
        // IL_04AD: ldarg.0 0
        // IL_04AE: call 0x0600017B OpenRA.Game::InitializeMod
        // IL_04B3: ret 
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[18])), try_offset: 136, try_length: 32, handler_offset: 168, handler_length: 3, raw_flags: 0 }
        // .try IL_0088..IL_00A8 catch 0x01000012 [System.Runtime]System.Object IL_00A8..IL_00AB
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[58])), try_offset: 508, try_length: 55, handler_offset: 563, handler_length: 81, raw_flags: 0 }
        // .try IL_01FC..IL_0233 catch 0x0100003A [System.Runtime]System.Exception IL_0233..IL_0284
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 759, try_length: 117, handler_offset: 876, handler_length: 12, raw_flags: 2 }
        // .try IL_02F7..IL_036C finally IL_036C..IL_0378
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 1072, try_length: 112, handler_offset: 1184, handler_length: 12, raw_flags: 2 }
        // .try IL_0430..IL_04A0 finally IL_04A0..IL_04AC
    }

    public static OpenRA.IPlatform CreatePlatform(string platformName)
    {
        // structural signature __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 bytes=1D128099: class [System.Runtime]System.Type[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_961e6022a7673463720bb85e120d726a88aff610 bytes=151280C90212809902: class [System.Runtime]System.Func`2<class [System.Runtime]System.Type, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_680b36952fa42a45596042d94398ccdfd5b77b9a bytes=1512808501128099: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [System.Runtime]System.Type>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000026 l2 = default;
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 s1_0 = default;
        __cil_ref_961e6022a7673463720bb85e120d726a88aff610 s1_1 = default;
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 s2_0 = default;
        __cil_ref_961e6022a7673463720bb85e120d726a88aff610 s2_1 = default;
        string v0 = OpenRA.Platform.get_BinDir();
        string v1 = __cil_ldstr_700015E8("OpenRA.Platforms.");
        string v3 = __cil_ldstr_70000BFC(".dll");
        string v4 = System.String.Concat(v1, platformName, v3);
        string v5 = System.IO.Path.Combine(v0, v4);
        global::OpenRA.Support.AssemblyLoader v7 = __cil_newobj_06000771(v5);
        __cil_type_01000049 v9 = __cil_callvirt_06000770(v7);
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 v10 = v9.GetTypes();
        __cil_ref_961e6022a7673463720bb85e120d726a88aff610 v11 = OpenRA.Game.__name_3C3E63.__il_field_04000986;
        if (v11 is not null) {
            __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 e0_2_0 = v10;
            __cil_ref_961e6022a7673463720bb85e120d726a88aff610 e0_2_1 = v11;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_004C;
        } else {
            __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 e0_1_0 = v10;
            __cil_ref_961e6022a7673463720bb85e120d726a88aff610 e0_1_1 = v11;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_0035;
        }
        IL_0035: ;
        global::OpenRA.Game.__name_3C3E63 v12 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v13 = __cil_ldftn_06000FAE;
        __cil_ref_961e6022a7673463720bb85e120d726a88aff610 v14 = __cil_newobj_0A00023E(v12, v13);
        OpenRA.Game.__name_3C3E63.__il_field_04000986 = v14;
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 e1_2_0 = s1_0;
        __cil_ref_961e6022a7673463720bb85e120d726a88aff610 e1_2_1 = v14;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        IL_004C: ;
        __cil_type_01000026 v15 = __cil_methodspec_call_2B000056(((__cil_ref_680b36952fa42a45596042d94398ccdfd5b77b9a)(s2_0)), s2_1);
        l2 = v15;
        __cil_type_01000026 v16 = l2;
        int v17 = __cil_bool_load(System.Type.op_Equality(v16, ((__cil_type_01000026)(null))));
        if (v17 == 0) {
            goto IL_0066;
        } else {
            goto IL_005B;
        }
        IL_005B: ;
        string v18 = __cil_ldstr_7000160C("Platform dll must include exactly one IPlatform implementation.");
        global::System.InvalidOperationException v19 = __cil_newobj_0A00006E(v18);
        throw v19;
        IL_0066: ;
        __cil_type_01000026 v20 = l2;
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 v21 = __cil_ldsfld_0A000240();
        __cil_type_0100005D v22 = v20.GetConstructor(v21);
        object v23 = v22.Invoke(((__cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff)(null)));
        global::OpenRA.IPlatform v24 = ((OpenRA.IPlatform)(object)v23);
        return v24;
    }

    public static void InitializeMod(string mod, OpenRA.Arguments args)
    {
        // structural signature __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec bytes=151281CD031287800E128744: class [System.Runtime]System.Action`3<class OpenRA.Network.OrderManager, string, class OpenRA.Network.NetworkConnection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 bytes=151281A901128748: class [System.Runtime]System.Action`1<class OpenRA.Network.ConnectionTarget>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c bytes=151286CC020E1283A8: class OpenRA.Primitives.Cache`2<string, class OpenRA.Support.PerfItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.MapGrid l0 = default;
        OpenRA.ModMetadata l1 = default;
        OpenRA.Support.PerfTimer l2 = default;
        __cil_type_01000072 s1_0 = default;
        __cil_type_01000072 s2_0 = default;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec s3_0 = default;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec s4_0 = default;
        __cil_type_01000072 s5_0 = default;
        __cil_type_01000072 s6_0 = default;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 s7_0 = default;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 s8_0 = default;
        OpenRA.Graphics.WorldRenderer s9_0 = default;
        OpenRA.Graphics.WorldRenderer s10_0 = default;
        OpenRA.Server.Server s12_0 = default;
        OpenRA.Server.Server s13_0 = default;
        OpenRA.Network.OrderManager s15_0 = default;
        OpenRA.Network.OrderManager s16_0 = default;
        OpenRA.MapGrid s33_0 = default;
        OpenRA.Graphics.CursorManager s34_0 = default;
        OpenRA.Graphics.CursorManager s35_0 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.__name_3C3E63.__il_field_04000987;
        if (v0 is not null) {
            __cil_type_01000072 e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_001F;
        } else {
            __cil_type_01000072 e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Game.__name_3C3E63 v1 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v2 = __cil_ldftn_06000FAF;
        __cil_type_01000072 v3 = __cil_newobj_0A000232(v1, v2);
        OpenRA.Game.__name_3C3E63.__il_field_04000987 = v3;
        __cil_type_01000072 e1_2_0 = v3;
        s2_0 = e1_2_0;
        goto IL_001F;
        IL_001F: ;
        OpenRA.Game.LobbyInfoChanged = s2_0;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v4 = OpenRA.Game.__name_3C3E63.__il_field_04000988;
        if (v4 is not null) {
            __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec e2_4_0 = v4;
            s4_0 = e2_4_0;
            goto IL_0043;
        } else {
            __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec e2_3_0 = v4;
            s3_0 = e2_3_0;
            goto IL_002C;
        }
        IL_002C: ;
        global::OpenRA.Game.__name_3C3E63 v5 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v6 = __cil_ldftn_06000FB0;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v7 = __cil_newobj_0A000241(v5, v6);
        OpenRA.Game.__name_3C3E63.__il_field_04000988 = v7;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec e3_4_0 = v7;
        s4_0 = e3_4_0;
        goto IL_0043;
        IL_0043: ;
        OpenRA.Game.ConnectionStateChanged = s4_0;
        __cil_type_01000072 v8 = OpenRA.Game.__name_3C3E63.__il_field_04000989;
        if (v8 is not null) {
            __cil_type_01000072 e4_6_0 = v8;
            s6_0 = e4_6_0;
            goto IL_0067;
        } else {
            __cil_type_01000072 e4_5_0 = v8;
            s5_0 = e4_5_0;
            goto IL_0050;
        }
        IL_0050: ;
        global::OpenRA.Game.__name_3C3E63 v9 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v10 = __cil_ldftn_06000FB1;
        __cil_type_01000072 v11 = __cil_newobj_0A000232(v9, v10);
        OpenRA.Game.__name_3C3E63.__il_field_04000989 = v11;
        __cil_type_01000072 e5_6_0 = v11;
        s6_0 = e5_6_0;
        goto IL_0067;
        IL_0067: ;
        OpenRA.Game.BeforeGameStart = s6_0;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v12 = OpenRA.Game.__name_3C3E63.__il_field_0400098A;
        if (v12 is not null) {
            __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 e6_8_0 = v12;
            s8_0 = e6_8_0;
            goto IL_008B;
        } else {
            __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 e6_7_0 = v12;
            s7_0 = e6_7_0;
            goto IL_0074;
        }
        IL_0074: ;
        global::OpenRA.Game.__name_3C3E63 v13 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v14 = __cil_ldftn_06000FB2;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v15 = __cil_newobj_0A000242(v13, v14);
        OpenRA.Game.__name_3C3E63.__il_field_0400098A = v15;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 e7_8_0 = v15;
        s8_0 = e7_8_0;
        goto IL_008B;
        IL_008B: ;
        OpenRA.Game.OnRemoteDirectConnect = s8_0;
        global::OpenRA.Primitives.ActionQueue v16 = __cil_newobj_06000A0B();
        System.Threading.Volatile.Write(ref OpenRA.Game.delayedActions, v16);
        OpenRA.Widgets.Ui.ResetAll();
        global::OpenRA.Graphics.WorldRenderer v17 = OpenRA.Game.worldRenderer;
        if (v17 is not null) {
            OpenRA.Graphics.WorldRenderer e8_10_0 = v17;
            s10_0 = e8_10_0;
            goto IL_00AC;
        } else {
            OpenRA.Graphics.WorldRenderer e8_9_0 = v17;
            s9_0 = e8_9_0;
            goto IL_00A9;
        }
        IL_00A9: ;
        goto IL_00B1;
        IL_00AC: ;
        __cil_direct_06000EC2(s10_0);
        goto IL_00B1;
        IL_00B1: ;
        OpenRA.Game.worldRenderer = null;
        global::OpenRA.Server.Server v18 = OpenRA.Game.server;
        if (v18 is not null) {
            OpenRA.Server.Server e11_13_0 = v18;
            s13_0 = e11_13_0;
            goto IL_00C2;
        } else {
            OpenRA.Server.Server e11_12_0 = v18;
            s12_0 = e11_12_0;
            goto IL_00BF;
        }
        IL_00BF: ;
        goto IL_00C7;
        IL_00C2: ;
        __cil_direct_060007EA(s13_0);
        goto IL_00C7;
        IL_00C7: ;
        global::OpenRA.Network.OrderManager v19 = OpenRA.Game.OrderManager;
        if (v19 is not null) {
            OpenRA.Network.OrderManager e14_16_0 = v19;
            s16_0 = e14_16_0;
            goto IL_00D2;
        } else {
            OpenRA.Network.OrderManager e14_15_0 = v19;
            s15_0 = e14_15_0;
            goto IL_00CF;
        }
        IL_00CF: ;
        goto IL_00D7;
        IL_00D2: ;
        __cil_direct_06000CAC(s16_0);
        goto IL_00D7;
        IL_00D7: ;
        global::OpenRA.ModData v20 = OpenRA.Game.ModData;
        if (v20 is null) {
            goto IL_00F7;
        } else {
            goto IL_00DE;
        }
        IL_00DE: ;
        global::OpenRA.ModData v21 = OpenRA.Game.ModData;
        global::OpenRA.FileSystem.FileSystem v22 = v21.ModFiles;
        __cil_callvirt_06000EEE(v22);
        global::OpenRA.ModData v23 = OpenRA.Game.ModData;
        __cil_callvirt_06000419(v23);
        goto IL_00F7;
        IL_00F7: ;
        OpenRA.Game.ModData = null;
        string v24 = mod;
        if (v24 is not null) {
            goto IL_010B;
        } else {
            goto IL_0100;
        }
        IL_0100: ;
        string v25 = __cil_ldstr_7000168C("Game.Mod argument missing.");
        global::System.InvalidOperationException v26 = __cil_newobj_0A00006E(v25);
        throw v26;
        IL_010B: ;
        global::OpenRA.InstalledMods v27 = OpenRA.Game.get_Mods();
        string v28 = mod;
        int v29 = __cil_bool_load(__cil_callvirt_0600024B(v27, v28));
        if (v29 != 0) {
            goto IL_012E;
        } else {
            goto IL_0118;
        }
        IL_0118: ;
        string v30 = __cil_ldstr_700016C2("Unknown or invalid mod '");
        string v31 = mod;
        string v32 = __cil_ldstr_700016F4("'.");
        string v33 = System.String.Concat(v30, v31, v32);
        global::System.InvalidOperationException v34 = __cil_newobj_0A00006E(v33);
        throw v34;
        IL_012E: ;
        string v35 = __cil_ldstr_700016FA("Loading mod: ");
        string v36 = mod;
        string v37 = System.String.Concat(v35, v36);
        System.Console.WriteLine(v37);
        global::OpenRA.Sound v38 = OpenRA.Game.Sound;
        __cil_callvirt_06000567(v38);
        global::OpenRA.InstalledMods v39 = OpenRA.Game.get_Mods();
        string v40 = mod;
        global::OpenRA.Manifest v41 = __cil_callvirt_06000247(v39, v40);
        global::OpenRA.InstalledMods v42 = OpenRA.Game.get_Mods();
        int v43 = 1;
        global::OpenRA.ModData v44 = __cil_newobj_06000412(v41, v42, v43);
        OpenRA.Game.ModData = v44;
        string v45 = OpenRA.Platform.get_SupportDir();
        global::OpenRA.Settings v46 = OpenRA.Game.Settings;
        global::OpenRA.GameSettings v47 = v46.Game;
        string v48 = v47.AuthProfile;
        string v49 = System.IO.Path.Combine(v45, v48);
        global::OpenRA.ModData v50 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v51 = v50.Manifest;
        global::OpenRA.PlayerDatabase v52 = __cil_callvirt_2B000057(v51);
        global::OpenRA.LocalPlayerProfile v53 = __cil_newobj_0600025B(v49, v52);
        OpenRA.Game.LocalPlayerProfile = v53;
        global::OpenRA.ModData v54 = OpenRA.Game.ModData;
        global::OpenRA.ILoadScreen v55 = __cil_callvirt_0600040C(v54);
        int v56 = __cil_bool_load(__cil_callvirt_0600041E(v55));
        if (v56 != 0) {
            goto IL_01A7;
        } else {
            goto IL_01A6;
        }
        IL_01A6: ;
        return;
        IL_01A7: ;
        global::OpenRA.ModData v57 = OpenRA.Game.ModData;
        global::OpenRA.ModData v58 = OpenRA.Game.ModData;
        global::OpenRA.FileSystem.IReadOnlyFileSystem v59 = __cil_callvirt_0600040F(v58);
        __cil_callvirt_06000415(v57, v59);
        global::OpenRA.Renderer v60 = OpenRA.Game.Renderer;
        global::OpenRA.ModData v61 = OpenRA.Game.ModData;
        __cil_callvirt_0600050C(v60, v61);
        string v62 = __cil_ldstr_70001716("LoadMaps");
        __cil_F v63 = __cil_ldc_r4_bits(0x00000000u);
        global::OpenRA.Support.PerfTimer v64 = __cil_newobj_060007B3(v62, v63);
        l2 = v64;
        try {
            IL_01DA: ;
            global::OpenRA.ModData v65 = OpenRA.Game.ModData;
            global::OpenRA.MapCache v66 = v65.MapCache;
            __cil_callvirt_0600034F(v66);
            goto IL_01F5;
        }
        finally {
            IL_01EB: ;
            global::OpenRA.Support.PerfTimer v67 = l2;
            if (v67 is null) {
                goto IL_01F4;
            } else {
                goto IL_01EE;
            }
            IL_01EE: ;
            global::OpenRA.Support.PerfTimer v68 = l2;
            __cil_callvirt_0A000017(v68);
            goto IL_01F4;
            IL_01F4: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_01F5: ;
        global::OpenRA.ModData v69 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v70 = v69.Manifest;
        int v71 = __cil_bool_load(__cil_callvirt_2B000058(v70));
        if (v71 != 0) {
            goto IL_0209;
        } else {
            goto IL_0206;
        }
        IL_0206: ;
        OpenRA.MapGrid e31_33_0 = null;
        s33_0 = e31_33_0;
        goto IL_0218;
        IL_0209: ;
        global::OpenRA.ModData v72 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v73 = v72.Manifest;
        global::OpenRA.MapGrid v74 = __cil_callvirt_2B000059(v73);
        OpenRA.MapGrid e32_33_0 = v74;
        s33_0 = e32_33_0;
        goto IL_0218;
        IL_0218: ;
        l0 = s33_0;
        global::OpenRA.Renderer v75 = OpenRA.Game.Renderer;
        global::OpenRA.MapGrid v76 = l0;
        __cil_callvirt_0600050D(v75, v76);
        global::OpenRA.Graphics.CursorManager v77 = OpenRA.Game.Cursor;
        if (v77 is not null) {
            OpenRA.Graphics.CursorManager e33_35_0 = v77;
            s35_0 = e33_35_0;
            goto IL_022F;
        } else {
            OpenRA.Graphics.CursorManager e33_34_0 = v77;
            s34_0 = e33_34_0;
            goto IL_022C;
        }
        IL_022C: ;
        goto IL_0234;
        IL_022F: ;
        __cil_direct_06000D2C(s35_0);
        goto IL_0234;
        IL_0234: ;
        global::OpenRA.ModData v78 = OpenRA.Game.ModData;
        global::OpenRA.Graphics.CursorProvider v79 = __cil_callvirt_0600040D(v78);
        global::OpenRA.ModData v80 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v81 = v80.Manifest;
        int v82 = v81.CursorSheetSize;
        global::OpenRA.Graphics.CursorManager v83 = __cil_newobj_06000D21(v79, v82);
        OpenRA.Game.Cursor = v83;
        global::OpenRA.ModData v84 = OpenRA.Game.ModData;
        global::OpenRA.Manifest v85 = v84.Manifest;
        global::OpenRA.ModMetadata v86 = v85.Metadata;
        l1 = v86;
        global::OpenRA.ModMetadata v87 = l1;
        string v88 = __cil_callvirt_06000265(v87);
        int v89 = __cil_bool_load(System.String.IsNullOrEmpty(v88));
        if (v89 != 0) {
            goto IL_0289;
        } else {
            goto IL_0274;
        }
        IL_0274: ;
        global::OpenRA.Renderer v90 = OpenRA.Game.Renderer;
        global::OpenRA.IPlatformWindow v91 = __cil_callvirt_06000500(v90);
        global::OpenRA.ModMetadata v92 = l1;
        string v93 = __cil_callvirt_06000265(v92);
        __cil_callvirt_060001D1(v91, v93);
        goto IL_0289;
        IL_0289: ;
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v94 = OpenRA.Support.PerfHistory.Items;
        string v95 = __cil_ldstr_70001728("render");
        global::OpenRA.Support.PerfItem v96 = v94.get_Item(v95);
        int v97 = 0;
        v96.HasNormalTick = __cil_bool_store(v97);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v98 = OpenRA.Support.PerfHistory.Items;
        string v99 = __cil_ldstr_70001736("batches");
        global::OpenRA.Support.PerfItem v100 = v98.get_Item(v99);
        int v101 = 0;
        v100.HasNormalTick = __cil_bool_store(v101);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v102 = OpenRA.Support.PerfHistory.Items;
        string v103 = __cil_ldstr_70001746("render_world");
        global::OpenRA.Support.PerfItem v104 = v102.get_Item(v103);
        int v105 = 0;
        v104.HasNormalTick = __cil_bool_store(v105);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v106 = OpenRA.Support.PerfHistory.Items;
        string v107 = __cil_ldstr_70001760("render_widgets");
        global::OpenRA.Support.PerfItem v108 = v106.get_Item(v107);
        int v109 = 0;
        v108.HasNormalTick = __cil_bool_store(v109);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v110 = OpenRA.Support.PerfHistory.Items;
        string v111 = __cil_ldstr_7000177E("render_flip");
        global::OpenRA.Support.PerfItem v112 = v110.get_Item(v111);
        int v113 = 0;
        v112.HasNormalTick = __cil_bool_store(v113);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v114 = OpenRA.Support.PerfHistory.Items;
        string v115 = __cil_ldstr_70001796("terrain_lighting");
        global::OpenRA.Support.PerfItem v116 = v114.get_Item(v115);
        int v117 = 0;
        v116.HasNormalTick = __cil_bool_store(v117);
        OpenRA.Game.JoinLocal();
        global::OpenRA.ModData v118 = OpenRA.Game.ModData;
        global::OpenRA.ILoadScreen v119 = __cil_callvirt_0600040C(v118);
        global::OpenRA.Arguments v120 = args;
        __cil_callvirt_0600041F(v119, v120);
        return;
    }

    public static void LoadEditor(string mapUid)
    {
        // enum storage token=0x020000C9 alias=__cil_enum_020000C9 underlying=int: global::@OpenRA.@WorldType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Game.JoinLocal();
        OpenRA.Game.StartGame(mapUid, unchecked((__cil_enum_020000C9)(2)));
        return;
    }

    public static void LoadShellMap()
    {
        // enum storage token=0x020000C9 alias=__cil_enum_020000C9 underlying=int: global::@OpenRA.@WorldType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        OpenRA.Support.PerfTimer l1 = default;
        IL_0000: ;
        string v0 = OpenRA.Game.ChooseShellmap();
        l0 = v0;
        string v1 = __cil_ldstr_700017B8("StartGame");
        __cil_F v2 = __cil_ldc_r4_bits(0x00000000u);
        global::OpenRA.Support.PerfTimer v3 = __cil_newobj_060007B3(v1, v2);
        l1 = v3;
        try {
            IL_0016: ;
            string v4 = l0;
            int v5 = 1;
            OpenRA.Game.StartGame(v4, unchecked((__cil_enum_020000C9)(v5)));
            __cil_type_01000072 v6 = OpenRA.Game.OnShellmapLoaded;
            v6.Invoke();
            goto IL_0033;
        }
        finally {
            IL_0029: ;
            global::OpenRA.Support.PerfTimer v7 = l1;
            if (v7 is null) {
                goto IL_0032;
            } else {
                goto IL_002C;
            }
            IL_002C: ;
            global::OpenRA.Support.PerfTimer v8 = l1;
            __cil_callvirt_0A000017(v8);
            goto IL_0032;
            IL_0032: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0033: ;
        return;
    }

    private static string ChooseShellmap()
    {
        // structural signature __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd bytes=15128085010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba bytes=151280C9021281D002: class [System.Runtime]System.Func`2<class OpenRA.MapPreview, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d bytes=15128085011281D0: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.MapPreview>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a bytes=151280C9021281D00E: class [System.Runtime]System.Func`2<class OpenRA.MapPreview, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string l1 = default;
        OpenRA.MapCache s1_0 = default;
        __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba s1_1 = default;
        OpenRA.MapCache s2_0 = default;
        __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba s2_1 = default;
        __cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d s3_0 = default;
        __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a s3_1 = default;
        __cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d s4_0 = default;
        __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a s4_1 = default;
        global::OpenRA.ModData v0 = OpenRA.Game.ModData;
        global::OpenRA.MapCache v1 = v0.MapCache;
        __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba v2 = OpenRA.Game.__name_3C3E63.__il_field_0400098B;
        if (v2 is not null) {
            OpenRA.MapCache e0_2_0 = v1;
            __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba e0_2_1 = v2;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_0029;
        } else {
            OpenRA.MapCache e0_1_0 = v1;
            __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba e0_1_1 = v2;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_0012;
        }
        IL_0012: ;
        global::OpenRA.Game.__name_3C3E63 v3 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v4 = __cil_ldftn_06000FB3;
        __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba v5 = __cil_newobj_0A000244(v3, v4);
        OpenRA.Game.__name_3C3E63.__il_field_0400098B = v5;
        OpenRA.MapCache e1_2_0 = s1_0;
        __cil_ref_43ce5b00ba9b5cc796da3b8193555432d8c425ba e1_2_1 = v5;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        IL_0029: ;
        __cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d v6 = __cil_methodspec_call_2B00005A(((__cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d)(s2_0)), s2_1);
        __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a v7 = OpenRA.Game.__name_3C3E63.__il_field_0400098C;
        if (v7 is not null) {
            __cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d e2_4_0 = v6;
            __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a e2_4_1 = v7;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_004D;
        } else {
            __cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d e2_3_0 = v6;
            __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a e2_3_1 = v7;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_0036;
        }
        IL_0036: ;
        global::OpenRA.Game.__name_3C3E63 v8 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v9 = __cil_ldftn_06000FB4;
        __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a v10 = __cil_newobj_0A000245(v8, v9);
        OpenRA.Game.__name_3C3E63.__il_field_0400098C = v10;
        __cil_ref_8fa9b7267307344d9d087d3881982f5e637fd92d e3_4_0 = s3_0;
        __cil_ref_819c7429caf822d9c91a9c24e861ae43127e1b7a e3_4_1 = v10;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        IL_004D: ;
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd v11 = __cil_methodspec_call_2B00005B(s4_0, s4_1);
        global::OpenRA.Support.MersenneTwister v13 = OpenRA.Game.CosmeticRandom;
        string v14 = __cil_methodspec_call_2B00005C(v11, v13);
        l1 = v14;
        string v15 = l1;
        if (v15 is not null) {
            goto IL_006D;
        } else {
            goto IL_0062;
        }
        IL_0062: ;
        string v16 = __cil_ldstr_700017CC("No valid shellmaps available");
        global::System.IO.InvalidDataException v17 = __cil_newobj_0A000078(v16);
        throw v17;
        IL_006D: ;
        string v18 = l1;
        return v18;
    }

    public static void SwitchToExternalMod(OpenRA.ExternalMod mod, string[] launchArguments = null, System.Action onFailed = null)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 40, 00, 00, 04, 0A, 03, 2D, 0A, 02, 7B, 41, 00, 00, 04, 0D, 09, 2B, 0C, 02, 7B, 41, 00]
        // .code-bytes IL_0018: [00, 04, 03, 28, 5D, 00, 00, 2B, 0B, 7E, 6A, 00, 00, 04, 2C, 1C, 7E, 6A, 00, 00, 04, 0A, 17, 8D]
        // .code-bytes IL_0030: [FE, 00, 00, 01, 25, 16, 02, 7B, 40, 00, 00, 04, A2, 07, 28, 27, 00, 00, 2B, 0B, 06, 07, 7E, 8D]
        // .code-bytes IL_0048: [09, 00, 04, 25, 2D, 17, 26, 7E, 84, 09, 00, 04, FE, 06, B5, 0F, 00, 06, 73, 9F, 01, 00, 0A, 25]
        // .code-bytes IL_0060: [80, 8D, 09, 00, 04, 28, 3E, 00, 00, 2B, 72, F5, 02, 00, 70, 28, 1F, 00, 00, 2B, 28, 46, 02, 00]
        // .code-bytes IL_0078: [0A, 0C, 08, 2C, 08, 08, 6F, 47, 02, 00, 0A, 2C, 08, 04, 6F, 31, 02, 00, 0A, 2B, 0B, 08, 6F, 48]
        // .code-bytes IL_0090: [02, 00, 0A, 28, 8C, 01, 00, 06, DE, 34, 13, 04, 72, 1E, 06, 00, 70, 72, 06, 18, 00, 70, 28, C4]
        // .code-bytes IL_00A8: [05, 00, 06, 72, 1E, 06, 00, 70, 72, 4A, 18, 00, 70, 11, 04, 6F, B3, 01, 00, 0A, 28, 7B, 00, 00]
        // .code-bytes IL_00C0: [0A, 28, C4, 05, 00, 06, 04, 6F, 31, 02, 00, 0A, DE, 00, 2A]
        // .local [0] string
        // .local [1] class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>
        // .local [2] class [System.Diagnostics.Process]System.Diagnostics.Process
        // .local [3] class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>
        // .local [4] class [System.Runtime]System.Exception
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x04000040 OpenRA.ExternalMod::LaunchPath
        // IL_0006: stloc.0 0
        // IL_0007: ldarg.1 1
        // IL_0008: brtrue.s IL_0014
        // IL_000A: ldarg.0 0
        // IL_000B: ldfld 0x04000041 OpenRA.ExternalMod::LaunchArgs
        // IL_0010: stloc.3 3
        // IL_0011: ldloc.3 3
        // IL_0012: br.s IL_0020
        // IL_0014: ldarg.0 0
        // IL_0015: ldfld 0x04000041 OpenRA.ExternalMod::LaunchArgs
        // IL_001A: ldarg.1 1
        // IL_001B: call 0x2B00005D OpenRA.Exts::Append<string>
        // IL_0020: stloc.1 1
        // IL_0021: ldsfld 0x0400006A OpenRA.Game::modLaunchWrapper
        // IL_0026: brfalse.s IL_0044
        // IL_0028: ldsfld 0x0400006A OpenRA.Game::modLaunchWrapper
        // IL_002D: stloc.0 0
        // IL_002E: ldc.i4.1 1
        // IL_002F: newarr 0x010000FE [System.Runtime]System.String
        // IL_0034: dup 
        // IL_0035: ldc.i4.0 0
        // IL_0036: ldarg.0 0
        // IL_0037: ldfld 0x04000040 OpenRA.ExternalMod::LaunchPath
        // IL_003C: stelem.ref 
        // IL_003D: ldloc.1 1
        // IL_003E: call 0x2B000027 [System.Linq]System.Linq.Enumerable::Concat<string>
        // IL_0043: stloc.1 1
        // IL_0044: ldloc.0 0
        // IL_0045: ldloc.1 1
        // IL_0046: ldsfld 0x0400098D OpenRA.Game/<>c::<>9__83_0
        // IL_004B: dup 
        // IL_004C: brtrue.s IL_0065
        // IL_004E: pop 
        // IL_004F: ldsfld 0x04000984 OpenRA.Game/<>c::<>9
        // IL_0054: ldftn 0x06000FB5 OpenRA.Game/<>c::<SwitchToExternalMod>b__83_0
        // IL_005A: newobj 0x0A00019F class [System.Runtime]System.Func`2<string, string>::.ctor
        // IL_005F: dup 
        // IL_0060: stsfld 0x0400098D OpenRA.Game/<>c::<>9__83_0
        // IL_0065: call 0x2B00003E [System.Linq]System.Linq.Enumerable::Select<string, string>
        // IL_006A: ldstr 0x700002F5 [32] utf16-bytes=[20, 00] terminal-flag=Some(0)
        // IL_006F: call 0x2B00001F OpenRA.Exts::JoinWith<string>
        // IL_0074: call 0x0A000246 [System.Diagnostics.Process]System.Diagnostics.Process::Start
        // IL_0079: stloc.2 2
        // IL_007A: ldloc.2 2
        // IL_007B: brfalse.s IL_0085
        // IL_007D: ldloc.2 2
        // IL_007E: callvirt 0x0A000247 [System.Diagnostics.Process]System.Diagnostics.Process::get_HasExited
        // IL_0083: brfalse.s IL_008D
        // IL_0085: ldarg.2 2
        // IL_0086: callvirt 0x0A000231 [System.Runtime]System.Action::Invoke
        // IL_008B: br.s IL_0098
        // IL_008D: ldloc.2 2
        // IL_008E: callvirt 0x0A000248 [System.Diagnostics.Process]System.Diagnostics.Process::Close
        // IL_0093: call 0x0600018C OpenRA.Game::Exit
        // IL_0098: leave.s IL_00CE
        // IL_009A: stloc.s 4
        // IL_009C: ldstr 0x7000061E [100, 101, 98, 117, 103] utf16-bytes=[64, 00, 65, 00, 62, 00, 75, 00, 67, 00] terminal-flag=Some(0)
        // IL_00A1: ldstr 0x70001806 [70, 97, 105, 108, 101, 100, 32, 116, 111, 32, 115, 119, 105, 116, 99, 104, 32, 116, 111, 32, 101, 120, 116, 101, 114, 110, 97, 108, 32, 109, 111, 100, 46] utf16-bytes=[46, 00, 61, 00, 69, 00, 6C, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 73, 00, 77, 00, 69, 00, 74, 00, 63, 00, 68, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 65, 00, 78, 00, 74, 00, 65, 00, 72, 00, 6E, 00, 61, 00, 6C, 00, 20, 00, 6D, 00, 6F, 00, 64, 00, 2E, 00] terminal-flag=Some(0)
        // IL_00A6: call 0x060005C4 OpenRA.Log::Write
        // IL_00AB: ldstr 0x7000061E [100, 101, 98, 117, 103] utf16-bytes=[64, 00, 65, 00, 62, 00, 75, 00, 67, 00] terminal-flag=Some(0)
        // IL_00B0: ldstr 0x7000184A [69, 114, 114, 111, 114, 32, 119, 97, 115, 58, 32] utf16-bytes=[45, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_00B5: ldloc.s 4
        // IL_00B7: callvirt 0x0A0001B3 [System.Runtime]System.Exception::get_Message
        // IL_00BC: call 0x0A00007B [System.Runtime]System.String::Concat
        // IL_00C1: call 0x060005C4 OpenRA.Log::Write
        // IL_00C6: ldarg.2 2
        // IL_00C7: callvirt 0x0A000231 [System.Runtime]System.Action::Invoke
        // IL_00CC: leave.s IL_00CE
        // IL_00CE: ret 
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[58])), try_offset: 0, try_length: 154, handler_offset: 154, handler_length: 52, raw_flags: 0 }
        // .try IL_0000..IL_009A catch 0x0100003A [System.Runtime]System.Exception IL_009A..IL_00CE
    }

    public static void add_OnQuit(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.OnQuit;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Combine(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.OnQuit;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void remove_OnQuit(System.Action value)
    {
        __cil_type_01000072 l0 = default;
        __cil_type_01000072 l1 = default;
        __cil_type_01000072 l2 = default;
        IL_0000: ;
        __cil_type_01000072 v0 = OpenRA.Game.OnQuit;
        l0 = v0;
        goto IL_0006;
        IL_0006: ;
        __cil_type_01000072 v1 = l0;
        l1 = v1;
        __cil_type_01000072 v2 = l1;
        __cil_type_01000072 v3 = value;
        __cil_type_01000131 v4 = System.Delegate.Remove(((__cil_type_01000131)(v2)), ((__cil_type_01000131)(v3)));
        __cil_type_01000072 v5 = ((__cil_type_01000072)(object)v4);
        l2 = v5;
        ref __cil_type_01000072 v6 = ref OpenRA.Game.OnQuit;
        __cil_type_01000072 v7 = l2;
        __cil_type_01000072 v8 = l1;
        __cil_type_01000072 v9 = __cil_methodspec_call_2B00004E(ref v6, v7, v8);
        l0 = v9;
        __cil_type_01000072 v10 = l0;
        __cil_type_01000072 v11 = l1;
        if (!System.Object.ReferenceEquals(v10, v11)) {
            goto IL_0006;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        return;
    }

    public static void RunAfterTick(System.Action a)
    {
        global::OpenRA.Primitives.ActionQueue v0 = System.Threading.Volatile.Read(ref OpenRA.Game.delayedActions);
        long v2 = OpenRA.Game.get_RunTime();
        __cil_callvirt_06000A08(v0, a, v2);
        return;
    }

    public static void RunAfterDelay(int delayMilliseconds, System.Action a)
    {
        global::OpenRA.Primitives.ActionQueue v0 = System.Threading.Volatile.Read(ref OpenRA.Game.delayedActions);
        long v2 = OpenRA.Game.get_RunTime();
        long v4 = unchecked((long)(delayMilliseconds));
        long v5 = unchecked(v2 + v4);
        __cil_callvirt_06000A08(v0, a, v5);
        return;
    }

    private static void TakeScreenshotInner()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Support.PerfTimer l0 = default;
        OpenRA.ModMetadata l1 = default;
        string l2 = default;
        string l3 = default;
        string l4 = default;
        IL_0000: ;
        string v0 = __cil_ldstr_70001862("Renderer.SaveScreenshot");
        __cil_F v1 = __cil_ldc_r4_bits(0x00000000u);
        global::OpenRA.Support.PerfTimer v2 = __cil_newobj_060007B3(v0, v1);
        l0 = v2;
        try {
            IL_0010: ;
            global::OpenRA.ModData v3 = OpenRA.Game.ModData;
            global::OpenRA.Manifest v4 = v3.Manifest;
            global::OpenRA.ModMetadata v5 = v4.Metadata;
            l1 = v5;
            string v6 = OpenRA.Platform.get_SupportDir();
            string v7 = __cil_ldstr_70001892("Screenshots");
            global::OpenRA.ModData v8 = OpenRA.Game.ModData;
            global::OpenRA.Manifest v9 = v8.Manifest;
            string v10 = v9.Id;
            global::OpenRA.ModMetadata v11 = l1;
            string v12 = v11.Version;
            string v13 = System.IO.Path.Combine(v6, v7, v10, v12);
            l2 = v13;
            string v14 = l2;
            __cil_type_0100008B v15 = System.IO.Directory.CreateDirectory(v14);
            int v16 = 1;
            string v17 = __cil_ldstr_700005EE("");
            string v18 = OpenRA.Game.TimestampedFilename(__cil_bool_store(v16), v17);
            l3 = v18;
            string v19 = l2;
            string v20 = l3;
            string v21 = __cil_ldstr_700018AA(".png");
            string v22 = System.String.Concat(v20, v21);
            string v23 = System.IO.Path.Combine(v19, v22);
            l4 = v23;
            string v24 = __cil_ldstr_7000061E("debug");
            string v25 = __cil_ldstr_700018B4("Taking screenshot ");
            string v26 = l4;
            string v27 = System.String.Concat(v25, v26);
            OpenRA.Log.Write(v24, v27);
            global::OpenRA.Renderer v28 = OpenRA.Game.Renderer;
            string v29 = l4;
            __cil_callvirt_0600052C(v28, v29);
            string v30 = __cil_ldstr_700018DA("notification-saved-screenshot");
            int v31 = 2;
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v32 = __cil_newarr_01000012(v31);
            int v33 = 0;
            string v34 = __cil_ldstr_70001916("filename");
            v32[v33] = v34;
            int v35 = 1;
            string v36 = l3;
            v32[v35] = v36;
            string v37 = OpenRA.FluentProvider.GetMessage(v30, v32);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v38 = __cil_methodspec_call_2B00005E();
            OpenRA.TextNotificationsManager.Debug(v37, v38);
            goto IL_00BF;
        }
        finally {
            IL_00B5: ;
            global::OpenRA.Support.PerfTimer v39 = l0;
            if (v39 is null) {
                goto IL_00BE;
            } else {
                goto IL_00B8;
            }
            IL_00B8: ;
            global::OpenRA.Support.PerfTimer v40 = l0;
            __cil_callvirt_0A000017(v40);
            goto IL_00BE;
            IL_00BE: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00BF: ;
        return;
    }

    private static void InnerLogicTick(OpenRA.Network.OrderManager orderManager)
    {
        // structural signature __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b bytes=1183AC: valuetype OpenRA.Support.PerfSample; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 l0 = default;
        long l1 = default;
        __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b l2 = default;
        OpenRA.Support.Benchmark s18_0 = default;
        OpenRA.Support.Benchmark s19_0 = default;
        IL_0000: ;
        global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v0 = __cil_newobj_06000FC1();
        l0 = v0;
        long v1 = OpenRA.Game.get_RunTime();
        l1 = v1;
        global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v2 = l0;
        global::OpenRA.Network.OrderManager v3 = orderManager;
        global::OpenRA.World v4 = v3.World;
        v2.world = v4;
        global::OpenRA.Network.TickTime v5 = OpenRA.Widgets.Ui.LastTickTime;
        long v6 = l1;
        int v7 = __cil_bool_load(__cil_callvirt_06000CD5(v5, v6));
        if (v7 == 0) {
            goto IL_0051;
        } else {
            goto IL_0025;
        }
        IL_0025: ;
        global::OpenRA.Network.TickTime v8 = OpenRA.Widgets.Ui.LastTickTime;
        long v9 = l1;
        __cil_callvirt_06000CD6(v8, v9);
        global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v10 = l0;
        global::OpenRA.World v11 = v10.world;
        nint v12 = __cil_ldftn_0600070C;
        __cil_type_01000072 v13 = __cil_newobj_0A000232(null, v12);
        OpenRA.Sync.RunUnsynced(v11, v13);
        global::OpenRA.Graphics.CursorManager v14 = OpenRA.Game.Cursor;
        __cil_callvirt_06000D24(v14);
        goto IL_0051;
        IL_0051: ;
        global::OpenRA.Network.OrderManager v15 = orderManager;
        global::OpenRA.Network.TickTime v16 = v15.LastTickTime;
        long v17 = l1;
        int v18 = __cil_bool_load(__cil_callvirt_06000CD5(v16, v17));
        if (v18 == 0) {
            goto IL_013A;
        } else {
            goto IL_0062;
        }
        IL_0062: ;
        global::OpenRA.Network.OrderManager v19 = orderManager;
        int v20 = __cil_bool_load(__cil_callvirt_06000C98(v19));
        if (v20 == 0) {
            goto IL_0077;
        } else {
            goto IL_006A;
        }
        IL_006A: ;
        global::OpenRA.Network.OrderManager v21 = orderManager;
        int v22 = v21.LocalFrameNumber;
        if (v22 != 0) {
            goto IL_0077;
        } else {
            goto IL_0072;
        }
        IL_0072: ;
        OpenRA.Support.PerfHistory.Reset();
        goto IL_0077;
        IL_0077: ;
        ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v23 = ref l2;
        string v24 = __cil_ldstr_70001928("tick_time");
        __cil_value_ctor_060007AE(ref v23, v24);
        try {
            IL_0083: ;
            global::OpenRA.Network.OrderManager v25 = orderManager;
            global::OpenRA.Network.TickTime v26 = v25.LastTickTime;
            long v27 = l1;
            __cil_callvirt_06000CD6(v26, v27);
            global::OpenRA.Sound v28 = OpenRA.Game.Sound;
            __cil_callvirt_06000568(v28);
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v29 = l0;
            global::OpenRA.World v30 = v29.world;
            global::OpenRA.Network.OrderManager v31 = orderManager;
            nint v32 = __cil_ldftn_06000CAD;
            __cil_type_01000072 v33 = __cil_newobj_0A000232(v31, v32);
            OpenRA.Sync.RunUnsynced(v30, v33);
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v34 = l0;
            global::OpenRA.World v35 = v34.world;
            if (v35 is not null) {
                goto IL_00C7;
            } else {
                goto IL_00B8;
            }
            IL_00B8: ;
            global::OpenRA.Network.OrderManager v36 = orderManager;
            int v37 = __cil_bool_load(__cil_callvirt_06000C98(v36));
            if (v37 == 0) {
                goto IL_00C5;
            } else {
                goto IL_00C0;
            }
            IL_00C0: ;
            OpenRA.Support.PerfHistory.Reset();
            goto IL_00C5;
            IL_00C5: ;
            goto IL_013A;
            IL_00C7: ;
            global::OpenRA.Network.OrderManager v38 = orderManager;
            int v39 = __cil_bool_load(__cil_callvirt_06000CAE(v38));
            if (v39 == 0) {
                goto IL_00F6;
            } else {
                goto IL_00CF;
            }
            IL_00CF: ;
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v40 = l0;
            global::OpenRA.World v41 = v40.world;
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v42 = l0;
            nint v43 = __cil_ldftn_06000FC2;
            __cil_type_01000072 v44 = __cil_newobj_0A000232(v42, v43);
            OpenRA.Sync.RunUnsynced(v41, v44);
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v45 = l0;
            global::OpenRA.World v46 = v45.world;
            __cil_callvirt_06000689(v46);
            OpenRA.Support.PerfHistory.Tick();
            goto IL_00F6;
            IL_00F6: ;
            global::OpenRA.Network.OrderManager v47 = orderManager;
            int v48 = v47.LocalFrameNumber;
            int v49 = 0;
            if (v48 <= v49) {
                goto IL_0116;
            } else {
                goto IL_00FF;
            }
            IL_00FF: ;
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v50 = l0;
            global::OpenRA.World v51 = v50.world;
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737339325F30 v52 = l0;
            nint v53 = __cil_ldftn_06000FC3;
            __cil_type_01000072 v54 = __cil_newobj_0A000232(v52, v53);
            OpenRA.Sync.RunUnsynced(v51, v54);
            goto IL_0116;
            IL_0116: ;
            goto IL_0126;
        }
        finally {
            IL_0118: ;
            ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v55 = ref l2;
            __cil_constrained_020000EB_0A000017(ref v55);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0126: ;
        global::OpenRA.Support.Benchmark v56 = OpenRA.Game.benchmark;
        if (v56 is not null) {
            OpenRA.Support.Benchmark e17_19_0 = v56;
            s19_0 = e17_19_0;
            goto IL_0130;
        } else {
            OpenRA.Support.Benchmark e17_18_0 = v56;
            s18_0 = e17_18_0;
            goto IL_012E;
        }
        IL_012E: ;
        return;
        IL_0130: ;
        int v57 = OpenRA.Game.get_LocalTick();
        __cil_direct_06000792(s19_0, v57);
        goto IL_013A;
        IL_013A: ;
        return;
    }

    private static void LogicTick()
    {
        // structural signature __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec bytes=151281CD031287800E128744: class [System.Runtime]System.Action`3<class OpenRA.Network.OrderManager, string, class OpenRA.Network.NetworkConnection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001CE alias=__cil_enum_020001CE underlying=int: global::@OpenRA.@Network.@ConnectionState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Network.NetworkConnection l0 = default;
        OpenRA.Game.PerformDelayedActions();
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.IConnection v1 = __cil_callvirt_06000C99(v0);
        global::OpenRA.Network.NetworkConnection v2 = ((object)v1 as OpenRA.Network.NetworkConnection);
        l0 = v2;
        global::OpenRA.Network.NetworkConnection v3 = l0;
        if (v3 is null) {
            goto IL_0041;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::OpenRA.Network.NetworkConnection v4 = l0;
        int v5 = unchecked((int)(__cil_callvirt_06000C3C(v4)));
        int v6 = unchecked((int)(OpenRA.Game.lastConnectionState));
        if (v5 == v6) {
            goto IL_0041;
        } else {
            goto IL_0025;
        }
        IL_0025: ;
        global::OpenRA.Network.NetworkConnection v7 = l0;
        int v8 = unchecked((int)(__cil_callvirt_06000C3C(v7)));
        OpenRA.Game.lastConnectionState = unchecked((__cil_enum_020001CE)(v8));
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v9 = OpenRA.Game.ConnectionStateChanged;
        global::OpenRA.Network.OrderManager v10 = OpenRA.Game.OrderManager;
        global::OpenRA.Network.NetworkConnection v11 = l0;
        __cil_callvirt_0A00022B(v9, v10, ((string)(null)), v11);
        IL_0041: ;
        global::OpenRA.Network.OrderManager v12 = OpenRA.Game.OrderManager;
        OpenRA.Game.InnerLogicTick(v12);
        global::OpenRA.Graphics.WorldRenderer v13 = OpenRA.Game.worldRenderer;
        if (v13 is null) {
            goto IL_007C;
        } else {
            goto IL_0052;
        }
        IL_0052: ;
        global::OpenRA.Network.OrderManager v14 = OpenRA.Game.OrderManager;
        global::OpenRA.World v15 = v14.World;
        global::OpenRA.Graphics.WorldRenderer v16 = OpenRA.Game.worldRenderer;
        global::OpenRA.World v17 = v16.World;
        if (System.Object.ReferenceEquals(v15, v17)) {
            goto IL_007C;
        } else {
            goto IL_0068;
        }
        IL_0068: ;
        global::OpenRA.Graphics.WorldRenderer v18 = OpenRA.Game.worldRenderer;
        global::OpenRA.World v19 = v18.World;
        global::OpenRA.Network.OrderManager v20 = v19.OrderManager;
        OpenRA.Game.InnerLogicTick(v20);
        IL_007C: ;
        return;
    }

    public static void PerformDelayedActions()
    {
        global::OpenRA.Primitives.ActionQueue v0 = System.Threading.Volatile.Read(ref OpenRA.Game.delayedActions);
        long v1 = OpenRA.Game.get_RunTime();
        __cil_callvirt_06000A09(v0, v1);
        return;
    }

    public static void TakeScreenshot()
    {
        OpenRA.Game.takeScreenshot = __cil_bool_store(1);
        return;
    }

    private static void RenderTick()
    {
        // structural signature __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c bytes=151286CC020E1283A8: class OpenRA.Primitives.Cache`2<string, class OpenRA.Support.PerfItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b bytes=1183AC: valuetype OpenRA.Support.PerfSample; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d bytes=118338: valuetype OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b l0 = default;
        __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b l1 = default;
        __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b l2 = default;
        __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b l3 = default;
        __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b l4 = default;
        OpenRA.Graphics.WorldRenderer s3_0 = default;
        OpenRA.Graphics.WorldRenderer s4_0 = default;
        OpenRA.Graphics.WorldRenderer s9_0 = default;
        OpenRA.Graphics.WorldRenderer s10_0 = default;
        OpenRA.Graphics.CursorManager s26_0 = default;
        string s26_1 = default;
        OpenRA.Graphics.CursorManager s27_0 = default;
        string s27_1 = default;
        IL_0000: ;
        ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v0 = ref l0;
        string v1 = __cil_ldstr_70001728("render");
        __cil_value_ctor_060007AE(ref v0, v1);
        try {
            IL_000C: ;
            int v2 = OpenRA.Game.RenderFrame;
            int v3 = 1;
            int v4 = unchecked(v2 + v3);
            OpenRA.Game.RenderFrame = v4;
            string v5 = __cil_ldstr_7000193C("render_prepare");
            __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v6 = __cil_value_newobj_060007AE(v5);
            l1 = v6;
            try {
                IL_0023: ;
                global::OpenRA.Graphics.WorldRenderer v7 = OpenRA.Game.worldRenderer;
                if (v7 is not null) {
                    OpenRA.Graphics.WorldRenderer e2_4_0 = v7;
                    s4_0 = e2_4_0;
                    goto IL_002E;
                } else {
                    OpenRA.Graphics.WorldRenderer e2_3_0 = v7;
                    s3_0 = e2_3_0;
                    goto IL_002B;
                }
                IL_002B: ;
                goto IL_0033;
                IL_002E: ;
                __cil_direct_06000EAA(s4_0);
                goto IL_0033;
                IL_0033: ;
                global::OpenRA.Graphics.WorldRenderer v8 = OpenRA.Game.worldRenderer;
                if (v8 is null) {
                    goto IL_0064;
                } else {
                    goto IL_003A;
                }
                IL_003A: ;
                global::OpenRA.Graphics.WorldRenderer v9 = OpenRA.Game.worldRenderer;
                global::OpenRA.World v10 = v9.World;
                int v11 = __cil_bool_load(__cil_callvirt_06000663(v10));
                if (v11 != 0) {
                    goto IL_0064;
                } else {
                    goto IL_004B;
                }
                IL_004B: ;
                global::OpenRA.Graphics.WorldRenderer v12 = OpenRA.Game.worldRenderer;
                global::OpenRA.Graphics.Viewport v13 = __cil_callvirt_06000EA6(v12);
                __cil_callvirt_06000E97(v13);
                global::OpenRA.Graphics.WorldRenderer v14 = OpenRA.Game.worldRenderer;
                __cil_callvirt_06000EB5(v14);
                goto IL_0064;
                IL_0064: ;
                OpenRA.Widgets.Ui.PrepareRenderables();
                global::OpenRA.Graphics.WorldRenderer v15 = OpenRA.Game.worldRenderer;
                if (v15 is not null) {
                    OpenRA.Graphics.WorldRenderer e8_10_0 = v15;
                    s10_0 = e8_10_0;
                    goto IL_0074;
                } else {
                    OpenRA.Graphics.WorldRenderer e8_9_0 = v15;
                    s9_0 = e8_9_0;
                    goto IL_0071;
                }
                IL_0071: ;
                goto IL_0089;
                IL_0074: ;
                __cil_direct_06000EAB(s10_0);
                goto IL_0089;
            }
            finally {
                IL_007B: ;
                ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v16 = ref l1;
                __cil_constrained_020000EB_0A000017(ref v16);
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_0089: ;
            global::OpenRA.Graphics.WorldRenderer v17 = OpenRA.Game.worldRenderer;
            if (v17 is null) {
                goto IL_00F8;
            } else {
                goto IL_0090;
            }
            IL_0090: ;
            global::OpenRA.Graphics.WorldRenderer v18 = OpenRA.Game.worldRenderer;
            global::OpenRA.World v19 = v18.World;
            int v20 = __cil_bool_load(__cil_callvirt_06000663(v19));
            if (v20 != 0) {
                goto IL_00F8;
            } else {
                goto IL_00A1;
            }
            IL_00A1: ;
            global::OpenRA.Renderer v21 = OpenRA.Game.Renderer;
            global::OpenRA.Graphics.WorldRenderer v22 = OpenRA.Game.worldRenderer;
            global::OpenRA.Graphics.Viewport v23 = __cil_callvirt_06000EA6(v22);
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v24 = __cil_callvirt_06000E88(v23);
            __cil_callvirt_06000510(v21, v24);
            global::OpenRA.Sound v25 = OpenRA.Game.Sound;
            global::OpenRA.Graphics.WorldRenderer v26 = OpenRA.Game.worldRenderer;
            global::OpenRA.Graphics.Viewport v27 = __cil_callvirt_06000EA6(v26);
            __cil_value_84dc388b92a5c851cb00ea64a31ed9760897cd4d v28 = __cil_callvirt_06000E87(v27);
            __cil_callvirt_0600054C(v25, v28);
            string v29 = __cil_ldstr_70001746("render_world");
            __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v30 = __cil_value_newobj_060007AE(v29);
            l2 = v30;
            try {
                IL_00DE: ;
                global::OpenRA.Graphics.WorldRenderer v31 = OpenRA.Game.worldRenderer;
                __cil_callvirt_06000EB6(v31);
                goto IL_00F8;
            }
            finally {
                IL_00EA: ;
                ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v32 = ref l2;
                __cil_constrained_020000EB_0A000017(ref v32);
                goto __cil_finally_end_1;
                __cil_finally_end_1: ;
            }
            IL_00F8: ;
            string v33 = __cil_ldstr_70001760("render_widgets");
            __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v34 = __cil_value_newobj_060007AE(v33);
            l3 = v34;
            try {
                IL_0103: ;
                global::OpenRA.Renderer v35 = OpenRA.Game.Renderer;
                __cil_callvirt_06000511(v35);
                global::OpenRA.Graphics.WorldRenderer v36 = OpenRA.Game.worldRenderer;
                if (v36 is null) {
                    goto IL_012F;
                } else {
                    goto IL_0114;
                }
                IL_0114: ;
                global::OpenRA.Graphics.WorldRenderer v37 = OpenRA.Game.worldRenderer;
                global::OpenRA.World v38 = v37.World;
                int v39 = __cil_bool_load(__cil_callvirt_06000663(v38));
                if (v39 != 0) {
                    goto IL_012F;
                } else {
                    goto IL_0125;
                }
                IL_0125: ;
                global::OpenRA.Graphics.WorldRenderer v40 = OpenRA.Game.worldRenderer;
                __cil_callvirt_06000EB8(v40);
                goto IL_012F;
                IL_012F: ;
                OpenRA.Widgets.Ui.Draw();
                global::OpenRA.ModData v41 = OpenRA.Game.ModData;
                if (v41 is null) {
                    goto IL_018C;
                } else {
                    goto IL_013B;
                }
                IL_013B: ;
                global::OpenRA.ModData v42 = OpenRA.Game.ModData;
                global::OpenRA.Graphics.CursorProvider v43 = __cil_callvirt_0600040D(v42);
                if (v43 is null) {
                    goto IL_018C;
                } else {
                    goto IL_0147;
                }
                IL_0147: ;
                int v44 = __cil_bool_load(OpenRA.Game.HideCursor);
                if (v44 == 0) {
                    goto IL_015B;
                } else {
                    goto IL_014E;
                }
                IL_014E: ;
                global::OpenRA.Graphics.CursorManager v45 = OpenRA.Game.Cursor;
                __cil_callvirt_06000D23(v45, ((string)(null)));
                goto IL_019C;
                IL_015B: ;
                global::OpenRA.Graphics.CursorManager v46 = OpenRA.Game.Cursor;
                global::OpenRA.Widgets.Widget v47 = OpenRA.Widgets.Ui.Root;
                __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v48 = OpenRA.Graphics.Viewport.LastMousePos;
                string v49 = __cil_callvirt_06000739(v47, v48);
                if (v49 is not null) {
                    OpenRA.Graphics.CursorManager e25_27_0 = v46;
                    string e25_27_1 = v49;
                    s27_0 = e25_27_0;
                    s27_1 = e25_27_1;
                    goto IL_0178;
                } else {
                    OpenRA.Graphics.CursorManager e25_26_0 = v46;
                    string e25_26_1 = v49;
                    s26_0 = e25_26_0;
                    s26_1 = e25_26_1;
                    goto IL_0172;
                }
                IL_0172: ;
                string v50 = __cil_ldstr_7000195A("default");
                OpenRA.Graphics.CursorManager e26_27_0 = s26_0;
                string e26_27_1 = v50;
                s27_0 = e26_27_0;
                s27_1 = e26_27_1;
                goto IL_0178;
                IL_0178: ;
                __cil_callvirt_06000D23(s27_0, s27_1);
                global::OpenRA.Graphics.CursorManager v51 = OpenRA.Game.Cursor;
                global::OpenRA.Renderer v52 = OpenRA.Game.Renderer;
                __cil_callvirt_06000D26(v51, v52);
                goto IL_018C;
                IL_018C: ;
                goto IL_019C;
            }
            finally {
                IL_018E: ;
                ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v53 = ref l3;
                __cil_constrained_020000EB_0A000017(ref v53);
                goto __cil_finally_end_2;
                __cil_finally_end_2: ;
            }
            IL_019C: ;
            string v54 = __cil_ldstr_7000177E("render_flip");
            __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v55 = __cil_value_newobj_060007AE(v54);
            l4 = v55;
            try {
                IL_01A8: ;
                global::OpenRA.Renderer v56 = OpenRA.Game.Renderer;
                global::OpenRA.Network.OrderManager v57 = OpenRA.Game.OrderManager;
                global::OpenRA.World v58 = v57.World;
                global::OpenRA.DefaultInputHandler v59 = __cil_newobj_06000239(v58);
                __cil_callvirt_06000513(v56, ((OpenRA.IInputHandler)(v59)));
                goto IL_01D1;
            }
            finally {
                IL_01C3: ;
                ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v60 = ref l4;
                __cil_constrained_020000EB_0A000017(ref v60);
                goto __cil_finally_end_3;
                __cil_finally_end_3: ;
            }
            IL_01D1: ;
            int v61 = __cil_bool_load(OpenRA.Game.takeScreenshot);
            if (v61 == 0) {
                goto IL_01E3;
            } else {
                goto IL_01D8;
            }
            IL_01D8: ;
            int v62 = 0;
            OpenRA.Game.takeScreenshot = __cil_bool_store(v62);
            OpenRA.Game.TakeScreenshotInner();
            goto IL_01E3;
            IL_01E3: ;
            goto IL_01F3;
        }
        finally {
            IL_01E5: ;
            ref __cil_value_d28ca3bb0c9840abfabfdb420988991519f8167b v63 = ref l0;
            __cil_constrained_020000EB_0A000017(ref v63);
            goto __cil_finally_end_4;
            __cil_finally_end_4: ;
        }
        IL_01F3: ;
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v64 = OpenRA.Support.PerfHistory.Items;
        string v65 = __cil_ldstr_70001728("render");
        global::OpenRA.Support.PerfItem v66 = v64.get_Item(v65);
        __cil_callvirt_060007A9(v66);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v67 = OpenRA.Support.PerfHistory.Items;
        string v68 = __cil_ldstr_70001736("batches");
        global::OpenRA.Support.PerfItem v69 = v67.get_Item(v68);
        __cil_callvirt_060007A9(v69);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v70 = OpenRA.Support.PerfHistory.Items;
        string v71 = __cil_ldstr_70001746("render_world");
        global::OpenRA.Support.PerfItem v72 = v70.get_Item(v71);
        __cil_callvirt_060007A9(v72);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v73 = OpenRA.Support.PerfHistory.Items;
        string v74 = __cil_ldstr_70001760("render_widgets");
        global::OpenRA.Support.PerfItem v75 = v73.get_Item(v74);
        __cil_callvirt_060007A9(v75);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v76 = OpenRA.Support.PerfHistory.Items;
        string v77 = __cil_ldstr_7000177E("render_flip");
        global::OpenRA.Support.PerfItem v78 = v76.get_Item(v77);
        __cil_callvirt_060007A9(v78);
        __cil_ref_b7e3a9983ee03860c61b90d60745bc7b6dbad24c v79 = OpenRA.Support.PerfHistory.Items;
        string v80 = __cil_ldstr_70001796("terrain_lighting");
        global::OpenRA.Support.PerfItem v81 = v79.get_Item(v80);
        __cil_callvirt_060007A9(v81);
        return;
    }

    private static void Loop()
    {
        // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@OpenRA.@RunStatus; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        long l0 = default;
        long l1 = default;
        long l2 = default;
        bool l3 = default;
        int l4 = default;
        OpenRA.World l5 = default;
        int l6 = default;
        long l7 = default;
        long l8 = default;
        int l9 = default;
        bool l10 = default;
        bool l11 = default;
        bool l12 = default;
        OpenRA.Graphics.WorldRenderer s2_0 = default;
        OpenRA.Graphics.WorldRenderer s3_0 = default;
        OpenRA.World s4_0 = default;
        int s10_0 = default;
        int s15_0 = default;
        int s25_0 = default;
        long v0 = OpenRA.Game.get_RunTime();
        l0 = v0;
        long v1 = OpenRA.Game.get_RunTime();
        l1 = v1;
        long v2 = OpenRA.Game.get_RunTime();
        l2 = v2;
        l3 = __cil_bool_store(0);
        goto IL_01DE;
        IL_0019: ;
        l4 = 40;
        global::OpenRA.Graphics.WorldRenderer v5 = OpenRA.Game.worldRenderer;
        if (v5 is not null) {
            OpenRA.Graphics.WorldRenderer e1_3_0 = v5;
            s3_0 = e1_3_0;
            goto IL_0029;
        } else {
            OpenRA.Graphics.WorldRenderer e1_2_0 = v5;
            s2_0 = e1_2_0;
            goto IL_0025;
        }
        IL_0025: ;
        OpenRA.World e2_4_0 = null;
        s4_0 = e2_4_0;
        goto IL_002E;
        IL_0029: ;
        global::OpenRA.World v6 = s3_0.World;
        OpenRA.World e3_4_0 = v6;
        s4_0 = e3_4_0;
        IL_002E: ;
        l5 = s4_0;
        global::OpenRA.World v7 = l5;
        if (v7 is null) {
            goto IL_0069;
        } else {
            goto IL_0034;
        }
        IL_0034: ;
        global::OpenRA.World v8 = l5;
        int v9 = __cil_bool_load(__cil_callvirt_06000662(v8));
        if (v9 == 0) {
            goto IL_0046;
        } else {
            goto IL_003D;
        }
        IL_003D: ;
        global::OpenRA.World v10 = l5;
        int v11 = v10.ReplayTimestep;
        if (v11 == 0) {
            goto IL_0069;
        } else {
            goto IL_0046;
        }
        IL_0046: ;
        global::OpenRA.World v12 = l5;
        global::OpenRA.Network.OrderManager v13 = OpenRA.Game.OrderManager;
        global::OpenRA.World v14 = v13.World;
        if (System.Object.ReferenceEquals(v12, v14)) {
            goto IL_005D;
        } else {
            goto IL_0054;
        }
        IL_0054: ;
        global::OpenRA.World v15 = l5;
        int v16 = v15.Timestep;
        int e8_10_0 = v16;
        s10_0 = e8_10_0;
        goto IL_0067;
        IL_005D: ;
        global::OpenRA.Network.OrderManager v17 = OpenRA.Game.OrderManager;
        int v18 = __cil_callvirt_06000CA9(v17);
        int e9_10_0 = v18;
        s10_0 = e9_10_0;
        IL_0067: ;
        l4 = s10_0;
        IL_0069: ;
        int v19 = l4;
        l6 = v19;
        global::OpenRA.Settings v20 = OpenRA.Game.Settings;
        global::OpenRA.GraphicSettings v21 = v20.Graphics;
        int v22 = __cil_bool_load(v21.CapFramerateToGameFps);
        if (v22 != 0) {
            goto IL_00BC;
        } else {
            goto IL_007E;
        }
        IL_007E: ;
        global::OpenRA.Settings v23 = OpenRA.Game.Settings;
        global::OpenRA.GraphicSettings v24 = v23.Graphics;
        int v25 = __cil_bool_load(v24.CapFramerate);
        if (v25 != 0) {
            goto IL_0096;
        } else {
            goto IL_008F;
        }
        IL_008F: ;
        int e13_15_0 = 1000;
        s15_0 = e13_15_0;
        goto IL_00B0;
        IL_0096: ;
        global::OpenRA.Settings v27 = OpenRA.Game.Settings;
        global::OpenRA.GraphicSettings v28 = v27.Graphics;
        int v29 = v28.MaxFramerate;
        int v32 = __cil_methodspec_call_2B00005F(v29, 1, 1000);
        int e14_15_0 = v32;
        s15_0 = e14_15_0;
        IL_00B0: ;
        l9 = s15_0;
        int v34 = l9;
        int v35 = unchecked(1000 / v34);
        l6 = v35;
        IL_00BC: ;
        global::OpenRA.Network.OrderManager v36 = OpenRA.Game.OrderManager;
        global::OpenRA.World v37 = v36.World;
        if (v37 is null) {
            goto IL_00E3;
        } else {
            goto IL_00C8;
        }
        IL_00C8: ;
        global::OpenRA.Network.OrderManager v38 = OpenRA.Game.OrderManager;
        global::OpenRA.World v39 = v38.World;
        int v40 = __cil_bool_load(__cil_callvirt_06000663(v39));
        if (v40 == 0) {
            goto IL_00E3;
        } else {
            goto IL_00D9;
        }
        IL_00D9: ;
        l4 = 1;
        l6 = 200;
        IL_00E3: ;
        long v43 = OpenRA.Game.get_RunTime();
        l7 = v43;
        long v44 = l7;
        long v45 = l0;
        long v46 = unchecked(v44 - v45);
        long v48 = unchecked((long)(250));
        if (v46 <= v48) {
            goto IL_00F9;
        } else {
            goto IL_00F6;
        }
        IL_00F6: ;
        long v49 = l7;
        l0 = v49;
        IL_00F9: ;
        long v50 = l0;
        long v51 = l1;
        long v52 = System.Math.Min(v50, v51);
        l8 = v52;
        long v53 = l7;
        long v54 = l8;
        if (v53 < v54) {
            goto IL_01D3;
        } else {
            goto IL_010B;
        }
        IL_010B: ;
        int v55 = __cil_bool_load(l3);
        if (v55 != 0) {
            goto IL_0118;
        } else {
            goto IL_010E;
        }
        IL_010E: ;
        long v56 = l7;
        long v57 = l2;
        int v58 = (v56 < v57 ? 1 : 0);
        int v60 = (v58 == 0 ? 1 : 0);
        int e23_25_0 = v60;
        s25_0 = e23_25_0;
        goto IL_0119;
        IL_0118: ;
        int e24_25_0 = 1;
        s25_0 = e24_25_0;
        IL_0119: ;
        l10 = __cil_bool_store(s25_0);
        long v62 = l7;
        long v63 = l0;
        if (v62 < v63) {
            goto IL_015E;
        } else {
            goto IL_0120;
        }
        IL_0120: ;
        int v64 = __cil_bool_load(l3);
        if (v64 != 0) {
            goto IL_015E;
        } else {
            goto IL_0123;
        }
        IL_0123: ;
        long v65 = l0;
        int v66 = l4;
        long v67 = unchecked((long)(v66));
        l0 = unchecked(v65 + v67);
        OpenRA.Game.LogicTick();
        global::OpenRA.Network.OrderManager v69 = OpenRA.Game.OrderManager;
        global::OpenRA.World v70 = v69.World;
        if (v70 is null) {
            goto IL_015E;
        } else {
            goto IL_013A;
        }
        IL_013A: ;
        global::OpenRA.Network.OrderManager v71 = OpenRA.Game.OrderManager;
        global::OpenRA.World v72 = v71.World;
        int v73 = __cil_bool_load(__cil_callvirt_06000663(v72));
        if (v73 != 0) {
            goto IL_015E;
        } else {
            goto IL_014B;
        }
        IL_014B: ;
        global::OpenRA.Network.OrderManager v74 = OpenRA.Game.OrderManager;
        global::OpenRA.World v75 = v74.World;
        int v76 = __cil_bool_load(__cil_callvirt_06000662(v75));
        if (v76 != 0) {
            goto IL_015E;
        } else {
            goto IL_015C;
        }
        IL_015C: ;
        l3 = __cil_bool_store(1);
        IL_015E: ;
        long v78 = l7;
        long v79 = l0;
        int v80 = (v78 < v79 ? 1 : 0);
        l11 = __cil_bool_store(v80);
        long v81 = l7;
        long v82 = l1;
        int v83 = (v81 < v82 ? 1 : 0);
        int v85 = (v83 == 0 ? 1 : 0);
        l12 = __cil_bool_store(v85);
        global::OpenRA.Renderer v86 = OpenRA.Game.Renderer;
        int v87 = __cil_bool_load(__cil_callvirt_060004FF(v86));
        if (v87 != 0) {
            goto IL_01A5;
        } else {
            goto IL_017B;
        }
        IL_017B: ;
        int v88 = __cil_bool_load(l12);
        int v89 = __cil_bool_load(l11);
        int v90 = unchecked(v88 & v89);
        int v91 = __cil_bool_load(l10);
        int v92 = unchecked(v90 | v91);
        if (v92 == 0) {
            goto IL_01A5;
        } else {
            goto IL_0185;
        }
        IL_0185: ;
        long v93 = l7;
        int v94 = l6;
        long v95 = unchecked((long)(v94));
        l1 = unchecked(v93 + v95);
        int v98 = l6;
        int v99 = System.Math.Max(100, v98);
        long v100 = l7;
        long v102 = unchecked((long)(v99));
        l2 = unchecked(v100 + v102);
        OpenRA.Game.RenderTick();
        l3 = __cil_bool_store(0);
        IL_01A5: ;
        global::OpenRA.Renderer v105 = OpenRA.Game.Renderer;
        int v106 = __cil_bool_load(__cil_callvirt_060004FF(v105));
        int v107 = __cil_bool_load(l12);
        int v108 = unchecked(v106 & v107);
        if (v108 == 0) {
            goto IL_01DE;
        } else {
            goto IL_01B4;
        }
        IL_01B4: ;
        long v109 = l7;
        int v110 = l6;
        long v111 = unchecked((long)(v110));
        l1 = unchecked(v109 + v111);
        global::OpenRA.Renderer v113 = OpenRA.Game.Renderer;
        global::OpenRA.IPlatformWindow v114 = __cil_callvirt_06000500(v113);
        global::OpenRA.NullInputHandler v115 = __cil_newobj_06000238();
        __cil_callvirt_060001CA(v114, ((OpenRA.IInputHandler)(v115)));
        l3 = __cil_bool_store(0);
        goto IL_01DE;
        IL_01D3: ;
        long v117 = l8;
        long v118 = l7;
        long v119 = unchecked(v117 - v118);
        int v120 = unchecked((int)(v119));
        System.Threading.Thread.Sleep(v120);
        IL_01DE: ;
        int v121 = unchecked((int)(OpenRA.Game.state));
        if (v121 == 2147483647) {
            goto IL_0019;
        } else {
            goto IL_01ED;
        }
        IL_01ED: ;
        return;
    }

    private static OpenRA.RunStatus Run()
    {
        // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@OpenRA.@RunStatus; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Network.OrderManager s5_0 = default;
        OpenRA.Network.OrderManager s6_0 = default;
        OpenRA.Graphics.WorldRenderer s9_0 = default;
        OpenRA.Graphics.WorldRenderer s10_0 = default;
        IL_0000: ;
        global::OpenRA.Settings v0 = OpenRA.Game.Settings;
        global::OpenRA.GraphicSettings v1 = v0.Graphics;
        int v2 = v1.MaxFramerate;
        int v3 = 1;
        if (v2 >= v3) {
            goto IL_003B;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        global::OpenRA.Settings v4 = OpenRA.Game.Settings;
        global::OpenRA.GraphicSettings v5 = v4.Graphics;
        global::OpenRA.GraphicSettings v6 = __cil_newobj_06000537();
        int v7 = v6.MaxFramerate;
        v5.MaxFramerate = v7;
        global::OpenRA.Settings v8 = OpenRA.Game.Settings;
        global::OpenRA.GraphicSettings v9 = v8.Graphics;
        int v10 = 0;
        v9.CapFramerate = __cil_bool_store(v10);
        goto IL_003B;
        IL_003B: ;
        try {
            IL_003C: ;
            OpenRA.Game.Loop();
            goto IL_0054;
        }
        finally {
            IL_0043: ;
            global::OpenRA.Network.OrderManager v11 = OpenRA.Game.OrderManager;
            if (v11 is not null) {
                OpenRA.Network.OrderManager e4_6_0 = v11;
                s6_0 = e4_6_0;
                goto IL_004E;
            } else {
                OpenRA.Network.OrderManager e4_5_0 = v11;
                s5_0 = e4_5_0;
                goto IL_004B;
            }
            IL_004B: ;
            goto IL_0053;
            IL_004E: ;
            __cil_direct_06000CAC(s6_0);
            goto IL_0053;
            IL_0053: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0054: ;
        global::OpenRA.Graphics.WorldRenderer v12 = OpenRA.Game.worldRenderer;
        if (v12 is not null) {
            OpenRA.Graphics.WorldRenderer e8_10_0 = v12;
            s10_0 = e8_10_0;
            goto IL_005F;
        } else {
            OpenRA.Graphics.WorldRenderer e8_9_0 = v12;
            s9_0 = e8_9_0;
            goto IL_005C;
        }
        IL_005C: ;
        goto IL_0064;
        IL_005F: ;
        __cil_direct_06000EC2(s10_0);
        goto IL_0064;
        IL_0064: ;
        global::OpenRA.ModData v13 = OpenRA.Game.ModData;
        __cil_callvirt_06000419(v13);
        OpenRA.Graphics.ChromeProvider.Deinitialize();
        global::OpenRA.Sound v14 = OpenRA.Game.Sound;
        __cil_callvirt_06000580(v14);
        global::OpenRA.Renderer v15 = OpenRA.Game.Renderer;
        __cil_callvirt_0600052D(v15);
        __cil_type_01000072 v16 = OpenRA.Game.OnQuit;
        v16.Invoke();
        int v17 = unchecked((int)(OpenRA.Game.state));
        return unchecked((__cil_enum_020000BC)(v17));
    }

    public static void Exit()
    {
        // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@OpenRA.@RunStatus; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Game.state = unchecked((__cil_enum_020000BC)(0));
        return;
    }

    public static void Disconnect()
    {
        OpenRA.World s1_0 = default;
        OpenRA.World s2_0 = default;
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        global::OpenRA.World v1 = v0.World;
        if (v1 is not null) {
            OpenRA.World e0_2_0 = v1;
            s2_0 = e0_2_0;
            goto IL_0010;
        } else {
            OpenRA.World e0_1_0 = v1;
            s1_0 = e0_1_0;
            goto IL_000D;
        }
        IL_000D: ;
        goto IL_001A;
        IL_0010: ;
        global::OpenRA.TraitDictionary v2 = s2_0.TraitDict;
        __cil_callvirt_060005F3(v2);
        IL_001A: ;
        global::OpenRA.Network.OrderManager v3 = OpenRA.Game.OrderManager;
        __cil_callvirt_06000CAC(v3);
        OpenRA.Game.CloseServer();
        OpenRA.Game.JoinLocal();
        return;
    }

    public static void CloseServer()
    {
        OpenRA.Server.Server s1_0 = default;
        OpenRA.Server.Server s2_0 = default;
        global::OpenRA.Server.Server v0 = OpenRA.Game.server;
        if (v0 is not null) {
            OpenRA.Server.Server e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_000A;
        } else {
            OpenRA.Server.Server e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_000A: ;
        __cil_direct_060007EA(s2_0);
        return;
    }

    public static T CreateObject<T>(string name)
    {
        // generic body context type-owner=0x0200001E type-arity=0 method-owner=0x0600018F method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_generic_5ce58c723824e910faf16be0aae7909c41f4b476 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x0600018F; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        global::OpenRA.ModData v0 = OpenRA.Game.ModData;
        global::OpenRA.ObjectCreator v1 = v0.ObjectCreator;
        __cil_generic_5ce58c723824e910faf16be0aae7909c41f4b476 v3 = __cil_callvirt_2B000060(v1, name);
        return v3;
    }

    public static OpenRA.Network.ConnectionTarget CreateServer(OpenRA.ServerSettings settings)
    {
        // structural signature __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc bytes=1512809D011281DD: class [System.Collections]System.Collections.Generic.List`1<class [System.Net.Primitives]System.Net.IPEndPoint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000FA alias=__cil_enum_020000FA underlying=int: global::@OpenRA.@Server.@ServerType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc v0 = __cil_newobj_0A00024C();
        __cil_type_010000D0 v1 = __cil_ldsfld_0A00024D();
        int v3 = settings.ListenPort;
        __cil_type_01000077 v4 = __cil_newobj_0A00024E(v1, v3);
        __cil_callvirt_0A00024F(v0, v4);
        __cil_type_010000D0 v5 = __cil_ldsfld_0A000250();
        int v7 = settings.ListenPort;
        __cil_type_01000077 v8 = __cil_newobj_0A00024E(v5, v7);
        __cil_callvirt_0A00024F(v0, v8);
        global::OpenRA.ModData v11 = OpenRA.Game.ModData;
        global::OpenRA.Server.Server v13 = __cil_newobj_060007EE(v0, settings, v11, 2);
        OpenRA.Game.server = v13;
        global::OpenRA.Server.Server v14 = OpenRA.Game.server;
        global::OpenRA.Network.ConnectionTarget v15 = __cil_callvirt_06000814(v14);
        return v15;
    }

    public static OpenRA.Network.ConnectionTarget CreateLocalServer(string map, bool isSkirmish = false)
    {
        // structural signature __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc bytes=1512809D011281DD: class [System.Collections]System.Collections.Generic.List`1<class [System.Net.Primitives]System.Net.IPEndPoint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000FA alias=__cil_enum_020000FA underlying=int: global::@OpenRA.@Server.@ServerType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc s1_0 = default;
        OpenRA.ServerSettings s1_1 = default;
        OpenRA.ModData s1_2 = default;
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc s2_0 = default;
        OpenRA.ServerSettings s2_1 = default;
        OpenRA.ModData s2_2 = default;
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc s3_0 = default;
        OpenRA.ServerSettings s3_1 = default;
        OpenRA.ModData s3_2 = default;
        int s3_3 = default;
        global::OpenRA.ServerSettings v0 = __cil_newobj_06000535();
        string v1 = __cil_ldstr_7000196A("Skirmish Game");
        v0.Name = v1;
        v0.Map = map;
        v0.AdvertiseOnline = __cil_bool_store(0);
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc v4 = __cil_newobj_0A00024C();
        __cil_type_010000D0 v5 = __cil_ldsfld_0A000251();
        __cil_type_01000077 v7 = __cil_newobj_0A00024E(v5, 0);
        __cil_callvirt_0A00024F(v4, v7);
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc v8 = v4;
        global::OpenRA.ServerSettings v9 = v0;
        global::OpenRA.ModData v10 = OpenRA.Game.ModData;
        int v11 = __cil_bool_load(isSkirmish);
        if (v11 != 0) {
            __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc e0_2_0 = v8;
            OpenRA.ServerSettings e0_2_1 = v9;
            OpenRA.ModData e0_2_2 = v10;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            s2_2 = e0_2_2;
            goto IL_0043;
        } else {
            __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc e0_1_0 = v8;
            OpenRA.ServerSettings e0_1_1 = v9;
            OpenRA.ModData e0_1_2 = v10;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            s1_2 = e0_1_2;
            goto IL_0040;
        }
        IL_0040: ;
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc e1_3_0 = s1_0;
        OpenRA.ServerSettings e1_3_1 = s1_1;
        OpenRA.ModData e1_3_2 = s1_2;
        int e1_3_3 = 0;
        s3_0 = e1_3_0;
        s3_1 = e1_3_1;
        s3_2 = e1_3_2;
        s3_3 = e1_3_3;
        goto IL_0044;
        IL_0043: ;
        __cil_ref_01e3de75eb3858554d7ca58ac13b4e9bd9f86ddc e2_3_0 = s2_0;
        OpenRA.ServerSettings e2_3_1 = s2_1;
        OpenRA.ModData e2_3_2 = s2_2;
        int e2_3_3 = 1;
        s3_0 = e2_3_0;
        s3_1 = e2_3_1;
        s3_2 = e2_3_2;
        s3_3 = e2_3_3;
        IL_0044: ;
        global::OpenRA.Server.Server v14 = __cil_newobj_060007EE(s3_0, s3_1, s3_2, s3_3);
        OpenRA.Game.server = v14;
        global::OpenRA.Server.Server v15 = OpenRA.Game.server;
        global::OpenRA.Network.ConnectionTarget v16 = __cil_callvirt_06000814(v15);
        return v16;
    }

    public static bool IsCurrentWorld(OpenRA.World world)
    {
        global::OpenRA.Network.OrderManager v0 = OpenRA.Game.OrderManager;
        if (v0 is null) {
            return false;
        } else {
            goto IL_0007;
        }
        IL_0007: ;
        global::OpenRA.Network.OrderManager v1 = OpenRA.Game.OrderManager;
        global::OpenRA.World v2 = v1.World;
        if (!System.Object.ReferenceEquals(v2, world)) {
            return false;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        int v5 = __cil_bool_load(world.Disposing);
        return (v5 == 0);
    }

    public static bool SetClipboardText(string text)
    {
        global::OpenRA.Renderer v0 = OpenRA.Game.Renderer;
        global::OpenRA.IPlatformWindow v1 = __cil_callvirt_06000500(v0);
        return __cil_callvirt_060001CC(v1, text);
    }

    public static void BenchmarkMode(string prefix)
    {
        global::OpenRA.Support.Benchmark v1 = __cil_newobj_06000791(prefix);
        OpenRA.Game.benchmark = v1;
        return;
    }

    public static void LoadMap(string launchMap)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, BD, 0F, 00, 06, 0A, 06, 02, 7D, 8E, 09, 00, 04, 73, 52, 02, 00, 0A, 25, 72, 86, 19, 00, 70]
        // .code-bytes IL_0018: [28, 42, 04, 00, 06, 6F, 53, 02, 00, 0A, 25, 12, 03, 1C, 17, 28, C4, 00, 00, 0A, 12, 03, 72, B8]
        // .code-bytes IL_0030: [19, 00, 70, 28, C5, 00, 00, 0A, 12, 03, 18, 28, 61, 00, 00, 2B, 12, 03, 28, C7, 00, 00, 0A, 28]
        // .code-bytes IL_0048: [42, 04, 00, 06, 6F, 53, 02, 00, 0A, 0B, 7E, 65, 00, 00, 04, 7B, 0C, 03, 00, 04, 06, FE, 06, BE]
        // .code-bytes IL_0060: [0F, 00, 06, 73, 44, 02, 00, 0A, 28, 62, 00, 00, 2B, 0C, 08, 2D, 1B, 72, C6, 19, 00, 70, 06, 7B]
        // .code-bytes IL_0078: [8E, 09, 00, 04, 72, F4, 16, 00, 70, 28, 6D, 00, 00, 0A, 73, 81, 01, 00, 0A, 7A, 08, 7B, C6, 02]
        // .code-bytes IL_0090: [00, 04, 07, 28, 73, 01, 00, 06, 2A]
        // .local [0] class OpenRA.Game/<>c__DisplayClass108_0
        // .local [1] class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Order>
        // .local [2] class OpenRA.MapPreview
        // .local [3] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: newobj 0x06000FBD OpenRA.Game/<>c__DisplayClass108_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x0400098E OpenRA.Game/<>c__DisplayClass108_0::launchMap
        // IL_000D: newobj 0x0A000252 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Order>::.ctor
        // IL_0012: dup 
        // IL_0013: ldstr 0x70001986 [111, 112, 116, 105, 111, 110, 32, 103, 97, 109, 101, 115, 112, 101, 101, 100, 32, 100, 101, 102, 97, 117, 108, 116] utf16-bytes=[6F, 00, 70, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 67, 00, 61, 00, 6D, 00, 65, 00, 73, 00, 70, 00, 65, 00, 65, 00, 64, 00, 20, 00, 64, 00, 65, 00, 66, 00, 61, 00, 75, 00, 6C, 00, 74, 00] terminal-flag=Some(0)
        // IL_0018: call 0x06000442 OpenRA.Order::Command
        // IL_001D: callvirt 0x0A000253 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Order>::Add
        // IL_0022: dup 
        // IL_0023: ldloca.s 3
        // IL_0025: ldc.i4.6 6
        // IL_0026: ldc.i4.1 1
        // IL_0027: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_002C: ldloca.s 3
        // IL_002E: ldstr 0x700019B8 [115, 116, 97, 116, 101, 32] utf16-bytes=[73, 00, 74, 00, 61, 00, 74, 00, 65, 00, 20, 00] terminal-flag=Some(0)
        // IL_0033: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0038: ldloca.s 3
        // IL_003A: ldc.i4.2 2
        // IL_003B: call 0x2B000061 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<valuetype OpenRA.Network.Session/ClientState>
        // IL_0040: ldloca.s 3
        // IL_0042: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0047: call 0x06000442 OpenRA.Order::Command
        // IL_004C: callvirt 0x0A000253 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Order>::Add
        // IL_0051: stloc.1 1
        // IL_0052: ldsfld 0x04000065 OpenRA.Game::ModData
        // IL_0057: ldfld 0x0400030C OpenRA.ModData::MapCache
        // IL_005C: ldloc.0 0
        // IL_005D: ldftn 0x06000FBE OpenRA.Game/<>c__DisplayClass108_0::<LoadMap>b__0
        // IL_0063: newobj 0x0A000244 class [System.Runtime]System.Func`2<class OpenRA.MapPreview, bool>::.ctor
        // IL_0068: call 0x2B000062 [System.Linq]System.Linq.Enumerable::SingleOrDefault<class OpenRA.MapPreview>
        // IL_006D: stloc.2 2
        // IL_006E: ldloc.2 2
        // IL_006F: brtrue.s IL_008C
        // IL_0071: ldstr 0x700019C6 [67, 111, 117, 108, 100, 32, 110, 111, 116, 32, 102, 105, 110, 100, 32, 109, 97, 112, 32, 39] utf16-bytes=[43, 00, 6F, 00, 75, 00, 6C, 00, 64, 00, 20, 00, 6E, 00, 6F, 00, 74, 00, 20, 00, 66, 00, 69, 00, 6E, 00, 64, 00, 20, 00, 6D, 00, 61, 00, 70, 00, 20, 00, 27, 00] terminal-flag=Some(1)
        // IL_0076: ldloc.0 0
        // IL_0077: ldfld 0x0400098E OpenRA.Game/<>c__DisplayClass108_0::launchMap
        // IL_007C: ldstr 0x700016F4 [39, 46] utf16-bytes=[27, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0081: call 0x0A00006D [System.Runtime]System.String::Concat
        // IL_0086: newobj 0x0A000181 [System.Runtime]System.ArgumentException::.ctor
        // IL_008B: throw 
        // IL_008C: ldloc.2 2
        // IL_008D: ldfld 0x040002C6 OpenRA.MapPreview::Uid
        // IL_0092: ldloc.1 1
        // IL_0093: call 0x06000173 OpenRA.Game::CreateAndStartLocalServer
        // IL_0098: ret 
    }

    public static void FinishBenchmark()
    {
        global::OpenRA.Support.Benchmark v0 = OpenRA.Game.benchmark;
        if (v0 is null) {
            goto IL_0016;
        } else {
            goto IL_0007;
        }
        IL_0007: ;
        global::OpenRA.Support.Benchmark v1 = OpenRA.Game.benchmark;
        __cil_callvirt_06000793(v1);
        OpenRA.Game.Exit();
        IL_0016: ;
        return;
    }

    static Game()
    {
        // structural signature __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec bytes=151281CD031287800E128744: class [System.Runtime]System.Action`3<class OpenRA.Network.OrderManager, string, class OpenRA.Network.NetworkConnection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 bytes=151281A901128748: class [System.Runtime]System.Action`1<class OpenRA.Network.ConnectionTarget>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@OpenRA.@RunStatus; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020001CE alias=__cil_enum_020001CE underlying=int: global::@OpenRA.@Network.@ConnectionState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.Support.MersenneTwister v0 = __cil_newobj_0600079D();
        OpenRA.Game.CosmeticRandom = v0;
        OpenRA.Game.takeScreenshot = __cil_bool_store(0);
        OpenRA.Game.benchmark = null;
        global::OpenRA.Game.__name_3C3E63 v2 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v3 = __cil_ldftn_06000FB6;
        __cil_type_01000072 v4 = __cil_newobj_0A000232(v2, v3);
        OpenRA.Game.OnShellmapLoaded = v4;
        __cil_type_01000074 v5 = System.Diagnostics.Stopwatch.StartNew();
        OpenRA.Game.Stopwatch = v5;
        OpenRA.Game.RenderFrame = 0;
        global::OpenRA.Game.__name_3C3E63 v7 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v8 = __cil_ldftn_06000FB7;
        __cil_ref_f0a0665e1be0ba7a7922cd4e356ce59a16ae9b04 v9 = __cil_newobj_0A000242(v7, v8);
        OpenRA.Game.OnRemoteDirectConnect = v9;
        global::OpenRA.Game.__name_3C3E63 v10 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v11 = __cil_ldftn_06000FB8;
        __cil_ref_5f68a94580d1c2d1c779281a2f3ab4b2a70455ec v12 = __cil_newobj_0A000241(v10, v11);
        OpenRA.Game.ConnectionStateChanged = v12;
        OpenRA.Game.lastConnectionState = unchecked((__cil_enum_020001CE)(0));
        global::OpenRA.Game.__name_3C3E63 v14 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v15 = __cil_ldftn_06000FB9;
        __cil_type_01000072 v16 = __cil_newobj_0A000232(v14, v15);
        OpenRA.Game.LobbyInfoChanged = v16;
        global::OpenRA.Game.__name_3C3E63 v17 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v18 = __cil_ldftn_06000FBA;
        __cil_type_01000072 v19 = __cil_newobj_0A000232(v17, v18);
        OpenRA.Game.BeforeGameStart = v19;
        global::OpenRA.Game.__name_3C3E63 v20 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v21 = __cil_ldftn_06000FBB;
        __cil_type_01000072 v22 = __cil_newobj_0A000232(v20, v21);
        OpenRA.Game.AfterGameStart = v22;
        OpenRA.Game.state = unchecked((__cil_enum_020000BC)(2147483647));
        global::OpenRA.Game.__name_3C3E63 v24 = OpenRA.Game.__name_3C3E63.__il_field_04000984;
        nint v25 = __cil_ldftn_06000FBC;
        __cil_type_01000072 v26 = __cil_newobj_0A000232(v24, v25);
        OpenRA.Game.OnQuit = v26;
        global::OpenRA.Primitives.ActionQueue v27 = __cil_newobj_06000A0B();
        System.Threading.Volatile.Write(ref OpenRA.Game.delayedActions, v27);
        return;
    }
    // property OpenRA.InstalledMods Mods { get: get_Mods; set: set_Mods; }
    // property OpenRA.ExternalMods ExternalMods { get: get_ExternalMods; set: set_ExternalMods; }
    // property string EngineVersion { get: get_EngineVersion; set: set_EngineVersion; }
    // property long RunTime { get: get_RunTime; }
    // property int NetFrameNumber { get: get_NetFrameNumber; }
    // property int LocalTick { get: get_LocalTick; }
    // property int LocalClientId { get: get_LocalClientId; }
    // property bool IsHost { get: get_IsHost; }
    // event System.Action OnShellmapLoaded { add: add_OnShellmapLoaded; remove: remove_OnShellmapLoaded; }
    // event System.Action<OpenRA.Network.ConnectionTarget> OnRemoteDirectConnect { add: add_OnRemoteDirectConnect; remove: remove_OnRemoteDirectConnect; }
    // event System.Action<OpenRA.Network.OrderManager, string, OpenRA.Network.NetworkConnection> ConnectionStateChanged { add: add_ConnectionStateChanged; remove: remove_ConnectionStateChanged; }
    // event System.Action LobbyInfoChanged { add: add_LobbyInfoChanged; remove: remove_LobbyInfoChanged; }
    // event System.Action BeforeGameStart { add: add_BeforeGameStart; remove: remove_BeforeGameStart; }
    // event System.Action AfterGameStart { add: add_AfterGameStart; remove: remove_AfterGameStart; }
    // event System.Action OnQuit { add: add_OnQuit; remove: remove_OnQuit; }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Game.__name_3C3E63 __il_field_04000984;
        public static System.Func<string> __il_field_04000985;
        public static System.Func<System.Type, bool> __il_field_04000986;
        public static System.Action __il_field_04000987;
        public static System.Action<OpenRA.Network.OrderManager, string, OpenRA.Network.NetworkConnection> __il_field_04000988;
        public static System.Action __il_field_04000989;
        public static System.Action<OpenRA.Network.ConnectionTarget> __il_field_0400098A;
        public static System.Func<OpenRA.MapPreview, bool> __il_field_0400098B;
        public static System.Func<OpenRA.MapPreview, string> __il_field_0400098C;
        public static System.Func<string, string> __il_field_0400098D;

        static __name_3C3E63()
        {
            global::OpenRA.Game.__name_3C3E63 v0 = __cil_newobj_06000FAC();
            OpenRA.Game.__name_3C3E63.__il_field_04000984 = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <JoinServer>b__31_0
        internal string JoinServerLambda31_0()
        {
            string v1 = __cil_ldstr_700005EE("");
            string v2 = OpenRA.Game.TimestampedFilename(__cil_bool_store(0), v1);
            return v2;
        }

        // Metadata name: <CreatePlatform>b__78_0
        internal bool CreatePlatformLambda78_0(System.Type t)
        {
            // structural signature __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 bytes=118415: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 v0 = __cil_ldtoken_type_02000026;
            __cil_type_01000026 v1 = System.Type.GetTypeFromHandle(v0);
            return v1.IsAssignableFrom(t);
        }

        // Metadata name: <InitializeMod>b__79_0
        internal void InitializeModLambda79_0()
        {
            return;
        }

        // Metadata name: <InitializeMod>b__79_1
        internal void InitializeModLambda79_1(OpenRA.Network.OrderManager om, string p, OpenRA.Network.NetworkConnection conn)
        {
            return;
        }

        // Metadata name: <InitializeMod>b__79_2
        internal void InitializeModLambda79_2()
        {
            return;
        }

        // Metadata name: <InitializeMod>b__79_3
        internal void InitializeModLambda79_3(OpenRA.Network.ConnectionTarget endpoint)
        {
            return;
        }

        // Metadata name: <ChooseShellmap>b__82_0
        internal bool ChooseShellmapLambda82_0(OpenRA.MapPreview m)
        {
            // IL fallback: incompatible value/receiver types
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 6F, 8D, 03, 00, 06, 2D, 17, 03, 6F, 8F, 03, 00, 06, 8C, 65, 00, 00, 02, 18, 8C, 65, 00, 00]
            // .code-bytes IL_0018: [02, 28, 25, 01, 00, 0A, 2A, 16, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: callvirt 0x0600038D OpenRA.MapPreview::get_Status
            // IL_0006: brtrue.s IL_001F
            // IL_0008: ldarg.1 1
            // IL_0009: callvirt 0x0600038F OpenRA.MapPreview::get_Visibility
            // IL_000E: box 0x02000065 OpenRA.MapVisibility
            // IL_0013: ldc.i4.2 2
            // IL_0014: box 0x02000065 OpenRA.MapVisibility
            // IL_0019: call 0x0A000125 [System.Runtime]System.Enum::HasFlag
            // IL_001E: ret 
            // IL_001F: ldc.i4.0 0
            // IL_0020: ret 
        }

        // Metadata name: <ChooseShellmap>b__82_1
        internal string ChooseShellmapLambda82_1(OpenRA.MapPreview m)
        {
            string v1 = m.Uid;
            return v1;
        }

        // Metadata name: <SwitchToExternalMod>b__83_0
        internal string SwitchToExternalModLambda83_0(string a)
        {
            string v0 = __cil_ldstr_7000C5C8("\"");
            string v2 = __cil_ldstr_7000C5C8("\"");
            string v3 = System.String.Concat(v0, a, v2);
            return v3;
        }

        // Metadata name: <.cctor>b__110_0
        internal void StaticCtorLambda110_0()
        {
            return;
        }

        // Metadata name: <.cctor>b__110_1
        internal void StaticCtorLambda110_1(OpenRA.Network.ConnectionTarget _)
        {
            return;
        }

        // Metadata name: <.cctor>b__110_2
        internal void StaticCtorLambda110_2(OpenRA.Network.OrderManager om, string pass, OpenRA.Network.NetworkConnection conn)
        {
            return;
        }

        // Metadata name: <.cctor>b__110_3
        internal void StaticCtorLambda110_3()
        {
            return;
        }

        // Metadata name: <.cctor>b__110_4
        internal void StaticCtorLambda110_4()
        {
            return;
        }

        // Metadata name: <.cctor>b__110_5
        internal void StaticCtorLambda110_5()
        {
            return;
        }

        // Metadata name: <.cctor>b__110_6
        internal void StaticCtorLambda110_6()
        {
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733130385F30
    {
        public string launchMap;

        public __name_3C3E635F5F446973706C6179436C6173733130385F30() : base()
        {
            return;
        }

        // Metadata name: <LoadMap>b__0
        internal bool LoadMapLambda0(OpenRA.MapPreview m)
        {
            string v1 = m.Uid;
            string v3 = this.launchMap;
            int v4 = __cil_bool_load(System.String.op_Equality(v1, v3));
            if (v4 != 0) {
                return true;
            } else {
                goto IL_0013;
            }
            IL_0013: ;
            string v6 = __cil_callvirt_0600037E(m);
            string v7 = System.IO.Path.GetFileName(v6);
            string v9 = this.launchMap;
            return System.String.op_Equality(v7, v9);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336395F30
    {
        public System.Collections.Generic.IEnumerable<OpenRA.Order> setupOrders;
        public OpenRA.Network.OrderManager om;

        public __name_3C3E635F5F446973706C6179436C61737336395F30() : base()
        {
            return;
        }

        internal void __name_3C437265617465416E6453746172744C6F63616C5365727665723E675F5F4C6F62627952656164797C30()
        {
            // structural signature __cil_ref_fcc908830936c12388832257baf21a5941e2b618 bytes=1512808501128234: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Order>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_4f2dad7858ef991bbf654e40ccdf86813d976deb bytes=151280A101128234: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Order>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_4f2dad7858ef991bbf654e40ccdf86813d976deb l0 = default;
            OpenRA.Order l1 = default;
            IL_0000: ;
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737336395F30 v0 = this;
            nint v1 = __cil_ldftn_06000FC0;
            __cil_type_01000072 v2 = __cil_newobj_0A000232(v0, v1);
            OpenRA.Game.remove_LobbyInfoChanged(v2);
            global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737336395F30 v3 = this;
            __cil_ref_fcc908830936c12388832257baf21a5941e2b618 v4 = v3.setupOrders;
            __cil_ref_4f2dad7858ef991bbf654e40ccdf86813d976deb v5 = __cil_callvirt_0A000051(v4);
            l0 = v5;
            try {
                IL_001D: ;
                goto IL_0032;
                IL_001F: ;
                __cil_ref_4f2dad7858ef991bbf654e40ccdf86813d976deb v6 = l0;
                global::OpenRA.Order v7 = __cil_callvirt_0A000050(v6);
                l1 = v7;
                global::OpenRA.Game.__name_3C3E635F5F446973706C6179436C61737336395F30 v8 = this;
                global::OpenRA.Network.OrderManager v9 = v8.om;
                global::OpenRA.Order v10 = l1;
                __cil_callvirt_06000CA0(v9, v10);
                goto IL_0032;
                IL_0032: ;
                __cil_ref_4f2dad7858ef991bbf654e40ccdf86813d976deb v11 = l0;
                int v12 = __cil_bool_load(__cil_callvirt_0A000018(v11));
                if (v12 != 0) {
                    goto IL_001F;
                } else {
                    goto IL_003A;
                }
                IL_003A: ;
                goto IL_0046;
            }
            finally {
                IL_003C: ;
                __cil_ref_4f2dad7858ef991bbf654e40ccdf86813d976deb v13 = l0;
                if (v13 is null) {
                    goto IL_0045;
                } else {
                    goto IL_003F;
                }
                IL_003F: ;
                __cil_ref_4f2dad7858ef991bbf654e40ccdf86813d976deb v14 = l0;
                __cil_callvirt_0A000017(v14);
                goto IL_0045;
                IL_0045: ;
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_0046: ;
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737339325F30
    {
        public OpenRA.World world;

        public __name_3C3E635F5F446973706C6179436C61737339325F30() : base()
        {
            return;
        }

        // Metadata name: <InnerLogicTick>b__0
        internal void InnerLogicTickLambda0()
        {
            global::OpenRA.World v1 = this.world;
            global::OpenRA.Orders.IOrderGenerator v2 = __cil_callvirt_06000667(v1);
            global::OpenRA.World v4 = this.world;
            __cil_callvirt_06000C23(v2, v4);
            return;
        }

        // Metadata name: <InnerLogicTick>b__1
        internal void InnerLogicTickLambda1()
        {
            global::OpenRA.World v1 = this.world;
            global::OpenRA.Graphics.WorldRenderer v2 = OpenRA.Game.worldRenderer;
            __cil_callvirt_0600068A(v1, v2);
            return;
        }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Algorithms, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Algorithms, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Csp, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Csp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.Process, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.Process, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.Watcher, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.Watcher, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Channels, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Threading.Channels, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.ILGeneration, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.ILGeneration, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.Lightweight, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.Lightweight, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Loader, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Loader, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq.Expressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq.Expressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Sockets, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Sockets, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Numerics, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Numerics, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.StackTrace, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.StackTrace, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.NameResolution, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.NameResolution, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 7; exact references retained; see --details for identities and provenance.
