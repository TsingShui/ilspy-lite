namespace OpenRA;

public static class Exts
{
    public static OpenRA.Primitives.Color OwnerColor(OpenRA.Actor actor)
    {
        // structural signature __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f bytes=1186D4: valuetype OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        OpenRA.Traits.IEffectiveOwner l0 = default;
        global::OpenRA.Traits.IEffectiveOwner v1 = __cil_callvirt_0600001D(actor);
        l0 = v1;
        global::OpenRA.Traits.IEffectiveOwner v2 = l0;
        if (v2 is null) {
            goto IL_002B;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::OpenRA.Traits.IEffectiveOwner v3 = l0;
        int v4 = __cil_bool_load(__cil_callvirt_060008F5(v3));
        if (v4 == 0) {
            goto IL_002B;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        global::OpenRA.World v6 = actor.World;
        global::OpenRA.Player v7 = __cil_callvirt_06000659(v6);
        if (v7 is null) {
            goto IL_002B;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        global::OpenRA.Traits.IEffectiveOwner v8 = l0;
        global::OpenRA.Player v9 = __cil_callvirt_060008F6(v8);
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v10 = __cil_callvirt_0600046C(v9);
        return v10;
        IL_002B: ;
        global::OpenRA.Player v12 = __cil_callvirt_06000013(actor);
        __cil_value_d36572f474cd2a8b8d1b445aa6ffdef3d022d30f v13 = __cil_callvirt_0600046C(v12);
        return v13;
    }

    public static string FormatInvariant(string format, object[] args)
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000113 v0 = System.Globalization.CultureInfo.get_InvariantCulture();
        string v3 = System.String.Format(((__cil_type_010000FF)(v0)), format, args);
        return v3;
    }

    public static string FormatCurrent(string format, object[] args)
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000113 v0 = System.Globalization.CultureInfo.get_CurrentCulture();
        string v3 = System.String.Format(((__cil_type_010000FF)(v0)), format, args);
        return v3;
    }

    public static System.Lazy<T> Lazy<T>(System.Func<T> p)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000BD method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_45b315d5d1c46e5a414e8efaf059beaf395890dc bytes=15128121011E00: class [System.Runtime]System.Func`1<!!0>; type-owner=0x00000000 method-owner=0x060000BD; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9efef5c3f31c567e59ab3261da5889598043787d bytes=15128091011E00: class [System.Runtime]System.Lazy`1<!!0>; type-owner=0x00000000 method-owner=0x060000BD; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_9efef5c3f31c567e59ab3261da5889598043787d v1 = __cil_newobj_0A00013B(p);
        return v1;
    }

    public static System.Collections.Generic.IEnumerable<string> GetNamespaces(System.Reflection.Assembly a)
    {
        // structural signature __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd bytes=15128085010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 bytes=1D128099: class [System.Runtime]System.Type[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 bytes=151280C9021280990E: class [System.Runtime]System.Func`2<class [System.Runtime]System.Type, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_680b36952fa42a45596042d94398ccdfd5b77b9a bytes=1512808501128099: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [System.Runtime]System.Type>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b bytes=151280C9020E02: class [System.Runtime]System.Func`2<string, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 s1_0 = default;
        __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 s1_1 = default;
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 s2_0 = default;
        __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 s2_1 = default;
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd s3_0 = default;
        __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b s3_1 = default;
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd s4_0 = default;
        __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b s4_1 = default;
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 v1 = a.GetTypes();
        __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 v2 = OpenRA.Exts.__name_3C3E63.__il_field_04000958;
        if (v2 is not null) {
            __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 e0_2_0 = v1;
            __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 e0_2_1 = v2;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_0025;
        } else {
            __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 e0_1_0 = v1;
            __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 e0_1_1 = v2;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_000E;
        }
        IL_000E: ;
        global::OpenRA.Exts.__name_3C3E63 v3 = OpenRA.Exts.__name_3C3E63.__il_field_04000957;
        nint v4 = __cil_ldftn_06000F73;
        __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 v5 = __cil_newobj_0A00013D(v3, v4);
        OpenRA.Exts.__name_3C3E63.__il_field_04000958 = v5;
        __cil_ref_0d9ea9ccc9577fdcf9d45ebcd6bcd8da4c46cad9 e1_2_0 = s1_0;
        __cil_ref_5e37bdce4d288e3f78a8365d2ccbefdc9ac4cd58 e1_2_1 = v5;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        IL_0025: ;
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd v6 = __cil_methodspec_call_2B000029(((__cil_ref_680b36952fa42a45596042d94398ccdfd5b77b9a)(s2_0)), s2_1);
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd v7 = __cil_methodspec_call_2B00002A(v6);
        __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b v8 = OpenRA.Exts.__name_3C3E63.__il_field_04000959;
        if (v8 is not null) {
            __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd e2_4_0 = v7;
            __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b e2_4_1 = v8;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_004E;
        } else {
            __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd e2_3_0 = v7;
            __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b e2_3_1 = v8;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_0037;
        }
        IL_0037: ;
        global::OpenRA.Exts.__name_3C3E63 v9 = OpenRA.Exts.__name_3C3E63.__il_field_04000957;
        nint v10 = __cil_ldftn_06000F74;
        __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b v11 = __cil_newobj_0A000140(v9, v10);
        OpenRA.Exts.__name_3C3E63.__il_field_04000959 = v11;
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd e3_4_0 = s3_0;
        __cil_ref_06d8b2dfd0af645cf33f552bd9a7579591d5b62b e3_4_1 = v11;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        IL_004E: ;
        __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd v12 = __cil_methodspec_call_2B00002B(s4_0, s4_1);
        return v12;
    }

    public static bool HasAttribute<TAttribute>(System.Reflection.MemberInfo mi) where TAttribute : System.Attribute
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000BF method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 bytes=118415: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 v1 = __cil_ldtoken_type_1B0000BA;
        __cil_type_01000026 v2 = System.Type.GetTypeFromHandle(v1);
        return System.Attribute.IsDefined(mi, v2);
    }

    public static TAttribute[] GetCustomAttributes<TAttribute>(System.Reflection.MemberInfo mi, bool inherit) where TAttribute : System.Attribute
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000C0 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 bytes=118415: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_d0a4ce244e806b50c5b3befd9f0a5caff760caf2 bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000C0; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 v1 = __cil_ldtoken_type_1B0000BA;
        __cil_type_01000026 v2 = System.Type.GetTypeFromHandle(v1);
        int v3 = __cil_bool_load(inherit);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v4 = mi.GetCustomAttributes(v2, __cil_bool_store(v3));
        __cil_ref_d0a4ce244e806b50c5b3befd9f0a5caff760caf2 v5 = ((__cil_ref_d0a4ce244e806b50c5b3befd9f0a5caff760caf2)(object)v4);
        return v5;
    }

    public static T Clamp<T>(T val, T min, T max) where T : System.IComparable<T>
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000C1 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000C1; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        IL_0000: ;
        ref __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae v0 = ref val;
        __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae v1 = min;
        int v2 = __cil_constrained_1B0000BA_0A000143(ref v0, v1);
        int v3 = 0;
        if (v2 >= v3) {
            goto IL_0013;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae v4 = min;
        return v4;
        IL_0013: ;
        ref __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae v5 = ref val;
        __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae v6 = max;
        int v7 = __cil_constrained_1B0000BA_0A000143(ref v5, v6);
        int v8 = 0;
        if (v7 <= v8) {
            goto IL_0026;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae v9 = max;
        return v9;
        IL_0026: ;
        __cil_generic_5103e67019535e74348000771ec7c4bfe3fa14ae v10 = val;
        return v10;
    }

    private static int WindingDirectionTest(OpenRA.int2 arg0, OpenRA.int2 arg1, OpenRA.int2 p)
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int v1 = arg1.X;
        int v3 = arg0.X;
        int v4 = unchecked(v1 - v3);
        int v6 = p.Y;
        int v8 = arg0.Y;
        int v9 = unchecked(v6 - v8);
        int v10 = unchecked(v4 * v9);
        int v12 = p.X;
        int v14 = arg0.X;
        int v15 = unchecked(v12 - v14);
        int v17 = arg1.Y;
        int v19 = arg0.Y;
        int v20 = unchecked(v17 - v19);
        int v21 = unchecked(v15 * v20);
        int v22 = unchecked(v10 - v21);
        int v23 = System.Math.Sign(v22);
        return v23;
    }

    public static bool PolygonContains(OpenRA.int2[] polygon, OpenRA.int2 p)
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_f45c7526b037b10c3f9b2b1744aafe437528d7e2 bytes=1D118274: valuetype OpenRA.int2[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        int l1 = default;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 l2 = default;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 l3 = default;
        l0 = 0;
        l1 = 0;
        goto IL_0078;
        IL_0006: ;
        int v3 = l1;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v4 = __cil_ldelem_0200009D(polygon, v3);
        l2 = v4;
        int v6 = l1;
        int v8 = unchecked(v6 + 1);
        nint v10 = unchecked((nint)(polygon.LongLength));
        int v11 = unchecked((int)(v10));
        int v12 = unchecked(v8 % v11);
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v13 = __cil_ldelem_0200009D(polygon, v12);
        l3 = v13;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v14 = l2;
        int v15 = v14.Y;
        int v17 = p.Y;
        if (v15 > v17) {
            goto IL_0049;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v18 = l3;
        int v19 = v18.Y;
        int v21 = p.Y;
        if (v19 <= v21) {
            goto IL_0049;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v22 = l2;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v23 = l3;
        int v25 = OpenRA.Exts.WindingDirectionTest(v22, v23, p);
        if (v25 <= 0) {
            goto IL_0049;
        } else {
            goto IL_0043;
        }
        IL_0043: ;
        int v27 = l0;
        l0 = unchecked(v27 + 1);
        goto IL_0074;
        IL_0049: ;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v30 = l2;
        int v31 = v30.Y;
        int v33 = p.Y;
        if (v31 <= v33) {
            goto IL_0074;
        } else {
            goto IL_0057;
        }
        IL_0057: ;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v34 = l3;
        int v35 = v34.Y;
        int v37 = p.Y;
        if (v35 > v37) {
            goto IL_0074;
        } else {
            goto IL_0065;
        }
        IL_0065: ;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v38 = l2;
        __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 v39 = l3;
        int v41 = OpenRA.Exts.WindingDirectionTest(v38, v39, p);
        if (v41 >= 0) {
            goto IL_0074;
        } else {
            goto IL_0070;
        }
        IL_0070: ;
        int v43 = unchecked(l0--);
        IL_0074: ;
        int v46 = l1;
        l1 = unchecked(v46 + 1);
        IL_0078: ;
        int v49 = l1;
        nint v51 = unchecked((nint)(polygon.LongLength));
        int v52 = unchecked((int)(v51));
        if (v49 < v52) {
            goto IL_0006;
        } else {
            goto IL_007E;
        }
        IL_007E: ;
        int v53 = l0;
        return (unchecked((uint)v53) > unchecked((uint)0));
    }

    public static bool LinesIntersect(OpenRA.int2 a, OpenRA.int2 b, OpenRA.int2 c, OpenRA.int2 d)
    {
        // structural signature __cil_value_4b07b3275df0d968fc083aeb54d2c7d9804554c9 bytes=118274: valuetype OpenRA.int2; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int v3 = OpenRA.Exts.WindingDirectionTest(c, d, a);
        int v7 = OpenRA.Exts.WindingDirectionTest(c, d, b);
        if (v3 == v7) {
            return false;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        int v11 = OpenRA.Exts.WindingDirectionTest(a, b, c);
        int v15 = OpenRA.Exts.WindingDirectionTest(a, b, d);
        int v16 = (v11 == v15 ? 1 : 0);
        return (v16 == 0);
    }

    public static bool HasModifier(OpenRA.Modifiers k, OpenRA.Modifiers mod)
    {
        // enum storage token=0x02000042 alias=__cil_enum_02000042 underlying=int: global::@OpenRA.@Modifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        return (unchecked(unchecked((int)(k)) & unchecked((int)(mod))) == unchecked((int)(mod)));
    }

    public static V GetOrAdd<K, V>(System.Collections.Generic.Dictionary<K, V> d, K k) where V : new()
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000C6 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_153bb982aabe8eb87c972036820a3b95c70fdd19 bytes=15128089021E001E01: class [System.Collections]System.Collections.Generic.Dictionary`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000C6; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_40b489c9c75882881ce52a2b95b554f031a94ad2 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000C6; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_generic_405d4da2205013abe66e51d0e03f2630b1065dda bytes=1E01: !!1; type-owner=0x00000000 method-owner=0x060000C6; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_405d4da2205013abe66e51d0e03f2630b1065dda v2 = __cil_methodspec_call_2B00002C();
        __cil_generic_405d4da2205013abe66e51d0e03f2630b1065dda v3 = __cil_methodspec_call_2B00002D(d, k, v2);
        return v3;
    }

    public static V GetOrAdd<K, V>(System.Collections.Generic.Dictionary<K, V> d, K k, V v)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000C7 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_aa42976fb23a69da04d8f66866dc89b787fc9939 bytes=15128089021E001E01: class [System.Collections]System.Collections.Generic.Dictionary`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000C7; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_b3db5841e6a7e1c142324fffc6bd349795a49959 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000C7; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_generic_834d9326b06726d5e47eb085218f82510f83071e bytes=1E01: !!1; type-owner=0x00000000 method-owner=0x060000C7; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        scoped ref __cil_generic_834d9326b06726d5e47eb085218f82510f83071e l0 = ref System.Runtime.CompilerServices.Unsafe.NullRef<__cil_generic_834d9326b06726d5e47eb085218f82510f83071e>();
        bool l1 = default;
        IL_0000: ;
        __cil_ref_aa42976fb23a69da04d8f66866dc89b787fc9939 v0 = d;
        __cil_generic_b3db5841e6a7e1c142324fffc6bd349795a49959 v1 = k;
        ref bool v2 = ref l1;
        ref __cil_generic_834d9326b06726d5e47eb085218f82510f83071e v3 = ref __cil_methodspec_call_2B00002E(v0, v1, ref v2);
        l0 = ref v3;
        int v4 = __cil_bool_load(l1);
        if (v4 != 0) {
            goto IL_0014;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        ref __cil_generic_834d9326b06726d5e47eb085218f82510f83071e v5 = ref l0;
        __cil_generic_834d9326b06726d5e47eb085218f82510f83071e v6 = v;
        v5 = v6;
        goto IL_0014;
        IL_0014: ;
        ref __cil_generic_834d9326b06726d5e47eb085218f82510f83071e v7 = ref l0;
        __cil_generic_834d9326b06726d5e47eb085218f82510f83071e v8 = v7;
        return v8;
    }

    public static V GetOrAdd<K, V>(System.Collections.Generic.Dictionary<K, V> d, K k, System.Func<K, V> createFn)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000C8 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_fe3e1b66d818a064e99ce89233eb9f43909a356d bytes=15128089021E001E01: class [System.Collections]System.Collections.Generic.Dictionary`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000C8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_be1b8b7bbdf918208d26033be07d73e4401b5d15 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000C8; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_58f9eb004731b1708a199e408c8a6725f62fabe9 bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000C8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_b94cd53a85196a4037e1bd1eda52cfba2a387419 bytes=1E01: !!1; type-owner=0x00000000 method-owner=0x060000C8; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_b94cd53a85196a4037e1bd1eda52cfba2a387419 l0 = default;
        IL_0000: ;
        __cil_ref_fe3e1b66d818a064e99ce89233eb9f43909a356d v0 = d;
        __cil_generic_be1b8b7bbdf918208d26033be07d73e4401b5d15 v1 = k;
        ref __cil_generic_b94cd53a85196a4037e1bd1eda52cfba2a387419 v2 = ref l0;
        int v3 = __cil_bool_load(__cil_callvirt_0A000146(v0, v1, ref v2));
        if (v3 != 0) {
            goto IL_001B;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        __cil_ref_fe3e1b66d818a064e99ce89233eb9f43909a356d v4 = d;
        __cil_generic_be1b8b7bbdf918208d26033be07d73e4401b5d15 v5 = k;
        __cil_ref_58f9eb004731b1708a199e408c8a6725f62fabe9 v6 = createFn;
        __cil_generic_be1b8b7bbdf918208d26033be07d73e4401b5d15 v7 = k;
        __cil_generic_b94cd53a85196a4037e1bd1eda52cfba2a387419 v8 = __cil_callvirt_0A000147(v6, v7);
        l0 = v8;
        __cil_callvirt_0A000148(v4, v5, v8);
        goto IL_001B;
        IL_001B: ;
        __cil_generic_b94cd53a85196a4037e1bd1eda52cfba2a387419 v9 = l0;
        return v9;
    }

    public static T GetOrAdd<T>(System.Collections.Generic.HashSet<T> @set, T value)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000C9 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_20e39a549ea997afa75ece151699fe7034aa67ba bytes=151280A5011E00: class [System.Collections]System.Collections.Generic.HashSet`1<!!0>; type-owner=0x00000000 method-owner=0x060000C9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_f3097a3a1e7fa931ab87918cbf210aef6d5af96c bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000C9; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_f3097a3a1e7fa931ab87918cbf210aef6d5af96c l0 = default;
        IL_0000: ;
        __cil_ref_20e39a549ea997afa75ece151699fe7034aa67ba v0 = @set;
        __cil_generic_f3097a3a1e7fa931ab87918cbf210aef6d5af96c v1 = value;
        ref __cil_generic_f3097a3a1e7fa931ab87918cbf210aef6d5af96c v2 = ref l0;
        int v3 = __cil_bool_load(__cil_callvirt_0A000149(v0, v1, ref v2));
        if (v3 != 0) {
            goto IL_0015;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        __cil_ref_20e39a549ea997afa75ece151699fe7034aa67ba v4 = @set;
        __cil_generic_f3097a3a1e7fa931ab87918cbf210aef6d5af96c v5 = value;
        l0 = v5;
        int v6 = __cil_bool_load(__cil_callvirt_0A00014A(v4, v5));
        goto IL_0015;
        IL_0015: ;
        __cil_generic_f3097a3a1e7fa931ab87918cbf210aef6d5af96c v7 = l0;
        return v7;
    }

    public static T GetOrAdd<T>(System.Collections.Generic.HashSet<T> @set, T value, System.Func<T, T> createFn)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000CA method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_6391a4771739352534759f0119d86a548b87b757 bytes=151280A5011E00: class [System.Collections]System.Collections.Generic.HashSet`1<!!0>; type-owner=0x00000000 method-owner=0x060000CA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_3e36351cd248f3b5caad17f0f703c122e0ca7a9a bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000CA; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_2de8f60f98ae3dffc87789ad5f58649c264503df bytes=151280C9021E001E00: class [System.Runtime]System.Func`2<!!0, !!0>; type-owner=0x00000000 method-owner=0x060000CA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_generic_3e36351cd248f3b5caad17f0f703c122e0ca7a9a l0 = default;
        IL_0000: ;
        __cil_ref_6391a4771739352534759f0119d86a548b87b757 v0 = @set;
        __cil_generic_3e36351cd248f3b5caad17f0f703c122e0ca7a9a v1 = value;
        ref __cil_generic_3e36351cd248f3b5caad17f0f703c122e0ca7a9a v2 = ref l0;
        int v3 = __cil_bool_load(__cil_callvirt_0A000149(v0, v1, ref v2));
        if (v3 != 0) {
            goto IL_001B;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        __cil_ref_6391a4771739352534759f0119d86a548b87b757 v4 = @set;
        __cil_ref_2de8f60f98ae3dffc87789ad5f58649c264503df v5 = createFn;
        __cil_generic_3e36351cd248f3b5caad17f0f703c122e0ca7a9a v6 = value;
        __cil_generic_3e36351cd248f3b5caad17f0f703c122e0ca7a9a v7 = __cil_callvirt_0A00014B(v5, v6);
        l0 = v7;
        int v8 = __cil_bool_load(__cil_callvirt_0A00014A(v4, v7));
        goto IL_001B;
        IL_001B: ;
        __cil_generic_3e36351cd248f3b5caad17f0f703c122e0ca7a9a v9 = l0;
        return v9;
    }

    public static int IndexOf<T>(T[] array, T value)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000CB method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_a8bae216cc4584ed1426c188c9c3668ebc261d9a bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000CB; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_42a15ecd8834fd03b3ac951b50356a51db52b01a bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000CB; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        int v2 = __cil_methodspec_call_2B00002F(array, value);
        return v2;
    }

    public static T FirstOrDefault<T>(T[] array, System.Predicate<T> match)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000CC method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_f93ac84759ed5995b28f282c0db556f08bccc0c0 bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000CC; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f083d776a0ec434630886135fee9d41e725bf470 bytes=15128131011E00: class [System.Runtime]System.Predicate`1<!!0>; type-owner=0x00000000 method-owner=0x060000CC; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_987b558d09901d40c4a5886fbfc97f7624ac037d bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000CC; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_987b558d09901d40c4a5886fbfc97f7624ac037d v2 = __cil_methodspec_call_2B000030(array, match);
        return v2;
    }

    public static T FirstOrDefault<T>(System.Collections.Generic.List<T> list, System.Predicate<T> match)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000CD method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_4b98a2e1e0356dd57d50540c68dbb90d2e24c6dd bytes=1512809D011E00: class [System.Collections]System.Collections.Generic.List`1<!!0>; type-owner=0x00000000 method-owner=0x060000CD; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_848f23f84a15f931f23dc4e5fccd5d91aa013967 bytes=15128131011E00: class [System.Runtime]System.Predicate`1<!!0>; type-owner=0x00000000 method-owner=0x060000CD; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_f71be17a2dc6d18f9c5e8fd2d4ae7aa78335e6f5 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000CD; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_f71be17a2dc6d18f9c5e8fd2d4ae7aa78335e6f5 v2 = __cil_callvirt_0A00014E(list, match);
        return v2;
    }

    public static T Random<T>(System.Collections.Generic.IEnumerable<T> ts, OpenRA.Support.MersenneTwister r)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000CE method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_485b261d3a2d8ca762190620ca24f515de3b42ac bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000CE; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_9150496638eb2d1ecf2065de87cee7fbeeec6fd2 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000CE; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_9150496638eb2d1ecf2065de87cee7fbeeec6fd2 v3 = __cil_methodspec_call_2B000031(ts, r, __cil_bool_store(1));
        return v3;
    }

    public static T RandomOrDefault<T>(System.Collections.Generic.IEnumerable<T> ts, OpenRA.Support.MersenneTwister r)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000CF method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_4d06692f447feec5b0edd391be556d38cd4592e6 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000CF; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_9818d70f765e3c50bafc2eda4f38d236177dd4c7 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000CF; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_9818d70f765e3c50bafc2eda4f38d236177dd4c7 v3 = __cil_methodspec_call_2B000031(ts, r, __cil_bool_store(0));
        return v3;
    }

    private static T Random<T>(System.Collections.Generic.IEnumerable<T> ts, OpenRA.Support.MersenneTwister r, bool throws)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D0 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_c93a3225d3171621e269f05884225d088fea0d61 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D0; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_ebe3dd4f05b3b56112b9c24eeee1b31b285ab384 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000D0; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047 bytes=15128115011E00: class [System.Runtime]System.Collections.Generic.IReadOnlyCollection`1<!!0>; type-owner=0x00000000 method-owner=0x060000D0; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b060cdf97cb6a3ccbc37f1e292ad7578d16cd70d bytes=1512809D011E00: class [System.Collections]System.Collections.Generic.List`1<!!0>; type-owner=0x00000000 method-owner=0x060000D0; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047 l0 = default;
        __cil_generic_ebe3dd4f05b3b56112b9c24eeee1b31b285ab384 l1 = default;
        IL_0000: ;
        __cil_ref_c93a3225d3171621e269f05884225d088fea0d61 v0 = ts;
        __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047 v1 = ((object)v0 as __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047);
        l0 = v1;
        __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047 v2 = l0;
        if (v2 is not null) {
            goto IL_0011;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        __cil_ref_c93a3225d3171621e269f05884225d088fea0d61 v3 = ts;
        __cil_ref_b060cdf97cb6a3ccbc37f1e292ad7578d16cd70d v4 = __cil_methodspec_call_2B000032(v3);
        l0 = v4;
        goto IL_0011;
        IL_0011: ;
        __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047 v5 = l0;
        int v6 = __cil_callvirt_0A000150(v5);
        if (v6 != 0) {
            goto IL_0036;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        int v7 = __cil_bool_load(throws);
        if (v7 == 0) {
            goto IL_002C;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        string v8 = __cil_ldstr_70000C98("Collection must not be empty.");
        string v9 = __cil_ldstr_70000CD4("ts");
        global::System.ArgumentException v10 = __cil_newobj_0A000151(v8, v9);
        throw v10;
        IL_002C: ;
        ref __cil_generic_ebe3dd4f05b3b56112b9c24eeee1b31b285ab384 v11 = ref l1;
        v11 = default;
        __cil_generic_ebe3dd4f05b3b56112b9c24eeee1b31b285ab384 v12 = l1;
        return v12;
        IL_0036: ;
        __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047 v13 = l0;
        global::OpenRA.Support.MersenneTwister v14 = r;
        __cil_ref_0c5b4ff51398018429ea52433d676f5c20d47047 v15 = l0;
        int v16 = __cil_callvirt_0A000150(v15);
        int v17 = __cil_callvirt_060007A1(v14, v16);
        __cil_generic_ebe3dd4f05b3b56112b9c24eeee1b31b285ab384 v18 = __cil_methodspec_call_2B000033(((__cil_ref_c93a3225d3171621e269f05884225d088fea0d61)(v13)), v17);
        return v18;
    }

    public static OpenRA.Primitives.Rectangle Union(System.Collections.Generic.IEnumerable<OpenRA.Primitives.Rectangle> rects)
    {
        // structural signature __cil_ref_2745b003c8defa48e628bba26e60343007031f0a bytes=1512808501118718: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 bytes=118718: valuetype OpenRA.Primitives.Rectangle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f bytes=151280A101118718: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype OpenRA.Primitives.Rectangle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 l1 = default;
        __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f l2 = default;
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 l3 = default;
        IL_0000: ;
        int v0 = 1;
        l0 = __cil_bool_store(v0);
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v1 = OpenRA.Primitives.Rectangle.Empty;
        l1 = v1;
        __cil_ref_2745b003c8defa48e628bba26e60343007031f0a v2 = rects;
        __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v3 = __cil_callvirt_0A00001C(v2);
        l2 = v3;
        try {
            IL_000F: ;
            goto IL_0029;
            IL_0011: ;
            __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v4 = l2;
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v5 = __cil_callvirt_0A000019(v4);
            l3 = v5;
            int v6 = __cil_bool_load(l0);
            if (v6 == 0) {
                goto IL_0021;
            } else {
                goto IL_001B;
            }
            IL_001B: ;
            int v7 = 0;
            l0 = __cil_bool_store(v7);
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v8 = l3;
            l1 = v8;
            goto IL_0029;
            IL_0021: ;
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v9 = l3;
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v10 = l1;
            __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v11 = OpenRA.Primitives.Rectangle.Union(v9, v10);
            l1 = v11;
            goto IL_0029;
            IL_0029: ;
            __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v12 = l2;
            int v13 = __cil_bool_load(__cil_callvirt_0A000018(v12));
            if (v13 != 0) {
                goto IL_0011;
            } else {
                goto IL_0031;
            }
            IL_0031: ;
            goto IL_003D;
        }
        finally {
            IL_0033: ;
            __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v14 = l2;
            if (v14 is null) {
                goto IL_003C;
            } else {
                goto IL_0036;
            }
            IL_0036: ;
            __cil_ref_b8b6ea941432b0ae0937826e8a26daac9ead124f v15 = l2;
            __cil_callvirt_0A000017(v15);
            goto IL_003C;
            IL_003C: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_003D: ;
        __cil_value_7e8a62945faf7f744e5ef6e791b8157c5f265c73 v16 = l1;
        return v16;
    }

    public static float Product(System.Collections.Generic.IEnumerable<float> xs)
    {
        // structural signature __cil_ref_ae221c615c049d1ef5eaff413178c2e3323ed841 bytes=15128085010C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<float32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 bytes=1512813D030C0C0C: class [System.Runtime]System.Func`3<float32, float32, float32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_ae221c615c049d1ef5eaff413178c2e3323ed841 s1_0 = default;
        __cil_F s1_1 = default;
        __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 s1_2 = default;
        __cil_ref_ae221c615c049d1ef5eaff413178c2e3323ed841 s2_0 = default;
        __cil_F s2_1 = default;
        __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 s2_2 = default;
        __cil_F v1 = __cil_ldc_r4_bits(0x3F800000u);
        __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 v2 = OpenRA.Exts.__name_3C3E63.__il_field_0400095A;
        if (v2 is not null) {
            __cil_ref_ae221c615c049d1ef5eaff413178c2e3323ed841 e0_2_0 = xs;
            __cil_F e0_2_1 = v1;
            __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 e0_2_2 = v2;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            s2_2 = e0_2_2;
            goto IL_0025;
        } else {
            __cil_ref_ae221c615c049d1ef5eaff413178c2e3323ed841 e0_1_0 = xs;
            __cil_F e0_1_1 = v1;
            __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 e0_1_2 = v2;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            s1_2 = e0_1_2;
            goto IL_000E;
        }
        IL_000E: ;
        global::OpenRA.Exts.__name_3C3E63 v3 = OpenRA.Exts.__name_3C3E63.__il_field_04000957;
        nint v4 = __cil_ldftn_06000F75;
        __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 v5 = __cil_newobj_0A000153(v3, v4);
        OpenRA.Exts.__name_3C3E63.__il_field_0400095A = v5;
        __cil_ref_ae221c615c049d1ef5eaff413178c2e3323ed841 e1_2_0 = s1_0;
        __cil_F e1_2_1 = s1_1;
        __cil_ref_59e81052d747716f8e1783ba6ad33799218e8fd7 e1_2_2 = v5;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        s2_2 = e1_2_2;
        IL_0025: ;
        __cil_F v6 = __cil_call_result_r4(__cil_methodspec_call_2B000034(s2_0, __cil_call_arg_r4(s2_1), s2_2));
        return __cil_return_r4(v6);
    }

    public static System.Collections.Generic.IEnumerable<T> SymmetricDifference<T>(System.Collections.Generic.IEnumerable<T> xs, System.Collections.Generic.IEnumerable<T> ys)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D3 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_00f383a54d2145553966e31398cf21a34268e5ce bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D3; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_00f383a54d2145553966e31398cf21a34268e5ce v2 = __cil_methodspec_call_2B000035(xs, ys);
        __cil_ref_00f383a54d2145553966e31398cf21a34268e5ce v5 = __cil_methodspec_call_2B000035(ys, xs);
        __cil_ref_00f383a54d2145553966e31398cf21a34268e5ce v6 = __cil_methodspec_call_2B000036(v2, v5);
        return v6;
    }

    public static System.Collections.Generic.IEnumerable<T> Iterate<T>(T t, System.Func<T, T> f)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D4 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_generic_fa76468c41288d0a81052c694a3692d035ebd8ea bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000D4; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_62a1ef7b9369580f163f93abf4a940d80e29ca6f bytes=151280C9021E001E00: class [System.Runtime]System.Func`2<!!0, !!0>; type-owner=0x00000000 method-owner=0x060000D4; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bf33e4ca304eef93cfbc86c5d4a0ff01a96d7348 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D4; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ac09c2c91d49b200014235c05b9cfdbd0a831695 bytes=15128964011E00: class OpenRA.Exts/<Iterate>d__26`1<!!0>; type-owner=0x00000000 method-owner=0x060000D4; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_ac09c2c91d49b200014235c05b9cfdbd0a831695 v1 = __cil_newobj_0A000156(-2);
        v1.__il_field_04000964 = t;
        v1.__il_field_04000966 = f;
        return v1;
    }

    public static T MinBy<T, U>(System.Collections.Generic.IEnumerable<T> ts, System.Func<T, U> selector)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D5 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_533e7987b9498f8b3d9cf45d39d11e659e46bc7b bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D5; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2e3ed6ae3b8c1323b7b355a98ca8198ec7d793c9 bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000D5; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_cb55e17f289ea6d618714f0fd69045563454de6b bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000D5; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_cb55e17f289ea6d618714f0fd69045563454de6b v4 = __cil_methodspec_call_2B000037(ts, selector, 1, __cil_bool_store(1));
        return v4;
    }

    public static T MaxBy<T, U>(System.Collections.Generic.IEnumerable<T> ts, System.Func<T, U> selector)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D6 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_439037bf2880d01e3ad39cf7896c7fb449905b84 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D6; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_535dab41ff30ac278c206fa10cf84633478c4a45 bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000D6; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_af36aaa799bbce7f61b5a724359c0635fac0b6bb bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000D6; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_af36aaa799bbce7f61b5a724359c0635fac0b6bb v4 = __cil_methodspec_call_2B000037(ts, selector, -1, __cil_bool_store(1));
        return v4;
    }

    public static T MinByOrDefault<T, U>(System.Collections.Generic.IEnumerable<T> ts, System.Func<T, U> selector)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D7 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_5a0a82375f0f5e74b4886d08a8ebdb90130dbdd2 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D7; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_224de573634b4f27c3c479e50bb6fb2d6f4621aa bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000D7; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_54f56d9de5aaa43e96d755ef92b9bd91325a90b1 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000D7; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_54f56d9de5aaa43e96d755ef92b9bd91325a90b1 v4 = __cil_methodspec_call_2B000037(ts, selector, 1, __cil_bool_store(0));
        return v4;
    }

    public static T MaxByOrDefault<T, U>(System.Collections.Generic.IEnumerable<T> ts, System.Func<T, U> selector)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D8 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_38cf274b21b2b41417781a8a76085c9c8f3b615c bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0f489526810bf0c7920c735c14ba5bdf2c9a79bf bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000D8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_3b6441791660c17648431b5147d308a2c9f3edb4 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000D8; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_generic_3b6441791660c17648431b5147d308a2c9f3edb4 v4 = __cil_methodspec_call_2B000037(ts, selector, -1, __cil_bool_store(0));
        return v4;
    }

    private static T CompareBy<T, U>(System.Collections.Generic.IEnumerable<T> ts, System.Func<T, U> selector, int modifier, bool throws)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000D9 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_48d8d1221472dab9ee3f92ae530a82671bf055de bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000D9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d4366a67896424309ce953f1ce5f95ea5e44c77f bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000D9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000D9; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_afb884d6a989fa846cf7f91fa3497d17a636013e bytes=15128135011E01: class [System.Collections]System.Collections.Generic.Comparer`1<!!1>; type-owner=0x00000000 method-owner=0x060000D9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 bytes=1E01: !!1; type-owner=0x00000000 method-owner=0x060000D9; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 bytes=151280A1011E00: class [System.Runtime]System.Collections.Generic.IEnumerator`1<!!0>; type-owner=0x00000000 method-owner=0x060000D9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_afb884d6a989fa846cf7f91fa3497d17a636013e l0 = default;
        __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c l1 = default;
        __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 l2 = default;
        __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 l3 = default;
        __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c l4 = default;
        __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c l5 = default;
        __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 l6 = default;
        IL_0000: ;
        __cil_ref_afb884d6a989fa846cf7f91fa3497d17a636013e v0 = __cil_reference_call_0A000159();
        l0 = v0;
        __cil_ref_48d8d1221472dab9ee3f92ae530a82671bf055de v1 = ts;
        __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 v2 = __cil_callvirt_0A00015A(v1);
        l3 = v2;
        try {
            IL_000D: ;
            __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 v3 = l3;
            int v4 = __cil_bool_load(__cil_callvirt_0A000018(v3));
            if (v4 != 0) {
                goto IL_0036;
            } else {
                goto IL_0015;
            }
            IL_0015: ;
            int v5 = __cil_bool_load(throws);
            if (v5 == 0) {
                goto IL_0028;
            } else {
                goto IL_0018;
            }
            IL_0018: ;
            string v6 = __cil_ldstr_70000C98("Collection must not be empty.");
            string v7 = __cil_ldstr_70000CD4("ts");
            global::System.ArgumentException v8 = __cil_newobj_0A000151(v6, v7);
            throw v8;
            IL_0028: ;
            ref __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v9 = ref l4;
            v9 = default;
            __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v10 = l4;
            l4 = v10;
            goto IL_0084;
            IL_0036: ;
            __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 v11 = l3;
            __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v12 = __cil_callvirt_0A00015B(v11);
            l1 = v12;
            __cil_ref_d4366a67896424309ce953f1ce5f95ea5e44c77f v13 = selector;
            __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v14 = l1;
            __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 v15 = __cil_callvirt_0A000147(v13, v14);
            l2 = v15;
            goto IL_006D;
            IL_0047: ;
            __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 v16 = l3;
            __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v17 = __cil_callvirt_0A00015B(v16);
            l5 = v17;
            __cil_ref_d4366a67896424309ce953f1ce5f95ea5e44c77f v18 = selector;
            __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v19 = l5;
            __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 v20 = __cil_callvirt_0A000147(v18, v19);
            l6 = v20;
            __cil_ref_afb884d6a989fa846cf7f91fa3497d17a636013e v21 = l0;
            __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 v22 = l6;
            __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 v23 = l2;
            int v24 = __cil_callvirt_0A00015C(v21, v22, v23);
            int v25 = modifier;
            int v26 = unchecked(v24 * v25);
            int v27 = 0;
            if (v26 >= v27) {
                goto IL_006D;
            } else {
                goto IL_0067;
            }
            IL_0067: ;
            __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v28 = l5;
            l1 = v28;
            __cil_generic_4f70e5a298a32635ddaf89c6d5ff20f0025d10c6 v29 = l6;
            l2 = v29;
            goto IL_006D;
            IL_006D: ;
            __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 v30 = l3;
            int v31 = __cil_bool_load(__cil_callvirt_0A000018(v30));
            if (v31 != 0) {
                goto IL_0047;
            } else {
                goto IL_0075;
            }
            IL_0075: ;
            __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v32 = l1;
            l4 = v32;
            goto IL_0084;
        }
        finally {
            IL_007A: ;
            __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 v33 = l3;
            if (v33 is null) {
                goto IL_0083;
            } else {
                goto IL_007D;
            }
            IL_007D: ;
            __cil_ref_99c56c33c59fd9b493c37849af4bfa3ea32cde43 v34 = l3;
            __cil_callvirt_0A000017(v34);
            goto IL_0083;
            IL_0083: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0084: ;
        __cil_generic_766cf4bb33c61b37b0f42416c17cc98c550bcb0c v35 = l4;
        return v35;
    }

    public static int NextPowerOf2(int v)
    {
        int v0 = v;
        v = unchecked(v0 - 1);
        int v3 = v;
        int v4 = v;
        int v6 = (v4 >> 1);
        v = unchecked(v3 | v6);
        int v8 = v;
        int v9 = v;
        int v11 = (v9 >> 2);
        v = unchecked(v8 | v11);
        int v13 = v;
        int v14 = v;
        int v16 = (v14 >> 4);
        v = unchecked(v13 | v16);
        int v18 = v;
        int v19 = v;
        int v21 = (v19 >> 8);
        v = unchecked(v18 | v21);
        int v23 = v;
        v = unchecked(v23 + 1);
        int v26 = v;
        return v26;
    }

    public static bool IsPowerOf2(int v)
    {
        return (unchecked(v & unchecked(v - 1)) == 0);
    }

    public static OpenRA.Primitives.Size NextPowerOf2(OpenRA.Primitives.Size s)
    {
        // structural signature __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd bytes=118724: valuetype OpenRA.Primitives.Size; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int v1 = s.Width;
        int v2 = OpenRA.Exts.NextPowerOf2(v1);
        int v4 = s.Height;
        int v5 = OpenRA.Exts.NextPowerOf2(v4);
        __cil_value_5d98256d18cf4c4f89d1b41406e17f048d0e29cd v6 = __cil_value_newobj_06000BFD(v2, v5);
        return v6;
    }

    public static int ISqrt(int number, OpenRA.Exts.ISqrtRoundMode round = 0)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [02, 16, 2F, 2B, 12, 00, 1F, 3E, 17, 28, C4, 00, 00, 0A, 12, 00, 72, DA, 0C, 00, 70, 28, C5, 00]
        // .code-bytes IL_0018: [00, 0A, 12, 00, 02, 28, 13, 00, 00, 2B, 12, 00, 28, C7, 00, 00, 0A, 73, 6E, 00, 00, 0A, 7A, 02]
        // .code-bytes IL_0030: [03, 28, DE, 00, 00, 06, 2A]
        // .local [0] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldarg.0 0
        // IL_0001: ldc.i4.0 0
        // IL_0002: bge.s IL_002F
        // IL_0004: ldloca.s 0
        // IL_0006: ldc.i4.s 62
        // IL_0008: ldc.i4.1 1
        // IL_0009: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_000E: ldloca.s 0
        // IL_0010: ldstr 0x70000CDA [65, 116, 116, 101, 109, 112, 116, 101, 100, 32, 116, 111, 32, 99, 97, 108, 99, 117, 108, 97, 116, 101, 32, 116, 104, 101, 32, 115, 113, 117, 97, 114, 101, 32, 114, 111, 111, 116, 32, 111, 102, 32, 97, 32, 110, 101, 103, 97, 116, 105, 118, 101, 32, 105, 110, 116, 101, 103, 101, 114, 58, 32] utf16-bytes=[41, 00, 74, 00, 74, 00, 65, 00, 6D, 00, 70, 00, 74, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 63, 00, 61, 00, 6C, 00, 63, 00, 75, 00, 6C, 00, 61, 00, 74, 00, 65, 00, 20, 00, 74, 00, 68, 00, 65, 00, 20, 00, 73, 00, 71, 00, 75, 00, 61, 00, 72, 00, 65, 00, 20, 00, 72, 00, 6F, 00, 6F, 00, 74, 00, 20, 00, 6F, 00, 66, 00, 20, 00, 61, 00, 20, 00, 6E, 00, 65, 00, 67, 00, 61, 00, 74, 00, 69, 00, 76, 00, 65, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_0015: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_001A: ldloca.s 0
        // IL_001C: ldarg.0 0
        // IL_001D: call 0x2B000013 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_0022: ldloca.s 0
        // IL_0024: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0029: newobj 0x0A00006E [System.Runtime]System.InvalidOperationException::.ctor
        // IL_002E: throw 
        // IL_002F: ldarg.0 0
        // IL_0030: ldarg.1 1
        // IL_0031: call 0x060000DE OpenRA.Exts::ISqrt
        // IL_0036: ret 
    }

    public static uint ISqrt(uint number, OpenRA.Exts.ISqrtRoundMode round = 0)
    {
        // enum storage token=0x02000255 alias=__cil_enum_02000255 underlying=int: global::@OpenRA.@Exts.@ISqrtRoundMode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        uint l0 = default;
        uint l1 = default;
        uint l2 = default;
        l0 = unchecked((uint)(1073741824));
        l1 = unchecked((uint)(0));
        int v2 = unchecked((int)(number));
        l2 = unchecked((uint)(v2));
        goto IL_0010;
        IL_000C: ;
        int v3 = unchecked((int)(l0));
        int v5 = (v3 >>> 2);
        l0 = unchecked((uint)(v5));
        IL_0010: ;
        int v6 = unchecked((int)(l0));
        int v7 = unchecked((int)(number));
        if (unchecked((uint)v6) > unchecked((uint)v7)) {
            goto IL_000C;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        goto IL_0030;
        IL_0016: ;
        int v8 = unchecked((int)(l1));
        int v9 = unchecked((int)(l0));
        int v10 = unchecked(v8 + v9);
        int v11 = unchecked((int)(l2));
        if (unchecked((uint)v10) > unchecked((uint)v11)) {
            goto IL_0028;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        int v12 = unchecked((int)(l2));
        int v13 = unchecked((int)(l1));
        int v14 = unchecked((int)(l0));
        int v15 = unchecked(v13 + v14);
        int v16 = unchecked(v12 - v15);
        l2 = unchecked((uint)(v16));
        int v17 = unchecked((int)(l1));
        int v19 = unchecked((int)(l0));
        int v20 = unchecked(2 * v19);
        int v21 = unchecked(v17 + v20);
        l1 = unchecked((uint)(v21));
        IL_0028: ;
        int v22 = unchecked((int)(l1));
        int v24 = (v22 >>> 1);
        l1 = unchecked((uint)(v24));
        int v25 = unchecked((int)(l0));
        int v27 = (v25 >>> 2);
        l0 = unchecked((uint)(v27));
        IL_0030: ;
        int v28 = unchecked((int)(l0));
        if (v28 != 0) {
            goto IL_0016;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        int v29 = unchecked((int)(round));
        if (unchecked((uint)v29) != unchecked((uint)1)) {
            goto IL_0041;
        } else {
            goto IL_0037;
        }
        IL_0037: ;
        int v31 = unchecked((int)(l2));
        int v32 = unchecked((int)(l1));
        if (unchecked((uint)v31) <= unchecked((uint)v32)) {
            goto IL_0041;
        } else {
            goto IL_003B;
        }
        IL_003B: ;
        int v33 = unchecked((int)(l1));
        int v35 = unchecked(v33 + 1);
        l1 = unchecked((uint)(v35));
        goto IL_004F;
        IL_0041: ;
        int v36 = unchecked((int)(round));
        if (unchecked((uint)v36) != unchecked((uint)2)) {
            goto IL_004F;
        } else {
            goto IL_0045;
        }
        IL_0045: ;
        int v38 = unchecked((int)(l1));
        int v39 = unchecked((int)(l1));
        int v40 = unchecked(v38 * v39);
        int v41 = unchecked((int)(number));
        if (unchecked((uint)v40) >= unchecked((uint)v41)) {
            goto IL_004F;
        } else {
            goto IL_004B;
        }
        IL_004B: ;
        int v42 = unchecked((int)(l1));
        int v44 = unchecked(v42 + 1);
        l1 = unchecked((uint)(v44));
        IL_004F: ;
        int v45 = unchecked((int)(l1));
        return unchecked((uint)(v45));
    }

    public static long ISqrt(long number, OpenRA.Exts.ISqrtRoundMode round = 0)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [02, 16, 6A, 2F, 2B, 12, 00, 1F, 3E, 17, 28, C4, 00, 00, 0A, 12, 00, 72, DA, 0C, 00, 70, 28, C5]
        // .code-bytes IL_0018: [00, 00, 0A, 12, 00, 02, 28, 38, 00, 00, 2B, 12, 00, 28, C7, 00, 00, 0A, 73, 6E, 00, 00, 0A, 7A]
        // .code-bytes IL_0030: [02, 03, 28, E0, 00, 00, 06, 2A]
        // .local [0] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldarg.0 0
        // IL_0001: ldc.i4.0 0
        // IL_0002: conv.i8 
        // IL_0003: bge.s IL_0030
        // IL_0005: ldloca.s 0
        // IL_0007: ldc.i4.s 62
        // IL_0009: ldc.i4.1 1
        // IL_000A: call 0x0A0000C4 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_000F: ldloca.s 0
        // IL_0011: ldstr 0x70000CDA [65, 116, 116, 101, 109, 112, 116, 101, 100, 32, 116, 111, 32, 99, 97, 108, 99, 117, 108, 97, 116, 101, 32, 116, 104, 101, 32, 115, 113, 117, 97, 114, 101, 32, 114, 111, 111, 116, 32, 111, 102, 32, 97, 32, 110, 101, 103, 97, 116, 105, 118, 101, 32, 105, 110, 116, 101, 103, 101, 114, 58, 32] utf16-bytes=[41, 00, 74, 00, 74, 00, 65, 00, 6D, 00, 70, 00, 74, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 63, 00, 61, 00, 6C, 00, 63, 00, 75, 00, 6C, 00, 61, 00, 74, 00, 65, 00, 20, 00, 74, 00, 68, 00, 65, 00, 20, 00, 73, 00, 71, 00, 75, 00, 61, 00, 72, 00, 65, 00, 20, 00, 72, 00, 6F, 00, 6F, 00, 74, 00, 20, 00, 6F, 00, 66, 00, 20, 00, 61, 00, 20, 00, 6E, 00, 65, 00, 67, 00, 61, 00, 74, 00, 69, 00, 76, 00, 65, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_0016: call 0x0A0000C5 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_001B: ldloca.s 0
        // IL_001D: ldarg.0 0
        // IL_001E: call 0x2B000038 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int64>
        // IL_0023: ldloca.s 0
        // IL_0025: call 0x0A0000C7 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_002A: newobj 0x0A00006E [System.Runtime]System.InvalidOperationException::.ctor
        // IL_002F: throw 
        // IL_0030: ldarg.0 0
        // IL_0031: ldarg.1 1
        // IL_0032: call 0x060000E0 OpenRA.Exts::ISqrt
        // IL_0037: ret 
    }

    public static ulong ISqrt(ulong number, OpenRA.Exts.ISqrtRoundMode round = 0)
    {
        // enum storage token=0x02000255 alias=__cil_enum_02000255 underlying=int: global::@OpenRA.@Exts.@ISqrtRoundMode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ulong l0 = default;
        ulong l1 = default;
        ulong l2 = default;
        l0 = unchecked((ulong)(4611686018427387904L));
        long v2 = unchecked((long)(0));
        l1 = unchecked((ulong)(v2));
        long v3 = unchecked((long)(number));
        l2 = unchecked((ulong)(v3));
        goto IL_0015;
        IL_0011: ;
        long v4 = unchecked((long)(l0));
        long v6 = (v4 >>> 2);
        l0 = unchecked((ulong)(v6));
        IL_0015: ;
        long v7 = unchecked((long)(l0));
        long v8 = unchecked((long)(number));
        if (unchecked((ulong)v7) > unchecked((ulong)v8)) {
            goto IL_0011;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        goto IL_0036;
        IL_001B: ;
        long v9 = unchecked((long)(l1));
        long v10 = unchecked((long)(l0));
        long v11 = unchecked(v9 + v10);
        long v12 = unchecked((long)(l2));
        if (unchecked((ulong)v11) > unchecked((ulong)v12)) {
            goto IL_002E;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        long v13 = unchecked((long)(l2));
        long v14 = unchecked((long)(l1));
        long v15 = unchecked((long)(l0));
        long v16 = unchecked(v14 + v15);
        long v17 = unchecked(v13 - v16);
        l2 = unchecked((ulong)(v17));
        long v18 = unchecked((long)(l1));
        long v20 = unchecked((long)(2));
        long v21 = unchecked((long)(l0));
        long v22 = unchecked(v20 * v21);
        long v23 = unchecked(v18 + v22);
        l1 = unchecked((ulong)(v23));
        IL_002E: ;
        long v24 = unchecked((long)(l1));
        long v26 = (v24 >>> 1);
        l1 = unchecked((ulong)(v26));
        long v27 = unchecked((long)(l0));
        long v29 = (v27 >>> 2);
        l0 = unchecked((ulong)(v29));
        IL_0036: ;
        long v30 = unchecked((long)(l0));
        if (v30 != 0) {
            goto IL_001B;
        } else {
            goto IL_0039;
        }
        IL_0039: ;
        int v31 = unchecked((int)(round));
        if (unchecked((uint)v31) != unchecked((uint)1)) {
            goto IL_0048;
        } else {
            goto IL_003D;
        }
        IL_003D: ;
        long v33 = unchecked((long)(l2));
        long v34 = unchecked((long)(l1));
        if (unchecked((ulong)v33) <= unchecked((ulong)v34)) {
            goto IL_0048;
        } else {
            goto IL_0041;
        }
        IL_0041: ;
        long v35 = unchecked((long)(l1));
        long v37 = unchecked((long)(1));
        long v38 = unchecked(v35 + v37);
        l1 = unchecked((ulong)(v38));
        goto IL_0057;
        IL_0048: ;
        int v39 = unchecked((int)(round));
        if (unchecked((uint)v39) != unchecked((uint)2)) {
            goto IL_0057;
        } else {
            goto IL_004C;
        }
        IL_004C: ;
        long v41 = unchecked((long)(l1));
        long v42 = unchecked((long)(l1));
        long v43 = unchecked(v41 * v42);
        long v44 = unchecked((long)(number));
        if (unchecked((ulong)v43) >= unchecked((ulong)v44)) {
            goto IL_0057;
        } else {
            goto IL_0052;
        }
        IL_0052: ;
        long v45 = unchecked((long)(l1));
        long v47 = unchecked((long)(1));
        long v48 = unchecked(v45 + v47);
        l1 = unchecked((ulong)(v48));
        IL_0057: ;
        long v49 = unchecked((long)(l1));
        return unchecked((ulong)(v49));
    }

    public static int MultiplyBySqrtTwo(short number)
    {
        int v0 = unchecked((int)(number));
        int v2 = unchecked(v0 * 46341);
        int v4 = unchecked(v2 / 32768);
        return v4;
    }

    public static int MultiplyBySqrtTwoOverTwo(int number)
    {
        long v1 = unchecked((long)(number));
        long v3 = unchecked((long)(23170));
        long v4 = unchecked(v1 * v3);
        long v6 = unchecked((long)(32768));
        long v7 = unchecked(v4 / v6);
        return unchecked((int)(v7));
    }

    public static int IntegerDivisionRoundingAwayFromZero(int dividend, int divisor)
    {
        int l0 = default;
        int l1 = default;
        int s3_0 = default;
        int s4_0 = default;
        int s5_0 = default;
        int s5_1 = default;
        IL_0000: ;
        int v0 = dividend;
        int v1 = divisor;
        ref int v2 = ref l1;
        int v3 = System.Math.DivRem(v0, v1, ref v2);
        l0 = v3;
        int v4 = l1;
        if (v4 != 0) {
            goto IL_000F;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v5 = l0;
        return v5;
        IL_000F: ;
        int v6 = l0;
        int v7 = dividend;
        int v8 = System.Math.Sign(v7);
        int v9 = divisor;
        int v10 = System.Math.Sign(v9);
        if (v8 == v10) {
            int e2_4_0 = v6;
            s4_0 = e2_4_0;
            goto IL_0021;
        } else {
            int e2_3_0 = v6;
            s3_0 = e2_3_0;
            goto IL_001E;
        }
        IL_001E: ;
        int v11 = -1;
        int e3_5_0 = s3_0;
        int e3_5_1 = v11;
        s5_0 = e3_5_0;
        s5_1 = e3_5_1;
        goto IL_0022;
        IL_0021: ;
        int v12 = 1;
        int e4_5_0 = s4_0;
        int e4_5_1 = v12;
        s5_0 = e4_5_0;
        s5_1 = e4_5_1;
        goto IL_0022;
        IL_0022: ;
        int v13 = unchecked(s5_0 + s5_1);
        return v13;
    }

    public static string JoinWith<T>(System.Collections.Generic.IEnumerable<T> ts, string j)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000E4 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_5219d81c4461c99111d1030bc37d9de69be37881 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000E4; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v2 = __cil_methodspec_call_2B000039(j, ts);
        return v2;
    }

    public static System.Collections.Generic.IEnumerable<T> Append<T>(System.Collections.Generic.IEnumerable<T> ts, T[] moreTs)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000E5 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_417f63796f86c8812e72aea9bc6458551a011bc1 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000E5; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_02a4f6edbec53236837d5b8d914935e93b2c5b12 bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000E5; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_417f63796f86c8812e72aea9bc6458551a011bc1 v2 = __cil_methodspec_call_2B000036(ts, ((__cil_ref_417f63796f86c8812e72aea9bc6458551a011bc1)(moreTs)));
        return v2;
    }

    public static System.Collections.Generic.IEnumerable<T> Exclude<T>(System.Collections.Generic.IEnumerable<T> ts, T[] exclusions)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000E6 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_7a10c4df9a79edc34a0c169d419579fbda9273c2 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000E6; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a3af20d9f75dbafe006160f879a516df32b3a9bd bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000E6; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_7a10c4df9a79edc34a0c169d419579fbda9273c2 v2 = __cil_methodspec_call_2B000035(ts, ((__cil_ref_7a10c4df9a79edc34a0c169d419579fbda9273c2)(exclusions)));
        return v2;
    }

    public static System.Collections.Generic.HashSet<T> ToHashSet<T>(System.Collections.Generic.IEnumerable<T> source)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000E7 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_daab3b89b4b0c9e1c8a36290bfccf3f4b52ab931 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000E7; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c77bc1793755e36cc267b4e2ea71170e60466819 bytes=151280A5011E00: class [System.Collections]System.Collections.Generic.HashSet`1<!!0>; type-owner=0x00000000 method-owner=0x060000E7; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_c77bc1793755e36cc267b4e2ea71170e60466819 v1 = __cil_newobj_0A00015F(source);
        return v1;
    }

    public static System.Collections.Generic.Dictionary<TKey, TSource> ToDictionaryWithConflictLog<TSource, TKey>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, TKey> keySelector, string debugName, System.Func<TKey, string> logKey, System.Func<TSource, string> logValue)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000E8 method-arity=2; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_eccc00f77f07bbbe56a4f8641a767b41b5180c2c bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000E8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9b9ff8604e37a723bc6d16538e11a62499c7b6b6 bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000E8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_322355d9033bac78393c971bf96349920e0f0a3f bytes=151280C9021E010E: class [System.Runtime]System.Func`2<!!1, string>; type-owner=0x00000000 method-owner=0x060000E8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_1a8b621f439965b077c872a147f2d14dfe2b0629 bytes=151280C9021E000E: class [System.Runtime]System.Func`2<!!0, string>; type-owner=0x00000000 method-owner=0x060000E8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e361d7442f8327406986d1e11056167e759c65b1 bytes=15128089021E011E00: class [System.Collections]System.Collections.Generic.Dictionary`2<!!1, !!0>; type-owner=0x00000000 method-owner=0x060000E8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb bytes=151280C9021E001E00: class [System.Runtime]System.Func`2<!!0, !!0>; type-owner=0x00000000 method-owner=0x060000E8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_42dcdc61cd96fa13d266b2a01b21ac6c04548306 bytes=1512895C021E001E01: class OpenRA.Exts/<>c__47`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000E8; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_eccc00f77f07bbbe56a4f8641a767b41b5180c2c s1_0 = default;
        __cil_ref_9b9ff8604e37a723bc6d16538e11a62499c7b6b6 s1_1 = default;
        __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb s1_2 = default;
        __cil_ref_eccc00f77f07bbbe56a4f8641a767b41b5180c2c s2_0 = default;
        __cil_ref_9b9ff8604e37a723bc6d16538e11a62499c7b6b6 s2_1 = default;
        __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb s2_2 = default;
        __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb v2 = __cil_ldsfld_0A000160();
        if (v2 is not null) {
            __cil_ref_eccc00f77f07bbbe56a4f8641a767b41b5180c2c e0_2_0 = source;
            __cil_ref_9b9ff8604e37a723bc6d16538e11a62499c7b6b6 e0_2_1 = keySelector;
            __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb e0_2_2 = v2;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            s2_2 = e0_2_2;
            goto IL_0021;
        } else {
            __cil_ref_eccc00f77f07bbbe56a4f8641a767b41b5180c2c e0_1_0 = source;
            __cil_ref_9b9ff8604e37a723bc6d16538e11a62499c7b6b6 e0_1_1 = keySelector;
            __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb e0_1_2 = v2;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            s1_2 = e0_1_2;
            goto IL_000A;
        }
        IL_000A: ;
        __cil_ref_42dcdc61cd96fa13d266b2a01b21ac6c04548306 v3 = __cil_ldsfld_0A000161();
        nint v4 = __cil_ldftn_0A000162;
        __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb v5 = __cil_newobj_0A000163(v3, v4);
        __cil_stsfld_0A000160(v5);
        __cil_ref_eccc00f77f07bbbe56a4f8641a767b41b5180c2c e1_2_0 = s1_0;
        __cil_ref_9b9ff8604e37a723bc6d16538e11a62499c7b6b6 e1_2_1 = s1_1;
        __cil_ref_6eeff17bca79017a2d2bc17c7fb70f0c5b95ecbb e1_2_2 = v5;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        s2_2 = e1_2_2;
        IL_0021: ;
        __cil_ref_e361d7442f8327406986d1e11056167e759c65b1 v9 = __cil_methodspec_call_2B00003A(s2_0, s2_1, s2_2, debugName, logKey, logValue);
        return v9;
    }

    public static System.Collections.Generic.Dictionary<TKey, TElement> ToDictionaryWithConflictLog<TSource, TKey, TElement>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, TKey> keySelector, System.Func<TSource, TElement> elementSelector, string debugName, System.Func<TKey, string> logKey = null, System.Func<TElement, string> logValue = null)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000E9 method-arity=3; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_89f64f6d23b45639b87d672e7913b9199d474bf6 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000E9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5ea9f9a24fd580cfaf765392d29dbaf9425873d2 bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000E9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8d80edd64d52fb53fbed3efc1ba5c6d42f5a7d33 bytes=151280C9021E001E02: class [System.Runtime]System.Func`2<!!0, !!2>; type-owner=0x00000000 method-owner=0x060000E9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e802afbbc09747049aafecf5db0ce18dad1af7e7 bytes=151280C9021E010E: class [System.Runtime]System.Func`2<!!1, string>; type-owner=0x00000000 method-owner=0x060000E9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_cfa0a18caf2a88671d930049f0d1cb315145579a bytes=151280C9021E020E: class [System.Runtime]System.Func`2<!!2, string>; type-owner=0x00000000 method-owner=0x060000E9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a893273c78bfdfca6c73232ece66a12814eba29f bytes=15128089021E011E02: class [System.Collections]System.Collections.Generic.Dictionary`2<!!1, !!2>; type-owner=0x00000000 method-owner=0x060000E9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_a893273c78bfdfca6c73232ece66a12814eba29f v0 = __cil_newobj_0A000164();
        __cil_methodspec_call_2B00003B(source, keySelector, elementSelector, debugName, v0, logKey, logValue);
        return v0;
    }

    public static void IntoDictionaryWithConflictLog<TSource, TKey, TElement>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, TKey> keySelector, System.Func<TSource, TElement> elementSelector, string debugName, System.Collections.Generic.Dictionary<TKey, TElement> output, System.Func<TKey, string> logKey = null, System.Func<TElement, string> logValue = null)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000EA method-arity=3; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd bytes=15128085010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 bytes=118415: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_83e976fa15210e8accfe345ad77f6e4568398c75 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8cc8ff8e9ace6445e93604d67f48d47ddc24b125 bytes=151280C9021E001E01: class [System.Runtime]System.Func`2<!!0, !!1>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_18bba2cc596f119a1d18005c3119a961bad4293b bytes=151280C9021E001E02: class [System.Runtime]System.Func`2<!!0, !!2>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0a85c100d6e62d8ac93adbb1d0c95c210237f194 bytes=15128089021E011E02: class [System.Collections]System.Collections.Generic.Dictionary`2<!!1, !!2>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 bytes=151280C9021E010E: class [System.Runtime]System.Func`2<!!1, string>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 bytes=151280C9021E020E: class [System.Runtime]System.Func`2<!!2, string>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 bytes=15128089021E011512809D010E: class [System.Collections]System.Collections.Generic.Dictionary`2<!!1, class [System.Collections]System.Collections.Generic.List`1<string>>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_30230403287081bcaba2ee86f71422bed51ea3f7 bytes=15128119011E00: class [System.Runtime]System.Collections.Generic.ICollection`1<!!0>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b39cb6b12849a21eec918ad81bad19eb2e8ff5e6 bytes=151280A1011E00: class [System.Runtime]System.Collections.Generic.IEnumerator`1<!!0>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_329e389f73005afeb80e6e96dfc2ebfce923363c bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 bytes=1E01: !!1; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_generic_bd6eb603db169f64b2652bbe885348db38723201 bytes=1E02: !!2; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_8764ddf6889a57624abb9f43ca57a529df8bb0fd bytes=1512809D010E: class [System.Collections]System.Collections.Generic.List`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_437b35f03d2560a78ff20e22e7283f4afb1ed046 bytes=15118139021E011512809D010E: valuetype [System.Collections]System.Collections.Generic.Dictionary`2/Enumerator<!!1, class [System.Collections]System.Collections.Generic.List`1<string>>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_e345e3bd60ccf9b6342f88596d0da66c73d4d02e bytes=15118111021E011512809D010E: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<!!1, class [System.Collections]System.Collections.Generic.List`1<string>>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_676d4d388cbc6556ad137d69af102dc80dc347cf bytes=15128960031E001E011E02: class OpenRA.Exts/<>c__49`3<!!0, !!1, !!2>; type-owner=0x00000000 method-owner=0x060000EA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 l0 = default;
        int l1 = default;
        __cil_ref_30230403287081bcaba2ee86f71422bed51ea3f7 l2 = default;
        __cil_ref_b39cb6b12849a21eec918ad81bad19eb2e8ff5e6 l3 = default;
        __cil_generic_329e389f73005afeb80e6e96dfc2ebfce923363c l4 = default;
        __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 l5 = default;
        __cil_generic_bd6eb603db169f64b2652bbe885348db38723201 l6 = default;
        __cil_ref_8764ddf6889a57624abb9f43ca57a529df8bb0fd l7 = default;
        __cil_type_01000038 l8 = default;
        __cil_value_437b35f03d2560a78ff20e22e7283f4afb1ed046 l9 = default;
        __cil_value_e345e3bd60ccf9b6342f88596d0da66c73d4d02e l10 = default;
        __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 s2_0 = default;
        __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 s3_0 = default;
        __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 s6_0 = default;
        __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 s7_0 = default;
        int s11_0 = default;
        IL_0000: ;
        __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 v0 = logKey;
        if (v0 is not null) {
            goto IL_0025;
        } else {
            goto IL_0004;
        }
        IL_0004: ;
        __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 v1 = __cil_ldsfld_0A000165();
        if (v1 is not null) {
            __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 e1_3_0 = v1;
            s3_0 = e1_3_0;
            goto IL_0023;
        } else {
            __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 e1_2_0 = v1;
            s2_0 = e1_2_0;
            goto IL_000C;
        }
        IL_000C: ;
        __cil_ref_676d4d388cbc6556ad137d69af102dc80dc347cf v2 = __cil_ldsfld_0A000166();
        nint v3 = __cil_ldftn_0A000167;
        __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 v4 = __cil_newobj_0A000168(v2, v3);
        __cil_stsfld_0A000165(v4);
        __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 e2_3_0 = v4;
        s3_0 = e2_3_0;
        goto IL_0023;
        IL_0023: ;
        logKey = s3_0;
        goto IL_0025;
        IL_0025: ;
        __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 v5 = logValue;
        if (v5 is not null) {
            goto IL_004A;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 v6 = __cil_ldsfld_0A000169();
        if (v6 is not null) {
            __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 e5_7_0 = v6;
            s7_0 = e5_7_0;
            goto IL_0048;
        } else {
            __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 e5_6_0 = v6;
            s6_0 = e5_6_0;
            goto IL_0031;
        }
        IL_0031: ;
        __cil_ref_676d4d388cbc6556ad137d69af102dc80dc347cf v7 = __cil_ldsfld_0A000166();
        nint v8 = __cil_ldftn_0A00016A;
        __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 v9 = __cil_newobj_0A00016B(v7, v8);
        __cil_stsfld_0A000169(v9);
        __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 e6_7_0 = v9;
        s7_0 = e6_7_0;
        goto IL_0048;
        IL_0048: ;
        logValue = s7_0;
        goto IL_004A;
        IL_004A: ;
        l0 = null;
        __cil_ref_83e976fa15210e8accfe345ad77f6e4568398c75 v10 = source;
        __cil_ref_30230403287081bcaba2ee86f71422bed51ea3f7 v11 = ((object)v10 as __cil_ref_30230403287081bcaba2ee86f71422bed51ea3f7);
        l2 = v11;
        __cil_ref_30230403287081bcaba2ee86f71422bed51ea3f7 v12 = l2;
        if (v12 is not null) {
            goto IL_0059;
        } else {
            goto IL_0056;
        }
        IL_0056: ;
        int v13 = 0;
        int e9_11_0 = v13;
        s11_0 = e9_11_0;
        goto IL_005F;
        IL_0059: ;
        __cil_ref_30230403287081bcaba2ee86f71422bed51ea3f7 v14 = l2;
        int v15 = __cil_callvirt_0A00016C(v14);
        int e10_11_0 = v15;
        s11_0 = e10_11_0;
        goto IL_005F;
        IL_005F: ;
        l1 = s11_0;
        __cil_ref_0a85c100d6e62d8ac93adbb1d0c95c210237f194 v16 = output;
        __cil_callvirt_0A00016D(v16);
        __cil_ref_0a85c100d6e62d8ac93adbb1d0c95c210237f194 v17 = output;
        int v18 = l1;
        int v19 = __cil_callvirt_0A00016E(v17, v18);
        __cil_ref_83e976fa15210e8accfe345ad77f6e4568398c75 v20 = source;
        __cil_ref_b39cb6b12849a21eec918ad81bad19eb2e8ff5e6 v21 = __cil_callvirt_0A00015A(v20);
        l3 = v21;
        try {
            IL_0077: ;
            goto IL_010B;
            IL_007C: ;
            __cil_ref_b39cb6b12849a21eec918ad81bad19eb2e8ff5e6 v22 = l3;
            __cil_generic_329e389f73005afeb80e6e96dfc2ebfce923363c v23 = __cil_callvirt_0A00015B(v22);
            l4 = v23;
            __cil_ref_8cc8ff8e9ace6445e93604d67f48d47ddc24b125 v24 = keySelector;
            __cil_generic_329e389f73005afeb80e6e96dfc2ebfce923363c v25 = l4;
            __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 v26 = __cil_callvirt_0A000147(v24, v25);
            l5 = v26;
            __cil_ref_18bba2cc596f119a1d18005c3119a961bad4293b v27 = elementSelector;
            __cil_generic_329e389f73005afeb80e6e96dfc2ebfce923363c v28 = l4;
            __cil_generic_bd6eb603db169f64b2652bbe885348db38723201 v29 = __cil_callvirt_0A00016F(v27, v28);
            l6 = v29;
            __cil_value_da9de212db54a27aa3d15de1dddb02b7b6e84c44 v30 = __cil_ldtoken_type_1B0000BC;
            __cil_type_01000026 v31 = System.Type.GetTypeFromHandle(v30);
            int v32 = __cil_bool_load(__cil_memberref_call_0A000170(v31));
            if (v32 != 0) {
                goto IL_00B2;
            } else {
                goto IL_00A9;
            }
            IL_00A9: ;
            __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 v33 = l5;
            object v34 = ((object)((__cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09)(v33)));
            if (v34 is null) {
                goto IL_010B;
            } else {
                goto IL_00B2;
            }
            IL_00B2: ;
            __cil_ref_0a85c100d6e62d8ac93adbb1d0c95c210237f194 v35 = output;
            __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 v36 = l5;
            __cil_generic_bd6eb603db169f64b2652bbe885348db38723201 v37 = l6;
            int v38 = __cil_bool_load(__cil_callvirt_0A000171(v35, v36, v37));
            if (v38 != 0) {
                goto IL_010B;
            } else {
                goto IL_00BF;
            }
            IL_00BF: ;
            __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 v39 = l0;
            if (v39 is not null) {
                goto IL_00C8;
            } else {
                goto IL_00C2;
            }
            IL_00C2: ;
            __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 v40 = __cil_newobj_0A000172();
            l0 = v40;
            goto IL_00C8;
            IL_00C8: ;
            __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 v41 = l0;
            __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 v42 = l5;
            ref __cil_ref_8764ddf6889a57624abb9f43ca57a529df8bb0fd v43 = ref l7;
            int v44 = __cil_bool_load(__cil_callvirt_0A000173(v41, v42, ref v43));
            if (v44 != 0) {
                goto IL_00FB;
            } else {
                goto IL_00D4;
            }
            IL_00D4: ;
            __cil_ref_8764ddf6889a57624abb9f43ca57a529df8bb0fd v45 = __cil_newobj_0A000174();
            __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 v46 = logValue;
            __cil_ref_0a85c100d6e62d8ac93adbb1d0c95c210237f194 v47 = output;
            __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 v48 = l5;
            __cil_generic_bd6eb603db169f64b2652bbe885348db38723201 v49 = __cil_callvirt_0A000175(v47, v48);
            string v50 = __cil_callvirt_0A000176(v46, v49);
            __cil_callvirt_0A000177(v45, v50);
            l7 = v45;
            __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 v51 = l0;
            __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 v52 = l5;
            __cil_ref_8764ddf6889a57624abb9f43ca57a529df8bb0fd v53 = l7;
            __cil_callvirt_0A000178(v51, v52, v53);
            goto IL_00FB;
            IL_00FB: ;
            __cil_ref_8764ddf6889a57624abb9f43ca57a529df8bb0fd v54 = l7;
            __cil_ref_f2fc8dfd2ea0d0f1237c64f8bf35ec65cbbe8529 v55 = logValue;
            __cil_generic_bd6eb603db169f64b2652bbe885348db38723201 v56 = l6;
            string v57 = __cil_callvirt_0A000176(v55, v56);
            __cil_callvirt_0A000177(v54, v57);
            goto IL_010B;
            IL_010B: ;
            __cil_ref_b39cb6b12849a21eec918ad81bad19eb2e8ff5e6 v58 = l3;
            int v59 = __cil_bool_load(__cil_callvirt_0A000018(v58));
            if (v59 != 0) {
                goto IL_007C;
            } else {
                goto IL_0116;
            }
            IL_0116: ;
            goto IL_0122;
        }
        finally {
            IL_0118: ;
            __cil_ref_b39cb6b12849a21eec918ad81bad19eb2e8ff5e6 v60 = l3;
            if (v60 is null) {
                goto IL_0121;
            } else {
                goto IL_011B;
            }
            IL_011B: ;
            __cil_ref_b39cb6b12849a21eec918ad81bad19eb2e8ff5e6 v61 = l3;
            __cil_callvirt_0A000017(v61);
            goto IL_0121;
            IL_0121: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0122: ;
        __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 v62 = l0;
        if (v62 is null) {
            goto IL_01A9;
        } else {
            goto IL_0128;
        }
        IL_0128: ;
        string v63 = debugName;
        string v64 = __cil_ldstr_70000D58(", duplicate values found for the following keys: ");
        string v65 = System.String.Concat(v63, v64);
        __cil_type_01000038 v66 = __cil_newobj_0A000179(v65);
        l8 = v66;
        __cil_ref_78e2cf75e4144f9ee61bff6dfddf681df7c40135 v67 = l0;
        __cil_value_437b35f03d2560a78ff20e22e7283f4afb1ed046 v68 = __cil_callvirt_0A00017A(v67);
        l9 = v68;
        try {
            IL_0142: ;
            goto IL_0183;
            IL_0144: ;
            ref __cil_value_437b35f03d2560a78ff20e22e7283f4afb1ed046 v69 = ref l9;
            __cil_value_e345e3bd60ccf9b6342f88596d0da66c73d4d02e v70 = __cil_value_call_0A00017B(ref v69);
            l10 = v70;
            __cil_type_01000038 v71 = l8;
            __cil_ref_1d9781e701033244849f282fb38ddc75323ced20 v72 = logKey;
            ref __cil_value_e345e3bd60ccf9b6342f88596d0da66c73d4d02e v73 = ref l10;
            __cil_generic_18a1c1fc5b1f62cceef25ddf1760de167e921b09 v74 = __cil_value_call_0A00017C(ref v73);
            string v75 = __cil_callvirt_0A00017D(v72, v74);
            string v76 = __cil_ldstr_70000DBC(": [");
            string v77 = __cil_ldstr_700003A3(",");
            ref __cil_value_e345e3bd60ccf9b6342f88596d0da66c73d4d02e v78 = ref l10;
            __cil_ref_8764ddf6889a57624abb9f43ca57a529df8bb0fd v79 = __cil_value_call_0A00017E(ref v78);
            string v80 = System.String.Join(v77, ((__cil_ref_bc4d36fe1c82f28064fcc35653d69d1d30dd7cbd)(v79)));
            string v81 = __cil_ldstr_70000DC4("]");
            string v82 = System.String.Concat(v75, v76, v80, v81);
            __cil_type_01000038 v83 = v71.Append(v82);
            goto IL_0183;
            IL_0183: ;
            ref __cil_value_437b35f03d2560a78ff20e22e7283f4afb1ed046 v84 = ref l9;
            int v85 = __cil_bool_load(__cil_value_call_0A000180(ref v84));
            if (v85 != 0) {
                goto IL_0144;
            } else {
                goto IL_018C;
            }
            IL_018C: ;
            goto IL_019C;
        }
        finally {
            IL_018E: ;
            ref __cil_value_437b35f03d2560a78ff20e22e7283f4afb1ed046 v86 = ref l9;
            __cil_constrained_1B0000D1_0A000017(ref v86);
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_019C: ;
        __cil_type_01000038 v87 = l8;
        string v88 = v87.ToString();
        global::System.ArgumentException v89 = __cil_newobj_0A000181(v88);
        throw v89;
        IL_01A9: ;
        return;
    }

    public static OpenRA.Primitives.Color ColorLerp(float t, OpenRA.Primitives.Color c1, OpenRA.Primitives.Color c2)
    {
        // IL fallback: conv.i4 source category needs IL fallback
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [02, 0F, 02, 28, 50, 0A, 00, 06, 6B, 5A, 22, 00, 00, 80, 3F, 02, 59, 0F, 01, 28, 50, 0A, 00, 06]
        // .code-bytes IL_0018: [6B, 5A, 58, 69, 02, 0F, 02, 28, 51, 0A, 00, 06, 6B, 5A, 22, 00, 00, 80, 3F, 02, 59, 0F, 01, 28]
        // .code-bytes IL_0030: [51, 0A, 00, 06, 6B, 5A, 58, 69, 02, 0F, 02, 28, 52, 0A, 00, 06, 6B, 5A, 22, 00, 00, 80, 3F, 02]
        // .code-bytes IL_0048: [59, 0F, 01, 28, 52, 0A, 00, 06, 6B, 5A, 58, 69, 02, 0F, 02, 28, 53, 0A, 00, 06, 6B, 5A, 22, 00]
        // .code-bytes IL_0060: [00, 80, 3F, 02, 59, 0F, 01, 28, 53, 0A, 00, 06, 6B, 5A, 58, 69, 28, 3C, 0A, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarga.s 2
        // IL_0003: call 0x06000A50 OpenRA.Primitives.Color::get_A
        // IL_0008: conv.r4 
        // IL_0009: mul 
        // IL_000A: ldc.r4 1.0
        // IL_000F: ldarg.0 0
        // IL_0010: sub 
        // IL_0011: ldarga.s 1
        // IL_0013: call 0x06000A50 OpenRA.Primitives.Color::get_A
        // IL_0018: conv.r4 
        // IL_0019: mul 
        // IL_001A: add 
        // IL_001B: conv.i4 
        // IL_001C: ldarg.0 0
        // IL_001D: ldarga.s 2
        // IL_001F: call 0x06000A51 OpenRA.Primitives.Color::get_R
        // IL_0024: conv.r4 
        // IL_0025: mul 
        // IL_0026: ldc.r4 1.0
        // IL_002B: ldarg.0 0
        // IL_002C: sub 
        // IL_002D: ldarga.s 1
        // IL_002F: call 0x06000A51 OpenRA.Primitives.Color::get_R
        // IL_0034: conv.r4 
        // IL_0035: mul 
        // IL_0036: add 
        // IL_0037: conv.i4 
        // IL_0038: ldarg.0 0
        // IL_0039: ldarga.s 2
        // IL_003B: call 0x06000A52 OpenRA.Primitives.Color::get_G
        // IL_0040: conv.r4 
        // IL_0041: mul 
        // IL_0042: ldc.r4 1.0
        // IL_0047: ldarg.0 0
        // IL_0048: sub 
        // IL_0049: ldarga.s 1
        // IL_004B: call 0x06000A52 OpenRA.Primitives.Color::get_G
        // IL_0050: conv.r4 
        // IL_0051: mul 
        // IL_0052: add 
        // IL_0053: conv.i4 
        // IL_0054: ldarg.0 0
        // IL_0055: ldarga.s 2
        // IL_0057: call 0x06000A53 OpenRA.Primitives.Color::get_B
        // IL_005C: conv.r4 
        // IL_005D: mul 
        // IL_005E: ldc.r4 1.0
        // IL_0063: ldarg.0 0
        // IL_0064: sub 
        // IL_0065: ldarga.s 1
        // IL_0067: call 0x06000A53 OpenRA.Primitives.Color::get_B
        // IL_006C: conv.r4 
        // IL_006D: mul 
        // IL_006E: add 
        // IL_006F: conv.i4 
        // IL_0070: call 0x06000A3C OpenRA.Primitives.Color::FromArgb
        // IL_0075: ret 
    }

    public static T[] MakeArray<T>(int count, System.Func<int, T> f)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000EC method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_64f8dc95dc3411839751622d4d93b0f3ee51a674 bytes=151280C902081E00: class [System.Runtime]System.Func`2<int32, !!0>; type-owner=0x00000000 method-owner=0x060000EC; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f9626a49081310867b5a30f4ea70cc53e3ce8605 bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000EC; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_a04f75a3b1322b8473d6a19cf027036b1c9b1e74 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000EC; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_ref_f9626a49081310867b5a30f4ea70cc53e3ce8605 l0 = default;
        int l1 = default;
        __cil_ref_f9626a49081310867b5a30f4ea70cc53e3ce8605 v1 = __cil_newarr_1B0000BA(count);
        l0 = v1;
        l1 = 0;
        goto IL_001D;
        IL_000B: ;
        __cil_ref_f9626a49081310867b5a30f4ea70cc53e3ce8605 v3 = l0;
        int v4 = l1;
        int v6 = l1;
        __cil_generic_a04f75a3b1322b8473d6a19cf027036b1c9b1e74 v7 = __cil_callvirt_0A000182(f, v6);
        __cil_stelem_1B0000BA(v3, v4, v7);
        int v8 = l1;
        l1 = unchecked(v8 + 1);
        IL_001D: ;
        int v11 = l1;
        if (v11 < count) {
            goto IL_000B;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        __cil_ref_f9626a49081310867b5a30f4ea70cc53e3ce8605 v13 = l0;
        return v13;
    }

    public static T[,] ResizeArray<T>(T[,] ts, T t, int width, int height)
    {
        // IL fallback: unsupported reference relationship argument shape
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [04, 05, 73, 83, 01, 00, 0A, 0A, 16, 0B, 2B, 3F, 16, 0C, 2B, 33, 07, 02, 16, 6F, 84, 01, 00, 0A]
        // .code-bytes IL_0018: [30, 1C, 08, 02, 17, 6F, 84, 01, 00, 0A, 30, 12, 06, 07, 08, 02, 07, 08, 28, 85, 01, 00, 0A, 28]
        // .code-bytes IL_0030: [86, 01, 00, 0A, 2B, 09, 06, 07, 08, 03, 28, 86, 01, 00, 0A, 08, 17, 58, 0C, 08, 05, 32, C9, 07]
        // .code-bytes IL_0048: [17, 58, 0B, 07, 04, 32, BD, 06, 2A]
        // .local [0] !!0[0...,0...]
        // .local [1] int32
        // .local [2] int32
        // IL_0000: ldarg.2 2
        // IL_0001: ldarg.3 3
        // IL_0002: newobj 0x0A000183 !!0[0...,0...]::.ctor
        // IL_0007: stloc.0 0
        // IL_0008: ldc.i4.0 0
        // IL_0009: stloc.1 1
        // IL_000A: br.s IL_004B
        // IL_000C: ldc.i4.0 0
        // IL_000D: stloc.2 2
        // IL_000E: br.s IL_0043
        // IL_0010: ldloc.1 1
        // IL_0011: ldarg.0 0
        // IL_0012: ldc.i4.0 0
        // IL_0013: callvirt 0x0A000184 [System.Runtime]System.Array::GetUpperBound
        // IL_0018: bgt.s IL_0036
        // IL_001A: ldloc.2 2
        // IL_001B: ldarg.0 0
        // IL_001C: ldc.i4.1 1
        // IL_001D: callvirt 0x0A000184 [System.Runtime]System.Array::GetUpperBound
        // IL_0022: bgt.s IL_0036
        // IL_0024: ldloc.0 0
        // IL_0025: ldloc.1 1
        // IL_0026: ldloc.2 2
        // IL_0027: ldarg.0 0
        // IL_0028: ldloc.1 1
        // IL_0029: ldloc.2 2
        // IL_002A: call 0x0A000185 !!0[0...,0...]::Get
        // IL_002F: call 0x0A000186 !!0[0...,0...]::Set
        // IL_0034: br.s IL_003F
        // IL_0036: ldloc.0 0
        // IL_0037: ldloc.1 1
        // IL_0038: ldloc.2 2
        // IL_0039: ldarg.1 1
        // IL_003A: call 0x0A000186 !!0[0...,0...]::Set
        // IL_003F: ldloc.2 2
        // IL_0040: ldc.i4.1 1
        // IL_0041: add 
        // IL_0042: stloc.2 2
        // IL_0043: ldloc.2 2
        // IL_0044: ldarg.3 3
        // IL_0045: blt.s IL_0010
        // IL_0047: ldloc.1 1
        // IL_0048: ldc.i4.1 1
        // IL_0049: add 
        // IL_004A: stloc.1 1
        // IL_004B: ldloc.1 1
        // IL_004C: ldarg.2 2
        // IL_004D: blt.s IL_000C
        // IL_004F: ldloc.0 0
        // IL_0050: ret 
    }

    public static int ToBits(System.Collections.Generic.IEnumerable<bool> bits)
    {
        // structural signature __cil_ref_6b12add1060e4f16d8bb02b6837010c5cb5999ba bytes=151280850102: class [System.Runtime]System.Collections.Generic.IEnumerable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_662ecc528f3cb04c807d4849fd8e82e761e15d5c bytes=151280A10102: class [System.Runtime]System.Collections.Generic.IEnumerator`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        int l1 = default;
        __cil_ref_662ecc528f3cb04c807d4849fd8e82e761e15d5c l2 = default;
        bool l3 = default;
        IL_0000: ;
        int v0 = 0;
        l0 = v0;
        int v1 = 0;
        l1 = v1;
        __cil_ref_6b12add1060e4f16d8bb02b6837010c5cb5999ba v2 = bits;
        __cil_ref_662ecc528f3cb04c807d4849fd8e82e761e15d5c v3 = __cil_callvirt_0A000187(v2);
        l2 = v3;
        try {
            IL_000B: ;
            goto IL_002A;
            IL_000D: ;
            __cil_ref_662ecc528f3cb04c807d4849fd8e82e761e15d5c v4 = l2;
            int v5 = __cil_bool_load(__cil_callvirt_0A000188(v4));
            l3 = __cil_bool_store(v5);
            int v6 = __cil_bool_load(l3);
            if (v6 == 0) {
                goto IL_0026;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            int v7 = l1;
            int v8 = 1;
            int v9 = l0;
            int v10 = 1;
            int v11 = unchecked(v9 + v10);
            l0 = v11;
            int v12 = 31;
            int v13 = unchecked(v9 & v12);
            int v14 = (v8 << v13);
            int v15 = unchecked(v7 | v14);
            l1 = v15;
            goto IL_002A;
            IL_0026: ;
            int v16 = l0;
            int v17 = 1;
            int v18 = unchecked(v16 + v17);
            l0 = v18;
            goto IL_002A;
            IL_002A: ;
            __cil_ref_662ecc528f3cb04c807d4849fd8e82e761e15d5c v19 = l2;
            int v20 = __cil_bool_load(__cil_callvirt_0A000018(v19));
            if (v20 != 0) {
                goto IL_000D;
            } else {
                goto IL_0032;
            }
            IL_0032: ;
            goto IL_003E;
        }
        finally {
            IL_0034: ;
            __cil_ref_662ecc528f3cb04c807d4849fd8e82e761e15d5c v21 = l2;
            if (v21 is null) {
                goto IL_003D;
            } else {
                goto IL_0037;
            }
            IL_0037: ;
            __cil_ref_662ecc528f3cb04c807d4849fd8e82e761e15d5c v22 = l2;
            __cil_callvirt_0A000017(v22);
            goto IL_003D;
            IL_003D: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_003E: ;
        int v23 = l0;
        int v24 = 33;
        if (v23 <= v24) {
            goto IL_004E;
        } else {
            goto IL_0043;
        }
        IL_0043: ;
        string v25 = __cil_ldstr_70000DC8("ToBits only accepts up to 32 values.");
        global::System.InvalidOperationException v26 = __cil_newobj_0A00006E(v25);
        throw v26;
        IL_004E: ;
        int v27 = l1;
        return v27;
    }

    public static byte ParseByteInvariant(string s)
    {
        // enum storage token=0x02000294 alias=__cil_enum_02000294 underlying=int: global::@System.@Globalization.@NumberStyles; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_01000116 v2 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        int v3 = unchecked((int)(System.Byte.Parse(s, unchecked((System.Globalization.NumberStyles)(7)), ((__cil_type_010000FF)(v2)))));
        return unchecked((byte)(v3));
    }

    public static short ParseInt16Invariant(string s)
    {
        // enum storage token=0x02000294 alias=__cil_enum_02000294 underlying=int: global::@System.@Globalization.@NumberStyles; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_01000116 v2 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        int v3 = unchecked((int)(System.Int16.Parse(s, unchecked((System.Globalization.NumberStyles)(7)), ((__cil_type_010000FF)(v2)))));
        return unchecked((short)(v3));
    }

    public static int ParseInt32Invariant(string s)
    {
        // enum storage token=0x02000294 alias=__cil_enum_02000294 underlying=int: global::@System.@Globalization.@NumberStyles; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_01000116 v2 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        int v3 = System.Int32.Parse(s, unchecked((System.Globalization.NumberStyles)(7)), ((__cil_type_010000FF)(v2)));
        return v3;
    }

    public static bool TryParseInt32Invariant(string s, out int i)
    {
        // enum storage token=0x02000294 alias=__cil_enum_02000294 underlying=int: global::@System.@Globalization.@NumberStyles; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        string v0 = s;
        int v1 = 7;
        __cil_type_01000116 v2 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        ref int v3 = ref i;
        int v4 = __cil_bool_load(System.Int32.TryParse(v0, unchecked((System.Globalization.NumberStyles)(v1)), ((__cil_type_010000FF)(v2)), ref v3));
        return __cil_bool_store(v4);
    }

    public static bool TryParseInt64Invariant(string s, out long i)
    {
        // enum storage token=0x02000294 alias=__cil_enum_02000294 underlying=int: global::@System.@Globalization.@NumberStyles; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        string v0 = s;
        int v1 = 7;
        __cil_type_01000116 v2 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        ref long v3 = ref i;
        int v4 = __cil_bool_load(System.Int64.TryParse(v0, unchecked((System.Globalization.NumberStyles)(v1)), ((__cil_type_010000FF)(v2)), ref v3));
        return __cil_bool_store(v4);
    }

    public static string ToStringInvariant(byte i)
    {
        IL_0000: ;
        ref byte v0 = ref i;
        __cil_type_01000116 v1 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        string v2 = __cil_memberref_call_0A00018F(ref v0, ((__cil_type_010000FF)(v1)));
        return v2;
    }

    public static string ToStringInvariant(byte i, string format)
    {
        IL_0000: ;
        ref byte v0 = ref i;
        string v1 = format;
        __cil_type_01000116 v2 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        string v3 = __cil_memberref_call_0A000190(ref v0, v1, ((__cil_type_010000FF)(v2)));
        return v3;
    }

    public static string ToStringInvariant(int i)
    {
        IL_0000: ;
        ref int v0 = ref i;
        __cil_type_01000116 v1 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        string v2 = __cil_memberref_call_0A000191(ref v0, ((__cil_type_010000FF)(v1)));
        return v2;
    }

    public static string ToStringInvariant(int i, string format)
    {
        IL_0000: ;
        ref int v0 = ref i;
        string v1 = format;
        __cil_type_01000116 v2 = System.Globalization.NumberFormatInfo.get_InvariantInfo();
        string v3 = __cil_memberref_call_0A000192(ref v0, v1, ((__cil_type_010000FF)(v2)));
        return v3;
    }

    public static bool IsTraitEnabled<T>(T trait)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000F8 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_generic_a61d83166821f36ee0628bcccd397f2bf47651aa bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000F8; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        OpenRA.Traits.IDisabledTrait l0 = default;
        object v1 = ((object)((__cil_generic_a61d83166821f36ee0628bcccd397f2bf47651aa)(trait)));
        global::OpenRA.Traits.IDisabledTrait v2 = ((object)v1 as OpenRA.Traits.IDisabledTrait);
        l0 = v2;
        global::OpenRA.Traits.IDisabledTrait v3 = l0;
        if (v3 is null) {
            return true;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        global::OpenRA.Traits.IDisabledTrait v4 = l0;
        int v5 = __cil_bool_load(__cil_callvirt_060008FD(v4));
        return (v5 == 0);
    }

    public static T FirstEnabledTraitOrDefault<T>(System.Collections.Generic.IEnumerable<T> ts)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000F9 method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_e43af341e8823be6c84205eadc4ae7ad07432dc7 bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000F9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000F9; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_b4744e1cbb41aafb4d40cfababda56fd984da697 bytes=151280A1011E00: class [System.Runtime]System.Collections.Generic.IEnumerator`1<!!0>; type-owner=0x00000000 method-owner=0x060000F9; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_b4744e1cbb41aafb4d40cfababda56fd984da697 l0 = default;
        __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd l1 = default;
        __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd l2 = default;
        __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd l3 = default;
        IL_0000: ;
        __cil_ref_e43af341e8823be6c84205eadc4ae7ad07432dc7 v0 = ts;
        __cil_ref_b4744e1cbb41aafb4d40cfababda56fd984da697 v1 = __cil_callvirt_0A00015A(v0);
        l0 = v1;
        try {
            IL_0007: ;
            goto IL_001C;
            IL_0009: ;
            __cil_ref_b4744e1cbb41aafb4d40cfababda56fd984da697 v2 = l0;
            __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd v3 = __cil_callvirt_0A00015B(v2);
            l1 = v3;
            __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd v4 = l1;
            int v5 = __cil_bool_load(__cil_methodspec_call_2B00003C(v4));
            if (v5 == 0) {
                goto IL_001C;
            } else {
                goto IL_0018;
            }
            IL_0018: ;
            __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd v6 = l1;
            l2 = v6;
            goto IL_003A;
            IL_001C: ;
            __cil_ref_b4744e1cbb41aafb4d40cfababda56fd984da697 v7 = l0;
            int v8 = __cil_bool_load(__cil_callvirt_0A000018(v7));
            if (v8 != 0) {
                goto IL_0009;
            } else {
                goto IL_0024;
            }
            IL_0024: ;
            goto IL_0030;
        }
        finally {
            IL_0026: ;
            __cil_ref_b4744e1cbb41aafb4d40cfababda56fd984da697 v9 = l0;
            if (v9 is null) {
                goto IL_002F;
            } else {
                goto IL_0029;
            }
            IL_0029: ;
            __cil_ref_b4744e1cbb41aafb4d40cfababda56fd984da697 v10 = l0;
            __cil_callvirt_0A000017(v10);
            goto IL_002F;
            IL_002F: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0030: ;
        ref __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd v11 = ref l3;
        v11 = default;
        __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd v12 = l3;
        return v12;
        IL_003A: ;
        __cil_generic_51da5b67c3f546f18934c4c880566acd53f2ffbd v13 = l2;
        return v13;
    }

    public static T FirstEnabledTraitOrDefault<T>(T[] ts)
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000FA method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_0995beeab415864655c587acdb09f53e13ad0de2 bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000FA; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000FA; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_ref_0995beeab415864655c587acdb09f53e13ad0de2 l0 = default;
        int l1 = default;
        __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 l2 = default;
        __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 l3 = default;
        IL_0000: ;
        __cil_ref_0995beeab415864655c587acdb09f53e13ad0de2 v0 = ts;
        l0 = v0;
        int v1 = 0;
        l1 = v1;
        goto IL_001C;
        IL_0006: ;
        __cil_ref_0995beeab415864655c587acdb09f53e13ad0de2 v2 = l0;
        int v3 = l1;
        __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 v4 = __cil_ldelem_1B0000BA(v2, v3);
        l2 = v4;
        __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 v5 = l2;
        int v6 = __cil_bool_load(__cil_methodspec_call_2B00003C(v5));
        if (v6 == 0) {
            goto IL_0018;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 v7 = l2;
        return v7;
        IL_0018: ;
        int v8 = l1;
        int v9 = 1;
        int v10 = unchecked(v8 + v9);
        l1 = v10;
        goto IL_001C;
        IL_001C: ;
        int v11 = l1;
        __cil_ref_0995beeab415864655c587acdb09f53e13ad0de2 v12 = l0;
        nint v13 = unchecked((nint)(v12.LongLength));
        int v14 = unchecked((int)(v13));
        if (v11 < v14) {
            goto IL_0006;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        ref __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 v15 = ref l3;
        v15 = default;
        __cil_generic_00f0806f1e614c02aa427a86aa6deed56c096831 v16 = l3;
        return v16;
    }

    public static T FirstEnabledConditionalTraitOrDefault<T>(System.Collections.Generic.IEnumerable<T> ts) where T : OpenRA.Traits.IDisabledTrait
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000FB method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_091e2fd80128c9563f6981a3ca6357cc7d752cfc bytes=15128085011E00: class [System.Runtime]System.Collections.Generic.IEnumerable`1<!!0>; type-owner=0x00000000 method-owner=0x060000FB; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000FB; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        // structural signature __cil_ref_447f6bb00d525f51c4bf71435be831aa78ab154a bytes=151280A1011E00: class [System.Runtime]System.Collections.Generic.IEnumerator`1<!!0>; type-owner=0x00000000 method-owner=0x060000FB; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_447f6bb00d525f51c4bf71435be831aa78ab154a l0 = default;
        __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 l1 = default;
        __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 l2 = default;
        __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 l3 = default;
        IL_0000: ;
        __cil_ref_091e2fd80128c9563f6981a3ca6357cc7d752cfc v0 = ts;
        __cil_ref_447f6bb00d525f51c4bf71435be831aa78ab154a v1 = __cil_callvirt_0A00015A(v0);
        l0 = v1;
        try {
            IL_0007: ;
            goto IL_0023;
            IL_0009: ;
            __cil_ref_447f6bb00d525f51c4bf71435be831aa78ab154a v2 = l0;
            __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 v3 = __cil_callvirt_0A00015B(v2);
            l1 = v3;
            ref __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 v4 = ref l1;
            int v5 = __cil_constrained_1B0000BA_060008FD(ref v4);
            if (v5 != 0) {
                goto IL_0023;
            } else {
                goto IL_001F;
            }
            IL_001F: ;
            __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 v6 = l1;
            l2 = v6;
            goto IL_0041;
            IL_0023: ;
            __cil_ref_447f6bb00d525f51c4bf71435be831aa78ab154a v7 = l0;
            int v8 = __cil_bool_load(__cil_callvirt_0A000018(v7));
            if (v8 != 0) {
                goto IL_0009;
            } else {
                goto IL_002B;
            }
            IL_002B: ;
            goto IL_0037;
        }
        finally {
            IL_002D: ;
            __cil_ref_447f6bb00d525f51c4bf71435be831aa78ab154a v9 = l0;
            if (v9 is null) {
                goto IL_0036;
            } else {
                goto IL_0030;
            }
            IL_0030: ;
            __cil_ref_447f6bb00d525f51c4bf71435be831aa78ab154a v10 = l0;
            __cil_callvirt_0A000017(v10);
            goto IL_0036;
            IL_0036: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0037: ;
        ref __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 v11 = ref l3;
        v11 = default;
        __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 v12 = l3;
        return v12;
        IL_0041: ;
        __cil_generic_0bda50ab97fec23482ad031e14c7a56da7bf8150 v13 = l2;
        return v13;
    }

    public static T FirstEnabledConditionalTraitOrDefault<T>(T[] ts) where T : OpenRA.Traits.IDisabledTrait
    {
        // generic body context type-owner=0x02000010 type-arity=0 method-owner=0x060000FC method-arity=1; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
        // structural signature __cil_ref_6fe2c644285193667ffb051705fae0add4d8046a bytes=1D1E00: !!0[]; type-owner=0x00000000 method-owner=0x060000FC; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 bytes=1E00: !!0; type-owner=0x00000000 method-owner=0x060000FC; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
        __cil_ref_6fe2c644285193667ffb051705fae0add4d8046a l0 = default;
        int l1 = default;
        __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 l2 = default;
        __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 l3 = default;
        IL_0000: ;
        __cil_ref_6fe2c644285193667ffb051705fae0add4d8046a v0 = ts;
        l0 = v0;
        int v1 = 0;
        l1 = v1;
        goto IL_0023;
        IL_0006: ;
        __cil_ref_6fe2c644285193667ffb051705fae0add4d8046a v2 = l0;
        int v3 = l1;
        __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 v4 = __cil_ldelem_1B0000BA(v2, v3);
        l2 = v4;
        ref __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 v5 = ref l2;
        int v6 = __cil_constrained_1B0000BA_060008FD(ref v5);
        if (v6 != 0) {
            goto IL_001F;
        } else {
            goto IL_001D;
        }
        IL_001D: ;
        __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 v7 = l2;
        return v7;
        IL_001F: ;
        int v8 = l1;
        int v9 = 1;
        int v10 = unchecked(v8 + v9);
        l1 = v10;
        goto IL_0023;
        IL_0023: ;
        int v11 = l1;
        __cil_ref_6fe2c644285193667ffb051705fae0add4d8046a v12 = l0;
        nint v13 = unchecked((nint)(v12.LongLength));
        int v14 = unchecked((int)(v13));
        if (v11 < v14) {
            goto IL_0006;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        ref __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 v15 = ref l3;
        v15 = default;
        __cil_generic_f838c68941dfbe8a7987cb2c347fd5bfbf366163 v16 = l3;
        return v16;
    }

    public static OpenRA.LineSplitEnumerator SplitLines(string str, char separator)
    {
        // IL fallback: invalid/modified/open/managed-address struct field needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 28, 93, 01, 00, 0A, 03, 73, FE, 00, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x0A000193 [System.Memory]System.MemoryExtensions::AsSpan
        // IL_0006: ldarg.1 1
        // IL_0007: newobj 0x060000FE OpenRA.LineSplitEnumerator::.ctor
        // IL_000C: ret 
    }

    public sealed class ISqrtRoundMode : System.Enum
    {
        public int value__;
        public const OpenRA.Exts.ISqrtRoundMode Floor = 0;
        public const OpenRA.Exts.ISqrtRoundMode Nearest = 1;
        public const OpenRA.Exts.ISqrtRoundMode Ceiling = 2;
    }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Exts.__name_3C3E63 __il_field_04000957;
        public static System.Func<System.Type, string> __il_field_04000958;
        public static System.Func<string, bool> __il_field_04000959;
        public static System.Func<float, float, float> __il_field_0400095A;

        static __name_3C3E63()
        {
            global::OpenRA.Exts.__name_3C3E63 v0 = __cil_newobj_06000F72();
            OpenRA.Exts.__name_3C3E63.__il_field_04000957 = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <GetNamespaces>b__4_0
        internal string GetNamespacesLambda4_0(System.Type t)
        {
            string v1 = __cil_callvirt_0A000B62(t);
            return v1;
        }

        // Metadata name: <GetNamespaces>b__4_1
        internal bool GetNamespacesLambda4_1(string n)
        {
            return (!System.Object.ReferenceEquals(n, null));
        }

        // Metadata name: <Product>b__24_0
        internal float ProductLambda24_0(float a, float x)
        {
            __cil_F v0 = __cil_arg_r4(a);
            __cil_F v1 = __cil_arg_r4(x);
            return __cil_return_r4(unchecked(v0 * v1));
        }
    }

    private sealed class __name_3C3E635F5F3437<TSource, TKey>
    {
        public static readonly OpenRA.Exts.__name_3C3E635F5F3437<TSource, TKey> __il_field_0400095B;
        public static System.Func<TSource, TSource> __il_field_0400095C;

        static __name_3C3E635F5F3437()
        {
            // generic body context type-owner=0x02000257 type-arity=2 method-owner=0x06000F76 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_ref_929d1c3e048d38f17f41e4da1298f2d7b6475261 bytes=1512895C0213001301: class OpenRA.Exts/<>c__47`2<!0, !1>; type-owner=0x02000257 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Exts.__name_3C3E635F5F3437 v0 = __cil_newobj_0A000B63();
            __cil_stsfld_0A000B64(v0);
            return;
        }

        public __name_3C3E635F5F3437() : base()
        {
            // generic body context type-owner=0x02000257 type-arity=2 method-owner=0x06000F77 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            return;
        }

        // Metadata name: <ToDictionaryWithConflictLog>b__47_0
        internal TSource ToDictionaryWithConflictLogLambda47_0(TSource x)
        {
            // generic body context type-owner=0x02000257 type-arity=2 method-owner=0x06000F78 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_generic_e7ee7acaa816b4792e2cf043fc84b70634a57945 bytes=1300: !0; type-owner=0x02000257 method-owner=0x00000000; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
            return x;
        }
    }

    private sealed class __name_3C3E635F5F3439<TSource, TKey, TElement>
    {
        public static readonly OpenRA.Exts.__name_3C3E635F5F3439<TSource, TKey, TElement> __il_field_0400095D;
        public static System.Func<TKey, string> __il_field_0400095E;
        public static System.Func<TElement, string> __il_field_0400095F;

        static __name_3C3E635F5F3439()
        {
            // generic body context type-owner=0x02000258 type-arity=3 method-owner=0x06000F79 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_ref_01a63537df5bb9330ec8e2c513695cd4ce6833a4 bytes=1512896003130013011302: class OpenRA.Exts/<>c__49`3<!0, !1, !2>; type-owner=0x02000258 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Exts.__name_3C3E635F5F3439 v0 = __cil_newobj_0A000B65();
            __cil_stsfld_0A000B66(v0);
            return;
        }

        public __name_3C3E635F5F3439() : base()
        {
            // generic body context type-owner=0x02000258 type-arity=3 method-owner=0x06000F7A method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            return;
        }

        // Metadata name: <IntoDictionaryWithConflictLog>b__49_0
        internal string IntoDictionaryWithConflictLogLambda49_0(TKey s)
        {
            // generic body context type-owner=0x02000258 type-arity=3 method-owner=0x06000F7B method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_generic_ac89b52dfe19ed333c5cdd12323d9b0b4d1be84e bytes=1301: !1; type-owner=0x02000258 method-owner=0x00000000; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
            IL_0000: ;
            ref __cil_generic_ac89b52dfe19ed333c5cdd12323d9b0b4d1be84e v0 = ref s;
            string v1 = __cil_constrained_1B00007D_0A000068(ref v0);
            return v1;
        }

        // Metadata name: <IntoDictionaryWithConflictLog>b__49_1
        internal string IntoDictionaryWithConflictLogLambda49_1(TElement s)
        {
            // generic body context type-owner=0x02000258 type-arity=3 method-owner=0x06000F7C method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_generic_9114342120b7f5e8641df6bc1991500f6d87a54c bytes=1302: !2; type-owner=0x02000258 method-owner=0x00000000; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
            IL_0000: ;
            ref __cil_generic_9114342120b7f5e8641df6bc1991500f6d87a54c v0 = ref s;
            string v1 = __cil_constrained_1B00007E_0A000068(ref v0);
            return v1;
        }
    }

    private sealed class __name_3C497465726174653E645F5F3236<T> : System.Collections.Generic.IEnumerable<T0>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<T0>, System.Collections.IEnumerator, System.IDisposable
    {
        private int __il_field_04000960;
        private T __il_field_04000961;
        private int __il_field_04000962;
        private T t;
        public T __il_field_04000964;
        private System.Func<T, T> f;
        public System.Func<T, T> __il_field_04000966;

        public __name_3C497465726174653E645F5F3236(int __name_3C3E315F5F7374617465) : base()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F7D method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            this.__il_field_04000960 = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04000962 = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F7E method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            this.__il_field_04000960 = -2;
            return;
        }

        private virtual bool MoveNext()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F7F method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc bytes=1300: !0; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
            // structural signature __cil_ref_4f0446325bd4187ab10fbc91e68ba81032018442 bytes=151280C90213001300: class [System.Runtime]System.Func`2<!0, !0>; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            int l0 = default;
            int v1 = this.__il_field_04000960;
            l0 = v1;
            int v2 = l0;
            if (v2 == 0) {
                goto IL_0010;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v3 = l0;
            if (v3 == 1) {
                goto IL_002C;
            } else {
                return false;
            }
            IL_0010: ;
            this.__il_field_04000960 = -1;
            IL_0017: ;
            __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc v10 = this.t;
            this.__il_field_04000961 = v10;
            this.__il_field_04000960 = 1;
            return true;
            IL_002C: ;
            this.__il_field_04000960 = -1;
            __cil_ref_4f0446325bd4187ab10fbc91e68ba81032018442 v18 = this.f;
            __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc v20 = this.t;
            __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc v21 = __cil_callvirt_0A000B6C(v18, v20);
            this.t = v21;
            goto IL_0017;
        }

        private virtual T __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C543E2E6765745F43757272656E74()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F80 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc bytes=1300: !0; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
            __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc v1 = this.__il_field_04000961;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F81 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            global::System.NotSupportedException v0 = __cil_newobj_0A000870();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F82 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc bytes=1300: !0; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
            __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc v1 = this.__il_field_04000961;
            object v2 = ((object)((__cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc)(v1)));
            return v2;
        }

        private virtual System.Collections.Generic.IEnumerator<T> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C543E2E476574456E756D657261746F72()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F83 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc bytes=1300: !0; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; generic value copy in the original target type; no boxing, reference/integer category or layout inference.
            // structural signature __cil_ref_4f0446325bd4187ab10fbc91e68ba81032018442 bytes=151280C90213001300: class [System.Runtime]System.Func`2<!0, !0>; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_6151623b17ff5d4d923368693213729f6263a89a bytes=151280A1011300: class [System.Runtime]System.Collections.Generic.IEnumerator`1<!0>; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_81ae16e90e72925e1d1a5ce8770e70f1172694d5 bytes=15128964011300: class OpenRA.Exts/<Iterate>d__26`1<!0>; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_81ae16e90e72925e1d1a5ce8770e70f1172694d5 l0 = default;
            int v1 = this.__il_field_04000960;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04000962;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_04000960 = 0;
            l0 = this;
            goto IL_0029;
            IL_0022: ;
            global::OpenRA.Exts.__name_3C497465726174653E645F5F3236 v10 = __cil_newobj_0A000B6D(0);
            l0 = v10;
            IL_0029: ;
            __cil_ref_81ae16e90e72925e1d1a5ce8770e70f1172694d5 v11 = l0;
            __cil_generic_fd5648edf1b2e63653948e83eebb7769df0776dc v13 = this.__il_field_04000964;
            v11.t = v13;
            __cil_ref_81ae16e90e72925e1d1a5ce8770e70f1172694d5 v14 = l0;
            __cil_ref_4f0446325bd4187ab10fbc91e68ba81032018442 v16 = this.__il_field_04000966;
            v14.f = v16;
            __cil_ref_81ae16e90e72925e1d1a5ce8770e70f1172694d5 v17 = l0;
            return v17;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // generic body context type-owner=0x02000259 type-arity=1 method-owner=0x06000F84 method-arity=0; variables use owner/position, not names; original generic constraints and runtime entry binding apply.
            // structural signature __cil_ref_6151623b17ff5d4d923368693213729f6263a89a bytes=151280A1011300: class [System.Runtime]System.Collections.Generic.IEnumerator`1<!0>; type-owner=0x02000259 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_6151623b17ff5d4d923368693213729f6263a89a v1 = __cil_direct_0A000B70(this);
            return v1;
        }
        // property T __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C543E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C543E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Algorithms, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Algorithms, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Csp, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Csp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.Process, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.Process, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.Watcher, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.Watcher, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Channels, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Threading.Channels, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.ILGeneration, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.ILGeneration, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Emit.Lightweight, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Emit.Lightweight, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Loader, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Loader, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq.Expressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq.Expressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Sockets, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Sockets, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Numerics, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Numerics, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Security.Cryptography.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Security.Cryptography.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Reflection.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Reflection.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Diagnostics.StackTrace, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Diagnostics.StackTrace, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.NameResolution, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.NameResolution, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 7; exact references retained; see --details for identities and provenance.
