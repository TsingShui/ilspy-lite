namespace System.Xml;

internal sealed class XmlSqlBinaryReader : System.Xml.XmlReader, System.Xml.IXmlNamespaceResolver
{
    internal static readonly System.Type TypeOfObject;
    internal static readonly System.Type TypeOfString;
    private static System.Type[] s_tokenTypeMap;
    private static byte[] s_xsdKatmaiTimeScaleToValueLengthMap;
    private static System.Xml.ReadState[] s_scanState2ReadState;
    private System.IO.Stream _inStrm;
    private byte[] _data;
    private int _pos;
    private int _mark;
    private int _end;
    private long _offset;
    private bool _eof;
    private bool _sniffed;
    private bool _isEmpty;
    private int _docState;
    private System.Xml.XmlSqlBinaryReader.SymbolTables _symbolTables;
    private System.Xml.XmlNameTable _xnt;
    private bool _xntFromSettings;
    private string _xml;
    private string _xmlns;
    private string _nsxmlns;
    private string _baseUri;
    private System.Xml.XmlSqlBinaryReader.ScanState _state;
    private System.Xml.XmlNodeType _nodetype;
    private System.Xml.BinXmlToken _token;
    private int _attrIndex;
    private System.Xml.XmlSqlBinaryReader.QName _qnameOther;
    private System.Xml.XmlSqlBinaryReader.QName _qnameElement;
    private System.Xml.XmlNodeType _parentNodeType;
    private System.Xml.XmlSqlBinaryReader.ElemInfo[] _elementStack;
    private int _elemDepth;
    private System.Xml.XmlSqlBinaryReader.AttrInfo[] _attributes;
    private int[] _attrHashTbl;
    private int _attrCount;
    private int _posAfterAttrs;
    private bool _xmlspacePreserve;
    private int _tokLen;
    private int _tokDataPos;
    private bool _hasTypedValue;
    private System.Type _valueType;
    private string _stringValue;
    private System.Collections.Generic.Dictionary<string, System.Xml.XmlSqlBinaryReader.NamespaceDecl> _namespaces;
    private System.Xml.XmlSqlBinaryReader.NestedBinXml _prevNameInfo;
    private System.Xml.XmlReader _textXmlReader;
    private bool _closeInput;
    private bool _checkCharacters;
    private bool _ignoreWhitespace;
    private bool _ignorePIs;
    private bool _ignoreComments;
    private System.Xml.DtdProcessing _dtdProcessing;
    private System.Xml.SecureStringHasher _hasher;
    private System.Xml.XmlCharType _xmlCharType;
    private System.Text.Encoding _unicode;
    private byte _version;

    public XmlSqlBinaryReader(System.IO.Stream stream, byte[] data, int len, string baseUri, bool closeInput, System.Xml.XmlReaderSettings settings)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bc3e90673aaa9e4973123c36ef52fa98f111a582 bytes=11826C: valuetype System.Xml.XmlCharType; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af bytes=151280D1020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b218fda95157f842b2e469151dc307c14619953b bytes=1512812D010E: class [System.Runtime]System.Collections.Generic.IEqualityComparer`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 bytes=1D1211: class [System.Runtime]System.Type[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000BE alias=__cil_enum_020000BE underlying=int: global::@System.@Xml.@ConformanceLevel; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000BF alias=__cil_enum_020000BF underlying=int: global::@System.@Xml.@DtdProcessing; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000BE l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_ctor_call_06000F5B(v0);
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        __cil_type_0100004A v2 = System.Text.Encoding.get_Unicode();
        v1._unicode = v2;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        __cil_value_bc3e90673aaa9e4973123c36ef52fa98f111a582 v4 = System.Xml.XmlCharType.get_Instance();
        v3._xmlCharType = v4;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        global::System.Xml.XmlReaderSettings v6 = settings;
        global::System.Xml.XmlNameTable v7 = __cil_callvirt_06000F7A(v6);
        v5._xnt = v7;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        global::System.Xml.XmlNameTable v9 = v8._xnt;
        if (v9 is not null) {
            goto IL_0045;
        } else {
            goto IL_0031;
        }
        IL_0031: ;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        global::System.Xml.NameTable v11 = __cil_newobj_060008FA();
        v10._xnt = v11;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        int v13 = 0;
        v12._xntFromSettings = __cil_bool_store(v13);
        goto IL_004C;
        IL_0045: ;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        int v15 = 1;
        v14._xntFromSettings = __cil_bool_store(v15);
        goto IL_004C;
        IL_004C: ;
        global::System.Xml.XmlSqlBinaryReader v16 = this;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        global::System.Xml.XmlNameTable v18 = v17._xnt;
        string v19 = __cil_ldstr_700003A9("xml");
        string v20 = __cil_callvirt_06000A35(v18, v19);
        v16._xml = v20;
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        global::System.Xml.XmlSqlBinaryReader v22 = this;
        global::System.Xml.XmlNameTable v23 = v22._xnt;
        string v24 = __cil_ldstr_7000CEB5("xmlns");
        string v25 = __cil_callvirt_06000A35(v23, v24);
        v21._xmlns = v25;
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        global::System.Xml.XmlSqlBinaryReader v27 = this;
        global::System.Xml.XmlNameTable v28 = v27._xnt;
        string v29 = __cil_ldstr_7000CEC1("http://www.w3.org/2000/xmlns/");
        string v30 = __cil_callvirt_06000A35(v28, v29);
        v26._nsxmlns = v30;
        global::System.Xml.XmlSqlBinaryReader v31 = this;
        string v32 = baseUri;
        v31._baseUri = v32;
        global::System.Xml.XmlSqlBinaryReader v33 = this;
        int v34 = 5;
        v33._state = unchecked((__cil_enum_0200006C)(v34));
        global::System.Xml.XmlSqlBinaryReader v35 = this;
        int v36 = 0;
        v35._nodetype = unchecked((__cil_enum_020000B5)(v36));
        global::System.Xml.XmlSqlBinaryReader v37 = this;
        int v38 = 0;
        v37._token = unchecked((__cil_enum_02000073)(v38));
        global::System.Xml.XmlSqlBinaryReader v39 = this;
        int v40 = 16;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v41 = __cil_newarr_0200006E(v40);
        v39._elementStack = v41;
        global::System.Xml.XmlSqlBinaryReader v42 = this;
        int v43 = 8;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v44 = __cil_newarr_0200006F(v43);
        v42._attributes = v44;
        global::System.Xml.XmlSqlBinaryReader v45 = this;
        int v46 = 8;
        int[] v47 = new int[v46];
        v45._attrHashTbl = v47;
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v49 = ref v48._symbolTables;
        __cil_direct_06000834(ref v49);
        global::System.Xml.XmlSqlBinaryReader v50 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v51 = ref v50._qnameOther;
        __cil_direct_06000821(ref v51);
        global::System.Xml.XmlSqlBinaryReader v52 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v53 = ref v52._qnameElement;
        __cil_direct_06000821(ref v53);
        global::System.Xml.XmlSqlBinaryReader v54 = this;
        int v55 = 0;
        v54._xmlspacePreserve = __cil_bool_store(v55);
        global::System.Xml.XmlSqlBinaryReader v56 = this;
        global::System.Xml.SecureStringHasher v57 = __cil_newobj_06000B89();
        v56._hasher = v57;
        global::System.Xml.XmlSqlBinaryReader v58 = this;
        global::System.Xml.XmlSqlBinaryReader v59 = this;
        global::System.Xml.SecureStringHasher v60 = v59._hasher;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v61 = __cil_newobj_0A00009E(v60);
        v58._namespaces = v61;
        global::System.Xml.XmlSqlBinaryReader v62 = this;
        string v63 = __cil_ldsfld_0A000002();
        string v64 = __cil_ldsfld_0A000002();
        __cil_direct_060007C2(v62, v63, v64);
        global::System.Xml.XmlSqlBinaryReader v65 = this;
        global::System.Xml.XmlSqlBinaryReader v66 = this;
        string v67 = v66._xml;
        global::System.Xml.XmlSqlBinaryReader v68 = this;
        global::System.Xml.XmlNameTable v69 = v68._xnt;
        string v70 = __cil_ldstr_700003B1("http://www.w3.org/XML/1998/namespace");
        string v71 = __cil_callvirt_06000A35(v69, v70);
        __cil_direct_060007C2(v65, v67, v71);
        global::System.Xml.XmlSqlBinaryReader v72 = this;
        global::System.Xml.XmlSqlBinaryReader v73 = this;
        string v74 = v73._xmlns;
        global::System.Xml.XmlSqlBinaryReader v75 = this;
        string v76 = v75._nsxmlns;
        __cil_direct_060007C2(v72, v74, v76);
        global::System.Xml.XmlSqlBinaryReader v77 = this;
        __cil_type_01000004 v78 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v77._valueType = v78;
        global::System.Xml.XmlSqlBinaryReader v79 = this;
        __cil_type_01000049 v80 = stream;
        v79._inStrm = v80;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v81 = data;
        if (v81 is null) {
            goto IL_0185;
        } else {
            goto IL_0167;
        }
        IL_0167: ;
        global::System.Xml.XmlSqlBinaryReader v82 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v83 = data;
        v82._data = v83;
        global::System.Xml.XmlSqlBinaryReader v84 = this;
        int v85 = len;
        v84._end = v85;
        global::System.Xml.XmlSqlBinaryReader v86 = this;
        int v87 = 2;
        v86._pos = v87;
        global::System.Xml.XmlSqlBinaryReader v88 = this;
        int v89 = 1;
        v88._sniffed = __cil_bool_store(v89);
        goto IL_01BB;
        IL_0185: ;
        global::System.Xml.XmlSqlBinaryReader v90 = this;
        int v91 = 4096;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v92 = __cil_newarr_0100003E(v91);
        v90._data = v92;
        global::System.Xml.XmlSqlBinaryReader v93 = this;
        __cil_type_01000049 v94 = stream;
        global::System.Xml.XmlSqlBinaryReader v95 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v96 = v95._data;
        int v97 = 0;
        int v98 = 4096;
        int v99 = v94.Read(v96, v97, v98);
        v93._end = v99;
        global::System.Xml.XmlSqlBinaryReader v100 = this;
        int v101 = 0;
        v100._pos = v101;
        global::System.Xml.XmlSqlBinaryReader v102 = this;
        int v103 = 0;
        v102._sniffed = __cil_bool_store(v103);
        goto IL_01BB;
        IL_01BB: ;
        global::System.Xml.XmlSqlBinaryReader v104 = this;
        int v105 = -1;
        v104._mark = v105;
        global::System.Xml.XmlSqlBinaryReader v106 = this;
        global::System.Xml.XmlSqlBinaryReader v107 = this;
        int v108 = v107._end;
        int v109 = 0;
        int v110 = (v108 == v109 ? 1 : 0);
        v106._eof = __cil_bool_store(v110);
        global::System.Xml.XmlSqlBinaryReader v111 = this;
        int v112 = 0;
        long v113 = unchecked((long)(v112));
        v111._offset = v113;
        global::System.Xml.XmlSqlBinaryReader v114 = this;
        int v115 = __cil_bool_load(closeInput);
        v114._closeInput = __cil_bool_store(v115);
        global::System.Xml.XmlReaderSettings v116 = settings;
        int v117 = unchecked((int)(__cil_callvirt_06000F85(v116)));
        l0 = unchecked((__cil_enum_020000BE)(v117));
        int v118 = unchecked((int)(l0));
        switch (v118) {
            case 0: {
                goto IL_01FD;
            }
            case 1: {
                goto IL_0206;
            }
            case 2: {
                goto IL_0210;
            }
            default: {
                goto IL_01FB;
            } }
        IL_01FB: ;
        goto IL_0217;
        IL_01FD: ;
        global::System.Xml.XmlSqlBinaryReader v119 = this;
        int v120 = 0;
        v119._docState = v120;
        goto IL_0217;
        IL_0206: ;
        global::System.Xml.XmlSqlBinaryReader v121 = this;
        int v122 = 9;
        v121._docState = v122;
        goto IL_0217;
        IL_0210: ;
        global::System.Xml.XmlSqlBinaryReader v123 = this;
        int v124 = 1;
        v123._docState = v124;
        goto IL_0217;
        IL_0217: ;
        global::System.Xml.XmlSqlBinaryReader v125 = this;
        global::System.Xml.XmlReaderSettings v126 = settings;
        int v127 = __cil_bool_load(__cil_callvirt_06000F87(v126));
        v125._checkCharacters = __cil_bool_store(v127);
        global::System.Xml.XmlSqlBinaryReader v128 = this;
        global::System.Xml.XmlReaderSettings v129 = settings;
        int v130 = unchecked((int)(__cil_callvirt_06000F95(v129)));
        v128._dtdProcessing = unchecked((__cil_enum_020000BF)(v130));
        global::System.Xml.XmlSqlBinaryReader v131 = this;
        global::System.Xml.XmlReaderSettings v132 = settings;
        int v133 = __cil_bool_load(__cil_callvirt_06000F8D(v132));
        v131._ignoreWhitespace = __cil_bool_store(v133);
        global::System.Xml.XmlSqlBinaryReader v134 = this;
        global::System.Xml.XmlReaderSettings v135 = settings;
        int v136 = __cil_bool_load(__cil_callvirt_06000F8F(v135));
        v134._ignorePIs = __cil_bool_store(v136);
        global::System.Xml.XmlSqlBinaryReader v137 = this;
        global::System.Xml.XmlReaderSettings v138 = settings;
        int v139 = __cil_bool_load(__cil_callvirt_06000F91(v138));
        v137._ignoreComments = __cil_bool_store(v139);
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v140 = System.Threading.Volatile.Read(ref System.Xml.XmlSqlBinaryReader.s_tokenTypeMap);
        if (v140 is not null) {
            goto IL_0267;
        } else {
            goto IL_0261;
        }
        IL_0261: ;
        global::System.Xml.XmlSqlBinaryReader v141 = this;
        __cil_direct_060007FD(v141);
        goto IL_0267;
        IL_0267: ;
        return;
    }

    public override System.Xml.XmlReaderSettings get_Settings()
    {
        // enum storage token=0x020000BE alias=__cil_enum_020000BE underlying=int: global::@System.@Xml.@ConformanceLevel; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000BF alias=__cil_enum_020000BF underlying=int: global::@System.@Xml.@DtdProcessing; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        System.Xml.XmlReaderSettings l0 = default;
        int l1 = default;
        global::System.Xml.XmlReaderSettings v0 = __cil_newobj_06000F77();
        l0 = v0;
        int v2 = __cil_bool_load(this._xntFromSettings);
        if (v2 == 0) {
            goto IL_001A;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        global::System.Xml.XmlReaderSettings v3 = l0;
        global::System.Xml.XmlNameTable v5 = this._xnt;
        __cil_callvirt_06000F7B(v3, v5);
        IL_001A: ;
        int v7 = this._docState;
        l1 = v7;
        int v8 = l1;
        if (v8 == 0) {
            goto IL_002B;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        int v9 = l1;
        if (v9 == 9) {
            goto IL_0034;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        goto IL_003D;
        IL_002B: ;
        global::System.Xml.XmlReaderSettings v11 = l0;
        __cil_callvirt_06000F86(v11, unchecked((__cil_enum_020000BE)(0)));
        goto IL_0044;
        IL_0034: ;
        global::System.Xml.XmlReaderSettings v13 = l0;
        __cil_callvirt_06000F86(v13, unchecked((__cil_enum_020000BE)(1)));
        goto IL_0044;
        IL_003D: ;
        global::System.Xml.XmlReaderSettings v15 = l0;
        __cil_callvirt_06000F86(v15, unchecked((__cil_enum_020000BE)(2)));
        IL_0044: ;
        global::System.Xml.XmlReaderSettings v17 = l0;
        int v19 = __cil_bool_load(this._checkCharacters);
        __cil_callvirt_06000F88(v17, __cil_bool_store(v19));
        global::System.Xml.XmlReaderSettings v20 = l0;
        int v22 = __cil_bool_load(this._ignoreWhitespace);
        __cil_callvirt_06000F8E(v20, __cil_bool_store(v22));
        global::System.Xml.XmlReaderSettings v23 = l0;
        int v25 = __cil_bool_load(this._ignorePIs);
        __cil_callvirt_06000F90(v23, __cil_bool_store(v25));
        global::System.Xml.XmlReaderSettings v26 = l0;
        int v28 = __cil_bool_load(this._ignoreComments);
        __cil_callvirt_06000F92(v26, __cil_bool_store(v28));
        global::System.Xml.XmlReaderSettings v29 = l0;
        int v31 = unchecked((int)(this._dtdProcessing));
        __cil_callvirt_06000F96(v29, unchecked((__cil_enum_020000BF)(v31)));
        global::System.Xml.XmlReaderSettings v32 = l0;
        int v34 = __cil_bool_load(this._closeInput);
        __cil_callvirt_06000F98(v32, __cil_bool_store(v34));
        global::System.Xml.XmlReaderSettings v35 = l0;
        __cil_callvirt_06000FA8(v35, __cil_bool_store(1));
        global::System.Xml.XmlReaderSettings v37 = l0;
        return v37;
    }

    public override System.Xml.XmlNodeType get_NodeType()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this._nodetype));
        return unchecked((__cil_enum_020000B5)(v1));
    }

    public override string get_LocalName()
    {
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref v0._qnameOther;
        string v2 = v1.localname;
        return v2;
    }

    public override string get_NamespaceURI()
    {
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref v0._qnameOther;
        string v2 = v1.namespaceUri;
        return v2;
    }

    public override string get_Prefix()
    {
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref v0._qnameOther;
        string v2 = v1.prefix;
        return v2;
    }

    public override bool get_HasValue()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_0015;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v4 = this._textXmlReader;
        return __cil_callvirt_06000EBD(v4);
        IL_0015: ;
        int v7 = unchecked((int)(this._nodetype));
        return System.Xml.XmlReader.HasValueInternal(unchecked((__cil_enum_020000B5)(v7)));
    }

    public override string get_Value()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        __cil_enum_020000B5 l1 = default;
        string l2 = default;
        string v1 = this._stringValue;
        if (v1 is null) {
            goto IL_000F;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        string v3 = this._stringValue;
        return v3;
        IL_000F: ;
        int v5 = unchecked((int)(this._state));
        l0 = unchecked((__cil_enum_0200006C)(v5));
        int v6 = unchecked((int)(l0));
        switch (v6) {
            case 0: {
                goto IL_0035;
            }
            case 1: {
                goto IL_00D7;
            }
            case 2: {
                goto IL_00E3;
            }
            case 3: {
                goto IL_00FB;
            }
            case 4: {
                goto IL_00E3;
            }
            default: {
                goto IL_0030;
            } }
        IL_0030: ;
        goto IL_0111;
        IL_0035: ;
        int v8 = unchecked((int)(this._nodetype));
        l1 = unchecked((__cil_enum_020000B5)(v8));
        int v9 = unchecked((int)(l1));
        int v11 = unchecked(v9 - 3);
        switch (v11) {
            case 0: {
                goto IL_00C1;
            }
            case 1: {
                goto IL_00A1;
            }
            case 2: {
                goto IL_0111;
            }
            case 3: {
                goto IL_0111;
            }
            case 4: {
                goto IL_0085;
            }
            case 5: {
                goto IL_0085;
            }
            case 6: {
                goto IL_0111;
            }
            case 7: {
                goto IL_0085;
            }
            case 8: {
                goto IL_0111;
            }
            case 9: {
                goto IL_0111;
            }
            case 10: {
                goto IL_00C1;
            }
            case 11: {
                goto IL_00C1;
            }
            case 12: {
                goto IL_0111;
            }
            case 13: {
                goto IL_0111;
            }
            case 14: {
                goto IL_00B1;
            }
            default: {
                goto IL_0080;
            } }
        IL_0080: ;
        goto IL_0111;
        IL_0085: ;
        int v15 = this._tokDataPos;
        int v17 = this._tokLen;
        string v18 = __cil_direct_060007DB(this, v15, v17);
        l2 = v18;
        this._stringValue = v18;
        string v19 = l2;
        return v19;
        IL_00A1: ;
        string v22 = __cil_direct_060007EC(this);
        l2 = v22;
        this._stringValue = v22;
        string v23 = l2;
        return v23;
        IL_00B1: ;
        string v26 = __cil_direct_060007EB(this);
        l2 = v26;
        this._stringValue = v26;
        string v27 = l2;
        return v27;
        IL_00C1: ;
        int v31 = unchecked((int)(this._token));
        string v32 = __cil_direct_0600080E(this, unchecked((__cil_enum_02000073)(v31)));
        l2 = v32;
        this._stringValue = v32;
        string v33 = l2;
        return v33;
        IL_00D7: ;
        global::System.Xml.XmlReader v35 = this._textXmlReader;
        string v36 = __cil_callvirt_06000EBE(v35);
        return v36;
        IL_00E3: ;
        int v40 = this._attrIndex;
        int v42 = unchecked(v40 - 1);
        string v43 = __cil_direct_060007DD(this, v42);
        l2 = v43;
        this._stringValue = v43;
        string v44 = l2;
        return v44;
        IL_00FB: ;
        int v48 = unchecked((int)(this._token));
        string v49 = __cil_direct_0600080E(this, unchecked((__cil_enum_02000073)(v48)));
        l2 = v49;
        this._stringValue = v49;
        string v50 = l2;
        return v50;
        IL_0111: ;
        string v51 = __cil_ldsfld_0A000002();
        return v51;
    }

    public override int get_Depth()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_enum_0200006C l1 = default;
        l0 = 0;
        int v2 = unchecked((int)(this._state));
        l1 = unchecked((__cil_enum_0200006C)(v2));
        int v3 = unchecked((int)(l1));
        switch (v3) {
            case 0: {
                goto IL_0025;
            }
            case 1: {
                goto IL_003C;
            }
            case 2: {
                goto IL_004A;
            }
            case 3: {
                goto IL_0057;
            }
            case 4: {
                goto IL_0057;
            }
            default: {
                return 0;
            } }
        IL_0025: ;
        int v5 = unchecked((int)(this._nodetype));
        if (v5 == 1) {
            goto IL_0038;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        int v8 = unchecked((int)(this._nodetype));
        if (unchecked((uint)v8) != unchecked((uint)15)) {
            goto IL_006A;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        l0 = -1;
        goto IL_006A;
        IL_003C: ;
        global::System.Xml.XmlReader v12 = this._textXmlReader;
        int v13 = __cil_callvirt_06000EBF(v12);
        l0 = v13;
        goto IL_006A;
        IL_004A: ;
        int v15 = unchecked((int)(this._parentNodeType));
        if (v15 == 1) {
            goto IL_006A;
        } else {
            goto IL_0053;
        }
        IL_0053: ;
        l0 = 1;
        goto IL_006A;
        IL_0057: ;
        int v19 = unchecked((int)(this._parentNodeType));
        if (v19 == 1) {
            goto IL_0062;
        } else {
            goto IL_0060;
        }
        IL_0060: ;
        l0 = 1;
        IL_0062: ;
        int v22 = l0;
        l0 = unchecked(v22 + 1);
        IL_006A: ;
        int v27 = this._elemDepth;
        int v28 = l0;
        return unchecked(v27 + v28);
    }

    public override string get_BaseURI()
    {
        string v1 = this._baseUri;
        return v1;
    }

    public override bool get_IsEmptyElement()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        int v1 = unchecked((int)(this._state));
        l0 = unchecked((__cil_enum_0200006C)(v1));
        int v2 = unchecked((int)(l0));
        if (unchecked((uint)v2) > unchecked((uint)1)) {
            return false;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        return this._isEmpty;
    }

    public override System.Xml.XmlSpace get_XmlSpace()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200013A alias=__cil_enum_0200013A underlying=int: global::@System.@Xml.@XmlSpace; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_enum_0200013A l1 = default;
        IL_0000: ;
        int v0 = 1;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = unchecked((int)(v1._state));
        if (v0 == v2) {
            goto IL_0033;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        int v4 = v3._elemDepth;
        l0 = v4;
        goto IL_002D;
        IL_0012: ;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v6 = v5._elementStack;
        int v7 = l0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v8 = ref __cil_ldelema_0200006E(v6, v7);
        int v9 = unchecked((int)(v8.xmlSpace));
        l1 = unchecked((__cil_enum_0200013A)(v9));
        int v10 = unchecked((int)(l1));
        if (v10 == 0) {
            goto IL_0029;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        int v11 = unchecked((int)(l1));
        return unchecked((__cil_enum_0200013A)(v11));
        IL_0029: ;
        int v12 = l0;
        int v13 = 1;
        int v14 = unchecked(v12 - v13);
        l0 = v14;
        goto IL_002D;
        IL_002D: ;
        int v15 = l0;
        int v16 = 0;
        if (v15 >= v16) {
            goto IL_0012;
        } else {
            goto IL_0031;
        }
        IL_0031: ;
        int v17 = 0;
        return unchecked((__cil_enum_0200013A)(v17));
        IL_0033: ;
        global::System.Xml.XmlSqlBinaryReader v18 = this;
        global::System.Xml.XmlReader v19 = v18._textXmlReader;
        int v20 = unchecked((int)(__cil_callvirt_06000EC4(v19)));
        return unchecked((__cil_enum_0200013A)(v20));
    }

    public override string get_XmlLang()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        string l1 = default;
        IL_0000: ;
        int v0 = 1;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = unchecked((int)(v1._state));
        if (v0 == v2) {
            goto IL_0037;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        int v4 = v3._elemDepth;
        l0 = v4;
        goto IL_002D;
        IL_0012: ;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v6 = v5._elementStack;
        int v7 = l0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v8 = ref __cil_ldelema_0200006E(v6, v7);
        string v9 = v8.xmlLang;
        l1 = v9;
        string v10 = l1;
        if (v10 is null) {
            goto IL_0029;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        string v11 = l1;
        return v11;
        IL_0029: ;
        int v12 = l0;
        int v13 = 1;
        int v14 = unchecked(v12 - v13);
        l0 = v14;
        goto IL_002D;
        IL_002D: ;
        int v15 = l0;
        int v16 = 0;
        if (v15 >= v16) {
            goto IL_0012;
        } else {
            goto IL_0031;
        }
        IL_0031: ;
        string v17 = __cil_ldsfld_0A000002();
        return v17;
        IL_0037: ;
        global::System.Xml.XmlSqlBinaryReader v18 = this;
        global::System.Xml.XmlReader v19 = v18._textXmlReader;
        string v20 = __cil_callvirt_06000EC5(v19);
        return v20;
    }

    public override System.Type get_ValueType()
    {
        __cil_type_01000004 v1 = this._valueType;
        return v1;
    }

    public override int get_AttributeCount()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        int v1 = unchecked((int)(this._state));
        l0 = unchecked((__cil_enum_0200006C)(v1));
        int v2 = unchecked((int)(l0));
        switch (v2) {
            case 0: {
                goto IL_0023;
            }
            case 1: {
                goto IL_002A;
            }
            case 2: {
                goto IL_0023;
            }
            case 3: {
                goto IL_0023;
            }
            case 4: {
                goto IL_0023;
            }
            default: {
                return 0;
            } }
        IL_0023: ;
        int v4 = this._attrCount;
        return v4;
        IL_002A: ;
        global::System.Xml.XmlReader v6 = this._textXmlReader;
        int v7 = __cil_callvirt_06000EE7(v6);
        return v7;
    }

    public override string GetAttribute(string name, string ns)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_0017;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v4 = this._textXmlReader;
        string v6 = ns;
        string v7 = __cil_callvirt_06000EE9(v4, name, v6);
        return v7;
        IL_0017: ;
        if (name is not null) {
            goto IL_0025;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        string v9 = __cil_ldstr_70000037("name");
        global::System.ArgumentNullException v10 = __cil_newobj_0A000062(v9);
        throw v10;
        IL_0025: ;
        string v11 = ns;
        if (v11 is not null) {
            goto IL_002F;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        string v12 = __cil_ldsfld_0A000002();
        ns = v12;
        IL_002F: ;
        string v15 = ns;
        int v16 = __cil_direct_060007DE(this, name, v15);
        l0 = v16;
        int v18 = l0;
        if (!(unchecked((uint)-1) != unchecked((uint)v18))) {
            return null;
        }
        int v20 = l0;
        string v21 = __cil_callvirt_06000EEA(this, v20);
        return v21;
    }

    public override string GetAttribute(string name)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_0016;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v4 = this._textXmlReader;
        string v6 = __cil_callvirt_06000EE8(v4, name);
        return v6;
        IL_0016: ;
        int v9 = __cil_direct_060007DF(this, name);
        l0 = v9;
        int v11 = l0;
        if (!(unchecked((uint)-1) != unchecked((uint)v11))) {
            return null;
        }
        int v13 = l0;
        string v14 = __cil_callvirt_06000EEA(this, v13);
        return v14;
    }

    public override string GetAttribute(int i)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_0016;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v4 = this._textXmlReader;
        string v6 = __cil_callvirt_06000EEA(v4, i);
        return v6;
        IL_0016: ;
        if (i < 0) {
            goto IL_0023;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        int v11 = this._attrCount;
        if (i < v11) {
            goto IL_002E;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        string v12 = __cil_ldstr_7000CEFD("i");
        global::System.ArgumentOutOfRangeException v13 = __cil_newobj_0A0000A0(v12);
        throw v13;
        IL_002E: ;
        string v16 = __cil_direct_060007DD(this, i);
        return v16;
    }

    public override bool MoveToAttribute(string name, string ns)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_001D;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v5 = this._textXmlReader;
        string v7 = ns;
        int v8 = __cil_bool_load(__cil_callvirt_06000EEF(v5, name, v7));
        return __cil_direct_060007FB(this, __cil_bool_store(v8));
        IL_001D: ;
        if (name is not null) {
            goto IL_002B;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        string v11 = __cil_ldstr_70000037("name");
        global::System.ArgumentNullException v12 = __cil_newobj_0A000062(v11);
        throw v12;
        IL_002B: ;
        string v13 = ns;
        if (v13 is not null) {
            goto IL_0035;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        string v14 = __cil_ldsfld_0A000002();
        ns = v14;
        IL_0035: ;
        string v17 = ns;
        int v18 = __cil_direct_060007DE(this, name, v17);
        l0 = v18;
        int v20 = l0;
        if (-1 == v20) {
            return false;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        int v22 = unchecked((int)(this._state));
        if (v22 >= 5) {
            return false;
        } else {
            goto IL_004B;
        }
        IL_004B: ;
        int v25 = l0;
        int v27 = unchecked(v25 + 1);
        __cil_direct_060007E0(this, v27);
        return true;
    }

    public override bool MoveToAttribute(string name)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_001C;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v5 = this._textXmlReader;
        int v7 = __cil_bool_load(__cil_callvirt_06000EEE(v5, name));
        return __cil_direct_060007FB(this, __cil_bool_store(v7));
        IL_001C: ;
        int v11 = __cil_direct_060007DF(this, name);
        l0 = v11;
        int v13 = l0;
        if (-1 == v13) {
            return false;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        int v15 = unchecked((int)(this._state));
        if (v15 >= 5) {
            return false;
        } else {
            goto IL_0031;
        }
        IL_0031: ;
        int v18 = l0;
        int v20 = unchecked(v18 + 1);
        __cil_direct_060007E0(this, v20);
        return true;
    }

    public override void MoveToAttribute(int i)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_001E;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v4 = this._textXmlReader;
        __cil_callvirt_06000EF0(v4, i);
        int v8 = __cil_bool_load(__cil_direct_060007FB(this, __cil_bool_store(1)));
        return;
        IL_001E: ;
        if (i < 0) {
            goto IL_002B;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        int v13 = this._attrCount;
        if (i < v13) {
            goto IL_0036;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        string v14 = __cil_ldstr_7000CEFD("i");
        global::System.ArgumentOutOfRangeException v15 = __cil_newobj_0A0000A0(v14);
        throw v15;
        IL_0036: ;
        int v19 = unchecked(i + 1);
        __cil_direct_060007E0(this, v19);
        return;
    }

    public override bool MoveToFirstAttribute()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v2 = unchecked((int)(this._state));
        if (unchecked((uint)1) != unchecked((uint)v2)) {
            goto IL_001B;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlReader v5 = this._textXmlReader;
        int v6 = __cil_bool_load(__cil_callvirt_06000EF1(v5));
        return __cil_direct_060007FB(this, __cil_bool_store(v6));
        IL_001B: ;
        int v9 = this._attrCount;
        if (!(v9 != 0)) {
            return false;
        }
        __cil_direct_060007E0(this, 1);
        return true;
    }

    public override bool MoveToNextAttribute()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        int l1 = default;
        int v1 = unchecked((int)(this._state));
        l0 = unchecked((__cil_enum_0200006C)(v1));
        int v2 = unchecked((int)(l0));
        switch (v2) {
            case 0: {
                goto IL_0023;
            }
            case 1: {
                goto IL_004C;
            }
            case 2: {
                goto IL_0023;
            }
            case 3: {
                goto IL_0023;
            }
            case 4: {
                goto IL_0023;
            }
            default: {
                return false;
            } }
        IL_0023: ;
        int v4 = this._attrIndex;
        int v6 = this._attrCount;
        if (!(v4 < v6)) {
            return false;
        }
        int v11 = this._attrIndex;
        l1 = unchecked(v11 + 1);
        int v14 = l1;
        this._attrIndex = v14;
        int v15 = l1;
        __cil_direct_060007E0(this, v15);
        return true;
        IL_004C: ;
        global::System.Xml.XmlReader v19 = this._textXmlReader;
        int v20 = __cil_bool_load(__cil_callvirt_06000EF2(v19));
        return __cil_direct_060007FB(this, __cil_bool_store(v20));
    }

    public override bool MoveToElement()
    {
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        int v1 = unchecked((int)(this._state));
        l0 = unchecked((__cil_enum_0200006C)(v1));
        int v2 = unchecked((int)(l0));
        if (v2 == 1) {
            goto IL_0094;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int v4 = unchecked((int)(l0));
        int v6 = unchecked(v4 - 2);
        if (unchecked((uint)v6) > unchecked((uint)2)) {
            return false;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        this._attrIndex = 0;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v12 = this._qnameElement;
        this._qnameOther = v12;
        int v15 = unchecked((int)(this._parentNodeType));
        if (unchecked((uint)1) != unchecked((uint)v15)) {
            goto IL_0040;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        this._token = unchecked((__cil_enum_02000073)(248));
        goto IL_006C;
        IL_0040: ;
        int v20 = unchecked((int)(this._parentNodeType));
        if (unchecked((uint)17) != unchecked((uint)v20)) {
            goto IL_0057;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        this._token = unchecked((__cil_enum_02000073)(254));
        goto IL_006C;
        IL_0057: ;
        int v25 = unchecked((int)(this._parentNodeType));
        if (unchecked((uint)10) != unchecked((uint)v25)) {
            goto IL_006C;
        } else {
            goto IL_0061;
        }
        IL_0061: ;
        this._token = unchecked((__cil_enum_02000073)(252));
        IL_006C: ;
        int v30 = unchecked((int)(this._parentNodeType));
        this._nodetype = unchecked((__cil_enum_020000B5)(v30));
        this._state = unchecked((__cil_enum_0200006C)(0));
        int v35 = this._posAfterAttrs;
        this._pos = v35;
        this._stringValue = null;
        return true;
        IL_0094: ;
        global::System.Xml.XmlReader v40 = this._textXmlReader;
        int v41 = __cil_bool_load(__cil_callvirt_06000EF3(v40));
        return __cil_direct_060007FB(this, __cil_bool_store(v41));
    }

    public override bool get_EOF()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this._state));
        return (v1 == 7);
    }

    public override bool ReadAttributeValue()
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        __cil_enum_02000073 l1 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        v0._stringValue = null;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = unchecked((int)(v1._state));
        l0 = unchecked((__cil_enum_0200006C)(v2));
        int v3 = unchecked((int)(l0));
        int v4 = 1;
        int v5 = unchecked(v3 - v4);
        switch (v5) {
            case 0: {
                goto IL_00CB;
            }
            case 1: {
                goto IL_0027;
            }
            case 2: {
                goto IL_00C9;
            }
            default: {
                goto IL_0022;
            } }
        IL_0022: ;
        goto IL_00DD;
        IL_0027: ;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v7 = v6._attributes;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        int v9 = v8._attrIndex;
        int v10 = 1;
        int v11 = unchecked(v9 - v10);
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v12 = ref __cil_ldelema_0200006F(v7, v11);
        string v13 = v12.val;
        if (v13 is not null) {
            goto IL_009C;
        } else {
            goto IL_0041;
        }
        IL_0041: ;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v16 = v15._attributes;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        int v18 = v17._attrIndex;
        int v19 = 1;
        int v20 = unchecked(v18 - v19);
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v21 = ref __cil_ldelema_0200006F(v16, v20);
        int v22 = v21.contentPos;
        v14._pos = v22;
        global::System.Xml.XmlSqlBinaryReader v23 = this;
        int v24 = unchecked((int)(__cil_direct_060007D8(v23)));
        l1 = unchecked((__cil_enum_02000073)(v24));
        int v25 = 246;
        int v26 = unchecked((int)(l1));
        if (v25 == v26) {
            goto IL_0076;
        } else {
            goto IL_006E;
        }
        IL_006E: ;
        int v27 = 245;
        int v28 = unchecked((int)(l1));
        if (unchecked((uint)v27) != unchecked((uint)v28)) {
            goto IL_0078;
        } else {
            goto IL_0076;
        }
        IL_0076: ;
        int v29 = 0;
        return __cil_bool_store(v29);
        IL_0078: ;
        global::System.Xml.XmlSqlBinaryReader v30 = this;
        int v31 = unchecked((int)(l1));
        v30._token = unchecked((__cil_enum_02000073)(v31));
        global::System.Xml.XmlSqlBinaryReader v32 = this;
        int v33 = unchecked((int)(l1));
        __cil_direct_060007FF(v32, unchecked((__cil_enum_02000073)(v33)));
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        global::System.Xml.XmlSqlBinaryReader v35 = this;
        int v36 = unchecked((int)(l1));
        __cil_type_01000004 v37 = __cil_direct_060007FE(v35, unchecked((__cil_enum_02000073)(v36)));
        v34._valueType = v37;
        global::System.Xml.XmlSqlBinaryReader v38 = this;
        int v39 = 3;
        v38._state = unchecked((__cil_enum_0200006C)(v39));
        goto IL_00B5;
        IL_009C: ;
        global::System.Xml.XmlSqlBinaryReader v40 = this;
        int v41 = 0;
        v40._token = unchecked((__cil_enum_02000073)(v41));
        global::System.Xml.XmlSqlBinaryReader v42 = this;
        __cil_type_01000004 v43 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v42._valueType = v43;
        global::System.Xml.XmlSqlBinaryReader v44 = this;
        int v45 = 4;
        v44._state = unchecked((__cil_enum_0200006C)(v45));
        goto IL_00B5;
        IL_00B5: ;
        global::System.Xml.XmlSqlBinaryReader v46 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v47 = ref v46._qnameOther;
        __cil_direct_06000821(ref v47);
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        int v49 = 3;
        v48._nodetype = unchecked((__cil_enum_020000B5)(v49));
        int v50 = 1;
        return __cil_bool_store(v50);
        IL_00C9: ;
        int v51 = 0;
        return __cil_bool_store(v51);
        IL_00CB: ;
        global::System.Xml.XmlSqlBinaryReader v52 = this;
        global::System.Xml.XmlSqlBinaryReader v53 = this;
        global::System.Xml.XmlReader v54 = v53._textXmlReader;
        int v55 = __cil_bool_load(__cil_callvirt_06000EF4(v54));
        int v56 = __cil_bool_load(__cil_direct_060007FB(v52, __cil_bool_store(v55)));
        return __cil_bool_store(v56);
        IL_00DD: ;
        int v57 = 0;
        return __cil_bool_store(v57);
    }

    public override void Close()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        this._state = unchecked((__cil_enum_0200006C)(8));
        this._nodetype = unchecked((__cil_enum_020000B5)(0));
        this._token = unchecked((__cil_enum_02000073)(0));
        this._stringValue = null;
        global::System.Xml.XmlReader v8 = this._textXmlReader;
        if (v8 is null) {
            goto IL_0036;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        global::System.Xml.XmlReader v10 = this._textXmlReader;
        __cil_callvirt_06000EF7(v10);
        this._textXmlReader = null;
        IL_0036: ;
        __cil_type_01000049 v13 = this._inStrm;
        if (v13 is null) {
            goto IL_0051;
        } else {
            goto IL_003E;
        }
        IL_003E: ;
        int v15 = __cil_bool_load(this._closeInput);
        if (v15 == 0) {
            goto IL_0051;
        } else {
            goto IL_0046;
        }
        IL_0046: ;
        __cil_type_01000049 v17 = this._inStrm;
        v17.Dispose();
        IL_0051: ;
        this._inStrm = null;
        l0 = 0;
        this._end = 0;
        int v22 = l0;
        this._pos = v22;
        return;
    }

    public override System.Xml.XmlNameTable get_NameTable()
    {
        global::System.Xml.XmlNameTable v1 = this._xnt;
        return v1;
    }

    public override string LookupNamespace(string prefix)
    {
        // structural signature __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af bytes=151280D1020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l0 = default;
        IL_0000: ;
        int v0 = 1;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = unchecked((int)(v1._state));
        if (unchecked((uint)v0) != unchecked((uint)v2)) {
            goto IL_0016;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        global::System.Xml.XmlReader v4 = v3._textXmlReader;
        string v5 = prefix;
        string v6 = __cil_callvirt_06000EFB(v4, v5);
        return v6;
        IL_0016: ;
        string v7 = prefix;
        if (v7 is null) {
            goto IL_0030;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v9 = v8._namespaces;
        string v10 = prefix;
        ref global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v11 = ref l0;
        int v12 = __cil_bool_load(__cil_callvirt_0A0000A2(v9, v10, ref v11));
        if (v12 == 0) {
            goto IL_0030;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v13 = l0;
        string v14 = v13.uri;
        return v14;
        IL_0030: ;
        return null;
    }

    public override void ResolveEntity()
    {
        global::System.NotSupportedException v0 = __cil_newobj_0A0000A3();
        throw v0;
    }

    public override System.Xml.ReadState get_ReadState()
    {
        // IL fallback: expected int[] or uint[] evaluation-stack value
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [7E, 84, 01, 00, 04, 02, 7B, 96, 01, 00, 04, 94, 2A]
        // IL_0000: ldsfld 0x04000184 System.Xml.XmlSqlBinaryReader::s_scanState2ReadState
        // IL_0005: ldarg.0 0
        // IL_0006: ldfld 0x04000196 System.Xml.XmlSqlBinaryReader::_state
        // IL_000B: ldelem.i4 
        // IL_000C: ret 
    }

    public override bool Read()
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        bool l1 = default;
        System.OverflowException l2 = default;
        System.OverflowException s9_0 = default;
        object s10_0 = default;
        try {
            IL_0000: ;
            global::System.Xml.XmlSqlBinaryReader v0 = this;
            int v1 = unchecked((int)(v0._state));
            l0 = unchecked((__cil_enum_0200006C)(v1));
            int v2 = unchecked((int)(l0));
            switch (v2) {
                case 0: {
                    goto IL_0031;
                }
                case 1: {
                    goto IL_003A;
                }
                case 2: {
                    goto IL_0068;
                }
                case 3: {
                    goto IL_0068;
                }
                case 4: {
                    goto IL_0068;
                }
                case 5: {
                    goto IL_0027;
                }
                default: {
                    goto IL_0025;
                } }
            IL_0025: ;
            goto IL_0071;
            IL_0027: ;
            global::System.Xml.XmlSqlBinaryReader v3 = this;
            int v4 = 0;
            int v5 = __cil_bool_load(__cil_direct_060007E7(v3, __cil_bool_store(v4)));
            l1 = __cil_bool_store(v5);
            goto IL_0094;
            IL_0031: ;
            global::System.Xml.XmlSqlBinaryReader v6 = this;
            int v7 = __cil_bool_load(__cil_direct_060007EF(v6));
            l1 = __cil_bool_store(v7);
            goto IL_0094;
            IL_003A: ;
            global::System.Xml.XmlSqlBinaryReader v8 = this;
            global::System.Xml.XmlReader v9 = v8._textXmlReader;
            int v10 = __cil_bool_load(__cil_callvirt_06000EF5(v9));
            if (v10 == 0) {
                goto IL_0051;
            } else {
                goto IL_0047;
            }
            IL_0047: ;
            global::System.Xml.XmlSqlBinaryReader v11 = this;
            int v12 = 1;
            int v13 = __cil_bool_load(__cil_direct_060007FB(v11, __cil_bool_store(v12)));
            l1 = __cil_bool_store(v13);
            goto IL_0094;
            IL_0051: ;
            global::System.Xml.XmlSqlBinaryReader v14 = this;
            int v15 = 0;
            v14._state = unchecked((__cil_enum_0200006C)(v15));
            global::System.Xml.XmlSqlBinaryReader v16 = this;
            int v17 = 0;
            v16._nodetype = unchecked((__cil_enum_020000B5)(v17));
            global::System.Xml.XmlSqlBinaryReader v18 = this;
            int v19 = 0;
            v18._isEmpty = __cil_bool_store(v19);
            goto IL_0031;
            IL_0068: ;
            global::System.Xml.XmlSqlBinaryReader v20 = this;
            int v21 = __cil_bool_load(__cil_callvirt_06000EF3(v20));
            goto IL_0031;
            IL_0071: ;
            int v22 = 0;
            l1 = __cil_bool_store(v22);
            goto IL_0094;
        }
        catch (System.OverflowException __cil_exception_0) {
            IL_0075: ;
            s9_0 = __cil_exception_0;
            l2 = s9_0;
            global::System.Xml.XmlSqlBinaryReader v23 = this;
            int v24 = 6;
            v23._state = unchecked((__cil_enum_0200006C)(v24));
            global::System.OverflowException v25 = l2;
            string v26 = ((System.Exception)v25).Message;
            global::System.OverflowException v27 = l2;
            global::System.Xml.XmlException v28 = __cil_newobj_06000A07(v26, v27);
            throw v28;
        }
        catch {
            IL_008A: ;
            global::System.Xml.XmlSqlBinaryReader v29 = this;
            int v30 = 6;
            v29._state = unchecked((__cil_enum_0200006C)(v30));
            throw;
        }
        IL_0094: ;
        int v31 = __cil_bool_load(l1);
        return __cil_bool_store(v31);
    }

    private bool SetupContentAsXXX(string name)
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200006C l0 = default;
        __cil_enum_02000073 l1 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(v0)));
        int v2 = __cil_bool_load(System.Xml.XmlReader.CanReadContentAs(unchecked((__cil_enum_020000B5)(v1))));
        if (v2 != 0) {
            goto IL_0015;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        string v4 = name;
        global::System.Exception v5 = __cil_direct_06000F29(v3, v4);
        throw v5;
        IL_0015: ;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        int v7 = unchecked((int)(v6._state));
        l0 = unchecked((__cil_enum_0200006C)(v7));
        int v8 = unchecked((int)(l0));
        switch (v8) {
            case 0: {
                goto IL_0037;
            }
            case 1: {
                goto IL_00CC;
            }
            case 2: {
                goto IL_0085;
            }
            case 3: {
                goto IL_00CA;
            }
            default: {
                goto IL_0032;
            } }
        IL_0032: ;
        goto IL_00CC;
        IL_0037: ;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        int v10 = unchecked((int)(__cil_callvirt_06000EB8(v9)));
        int v11 = 15;
        if (unchecked((uint)v10) != unchecked((uint)v11)) {
            goto IL_0043;
        } else {
            goto IL_0041;
        }
        IL_0041: ;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0043: ;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = unchecked((int)(__cil_callvirt_06000EB8(v13)));
        int v15 = 7;
        if (v14 == v15) {
            goto IL_0055;
        } else {
            goto IL_004C;
        }
        IL_004C: ;
        global::System.Xml.XmlSqlBinaryReader v16 = this;
        int v17 = unchecked((int)(__cil_callvirt_06000EB8(v16)));
        int v18 = 8;
        if (unchecked((uint)v17) != unchecked((uint)v18)) {
            goto IL_007B;
        } else {
            goto IL_0055;
        }
        IL_0055: ;
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        int v20 = __cil_bool_load(__cil_callvirt_06000EF5(v19));
        if (v20 == 0) {
            goto IL_006F;
        } else {
            goto IL_005D;
        }
        IL_005D: ;
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        int v22 = unchecked((int)(__cil_callvirt_06000EB8(v21)));
        int v23 = 7;
        if (v22 == v23) {
            goto IL_0055;
        } else {
            goto IL_0066;
        }
        IL_0066: ;
        global::System.Xml.XmlSqlBinaryReader v24 = this;
        int v25 = unchecked((int)(__cil_callvirt_06000EB8(v24)));
        int v26 = 8;
        if (v25 == v26) {
            goto IL_0055;
        } else {
            goto IL_006F;
        }
        IL_006F: ;
        global::System.Xml.XmlSqlBinaryReader v27 = this;
        int v28 = unchecked((int)(__cil_callvirt_06000EB8(v27)));
        int v29 = 15;
        if (unchecked((uint)v28) != unchecked((uint)v29)) {
            goto IL_007B;
        } else {
            goto IL_0079;
        }
        IL_0079: ;
        int v30 = 1;
        return __cil_bool_store(v30);
        IL_007B: ;
        global::System.Xml.XmlSqlBinaryReader v31 = this;
        int v32 = __cil_bool_load(v31._hasTypedValue);
        if (v32 == 0) {
            goto IL_00CC;
        } else {
            goto IL_0083;
        }
        IL_0083: ;
        int v33 = 1;
        return __cil_bool_store(v33);
        IL_0085: ;
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        global::System.Xml.XmlSqlBinaryReader v35 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v36 = v35._attributes;
        global::System.Xml.XmlSqlBinaryReader v37 = this;
        int v38 = v37._attrIndex;
        int v39 = 1;
        int v40 = unchecked(v38 - v39);
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v41 = ref __cil_ldelema_0200006F(v36, v40);
        int v42 = v41.contentPos;
        v34._pos = v42;
        global::System.Xml.XmlSqlBinaryReader v43 = this;
        int v44 = unchecked((int)(__cil_direct_060007D8(v43)));
        l1 = unchecked((__cil_enum_02000073)(v44));
        int v45 = 246;
        int v46 = unchecked((int)(l1));
        if (v45 == v46) {
            goto IL_00CC;
        } else {
            goto IL_00B2;
        }
        IL_00B2: ;
        int v47 = 245;
        int v48 = unchecked((int)(l1));
        if (v47 == v48) {
            goto IL_00CC;
        } else {
            goto IL_00BA;
        }
        IL_00BA: ;
        global::System.Xml.XmlSqlBinaryReader v49 = this;
        int v50 = unchecked((int)(l1));
        v49._token = unchecked((__cil_enum_02000073)(v50));
        global::System.Xml.XmlSqlBinaryReader v51 = this;
        int v52 = unchecked((int)(l1));
        __cil_direct_060007FF(v51, unchecked((__cil_enum_02000073)(v52)));
        int v53 = 1;
        return __cil_bool_store(v53);
        IL_00CA: ;
        int v54 = 1;
        return __cil_bool_store(v54);
        IL_00CC: ;
        int v55 = 0;
        return __cil_bool_store(v55);
    }

    private int FinishContentAsXXX(int origPos)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        int v1 = unchecked((int)(this._state));
        if (v1 != 0) {
            return origPos;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v3 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (v3 == 1) {
            goto IL_0045;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        int v6 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (v6 == 15) {
            goto IL_0045;
        } else {
            goto IL_001B;
        }
        IL_001B: ;
        int v9 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v9 == 0) {
            goto IL_0045;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        int v11 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        l0 = unchecked((__cil_enum_020000B5)(v11));
        int v12 = unchecked((int)(l0));
        if (v12 == 1) {
            goto IL_0045;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        int v14 = unchecked((int)(l0));
        int v16 = unchecked(v14 - 7);
        if (unchecked((uint)v16) <= unchecked((uint)1)) {
            goto IL_001B;
        } else {
            goto IL_0034;
        }
        IL_0034: ;
        int v18 = unchecked((int)(l0));
        if (v18 == 15) {
            goto IL_0045;
        } else {
            goto IL_0039;
        }
        IL_0039: ;
        string v21 = System.SR.get_XmlBinary_ListsOfValuesNotSupported();
        global::System.Exception v22 = __cil_direct_0600081D(this, v21);
        throw v22;
        IL_0045: ;
        int v24 = this._pos;
        return v24;
    }

    public override bool ReadContentAsBoolean()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        bool l1 = default;
        __cil_enum_02000073 l2 = default;
        bool l3 = default;
        System.InvalidCastException l4 = default;
        System.FormatException l5 = default;
        System.InvalidCastException s12_0 = default;
        System.FormatException s13_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        int v2 = 0;
        l1 = __cil_bool_store(v2);
        try {
            IL_0009: ;
            global::System.Xml.XmlSqlBinaryReader v3 = this;
            string v4 = __cil_ldstr_7000CF01("ReadContentAsBoolean");
            int v5 = __cil_bool_load(__cil_direct_060007B4(v3, v4));
            if (v5 == 0) {
                goto IL_0171;
            } else {
            }
            try {
                IL_0019: ;
                global::System.Xml.XmlSqlBinaryReader v6 = this;
                int v7 = unchecked((int)(v6._token));
                l2 = unchecked((__cil_enum_02000073)(v7));
                int v8 = unchecked((int)(l2));
                int v9 = 1;
                int v10 = unchecked(v8 - v9);
                switch (v10) {
                    case 0: {
                        goto IL_0108;
                    }
                    case 1: {
                        goto IL_0108;
                    }
                    case 2: {
                        goto IL_0108;
                    }
                    case 3: {
                        goto IL_0108;
                    }
                    case 4: {
                        goto IL_0108;
                    }
                    case 5: {
                        goto IL_0108;
                    }
                    case 6: {
                        goto IL_0108;
                    }
                    case 7: {
                        goto IL_0108;
                    }
                    case 8: {
                        goto IL_0108;
                    }
                    case 9: {
                        goto IL_0108;
                    }
                    case 10: {
                        goto IL_0108;
                    }
                    case 11: {
                        goto IL_0108;
                    }
                    case 12: {
                        goto IL_0128;
                    }
                    case 13: {
                        goto IL_0128;
                    }
                    case 14: {
                        goto IL_0108;
                    }
                    case 15: {
                        goto IL_0128;
                    }
                    case 16: {
                        goto IL_0128;
                    }
                    case 17: {
                        goto IL_0108;
                    }
                    case 18: {
                        goto IL_0108;
                    }
                    case 19: {
                        goto IL_0108;
                    }
                    case 20: {
                        goto IL_0137;
                    }
                    case 21: {
                        goto IL_0128;
                    }
                    case 22: {
                        goto IL_0108;
                    }
                    case 23: {
                        goto IL_0128;
                    }
                    case 24: {
                        goto IL_0137;
                    }
                    case 25: {
                        goto IL_0137;
                    }
                    case 26: {
                        goto IL_0108;
                    }
                    default: {
                        goto IL_0094;
                    } }
                IL_0094: ;
                int v11 = unchecked((int)(l2));
                int v12 = 122;
                int v13 = unchecked(v11 - v12);
                switch (v13) {
                    case 0: {
                        goto IL_0108;
                    }
                    case 1: {
                        goto IL_0108;
                    }
                    case 2: {
                        goto IL_0108;
                    }
                    case 3: {
                        goto IL_0108;
                    }
                    case 4: {
                        goto IL_0108;
                    }
                    case 5: {
                        goto IL_0108;
                    }
                    case 6: {
                        goto IL_0137;
                    }
                    case 7: {
                        goto IL_0108;
                    }
                    case 8: {
                        goto IL_0108;
                    }
                    case 9: {
                        goto IL_0108;
                    }
                    case 10: {
                        goto IL_0108;
                    }
                    case 11: {
                        goto IL_0108;
                    }
                    case 12: {
                        goto IL_00F5;
                    }
                    case 13: {
                        goto IL_0108;
                    }
                    case 14: {
                        goto IL_0108;
                    }
                    case 15: {
                        goto IL_0108;
                    }
                    case 16: {
                        goto IL_0108;
                    }
                    case 17: {
                        goto IL_0108;
                    }
                    case 18: {
                        goto IL_0108;
                    }
                    default: {
                        goto IL_00E9;
                    } }
                IL_00E9: ;
                int v14 = unchecked((int)(l2));
                int v15 = 247;
                int v16 = unchecked(v14 - v15);
                int v17 = 1;
                if (unchecked((uint)v16) <= unchecked((uint)v17)) {
                    goto IL_012A;
                } else {
                    goto IL_00F3;
                }
                IL_00F3: ;
                goto IL_0137;
                IL_00F5: ;
                global::System.Xml.XmlSqlBinaryReader v18 = this;
                __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v19 = v18._data;
                global::System.Xml.XmlSqlBinaryReader v20 = this;
                int v21 = v20._tokDataPos;
                int v22 = unchecked((int)(unchecked((byte)(unchecked((int)(v19[v21]))))));
                int v23 = 0;
                int v24 = (unchecked((uint)v22) > unchecked((uint)v23) ? 1 : 0);
                l1 = __cil_bool_store(v24);
                goto IL_0139;
                IL_0108: ;
                string v25 = System.SR.get_XmlBinary_CastNotSupported();
                global::System.Xml.XmlSqlBinaryReader v26 = this;
                int v27 = unchecked((int)(v26._token));
                object v28 = ((object)((System.Xml.BinXmlToken)(v27)));
                string v29 = __cil_ldstr_7000CF2B("Boolean");
                string v30 = System.SR.Format(v25, v28, ((object)(v29)));
                global::System.InvalidCastException v31 = __cil_newobj_0A0000A5(v30);
                throw v31;
                IL_0128: ;
                goto IL_017B;
                IL_012A: ;
                string v32 = __cil_ldsfld_0A000002();
                int v33 = __cil_bool_load(System.Xml.XmlConvert.ToBoolean(v32));
                l3 = __cil_bool_store(v33);
                goto IL_0182;
                IL_0137: ;
                goto IL_017B;
                IL_0139: ;
                goto IL_0165;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_013B: ;
                s12_0 = __cil_exception_0;
                l4 = s12_0;
                string v34 = System.SR.get_Xml_ReadContentAsFormatException();
                string v35 = __cil_ldstr_7000CF2B("Boolean");
                global::System.InvalidCastException v36 = l4;
                global::System.Xml.XmlException v37 = __cil_newobj_06000A0E(v34, v35, v36, null);
                throw v37;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0150: ;
                s13_0 = __cil_exception_1;
                l5 = s13_0;
                string v38 = System.SR.get_Xml_ReadContentAsFormatException();
                string v39 = __cil_ldstr_7000CF2B("Boolean");
                global::System.FormatException v40 = l5;
                global::System.Xml.XmlException v41 = __cil_newobj_06000A0E(v38, v39, v40, null);
                throw v41;
            }
            IL_0165: ;
            global::System.Xml.XmlSqlBinaryReader v42 = this;
            int v43 = l0;
            int v44 = __cil_direct_060007B5(v42, v43);
            l0 = v44;
            int v45 = __cil_bool_load(l1);
            l3 = __cil_bool_store(v45);
            goto IL_0182;
            IL_0171: ;
            goto IL_017B;
        }
        finally {
            IL_0173: ;
            global::System.Xml.XmlSqlBinaryReader v46 = this;
            int v47 = l0;
            v46._pos = v47;
            goto __cil_finally_end_2;
            __cil_finally_end_2: ;
        }
        IL_017B: ;
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        int v49 = __cil_bool_load(__cil_direct_06000EC9(v48));
        return __cil_bool_store(v49);
        IL_0182: ;
        int v50 = __cil_bool_load(l3);
        return __cil_bool_store(v50);
    }

    public override System.DateTime ReadContentAsDateTime()
    {
        // structural signature __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b bytes=118145: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200009E alias=__cil_enum_0200009E underlying=int: global::@System.@Xml.@XmlDateTimeSerializationMode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b l1 = default;
        __cil_enum_02000073 l2 = default;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b l3 = default;
        System.InvalidCastException l4 = default;
        System.FormatException l5 = default;
        System.OverflowException l6 = default;
        System.InvalidCastException s12_0 = default;
        System.FormatException s13_0 = default;
        System.OverflowException s14_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        try {
            IL_0007: ;
            global::System.Xml.XmlSqlBinaryReader v2 = this;
            string v3 = __cil_ldstr_7000CF3B("ReadContentAsDateTime");
            int v4 = __cil_bool_load(__cil_direct_060007B4(v2, v3));
            if (v4 == 0) {
                goto IL_017B;
            } else {
            }
            try {
                IL_0017: ;
                global::System.Xml.XmlSqlBinaryReader v5 = this;
                int v6 = unchecked((int)(v5._token));
                l2 = unchecked((__cil_enum_02000073)(v6));
                int v7 = unchecked((int)(l2));
                int v8 = 1;
                int v9 = unchecked(v7 - v8);
                switch (v9) {
                    case 0: {
                        goto IL_00FC;
                    }
                    case 1: {
                        goto IL_00FC;
                    }
                    case 2: {
                        goto IL_00FC;
                    }
                    case 3: {
                        goto IL_00FC;
                    }
                    case 4: {
                        goto IL_00FC;
                    }
                    case 5: {
                        goto IL_00FC;
                    }
                    case 6: {
                        goto IL_00FC;
                    }
                    case 7: {
                        goto IL_00FC;
                    }
                    case 8: {
                        goto IL_00FC;
                    }
                    case 9: {
                        goto IL_00FC;
                    }
                    case 10: {
                        goto IL_00FC;
                    }
                    case 11: {
                        goto IL_00FC;
                    }
                    case 12: {
                        goto IL_011C;
                    }
                    case 13: {
                        goto IL_011C;
                    }
                    case 14: {
                        goto IL_00FC;
                    }
                    case 15: {
                        goto IL_011C;
                    }
                    case 16: {
                        goto IL_011C;
                    }
                    case 17: {
                        goto IL_00F3;
                    }
                    case 18: {
                        goto IL_00F3;
                    }
                    case 19: {
                        goto IL_00FC;
                    }
                    case 20: {
                        goto IL_012C;
                    }
                    case 21: {
                        goto IL_011C;
                    }
                    case 22: {
                        goto IL_00FC;
                    }
                    case 23: {
                        goto IL_011C;
                    }
                    case 24: {
                        goto IL_012C;
                    }
                    case 25: {
                        goto IL_012C;
                    }
                    case 26: {
                        goto IL_00FC;
                    }
                    default: {
                        goto IL_0092;
                    } }
                IL_0092: ;
                int v10 = unchecked((int)(l2));
                int v11 = 122;
                int v12 = unchecked(v10 - v11);
                switch (v12) {
                    case 0: {
                        goto IL_00F3;
                    }
                    case 1: {
                        goto IL_00F3;
                    }
                    case 2: {
                        goto IL_00F3;
                    }
                    case 3: {
                        goto IL_00F3;
                    }
                    case 4: {
                        goto IL_00F3;
                    }
                    case 5: {
                        goto IL_00F3;
                    }
                    case 6: {
                        goto IL_012C;
                    }
                    case 7: {
                        goto IL_00F3;
                    }
                    case 8: {
                        goto IL_00F3;
                    }
                    case 9: {
                        goto IL_00F3;
                    }
                    case 10: {
                        goto IL_00FC;
                    }
                    case 11: {
                        goto IL_00FC;
                    }
                    case 12: {
                        goto IL_00FC;
                    }
                    case 13: {
                        goto IL_00FC;
                    }
                    case 14: {
                        goto IL_00FC;
                    }
                    case 15: {
                        goto IL_00FC;
                    }
                    case 16: {
                        goto IL_00FC;
                    }
                    case 17: {
                        goto IL_00FC;
                    }
                    case 18: {
                        goto IL_00FC;
                    }
                    default: {
                        goto IL_00E7;
                    } }
                IL_00E7: ;
                int v13 = unchecked((int)(l2));
                int v14 = 247;
                int v15 = unchecked(v13 - v14);
                int v16 = 1;
                if (unchecked((uint)v15) <= unchecked((uint)v16)) {
                    goto IL_011E;
                } else {
                    goto IL_00F1;
                }
                IL_00F1: ;
                goto IL_012C;
                IL_00F3: ;
                global::System.Xml.XmlSqlBinaryReader v17 = this;
                __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v18 = __cil_direct_0600080B(v17);
                l1 = v18;
                goto IL_012E;
                IL_00FC: ;
                string v19 = System.SR.get_XmlBinary_CastNotSupported();
                global::System.Xml.XmlSqlBinaryReader v20 = this;
                int v21 = unchecked((int)(v20._token));
                object v22 = ((object)((System.Xml.BinXmlToken)(v21)));
                string v23 = __cil_ldstr_7000CF67("DateTime");
                string v24 = System.SR.Format(v19, v22, ((object)(v23)));
                global::System.InvalidCastException v25 = __cil_newobj_0A0000A5(v24);
                throw v25;
                IL_011C: ;
                goto IL_0185;
                IL_011E: ;
                string v26 = __cil_ldsfld_0A000002();
                int v27 = 3;
                __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v28 = System.Xml.XmlConvert.ToDateTime(v26, unchecked((__cil_enum_0200009E)(v27)));
                l3 = v28;
                goto IL_018C;
                IL_012C: ;
                goto IL_0185;
                IL_012E: ;
                goto IL_016F;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_0130: ;
                s12_0 = __cil_exception_0;
                l4 = s12_0;
                string v29 = System.SR.get_Xml_ReadContentAsFormatException();
                string v30 = __cil_ldstr_7000CF67("DateTime");
                global::System.InvalidCastException v31 = l4;
                global::System.Xml.XmlException v32 = __cil_newobj_06000A0E(v29, v30, v31, null);
                throw v32;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0145: ;
                s13_0 = __cil_exception_1;
                l5 = s13_0;
                string v33 = System.SR.get_Xml_ReadContentAsFormatException();
                string v34 = __cil_ldstr_7000CF67("DateTime");
                global::System.FormatException v35 = l5;
                global::System.Xml.XmlException v36 = __cil_newobj_06000A0E(v33, v34, v35, null);
                throw v36;
            }
            catch (System.OverflowException __cil_exception_2) {
                IL_015A: ;
                s14_0 = __cil_exception_2;
                l6 = s14_0;
                string v37 = System.SR.get_Xml_ReadContentAsFormatException();
                string v38 = __cil_ldstr_7000CF67("DateTime");
                global::System.OverflowException v39 = l6;
                global::System.Xml.XmlException v40 = __cil_newobj_06000A0E(v37, v38, v39, null);
                throw v40;
            }
            IL_016F: ;
            global::System.Xml.XmlSqlBinaryReader v41 = this;
            int v42 = l0;
            int v43 = __cil_direct_060007B5(v41, v42);
            l0 = v43;
            __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v44 = l1;
            l3 = v44;
            goto IL_018C;
            IL_017B: ;
            goto IL_0185;
        }
        finally {
            IL_017D: ;
            global::System.Xml.XmlSqlBinaryReader v45 = this;
            int v46 = l0;
            v45._pos = v46;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_0185: ;
        global::System.Xml.XmlSqlBinaryReader v47 = this;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v48 = __cil_direct_06000ECA(v47);
        return v48;
        IL_018C: ;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v49 = l3;
        return v49;
    }

    public override double ReadContentAsDouble()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        double l1 = default;
        __cil_enum_02000073 l2 = default;
        double l3 = default;
        System.InvalidCastException l4 = default;
        System.FormatException l5 = default;
        System.OverflowException l6 = default;
        System.InvalidCastException s15_0 = default;
        System.FormatException s16_0 = default;
        System.OverflowException s17_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        try {
            IL_0007: ;
            global::System.Xml.XmlSqlBinaryReader v2 = this;
            string v3 = __cil_ldstr_7000CF79("ReadContentAsDouble");
            int v4 = __cil_bool_load(__cil_direct_060007B4(v2, v3));
            if (v4 == 0) {
                goto IL_013E;
            } else {
            }
            try {
                IL_0017: ;
                global::System.Xml.XmlSqlBinaryReader v5 = this;
                int v6 = unchecked((int)(v5._token));
                l2 = unchecked((__cil_enum_02000073)(v6));
                int v7 = unchecked((int)(l2));
                int v8 = 127;
                if (v7 > v8) {
                    goto IL_00A0;
                } else {
                    goto IL_0023;
                }
                IL_0023: ;
                int v9 = unchecked((int)(l2));
                int v10 = 1;
                int v11 = unchecked(v9 - v10);
                switch (v11) {
                    case 0: {
                        goto IL_00C0;
                    }
                    case 1: {
                        goto IL_00C0;
                    }
                    case 2: {
                        goto IL_00B7;
                    }
                    case 3: {
                        goto IL_00B7;
                    }
                    case 4: {
                        goto IL_00C0;
                    }
                    case 5: {
                        goto IL_00C0;
                    }
                    case 6: {
                        goto IL_00C0;
                    }
                    case 7: {
                        goto IL_00C0;
                    }
                    case 8: {
                        goto IL_00C0;
                    }
                    case 9: {
                        goto IL_00C0;
                    }
                    case 10: {
                        goto IL_00C0;
                    }
                    case 11: {
                        goto IL_00C0;
                    }
                    case 12: {
                        goto IL_00E0;
                    }
                    case 13: {
                        goto IL_00E0;
                    }
                    case 14: {
                        goto IL_00C0;
                    }
                    case 15: {
                        goto IL_00E0;
                    }
                    case 16: {
                        goto IL_00E0;
                    }
                    case 17: {
                        goto IL_00C0;
                    }
                    case 18: {
                        goto IL_00C0;
                    }
                    case 19: {
                        goto IL_00C0;
                    }
                    case 20: {
                        goto IL_00EF;
                    }
                    case 21: {
                        goto IL_00E0;
                    }
                    case 22: {
                        goto IL_00C0;
                    }
                    case 23: {
                        goto IL_00E0;
                    }
                    case 24: {
                        goto IL_00EF;
                    }
                    case 25: {
                        goto IL_00EF;
                    }
                    case 26: {
                        goto IL_00C0;
                    }
                    default: {
                        goto IL_0097;
                    } }
                IL_0097: ;
                int v12 = unchecked((int)(l2));
                int v13 = 122;
                int v14 = unchecked(v12 - v13);
                int v15 = 5;
                if (unchecked((uint)v14) <= unchecked((uint)v15)) {
                    goto IL_00C0;
                } else {
                    goto IL_009E;
                }
                IL_009E: ;
                goto IL_00EF;
                IL_00A0: ;
                int v16 = unchecked((int)(l2));
                int v17 = 129;
                int v18 = unchecked(v16 - v17);
                int v19 = 11;
                if (unchecked((uint)v18) <= unchecked((uint)v19)) {
                    goto IL_00C0;
                } else {
                    goto IL_00AB;
                }
                IL_00AB: ;
                int v20 = unchecked((int)(l2));
                int v21 = 247;
                int v22 = unchecked(v20 - v21);
                int v23 = 1;
                if (unchecked((uint)v22) <= unchecked((uint)v23)) {
                    goto IL_00E2;
                } else {
                    goto IL_00B5;
                }
                IL_00B5: ;
                goto IL_00EF;
                IL_00B7: ;
                global::System.Xml.XmlSqlBinaryReader v24 = this;
                double v25 = __cil_direct_0600080A(v24);
                l1 = unchecked((double)(v25));
                goto IL_00F1;
                IL_00C0: ;
                string v26 = System.SR.get_XmlBinary_CastNotSupported();
                global::System.Xml.XmlSqlBinaryReader v27 = this;
                int v28 = unchecked((int)(v27._token));
                object v29 = ((object)((System.Xml.BinXmlToken)(v28)));
                string v30 = __cil_ldstr_7000CFA1("Double");
                string v31 = System.SR.Format(v26, v29, ((object)(v30)));
                global::System.InvalidCastException v32 = __cil_newobj_0A0000A5(v31);
                throw v32;
                IL_00E0: ;
                goto IL_0148;
                IL_00E2: ;
                string v33 = __cil_ldsfld_0A000002();
                double v34 = System.Xml.XmlConvert.ToDouble(v33);
                l3 = unchecked((double)(v34));
                goto IL_014F;
                IL_00EF: ;
                goto IL_0148;
                IL_00F1: ;
                goto IL_0132;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_00F3: ;
                s15_0 = __cil_exception_0;
                l4 = s15_0;
                string v35 = System.SR.get_Xml_ReadContentAsFormatException();
                string v36 = __cil_ldstr_7000CFA1("Double");
                global::System.InvalidCastException v37 = l4;
                global::System.Xml.XmlException v38 = __cil_newobj_06000A0E(v35, v36, v37, null);
                throw v38;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0108: ;
                s16_0 = __cil_exception_1;
                l5 = s16_0;
                string v39 = System.SR.get_Xml_ReadContentAsFormatException();
                string v40 = __cil_ldstr_7000CFA1("Double");
                global::System.FormatException v41 = l5;
                global::System.Xml.XmlException v42 = __cil_newobj_06000A0E(v39, v40, v41, null);
                throw v42;
            }
            catch (System.OverflowException __cil_exception_2) {
                IL_011D: ;
                s17_0 = __cil_exception_2;
                l6 = s17_0;
                string v43 = System.SR.get_Xml_ReadContentAsFormatException();
                string v44 = __cil_ldstr_7000CFA1("Double");
                global::System.OverflowException v45 = l6;
                global::System.Xml.XmlException v46 = __cil_newobj_06000A0E(v43, v44, v45, null);
                throw v46;
            }
            IL_0132: ;
            global::System.Xml.XmlSqlBinaryReader v47 = this;
            int v48 = l0;
            int v49 = __cil_direct_060007B5(v47, v48);
            l0 = v49;
            double v50 = l1;
            l3 = unchecked((double)(v50));
            goto IL_014F;
            IL_013E: ;
            goto IL_0148;
        }
        finally {
            IL_0140: ;
            global::System.Xml.XmlSqlBinaryReader v51 = this;
            int v52 = l0;
            v51._pos = v52;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_0148: ;
        global::System.Xml.XmlSqlBinaryReader v53 = this;
        double v54 = __cil_direct_06000ECC(v53);
        return unchecked((double)(v54));
        IL_014F: ;
        double v55 = l3;
        return unchecked((double)(v55));
    }

    public override float ReadContentAsFloat()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_F l1 = default;
        __cil_enum_02000073 l2 = default;
        __cil_F l3 = default;
        System.InvalidCastException l4 = default;
        System.FormatException l5 = default;
        System.OverflowException l6 = default;
        System.InvalidCastException s15_0 = default;
        System.FormatException s16_0 = default;
        System.OverflowException s17_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        try {
            IL_0007: ;
            global::System.Xml.XmlSqlBinaryReader v2 = this;
            string v3 = __cil_ldstr_7000CFAF("ReadContentAsFloat");
            int v4 = __cil_bool_load(__cil_direct_060007B4(v2, v3));
            if (v4 == 0) {
                goto IL_013F;
            } else {
            }
            try {
                IL_0017: ;
                global::System.Xml.XmlSqlBinaryReader v5 = this;
                int v6 = unchecked((int)(v5._token));
                l2 = unchecked((__cil_enum_02000073)(v6));
                int v7 = unchecked((int)(l2));
                int v8 = 127;
                if (v7 > v8) {
                    goto IL_00A0;
                } else {
                    goto IL_0023;
                }
                IL_0023: ;
                int v9 = unchecked((int)(l2));
                int v10 = 1;
                int v11 = unchecked(v9 - v10);
                switch (v11) {
                    case 0: {
                        goto IL_00C1;
                    }
                    case 1: {
                        goto IL_00C1;
                    }
                    case 2: {
                        goto IL_00B7;
                    }
                    case 3: {
                        goto IL_00B7;
                    }
                    case 4: {
                        goto IL_00C1;
                    }
                    case 5: {
                        goto IL_00C1;
                    }
                    case 6: {
                        goto IL_00C1;
                    }
                    case 7: {
                        goto IL_00C1;
                    }
                    case 8: {
                        goto IL_00C1;
                    }
                    case 9: {
                        goto IL_00C1;
                    }
                    case 10: {
                        goto IL_00C1;
                    }
                    case 11: {
                        goto IL_00C1;
                    }
                    case 12: {
                        goto IL_00E1;
                    }
                    case 13: {
                        goto IL_00E1;
                    }
                    case 14: {
                        goto IL_00C1;
                    }
                    case 15: {
                        goto IL_00E1;
                    }
                    case 16: {
                        goto IL_00E1;
                    }
                    case 17: {
                        goto IL_00C1;
                    }
                    case 18: {
                        goto IL_00C1;
                    }
                    case 19: {
                        goto IL_00C1;
                    }
                    case 20: {
                        goto IL_00F0;
                    }
                    case 21: {
                        goto IL_00E1;
                    }
                    case 22: {
                        goto IL_00C1;
                    }
                    case 23: {
                        goto IL_00E1;
                    }
                    case 24: {
                        goto IL_00F0;
                    }
                    case 25: {
                        goto IL_00F0;
                    }
                    case 26: {
                        goto IL_00C1;
                    }
                    default: {
                        goto IL_0097;
                    } }
                IL_0097: ;
                int v12 = unchecked((int)(l2));
                int v13 = 122;
                int v14 = unchecked(v12 - v13);
                int v15 = 5;
                if (unchecked((uint)v14) <= unchecked((uint)v15)) {
                    goto IL_00C1;
                } else {
                    goto IL_009E;
                }
                IL_009E: ;
                goto IL_00F0;
                IL_00A0: ;
                int v16 = unchecked((int)(l2));
                int v17 = 129;
                int v18 = unchecked(v16 - v17);
                int v19 = 11;
                if (unchecked((uint)v18) <= unchecked((uint)v19)) {
                    goto IL_00C1;
                } else {
                    goto IL_00AB;
                }
                IL_00AB: ;
                int v20 = unchecked((int)(l2));
                int v21 = 247;
                int v22 = unchecked(v20 - v21);
                int v23 = 1;
                if (unchecked((uint)v22) <= unchecked((uint)v23)) {
                    goto IL_00E3;
                } else {
                    goto IL_00B5;
                }
                IL_00B5: ;
                goto IL_00F0;
                IL_00B7: ;
                global::System.Xml.XmlSqlBinaryReader v24 = this;
                double v25 = __cil_direct_0600080A(v24);
                __cil_F v26 = __cil_conv_r4_float(v25);
                l1 = v26;
                goto IL_00F2;
                IL_00C1: ;
                string v27 = System.SR.get_XmlBinary_CastNotSupported();
                global::System.Xml.XmlSqlBinaryReader v28 = this;
                int v29 = unchecked((int)(v28._token));
                object v30 = ((object)((System.Xml.BinXmlToken)(v29)));
                string v31 = __cil_ldstr_7000CFD5("Float");
                string v32 = System.SR.Format(v27, v30, ((object)(v31)));
                global::System.InvalidCastException v33 = __cil_newobj_0A0000A5(v32);
                throw v33;
                IL_00E1: ;
                goto IL_0149;
                IL_00E3: ;
                string v34 = __cil_ldsfld_0A000002();
                __cil_F v35 = __cil_call_result_r4(System.Xml.XmlConvert.ToSingle(v34));
                l3 = v35;
                goto IL_0150;
                IL_00F0: ;
                goto IL_0149;
                IL_00F2: ;
                goto IL_0133;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_00F4: ;
                s15_0 = __cil_exception_0;
                l4 = s15_0;
                string v36 = System.SR.get_Xml_ReadContentAsFormatException();
                string v37 = __cil_ldstr_7000CFD5("Float");
                global::System.InvalidCastException v38 = l4;
                global::System.Xml.XmlException v39 = __cil_newobj_06000A0E(v36, v37, v38, null);
                throw v39;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0109: ;
                s16_0 = __cil_exception_1;
                l5 = s16_0;
                string v40 = System.SR.get_Xml_ReadContentAsFormatException();
                string v41 = __cil_ldstr_7000CFD5("Float");
                global::System.FormatException v42 = l5;
                global::System.Xml.XmlException v43 = __cil_newobj_06000A0E(v40, v41, v42, null);
                throw v43;
            }
            catch (System.OverflowException __cil_exception_2) {
                IL_011E: ;
                s17_0 = __cil_exception_2;
                l6 = s17_0;
                string v44 = System.SR.get_Xml_ReadContentAsFormatException();
                string v45 = __cil_ldstr_7000CFD5("Float");
                global::System.OverflowException v46 = l6;
                global::System.Xml.XmlException v47 = __cil_newobj_06000A0E(v44, v45, v46, null);
                throw v47;
            }
            IL_0133: ;
            global::System.Xml.XmlSqlBinaryReader v48 = this;
            int v49 = l0;
            int v50 = __cil_direct_060007B5(v48, v49);
            l0 = v50;
            __cil_F v51 = l1;
            l3 = v51;
            goto IL_0150;
            IL_013F: ;
            goto IL_0149;
        }
        finally {
            IL_0141: ;
            global::System.Xml.XmlSqlBinaryReader v52 = this;
            int v53 = l0;
            v52._pos = v53;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_0149: ;
        global::System.Xml.XmlSqlBinaryReader v54 = this;
        __cil_F v55 = __cil_call_result_r4(__cil_direct_06000ECD(v54));
        return __cil_return_r4(v55);
        IL_0150: ;
        __cil_F v56 = l3;
        return __cil_return_r4(v56);
    }

    public override System.Decimal ReadContentAsDecimal()
    {
        // structural signature __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f bytes=1169: valuetype [System.Runtime]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f l1 = default;
        __cil_enum_02000073 l2 = default;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f l3 = default;
        System.InvalidCastException l4 = default;
        System.FormatException l5 = default;
        System.OverflowException l6 = default;
        System.InvalidCastException s12_0 = default;
        System.FormatException s13_0 = default;
        System.OverflowException s14_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        try {
            IL_0007: ;
            global::System.Xml.XmlSqlBinaryReader v2 = this;
            string v3 = __cil_ldstr_7000CFE1("ReadContentAsDecimal");
            int v4 = __cil_bool_load(__cil_direct_060007B4(v2, v3));
            if (v4 == 0) {
                goto IL_017A;
            } else {
            }
            try {
                IL_0017: ;
                global::System.Xml.XmlSqlBinaryReader v5 = this;
                int v6 = unchecked((int)(v5._token));
                l2 = unchecked((__cil_enum_02000073)(v6));
                int v7 = unchecked((int)(l2));
                int v8 = 1;
                int v9 = unchecked(v7 - v8);
                switch (v9) {
                    case 0: {
                        goto IL_00F3;
                    }
                    case 1: {
                        goto IL_00F3;
                    }
                    case 2: {
                        goto IL_00FC;
                    }
                    case 3: {
                        goto IL_00FC;
                    }
                    case 4: {
                        goto IL_00F3;
                    }
                    case 5: {
                        goto IL_00F3;
                    }
                    case 6: {
                        goto IL_00F3;
                    }
                    case 7: {
                        goto IL_00F3;
                    }
                    case 8: {
                        goto IL_00FC;
                    }
                    case 9: {
                        goto IL_00F3;
                    }
                    case 10: {
                        goto IL_00F3;
                    }
                    case 11: {
                        goto IL_00FC;
                    }
                    case 12: {
                        goto IL_011C;
                    }
                    case 13: {
                        goto IL_011C;
                    }
                    case 14: {
                        goto IL_00FC;
                    }
                    case 15: {
                        goto IL_011C;
                    }
                    case 16: {
                        goto IL_011C;
                    }
                    case 17: {
                        goto IL_00FC;
                    }
                    case 18: {
                        goto IL_00FC;
                    }
                    case 19: {
                        goto IL_00F3;
                    }
                    case 20: {
                        goto IL_012B;
                    }
                    case 21: {
                        goto IL_011C;
                    }
                    case 22: {
                        goto IL_00FC;
                    }
                    case 23: {
                        goto IL_011C;
                    }
                    case 24: {
                        goto IL_012B;
                    }
                    case 25: {
                        goto IL_012B;
                    }
                    case 26: {
                        goto IL_00FC;
                    }
                    default: {
                        goto IL_0092;
                    } }
                IL_0092: ;
                int v10 = unchecked((int)(l2));
                int v11 = 122;
                int v12 = unchecked(v10 - v11);
                switch (v12) {
                    case 0: {
                        goto IL_00FC;
                    }
                    case 1: {
                        goto IL_00FC;
                    }
                    case 2: {
                        goto IL_00FC;
                    }
                    case 3: {
                        goto IL_00FC;
                    }
                    case 4: {
                        goto IL_00FC;
                    }
                    case 5: {
                        goto IL_00FC;
                    }
                    case 6: {
                        goto IL_012B;
                    }
                    case 7: {
                        goto IL_00FC;
                    }
                    case 8: {
                        goto IL_00FC;
                    }
                    case 9: {
                        goto IL_00FC;
                    }
                    case 10: {
                        goto IL_00FC;
                    }
                    case 11: {
                        goto IL_00FC;
                    }
                    case 12: {
                        goto IL_00FC;
                    }
                    case 13: {
                        goto IL_00F3;
                    }
                    case 14: {
                        goto IL_00F3;
                    }
                    case 15: {
                        goto IL_00F3;
                    }
                    case 16: {
                        goto IL_00F3;
                    }
                    case 17: {
                        goto IL_00F3;
                    }
                    case 18: {
                        goto IL_00FC;
                    }
                    default: {
                        goto IL_00E7;
                    } }
                IL_00E7: ;
                int v13 = unchecked((int)(l2));
                int v14 = 247;
                int v15 = unchecked(v13 - v14);
                int v16 = 1;
                if (unchecked((uint)v15) <= unchecked((uint)v16)) {
                    goto IL_011E;
                } else {
                    goto IL_00F1;
                }
                IL_00F1: ;
                goto IL_012B;
                IL_00F3: ;
                global::System.Xml.XmlSqlBinaryReader v17 = this;
                __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v18 = __cil_direct_06000809(v17);
                l1 = v18;
                goto IL_012D;
                IL_00FC: ;
                string v19 = System.SR.get_XmlBinary_CastNotSupported();
                global::System.Xml.XmlSqlBinaryReader v20 = this;
                int v21 = unchecked((int)(v20._token));
                object v22 = ((object)((System.Xml.BinXmlToken)(v21)));
                string v23 = __cil_ldstr_7000D00B("Decimal");
                string v24 = System.SR.Format(v19, v22, ((object)(v23)));
                global::System.InvalidCastException v25 = __cil_newobj_0A0000A5(v24);
                throw v25;
                IL_011C: ;
                goto IL_0184;
                IL_011E: ;
                string v26 = __cil_ldsfld_0A000002();
                __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v27 = System.Xml.XmlConvert.ToDecimal(v26);
                l3 = v27;
                goto IL_018B;
                IL_012B: ;
                goto IL_0184;
                IL_012D: ;
                goto IL_016E;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_012F: ;
                s12_0 = __cil_exception_0;
                l4 = s12_0;
                string v28 = System.SR.get_Xml_ReadContentAsFormatException();
                string v29 = __cil_ldstr_7000D00B("Decimal");
                global::System.InvalidCastException v30 = l4;
                global::System.Xml.XmlException v31 = __cil_newobj_06000A0E(v28, v29, v30, null);
                throw v31;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0144: ;
                s13_0 = __cil_exception_1;
                l5 = s13_0;
                string v32 = System.SR.get_Xml_ReadContentAsFormatException();
                string v33 = __cil_ldstr_7000D00B("Decimal");
                global::System.FormatException v34 = l5;
                global::System.Xml.XmlException v35 = __cil_newobj_06000A0E(v32, v33, v34, null);
                throw v35;
            }
            catch (System.OverflowException __cil_exception_2) {
                IL_0159: ;
                s14_0 = __cil_exception_2;
                l6 = s14_0;
                string v36 = System.SR.get_Xml_ReadContentAsFormatException();
                string v37 = __cil_ldstr_7000D00B("Decimal");
                global::System.OverflowException v38 = l6;
                global::System.Xml.XmlException v39 = __cil_newobj_06000A0E(v36, v37, v38, null);
                throw v39;
            }
            IL_016E: ;
            global::System.Xml.XmlSqlBinaryReader v40 = this;
            int v41 = l0;
            int v42 = __cil_direct_060007B5(v40, v41);
            l0 = v42;
            __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v43 = l1;
            l3 = v43;
            goto IL_018B;
            IL_017A: ;
            goto IL_0184;
        }
        finally {
            IL_017C: ;
            global::System.Xml.XmlSqlBinaryReader v44 = this;
            int v45 = l0;
            v44._pos = v45;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_0184: ;
        global::System.Xml.XmlSqlBinaryReader v46 = this;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v47 = __cil_direct_06000ECE(v46);
        return v47;
        IL_018B: ;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v48 = l3;
        return v48;
    }

    public override int ReadContentAsInt()
    {
        // IL fallback: unsupported opcode conv.ovf.i4 at IL_00F9
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 87, 01, 00, 04, 0A, 02, 72, 1B, D0, 00, 70, 28, B4, 07, 00, 06, 39, 64, 01, 00, 00, 02]
        // .code-bytes IL_0018: [7B, 98, 01, 00, 04, 0C, 08, 17, 59, 45, 1B, 00, 00, 00, 61, 00, 00, 00, 61, 00, 00, 00, 6B, 00]
        // .code-bytes IL_0030: [00, 00, 6B, 00, 00, 00, 61, 00, 00, 00, 61, 00, 00, 00, 61, 00, 00, 00, 61, 00, 00, 00, 6B, 00]
        // .code-bytes IL_0048: [00, 00, 61, 00, 00, 00, 61, 00, 00, 00, 6B, 00, 00, 00, 8B, 00, 00, 00, 8B, 00, 00, 00, 6B, 00]
        // .code-bytes IL_0060: [00, 00, 8B, 00, 00, 00, 8B, 00, 00, 00, 6B, 00, 00, 00, 6B, 00, 00, 00, 61, 00, 00, 00, 9A, 00]
        // .code-bytes IL_0078: [00, 00, 8B, 00, 00, 00, 6B, 00, 00, 00, 8B, 00, 00, 00, 9A, 00, 00, 00, 9A, 00, 00, 00, 6B, 00]
        // .code-bytes IL_0090: [00, 00, 08, 1F, 7A, 59, 45, 13, 00, 00, 00, 16, 00, 00, 00, 16, 00, 00, 00, 16, 00, 00, 00, 16]
        // .code-bytes IL_00A8: [00, 00, 00, 16, 00, 00, 00, 16, 00, 00, 00, 45, 00, 00, 00, 16, 00, 00, 00, 16, 00, 00, 00, 16]
        // .code-bytes IL_00C0: [00, 00, 00, 16, 00, 00, 00, 16, 00, 00, 00, 16, 00, 00, 00, 0C, 00, 00, 00, 0C, 00, 00, 00, 0C]
        // .code-bytes IL_00D8: [00, 00, 00, 0C, 00, 00, 00, 0C, 00, 00, 00, 16, 00, 00, 00, 08, 20, F7, 00, 00, 00, 59, 17, 36]
        // .code-bytes IL_00F0: [2E, 2B, 39, 02, 28, 07, 08, 00, 06, B7, 0B, 2B, 31, 28, 11, 06, 00, 06, 02, 7B, 98, 01, 00, 04]
        // .code-bytes IL_0108: [8C, 73, 00, 00, 02, 72, 3D, D0, 00, 70, 28, 63, 03, 00, 06, 73, A5, 00, 00, 0A, 7A, DE, 66, 7E]
        // .code-bytes IL_0120: [02, 00, 00, 0A, 28, 79, 09, 00, 06, 0D, DE, 60, DE, 57, DE, 3F, 13, 04, 28, BE, 03, 00, 06, 72]
        // .code-bytes IL_0138: [3D, D0, 00, 70, 11, 04, 14, 73, 0E, 0A, 00, 06, 7A, 13, 05, 28, BE, 03, 00, 06, 72, 3D, D0, 00]
        // .code-bytes IL_0150: [70, 11, 05, 14, 73, 0E, 0A, 00, 06, 7A, 13, 06, 28, BE, 03, 00, 06, 72, 3D, D0, 00, 70, 11, 06]
        // .code-bytes IL_0168: [14, 73, 0E, 0A, 00, 06, 7A, 02, 06, 28, B5, 07, 00, 06, 0A, 07, 0D, DE, 11, DE, 08, 02, 06, 7D]
        // .code-bytes IL_0180: [87, 01, 00, 04, DC, 02, 28, CF, 0E, 00, 06, 2A, 09, 2A]
        // .local [0] int32
        // .local [1] int32
        // .local [2] valuetype System.Xml.BinXmlToken
        // .local [3] int32
        // .local [4] class [System.Runtime]System.InvalidCastException
        // .local [5] class [System.Runtime]System.FormatException
        // .local [6] class [System.Runtime]System.OverflowException
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x04000187 System.Xml.XmlSqlBinaryReader::_pos
        // IL_0006: stloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: ldstr 0x7000D01B [82, 101, 97, 100, 67, 111, 110, 116, 101, 110, 116, 65, 115, 73, 110, 116] utf16-bytes=[52, 00, 65, 00, 61, 00, 64, 00, 43, 00, 6F, 00, 6E, 00, 74, 00, 65, 00, 6E, 00, 74, 00, 41, 00, 73, 00, 49, 00, 6E, 00, 74, 00] terminal-flag=Some(0)
        // IL_000D: call 0x060007B4 System.Xml.XmlSqlBinaryReader::SetupContentAsXXX
        // IL_0012: brfalse IL_017B
        // IL_0017: ldarg.0 0
        // IL_0018: ldfld 0x04000198 System.Xml.XmlSqlBinaryReader::_token
        // IL_001D: stloc.2 2
        // IL_001E: ldloc.2 2
        // IL_001F: ldc.i4.1 1
        // IL_0020: sub 
        // IL_0021: switch IL_00F3, IL_00F3, IL_00FD, IL_00FD, IL_00F3, IL_00F3, IL_00F3, IL_00F3, IL_00FD, IL_00F3, IL_00F3, IL_00FD, IL_011D, IL_011D, IL_00FD, IL_011D, IL_011D, IL_00FD, IL_00FD, IL_00F3, IL_012C, IL_011D, IL_00FD, IL_011D, IL_012C, IL_012C, IL_00FD
        // IL_0092: ldloc.2 2
        // IL_0093: ldc.i4.s 122
        // IL_0095: sub 
        // IL_0096: switch IL_00FD, IL_00FD, IL_00FD, IL_00FD, IL_00FD, IL_00FD, IL_012C, IL_00FD, IL_00FD, IL_00FD, IL_00FD, IL_00FD, IL_00FD, IL_00F3, IL_00F3, IL_00F3, IL_00F3, IL_00F3, IL_00FD
        // IL_00E7: ldloc.2 2
        // IL_00E8: ldc.i4 247
        // IL_00ED: sub 
        // IL_00EE: ldc.i4.1 1
        // IL_00EF: ble.un.s IL_011F
        // IL_00F1: br.s IL_012C
        // IL_00F3: ldarg.0 0
        // IL_00F4: call 0x06000807 System.Xml.XmlSqlBinaryReader::ValueAsLong
        // IL_00F9: conv.ovf.i4 
        // IL_00FA: stloc.1 1
        // IL_00FB: br.s IL_012E
        // IL_00FD: call 0x06000611 System.SR::get_XmlBinary_CastNotSupported
        // IL_0102: ldarg.0 0
        // IL_0103: ldfld 0x04000198 System.Xml.XmlSqlBinaryReader::_token
        // IL_0108: box 0x02000073 System.Xml.BinXmlToken
        // IL_010D: ldstr 0x7000D03D [73, 110, 116, 51, 50] utf16-bytes=[49, 00, 6E, 00, 74, 00, 33, 00, 32, 00] terminal-flag=Some(0)
        // IL_0112: call 0x06000363 System.SR::Format
        // IL_0117: newobj 0x0A0000A5 [System.Runtime]System.InvalidCastException::.ctor
        // IL_011C: throw 
        // IL_011D: leave.s IL_0185
        // IL_011F: ldsfld 0x0A000002 [System.Runtime]System.String::Empty
        // IL_0124: call 0x06000979 System.Xml.XmlConvert::ToInt32
        // IL_0129: stloc.3 3
        // IL_012A: leave.s IL_018C
        // IL_012C: leave.s IL_0185
        // IL_012E: leave.s IL_016F
        // IL_0130: stloc.s 4
        // IL_0132: call 0x060003BE System.SR::get_Xml_ReadContentAsFormatException
        // IL_0137: ldstr 0x7000D03D [73, 110, 116, 51, 50] utf16-bytes=[49, 00, 6E, 00, 74, 00, 33, 00, 32, 00] terminal-flag=Some(0)
        // IL_013C: ldloc.s 4
        // IL_013E: ldnull 
        // IL_013F: newobj 0x06000A0E System.Xml.XmlException::.ctor
        // IL_0144: throw 
        // IL_0145: stloc.s 5
        // IL_0147: call 0x060003BE System.SR::get_Xml_ReadContentAsFormatException
        // IL_014C: ldstr 0x7000D03D [73, 110, 116, 51, 50] utf16-bytes=[49, 00, 6E, 00, 74, 00, 33, 00, 32, 00] terminal-flag=Some(0)
        // IL_0151: ldloc.s 5
        // IL_0153: ldnull 
        // IL_0154: newobj 0x06000A0E System.Xml.XmlException::.ctor
        // IL_0159: throw 
        // IL_015A: stloc.s 6
        // IL_015C: call 0x060003BE System.SR::get_Xml_ReadContentAsFormatException
        // IL_0161: ldstr 0x7000D03D [73, 110, 116, 51, 50] utf16-bytes=[49, 00, 6E, 00, 74, 00, 33, 00, 32, 00] terminal-flag=Some(0)
        // IL_0166: ldloc.s 6
        // IL_0168: ldnull 
        // IL_0169: newobj 0x06000A0E System.Xml.XmlException::.ctor
        // IL_016E: throw 
        // IL_016F: ldarg.0 0
        // IL_0170: ldloc.0 0
        // IL_0171: call 0x060007B5 System.Xml.XmlSqlBinaryReader::FinishContentAsXXX
        // IL_0176: stloc.0 0
        // IL_0177: ldloc.1 1
        // IL_0178: stloc.3 3
        // IL_0179: leave.s IL_018C
        // IL_017B: leave.s IL_0185
        // IL_017D: ldarg.0 0
        // IL_017E: ldloc.0 0
        // IL_017F: stfld 0x04000187 System.Xml.XmlSqlBinaryReader::_pos
        // IL_0184: endfinally 
        // IL_0185: ldarg.0 0
        // IL_0186: call 0x06000ECF System.Xml.XmlReader::ReadContentAsInt
        // IL_018B: ret 
        // IL_018C: ldloc.3 3
        // IL_018D: ret 
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[79])), try_offset: 23, try_length: 281, handler_offset: 304, handler_length: 21, raw_flags: 0 }
        // .try IL_0017..IL_0130 catch 0x0100004F [System.Runtime]System.InvalidCastException IL_0130..IL_0145
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[80])), try_offset: 23, try_length: 281, handler_offset: 325, handler_length: 21, raw_flags: 0 }
        // .try IL_0017..IL_0130 catch 0x01000050 [System.Runtime]System.FormatException IL_0145..IL_015A
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[78])), try_offset: 23, try_length: 281, handler_offset: 346, handler_length: 21, raw_flags: 0 }
        // .try IL_0017..IL_0130 catch 0x0100004E [System.Runtime]System.OverflowException IL_015A..IL_016F
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 7, try_length: 374, handler_offset: 381, handler_length: 8, raw_flags: 2 }
        // .try IL_0007..IL_017D finally IL_017D..IL_0185
    }

    public override long ReadContentAsLong()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        long l1 = default;
        __cil_enum_02000073 l2 = default;
        long l3 = default;
        System.InvalidCastException l4 = default;
        System.FormatException l5 = default;
        System.OverflowException l6 = default;
        System.InvalidCastException s12_0 = default;
        System.FormatException s13_0 = default;
        System.OverflowException s14_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        try {
            IL_0007: ;
            global::System.Xml.XmlSqlBinaryReader v2 = this;
            string v3 = __cil_ldstr_7000D049("ReadContentAsLong");
            int v4 = __cil_bool_load(__cil_direct_060007B4(v2, v3));
            if (v4 == 0) {
                goto IL_017A;
            } else {
            }
            try {
                IL_0017: ;
                global::System.Xml.XmlSqlBinaryReader v5 = this;
                int v6 = unchecked((int)(v5._token));
                l2 = unchecked((__cil_enum_02000073)(v6));
                int v7 = unchecked((int)(l2));
                int v8 = 1;
                int v9 = unchecked(v7 - v8);
                switch (v9) {
                    case 0: {
                        goto IL_00F3;
                    }
                    case 1: {
                        goto IL_00F3;
                    }
                    case 2: {
                        goto IL_00FC;
                    }
                    case 3: {
                        goto IL_00FC;
                    }
                    case 4: {
                        goto IL_00F3;
                    }
                    case 5: {
                        goto IL_00F3;
                    }
                    case 6: {
                        goto IL_00F3;
                    }
                    case 7: {
                        goto IL_00F3;
                    }
                    case 8: {
                        goto IL_00FC;
                    }
                    case 9: {
                        goto IL_00F3;
                    }
                    case 10: {
                        goto IL_00F3;
                    }
                    case 11: {
                        goto IL_00FC;
                    }
                    case 12: {
                        goto IL_011C;
                    }
                    case 13: {
                        goto IL_011C;
                    }
                    case 14: {
                        goto IL_00FC;
                    }
                    case 15: {
                        goto IL_011C;
                    }
                    case 16: {
                        goto IL_011C;
                    }
                    case 17: {
                        goto IL_00FC;
                    }
                    case 18: {
                        goto IL_00FC;
                    }
                    case 19: {
                        goto IL_00F3;
                    }
                    case 20: {
                        goto IL_012B;
                    }
                    case 21: {
                        goto IL_011C;
                    }
                    case 22: {
                        goto IL_00FC;
                    }
                    case 23: {
                        goto IL_011C;
                    }
                    case 24: {
                        goto IL_012B;
                    }
                    case 25: {
                        goto IL_012B;
                    }
                    case 26: {
                        goto IL_00FC;
                    }
                    default: {
                        goto IL_0092;
                    } }
                IL_0092: ;
                int v10 = unchecked((int)(l2));
                int v11 = 122;
                int v12 = unchecked(v10 - v11);
                switch (v12) {
                    case 0: {
                        goto IL_00FC;
                    }
                    case 1: {
                        goto IL_00FC;
                    }
                    case 2: {
                        goto IL_00FC;
                    }
                    case 3: {
                        goto IL_00FC;
                    }
                    case 4: {
                        goto IL_00FC;
                    }
                    case 5: {
                        goto IL_00FC;
                    }
                    case 6: {
                        goto IL_012B;
                    }
                    case 7: {
                        goto IL_00FC;
                    }
                    case 8: {
                        goto IL_00FC;
                    }
                    case 9: {
                        goto IL_00FC;
                    }
                    case 10: {
                        goto IL_00FC;
                    }
                    case 11: {
                        goto IL_00FC;
                    }
                    case 12: {
                        goto IL_00FC;
                    }
                    case 13: {
                        goto IL_00F3;
                    }
                    case 14: {
                        goto IL_00F3;
                    }
                    case 15: {
                        goto IL_00F3;
                    }
                    case 16: {
                        goto IL_00F3;
                    }
                    case 17: {
                        goto IL_00F3;
                    }
                    case 18: {
                        goto IL_00FC;
                    }
                    default: {
                        goto IL_00E7;
                    } }
                IL_00E7: ;
                int v13 = unchecked((int)(l2));
                int v14 = 247;
                int v15 = unchecked(v13 - v14);
                int v16 = 1;
                if (unchecked((uint)v15) <= unchecked((uint)v16)) {
                    goto IL_011E;
                } else {
                    goto IL_00F1;
                }
                IL_00F1: ;
                goto IL_012B;
                IL_00F3: ;
                global::System.Xml.XmlSqlBinaryReader v17 = this;
                long v18 = __cil_direct_06000807(v17);
                l1 = v18;
                goto IL_012D;
                IL_00FC: ;
                string v19 = System.SR.get_XmlBinary_CastNotSupported();
                global::System.Xml.XmlSqlBinaryReader v20 = this;
                int v21 = unchecked((int)(v20._token));
                object v22 = ((object)((System.Xml.BinXmlToken)(v21)));
                string v23 = __cil_ldstr_7000D06D("Int64");
                string v24 = System.SR.Format(v19, v22, ((object)(v23)));
                global::System.InvalidCastException v25 = __cil_newobj_0A0000A5(v24);
                throw v25;
                IL_011C: ;
                goto IL_0184;
                IL_011E: ;
                string v26 = __cil_ldsfld_0A000002();
                long v27 = System.Xml.XmlConvert.ToInt64(v26);
                l3 = v27;
                goto IL_018B;
                IL_012B: ;
                goto IL_0184;
                IL_012D: ;
                goto IL_016E;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_012F: ;
                s12_0 = __cil_exception_0;
                l4 = s12_0;
                string v28 = System.SR.get_Xml_ReadContentAsFormatException();
                string v29 = __cil_ldstr_7000D06D("Int64");
                global::System.InvalidCastException v30 = l4;
                global::System.Xml.XmlException v31 = __cil_newobj_06000A0E(v28, v29, v30, null);
                throw v31;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0144: ;
                s13_0 = __cil_exception_1;
                l5 = s13_0;
                string v32 = System.SR.get_Xml_ReadContentAsFormatException();
                string v33 = __cil_ldstr_7000D06D("Int64");
                global::System.FormatException v34 = l5;
                global::System.Xml.XmlException v35 = __cil_newobj_06000A0E(v32, v33, v34, null);
                throw v35;
            }
            catch (System.OverflowException __cil_exception_2) {
                IL_0159: ;
                s14_0 = __cil_exception_2;
                l6 = s14_0;
                string v36 = System.SR.get_Xml_ReadContentAsFormatException();
                string v37 = __cil_ldstr_7000D06D("Int64");
                global::System.OverflowException v38 = l6;
                global::System.Xml.XmlException v39 = __cil_newobj_06000A0E(v36, v37, v38, null);
                throw v39;
            }
            IL_016E: ;
            global::System.Xml.XmlSqlBinaryReader v40 = this;
            int v41 = l0;
            int v42 = __cil_direct_060007B5(v40, v41);
            l0 = v42;
            long v43 = l1;
            l3 = v43;
            goto IL_018B;
            IL_017A: ;
            goto IL_0184;
        }
        finally {
            IL_017C: ;
            global::System.Xml.XmlSqlBinaryReader v44 = this;
            int v45 = l0;
            v44._pos = v45;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_0184: ;
        global::System.Xml.XmlSqlBinaryReader v46 = this;
        long v47 = __cil_direct_06000ED0(v46);
        return v47;
        IL_018B: ;
        long v48 = l3;
        return v48;
    }

    public override object ReadContentAsObject()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        object l1 = default;
        System.InvalidCastException l2 = default;
        System.FormatException l3 = default;
        System.OverflowException l4 = default;
        object l5 = default;
        System.InvalidCastException s7_0 = default;
        System.FormatException s8_0 = default;
        System.OverflowException s9_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        try {
            IL_0007: ;
            global::System.Xml.XmlSqlBinaryReader v2 = this;
            string v3 = __cil_ldstr_7000D079("ReadContentAsObject");
            int v4 = __cil_bool_load(__cil_direct_060007B4(v2, v3));
            if (v4 == 0) {
                goto IL_0087;
            } else {
            }
            try {
                IL_0014: ;
                global::System.Xml.XmlSqlBinaryReader v5 = this;
                int v6 = unchecked((int)(__cil_callvirt_06000EB8(v5)));
                int v7 = 1;
                if (v6 == v7) {
                    goto IL_0027;
                } else {
                    goto IL_001D;
                }
                IL_001D: ;
                global::System.Xml.XmlSqlBinaryReader v8 = this;
                int v9 = unchecked((int)(__cil_callvirt_06000EB8(v8)));
                int v10 = 15;
                if (unchecked((uint)v9) != unchecked((uint)v10)) {
                    goto IL_002F;
                } else {
                    goto IL_0027;
                }
                IL_0027: ;
                string v11 = __cil_ldsfld_0A000002();
                l1 = v11;
                goto IL_003D;
                IL_002F: ;
                global::System.Xml.XmlSqlBinaryReader v12 = this;
                global::System.Xml.XmlSqlBinaryReader v13 = this;
                int v14 = unchecked((int)(v13._token));
                int v15 = 0;
                object v16 = __cil_direct_0600080F(v12, unchecked((__cil_enum_02000073)(v14)), __cil_bool_store(v15));
                l1 = v16;
                goto IL_003D;
                IL_003D: ;
                goto IL_007A;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_003F: ;
                s7_0 = __cil_exception_0;
                l2 = s7_0;
                string v17 = System.SR.get_Xml_ReadContentAsFormatException();
                string v18 = __cil_ldstr_7000D0A1("Object");
                global::System.InvalidCastException v19 = l2;
                global::System.Xml.XmlException v20 = __cil_newobj_06000A0E(v17, v18, v19, null);
                throw v20;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0052: ;
                s8_0 = __cil_exception_1;
                l3 = s8_0;
                string v21 = System.SR.get_Xml_ReadContentAsFormatException();
                string v22 = __cil_ldstr_7000D0A1("Object");
                global::System.FormatException v23 = l3;
                global::System.Xml.XmlException v24 = __cil_newobj_06000A0E(v21, v22, v23, null);
                throw v24;
            }
            catch (System.OverflowException __cil_exception_2) {
                IL_0065: ;
                s9_0 = __cil_exception_2;
                l4 = s9_0;
                string v25 = System.SR.get_Xml_ReadContentAsFormatException();
                string v26 = __cil_ldstr_7000D0A1("Object");
                global::System.OverflowException v27 = l4;
                global::System.Xml.XmlException v28 = __cil_newobj_06000A0E(v25, v26, v27, null);
                throw v28;
            }
            IL_007A: ;
            global::System.Xml.XmlSqlBinaryReader v29 = this;
            int v30 = l0;
            int v31 = __cil_direct_060007B5(v29, v30);
            l0 = v31;
            object v32 = l1;
            l5 = v32;
            goto IL_0098;
            IL_0087: ;
            goto IL_0091;
        }
        finally {
            IL_0089: ;
            global::System.Xml.XmlSqlBinaryReader v33 = this;
            int v34 = l0;
            v33._pos = v34;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_0091: ;
        global::System.Xml.XmlSqlBinaryReader v35 = this;
        object v36 = __cil_direct_06000EC8(v35);
        return v36;
        IL_0098: ;
        object v37 = l5;
        return v37;
    }

    public override object ReadContentAs(System.Type returnType, System.Xml.IXmlNamespaceResolver namespaceResolver)
    {
        // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        object l1 = default;
        System.InvalidCastException l2 = default;
        System.FormatException l3 = default;
        System.OverflowException l4 = default;
        object l5 = default;
        System.InvalidCastException s10_0 = default;
        System.FormatException s11_0 = default;
        System.OverflowException s12_0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._pos;
        l0 = v1;
        try {
            IL_0007: ;
            global::System.Xml.XmlSqlBinaryReader v2 = this;
            string v3 = __cil_ldstr_7000D0AF("ReadContentAs");
            int v4 = __cil_bool_load(__cil_direct_060007B4(v2, v3));
            if (v4 == 0) {
                goto IL_00BE;
            } else {
            }
            try {
                IL_0017: ;
                global::System.Xml.XmlSqlBinaryReader v5 = this;
                int v6 = unchecked((int)(__cil_callvirt_06000EB8(v5)));
                int v7 = 1;
                if (v6 == v7) {
                    goto IL_002A;
                } else {
                    goto IL_0020;
                }
                IL_0020: ;
                global::System.Xml.XmlSqlBinaryReader v8 = this;
                int v9 = unchecked((int)(__cil_callvirt_06000EB8(v8)));
                int v10 = 15;
                if (unchecked((uint)v9) != unchecked((uint)v10)) {
                    goto IL_0032;
                } else {
                    goto IL_002A;
                }
                IL_002A: ;
                string v11 = __cil_ldsfld_0A000002();
                l1 = v11;
                goto IL_0071;
                IL_0032: ;
                __cil_type_01000004 v12 = returnType;
                global::System.Xml.XmlSqlBinaryReader v13 = this;
                __cil_type_01000004 v14 = __cil_callvirt_06000EC7(v13);
                int v15 = __cil_bool_load(System.Type.op_Equality(v12, v14));
                if (v15 != 0) {
                    goto IL_0052;
                } else {
                    goto IL_0040;
                }
                IL_0040: ;
                __cil_type_01000004 v16 = returnType;
                __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v17 = __cil_ldtoken_type_01000001;
                __cil_type_01000004 v18 = System.Type.GetTypeFromHandle(v17);
                int v19 = __cil_bool_load(System.Type.op_Equality(v16, v18));
                if (v19 == 0) {
                    goto IL_0062;
                } else {
                    goto IL_0052;
                }
                IL_0052: ;
                global::System.Xml.XmlSqlBinaryReader v20 = this;
                global::System.Xml.XmlSqlBinaryReader v21 = this;
                int v22 = unchecked((int)(v21._token));
                int v23 = 0;
                object v24 = __cil_direct_0600080F(v20, unchecked((__cil_enum_02000073)(v22)), __cil_bool_store(v23));
                l1 = v24;
                goto IL_0071;
                IL_0062: ;
                global::System.Xml.XmlSqlBinaryReader v25 = this;
                global::System.Xml.XmlSqlBinaryReader v26 = this;
                int v27 = unchecked((int)(v26._token));
                __cil_type_01000004 v28 = returnType;
                global::System.Xml.IXmlNamespaceResolver v29 = namespaceResolver;
                object v30 = __cil_direct_06000811(v25, unchecked((__cil_enum_02000073)(v27)), v28, v29);
                l1 = v30;
                goto IL_0071;
                IL_0071: ;
                goto IL_00B1;
            }
            catch (System.InvalidCastException __cil_exception_0) {
                IL_0073: ;
                s10_0 = __cil_exception_0;
                l2 = s10_0;
                string v31 = System.SR.get_Xml_ReadContentAsFormatException();
                __cil_type_01000004 v32 = returnType;
                string v33 = v32.ToString();
                global::System.InvalidCastException v34 = l2;
                global::System.Xml.XmlException v35 = __cil_newobj_06000A0E(v31, v33, v34, null);
                throw v35;
            }
            catch (System.FormatException __cil_exception_1) {
                IL_0087: ;
                s11_0 = __cil_exception_1;
                l3 = s11_0;
                string v36 = System.SR.get_Xml_ReadContentAsFormatException();
                __cil_type_01000004 v37 = returnType;
                string v38 = v37.ToString();
                global::System.FormatException v39 = l3;
                global::System.Xml.XmlException v40 = __cil_newobj_06000A0E(v36, v38, v39, null);
                throw v40;
            }
            catch (System.OverflowException __cil_exception_2) {
                IL_009B: ;
                s12_0 = __cil_exception_2;
                l4 = s12_0;
                string v41 = System.SR.get_Xml_ReadContentAsFormatException();
                __cil_type_01000004 v42 = returnType;
                string v43 = v42.ToString();
                global::System.OverflowException v44 = l4;
                global::System.Xml.XmlException v45 = __cil_newobj_06000A0E(v41, v43, v44, null);
                throw v45;
            }
            IL_00B1: ;
            global::System.Xml.XmlSqlBinaryReader v46 = this;
            int v47 = l0;
            int v48 = __cil_direct_060007B5(v46, v47);
            l0 = v48;
            object v49 = l1;
            l5 = v49;
            goto IL_00D1;
            IL_00BE: ;
            goto IL_00C8;
        }
        finally {
            IL_00C0: ;
            global::System.Xml.XmlSqlBinaryReader v50 = this;
            int v51 = l0;
            v50._pos = v51;
            goto __cil_finally_end_3;
            __cil_finally_end_3: ;
        }
        IL_00C8: ;
        global::System.Xml.XmlSqlBinaryReader v52 = this;
        __cil_type_01000004 v53 = returnType;
        global::System.Xml.IXmlNamespaceResolver v54 = namespaceResolver;
        object v55 = __cil_direct_06000ED2(v52, v53, v54);
        return v55;
        IL_00D1: ;
        object v56 = l5;
        return v56;
    }

    private virtual System.Collections.Generic.IDictionary<string, string> __name_53797374656D2E586D6C2E49586D6C4E616D6573706163655265736F6C7665722E4765744E616D65737061636573496E53636F7065(System.Xml.XmlNamespaceScope scope)
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af bytes=151280D1020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_2e1a08d1919f285a7d76c39fa6eb309d4f5573c7 bytes=15128151020E0E: class [System.Runtime]System.Collections.Generic.IDictionary`2<string, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d6e5e9ef9c597b9b43ef419a8a03a2a1efd10719 bytes=151280D1020E0E: class [System.Collections]System.Collections.Generic.Dictionary`2<string, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 bytes=1511814D020E1281C0: valuetype [System.Collections]System.Collections.Generic.Dictionary`2/ValueCollection/Enumerator<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b96c34a4c67f46dc257ee1bf65a223c208c498aa bytes=15128149020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2/ValueCollection<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B2 alias=__cil_enum_020000B2 underlying=int: global::@System.@Xml.@XmlNamespaceScope; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        System.Xml.IXmlNamespaceResolver l0 = default;
        __cil_ref_d6e5e9ef9c597b9b43ef419a8a03a2a1efd10719 l1 = default;
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l2 = default;
        __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 l3 = default;
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l4 = default;
        IL_0000: ;
        int v0 = 1;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = unchecked((int)(v1._state));
        if (unchecked((uint)v0) != unchecked((uint)v2)) {
            goto IL_001D;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        global::System.Xml.XmlReader v4 = v3._textXmlReader;
        global::System.Xml.IXmlNamespaceResolver v5 = ((System.Xml.IXmlNamespaceResolver)(object)v4);
        l0 = v5;
        global::System.Xml.IXmlNamespaceResolver v6 = l0;
        int v7 = unchecked((int)(scope));
        __cil_ref_2e1a08d1919f285a7d76c39fa6eb309d4f5573c7 v8 = __cil_callvirt_060008F5(v6, unchecked((__cil_enum_020000B2)(v7)));
        return v8;
        IL_001D: ;
        __cil_ref_d6e5e9ef9c597b9b43ef419a8a03a2a1efd10719 v9 = __cil_newobj_0A0000A7();
        l1 = v9;
        int v10 = 2;
        int v11 = unchecked((int)(scope));
        if (unchecked((uint)v10) != unchecked((uint)v11)) {
            goto IL_006D;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        int v13 = v12._elemDepth;
        int v14 = 0;
        if (v13 <= v14) {
            goto IL_00F4;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v16 = v15._elementStack;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        int v18 = v17._elemDepth;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v19 = ref __cil_ldelema_0200006E(v16, v18);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v20 = v19.nsdecls;
        l2 = v20;
        goto IL_0065;
        IL_004C: ;
        __cil_ref_d6e5e9ef9c597b9b43ef419a8a03a2a1efd10719 v21 = l1;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v22 = l2;
        string v23 = v22.prefix;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v24 = l2;
        string v25 = v24.uri;
        __cil_callvirt_0A0000A8(v21, v23, v25);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v26 = l2;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v27 = v26.scopeLink;
        l2 = v27;
        goto IL_0065;
        IL_0065: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v28 = l2;
        if (v28 is not null) {
            goto IL_004C;
        } else {
            goto IL_0068;
        }
        IL_0068: ;
        goto IL_00F4;
        IL_006D: ;
        global::System.Xml.XmlSqlBinaryReader v29 = this;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v30 = v29._namespaces;
        __cil_ref_b96c34a4c67f46dc257ee1bf65a223c208c498aa v31 = __cil_callvirt_0A0000A9(v30);
        __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v32 = __cil_callvirt_0A0000AA(v31);
        l3 = v32;
        try {
            IL_007E: ;
            goto IL_00DB;
            IL_0080: ;
            ref __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v33 = ref l3;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v34 = __cil_value_call_0A0000AB(ref v33);
            l4 = v34;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v35 = l4;
            int v36 = v35.scope;
            int v37 = -1;
            if (unchecked((uint)v36) != unchecked((uint)v37)) {
                goto IL_00A9;
            } else {
                goto IL_0093;
            }
            IL_0093: ;
            int v38 = unchecked((int)(scope));
            if (v38 != 0) {
                goto IL_00DB;
            } else {
                goto IL_0096;
            }
            IL_0096: ;
            string v39 = __cil_ldstr_700003A9("xml");
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v40 = l4;
            string v41 = v40.prefix;
            int v42 = __cil_bool_load(System.String.op_Equality(v39, v41));
            if (v42 == 0) {
                goto IL_00DB;
            } else {
                goto IL_00A9;
            }
            IL_00A9: ;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v43 = l4;
            string v44 = v43.prefix;
            int v45 = ((System.String)v44).Length;
            int v46 = 0;
            if (v45 > v46) {
                goto IL_00C7;
            } else {
                goto IL_00B8;
            }
            IL_00B8: ;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v47 = l4;
            string v48 = v47.uri;
            int v49 = ((System.String)v48).Length;
            int v50 = 0;
            if (v49 <= v50) {
                goto IL_00DB;
            } else {
                goto IL_00C7;
            }
            IL_00C7: ;
            __cil_ref_d6e5e9ef9c597b9b43ef419a8a03a2a1efd10719 v51 = l1;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v52 = l4;
            string v53 = v52.prefix;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v54 = l4;
            string v55 = v54.uri;
            __cil_callvirt_0A0000A8(v51, v53, v55);
            goto IL_00DB;
            IL_00DB: ;
            ref __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v56 = ref l3;
            int v57 = __cil_bool_load(__cil_value_call_0A0000AC(ref v56));
            if (v57 != 0) {
                goto IL_0080;
            } else {
                goto IL_00E4;
            }
            IL_00E4: ;
            goto IL_00F4;
        }
        finally {
            IL_00E6: ;
            ref __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v58 = ref l3;
            __cil_constrained_1B000021_0A000031(ref v58);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00F4: ;
        __cil_ref_d6e5e9ef9c597b9b43ef419a8a03a2a1efd10719 v59 = l1;
        return v59;
    }

    private virtual string __name_53797374656D2E586D6C2E49586D6C4E616D6573706163655265736F6C7665722E4C6F6F6B7570507265666978(string namespaceName)
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        System.Xml.IXmlNamespaceResolver l0 = default;
        int l1 = default;
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l2 = default;
        IL_0000: ;
        int v0 = 1;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = unchecked((int)(v1._state));
        if (unchecked((uint)v0) != unchecked((uint)v2)) {
            goto IL_001D;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        global::System.Xml.XmlReader v4 = v3._textXmlReader;
        global::System.Xml.IXmlNamespaceResolver v5 = ((System.Xml.IXmlNamespaceResolver)(object)v4);
        l0 = v5;
        global::System.Xml.IXmlNamespaceResolver v6 = l0;
        string v7 = namespaceName;
        string v8 = __cil_callvirt_060008F7(v6, v7);
        return v8;
        IL_001D: ;
        string v9 = namespaceName;
        if (v9 is not null) {
            goto IL_0022;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        return null;
        IL_0022: ;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        global::System.Xml.XmlNameTable v11 = v10._xnt;
        string v12 = namespaceName;
        string v13 = __cil_callvirt_06000A33(v11, v12);
        namespaceName = v13;
        string v14 = namespaceName;
        if (v14 is not null) {
            goto IL_0035;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        return null;
        IL_0035: ;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        int v16 = v15._elemDepth;
        l1 = v16;
        goto IL_0070;
        IL_003E: ;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v18 = v17._elementStack;
        int v19 = l1;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v20 = ref __cil_ldelema_0200006E(v18, v19);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v21 = v20.nsdecls;
        l2 = v21;
        goto IL_0069;
        IL_0052: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v22 = l2;
        string v23 = v22.uri;
        string v24 = namespaceName;
        if (!System.Object.ReferenceEquals(v23, v24)) {
            goto IL_0062;
        } else {
            goto IL_005B;
        }
        IL_005B: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v25 = l2;
        string v26 = v25.prefix;
        return v26;
        IL_0062: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v27 = l2;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v28 = v27.scopeLink;
        l2 = v28;
        goto IL_0069;
        IL_0069: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v29 = l2;
        if (v29 is not null) {
            goto IL_0052;
        } else {
            goto IL_006C;
        }
        IL_006C: ;
        int v30 = l1;
        int v31 = 1;
        int v32 = unchecked(v30 - v31);
        l1 = v32;
        goto IL_0070;
        IL_0070: ;
        int v33 = l1;
        int v34 = 0;
        if (v33 >= v34) {
            goto IL_003E;
        } else {
            goto IL_0074;
        }
        IL_0074: ;
        return null;
    }

    private void VerifyVersion(int requiredVersion, System.Xml.BinXmlToken token)
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this._version));
        if (v1 >= requiredVersion) {
            goto IL_0011;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        int v4 = unchecked((int)(token));
        global::System.Exception v5 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v4)));
        throw v5;
        IL_0011: ;
        return;
    }

    private void AddInitNamespace(string prefix, string uri)
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af bytes=151280D1020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l0 = default;
        IL_0000: ;
        string v0 = prefix;
        string v1 = uri;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v3 = v2._elementStack;
        int v4 = 0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v5 = ref __cil_ldelema_0200006E(v3, v4);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v6 = v5.nsdecls;
        int v7 = -1;
        int v8 = 1;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v9 = __cil_newobj_06000833(v0, v1, v6, null, v7, v8);
        l0 = v9;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v11 = v10._elementStack;
        int v12 = 0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v13 = ref __cil_ldelema_0200006E(v11, v12);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v14 = l0;
        v13.nsdecls = v14;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v16 = v15._namespaces;
        string v17 = prefix;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v18 = l0;
        __cil_callvirt_0A0000AD(v16, v17, v18);
        return;
    }

    private void AddName()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string l0 = default;
        int l1 = default;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 l2 = default;
        int l3 = default;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 l4 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        string v1 = __cil_direct_060007D9(v0);
        l0 = v1;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v3 = ref v2._symbolTables;
        ref int v4 = ref v3.symCount;
        int v5 = unchecked((int)(v4));
        l3 = v5;
        int v6 = l3;
        int v7 = 1;
        int v8 = unchecked(v6 + v7);
        v4 = v8;
        int v9 = l3;
        l1 = v9;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v11 = ref v10._symbolTables;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v12 = v11.symtable;
        l2 = v12;
        int v13 = l1;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v14 = l2;
        nint v15 = unchecked((nint)(v14.LongLength));
        int v16 = unchecked((int)(v15));
        if (unchecked((uint)v13) != unchecked((uint)v16)) {
            goto IL_0051;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        int v17 = l1;
        int v18 = 2;
        int v19 = checked(v17 * v18);
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v20 = __cil_newarr_01000003(v19);
        l4 = v20;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v21 = l2;
        int v22 = 0;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v23 = l4;
        int v24 = 0;
        int v25 = l1;
        System.Array.Copy(((__cil_type_01000022)(v21)), v22, ((__cil_type_01000022)(v23)), v24, v25);
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v27 = ref v26._symbolTables;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v28 = l4;
        l2 = v28;
        v27.symtable = v28;
        goto IL_0051;
        IL_0051: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v29 = l2;
        int v30 = l1;
        global::System.Xml.XmlSqlBinaryReader v31 = this;
        global::System.Xml.XmlNameTable v32 = v31._xnt;
        string v33 = l0;
        string v34 = __cil_callvirt_06000A35(v32, v33);
        v29[v30] = v34;
        return;
    }

    private void AddQName()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c bytes=1D1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200017B alias=__cil_enum_0200017B underlying=int: global::@System.@StringComparison; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        int l1 = default;
        int l2 = default;
        int l3 = default;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c l4 = default;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 l5 = default;
        string l6 = default;
        string l7 = default;
        string l8 = default;
        int l9 = default;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c l10 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = __cil_direct_060007C8(v0);
        l0 = v1;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        int v3 = __cil_direct_060007C8(v2);
        l1 = v3;
        global::System.Xml.XmlSqlBinaryReader v4 = this;
        int v5 = __cil_direct_060007C8(v4);
        l2 = v5;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v7 = ref v6._symbolTables;
        ref int v8 = ref v7.qnameCount;
        int v9 = unchecked((int)(v8));
        l9 = v9;
        int v10 = l9;
        int v11 = 1;
        int v12 = unchecked(v10 + v11);
        v8 = v12;
        int v13 = l9;
        l3 = v13;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v15 = ref v14._symbolTables;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v16 = v15.qnametable;
        l4 = v16;
        int v17 = l3;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v18 = l4;
        nint v19 = unchecked((nint)(v18.LongLength));
        int v20 = unchecked((int)(v19));
        if (unchecked((uint)v17) != unchecked((uint)v20)) {
            goto IL_0066;
        } else {
            goto IL_0040;
        }
        IL_0040: ;
        int v21 = l3;
        int v22 = 2;
        int v23 = checked(v21 * v22);
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v24 = __cil_newarr_0200006D(v23);
        l10 = v24;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v25 = l4;
        int v26 = 0;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v27 = l10;
        int v28 = 0;
        int v29 = l3;
        System.Array.Copy(((__cil_type_01000022)(v25)), v26, ((__cil_type_01000022)(v27)), v28, v29);
        global::System.Xml.XmlSqlBinaryReader v30 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v31 = ref v30._symbolTables;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v32 = l10;
        l4 = v32;
        v31.qnametable = v32;
        goto IL_0066;
        IL_0066: ;
        global::System.Xml.XmlSqlBinaryReader v33 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v34 = ref v33._symbolTables;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v35 = v34.symtable;
        l5 = v35;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v36 = l5;
        int v37 = l1;
        string v38 = v36[v37];
        l6 = v38;
        int v39 = l2;
        if (v39 != 0) {
            goto IL_00E6;
        } else {
            goto IL_007C;
        }
        IL_007C: ;
        int v40 = l1;
        if (v40 != 0) {
            goto IL_0083;
        } else {
            goto IL_007F;
        }
        IL_007F: ;
        int v41 = l0;
        if (v41 != 0) {
            goto IL_0083;
        } else {
            goto IL_0082;
        }
        IL_0082: ;
        return;
        IL_0083: ;
        string v42 = l6;
        string v43 = __cil_ldstr_7000CEB5("xmlns");
        int v44 = 4;
        int v45 = __cil_bool_load(v42.StartsWith(v43, unchecked((System.StringComparison)(v44))));
        if (v45 == 0) {
            goto IL_0106;
        } else {
            goto IL_0092;
        }
        IL_0092: ;
        int v46 = 5;
        string v47 = l6;
        int v48 = ((System.String)v47).Length;
        if (v46 >= v48) {
            goto IL_00D1;
        } else {
            goto IL_009C;
        }
        IL_009C: ;
        int v49 = 6;
        string v50 = l6;
        int v51 = ((System.String)v50).Length;
        if (v49 == v51) {
            goto IL_0106;
        } else {
            goto IL_00A6;
        }
        IL_00A6: ;
        int v52 = 58;
        string v53 = l6;
        int v54 = 5;
        int v55 = unchecked((int)(__cil_callvirt_0A00000B(v53, v54)));
        if (unchecked((uint)v52) != unchecked((uint)v55)) {
            goto IL_0106;
        } else {
            goto IL_00B2;
        }
        IL_00B2: ;
        global::System.Xml.XmlSqlBinaryReader v56 = this;
        global::System.Xml.XmlNameTable v57 = v56._xnt;
        string v58 = l6;
        int v59 = 6;
        string v60 = v58.Substring(v59);
        string v61 = __cil_callvirt_06000A35(v57, v60);
        l7 = v61;
        global::System.Xml.XmlSqlBinaryReader v62 = this;
        string v63 = v62._xmlns;
        l6 = v63;
        goto IL_00DC;
        IL_00D1: ;
        string v64 = l6;
        l7 = v64;
        string v65 = __cil_ldsfld_0A000002();
        l6 = v65;
        goto IL_00DC;
        IL_00DC: ;
        global::System.Xml.XmlSqlBinaryReader v66 = this;
        string v67 = v66._nsxmlns;
        l8 = v67;
        goto IL_00F2;
        IL_00E6: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v68 = l5;
        int v69 = l2;
        string v70 = v68[v69];
        l7 = v70;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v71 = l5;
        int v72 = l0;
        string v73 = v71[v72];
        l8 = v73;
        goto IL_00F2;
        IL_00F2: ;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v74 = l4;
        int v75 = l3;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v76 = ref __cil_ldelema_0200006D(v74, v75);
        string v77 = l6;
        string v78 = l7;
        string v79 = l8;
        __cil_direct_06000820(ref v76, v77, v78, v79);
        return;
        IL_0106: ;
        string v80 = System.SR.get_Xml_BadNamespaceDecl();
        global::System.Xml.XmlException v81 = __cil_newobj_06000A0A(v80, null);
        throw v81;
    }

    private void NameFlush()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c bytes=1D1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v1 = ref v0._symbolTables;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v3 = ref v2._symbolTables;
        int v4 = 1;
        l0 = v4;
        v3.qnameCount = v4;
        int v5 = l0;
        v1.symCount = v5;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v7 = ref v6._symbolTables;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v8 = v7.symtable;
        int v9 = 1;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v11 = ref v10._symbolTables;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v12 = v11.symtable;
        nint v13 = unchecked((nint)(v12.LongLength));
        int v14 = unchecked((int)(v13));
        int v15 = 1;
        int v16 = unchecked(v14 - v15);
        System.Array.Clear(((__cil_type_01000022)(v8)), v9, v16);
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v18 = ref v17._symbolTables;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v19 = v18.qnametable;
        int v20 = 0;
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v22 = ref v21._symbolTables;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v23 = v22.qnametable;
        nint v24 = unchecked((nint)(v23.LongLength));
        int v25 = unchecked((int)(v24));
        System.Array.Clear(((__cil_type_01000022)(v19)), v20, v25);
        return;
    }

    private void SkipExtn()
    {
        int v1 = __cil_direct_060007CE(this);
        int v4 = this._pos;
        int v6 = checked(v4 + v1);
        this._pos = v6;
        __cil_direct_060007CB(this, -1);
        return;
    }

    private int ReadQNameRef()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = __cil_direct_060007CE(v0);
        l0 = v1;
        int v2 = l0;
        int v3 = 0;
        if (v2 < v3) {
            goto IL_0019;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        int v4 = l0;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v6 = ref v5._symbolTables;
        int v7 = v6.qnameCount;
        if (v4 < v7) {
            goto IL_0029;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        string v8 = System.SR.get_XmlBin_InvalidQNameID();
        string v9 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlException v10 = __cil_newobj_06000A0B(v8, v9);
        throw v10;
        IL_0029: ;
        int v11 = l0;
        return v11;
    }

    private int ReadNameRef()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = __cil_direct_060007CE(v0);
        l0 = v1;
        int v2 = l0;
        int v3 = 0;
        if (v2 < v3) {
            goto IL_0019;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        int v4 = l0;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v6 = ref v5._symbolTables;
        int v7 = v6.symCount;
        if (v4 < v7) {
            goto IL_0029;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        string v8 = System.SR.get_XmlBin_InvalidQNameID();
        string v9 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlException v10 = __cil_newobj_06000A0B(v8, v9);
        throw v10;
        IL_0029: ;
        int v11 = l0;
        return v11;
    }

    private bool FillAllowEOF()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 l0 = default;
        int l1 = default;
        int l2 = default;
        int l3 = default;
        int l4 = default;
        int l5 = default;
        int l6 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 l7 = default;
        int l8 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = __cil_bool_load(v0._eof);
        if (v1 == 0) {
            goto IL_000A;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v2 = 0;
        return __cil_bool_store(v2);
        IL_000A: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v4 = v3._data;
        l0 = v4;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        int v6 = v5._pos;
        l1 = v6;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        int v8 = v7._mark;
        l2 = v8;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        int v10 = v9._end;
        l3 = v10;
        int v11 = l2;
        int v12 = -1;
        if (unchecked((uint)v11) != unchecked((uint)v12)) {
            goto IL_002C;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        int v13 = l1;
        l2 = v13;
        goto IL_002C;
        IL_002C: ;
        int v14 = l2;
        int v15 = 0;
        if (v14 < v15) {
            goto IL_00D7;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        int v16 = l2;
        int v17 = l3;
        if (v16 >= v17) {
            goto IL_00D7;
        } else {
            goto IL_003A;
        }
        IL_003A: ;
        int v18 = l3;
        int v19 = l2;
        int v20 = unchecked(v18 - v19);
        l6 = v20;
        int v21 = l6;
        int v22 = 7;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v23 = l0;
        nint v24 = unchecked((nint)(v23.LongLength));
        int v25 = unchecked((int)(v24));
        int v26 = 8;
        int v27 = unchecked(v25 / v26);
        int v28 = unchecked(v22 * v27);
        if (v21 <= v28) {
            goto IL_006E;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v29 = l0;
        nint v30 = unchecked((nint)(v29.LongLength));
        int v31 = unchecked((int)(v30));
        int v32 = 2;
        int v33 = checked(v31 * v32);
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v34 = __cil_newarr_0100003E(v33);
        l7 = v34;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v35 = l0;
        int v36 = l2;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v37 = l7;
        int v38 = 0;
        int v39 = l6;
        System.Array.Copy(((__cil_type_01000022)(v35)), v36, ((__cil_type_01000022)(v37)), v38, v39);
        global::System.Xml.XmlSqlBinaryReader v40 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v41 = l7;
        l0 = v41;
        v40._data = v41;
        goto IL_0079;
        IL_006E: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v42 = l0;
        int v43 = l2;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v44 = l0;
        int v45 = 0;
        int v46 = l6;
        System.Array.Copy(((__cil_type_01000022)(v42)), v43, ((__cil_type_01000022)(v44)), v45, v46);
        goto IL_0079;
        IL_0079: ;
        int v47 = l1;
        int v48 = l2;
        int v49 = unchecked(v47 - v48);
        l1 = v49;
        int v50 = l3;
        int v51 = l2;
        int v52 = unchecked(v50 - v51);
        l3 = v52;
        global::System.Xml.XmlSqlBinaryReader v53 = this;
        global::System.Xml.XmlSqlBinaryReader v54 = this;
        int v55 = v54._tokDataPos;
        int v56 = l2;
        int v57 = unchecked(v55 - v56);
        v53._tokDataPos = v57;
        int v58 = 0;
        l8 = v58;
        goto IL_00AE;
        IL_0094: ;
        global::System.Xml.XmlSqlBinaryReader v59 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v60 = v59._attributes;
        int v61 = l8;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v62 = ref __cil_ldelema_0200006F(v60, v61);
        int v63 = l2;
        int v64 = unchecked(-v63);
        __cil_direct_06000832(ref v62, v64);
        int v65 = l8;
        int v66 = 1;
        int v67 = unchecked(v65 + v66);
        l8 = v67;
        goto IL_00AE;
        IL_00AE: ;
        int v68 = l8;
        global::System.Xml.XmlSqlBinaryReader v69 = this;
        int v70 = v69._attrCount;
        if (v68 < v70) {
            goto IL_0094;
        } else {
            goto IL_00B8;
        }
        IL_00B8: ;
        global::System.Xml.XmlSqlBinaryReader v71 = this;
        int v72 = l1;
        v71._pos = v72;
        global::System.Xml.XmlSqlBinaryReader v73 = this;
        int v74 = 0;
        v73._mark = v74;
        global::System.Xml.XmlSqlBinaryReader v75 = this;
        global::System.Xml.XmlSqlBinaryReader v76 = this;
        long v77 = v76._offset;
        int v78 = l2;
        long v79 = unchecked((long)(v78));
        long v80 = unchecked(v77 + v79);
        v75._offset = v80;
        goto IL_0112;
        IL_00D7: ;
        global::System.Xml.XmlSqlBinaryReader v81 = this;
        global::System.Xml.XmlSqlBinaryReader v82 = this;
        int v83 = v82._pos;
        int v84 = l3;
        int v85 = unchecked(v83 - v84);
        v81._pos = v85;
        global::System.Xml.XmlSqlBinaryReader v86 = this;
        global::System.Xml.XmlSqlBinaryReader v87 = this;
        int v88 = v87._mark;
        int v89 = l3;
        int v90 = unchecked(v88 - v89);
        v86._mark = v90;
        global::System.Xml.XmlSqlBinaryReader v91 = this;
        global::System.Xml.XmlSqlBinaryReader v92 = this;
        long v93 = v92._offset;
        int v94 = l3;
        long v95 = unchecked((long)(v94));
        long v96 = unchecked(v93 + v95);
        v91._offset = v96;
        global::System.Xml.XmlSqlBinaryReader v97 = this;
        global::System.Xml.XmlSqlBinaryReader v98 = this;
        int v99 = v98._tokDataPos;
        int v100 = l3;
        int v101 = unchecked(v99 - v100);
        v97._tokDataPos = v101;
        int v102 = 0;
        l3 = v102;
        goto IL_0112;
        IL_0112: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v103 = l0;
        nint v104 = unchecked((nint)(v103.LongLength));
        int v105 = unchecked((int)(v104));
        int v106 = l3;
        int v107 = unchecked(v105 - v106);
        l4 = v107;
        global::System.Xml.XmlSqlBinaryReader v108 = this;
        __cil_type_01000049 v109 = v108._inStrm;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v110 = l0;
        int v111 = l3;
        int v112 = l4;
        int v113 = v109.Read(v110, v111, v112);
        l5 = v113;
        global::System.Xml.XmlSqlBinaryReader v114 = this;
        int v115 = l3;
        int v116 = l5;
        int v117 = unchecked(v115 + v116);
        v114._end = v117;
        global::System.Xml.XmlSqlBinaryReader v118 = this;
        int v119 = l5;
        int v120 = 0;
        int v121 = (v119 > v120 ? 1 : 0);
        int v122 = 0;
        int v123 = (v121 == v122 ? 1 : 0);
        v118._eof = __cil_bool_store(v123);
        int v124 = l5;
        int v125 = 0;
        int v126 = (v124 > v125 ? 1 : 0);
        return __cil_bool_store(v126);
    }

    private void Fill_(int require)
    {
        IL_0000: ;
        int v1 = __cil_bool_load(__cil_direct_060007C9(this));
        if (v1 == 0) {
            goto IL_0018;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v3 = this._pos;
        int v5 = unchecked(v3 + require);
        int v7 = this._end;
        if (v5 >= v7) {
            goto IL_0000;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        int v9 = this._pos;
        int v11 = unchecked(v9 + require);
        int v13 = this._end;
        if (v11 < v13) {
            goto IL_0034;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        string v15 = System.SR.get_Xml_UnexpectedEOF1();
        global::System.Exception v16 = __cil_direct_0600081B(this, v15);
        throw v16;
        IL_0034: ;
        return;
    }

    private void Fill(int require)
    {
        int v1 = this._pos;
        int v3 = unchecked(v1 + require);
        int v5 = this._end;
        if (v3 < v5) {
            goto IL_0017;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        __cil_direct_060007CA(this, require);
        IL_0017: ;
        return;
    }

    private byte ReadByte()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_direct_060007CB(this, 0);
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v3 = this._data;
        int v6 = this._pos;
        this._pos = unchecked(v6 + 1);
        int v11 = unchecked((int)(unchecked((byte)(unchecked((int)(v3[v6]))))));
        return unchecked((byte)(v11));
    }

    private ushort ReadUShort()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        ushort l2 = default;
        __cil_direct_060007CB(this, 1);
        int v3 = this._pos;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v5 = this._data;
        int v8 = unchecked((int)(unchecked((byte)(unchecked((int)(v5[v3]))))));
        int v12 = unchecked(v3 + 1);
        int v13 = unchecked((int)(unchecked((byte)(unchecked((int)(v5[v12]))))));
        int v15 = (v13 << 8);
        int v16 = unchecked(v8 + v15);
        int v17 = unchecked((int)(unchecked((ushort)(v16))));
        l2 = unchecked((ushort)(v17));
        int v20 = this._pos;
        this._pos = unchecked(v20 + 2);
        int v23 = unchecked((int)(l2));
        return unchecked((ushort)(v23));
    }

    private int ParseMB32()
    {
        byte l0 = default;
        int v1 = unchecked((int)(__cil_direct_060007CC(this)));
        l0 = unchecked((byte)(v1));
        int v2 = unchecked((int)(l0));
        if (v2 <= 127) {
            goto IL_0014;
        } else {
            goto IL_000C;
        }
        IL_000C: ;
        int v5 = unchecked((int)(l0));
        int v6 = __cil_direct_060007CF(this, unchecked((byte)(v5)));
        return v6;
        IL_0014: ;
        int v7 = unchecked((int)(l0));
        return v7;
    }

    private int ParseMB32_(byte b)
    {
        uint l0 = default;
        uint l1 = default;
        int v0 = unchecked((int)(b));
        int v2 = unchecked(v0 & 127);
        l0 = unchecked((uint)(v2));
        int v4 = unchecked((int)(__cil_direct_060007CC(this)));
        b = unchecked((byte)(v4));
        int v5 = unchecked((int)(b));
        int v7 = unchecked(v5 & 127);
        l1 = unchecked((uint)(v7));
        int v8 = unchecked((int)(l0));
        int v9 = unchecked((int)(l1));
        int v11 = (v9 << 7);
        int v12 = unchecked(v8 + v11);
        l0 = unchecked((uint)(v12));
        int v13 = unchecked((int)(b));
        if (v13 <= 127) {
            goto IL_0072;
        } else {
            goto IL_001D;
        }
        IL_001D: ;
        int v16 = unchecked((int)(__cil_direct_060007CC(this)));
        b = unchecked((byte)(v16));
        int v17 = unchecked((int)(b));
        int v19 = unchecked(v17 & 127);
        l1 = unchecked((uint)(v19));
        int v20 = unchecked((int)(l0));
        int v21 = unchecked((int)(l1));
        int v23 = (v21 << 14);
        int v24 = unchecked(v20 + v23);
        l0 = unchecked((uint)(v24));
        int v25 = unchecked((int)(b));
        if (v25 <= 127) {
            goto IL_0072;
        } else {
            goto IL_0036;
        }
        IL_0036: ;
        int v28 = unchecked((int)(__cil_direct_060007CC(this)));
        b = unchecked((byte)(v28));
        int v29 = unchecked((int)(b));
        int v31 = unchecked(v29 & 127);
        l1 = unchecked((uint)(v31));
        int v32 = unchecked((int)(l0));
        int v33 = unchecked((int)(l1));
        int v35 = (v33 << 21);
        int v36 = unchecked(v32 + v35);
        l0 = unchecked((uint)(v36));
        int v37 = unchecked((int)(b));
        if (v37 <= 127) {
            goto IL_0072;
        } else {
            goto IL_004F;
        }
        IL_004F: ;
        int v40 = unchecked((int)(__cil_direct_060007CC(this)));
        b = unchecked((byte)(v40));
        int v41 = unchecked((int)(b));
        int v43 = unchecked(v41 & 7);
        l1 = unchecked((uint)(v43));
        int v44 = unchecked((int)(b));
        if (v44 <= 7) {
            goto IL_006B;
        } else {
            goto IL_005F;
        }
        IL_005F: ;
        string v47 = System.SR.get_XmlBinary_ValueTooBig();
        global::System.Exception v48 = __cil_direct_0600081B(this, v47);
        throw v48;
        IL_006B: ;
        int v49 = unchecked((int)(l0));
        int v50 = unchecked((int)(l1));
        int v52 = (v50 << 28);
        int v53 = unchecked(v49 + v52);
        l0 = unchecked((uint)(v53));
        IL_0072: ;
        int v54 = unchecked((int)(l0));
        return v54;
    }

    private int ParseMB32(int pos)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        uint l0 = default;
        uint l1 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 l2 = default;
        byte l3 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        l2 = v1;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = l2;
        int v3 = pos;
        pos = unchecked(v3 + 1);
        int v6 = unchecked((int)(unchecked((byte)(unchecked((int)(v2[v3]))))));
        l3 = unchecked((byte)(v6));
        int v7 = unchecked((int)(l3));
        int v9 = unchecked(v7 & 127);
        l0 = unchecked((uint)(v9));
        int v10 = unchecked((int)(l3));
        if (v10 <= 127) {
            goto IL_008B;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v12 = l2;
        int v13 = pos;
        pos = unchecked(v13 + 1);
        int v16 = unchecked((int)(unchecked((byte)(unchecked((int)(v12[v13]))))));
        l3 = unchecked((byte)(v16));
        int v17 = unchecked((int)(l3));
        int v19 = unchecked(v17 & 127);
        l1 = unchecked((uint)(v19));
        int v20 = unchecked((int)(l0));
        int v21 = unchecked((int)(l1));
        int v23 = (v21 << 7);
        int v24 = unchecked(v20 + v23);
        l0 = unchecked((uint)(v24));
        int v25 = unchecked((int)(l3));
        if (v25 <= 127) {
            goto IL_008B;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v27 = l2;
        int v28 = pos;
        pos = unchecked(v28 + 1);
        int v31 = unchecked((int)(unchecked((byte)(unchecked((int)(v27[v28]))))));
        l3 = unchecked((byte)(v31));
        int v32 = unchecked((int)(l3));
        int v34 = unchecked(v32 & 127);
        l1 = unchecked((uint)(v34));
        int v35 = unchecked((int)(l0));
        int v36 = unchecked((int)(l1));
        int v38 = (v36 << 14);
        int v39 = unchecked(v35 + v38);
        l0 = unchecked((uint)(v39));
        int v40 = unchecked((int)(l3));
        if (v40 <= 127) {
            goto IL_008B;
        } else {
            goto IL_004D;
        }
        IL_004D: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v42 = l2;
        int v43 = pos;
        pos = unchecked(v43 + 1);
        int v46 = unchecked((int)(unchecked((byte)(unchecked((int)(v42[v43]))))));
        l3 = unchecked((byte)(v46));
        int v47 = unchecked((int)(l3));
        int v49 = unchecked(v47 & 127);
        l1 = unchecked((uint)(v49));
        int v50 = unchecked((int)(l0));
        int v51 = unchecked((int)(l1));
        int v53 = (v51 << 21);
        int v54 = unchecked(v50 + v53);
        l0 = unchecked((uint)(v54));
        int v55 = unchecked((int)(l3));
        if (v55 <= 127) {
            goto IL_008B;
        } else {
            goto IL_0067;
        }
        IL_0067: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v57 = l2;
        int v58 = pos;
        pos = unchecked(v58 + 1);
        int v61 = unchecked((int)(unchecked((byte)(unchecked((int)(v57[v58]))))));
        l3 = unchecked((byte)(v61));
        int v62 = unchecked((int)(l3));
        int v64 = unchecked(v62 & 7);
        l1 = unchecked((uint)(v64));
        int v65 = unchecked((int)(l3));
        if (v65 <= 7) {
            goto IL_0084;
        } else {
            goto IL_0078;
        }
        IL_0078: ;
        string v68 = System.SR.get_XmlBinary_ValueTooBig();
        global::System.Exception v69 = __cil_direct_0600081B(this, v68);
        throw v69;
        IL_0084: ;
        int v70 = unchecked((int)(l0));
        int v71 = unchecked((int)(l1));
        int v73 = (v71 << 28);
        int v74 = unchecked(v70 + v73);
        l0 = unchecked((uint)(v74));
        IL_008B: ;
        int v75 = unchecked((int)(l0));
        return v75;
    }

    private int ParseMB64()
    {
        byte l0 = default;
        int v1 = unchecked((int)(__cil_direct_060007CC(this)));
        l0 = unchecked((byte)(v1));
        int v2 = unchecked((int)(l0));
        if (v2 <= 127) {
            goto IL_0014;
        } else {
            goto IL_000C;
        }
        IL_000C: ;
        int v5 = unchecked((int)(l0));
        int v6 = __cil_direct_060007CF(this, unchecked((byte)(v5)));
        return v6;
        IL_0014: ;
        int v7 = unchecked((int)(l0));
        return v7;
    }

    private System.Xml.BinXmlToken PeekToken()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        int v1 = this._pos;
        int v3 = this._end;
        if (v1 < v3) {
            goto IL_0016;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int v5 = __cil_bool_load(__cil_direct_060007C9(this));
        if (v5 != 0) {
            goto IL_0000;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        int v7 = this._pos;
        int v9 = this._end;
        if (v7 < v9) {
            goto IL_0026;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        return unchecked((__cil_enum_02000073)(-1));
        IL_0026: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v12 = this._data;
        int v14 = this._pos;
        int v15 = unchecked((int)(unchecked((byte)(unchecked((int)(v12[v14]))))));
        return unchecked((__cil_enum_02000073)(v15));
    }

    private System.Xml.BinXmlToken ReadToken()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        int v1 = this._pos;
        int v3 = this._end;
        if (v1 < v3) {
            goto IL_0016;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int v5 = __cil_bool_load(__cil_direct_060007C9(this));
        if (v5 != 0) {
            goto IL_0000;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        int v7 = this._pos;
        int v9 = this._end;
        if (v7 < v9) {
            goto IL_0026;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        return unchecked((__cil_enum_02000073)(-1));
        IL_0026: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v12 = this._data;
        int v15 = this._pos;
        this._pos = unchecked(v15 + 1);
        int v20 = unchecked((int)(unchecked((byte)(unchecked((int)(v12[v15]))))));
        return unchecked((__cil_enum_02000073)(v20));
    }

    private System.Xml.BinXmlToken NextToken2(System.Xml.BinXmlToken token)
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        int v0 = unchecked((int)(token));
        if (v0 > 234) {
            goto IL_001A;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v2 = unchecked((int)(token));
        if (v2 == 233) {
            goto IL_003A;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        int v4 = unchecked((int)(token));
        if (v4 == 234) {
            goto IL_0042;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        goto IL_004A;
        IL_001A: ;
        int v6 = unchecked((int)(token));
        if (v6 == 239) {
            goto IL_0032;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        int v8 = unchecked((int)(token));
        if (unchecked((uint)v8) != unchecked((uint)240)) {
            goto IL_004A;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        __cil_direct_060007C3(this);
        goto IL_004C;
        IL_0032: ;
        __cil_direct_060007C4(this);
        goto IL_004C;
        IL_003A: ;
        __cil_direct_060007C5(this);
        goto IL_004C;
        IL_0042: ;
        __cil_direct_060007C6(this);
        goto IL_004C;
        IL_004A: ;
        int v14 = unchecked((int)(token));
        return unchecked((__cil_enum_02000073)(v14));
        IL_004C: ;
        int v16 = unchecked((int)(__cil_direct_060007D3(this)));
        token = unchecked((__cil_enum_02000073)(v16));
        goto IL_0000;
    }

    private System.Xml.BinXmlToken NextToken1()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        int l1 = default;
        int v1 = this._pos;
        l1 = v1;
        int v2 = l1;
        int v4 = this._end;
        if (v2 < v4) {
            goto IL_0019;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        int v6 = unchecked((int)(__cil_direct_060007D3(this)));
        l0 = unchecked((__cil_enum_02000073)(v6));
        goto IL_002B;
        IL_0019: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v8 = this._data;
        int v9 = l1;
        int v10 = unchecked((int)(unchecked((byte)(unchecked((int)(v8[v9]))))));
        l0 = unchecked((__cil_enum_02000073)(v10));
        int v12 = l1;
        this._pos = unchecked(v12 + 1);
        IL_002B: ;
        int v15 = unchecked((int)(l0));
        if (v15 < 233) {
            goto IL_0043;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        int v17 = unchecked((int)(l0));
        if (v17 > 240) {
            goto IL_0043;
        } else {
            goto IL_003B;
        }
        IL_003B: ;
        int v20 = unchecked((int)(l0));
        int v21 = unchecked((int)(__cil_direct_060007D4(this, unchecked((__cil_enum_02000073)(v20)))));
        return unchecked((__cil_enum_02000073)(v21));
        IL_0043: ;
        int v22 = unchecked((int)(l0));
        return unchecked((__cil_enum_02000073)(v22));
    }

    private System.Xml.BinXmlToken NextToken()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_enum_02000073 l1 = default;
        int v1 = this._pos;
        l0 = v1;
        int v2 = l0;
        int v4 = this._end;
        if (v2 >= v4) {
            goto IL_0034;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v6 = this._data;
        int v7 = l0;
        int v8 = unchecked((int)(unchecked((byte)(unchecked((int)(v6[v7]))))));
        l1 = unchecked((__cil_enum_02000073)(v8));
        int v9 = unchecked((int)(l1));
        if (v9 < 233) {
            goto IL_0029;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        int v11 = unchecked((int)(l1));
        if (v11 <= 240) {
            goto IL_0034;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        int v14 = l0;
        this._pos = unchecked(v14 + 1);
        int v17 = unchecked((int)(l1));
        return unchecked((__cil_enum_02000073)(v17));
        IL_0034: ;
        int v19 = unchecked((int)(__cil_direct_060007D5(this)));
        return unchecked((__cil_enum_02000073)(v19));
    }

    private System.Xml.BinXmlToken PeekNextToken()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        int v1 = unchecked((int)(__cil_direct_060007D6(this)));
        l0 = unchecked((__cil_enum_02000073)(v1));
        int v3 = unchecked((int)(l0));
        if (-1 == v3) {
            goto IL_0019;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        int v6 = unchecked(this._pos--);
        IL_0019: ;
        int v9 = unchecked((int)(l0));
        return unchecked((__cil_enum_02000073)(v9));
    }

    private System.Xml.BinXmlToken RescanNextToken()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        IL_0000: ;
        int v1 = unchecked((int)(__cil_direct_060007D3(this)));
        l0 = unchecked((__cil_enum_02000073)(v1));
        int v2 = unchecked((int)(l0));
        if (v2 > 234) {
            goto IL_0021;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        int v4 = unchecked((int)(l0));
        if (v4 == 233) {
            goto IL_0000;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        int v6 = unchecked((int)(l0));
        if (v6 == 234) {
            goto IL_0061;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        goto IL_0078;
        IL_0021: ;
        int v8 = unchecked((int)(l0));
        if (v8 == 239) {
            goto IL_004A;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        int v10 = unchecked((int)(l0));
        if (unchecked((uint)v10) != unchecked((uint)240)) {
            goto IL_0078;
        } else {
            goto IL_0031;
        }
        IL_0031: ;
        int v13 = __cil_direct_060007CE(this);
        int v16 = this._pos;
        int v19 = checked(2 * v13);
        int v20 = checked(v16 + v19);
        this._pos = v20;
        goto IL_0000;
        IL_004A: ;
        int v22 = __cil_direct_060007CE(this);
        int v24 = __cil_direct_060007CE(this);
        int v26 = __cil_direct_060007CE(this);
        goto IL_0000;
        IL_0061: ;
        int v28 = __cil_direct_060007CE(this);
        int v31 = this._pos;
        int v33 = checked(v31 + v28);
        this._pos = v33;
        goto IL_0000;
        IL_0078: ;
        int v34 = unchecked((int)(l0));
        return unchecked((__cil_enum_02000073)(v34));
    }

    private string ParseText()
    {
        int l0 = default;
        int l1 = default;
        int l2 = default;
        string l3 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._mark;
        l0 = v1;
        try {
            IL_0007: ;
            int v2 = l0;
            int v3 = 0;
            if (v2 >= v3) {
                goto IL_0017;
            } else {
                goto IL_000B;
            }
            IL_000B: ;
            global::System.Xml.XmlSqlBinaryReader v4 = this;
            global::System.Xml.XmlSqlBinaryReader v5 = this;
            int v6 = v5._pos;
            v4._mark = v6;
            goto IL_0017;
            IL_0017: ;
            global::System.Xml.XmlSqlBinaryReader v7 = this;
            ref int v8 = ref l2;
            int v9 = __cil_direct_060007DA(v7, ref v8);
            l1 = v9;
            global::System.Xml.XmlSqlBinaryReader v10 = this;
            int v11 = l2;
            int v12 = l1;
            string v13 = __cil_direct_060007DB(v10, v11, v12);
            l3 = v13;
            goto IL_0037;
        }
        finally {
            IL_002B: ;
            int v14 = l0;
            int v15 = 0;
            if (v14 >= v15) {
                goto IL_0036;
            } else {
                goto IL_002F;
            }
            IL_002F: ;
            global::System.Xml.XmlSqlBinaryReader v16 = this;
            int v17 = -1;
            v16._mark = v17;
            goto IL_0036;
            IL_0036: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0037: ;
        string v18 = l3;
        return v18;
    }

    private int ScanText(out int start)
    {
        int l0 = default;
        int l1 = default;
        int l2 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = __cil_direct_060007CE(v0);
        l0 = v1;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        int v3 = v2._mark;
        l1 = v3;
        global::System.Xml.XmlSqlBinaryReader v4 = this;
        int v5 = v4._pos;
        l2 = v5;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        int v8 = v7._pos;
        int v9 = l0;
        int v10 = 2;
        int v11 = checked(v9 * v10);
        int v12 = checked(v8 + v11);
        v6._pos = v12;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = v13._pos;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        int v16 = v15._end;
        if (v14 <= v16) {
            goto IL_003A;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        int v18 = -1;
        __cil_direct_060007CB(v17, v18);
        goto IL_003A;
        IL_003A: ;
        ref int v19 = ref start;
        int v20 = l2;
        int v21 = l1;
        global::System.Xml.XmlSqlBinaryReader v22 = this;
        int v23 = v22._mark;
        int v24 = unchecked(v21 - v23);
        int v25 = unchecked(v20 - v24);
        v19 = v25;
        int v26 = l0;
        return v26;
    }

    private string GetString(int pos, int cch)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v3 = checked(cch * 2);
        int v4 = checked(pos + v3);
        int v6 = this._end;
        if (v4 <= v6) {
            goto IL_0019;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        string v7 = System.SR.get_Xml_UnexpectedEOF1();
        global::System.Xml.XmlException v8 = __cil_newobj_06000A0A(v7, null);
        throw v8;
        IL_0019: ;
        if (cch != 0) {
            goto IL_0022;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        string v10 = __cil_ldsfld_0A000002();
        return v10;
        IL_0022: ;
        int v13 = unchecked(pos & 1);
        if (v13 != 0) {
            goto IL_0036;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v16 = this._data;
        string v19 = __cil_direct_060007DC(this, v16, pos, cch);
        return v19;
        IL_0036: ;
        __cil_type_0100004A v21 = this._unicode;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v23 = this._data;
        int v27 = checked(cch * 2);
        string v28 = v21.GetString(v23, pos, v27);
        return v28;
    }

    private string GetStringAligned(byte[] data, int offset, int cch)
    {
        // IL fallback: pinned/byref/modified local needs IL fallback
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [03, 25, 0B, 2C, 05, 07, 8E, 69, 2D, 05, 16, E0, 0A, 2B, 09, 07, 16, 8F, 3E, 00, 00, 01, E0, 0A]
        // .code-bytes IL_0018: [06, 04, 58, 0C, 08, 16, 05, 73, B0, 00, 00, 0A, 2A]
        // .local [0] uint8*
        // .local [1] uint8[] pinned
        // .local [2] char*
        // IL_0000: ldarg.1 1
        // IL_0001: dup 
        // IL_0002: stloc.1 1
        // IL_0003: brfalse.s IL_000A
        // IL_0005: ldloc.1 1
        // IL_0006: ldlen 
        // IL_0007: conv.i4 
        // IL_0008: brtrue.s IL_000F
        // IL_000A: ldc.i4.0 0
        // IL_000B: conv.u 
        // IL_000C: stloc.0 0
        // IL_000D: br.s IL_0018
        // IL_000F: ldloc.1 1
        // IL_0010: ldc.i4.0 0
        // IL_0011: ldelema 0x0100003E [System.Runtime]System.Byte
        // IL_0016: conv.u 
        // IL_0017: stloc.0 0
        // IL_0018: ldloc.0 0
        // IL_0019: ldarg.2 2
        // IL_001A: add 
        // IL_001B: stloc.2 2
        // IL_001C: ldloc.2 2
        // IL_001D: ldc.i4.0 0
        // IL_001E: ldarg.3 3
        // IL_001F: newobj 0x0A0000B0 [System.Runtime]System.String::.ctor
        // IL_0024: ret 
    }

    private string GetAttributeText(int i)
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        int l1 = default;
        __cil_enum_02000073 l2 = default;
        string l3 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v1 = v0._attributes;
        int v2 = i;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v3 = ref __cil_ldelema_0200006F(v1, v2);
        string v4 = v3.val;
        l0 = v4;
        string v5 = l0;
        if (v5 is null) {
            goto IL_0017;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        string v6 = l0;
        return v6;
        IL_0017: ;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        int v8 = v7._pos;
        l1 = v8;
        try {
            IL_001E: ;
            global::System.Xml.XmlSqlBinaryReader v9 = this;
            global::System.Xml.XmlSqlBinaryReader v10 = this;
            __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v11 = v10._attributes;
            int v12 = i;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v13 = ref __cil_ldelema_0200006F(v11, v12);
            int v14 = v13.contentPos;
            v9._pos = v14;
            global::System.Xml.XmlSqlBinaryReader v15 = this;
            int v16 = unchecked((int)(__cil_direct_060007D8(v15)));
            l2 = unchecked((__cil_enum_02000073)(v16));
            int v17 = 246;
            int v18 = unchecked((int)(l2));
            if (v17 == v18) {
                goto IL_004C;
            } else {
                goto IL_0044;
            }
            IL_0044: ;
            int v19 = 245;
            int v20 = unchecked((int)(l2));
            if (unchecked((uint)v19) != unchecked((uint)v20)) {
                goto IL_0054;
            } else {
                goto IL_004C;
            }
            IL_004C: ;
            string v21 = __cil_ldstr_700000D5("");
            l3 = v21;
            goto IL_0074;
            IL_0054: ;
            global::System.Xml.XmlSqlBinaryReader v22 = this;
            int v23 = unchecked((int)(l2));
            v22._token = unchecked((__cil_enum_02000073)(v23));
            global::System.Xml.XmlSqlBinaryReader v24 = this;
            int v25 = unchecked((int)(l2));
            __cil_direct_060007FF(v24, unchecked((__cil_enum_02000073)(v25)));
            global::System.Xml.XmlSqlBinaryReader v26 = this;
            int v27 = unchecked((int)(l2));
            string v28 = __cil_direct_0600080E(v26, unchecked((__cil_enum_02000073)(v27)));
            l3 = v28;
            goto IL_0074;
        }
        finally {
            IL_006C: ;
            global::System.Xml.XmlSqlBinaryReader v29 = this;
            int v30 = l1;
            v29._pos = v30;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0074: ;
        string v31 = l3;
        return v31;
    }

    private int LocateAttribute(string name, string ns)
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        IL_0000: ;
        int v0 = 0;
        l0 = v0;
        goto IL_0024;
        IL_0004: ;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v2 = v1._attributes;
        int v3 = l0;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v4 = ref __cil_ldelema_0200006F(v2, v3);
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v5 = ref v4.name;
        string v6 = name;
        string v7 = ns;
        int v8 = __cil_bool_load(__cil_direct_06000822(ref v5, v6, v7));
        if (v8 == 0) {
            goto IL_0020;
        } else {
            goto IL_001E;
        }
        IL_001E: ;
        int v9 = l0;
        return v9;
        IL_0020: ;
        int v10 = l0;
        int v11 = 1;
        int v12 = unchecked(v10 + v11);
        l0 = v12;
        goto IL_0024;
        IL_0024: ;
        int v13 = l0;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        int v15 = v14._attrCount;
        if (v13 < v15) {
            goto IL_0004;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        int v16 = -1;
        return v16;
    }

    private int LocateAttribute(string name)
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string l0 = default;
        string l1 = default;
        int l2 = default;
        IL_0000: ;
        string v0 = name;
        ref string v1 = ref l0;
        ref string v2 = ref l1;
        System.Xml.ValidateNames.SplitQName(v0, ref v1, ref v2);
        int v3 = 0;
        l2 = v3;
        goto IL_002E;
        IL_000E: ;
        global::System.Xml.XmlSqlBinaryReader v4 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v5 = v4._attributes;
        int v6 = l2;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v7 = ref __cil_ldelema_0200006F(v5, v6);
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v8 = ref v7.name;
        string v9 = l0;
        string v10 = l1;
        int v11 = __cil_bool_load(__cil_direct_06000823(ref v8, v9, v10));
        if (v11 == 0) {
            goto IL_002A;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        int v12 = l2;
        return v12;
        IL_002A: ;
        int v13 = l2;
        int v14 = 1;
        int v15 = unchecked(v13 + v14);
        l2 = v15;
        goto IL_002E;
        IL_002E: ;
        int v16 = l2;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        int v18 = v17._attrCount;
        if (v16 < v18) {
            goto IL_000E;
        } else {
            goto IL_0037;
        }
        IL_0037: ;
        int v19 = -1;
        return v19;
    }

    private void PositionOnAttribute(int i)
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = i;
        v0._attrIndex = v1;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v4 = v3._attributes;
        int v5 = i;
        int v6 = 1;
        int v7 = unchecked(v5 - v6);
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v8 = ref __cil_ldelema_0200006F(v4, v7);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v9 = v8.name;
        v2._qnameOther = v9;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        int v11 = unchecked((int)(v10._state));
        if (v11 != 0) {
            goto IL_0034;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = unchecked((int)(v13._nodetype));
        v12._parentNodeType = unchecked((__cil_enum_020000B5)(v14));
        goto IL_0034;
        IL_0034: ;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        int v16 = 246;
        v15._token = unchecked((__cil_enum_02000073)(v16));
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        int v18 = 2;
        v17._nodetype = unchecked((__cil_enum_020000B5)(v18));
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        int v20 = 2;
        v19._state = unchecked((__cil_enum_0200006C)(v20));
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        __cil_type_01000004 v22 = System.Xml.XmlSqlBinaryReader.TypeOfObject;
        v21._valueType = v22;
        global::System.Xml.XmlSqlBinaryReader v23 = this;
        v23._stringValue = null;
        return;
    }

    private void GrowElements()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v1 = this._elementStack;
        nint v2 = unchecked((nint)(v1.LongLength));
        int v3 = unchecked((int)(v2));
        l0 = unchecked(v3 * 2);
        int v6 = l0;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v7 = __cil_newarr_0200006E(v6);
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v9 = this._elementStack;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v14 = this._elementStack;
        nint v15 = unchecked((nint)(v14.LongLength));
        int v16 = unchecked((int)(v15));
        System.Array.Copy(((__cil_type_01000022)(v9)), 0, ((__cil_type_01000022)(v7)), 0, v16);
        this._elementStack = v7;
        return;
    }

    private void GrowAttributes()
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v1 = this._attributes;
        nint v2 = unchecked((nint)(v1.LongLength));
        int v3 = unchecked((int)(v2));
        l0 = unchecked(v3 * 2);
        int v6 = l0;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v7 = __cil_newarr_0200006F(v6);
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v9 = this._attributes;
        int v14 = this._attrCount;
        System.Array.Copy(((__cil_type_01000022)(v9)), 0, ((__cil_type_01000022)(v7)), 0, v14);
        this._attributes = v7;
        return;
    }

    private void ClearAttributes()
    {
        int v1 = this._attrCount;
        if (v1 == 0) {
            goto IL_000F;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        this._attrCount = 0;
        IL_000F: ;
        return;
    }

    private void PushNamespace(string prefix, string ns, bool implied)
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af bytes=151280D1020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l1 = default;
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l2 = default;
        int l3 = default;
        IL_0000: ;
        string v0 = prefix;
        string v1 = __cil_ldstr_700003A9("xml");
        int v2 = __cil_bool_load(System.String.op_Equality(v0, v1));
        if (v2 == 0) {
            goto IL_000E;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        return;
        IL_000E: ;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        int v4 = v3._elemDepth;
        l0 = v4;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v6 = v5._namespaces;
        string v7 = prefix;
        ref global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v8 = ref l1;
        int v9 = __cil_bool_load(__cil_callvirt_0A0000A2(v6, v7, ref v8));
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v10 = l1;
        if (v10 is null) {
            goto IL_00AF;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v11 = l1;
        string v12 = v11.uri;
        string v13 = ns;
        int v14 = __cil_bool_load(System.String.op_Equality(v12, v13));
        if (v14 == 0) {
            goto IL_0054;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        int v15 = __cil_bool_load(implied);
        if (v15 != 0) {
            goto IL_0053;
        } else {
            goto IL_003B;
        }
        IL_003B: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v16 = l1;
        int v17 = __cil_bool_load(v16.implied);
        if (v17 == 0) {
            goto IL_0053;
        } else {
            goto IL_0043;
        }
        IL_0043: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v18 = l1;
        int v19 = v18.scope;
        int v20 = l0;
        if (unchecked((uint)v19) != unchecked((uint)v20)) {
            goto IL_0053;
        } else {
            goto IL_004C;
        }
        IL_004C: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v21 = l1;
        int v22 = 0;
        v21.implied = __cil_bool_store(v22);
        goto IL_0053;
        IL_0053: ;
        return;
        IL_0054: ;
        global::System.Xml.XmlSqlBinaryReader v23 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v24 = ref v23._qnameElement;
        string v25 = prefix;
        string v26 = ns;
        __cil_direct_06000824(ref v24, v25, v26);
        string v27 = prefix;
        int v28 = ((System.String)v27).Length;
        if (v28 == 0) {
            goto IL_00AF;
        } else {
            goto IL_0069;
        }
        IL_0069: ;
        int v29 = 0;
        l3 = v29;
        goto IL_00A6;
        IL_006D: ;
        global::System.Xml.XmlSqlBinaryReader v30 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v31 = v30._attributes;
        int v32 = l3;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v33 = ref __cil_ldelema_0200006F(v31, v32);
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v34 = ref v33.name;
        string v35 = v34.prefix;
        int v36 = ((System.String)v35).Length;
        if (v36 == 0) {
            goto IL_00A2;
        } else {
            goto IL_008A;
        }
        IL_008A: ;
        global::System.Xml.XmlSqlBinaryReader v37 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v38 = v37._attributes;
        int v39 = l3;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v40 = ref __cil_ldelema_0200006F(v38, v39);
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v41 = ref v40.name;
        string v42 = prefix;
        string v43 = ns;
        __cil_direct_06000824(ref v41, v42, v43);
        goto IL_00A2;
        IL_00A2: ;
        int v44 = l3;
        int v45 = 1;
        int v46 = unchecked(v44 + v45);
        l3 = v46;
        goto IL_00A6;
        IL_00A6: ;
        int v47 = l3;
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        int v49 = v48._attrCount;
        if (v47 < v49) {
            goto IL_006D;
        } else {
            goto IL_00AF;
        }
        IL_00AF: ;
        string v50 = prefix;
        string v51 = ns;
        global::System.Xml.XmlSqlBinaryReader v52 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v53 = v52._elementStack;
        int v54 = l0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v55 = ref __cil_ldelema_0200006E(v53, v54);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v56 = v55.nsdecls;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v57 = l1;
        int v58 = l0;
        int v59 = __cil_bool_load(implied);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v60 = __cil_newobj_06000833(v50, v51, v56, v57, v58, v59);
        l2 = v60;
        global::System.Xml.XmlSqlBinaryReader v61 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v62 = v61._elementStack;
        int v63 = l0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v64 = ref __cil_ldelema_0200006E(v62, v63);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v65 = l2;
        v64.nsdecls = v65;
        global::System.Xml.XmlSqlBinaryReader v66 = this;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v67 = v66._namespaces;
        string v68 = prefix;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v69 = l2;
        __cil_callvirt_0A0000B1(v67, v68, v69);
        return;
    }

    private void PopNamespaces(System.Xml.XmlSqlBinaryReader.NamespaceDecl firstInScopeChain)
    {
        // structural signature __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af bytes=151280D1020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l0 = default;
        l0 = firstInScopeChain;
        goto IL_004E;
        IL_0004: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v1 = l0;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v2 = v1.prevLink;
        if (v2 is not null) {
            goto IL_0020;
        } else {
            goto IL_000C;
        }
        IL_000C: ;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v4 = this._namespaces;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v5 = l0;
        string v6 = v5.prefix;
        int v7 = __cil_bool_load(__cil_callvirt_0A0000B2(v4, v6));
        goto IL_0037;
        IL_0020: ;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v9 = this._namespaces;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v10 = l0;
        string v11 = v10.prefix;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v12 = l0;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v13 = v12.prevLink;
        __cil_callvirt_0A0000B1(v9, v11, v13);
        IL_0037: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v14 = l0;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v15 = v14.scopeLink;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v16 = l0;
        v16.prevLink = null;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v17 = l0;
        v17.scopeLink = null;
        l0 = v15;
        IL_004E: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v19 = l0;
        if (v19 is not null) {
            goto IL_0004;
        } else {
            goto IL_0051;
        }
        IL_0051: ;
        return;
    }

    private void GenerateImpliedXmlnsAttrs()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l0 = default;
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l1 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v1 = v0._elementStack;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        int v3 = v2._elemDepth;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v4 = ref __cil_ldelema_0200006E(v1, v3);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v5 = v4.nsdecls;
        l1 = v5;
        goto IL_00BA;
        IL_001C: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v6 = l1;
        int v7 = __cil_bool_load(v6.implied);
        if (v7 == 0) {
            goto IL_00B3;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        int v9 = v8._attrCount;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v11 = v10._attributes;
        nint v12 = unchecked((nint)(v11.LongLength));
        int v13 = unchecked((int)(v12));
        if (unchecked((uint)v9) != unchecked((uint)v13)) {
            goto IL_003D;
        } else {
            goto IL_0037;
        }
        IL_0037: ;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        __cil_direct_060007E2(v14);
        goto IL_003D;
        IL_003D: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v15 = l1;
        string v16 = v15.prefix;
        int v17 = ((System.String)v16).Length;
        if (v17 != 0) {
            goto IL_0064;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v18 = ref l0;
        string v19 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlSqlBinaryReader v20 = this;
        string v21 = v20._xmlns;
        global::System.Xml.XmlSqlBinaryReader v22 = this;
        string v23 = v22._nsxmlns;
        __cil_value_ctor_0600081F(ref v18, v19, v21, v23);
        goto IL_0088;
        IL_0064: ;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v24 = ref l0;
        global::System.Xml.XmlSqlBinaryReader v25 = this;
        string v26 = v25._xmlns;
        global::System.Xml.XmlSqlBinaryReader v27 = this;
        global::System.Xml.XmlNameTable v28 = v27._xnt;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v29 = l1;
        string v30 = v29.prefix;
        string v31 = __cil_callvirt_06000A35(v28, v30);
        global::System.Xml.XmlSqlBinaryReader v32 = this;
        string v33 = v32._nsxmlns;
        __cil_value_ctor_0600081F(ref v24, v26, v31, v33);
        goto IL_0088;
        IL_0088: ;
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v35 = v34._attributes;
        global::System.Xml.XmlSqlBinaryReader v36 = this;
        int v37 = v36._attrCount;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v38 = ref __cil_ldelema_0200006F(v35, v37);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v39 = l0;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v40 = l1;
        string v41 = v40.uri;
        __cil_direct_0600082C(ref v38, v39, v41);
        global::System.Xml.XmlSqlBinaryReader v42 = this;
        global::System.Xml.XmlSqlBinaryReader v43 = this;
        int v44 = v43._attrCount;
        int v45 = 1;
        int v46 = unchecked(v44 + v45);
        v42._attrCount = v46;
        goto IL_00B3;
        IL_00B3: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v47 = l1;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v48 = v47.scopeLink;
        l1 = v48;
        goto IL_00BA;
        IL_00BA: ;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v49 = l1;
        if (v49 is not null) {
            goto IL_001C;
        } else {
            goto IL_00C0;
        }
        IL_00C0: ;
        return;
    }

    private bool ReadInit(bool skipXmlDecl)
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        ushort l1 = default;
        byte l2 = default;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l3 = default;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l4 = default;
        scoped ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c s14_0 = ref System.Runtime.CompilerServices.Unsafe.NullRef<__cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c>();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 s14_1 = default;
        scoped ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c s15_0 = ref System.Runtime.CompilerServices.Unsafe.NullRef<__cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c>();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 s15_1 = default;
        scoped ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c s16_0 = ref System.Runtime.CompilerServices.Unsafe.NullRef<__cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c>();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 s16_1 = default;
        string s16_2 = default;
        IL_0000: ;
        l0 = null;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = __cil_bool_load(v0._sniffed);
        if (v1 != 0) {
            goto IL_0024;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        int v3 = unchecked((int)(__cil_direct_060007CD(v2)));
        l1 = unchecked((ushort)(v3));
        int v4 = unchecked((int)(l1));
        int v5 = 65503;
        if (v4 == v5) {
            goto IL_0024;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        string v6 = System.SR.get_XmlBinary_InvalidSignature();
        l0 = v6;
        goto IL_01E6;
        IL_0024: ;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        int v9 = unchecked((int)(__cil_direct_060007CC(v8)));
        v7._version = unchecked((byte)(v9));
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        int v11 = unchecked((int)(v10._version));
        int v12 = 1;
        if (v11 == v12) {
            goto IL_004D;
        } else {
            goto IL_0039;
        }
        IL_0039: ;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = unchecked((int)(v13._version));
        int v15 = 2;
        if (v14 == v15) {
            goto IL_004D;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        string v16 = System.SR.get_XmlBinary_InvalidProtocolVersion();
        l0 = v16;
        goto IL_01E6;
        IL_004D: ;
        int v17 = 1200;
        global::System.Xml.XmlSqlBinaryReader v18 = this;
        int v19 = unchecked((int)(__cil_direct_060007CD(v18)));
        if (v17 == v19) {
            goto IL_0065;
        } else {
            goto IL_005A;
        }
        IL_005A: ;
        string v20 = System.SR.get_XmlBinary_UnsupportedCodePage();
        l0 = v20;
        goto IL_01E6;
        IL_0065: ;
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        int v22 = 0;
        v21._state = unchecked((__cil_enum_0200006C)(v22));
        int v23 = 254;
        global::System.Xml.XmlSqlBinaryReader v24 = this;
        int v25 = unchecked((int)(__cil_direct_060007D2(v24)));
        if (unchecked((uint)v23) != unchecked((uint)v25)) {
            goto IL_01DF;
        } else {
            goto IL_007C;
        }
        IL_007C: ;
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        global::System.Xml.XmlSqlBinaryReader v27 = this;
        int v28 = v27._pos;
        int v29 = 1;
        int v30 = unchecked(v28 + v29);
        v26._pos = v30;
        global::System.Xml.XmlSqlBinaryReader v31 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v32 = v31._attributes;
        int v33 = 0;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v34 = ref __cil_ldelema_0200006F(v32, v33);
        string v35 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlSqlBinaryReader v36 = this;
        global::System.Xml.XmlNameTable v37 = v36._xnt;
        string v38 = __cil_ldstr_7000D0CB("version");
        string v39 = __cil_callvirt_06000A35(v37, v38);
        string v40 = __cil_ldsfld_0A000002();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v41 = __cil_value_newobj_0600081F(v35, v39, v40);
        global::System.Xml.XmlSqlBinaryReader v42 = this;
        string v43 = __cil_direct_060007D9(v42);
        __cil_direct_0600082C(ref v34, v41, v43);
        global::System.Xml.XmlSqlBinaryReader v44 = this;
        int v45 = 1;
        v44._attrCount = v45;
        int v46 = 253;
        global::System.Xml.XmlSqlBinaryReader v47 = this;
        int v48 = unchecked((int)(__cil_direct_060007D2(v47)));
        if (unchecked((uint)v46) != unchecked((uint)v48)) {
            goto IL_0126;
        } else {
            goto IL_00D4;
        }
        IL_00D4: ;
        global::System.Xml.XmlSqlBinaryReader v49 = this;
        global::System.Xml.XmlSqlBinaryReader v50 = this;
        int v51 = v50._pos;
        int v52 = 1;
        int v53 = unchecked(v51 + v52);
        v49._pos = v53;
        global::System.Xml.XmlSqlBinaryReader v54 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v55 = v54._attributes;
        int v56 = 1;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v57 = ref __cil_ldelema_0200006F(v55, v56);
        string v58 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlSqlBinaryReader v59 = this;
        global::System.Xml.XmlNameTable v60 = v59._xnt;
        string v61 = __cil_ldstr_7000D0DB("encoding");
        string v62 = __cil_callvirt_06000A35(v60, v61);
        string v63 = __cil_ldsfld_0A000002();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v64 = __cil_value_newobj_0600081F(v58, v62, v63);
        global::System.Xml.XmlSqlBinaryReader v65 = this;
        string v66 = __cil_direct_060007D9(v65);
        __cil_direct_0600082C(ref v57, v64, v66);
        global::System.Xml.XmlSqlBinaryReader v67 = this;
        global::System.Xml.XmlSqlBinaryReader v68 = this;
        int v69 = v68._attrCount;
        int v70 = 1;
        int v71 = unchecked(v69 + v70);
        v67._attrCount = v71;
        goto IL_0126;
        IL_0126: ;
        global::System.Xml.XmlSqlBinaryReader v72 = this;
        int v73 = unchecked((int)(__cil_direct_060007CC(v72)));
        l2 = unchecked((byte)(v73));
        int v74 = unchecked((int)(l2));
        if (v74 == 0) {
            goto IL_0193;
        } else {
            goto IL_0130;
        }
        IL_0130: ;
        int v75 = unchecked((int)(l2));
        int v76 = 1;
        int v77 = unchecked(v75 - v76);
        int v78 = 1;
        if (unchecked((uint)v77) > unchecked((uint)v78)) {
            goto IL_018B;
        } else {
            goto IL_0136;
        }
        IL_0136: ;
        global::System.Xml.XmlSqlBinaryReader v79 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v80 = v79._attributes;
        global::System.Xml.XmlSqlBinaryReader v81 = this;
        int v82 = v81._attrCount;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v83 = ref __cil_ldelema_0200006F(v80, v82);
        string v84 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlSqlBinaryReader v85 = this;
        global::System.Xml.XmlNameTable v86 = v85._xnt;
        string v87 = __cil_ldstr_7000D0ED("standalone");
        string v88 = __cil_callvirt_06000A35(v86, v87);
        string v89 = __cil_ldsfld_0A000002();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v90 = __cil_value_newobj_0600081F(v84, v88, v89);
        int v91 = unchecked((int)(l2));
        int v92 = 1;
        if (v91 == v92) {
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c e13_15_0 = ref v83;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 e13_15_1 = v90;
            s15_0 = ref e13_15_0;
            s15_1 = e13_15_1;
            goto IL_0171;
        } else {
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c e13_14_0 = ref v83;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 e13_14_1 = v90;
            s14_0 = ref e13_14_0;
            s14_1 = e13_14_1;
            goto IL_016A;
        }
        IL_016A: ;
        string v93 = __cil_ldstr_7000D103("no");
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c e14_16_0 = ref s14_0;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 e14_16_1 = s14_1;
        string e14_16_2 = v93;
        s16_0 = ref e14_16_0;
        s16_1 = e14_16_1;
        s16_2 = e14_16_2;
        goto IL_0176;
        IL_0171: ;
        string v94 = __cil_ldstr_7000D109("yes");
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c e15_16_0 = ref s15_0;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 e15_16_1 = s15_1;
        string e15_16_2 = v94;
        s16_0 = ref e15_16_0;
        s16_1 = e15_16_1;
        s16_2 = e15_16_2;
        goto IL_0176;
        IL_0176: ;
        __cil_direct_0600082C(ref s16_0, s16_1, s16_2);
        global::System.Xml.XmlSqlBinaryReader v95 = this;
        global::System.Xml.XmlSqlBinaryReader v96 = this;
        int v97 = v96._attrCount;
        int v98 = 1;
        int v99 = unchecked(v97 + v98);
        v95._attrCount = v99;
        goto IL_0193;
        IL_018B: ;
        string v100 = System.SR.get_XmlBinary_InvalidStandalone();
        l0 = v100;
        goto IL_01E6;
        IL_0193: ;
        int v101 = __cil_bool_load(skipXmlDecl);
        if (v101 != 0) {
            goto IL_01DF;
        } else {
            goto IL_0196;
        }
        IL_0196: ;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v102 = ref l3;
        string v103 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlSqlBinaryReader v104 = this;
        global::System.Xml.XmlNameTable v105 = v104._xnt;
        string v106 = __cil_ldstr_700003A9("xml");
        string v107 = __cil_callvirt_06000A35(v105, v106);
        string v108 = __cil_ldsfld_0A000002();
        __cil_value_ctor_0600081F(ref v102, v103, v107, v108);
        global::System.Xml.XmlSqlBinaryReader v109 = this;
        global::System.Xml.XmlSqlBinaryReader v110 = this;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v111 = l3;
        l4 = v111;
        v110._qnameElement = v111;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v112 = l4;
        v109._qnameOther = v112;
        global::System.Xml.XmlSqlBinaryReader v113 = this;
        int v114 = 17;
        v113._nodetype = unchecked((__cil_enum_020000B5)(v114));
        global::System.Xml.XmlSqlBinaryReader v115 = this;
        global::System.Xml.XmlSqlBinaryReader v116 = this;
        int v117 = v116._pos;
        v115._posAfterAttrs = v117;
        int v118 = 1;
        return __cil_bool_store(v118);
        IL_01DF: ;
        global::System.Xml.XmlSqlBinaryReader v119 = this;
        int v120 = __cil_bool_load(__cil_direct_060007EF(v119));
        return __cil_bool_store(v120);
        IL_01E6: ;
        global::System.Xml.XmlSqlBinaryReader v121 = this;
        int v122 = 6;
        v121._state = unchecked((__cil_enum_0200006C)(v122));
        string v123 = l0;
        global::System.Xml.XmlException v124 = __cil_newobj_06000A0A(v123, null);
        throw v124;
    }

    private void ScanAttributes()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c bytes=1D1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200013A alias=__cil_enum_0200013A underlying=int: global::@System.@Xml.@XmlSpace; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        int l1 = default;
        int l2 = default;
        string l3 = default;
        bool l4 = default;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l5 = default;
        string l6 = default;
        string l7 = default;
        string l8 = default;
        __cil_enum_0200013A l9 = default;
        IL_0000: ;
        int v0 = -1;
        l1 = v0;
        int v1 = -1;
        l2 = v1;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        int v4 = v3._pos;
        v2._mark = v4;
        l3 = null;
        int v5 = 0;
        l4 = __cil_bool_store(v5);
        goto IL_01F3;
        IL_001A: ;
        int v6 = 246;
        int v7 = unchecked((int)(l0));
        if (unchecked((uint)v6) != unchecked((uint)v7)) {
            goto IL_0186;
        } else {
            goto IL_0025;
        }
        IL_0025: ;
        string v8 = l3;
        if (v8 is null) {
            goto IL_0037;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        string v10 = l3;
        string v11 = __cil_ldsfld_0A000002();
        int v12 = 0;
        __cil_direct_060007E4(v9, v10, v11, __cil_bool_store(v12));
        l3 = null;
        goto IL_0037;
        IL_0037: ;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = v13._attrCount;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v16 = v15._attributes;
        nint v17 = unchecked((nint)(v16.LongLength));
        int v18 = unchecked((int)(v17));
        if (unchecked((uint)v14) != unchecked((uint)v18)) {
            goto IL_004D;
        } else {
            goto IL_0047;
        }
        IL_0047: ;
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        __cil_direct_060007E2(v19);
        goto IL_004D;
        IL_004D: ;
        global::System.Xml.XmlSqlBinaryReader v20 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v21 = ref v20._symbolTables;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v22 = v21.qnametable;
        global::System.Xml.XmlSqlBinaryReader v23 = this;
        int v24 = __cil_direct_060007C7(v23);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v25 = __cil_ldelem_0200006D(v22, v24);
        l5 = v25;
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v27 = v26._attributes;
        global::System.Xml.XmlSqlBinaryReader v28 = this;
        int v29 = v28._attrCount;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v30 = ref __cil_ldelema_0200006F(v27, v29);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v31 = l5;
        global::System.Xml.XmlSqlBinaryReader v32 = this;
        int v33 = v32._pos;
        __cil_direct_0600082D(ref v30, v31, v33);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v34 = l5;
        string v35 = v34.prefix;
        string v36 = __cil_ldstr_700003A9("xml");
        int v37 = __cil_bool_load(System.String.op_Equality(v35, v36));
        if (v37 == 0) {
            goto IL_00D7;
        } else {
            goto IL_0096;
        }
        IL_0096: ;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v38 = l5;
        string v39 = v38.localname;
        string v40 = __cil_ldstr_70000235("lang");
        int v41 = __cil_bool_load(System.String.op_Equality(v39, v40));
        if (v41 == 0) {
            goto IL_00B5;
        } else {
            goto IL_00A9;
        }
        IL_00A9: ;
        global::System.Xml.XmlSqlBinaryReader v42 = this;
        int v43 = v42._attrCount;
        l2 = v43;
        goto IL_0173;
        IL_00B5: ;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v44 = l5;
        string v45 = v44.localname;
        string v46 = __cil_ldstr_7000D111("space");
        int v47 = __cil_bool_load(System.String.op_Equality(v45, v46));
        if (v47 == 0) {
            goto IL_0173;
        } else {
            goto IL_00CB;
        }
        IL_00CB: ;
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        int v49 = v48._attrCount;
        l1 = v49;
        goto IL_0173;
        IL_00D7: ;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v50 = l5;
        string v51 = v50.namespaceUri;
        global::System.Xml.XmlSqlBinaryReader v52 = this;
        string v53 = v52._nsxmlns;
        int v54 = __cil_bool_load(System.Xml.Ref.Equal(v51, v53));
        if (v54 == 0) {
            goto IL_0108;
        } else {
            goto IL_00EB;
        }
        IL_00EB: ;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v55 = l5;
        string v56 = v55.localname;
        l3 = v56;
        string v57 = l3;
        string v58 = __cil_ldstr_7000CEB5("xmlns");
        int v59 = __cil_bool_load(System.String.op_Equality(v57, v58));
        if (v59 == 0) {
            goto IL_0173;
        } else {
            goto IL_0100;
        }
        IL_0100: ;
        string v60 = __cil_ldsfld_0A000002();
        l3 = v60;
        goto IL_0173;
        IL_0108: ;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v61 = l5;
        string v62 = v61.prefix;
        int v63 = ((System.String)v62).Length;
        if (v63 == 0) {
            goto IL_014B;
        } else {
            goto IL_0116;
        }
        IL_0116: ;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v64 = l5;
        string v65 = v64.namespaceUri;
        int v66 = ((System.String)v65).Length;
        if (v66 != 0) {
            goto IL_0134;
        } else {
            goto IL_0124;
        }
        IL_0124: ;
        string v67 = System.SR.get_Xml_PrefixForEmptyNs();
        string v68 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlException v69 = __cil_newobj_06000A0B(v67, v68);
        throw v69;
        IL_0134: ;
        global::System.Xml.XmlSqlBinaryReader v70 = this;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v71 = l5;
        string v72 = v71.prefix;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v73 = l5;
        string v74 = v73.namespaceUri;
        int v75 = 1;
        __cil_direct_060007E4(v70, v72, v74, __cil_bool_store(v75));
        goto IL_0173;
        IL_014B: ;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v76 = l5;
        string v77 = v76.namespaceUri;
        int v78 = ((System.String)v77).Length;
        if (v78 == 0) {
            goto IL_0173;
        } else {
            goto IL_0159;
        }
        IL_0159: ;
        global::System.Xml.XmlSqlBinaryReader v79 = this;
        string v80 = System.SR.get_XmlBinary_AttrWithNsNoPrefix();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v81 = l5;
        string v82 = v81.localname;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v83 = l5;
        string v84 = v83.namespaceUri;
        global::System.Exception v85 = __cil_direct_0600081C(v79, v80, v82, v84);
        throw v85;
        IL_0173: ;
        global::System.Xml.XmlSqlBinaryReader v86 = this;
        global::System.Xml.XmlSqlBinaryReader v87 = this;
        int v88 = v87._attrCount;
        int v89 = 1;
        int v90 = unchecked(v88 + v89);
        v86._attrCount = v90;
        int v91 = 0;
        l4 = __cil_bool_store(v91);
        goto IL_01F3;
        IL_0186: ;
        global::System.Xml.XmlSqlBinaryReader v92 = this;
        int v93 = unchecked((int)(l0));
        int v94 = 1;
        int v95 = 1;
        int v96 = unchecked((int)(__cil_direct_06000800(v92, unchecked((__cil_enum_02000073)(v93)), __cil_bool_store(v94), __cil_bool_store(v95))));
        int v97 = __cil_bool_load(l4);
        if (v97 == 0) {
            goto IL_01A0;
        } else {
            goto IL_0194;
        }
        IL_0194: ;
        global::System.Xml.XmlSqlBinaryReader v98 = this;
        string v99 = System.SR.get_XmlBinary_ListsOfValuesNotSupported();
        global::System.Exception v100 = __cil_direct_0600081D(v98, v99);
        throw v100;
        IL_01A0: ;
        global::System.Xml.XmlSqlBinaryReader v101 = this;
        string v102 = v101._stringValue;
        l6 = v102;
        string v103 = l6;
        if (v103 is null) {
            goto IL_01CD;
        } else {
            goto IL_01AC;
        }
        IL_01AC: ;
        global::System.Xml.XmlSqlBinaryReader v104 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v105 = v104._attributes;
        global::System.Xml.XmlSqlBinaryReader v106 = this;
        int v107 = v106._attrCount;
        int v108 = 1;
        int v109 = unchecked(v107 - v108);
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v110 = ref __cil_ldelema_0200006F(v105, v109);
        string v111 = l6;
        v110.val = v111;
        global::System.Xml.XmlSqlBinaryReader v112 = this;
        v112._stringValue = null;
        goto IL_01CD;
        IL_01CD: ;
        string v113 = l3;
        if (v113 is null) {
            goto IL_01F0;
        } else {
            goto IL_01D0;
        }
        IL_01D0: ;
        global::System.Xml.XmlSqlBinaryReader v114 = this;
        global::System.Xml.XmlNameTable v115 = v114._xnt;
        global::System.Xml.XmlSqlBinaryReader v116 = this;
        int v117 = unchecked((int)(l0));
        string v118 = __cil_direct_0600080E(v116, unchecked((__cil_enum_02000073)(v117)));
        string v119 = __cil_callvirt_06000A35(v115, v118);
        l7 = v119;
        global::System.Xml.XmlSqlBinaryReader v120 = this;
        string v121 = l3;
        string v122 = l7;
        int v123 = 0;
        __cil_direct_060007E4(v120, v121, v122, __cil_bool_store(v123));
        l3 = null;
        goto IL_01F0;
        IL_01F0: ;
        int v124 = 1;
        l4 = __cil_bool_store(v124);
        goto IL_01F3;
        IL_01F3: ;
        int v125 = 245;
        global::System.Xml.XmlSqlBinaryReader v126 = this;
        int v127 = unchecked((int)(__cil_direct_060007D6(v126)));
        l0 = unchecked((__cil_enum_02000073)(v127));
        if (unchecked((uint)v125) != unchecked((uint)v127)) {
            goto IL_001A;
        } else {
            goto IL_0205;
        }
        IL_0205: ;
        int v128 = l1;
        int v129 = -1;
        if (v128 == v129) {
            goto IL_025C;
        } else {
            goto IL_0209;
        }
        IL_0209: ;
        global::System.Xml.XmlSqlBinaryReader v130 = this;
        int v131 = l1;
        string v132 = __cil_direct_060007DD(v130, v131);
        l8 = v132;
        int v133 = 0;
        l9 = unchecked((__cil_enum_0200013A)(v133));
        string v134 = l8;
        string v135 = __cil_ldstr_7000D11D("preserve");
        int v136 = __cil_bool_load(System.String.op_Equality(v134, v135));
        if (v136 == 0) {
            goto IL_0228;
        } else {
            goto IL_0223;
        }
        IL_0223: ;
        int v137 = 2;
        l9 = unchecked((__cil_enum_0200013A)(v137));
        goto IL_0239;
        IL_0228: ;
        string v138 = l8;
        string v139 = __cil_ldstr_70000909("default");
        int v140 = __cil_bool_load(System.String.op_Equality(v138, v139));
        if (v140 == 0) {
            goto IL_0239;
        } else {
            goto IL_0236;
        }
        IL_0236: ;
        int v141 = 1;
        l9 = unchecked((__cil_enum_0200013A)(v141));
        goto IL_0239;
        IL_0239: ;
        global::System.Xml.XmlSqlBinaryReader v142 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v143 = v142._elementStack;
        global::System.Xml.XmlSqlBinaryReader v144 = this;
        int v145 = v144._elemDepth;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v146 = ref __cil_ldelema_0200006E(v143, v145);
        int v147 = unchecked((int)(l9));
        v146.xmlSpace = unchecked((__cil_enum_0200013A)(v147));
        global::System.Xml.XmlSqlBinaryReader v148 = this;
        int v149 = 2;
        int v150 = unchecked((int)(l9));
        int v151 = (v149 == v150 ? 1 : 0);
        v148._xmlspacePreserve = __cil_bool_store(v151);
        goto IL_025C;
        IL_025C: ;
        int v152 = l2;
        int v153 = -1;
        if (v152 == v153) {
            goto IL_027D;
        } else {
            goto IL_0260;
        }
        IL_0260: ;
        global::System.Xml.XmlSqlBinaryReader v154 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v155 = v154._elementStack;
        global::System.Xml.XmlSqlBinaryReader v156 = this;
        int v157 = v156._elemDepth;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v158 = ref __cil_ldelema_0200006E(v155, v157);
        global::System.Xml.XmlSqlBinaryReader v159 = this;
        int v160 = l2;
        string v161 = __cil_direct_060007DD(v159, v160);
        v158.xmlLang = v161;
        goto IL_027D;
        IL_027D: ;
        global::System.Xml.XmlSqlBinaryReader v162 = this;
        int v163 = v162._attrCount;
        int v164 = 200;
        if (v163 >= v164) {
            goto IL_0291;
        } else {
            goto IL_028A;
        }
        IL_028A: ;
        global::System.Xml.XmlSqlBinaryReader v165 = this;
        __cil_direct_060007E9(v165);
        return;
        IL_0291: ;
        global::System.Xml.XmlSqlBinaryReader v166 = this;
        __cil_direct_060007EA(v166);
        return;
    }

    private void SimpleCheckForDuplicateAttributes()
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        string l1 = default;
        string l2 = default;
        int l3 = default;
        IL_0000: ;
        int v0 = 0;
        l0 = v0;
        goto IL_006C;
        IL_0004: ;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v2 = v1._attributes;
        int v3 = l0;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v4 = ref __cil_ldelema_0200006F(v2, v3);
        ref string v5 = ref l1;
        ref string v6 = ref l2;
        __cil_direct_0600082E(ref v4, ref v5, ref v6);
        int v7 = l0;
        int v8 = 1;
        int v9 = unchecked(v7 + v8);
        l3 = v9;
        goto IL_005F;
        IL_001F: ;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v11 = v10._attributes;
        int v12 = l3;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v13 = ref __cil_ldelema_0200006F(v11, v12);
        string v14 = l1;
        string v15 = l2;
        int v16 = __cil_bool_load(__cil_direct_06000830(ref v13, v14, v15));
        if (v16 == 0) {
            goto IL_005B;
        } else {
            goto IL_0034;
        }
        IL_0034: ;
        string v17 = System.SR.get_Xml_DupAttributeName();
        global::System.Xml.XmlSqlBinaryReader v18 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v19 = v18._attributes;
        int v20 = l0;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v21 = ref __cil_ldelema_0200006F(v19, v20);
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v22 = ref v21.name;
        string v23 = __cil_constrained_0200006D_0A000009(ref v22);
        global::System.Xml.XmlException v24 = __cil_newobj_06000A0B(v17, v23);
        throw v24;
        IL_005B: ;
        int v25 = l3;
        int v26 = 1;
        int v27 = unchecked(v25 + v26);
        l3 = v27;
        goto IL_005F;
        IL_005F: ;
        int v28 = l3;
        global::System.Xml.XmlSqlBinaryReader v29 = this;
        int v30 = v29._attrCount;
        if (v28 < v30) {
            goto IL_001F;
        } else {
            goto IL_0068;
        }
        IL_0068: ;
        int v31 = l0;
        int v32 = 1;
        int v33 = unchecked(v31 + v32);
        l0 = v33;
        goto IL_006C;
        IL_006C: ;
        int v34 = l0;
        global::System.Xml.XmlSqlBinaryReader v35 = this;
        int v36 = v35._attrCount;
        if (v34 < v36) {
            goto IL_0004;
        } else {
            goto IL_0075;
        }
        IL_0075: ;
        return;
    }

    private void HashCheckForDuplicateAttributes()
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        int l1 = default;
        string l2 = default;
        string l3 = default;
        int l4 = default;
        int l5 = default;
        int l6 = default;
        IL_0000: ;
        int v0 = 256;
        l0 = v0;
        goto IL_000C;
        IL_0008: ;
        int v1 = l0;
        int v2 = 2;
        int v3 = checked(v1 * v2);
        l0 = v3;
        goto IL_000C;
        IL_000C: ;
        int v4 = l0;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        int v6 = v5._attrCount;
        if (v4 < v6) {
            goto IL_0008;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        int[] v8 = v7._attrHashTbl;
        nint v9 = unchecked((nint)(v8.LongLength));
        int v10 = unchecked((int)(v9));
        int v11 = l0;
        if (v10 >= v11) {
            goto IL_002C;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        int v13 = l0;
        int[] v14 = new int[v13];
        v12._attrHashTbl = v14;
        goto IL_002C;
        IL_002C: ;
        int v15 = 0;
        l1 = v15;
        goto IL_00E5;
        IL_0033: ;
        global::System.Xml.XmlSqlBinaryReader v16 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v17 = v16._attributes;
        int v18 = l1;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v19 = ref __cil_ldelema_0200006F(v17, v18);
        global::System.Xml.XmlSqlBinaryReader v20 = this;
        global::System.Xml.SecureStringHasher v21 = v20._hasher;
        ref string v22 = ref l2;
        ref string v23 = ref l3;
        int v24 = __cil_direct_0600082F(ref v19, v21, ref v22, ref v23);
        l4 = v24;
        int v25 = l4;
        int v26 = l0;
        int v27 = 1;
        int v28 = unchecked(v26 - v27);
        int v29 = unchecked(v25 & v28);
        l5 = v29;
        global::System.Xml.XmlSqlBinaryReader v30 = this;
        int[] v31 = v30._attrHashTbl;
        int v32 = l5;
        int v33 = v31[v32];
        l6 = v33;
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        int[] v35 = v34._attrHashTbl;
        int v36 = l5;
        int v37 = l1;
        int v38 = 1;
        int v39 = unchecked(v37 + v38);
        v35[v36] = v39;
        global::System.Xml.XmlSqlBinaryReader v40 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v41 = v40._attributes;
        int v42 = l1;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v43 = ref __cil_ldelema_0200006F(v41, v42);
        int v44 = l6;
        v43.prevHash = v44;
        goto IL_00DD;
        IL_0084: ;
        int v45 = l6;
        int v46 = 1;
        int v47 = unchecked(v45 - v46);
        l6 = v47;
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v49 = v48._attributes;
        int v50 = l6;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v51 = ref __cil_ldelema_0200006F(v49, v50);
        int v52 = l4;
        string v53 = l2;
        string v54 = l3;
        int v55 = __cil_bool_load(__cil_direct_06000831(ref v51, v52, v53, v54));
        if (v55 == 0) {
            goto IL_00C9;
        } else {
            goto IL_00A2;
        }
        IL_00A2: ;
        string v56 = System.SR.get_Xml_DupAttributeName();
        global::System.Xml.XmlSqlBinaryReader v57 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v58 = v57._attributes;
        int v59 = l1;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v60 = ref __cil_ldelema_0200006F(v58, v59);
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v61 = ref v60.name;
        string v62 = __cil_constrained_0200006D_0A000009(ref v61);
        global::System.Xml.XmlException v63 = __cil_newobj_06000A0B(v56, v62);
        throw v63;
        IL_00C9: ;
        global::System.Xml.XmlSqlBinaryReader v64 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v65 = v64._attributes;
        int v66 = l6;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v67 = ref __cil_ldelema_0200006F(v65, v66);
        int v68 = v67.prevHash;
        l6 = v68;
        goto IL_00DD;
        IL_00DD: ;
        int v69 = l6;
        if (v69 != 0) {
            goto IL_0084;
        } else {
            goto IL_00E1;
        }
        IL_00E1: ;
        int v70 = l1;
        int v71 = 1;
        int v72 = unchecked(v70 + v71);
        l1 = v72;
        goto IL_00E5;
        IL_00E5: ;
        int v73 = l1;
        global::System.Xml.XmlSqlBinaryReader v74 = this;
        int v75 = v74._attrCount;
        if (v73 < v75) {
            goto IL_0033;
        } else {
            goto IL_00F1;
        }
        IL_00F1: ;
        global::System.Xml.XmlSqlBinaryReader v76 = this;
        int[] v77 = v76._attrHashTbl;
        int v78 = 0;
        int v79 = l0;
        System.Array.Clear(((__cil_type_01000022)(v77)), v78, v79);
        return;
    }

    private string XmlDeclValue()
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_type_0100002E l0 = default;
        int l1 = default;
        IL_0000: ;
        __cil_type_0100002E v0 = __cil_newobj_0A000053();
        l0 = v0;
        int v1 = 0;
        l1 = v1;
        goto IL_0065;
        IL_000A: ;
        int v2 = l1;
        int v3 = 0;
        if (v2 <= v3) {
            goto IL_0017;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        __cil_type_0100002E v4 = l0;
        int v5 = 32;
        __cil_type_0100002E v6 = v4.Append(unchecked((char)(v5)));
        goto IL_0017;
        IL_0017: ;
        __cil_type_0100002E v7 = l0;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v9 = v8._attributes;
        int v10 = l1;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v11 = ref __cil_ldelema_0200006F(v9, v10);
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v12 = ref v11.name;
        string v13 = v12.localname;
        __cil_type_0100002E v14 = v7.Append(v13);
        __cil_type_0100002E v15 = l0;
        string v16 = __cil_ldstr_7000D12F("=\"");
        __cil_type_0100002E v17 = v15.Append(v16);
        __cil_type_0100002E v18 = l0;
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v20 = v19._attributes;
        int v21 = l1;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v22 = ref __cil_ldelema_0200006F(v20, v21);
        string v23 = v22.val;
        __cil_type_0100002E v24 = v18.Append(v23);
        __cil_type_0100002E v25 = l0;
        int v26 = 34;
        __cil_type_0100002E v27 = v25.Append(unchecked((char)(v26)));
        int v28 = l1;
        int v29 = 1;
        int v30 = unchecked(v28 + v29);
        l1 = v30;
        goto IL_0065;
        IL_0065: ;
        int v31 = l1;
        global::System.Xml.XmlSqlBinaryReader v32 = this;
        int v33 = v32._attrCount;
        if (v31 < v33) {
            goto IL_000A;
        } else {
            goto IL_006E;
        }
        IL_006E: ;
        __cil_type_0100002E v34 = l0;
        string v35 = v34.ToString();
        return v35;
    }

    private string CDATAValue()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        __cil_type_0100002E l1 = default;
        int v2 = this._tokDataPos;
        int v4 = this._tokLen;
        string v5 = __cil_direct_060007DB(this, v2, v4);
        l0 = v5;
        l1 = null;
        goto IL_0052;
        IL_0017: ;
        int v8 = this._pos;
        this._pos = unchecked(v8 + 1);
        __cil_type_0100002E v11 = l1;
        if (v11 is not null) {
            goto IL_0045;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        string v12 = l0;
        int v13 = ((System.String)v12).Length;
        string v14 = l0;
        int v15 = ((System.String)v14).Length;
        int v17 = unchecked(v15 / 2);
        int v18 = unchecked(v13 + v17);
        __cil_type_0100002E v19 = __cil_newobj_0A0000B3(v18);
        l1 = v19;
        __cil_type_0100002E v20 = l1;
        string v21 = l0;
        __cil_type_0100002E v22 = v20.Append(v21);
        IL_0045: ;
        __cil_type_0100002E v23 = l1;
        string v25 = __cil_direct_060007D9(this);
        __cil_type_0100002E v26 = v23.Append(v25);
        IL_0052: ;
        int v28 = unchecked((int)(__cil_direct_060007D2(this)));
        if (v28 == 242) {
            goto IL_0017;
        } else {
            goto IL_005F;
        }
        IL_005F: ;
        __cil_type_0100002E v30 = l1;
        if (v30 is null) {
            goto IL_0069;
        } else {
            goto IL_0062;
        }
        IL_0062: ;
        __cil_type_0100002E v31 = l1;
        string v32 = v31.ToString();
        l0 = v32;
        IL_0069: ;
        string v34 = l0;
        this._stringValue = v34;
        string v35 = l0;
        return v35;
    }

    private void FinishCDATA()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        int l1 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = unchecked((int)(__cil_direct_060007D2(v0)));
        l0 = unchecked((__cil_enum_02000073)(v1));
        int v2 = unchecked((int)(l0));
        int v3 = 241;
        if (v2 == v3) {
            goto IL_0030;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        int v4 = unchecked((int)(l0));
        int v5 = 242;
        if (unchecked((uint)v4) != unchecked((uint)v5)) {
            goto IL_003F;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        int v8 = v7._pos;
        int v9 = 1;
        int v10 = unchecked(v8 + v9);
        v6._pos = v10;
        global::System.Xml.XmlSqlBinaryReader v11 = this;
        ref int v12 = ref l1;
        int v13 = __cil_direct_060007DA(v11, ref v12);
        goto IL_0000;
        IL_0030: ;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        int v16 = v15._pos;
        int v17 = 1;
        int v18 = unchecked(v16 + v17);
        v14._pos = v18;
        return;
        IL_003F: ;
        string v19 = System.SR.get_XmlBin_MissingEndCDATA();
        global::System.Xml.XmlException v20 = __cil_newobj_06000A06(v19);
        throw v20;
    }

    private void FinishEndElement()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v1 = v0._elementStack;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        int v3 = v2._elemDepth;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v4 = ref __cil_ldelema_0200006E(v1, v3);
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v5 = __cil_direct_0600082B(ref v4);
        l0 = v5;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v7 = l0;
        __cil_direct_060007E5(v6, v7);
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        int v10 = v9._elemDepth;
        int v11 = 1;
        int v12 = unchecked(v10 - v11);
        v8._elemDepth = v12;
        return;
    }

    private bool ReadDoc()
    {
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000BF alias=__cil_enum_020000BF underlying=int: global::@System.@Xml.@DtdProcessing; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        __cil_enum_02000073 l1 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = unchecked((int)(v0._nodetype));
        l0 = unchecked((__cil_enum_020000B5)(v1));
        int v2 = unchecked((int)(l0));
        int v3 = 1;
        if (v2 == v3) {
            goto IL_0026;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        int v4 = unchecked((int)(l0));
        int v5 = 4;
        if (v4 == v5) {
            goto IL_0016;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        int v6 = unchecked((int)(l0));
        int v7 = 15;
        if (v6 == v7) {
            goto IL_001E;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        goto IL_003B;
        IL_0016: ;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        __cil_direct_060007ED(v8);
        goto IL_003B;
        IL_001E: ;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        __cil_direct_060007EE(v9);
        goto IL_003B;
        IL_0026: ;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        int v11 = __cil_bool_load(v10._isEmpty);
        if (v11 == 0) {
            goto IL_003B;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        __cil_direct_060007EE(v12);
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = 0;
        v13._isEmpty = __cil_bool_store(v14);
        goto IL_003B;
        IL_003B: ;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        int v16 = 0;
        v15._nodetype = unchecked((__cil_enum_020000B5)(v16));
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        int v18 = -1;
        v17._mark = v18;
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v20 = ref v19._qnameOther;
        string v21 = v20.localname;
        int v22 = ((System.String)v21).Length;
        if (v22 == 0) {
            goto IL_0066;
        } else {
            goto IL_005B;
        }
        IL_005B: ;
        global::System.Xml.XmlSqlBinaryReader v23 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v24 = ref v23._qnameOther;
        __cil_direct_06000821(ref v24);
        goto IL_0066;
        IL_0066: ;
        global::System.Xml.XmlSqlBinaryReader v25 = this;
        __cil_direct_060007E3(v25);
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        int v27 = 0;
        v26._attrCount = v27;
        global::System.Xml.XmlSqlBinaryReader v28 = this;
        __cil_type_01000004 v29 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v28._valueType = v29;
        global::System.Xml.XmlSqlBinaryReader v30 = this;
        v30._stringValue = null;
        global::System.Xml.XmlSqlBinaryReader v31 = this;
        int v32 = 0;
        v31._hasTypedValue = __cil_bool_store(v32);
        global::System.Xml.XmlSqlBinaryReader v33 = this;
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        int v35 = unchecked((int)(__cil_direct_060007D6(v34)));
        v33._token = unchecked((__cil_enum_02000073)(v35));
        global::System.Xml.XmlSqlBinaryReader v36 = this;
        int v37 = unchecked((int)(v36._token));
        l1 = unchecked((__cil_enum_02000073)(v37));
        int v38 = unchecked((int)(l1));
        int v39 = 127;
        if (v38 > v39) {
            goto IL_0132;
        } else {
            goto IL_00A7;
        }
        IL_00A7: ;
        int v40 = unchecked((int)(l1));
        int v41 = -1;
        int v42 = unchecked(v40 - v41);
        switch (v42) {
            case 0: {
                goto IL_0191;
            }
            case 1: {
                goto IL_027C;
            }
            case 2: {
                goto IL_024A;
            }
            case 3: {
                goto IL_024A;
            }
            case 4: {
                goto IL_024A;
            }
            case 5: {
                goto IL_024A;
            }
            case 6: {
                goto IL_024A;
            }
            case 7: {
                goto IL_024A;
            }
            case 8: {
                goto IL_024A;
            }
            case 9: {
                goto IL_024A;
            }
            case 10: {
                goto IL_024A;
            }
            case 11: {
                goto IL_024A;
            }
            case 12: {
                goto IL_024A;
            }
            case 13: {
                goto IL_024A;
            }
            case 14: {
                goto IL_024A;
            }
            case 15: {
                goto IL_024A;
            }
            case 16: {
                goto IL_024A;
            }
            case 17: {
                goto IL_024A;
            }
            case 18: {
                goto IL_024A;
            }
            case 19: {
                goto IL_024A;
            }
            case 20: {
                goto IL_024A;
            }
            case 21: {
                goto IL_024A;
            }
            case 22: {
                goto IL_027C;
            }
            case 23: {
                goto IL_024A;
            }
            case 24: {
                goto IL_024A;
            }
            case 25: {
                goto IL_024A;
            }
            case 26: {
                goto IL_027C;
            }
            case 27: {
                goto IL_027C;
            }
            case 28: {
                goto IL_024A;
            }
            default: {
                goto IL_0123;
            } }
        IL_0123: ;
        int v43 = unchecked((int)(l1));
        int v44 = 122;
        int v45 = unchecked(v43 - v44);
        int v46 = 5;
        if (unchecked((uint)v45) <= unchecked((uint)v46)) {
            goto IL_024A;
        } else {
            goto IL_012D;
        }
        IL_012D: ;
        goto IL_027C;
        IL_0132: ;
        int v47 = unchecked((int)(l1));
        int v48 = 129;
        int v49 = unchecked(v47 - v48);
        int v50 = 11;
        if (unchecked((uint)v49) <= unchecked((uint)v50)) {
            goto IL_024A;
        } else {
            goto IL_0140;
        }
        IL_0140: ;
        int v51 = unchecked((int)(l1));
        int v52 = 235;
        int v53 = unchecked(v51 - v52);
        switch (v53) {
            case 0: {
                goto IL_022D;
            }
            case 1: {
                goto IL_0218;
            }
            case 2: {
                goto IL_0242;
            }
            case 3: {
                goto IL_027C;
            }
            case 4: {
                goto IL_027C;
            }
            case 5: {
                goto IL_027C;
            }
            case 6: {
                goto IL_027C;
            }
            case 7: {
                goto IL_0210;
            }
            case 8: {
                goto IL_01FD;
            }
            case 9: {
                goto IL_01E7;
            }
            case 10: {
                goto IL_027C;
            }
            case 11: {
                goto IL_027C;
            }
            case 12: {
                goto IL_01BA;
            }
            case 13: {
                goto IL_01AF;
            }
            default: {
                goto IL_0184;
            } }
        IL_0184: ;
        int v54 = unchecked((int)(l1));
        int v55 = 252;
        if (v54 == v55) {
            goto IL_01C5;
        } else {
            goto IL_018C;
        }
        IL_018C: ;
        goto IL_027C;
        IL_0191: ;
        global::System.Xml.XmlSqlBinaryReader v56 = this;
        int v57 = v56._elemDepth;
        int v58 = 0;
        if (v57 <= v58) {
            goto IL_01A6;
        } else {
            goto IL_019A;
        }
        IL_019A: ;
        string v59 = System.SR.get_Xml_UnexpectedEOF1();
        global::System.Xml.XmlException v60 = __cil_newobj_06000A0A(v59, null);
        throw v60;
        IL_01A6: ;
        global::System.Xml.XmlSqlBinaryReader v61 = this;
        int v62 = 7;
        v61._state = unchecked((__cil_enum_0200006C)(v62));
        int v63 = 0;
        return __cil_bool_store(v63);
        IL_01AF: ;
        global::System.Xml.XmlSqlBinaryReader v64 = this;
        __cil_direct_060007F1(v64);
        goto IL_0289;
        IL_01BA: ;
        global::System.Xml.XmlSqlBinaryReader v65 = this;
        __cil_direct_060007F2(v65);
        goto IL_0289;
        IL_01C5: ;
        global::System.Xml.XmlSqlBinaryReader v66 = this;
        __cil_direct_060007F3(v66);
        global::System.Xml.XmlSqlBinaryReader v67 = this;
        int v68 = unchecked((int)(v67._dtdProcessing));
        int v69 = 1;
        if (v68 == v69) {
            goto IL_003B;
        } else {
            goto IL_01D7;
        }
        IL_01D7: ;
        global::System.Xml.XmlSqlBinaryReader v70 = this;
        global::System.Xml.XmlSqlBinaryReader.NestedBinXml v71 = v70._prevNameInfo;
        if (v71 is null) {
            goto IL_0289;
        } else {
            goto IL_01E2;
        }
        IL_01E2: ;
        goto IL_003B;
        IL_01E7: ;
        global::System.Xml.XmlSqlBinaryReader v72 = this;
        __cil_direct_060007F4(v72);
        global::System.Xml.XmlSqlBinaryReader v73 = this;
        int v74 = __cil_bool_load(v73._ignorePIs);
        if (v74 == 0) {
            goto IL_0289;
        } else {
            goto IL_01F8;
        }
        IL_01F8: ;
        goto IL_003B;
        IL_01FD: ;
        global::System.Xml.XmlSqlBinaryReader v75 = this;
        __cil_direct_060007F5(v75);
        global::System.Xml.XmlSqlBinaryReader v76 = this;
        int v77 = __cil_bool_load(v76._ignoreComments);
        if (v77 == 0) {
            goto IL_0289;
        } else {
            goto IL_020B;
        }
        IL_020B: ;
        goto IL_003B;
        IL_0210: ;
        global::System.Xml.XmlSqlBinaryReader v78 = this;
        __cil_direct_060007F6(v78);
        goto IL_0289;
        IL_0218: ;
        global::System.Xml.XmlSqlBinaryReader v79 = this;
        __cil_direct_060007F7(v79);
        global::System.Xml.XmlSqlBinaryReader v80 = this;
        int v81 = 0;
        v80._sniffed = __cil_bool_store(v81);
        global::System.Xml.XmlSqlBinaryReader v82 = this;
        int v83 = 1;
        int v84 = __cil_bool_load(__cil_direct_060007E7(v82, __cil_bool_store(v83)));
        return __cil_bool_store(v84);
        IL_022D: ;
        global::System.Xml.XmlSqlBinaryReader v85 = this;
        global::System.Xml.XmlSqlBinaryReader.NestedBinXml v86 = v85._prevNameInfo;
        if (v86 is null) {
            goto IL_027C;
        } else {
            goto IL_0235;
        }
        IL_0235: ;
        global::System.Xml.XmlSqlBinaryReader v87 = this;
        __cil_direct_060007F8(v87);
        global::System.Xml.XmlSqlBinaryReader v88 = this;
        int v89 = __cil_bool_load(__cil_direct_060007EF(v88));
        return __cil_bool_store(v89);
        IL_0242: ;
        global::System.Xml.XmlSqlBinaryReader v90 = this;
        __cil_direct_060007F9(v90);
        goto IL_0289;
        IL_024A: ;
        global::System.Xml.XmlSqlBinaryReader v91 = this;
        global::System.Xml.XmlSqlBinaryReader v92 = this;
        int v93 = unchecked((int)(v92._token));
        __cil_direct_060007F0(v91, unchecked((__cil_enum_02000073)(v93)));
        int v94 = 3;
        global::System.Xml.XmlSqlBinaryReader v95 = this;
        int v96 = unchecked((int)(v95._nodetype));
        if (unchecked((uint)v94) != unchecked((uint)v96)) {
            goto IL_0267;
        } else {
            goto IL_025F;
        }
        IL_025F: ;
        global::System.Xml.XmlSqlBinaryReader v97 = this;
        __cil_direct_060007FC(v97);
        goto IL_027A;
        IL_0267: ;
        global::System.Xml.XmlSqlBinaryReader v98 = this;
        int v99 = __cil_bool_load(v98._ignoreWhitespace);
        if (v99 == 0) {
            goto IL_027A;
        } else {
            goto IL_026F;
        }
        IL_026F: ;
        global::System.Xml.XmlSqlBinaryReader v100 = this;
        int v101 = __cil_bool_load(v100._xmlspacePreserve);
        if (v101 == 0) {
            goto IL_003B;
        } else {
            goto IL_027A;
        }
        IL_027A: ;
        int v102 = 1;
        return __cil_bool_store(v102);
        IL_027C: ;
        global::System.Xml.XmlSqlBinaryReader v103 = this;
        global::System.Xml.XmlSqlBinaryReader v104 = this;
        int v105 = unchecked((int)(v104._token));
        global::System.Exception v106 = __cil_direct_0600081A(v103, unchecked((__cil_enum_02000073)(v105)));
        throw v106;
        IL_0289: ;
        int v107 = 1;
        return __cil_bool_store(v107);
    }

    private void ImplReadData(System.Xml.BinXmlToken tokenType)
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        int v2 = this._pos;
        this._mark = v2;
        int v3 = unchecked((int)(tokenType));
        if (v3 > 17) {
            goto IL_0021;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        int v5 = unchecked((int)(tokenType));
        int v7 = unchecked(v5 - 13);
        if (unchecked((uint)v7) <= unchecked((uint)1)) {
            goto IL_002B;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        int v9 = unchecked((int)(tokenType));
        int v11 = unchecked(v9 - 16);
        if (unchecked((uint)v11) <= unchecked((uint)1)) {
            goto IL_002B;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        goto IL_003F;
        IL_0021: ;
        int v13 = unchecked((int)(tokenType));
        if (v13 == 22) {
            goto IL_002B;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        int v15 = unchecked((int)(tokenType));
        if (unchecked((uint)v15) != unchecked((uint)24)) {
            goto IL_003F;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        __cil_type_01000004 v18 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        this._valueType = v18;
        this._hasTypedValue = __cil_bool_store(0);
        goto IL_0058;
        IL_003F: ;
        int v24 = unchecked((int)(this._token));
        __cil_type_01000004 v25 = __cil_direct_060007FE(this, unchecked((__cil_enum_02000073)(v24)));
        this._valueType = v25;
        this._hasTypedValue = __cil_bool_store(1);
        IL_0058: ;
        int v31 = unchecked((int)(this._token));
        int v34 = unchecked((int)(__cil_direct_06000800(this, unchecked((__cil_enum_02000073)(v31)), __cil_bool_store(0), __cil_bool_store(1))));
        this._nodetype = unchecked((__cil_enum_020000B5)(v34));
        int v36 = unchecked((int)(__cil_direct_060007D7(this)));
        l0 = unchecked((__cil_enum_02000073)(v36));
        int v37 = unchecked((int)(l0));
        int v39 = unchecked(v37 - 1);
        switch (v39) {
            case 0: {
                goto IL_00F9;
            }
            case 1: {
                goto IL_00F9;
            }
            case 2: {
                goto IL_00F9;
            }
            case 3: {
                goto IL_00F9;
            }
            case 4: {
                goto IL_00F9;
            }
            case 5: {
                goto IL_00F9;
            }
            case 6: {
                goto IL_00F9;
            }
            case 7: {
                goto IL_00F9;
            }
            case 8: {
                goto IL_00F9;
            }
            case 9: {
                goto IL_00F9;
            }
            case 10: {
                goto IL_00F9;
            }
            case 11: {
                goto IL_00F9;
            }
            case 12: {
                goto IL_00F9;
            }
            case 13: {
                goto IL_00F9;
            }
            case 14: {
                goto IL_00F9;
            }
            case 15: {
                goto IL_00F9;
            }
            case 16: {
                goto IL_00F9;
            }
            case 17: {
                goto IL_00F9;
            }
            case 18: {
                goto IL_00F9;
            }
            case 19: {
                goto IL_00F9;
            }
            case 20: {
                goto IL_0105;
            }
            case 21: {
                goto IL_00F9;
            }
            case 22: {
                goto IL_00F9;
            }
            case 23: {
                goto IL_00F9;
            }
            case 24: {
                goto IL_0105;
            }
            case 25: {
                goto IL_0105;
            }
            case 26: {
                goto IL_00F9;
            }
            default: {
                goto IL_00E7;
            } }
        IL_00E7: ;
        int v40 = unchecked((int)(l0));
        int v42 = unchecked(v40 - 122);
        if (unchecked((uint)v42) <= unchecked((uint)5)) {
            goto IL_00F9;
        } else {
            goto IL_00EE;
        }
        IL_00EE: ;
        int v44 = unchecked((int)(l0));
        int v46 = unchecked(v44 - 129);
        if (unchecked((uint)v46) > unchecked((uint)11)) {
            goto IL_0105;
        } else {
            goto IL_00F9;
        }
        IL_00F9: ;
        string v49 = System.SR.get_XmlBinary_ListsOfValuesNotSupported();
        global::System.Exception v50 = __cil_direct_0600081D(this, v49);
        throw v50;
        IL_0105: ;
        return;
    }

    private void ImplReadElement()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c bytes=1D1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l0 = default;
        __cil_enum_02000073 l1 = default;
        int l2 = default;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l3 = default;
        IL_0000: ;
        int v0 = 3;
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = v1._docState;
        if (unchecked((uint)v0) != unchecked((uint)v2)) {
            goto IL_0013;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        int v3 = 9;
        global::System.Xml.XmlSqlBinaryReader v4 = this;
        int v5 = v4._docState;
        if (v3 == v5) {
            goto IL_0054;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        int v7 = v6._docState;
        l2 = v7;
        int v8 = l2;
        int v9 = -1;
        int v10 = unchecked(v8 - v9);
        switch (v10) {
            case 0: {
                goto IL_0047;
            }
            case 1: {
                goto IL_0034;
            }
            case 2: {
                goto IL_003E;
            }
            case 3: {
                goto IL_003E;
            }
            default: {
                goto IL_0032;
            } }
        IL_0032: ;
        goto IL_0054;
        IL_0034: ;
        global::System.Xml.XmlSqlBinaryReader v11 = this;
        int v12 = 9;
        v11._docState = v12;
        goto IL_0054;
        IL_003E: ;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = 3;
        v13._docState = v14;
        goto IL_0054;
        IL_0047: ;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        global::System.Xml.XmlSqlBinaryReader v16 = this;
        int v17 = unchecked((int)(v16._token));
        global::System.Exception v18 = __cil_direct_0600081A(v15, unchecked((__cil_enum_02000073)(v17)));
        throw v18;
        IL_0054: ;
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        global::System.Xml.XmlSqlBinaryReader v20 = this;
        int v21 = v20._elemDepth;
        int v22 = 1;
        int v23 = unchecked(v21 + v22);
        v19._elemDepth = v23;
        global::System.Xml.XmlSqlBinaryReader v24 = this;
        int v25 = v24._elemDepth;
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v27 = v26._elementStack;
        nint v28 = unchecked((nint)(v27.LongLength));
        int v29 = unchecked((int)(v28));
        if (unchecked((uint)v25) != unchecked((uint)v29)) {
            goto IL_0078;
        } else {
            goto IL_0072;
        }
        IL_0072: ;
        global::System.Xml.XmlSqlBinaryReader v30 = this;
        __cil_direct_060007E1(v30);
        goto IL_0078;
        IL_0078: ;
        global::System.Xml.XmlSqlBinaryReader v31 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v32 = ref v31._symbolTables;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v33 = v32.qnametable;
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        int v35 = __cil_direct_060007C7(v34);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v36 = __cil_ldelem_0200006D(v33, v35);
        l0 = v36;
        global::System.Xml.XmlSqlBinaryReader v37 = this;
        global::System.Xml.XmlSqlBinaryReader v38 = this;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v39 = l0;
        l3 = v39;
        v38._qnameElement = v39;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v40 = l3;
        v37._qnameOther = v40;
        global::System.Xml.XmlSqlBinaryReader v41 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v42 = v41._elementStack;
        global::System.Xml.XmlSqlBinaryReader v43 = this;
        int v44 = v43._elemDepth;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v45 = ref __cil_ldelema_0200006E(v42, v44);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v46 = l0;
        global::System.Xml.XmlSqlBinaryReader v47 = this;
        int v48 = __cil_bool_load(v47._xmlspacePreserve);
        __cil_direct_0600082A(ref v45, v46, __cil_bool_store(v48));
        global::System.Xml.XmlSqlBinaryReader v49 = this;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v50 = l0;
        string v51 = v50.prefix;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v52 = l0;
        string v53 = v52.namespaceUri;
        int v54 = 1;
        __cil_direct_060007E4(v49, v51, v53, __cil_bool_store(v54));
        global::System.Xml.XmlSqlBinaryReader v55 = this;
        int v56 = unchecked((int)(__cil_direct_060007D7(v55)));
        l1 = unchecked((__cil_enum_02000073)(v56));
        int v57 = 246;
        int v58 = unchecked((int)(l1));
        if (unchecked((uint)v57) != unchecked((uint)v58)) {
            goto IL_00EB;
        } else {
            goto IL_00DE;
        }
        IL_00DE: ;
        global::System.Xml.XmlSqlBinaryReader v59 = this;
        __cil_direct_060007E8(v59);
        global::System.Xml.XmlSqlBinaryReader v60 = this;
        int v61 = unchecked((int)(__cil_direct_060007D7(v60)));
        l1 = unchecked((__cil_enum_02000073)(v61));
        goto IL_00EB;
        IL_00EB: ;
        global::System.Xml.XmlSqlBinaryReader v62 = this;
        __cil_direct_060007E6(v62);
        int v63 = 247;
        int v64 = unchecked((int)(l1));
        if (unchecked((uint)v63) != unchecked((uint)v64)) {
            goto IL_0109;
        } else {
            goto IL_00F9;
        }
        IL_00F9: ;
        global::System.Xml.XmlSqlBinaryReader v65 = this;
        int v66 = unchecked((int)(__cil_direct_060007D6(v65)));
        global::System.Xml.XmlSqlBinaryReader v67 = this;
        int v68 = 1;
        v67._isEmpty = __cil_bool_store(v68);
        goto IL_0174;
        IL_0109: ;
        int v69 = 17;
        int v70 = unchecked((int)(l1));
        if (unchecked((uint)v69) != unchecked((uint)v70)) {
            goto IL_0174;
        } else {
            goto IL_010E;
        }
        IL_010E: ;
        global::System.Xml.XmlSqlBinaryReader v71 = this;
        int v72 = v71._mark;
        int v73 = 0;
        if (v72 >= v73) {
            goto IL_0123;
        } else {
            goto IL_0117;
        }
        IL_0117: ;
        global::System.Xml.XmlSqlBinaryReader v74 = this;
        global::System.Xml.XmlSqlBinaryReader v75 = this;
        int v76 = v75._pos;
        v74._mark = v76;
        goto IL_0123;
        IL_0123: ;
        global::System.Xml.XmlSqlBinaryReader v77 = this;
        global::System.Xml.XmlSqlBinaryReader v78 = this;
        int v79 = v78._pos;
        int v80 = 1;
        int v81 = unchecked(v79 + v80);
        v77._pos = v81;
        global::System.Xml.XmlSqlBinaryReader v82 = this;
        int v83 = unchecked((int)(__cil_direct_060007CC(v82)));
        if (v83 != 0) {
            goto IL_0166;
        } else {
            goto IL_0139;
        }
        IL_0139: ;
        int v84 = 247;
        global::System.Xml.XmlSqlBinaryReader v85 = this;
        int v86 = unchecked((int)(__cil_direct_060007CC(v85)));
        if (v84 == v86) {
            goto IL_0156;
        } else {
            goto IL_0146;
        }
        IL_0146: ;
        global::System.Xml.XmlSqlBinaryReader v87 = this;
        global::System.Xml.XmlSqlBinaryReader v88 = this;
        int v89 = v88._pos;
        int v90 = 3;
        int v91 = unchecked(v89 - v90);
        v87._pos = v91;
        goto IL_0174;
        IL_0156: ;
        global::System.Xml.XmlSqlBinaryReader v92 = this;
        global::System.Xml.XmlSqlBinaryReader v93 = this;
        int v94 = v93._pos;
        int v95 = 1;
        int v96 = unchecked(v94 - v95);
        v92._pos = v96;
        goto IL_0174;
        IL_0166: ;
        global::System.Xml.XmlSqlBinaryReader v97 = this;
        global::System.Xml.XmlSqlBinaryReader v98 = this;
        int v99 = v98._pos;
        int v100 = 2;
        int v101 = unchecked(v99 - v100);
        v97._pos = v101;
        goto IL_0174;
        IL_0174: ;
        global::System.Xml.XmlSqlBinaryReader v102 = this;
        int v103 = 1;
        v102._nodetype = unchecked((__cil_enum_020000B5)(v103));
        global::System.Xml.XmlSqlBinaryReader v104 = this;
        __cil_type_01000004 v105 = System.Xml.XmlSqlBinaryReader.TypeOfObject;
        v104._valueType = v105;
        global::System.Xml.XmlSqlBinaryReader v106 = this;
        global::System.Xml.XmlSqlBinaryReader v107 = this;
        int v108 = v107._pos;
        v106._posAfterAttrs = v108;
        return;
    }

    private void ImplReadEndElement()
    {
        // structural signature __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 bytes=1D1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = v0._elemDepth;
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        string v3 = System.SR.get_Xml_UnexpectedEndTag();
        global::System.Exception v4 = __cil_direct_0600081B(v2, v3);
        throw v4;
        IL_0014: ;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        int v6 = v5._elemDepth;
        l0 = v6;
        int v7 = 1;
        int v8 = l0;
        if (unchecked((uint)v7) != unchecked((uint)v8)) {
            goto IL_002F;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        int v9 = 3;
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        int v11 = v10._docState;
        if (unchecked((uint)v9) != unchecked((uint)v11)) {
            goto IL_002F;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        int v13 = -1;
        v12._docState = v13;
        goto IL_002F;
        IL_002F: ;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v16 = v15._elementStack;
        int v17 = l0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v18 = ref __cil_ldelema_0200006E(v16, v17);
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v19 = v18.name;
        v14._qnameOther = v19;
        global::System.Xml.XmlSqlBinaryReader v20 = this;
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        __cil_ref_b758b12e7d24d465b924587007d48b63b400c590 v22 = v21._elementStack;
        int v23 = l0;
        ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v24 = ref __cil_ldelema_0200006E(v22, v23);
        int v25 = __cil_bool_load(v24.xmlspacePreserve);
        v20._xmlspacePreserve = __cil_bool_store(v25);
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        int v27 = 15;
        v26._nodetype = unchecked((__cil_enum_020000B5)(v27));
        return;
    }

    private void ImplReadDoctype()
    {
        // structural signature __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 bytes=1D1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000BF alias=__cil_enum_020000BF underlying=int: global::@System.@Xml.@DtdProcessing; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = unchecked((int)(v0._dtdProcessing));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        string v3 = System.SR.get_Xml_DtdIsProhibited();
        global::System.Exception v4 = __cil_direct_0600081B(v2, v3);
        throw v4;
        IL_0014: ;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        int v6 = v5._docState;
        l0 = v6;
        int v7 = l0;
        int v8 = 1;
        if (unchecked((uint)v7) <= unchecked((uint)v8)) {
            goto IL_003C;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        int v9 = l0;
        int v10 = 9;
        if (unchecked((uint)v9) != unchecked((uint)v10)) {
            goto IL_0030;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        global::System.Xml.XmlSqlBinaryReader v11 = this;
        string v12 = System.SR.get_Xml_DtdNotAllowedInFragment();
        global::System.Exception v13 = __cil_direct_0600081B(v11, v12);
        throw v13;
        IL_0030: ;
        global::System.Xml.XmlSqlBinaryReader v14 = this;
        string v15 = System.SR.get_Xml_BadDTDLocation();
        global::System.Exception v16 = __cil_direct_0600081B(v14, v15);
        throw v16;
        IL_003C: ;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        int v18 = 2;
        v17._docState = v18;
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v20 = ref v19._qnameOther;
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        string v22 = __cil_direct_060007D9(v21);
        v20.localname = v22;
        int v23 = 251;
        global::System.Xml.XmlSqlBinaryReader v24 = this;
        int v25 = unchecked((int)(__cil_direct_060007D2(v24)));
        if (unchecked((uint)v23) != unchecked((uint)v25)) {
            goto IL_00B5;
        } else {
            goto IL_0061;
        }
        IL_0061: ;
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        global::System.Xml.XmlSqlBinaryReader v27 = this;
        int v28 = v27._pos;
        int v29 = 1;
        int v30 = unchecked(v28 + v29);
        v26._pos = v30;
        global::System.Xml.XmlSqlBinaryReader v31 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v32 = v31._attributes;
        global::System.Xml.XmlSqlBinaryReader v33 = this;
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        int v35 = v34._attrCount;
        l0 = v35;
        int v36 = l0;
        int v37 = 1;
        int v38 = unchecked(v36 + v37);
        v33._attrCount = v38;
        int v39 = l0;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v40 = ref __cil_ldelema_0200006F(v32, v39);
        string v41 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlSqlBinaryReader v42 = this;
        global::System.Xml.XmlNameTable v43 = v42._xnt;
        string v44 = __cil_ldstr_7000D135("SYSTEM");
        string v45 = __cil_callvirt_06000A35(v43, v44);
        string v46 = __cil_ldsfld_0A000002();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v47 = __cil_value_newobj_0600081F(v41, v45, v46);
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        string v49 = __cil_direct_060007D9(v48);
        __cil_direct_0600082C(ref v40, v47, v49);
        goto IL_00B5;
        IL_00B5: ;
        int v50 = 250;
        global::System.Xml.XmlSqlBinaryReader v51 = this;
        int v52 = unchecked((int)(__cil_direct_060007D2(v51)));
        if (unchecked((uint)v50) != unchecked((uint)v52)) {
            goto IL_0116;
        } else {
            goto IL_00C2;
        }
        IL_00C2: ;
        global::System.Xml.XmlSqlBinaryReader v53 = this;
        global::System.Xml.XmlSqlBinaryReader v54 = this;
        int v55 = v54._pos;
        int v56 = 1;
        int v57 = unchecked(v55 + v56);
        v53._pos = v57;
        global::System.Xml.XmlSqlBinaryReader v58 = this;
        __cil_ref_754c154bcdfb1d2db28570be063f8daf4c18c4a4 v59 = v58._attributes;
        global::System.Xml.XmlSqlBinaryReader v60 = this;
        global::System.Xml.XmlSqlBinaryReader v61 = this;
        int v62 = v61._attrCount;
        l0 = v62;
        int v63 = l0;
        int v64 = 1;
        int v65 = unchecked(v63 + v64);
        v60._attrCount = v65;
        int v66 = l0;
        ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v67 = ref __cil_ldelema_0200006F(v59, v66);
        string v68 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlSqlBinaryReader v69 = this;
        global::System.Xml.XmlNameTable v70 = v69._xnt;
        string v71 = __cil_ldstr_7000D143("PUBLIC");
        string v72 = __cil_callvirt_06000A35(v70, v71);
        string v73 = __cil_ldsfld_0A000002();
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v74 = __cil_value_newobj_0600081F(v68, v72, v73);
        global::System.Xml.XmlSqlBinaryReader v75 = this;
        string v76 = __cil_direct_060007D9(v75);
        __cil_direct_0600082C(ref v67, v74, v76);
        goto IL_0116;
        IL_0116: ;
        int v77 = 249;
        global::System.Xml.XmlSqlBinaryReader v78 = this;
        int v79 = unchecked((int)(__cil_direct_060007D2(v78)));
        if (unchecked((uint)v77) != unchecked((uint)v79)) {
            goto IL_0151;
        } else {
            goto IL_0123;
        }
        IL_0123: ;
        global::System.Xml.XmlSqlBinaryReader v80 = this;
        global::System.Xml.XmlSqlBinaryReader v81 = this;
        int v82 = v81._pos;
        int v83 = 1;
        int v84 = unchecked(v82 + v83);
        v80._pos = v84;
        global::System.Xml.XmlSqlBinaryReader v85 = this;
        global::System.Xml.XmlSqlBinaryReader v86 = this;
        int v87 = v86._pos;
        v85._mark = v87;
        global::System.Xml.XmlSqlBinaryReader v88 = this;
        global::System.Xml.XmlSqlBinaryReader v89 = this;
        global::System.Xml.XmlSqlBinaryReader v90 = this;
        ref int v91 = ref v90._tokDataPos;
        int v92 = __cil_direct_060007DA(v89, ref v91);
        v88._tokLen = v92;
        goto IL_0161;
        IL_0151: ;
        global::System.Xml.XmlSqlBinaryReader v93 = this;
        global::System.Xml.XmlSqlBinaryReader v94 = this;
        int v95 = 0;
        l0 = v95;
        v94._tokDataPos = v95;
        int v96 = l0;
        v93._tokLen = v96;
        goto IL_0161;
        IL_0161: ;
        global::System.Xml.XmlSqlBinaryReader v97 = this;
        int v98 = 10;
        v97._nodetype = unchecked((__cil_enum_020000B5)(v98));
        global::System.Xml.XmlSqlBinaryReader v99 = this;
        global::System.Xml.XmlSqlBinaryReader v100 = this;
        int v101 = v100._pos;
        v99._posAfterAttrs = v101;
        return;
    }

    private void ImplReadPI()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref v0._qnameOther;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v3 = ref v2._symbolTables;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v4 = v3.symtable;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        int v6 = __cil_direct_060007C8(v5);
        string v7 = v4[v6];
        v1.localname = v7;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        int v10 = v9._pos;
        v8._mark = v10;
        global::System.Xml.XmlSqlBinaryReader v11 = this;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        ref int v14 = ref v13._tokDataPos;
        int v15 = __cil_direct_060007DA(v12, ref v14);
        v11._tokLen = v15;
        global::System.Xml.XmlSqlBinaryReader v16 = this;
        int v17 = 7;
        v16._nodetype = unchecked((__cil_enum_020000B5)(v17));
        return;
    }

    private void ImplReadComment()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        int v1 = 8;
        v0._nodetype = unchecked((__cil_enum_020000B5)(v1));
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        int v4 = v3._pos;
        v2._mark = v4;
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        ref int v8 = ref v7._tokDataPos;
        int v9 = __cil_direct_060007DA(v6, ref v8);
        v5._tokLen = v9;
        return;
    }

    private void ImplReadCDATA()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_direct_060007FC(v0);
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = 4;
        v1._nodetype = unchecked((__cil_enum_020000B5)(v2));
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        global::System.Xml.XmlSqlBinaryReader v4 = this;
        int v5 = v4._pos;
        v3._mark = v5;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        global::System.Xml.XmlSqlBinaryReader v8 = this;
        ref int v9 = ref v8._tokDataPos;
        int v10 = __cil_direct_060007DA(v7, ref v9);
        v6._tokLen = v10;
        return;
    }

    private void ImplReadNest()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_direct_060007FC(v0);
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v3 = v2._symbolTables;
        global::System.Xml.XmlSqlBinaryReader v4 = this;
        int v5 = v4._docState;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        global::System.Xml.XmlSqlBinaryReader.NestedBinXml v7 = v6._prevNameInfo;
        global::System.Xml.XmlSqlBinaryReader.NestedBinXml v8 = __cil_newobj_06000835(v3, v5, v7);
        v1._prevNameInfo = v8;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v10 = ref v9._symbolTables;
        __cil_direct_06000834(ref v10);
        global::System.Xml.XmlSqlBinaryReader v11 = this;
        int v12 = 0;
        v11._docState = v12;
        return;
    }

    private void ImplReadEndNest()
    {
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::System.Xml.XmlSqlBinaryReader.NestedBinXml v1 = this._prevNameInfo;
        __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v4 = v1.symbolTables;
        this._symbolTables = v4;
        int v7 = v1.docState;
        this._docState = v7;
        global::System.Xml.XmlSqlBinaryReader.NestedBinXml v10 = v1.next;
        this._prevNameInfo = v10;
        return;
    }

    private void ImplReadXmlText()
    {
        // structural signature __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af bytes=151280D1020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 bytes=1511814D020E1281C0: valuetype [System.Collections]System.Collections.Generic.Dictionary`2/ValueCollection/Enumerator<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_b96c34a4c67f46dc257ee1bf65a223c208c498aa bytes=15128149020E1281C0: class [System.Collections]System.Collections.Generic.Dictionary`2/ValueCollection<string, class System.Xml.XmlSqlBinaryReader/NamespaceDecl>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000BE alias=__cil_enum_020000BE underlying=int: global::@System.@Xml.@ConformanceLevel; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000BF alias=__cil_enum_020000BF underlying=int: global::@System.@Xml.@DtdProcessing; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200013A alias=__cil_enum_0200013A underlying=int: global::@System.@Xml.@XmlSpace; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        System.Xml.XmlNamespaceManager l1 = default;
        System.Xml.XmlReaderSettings l2 = default;
        System.Xml.XmlParserContext l3 = default;
        __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 l4 = default;
        System.Xml.XmlSqlBinaryReader.NamespaceDecl l5 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_direct_060007FC(v0);
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        string v2 = __cil_direct_060007D9(v1);
        l0 = v2;
        global::System.Xml.XmlSqlBinaryReader v3 = this;
        global::System.Xml.XmlNameTable v4 = v3._xnt;
        global::System.Xml.XmlNamespaceManager v5 = __cil_newobj_06000A23(v4);
        l1 = v5;
        global::System.Xml.XmlSqlBinaryReader v6 = this;
        __cil_ref_73775db26a5f38ea473b02c84831bde5dbb186af v7 = v6._namespaces;
        __cil_ref_b96c34a4c67f46dc257ee1bf65a223c208c498aa v8 = __cil_callvirt_0A0000A9(v7);
        __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v9 = __cil_callvirt_0A0000AA(v8);
        l4 = v9;
        try {
            IL_002B: ;
            goto IL_0054;
            IL_002D: ;
            ref __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v10 = ref l4;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v11 = __cil_value_call_0A0000AB(ref v10);
            l5 = v11;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v12 = l5;
            int v13 = v12.scope;
            int v14 = 0;
            if (v13 <= v14) {
                goto IL_0054;
            } else {
                goto IL_0040;
            }
            IL_0040: ;
            global::System.Xml.XmlNamespaceManager v15 = l1;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v16 = l5;
            string v17 = v16.prefix;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v18 = l5;
            string v19 = v18.uri;
            __cil_callvirt_06000A28(v15, v17, v19);
            goto IL_0054;
            IL_0054: ;
            ref __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v20 = ref l4;
            int v21 = __cil_bool_load(__cil_value_call_0A0000AC(ref v20));
            if (v21 != 0) {
                goto IL_002D;
            } else {
                goto IL_005D;
            }
            IL_005D: ;
            goto IL_006D;
        }
        finally {
            IL_005F: ;
            ref __cil_value_6534f25fef1b3b133ef35d116f2ae149b918aa23 v22 = ref l4;
            __cil_constrained_1B000021_0A000031(ref v22);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_006D: ;
        global::System.Xml.XmlSqlBinaryReader v23 = this;
        global::System.Xml.XmlReaderSettings v24 = __cil_callvirt_06000EB7(v23);
        l2 = v24;
        global::System.Xml.XmlReaderSettings v25 = l2;
        int v26 = 0;
        __cil_callvirt_06000FA8(v25, __cil_bool_store(v26));
        global::System.Xml.XmlReaderSettings v27 = l2;
        global::System.Xml.XmlSqlBinaryReader v28 = this;
        global::System.Xml.XmlNameTable v29 = v28._xnt;
        __cil_callvirt_06000F7B(v27, v29);
        global::System.Xml.XmlReaderSettings v30 = l2;
        int v31 = 0;
        __cil_callvirt_06000F96(v30, unchecked((__cil_enum_020000BF)(v31)));
        global::System.Xml.XmlSqlBinaryReader v32 = this;
        int v33 = v32._elemDepth;
        if (v33 == 0) {
            goto IL_009D;
        } else {
            goto IL_0096;
        }
        IL_0096: ;
        global::System.Xml.XmlReaderSettings v34 = l2;
        int v35 = 1;
        __cil_callvirt_06000F86(v34, unchecked((__cil_enum_020000BE)(v35)));
        goto IL_009D;
        IL_009D: ;
        global::System.Xml.XmlReaderSettings v36 = l2;
        int v37 = 1;
        __cil_callvirt_06000FA8(v36, __cil_bool_store(v37));
        global::System.Xml.XmlSqlBinaryReader v38 = this;
        global::System.Xml.XmlNameTable v39 = v38._xnt;
        global::System.Xml.XmlNamespaceManager v40 = l1;
        global::System.Xml.XmlSqlBinaryReader v41 = this;
        string v42 = __cil_callvirt_06000EC5(v41);
        global::System.Xml.XmlSqlBinaryReader v43 = this;
        int v44 = unchecked((int)(__cil_callvirt_06000EC4(v43)));
        global::System.Xml.XmlParserContext v45 = __cil_newobj_06000E55(v39, v40, v42, v44);
        l3 = v45;
        global::System.Xml.XmlSqlBinaryReader v46 = this;
        string v47 = l0;
        global::System.Xml.XmlParserContext v48 = l3;
        global::System.Xml.XmlReaderSettings v49 = l2;
        global::System.Xml.XmlTextReaderImpl v50 = __cil_newobj_0600109E(v47, v48, v49);
        v46._textXmlReader = v50;
        global::System.Xml.XmlSqlBinaryReader v51 = this;
        global::System.Xml.XmlReader v52 = v51._textXmlReader;
        int v53 = __cil_bool_load(__cil_callvirt_06000EF5(v52));
        if (v53 == 0) {
            goto IL_00F4;
        } else {
            goto IL_00D8;
        }
        IL_00D8: ;
        global::System.Xml.XmlSqlBinaryReader v54 = this;
        global::System.Xml.XmlReader v55 = v54._textXmlReader;
        int v56 = unchecked((int)(__cil_callvirt_06000EB8(v55)));
        int v57 = 17;
        if (unchecked((uint)v56) != unchecked((uint)v57)) {
            goto IL_0103;
        } else {
            goto IL_00E7;
        }
        IL_00E7: ;
        global::System.Xml.XmlSqlBinaryReader v58 = this;
        global::System.Xml.XmlReader v59 = v58._textXmlReader;
        int v60 = __cil_bool_load(__cil_callvirt_06000EF5(v59));
        if (v60 != 0) {
            goto IL_0103;
        } else {
            goto IL_00F4;
        }
        IL_00F4: ;
        global::System.Xml.XmlSqlBinaryReader v61 = this;
        int v62 = 0;
        v61._state = unchecked((__cil_enum_0200006C)(v62));
        global::System.Xml.XmlSqlBinaryReader v63 = this;
        int v64 = __cil_bool_load(__cil_direct_060007EF(v63));
        return;
        IL_0103: ;
        global::System.Xml.XmlSqlBinaryReader v65 = this;
        int v66 = 1;
        v65._state = unchecked((__cil_enum_0200006C)(v66));
        global::System.Xml.XmlSqlBinaryReader v67 = this;
        __cil_direct_060007FA(v67);
        return;
    }

    private void UpdateFromTextReader()
    {
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        System.Xml.XmlReader l0 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        global::System.Xml.XmlReader v1 = v0._textXmlReader;
        l0 = v1;
        global::System.Xml.XmlSqlBinaryReader v2 = this;
        global::System.Xml.XmlReader v3 = l0;
        int v4 = unchecked((int)(__cil_callvirt_06000EB8(v3)));
        v2._nodetype = unchecked((__cil_enum_020000B5)(v4));
        global::System.Xml.XmlSqlBinaryReader v5 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v6 = ref v5._qnameOther;
        global::System.Xml.XmlReader v7 = l0;
        string v8 = __cil_callvirt_06000EBC(v7);
        v6.prefix = v8;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v10 = ref v9._qnameOther;
        global::System.Xml.XmlReader v11 = l0;
        string v12 = __cil_callvirt_06000EBA(v11);
        v10.localname = v12;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v14 = ref v13._qnameOther;
        global::System.Xml.XmlReader v15 = l0;
        string v16 = __cil_callvirt_06000EBB(v15);
        v14.namespaceUri = v16;
        global::System.Xml.XmlSqlBinaryReader v17 = this;
        global::System.Xml.XmlReader v18 = l0;
        __cil_type_01000004 v19 = __cil_callvirt_06000EC7(v18);
        v17._valueType = v19;
        global::System.Xml.XmlSqlBinaryReader v20 = this;
        global::System.Xml.XmlReader v21 = l0;
        int v22 = __cil_bool_load(__cil_callvirt_06000EC1(v21));
        v20._isEmpty = __cil_bool_store(v22);
        return;
    }

    private bool UpdateFromTextReader(bool needUpdate)
    {
        int v0 = __cil_bool_load(needUpdate);
        if (v0 == 0) {
            return needUpdate;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        __cil_direct_060007FA(this);
        return needUpdate;
    }

    private void CheckAllowContent()
    {
        int l0 = default;
        int v1 = this._docState;
        l0 = v1;
        int v2 = l0;
        if (v2 == 0) {
            goto IL_0015;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        int v3 = l0;
        if (v3 == 3) {
            goto IL_002A;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int v5 = l0;
        if (v5 == 9) {
            goto IL_002A;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        goto IL_001E;
        IL_0015: ;
        this._docState = 9;
        return;
        IL_001E: ;
        string v10 = System.SR.get_Xml_InvalidRootData();
        global::System.Exception v11 = __cil_direct_0600081B(this, v10);
        throw v11;
        IL_002A: ;
        return;
    }

    private void GenerateTokenTypeMap()
    {
        // structural signature __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 bytes=1D1211: class [System.Runtime]System.Type[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 l0 = default;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v1 = __cil_newarr_01000004(256);
        l0 = v1;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v2 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v4 = __cil_ldtoken_type_01000006;
        __cil_type_01000004 v5 = System.Type.GetTypeFromHandle(v4);
        v2[134] = v5;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v6 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v8 = __cil_ldtoken_type_0100003E;
        __cil_type_01000004 v9 = System.Type.GetTypeFromHandle(v8);
        v6[7] = v9;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v10 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v12 = __cil_ldtoken_type_01000055;
        __cil_type_01000004 v13 = System.Type.GetTypeFromHandle(v12);
        v10[136] = v13;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v14 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v16 = __cil_ldtoken_type_01000014;
        __cil_type_01000004 v17 = System.Type.GetTypeFromHandle(v16);
        v14[1] = v17;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v18 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v20 = __cil_ldtoken_type_01000017;
        __cil_type_01000004 v21 = System.Type.GetTypeFromHandle(v20);
        v18[137] = v21;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v22 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v24 = __cil_ldtoken_type_01000016;
        __cil_type_01000004 v25 = System.Type.GetTypeFromHandle(v24);
        v22[138] = v25;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v26 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v28 = __cil_ldtoken_type_01000019;
        __cil_type_01000004 v29 = System.Type.GetTypeFromHandle(v28);
        v26[3] = v29;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v30 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v32 = __cil_ldtoken_type_01000007;
        __cil_type_01000004 v33 = System.Type.GetTypeFromHandle(v32);
        v30[4] = v33;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v34 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v36 = __cil_ldtoken_type_01000015;
        __cil_type_01000004 v37 = System.Type.GetTypeFromHandle(v36);
        v34[8] = v37;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v38 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v40 = __cil_ldtoken_type_01000018;
        __cil_type_01000004 v41 = System.Type.GetTypeFromHandle(v40);
        v38[139] = v41;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v42 = l0;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v44 = __cil_ldtoken_type_020000B7;
        __cil_type_01000004 v45 = System.Type.GetTypeFromHandle(v44);
        v42[140] = v45;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v46 = __cil_ldtoken_type_01000013;
        __cil_type_01000004 v47 = System.Type.GetTypeFromHandle(v46);
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v48 = l0;
        v48[6] = v47;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v51 = l0;
        v51[2] = v47;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v54 = __cil_ldtoken_type_0100001A;
        __cil_type_01000004 v55 = System.Type.GetTypeFromHandle(v54);
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v56 = l0;
        v56[20] = v55;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v59 = l0;
        v59[5] = v55;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v62 = l0;
        v62[10] = v55;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v65 = l0;
        v65[11] = v55;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v68 = l0;
        v68[135] = v55;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v71 = __cil_ldtoken_type_01000051;
        __cil_type_01000004 v72 = System.Type.GetTypeFromHandle(v71);
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v73 = l0;
        v73[19] = v72;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v76 = l0;
        v76[18] = v72;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v79 = l0;
        v79[129] = v72;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v82 = l0;
        v82[130] = v72;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v85 = l0;
        v85[131] = v72;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v88 = l0;
        v88[127] = v72;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v91 = l0;
        v91[126] = v72;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v94 = l0;
        v94[125] = v72;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v97 = __cil_ldtoken_type_01000056;
        __cil_type_01000004 v98 = System.Type.GetTypeFromHandle(v97);
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v99 = l0;
        v99[124] = v98;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v102 = l0;
        v102[123] = v98;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v105 = l0;
        v105[122] = v98;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v108 = __cil_ldtoken_type_1B000022;
        __cil_type_01000004 v109 = System.Type.GetTypeFromHandle(v108);
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v110 = l0;
        v110[15] = v109;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v113 = l0;
        v113[12] = v109;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v116 = l0;
        v116[23] = v109;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v119 = l0;
        v119[27] = v109;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v122 = l0;
        v122[132] = v109;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v125 = l0;
        v125[133] = v109;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v128 = l0;
        __cil_type_01000004 v130 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v128[13] = v130;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v131 = l0;
        __cil_type_01000004 v133 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v131[16] = v133;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v134 = l0;
        __cil_type_01000004 v136 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v134[22] = v136;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v137 = l0;
        __cil_type_01000004 v139 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v137[14] = v139;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v140 = l0;
        __cil_type_01000004 v142 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v140[17] = v142;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v143 = l0;
        __cil_type_01000004 v145 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v143[24] = v145;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v146 = l0;
        __cil_type_01000004 v148 = System.Xml.XmlSqlBinaryReader.TypeOfString;
        v146[9] = v148;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v149 = System.Threading.Volatile.Read(ref System.Xml.XmlSqlBinaryReader.s_tokenTypeMap);
        if (v149 is not null) {
            goto IL_01CB;
        } else {
            goto IL_01C3;
        }
        IL_01C3: ;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v150 = l0;
        System.Threading.Volatile.Write(ref System.Xml.XmlSqlBinaryReader.s_tokenTypeMap, v150);
        IL_01CB: ;
        return;
    }

    private System.Type GetValueType(System.Xml.BinXmlToken token)
    {
        // structural signature __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 bytes=1D1211: class [System.Runtime]System.Type[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_01000004 l0 = default;
        __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 v0 = System.Threading.Volatile.Read(ref System.Xml.XmlSqlBinaryReader.s_tokenTypeMap);
        int v1 = unchecked((int)(token));
        __cil_type_01000004 v2 = v0[v1];
        l0 = v2;
        __cil_type_01000004 v3 = l0;
        int v4 = __cil_bool_load(System.Type.op_Equality(v3, ((__cil_type_01000004)(null))));
        if (v4 == 0) {
            goto IL_001B;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        int v6 = unchecked((int)(token));
        global::System.Exception v7 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v6)));
        throw v7;
        IL_001B: ;
        __cil_type_01000004 v8 = l0;
        return v8;
    }

    private void ReScanOverValue(System.Xml.BinXmlToken token)
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(token));
        int v4 = unchecked((int)(__cil_direct_06000800(this, unchecked((__cil_enum_02000073)(v1)), __cil_bool_store(1), __cil_bool_store(0))));
        return;
    }

    private System.Xml.XmlNodeType ScanOverValue(System.Xml.BinXmlToken token, bool attr, bool checkChars)
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(token));
        if (unchecked((uint)v0) != unchecked((uint)17)) {
            goto IL_006D;
        } else {
            goto IL_0005;
        }
        IL_0005: ;
        int v3 = this._mark;
        if (v3 >= 0) {
            goto IL_001A;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int v7 = this._pos;
        this._mark = v7;
        IL_001A: ;
        int v10 = __cil_direct_060007CE(this);
        this._tokLen = v10;
        int v13 = this._pos;
        this._tokDataPos = v13;
        int v16 = this._pos;
        int v18 = this._tokLen;
        int v20 = checked(v18 * 2);
        int v21 = checked(v16 + v20);
        this._pos = v21;
        __cil_direct_060007CB(this, -1);
        int v24 = __cil_bool_load(checkChars);
        if (v24 == 0) {
            goto IL_0061;
        } else {
            goto IL_0051;
        }
        IL_0051: ;
        int v26 = __cil_bool_load(this._checkCharacters);
        if (v26 == 0) {
            goto IL_0061;
        } else {
            goto IL_0059;
        }
        IL_0059: ;
        int v28 = __cil_bool_load(attr);
        int v29 = unchecked((int)(__cil_direct_06000802(this, __cil_bool_store(v28))));
        return unchecked((__cil_enum_020000B5)(v29));
        IL_0061: ;
        int v30 = __cil_bool_load(attr);
        if (v30 != 0) {
            goto IL_006B;
        } else {
            goto IL_0064;
        }
        IL_0064: ;
        int v32 = unchecked((int)(__cil_direct_06000803(this)));
        return unchecked((__cil_enum_020000B5)(v32));
        IL_006B: ;
        return unchecked((__cil_enum_020000B5)(3));
        IL_006D: ;
        int v35 = unchecked((int)(token));
        int v36 = __cil_bool_load(attr);
        int v37 = __cil_bool_load(checkChars);
        int v38 = unchecked((int)(__cil_direct_06000801(this, unchecked((__cil_enum_02000073)(v35)), __cil_bool_store(v36), __cil_bool_store(v37))));
        return unchecked((__cil_enum_020000B5)(v38));
    }

    private System.Xml.XmlNodeType ScanOverAnyValue(System.Xml.BinXmlToken token, bool attr, bool checkChars)
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200009D alias=__cil_enum_0200009D underlying=int: global::@System.@Xml.@ExceptionType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = this._mark;
        if (v1 >= 0) {
            goto IL_0015;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        int v5 = this._pos;
        this._mark = v5;
        IL_0015: ;
        int v6 = unchecked((int)(token));
        int v8 = unchecked(v6 - 1);
        switch (v8) {
            case 0: {
                goto IL_0109;
            }
            case 1: {
                goto IL_012F;
            }
            case 2: {
                goto IL_012F;
            }
            case 3: {
                goto IL_0155;
            }
            case 4: {
                goto IL_0155;
            }
            case 5: {
                goto IL_00E3;
            }
            case 6: {
                goto IL_00E3;
            }
            case 7: {
                goto IL_0155;
            }
            case 8: {
                goto IL_017B;
            }
            case 9: {
                goto IL_01A3;
            }
            case 10: {
                goto IL_01A3;
            }
            case 11: {
                goto IL_01D3;
            }
            case 12: {
                goto IL_0203;
            }
            case 13: {
                goto IL_025C;
            }
            case 14: {
                goto IL_01D3;
            }
            case 15: {
                goto IL_0203;
            }
            case 16: {
                goto IL_025C;
            }
            case 17: {
                goto IL_0155;
            }
            case 18: {
                goto IL_012F;
            }
            case 19: {
                goto IL_012F;
            }
            case 20: {
                goto IL_02B2;
            }
            case 21: {
                goto IL_0203;
            }
            case 22: {
                goto IL_01D3;
            }
            case 23: {
                goto IL_025C;
            }
            case 24: {
                goto IL_02B2;
            }
            case 25: {
                goto IL_02B2;
            }
            case 26: {
                goto IL_01D3;
            }
            default: {
                goto IL_0089;
            } }
        IL_0089: ;
        int v9 = unchecked((int)(token));
        int v11 = unchecked(v9 - 122);
        switch (v11) {
            case 0: {
                goto IL_027C;
            }
            case 1: {
                goto IL_027C;
            }
            case 2: {
                goto IL_027C;
            }
            case 3: {
                goto IL_027C;
            }
            case 4: {
                goto IL_027C;
            }
            case 5: {
                goto IL_027C;
            }
            case 6: {
                goto IL_02B2;
            }
            case 7: {
                goto IL_0155;
            }
            case 8: {
                goto IL_0155;
            }
            case 9: {
                goto IL_0155;
            }
            case 10: {
                goto IL_01D3;
            }
            case 11: {
                goto IL_01D3;
            }
            case 12: {
                goto IL_00E3;
            }
            case 13: {
                goto IL_01A3;
            }
            case 14: {
                goto IL_00E3;
            }
            case 15: {
                goto IL_0109;
            }
            case 16: {
                goto IL_012F;
            }
            case 17: {
                goto IL_0155;
            }
            case 18: {
                goto IL_0267;
            }
            default: {
                goto IL_00DE;
            } }
        IL_00DE: ;
        goto IL_02B2;
        IL_00E3: ;
        int v14 = this._pos;
        this._tokDataPos = v14;
        this._tokLen = 1;
        int v19 = this._pos;
        int v21 = checked(v19 + 1);
        this._pos = v21;
        goto IL_02BA;
        IL_0109: ;
        int v24 = this._pos;
        this._tokDataPos = v24;
        this._tokLen = 2;
        int v29 = this._pos;
        int v31 = checked(v29 + 2);
        this._pos = v31;
        goto IL_02BA;
        IL_012F: ;
        int v34 = this._pos;
        this._tokDataPos = v34;
        this._tokLen = 4;
        int v39 = this._pos;
        int v41 = checked(v39 + 4);
        this._pos = v41;
        goto IL_02BA;
        IL_0155: ;
        int v44 = this._pos;
        this._tokDataPos = v44;
        this._tokLen = 8;
        int v49 = this._pos;
        int v51 = checked(v49 + 8);
        this._pos = v51;
        goto IL_02BA;
        IL_017B: ;
        int v54 = this._pos;
        this._tokDataPos = v54;
        this._tokLen = 16;
        int v59 = this._pos;
        int v61 = checked(v59 + 16);
        this._pos = v61;
        goto IL_02BA;
        IL_01A3: ;
        int v64 = this._pos;
        this._tokDataPos = v64;
        int v67 = __cil_direct_060007D1(this);
        this._tokLen = v67;
        int v70 = this._pos;
        int v72 = this._tokLen;
        int v73 = checked(v70 + v72);
        this._pos = v73;
        goto IL_02BA;
        IL_01D3: ;
        int v76 = __cil_direct_060007D1(this);
        this._tokLen = v76;
        int v79 = this._pos;
        this._tokDataPos = v79;
        int v82 = this._pos;
        int v84 = this._tokLen;
        int v85 = checked(v82 + v84);
        this._pos = v85;
        goto IL_02BA;
        IL_0203: ;
        int v88 = __cil_direct_060007D1(this);
        this._tokLen = v88;
        int v91 = this._pos;
        this._tokDataPos = v91;
        int v94 = this._pos;
        int v96 = this._tokLen;
        int v97 = checked(v94 + v96);
        this._pos = v97;
        int v98 = __cil_bool_load(checkChars);
        if (v98 == 0) {
            goto IL_02BA;
        } else {
            goto IL_0234;
        }
        IL_0234: ;
        int v100 = __cil_bool_load(this._checkCharacters);
        if (v100 == 0) {
            goto IL_02BA;
        } else {
            goto IL_023C;
        }
        IL_023C: ;
        __cil_direct_060007CB(this, -1);
        int v104 = unchecked((int)(token));
        string v105 = __cil_direct_0600080E(this, unchecked((__cil_enum_02000073)(v104)));
        System.Xml.XmlConvert.VerifyCharData(v105, unchecked((__cil_enum_0200009D)(0)), unchecked((__cil_enum_0200009D)(1)));
        this._stringValue = v105;
        goto IL_02BA;
        IL_025C: ;
        int v113 = __cil_bool_load(attr);
        int v114 = __cil_bool_load(checkChars);
        int v115 = unchecked((int)(__cil_direct_06000800(this, unchecked((__cil_enum_02000073)(17)), __cil_bool_store(v113), __cil_bool_store(v114))));
        return unchecked((__cil_enum_020000B5)(v115));
        IL_0267: ;
        int v118 = this._pos;
        this._tokDataPos = v118;
        int v120 = __cil_direct_060007CE(this);
        goto IL_02BA;
        IL_027C: ;
        int v123 = unchecked((int)(token));
        __cil_direct_060007C1(this, 2, unchecked((__cil_enum_02000073)(v123)));
        int v126 = this._pos;
        this._tokDataPos = v126;
        int v129 = unchecked((int)(token));
        int v130 = __cil_direct_06000805(this, unchecked((__cil_enum_02000073)(v129)));
        this._tokLen = v130;
        int v133 = this._pos;
        int v135 = this._tokLen;
        int v136 = checked(v133 + v135);
        this._pos = v136;
        goto IL_02BA;
        IL_02B2: ;
        int v138 = unchecked((int)(token));
        global::System.Exception v139 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v138)));
        throw v139;
        IL_02BA: ;
        __cil_direct_060007CB(this, -1);
        return unchecked((__cil_enum_020000B5)(3));
    }

    private System.Xml.XmlNodeType CheckText(bool attr)
    {
        // IL fallback: pinned/byref/modified local needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, B3, 01, 00, 04, 0A, 02, 7B, 86, 01, 00, 04, 25, 0C, 2C, 05, 08, 8E, 69, 2D, 05, 16, E0]
        // .code-bytes IL_0018: [0B, 2B, 09, 08, 16, 8F, 3E, 00, 00, 01, E0, 0B, 02, 7B, 87, 01, 00, 04, 0D, 02, 7B, A5, 01, 00]
        // .code-bytes IL_0030: [04, 13, 04, 03, 2D, 36, 11, 04, 18, 58, 13, 05, 11, 05, 09, 31, 0E, 02, 7B, A3, 01, 00, 04, 2D]
        // .code-bytes IL_0048: [03, 1F, 0D, 2A, 1F, 0E, 2A, 07, 11, 04, 17, 58, 58, 47, 2D, 14, 12, 00, 07, 11, 04, 58, 47, 28]
        // .code-bytes IL_0060: [20, 09, 00, 06, 2C, 06, 11, 05, 13, 04, 2B, CA, 11, 04, 18, 58, 13, 07, 11, 07, 09, 31, 02, 19]
        // .code-bytes IL_0078: [2A, 07, 11, 04, 58, 47, 07, 11, 04, 17, 58, 58, 47, 1E, 62, 60, D1, 13, 06, 02, 7C, B3, 01, 00]
        // .code-bytes IL_0090: [04, 11, 06, 28, 24, 09, 00, 06, 2C, 06, 11, 07, 13, 04, 2B, CC, 11, 06, 28, 2D, 09, 00, 06, 2D]
        // .code-bytes IL_00A8: [0A, 11, 06, 16, 17, 28, B8, 09, 00, 06, 7A, 11, 04, 1A, 58, 09, 31, 0C, 02, 28, 01, 04, 00, 06]
        // .code-bytes IL_00C0: [28, 1B, 08, 00, 06, 7A, 07, 11, 04, 18, 58, 58, 47, 07, 11, 04, 19, 58, 58, 47, 1E, 62, 60, D1]
        // .code-bytes IL_00D8: [13, 08, 11, 08, 28, 2E, 09, 00, 06, 2D, 0A, 11, 06, 11, 08, 28, AE, 09, 00, 06, 7A, 11, 04, 1A]
        // .code-bytes IL_00F0: [58, 13, 04, 38, 74, FF, FF, FF]
        // .local [0] valuetype System.Xml.XmlCharType
        // .local [1] uint8*
        // .local [2] uint8[] pinned
        // .local [3] int32
        // .local [4] int32
        // .local [5] int32
        // .local [6] char
        // .local [7] int32
        // .local [8] char
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x040001B3 System.Xml.XmlSqlBinaryReader::_xmlCharType
        // IL_0006: stloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_000D: dup 
        // IL_000E: stloc.2 2
        // IL_000F: brfalse.s IL_0016
        // IL_0011: ldloc.2 2
        // IL_0012: ldlen 
        // IL_0013: conv.i4 
        // IL_0014: brtrue.s IL_001B
        // IL_0016: ldc.i4.0 0
        // IL_0017: conv.u 
        // IL_0018: stloc.1 1
        // IL_0019: br.s IL_0024
        // IL_001B: ldloc.2 2
        // IL_001C: ldc.i4.0 0
        // IL_001D: ldelema 0x0100003E [System.Runtime]System.Byte
        // IL_0022: conv.u 
        // IL_0023: stloc.1 1
        // IL_0024: ldarg.0 0
        // IL_0025: ldfld 0x04000187 System.Xml.XmlSqlBinaryReader::_pos
        // IL_002A: stloc.3 3
        // IL_002B: ldarg.0 0
        // IL_002C: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0031: stloc.s 4
        // IL_0033: ldarg.1 1
        // IL_0034: brtrue.s IL_006C
        // IL_0036: ldloc.s 4
        // IL_0038: ldc.i4.2 2
        // IL_0039: add 
        // IL_003A: stloc.s 5
        // IL_003C: ldloc.s 5
        // IL_003E: ldloc.3 3
        // IL_003F: ble.s IL_004F
        // IL_0041: ldarg.0 0
        // IL_0042: ldfld 0x040001A3 System.Xml.XmlSqlBinaryReader::_xmlspacePreserve
        // IL_0047: brtrue.s IL_004C
        // IL_0049: ldc.i4.s 13
        // IL_004B: ret 
        // IL_004C: ldc.i4.s 14
        // IL_004E: ret 
        // IL_004F: ldloc.1 1
        // IL_0050: ldloc.s 4
        // IL_0052: ldc.i4.1 1
        // IL_0053: add 
        // IL_0054: add 
        // IL_0055: ldind.u1 
        // IL_0056: brtrue.s IL_006C
        // IL_0058: ldloca.s 0
        // IL_005A: ldloc.1 1
        // IL_005B: ldloc.s 4
        // IL_005D: add 
        // IL_005E: ldind.u1 
        // IL_005F: call 0x06000920 System.Xml.XmlCharType::IsWhiteSpace
        // IL_0064: brfalse.s IL_006C
        // IL_0066: ldloc.s 5
        // IL_0068: stloc.s 4
        // IL_006A: br.s IL_0036
        // IL_006C: ldloc.s 4
        // IL_006E: ldc.i4.2 2
        // IL_006F: add 
        // IL_0070: stloc.s 7
        // IL_0072: ldloc.s 7
        // IL_0074: ldloc.3 3
        // IL_0075: ble.s IL_0079
        // IL_0077: ldc.i4.3 3
        // IL_0078: ret 
        // IL_0079: ldloc.1 1
        // IL_007A: ldloc.s 4
        // IL_007C: add 
        // IL_007D: ldind.u1 
        // IL_007E: ldloc.1 1
        // IL_007F: ldloc.s 4
        // IL_0081: ldc.i4.1 1
        // IL_0082: add 
        // IL_0083: add 
        // IL_0084: ldind.u1 
        // IL_0085: ldc.i4.8 8
        // IL_0086: shl 
        // IL_0087: or 
        // IL_0088: conv.u2 
        // IL_0089: stloc.s 6
        // IL_008B: ldarg.0 0
        // IL_008C: ldflda 0x040001B3 System.Xml.XmlSqlBinaryReader::_xmlCharType
        // IL_0091: ldloc.s 6
        // IL_0093: call 0x06000924 System.Xml.XmlCharType::IsCharData
        // IL_0098: brfalse.s IL_00A0
        // IL_009A: ldloc.s 7
        // IL_009C: stloc.s 4
        // IL_009E: br.s IL_006C
        // IL_00A0: ldloc.s 6
        // IL_00A2: call 0x0600092D System.Xml.XmlCharType::IsHighSurrogate
        // IL_00A7: brtrue.s IL_00B3
        // IL_00A9: ldloc.s 6
        // IL_00AB: ldc.i4.0 0
        // IL_00AC: ldc.i4.1 1
        // IL_00AD: call 0x060009B8 System.Xml.XmlConvert::CreateInvalidCharException
        // IL_00B2: throw 
        // IL_00B3: ldloc.s 4
        // IL_00B5: ldc.i4.4 4
        // IL_00B6: add 
        // IL_00B7: ldloc.3 3
        // IL_00B8: ble.s IL_00C6
        // IL_00BA: ldarg.0 0
        // IL_00BB: call 0x06000401 System.SR::get_Xml_InvalidSurrogateMissingLowChar
        // IL_00C0: call 0x0600081B System.Xml.XmlSqlBinaryReader::ThrowXmlException
        // IL_00C5: throw 
        // IL_00C6: ldloc.1 1
        // IL_00C7: ldloc.s 4
        // IL_00C9: ldc.i4.2 2
        // IL_00CA: add 
        // IL_00CB: add 
        // IL_00CC: ldind.u1 
        // IL_00CD: ldloc.1 1
        // IL_00CE: ldloc.s 4
        // IL_00D0: ldc.i4.3 3
        // IL_00D1: add 
        // IL_00D2: add 
        // IL_00D3: ldind.u1 
        // IL_00D4: ldc.i4.8 8
        // IL_00D5: shl 
        // IL_00D6: or 
        // IL_00D7: conv.u2 
        // IL_00D8: stloc.s 8
        // IL_00DA: ldloc.s 8
        // IL_00DC: call 0x0600092E System.Xml.XmlCharType::IsLowSurrogate
        // IL_00E1: brtrue.s IL_00ED
        // IL_00E3: ldloc.s 6
        // IL_00E5: ldloc.s 8
        // IL_00E7: call 0x060009AE System.Xml.XmlConvert::CreateInvalidSurrogatePairException
        // IL_00EC: throw 
        // IL_00ED: ldloc.s 4
        // IL_00EF: ldc.i4.4 4
        // IL_00F0: add 
        // IL_00F1: stloc.s 4
        // IL_00F3: br IL_006C
    }

    private System.Xml.XmlNodeType CheckTextIsWS()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 l0 = default;
        int l1 = default;
        byte l2 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        l0 = v1;
        int v3 = this._tokDataPos;
        l1 = v3;
        goto IL_0030;
        IL_0010: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v4 = l0;
        int v5 = l1;
        int v7 = unchecked(v5 + 1);
        int v8 = unchecked((int)(unchecked((byte)(unchecked((int)(v4[v7]))))));
        if (v8 != 0) {
            goto IL_0047;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v9 = l0;
        int v10 = l1;
        int v11 = unchecked((int)(unchecked((byte)(unchecked((int)(v9[v10]))))));
        l2 = unchecked((byte)(v11));
        int v12 = unchecked((int)(l2));
        int v14 = unchecked(v12 - 9);
        if (unchecked((uint)v14) <= unchecked((uint)1)) {
            goto IL_002C;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        int v16 = unchecked((int)(l2));
        if (v16 == 13) {
            goto IL_002C;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        int v18 = unchecked((int)(l2));
        if (unchecked((uint)v18) != unchecked((uint)32)) {
            goto IL_0047;
        } else {
            goto IL_002C;
        }
        IL_002C: ;
        int v20 = l1;
        l1 = unchecked(v20 + 2);
        IL_0030: ;
        int v23 = l1;
        int v25 = this._pos;
        if (v23 < v25) {
            goto IL_0010;
        } else {
            goto IL_0039;
        }
        IL_0039: ;
        int v27 = __cil_bool_load(this._xmlspacePreserve);
        if (v27 == 0) {
            goto IL_0044;
        } else {
            goto IL_0041;
        }
        IL_0041: ;
        return unchecked((__cil_enum_020000B5)(14));
        IL_0044: ;
        return unchecked((__cil_enum_020000B5)(13));
        IL_0047: ;
        return unchecked((__cil_enum_020000B5)(3));
    }

    private void CheckValueTokenBounds()
    {
        int v1 = this._end;
        int v3 = this._tokDataPos;
        int v4 = unchecked(v1 - v3);
        int v6 = this._tokLen;
        if (v4 >= v6) {
            goto IL_0021;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        string v8 = System.SR.get_Xml_UnexpectedEOF1();
        global::System.Exception v9 = __cil_direct_0600081B(this, v8);
        throw v9;
        IL_0021: ;
        return;
    }

    private int GetXsdKatmaiTokenLength(System.Xml.BinXmlToken token)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        byte l0 = default;
        int v0 = unchecked((int)(token));
        int v2 = unchecked(v0 - 122);
        switch (v2) {
            case 0: {
                goto IL_0044;
            }
            case 1: {
                goto IL_0044;
            }
            case 2: {
                goto IL_0044;
            }
            case 3: {
                goto IL_0025;
            }
            case 4: {
                goto IL_0025;
            }
            case 5: {
                return 3;
            }
            default: {
                goto IL_0021;
            } }
        IL_0021: ;
        goto IL_0063;
        IL_0025: ;
        __cil_direct_060007CB(this, 0);
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v7 = this._data;
        int v9 = this._pos;
        int v10 = unchecked((int)(unchecked((byte)(unchecked((int)(v7[v9]))))));
        l0 = unchecked((byte)(v10));
        int v13 = unchecked((int)(l0));
        int v14 = __cil_direct_06000806(this, unchecked((byte)(v13)));
        return unchecked(4 + v14);
        IL_0044: ;
        __cil_direct_060007CB(this, 0);
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v19 = this._data;
        int v21 = this._pos;
        int v22 = unchecked((int)(unchecked((byte)(unchecked((int)(v19[v21]))))));
        l0 = unchecked((byte)(v22));
        int v25 = unchecked((int)(l0));
        int v26 = __cil_direct_06000806(this, unchecked((byte)(v25)));
        return unchecked(6 + v26);
        IL_0063: ;
        int v30 = unchecked((int)(this._token));
        global::System.Exception v31 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v30)));
        throw v31;
    }

    private int XsdKatmaiTimeScaleToValueLength(byte scale)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v0 = unchecked((int)(scale));
        if (v0 <= 7) {
            goto IL_0010;
        } else {
            goto IL_0004;
        }
        IL_0004: ;
        string v2 = System.SR.get_SqlTypes_ArithOverflow();
        global::System.Xml.XmlException v3 = __cil_newobj_06000A0B(v2, null);
        throw v3;
        IL_0010: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v4 = System.Xml.XmlSqlBinaryReader.s_xsdKatmaiTimeScaleToValueLengthMap;
        int v5 = unchecked((int)(scale));
        int v6 = unchecked((int)(unchecked((byte)(unchecked((int)(v4[v5]))))));
        return v6;
    }

    private long ValueAsLong()
    {
        // IL fallback: conv.i8 source category needs IL fallback
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, 04, 08, 00, 06, 02, 7B, 98, 01, 00, 04, 0A, 06, 17, 59, 45, 14, 00, 00, 00, 48, 00, 00]
        // .code-bytes IL_0018: [00, 56, 00, 00, 00, 9D, 00, 00, 00, 9D, 00, 00, 00, A9, 00, 00, 00, 25, 00, 00, 00, 25, 00, 00]
        // .code-bytes IL_0030: [00, 64, 00, 00, 00, B9, 00, 00, 00, A9, 00, 00, 00, A9, 00, 00, 00, B9, 00, 00, 00, B9, 00, 00]
        // .code-bytes IL_0048: [00, B9, 00, 00, 00, B9, 00, 00, 00, B9, 00, 00, 00, B9, 00, 00, 00, B9, 00, 00, 00, B9, 00, 00]
        // .code-bytes IL_0060: [00, A9, 00, 00, 00, 06, 20, 87, 00, 00, 00, 59, 45, 05, 00, 00, 00, 89, 00, 00, 00, 16, 00, 00]
        // .code-bytes IL_0078: [00, 51, 00, 00, 00, 5F, 00, 00, 00, 6D, 00, 00, 00, 38, 94, 00, 00, 00, 02, 7B, 86, 01, 00, 04]
        // .code-bytes IL_0090: [02, 7B, A5, 01, 00, 04, 91, 0B, 07, 6E, 2A, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01, 00, 04, 91]
        // .code-bytes IL_00A8: [67, 0C, 08, 6A, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 12, 08, 00, 06, 6A, 2A, 02, 02, 7B, A5, 01]
        // .code-bytes IL_00C0: [00, 04, 28, 14, 08, 00, 06, 6A, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 16, 08, 00, 06, 2A, 02, 02]
        // .code-bytes IL_00D8: [7B, A5, 01, 00, 04, 28, 13, 08, 00, 06, 6E, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 15, 08, 00, 06]
        // .code-bytes IL_00F0: [6E, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 17, 08, 00, 06, 0D, 09, 85, 2A, 02, 28, 0A, 08, 00, 06]
        // .code-bytes IL_0108: [13, 04, 11, 04, 6A, 2A, 02, 28, 09, 08, 00, 06, 13, 05, 11, 05, 28, B4, 00, 00, 0A, 2A, 02, 02]
        // .code-bytes IL_0120: [7B, 98, 01, 00, 04, 28, 1A, 08, 00, 06, 7A]
        // .local [0] valuetype System.Xml.BinXmlToken
        // .local [1] uint8
        // .local [2] int8
        // .local [3] uint64
        // .local [4] float64
        // .local [5] valuetype [System.Runtime]System.Decimal
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x06000804 System.Xml.XmlSqlBinaryReader::CheckValueTokenBounds
        // IL_0006: ldarg.0 0
        // IL_0007: ldfld 0x04000198 System.Xml.XmlSqlBinaryReader::_token
        // IL_000C: stloc.0 0
        // IL_000D: ldloc.0 0
        // IL_000E: ldc.i4.1 1
        // IL_000F: sub 
        // IL_0010: switch IL_00AD, IL_00BB, IL_0102, IL_0102, IL_010E, IL_008A, IL_008A, IL_00C9, IL_011E, IL_010E, IL_010E, IL_011E, IL_011E, IL_011E, IL_011E, IL_011E, IL_011E, IL_011E, IL_011E, IL_010E
        // IL_0065: ldloc.0 0
        // IL_0066: ldc.i4 135
        // IL_006B: sub 
        // IL_006C: switch IL_010E, IL_009B, IL_00D6, IL_00E4, IL_00F2
        // IL_0085: br IL_011E
        // IL_008A: ldarg.0 0
        // IL_008B: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0090: ldarg.0 0
        // IL_0091: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0096: ldelem.u1 
        // IL_0097: stloc.1 1
        // IL_0098: ldloc.1 1
        // IL_0099: conv.u8 
        // IL_009A: ret 
        // IL_009B: ldarg.0 0
        // IL_009C: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_00A1: ldarg.0 0
        // IL_00A2: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00A7: ldelem.u1 
        // IL_00A8: conv.i1 
        // IL_00A9: stloc.2 2
        // IL_00AA: ldloc.2 2
        // IL_00AB: conv.i8 
        // IL_00AC: ret 
        // IL_00AD: ldarg.0 0
        // IL_00AE: ldarg.0 0
        // IL_00AF: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00B4: call 0x06000812 System.Xml.XmlSqlBinaryReader::GetInt16
        // IL_00B9: conv.i8 
        // IL_00BA: ret 
        // IL_00BB: ldarg.0 0
        // IL_00BC: ldarg.0 0
        // IL_00BD: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00C2: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_00C7: conv.i8 
        // IL_00C8: ret 
        // IL_00C9: ldarg.0 0
        // IL_00CA: ldarg.0 0
        // IL_00CB: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00D0: call 0x06000816 System.Xml.XmlSqlBinaryReader::GetInt64
        // IL_00D5: ret 
        // IL_00D6: ldarg.0 0
        // IL_00D7: ldarg.0 0
        // IL_00D8: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00DD: call 0x06000813 System.Xml.XmlSqlBinaryReader::GetUInt16
        // IL_00E2: conv.u8 
        // IL_00E3: ret 
        // IL_00E4: ldarg.0 0
        // IL_00E5: ldarg.0 0
        // IL_00E6: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00EB: call 0x06000815 System.Xml.XmlSqlBinaryReader::GetUInt32
        // IL_00F0: conv.u8 
        // IL_00F1: ret 
        // IL_00F2: ldarg.0 0
        // IL_00F3: ldarg.0 0
        // IL_00F4: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00F9: call 0x06000817 System.Xml.XmlSqlBinaryReader::GetUInt64
        // IL_00FE: stloc.3 3
        // IL_00FF: ldloc.3 3
        // IL_0100: conv.ovf.i8.un 
        // IL_0101: ret 
        // IL_0102: ldarg.0 0
        // IL_0103: call 0x0600080A System.Xml.XmlSqlBinaryReader::ValueAsDouble
        // IL_0108: stloc.s 4
        // IL_010A: ldloc.s 4
        // IL_010C: conv.i8 
        // IL_010D: ret 
        // IL_010E: ldarg.0 0
        // IL_010F: call 0x06000809 System.Xml.XmlSqlBinaryReader::ValueAsDecimal
        // IL_0114: stloc.s 5
        // IL_0116: ldloc.s 5
        // IL_0118: call 0x0A0000B4 [System.Runtime]System.Decimal::op_Explicit
        // IL_011D: ret 
        // IL_011E: ldarg.0 0
        // IL_011F: ldarg.0 0
        // IL_0120: ldfld 0x04000198 System.Xml.XmlSqlBinaryReader::_token
        // IL_0125: call 0x0600081A System.Xml.XmlSqlBinaryReader::ThrowUnexpectedToken
        // IL_012A: throw 
    }

    private ulong ValueAsULong()
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v2 = unchecked((int)(this._token));
        if (unchecked((uint)139) != unchecked((uint)v2)) {
            goto IL_0020;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_direct_06000804(this);
        int v6 = this._tokDataPos;
        long v7 = unchecked((long)(__cil_direct_06000817(this, v6)));
        return unchecked((ulong)(v7));
        IL_0020: ;
        int v10 = unchecked((int)(this._token));
        global::System.Exception v11 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v10)));
        throw v11;
    }

    private System.Decimal ValueAsDecimal()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f bytes=1169: valuetype [System.Runtime]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_094d148f100986f28432885961b9959bc8d16c44 bytes=1181D4: valuetype System.Xml.BinXmlSqlMoney; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a bytes=1181D0: valuetype System.Xml.BinXmlSqlDecimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        __cil_value_094d148f100986f28432885961b9959bc8d16c44 l1 = default;
        __cil_value_094d148f100986f28432885961b9959bc8d16c44 l2 = default;
        __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a l3 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_direct_06000804(v0);
        global::System.Xml.XmlSqlBinaryReader v1 = this;
        int v2 = unchecked((int)(v1._token));
        l0 = unchecked((__cil_enum_02000073)(v2));
        int v3 = unchecked((int)(l0));
        int v4 = 1;
        int v5 = unchecked(v3 - v4);
        switch (v5) {
            case 0: {
                goto IL_008A;
            }
            case 1: {
                goto IL_008A;
            }
            case 2: {
                goto IL_00A2;
            }
            case 3: {
                goto IL_00B4;
            }
            case 4: {
                goto IL_00E1;
            }
            case 5: {
                goto IL_008A;
            }
            case 6: {
                goto IL_008A;
            }
            case 7: {
                goto IL_008A;
            }
            case 8: {
                goto IL_0124;
            }
            case 9: {
                goto IL_00FC;
            }
            case 10: {
                goto IL_00FC;
            }
            case 11: {
                goto IL_0124;
            }
            case 12: {
                goto IL_0124;
            }
            case 13: {
                goto IL_0124;
            }
            case 14: {
                goto IL_0124;
            }
            case 15: {
                goto IL_0124;
            }
            case 16: {
                goto IL_0124;
            }
            case 17: {
                goto IL_0124;
            }
            case 18: {
                goto IL_0124;
            }
            case 19: {
                goto IL_00C6;
            }
            default: {
                goto IL_0065;
            } }
        IL_0065: ;
        int v6 = unchecked((int)(l0));
        int v7 = 135;
        int v8 = unchecked(v6 - v7);
        switch (v8) {
            case 0: {
                goto IL_00FC;
            }
            case 1: {
                goto IL_008A;
            }
            case 2: {
                goto IL_008A;
            }
            case 3: {
                goto IL_008A;
            }
            case 4: {
                goto IL_0096;
            }
            default: {
                goto IL_0085;
            } }
        IL_0085: ;
        goto IL_0124;
        IL_008A: ;
        global::System.Xml.XmlSqlBinaryReader v9 = this;
        long v10 = __cil_direct_06000807(v9);
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v11 = __cil_newobj_0A0000B5(v10);
        return v11;
        IL_0096: ;
        global::System.Xml.XmlSqlBinaryReader v12 = this;
        long v13 = unchecked((long)(__cil_direct_06000808(v12)));
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v14 = __cil_newobj_0A0000B6(v13);
        return v14;
        IL_00A2: ;
        global::System.Xml.XmlSqlBinaryReader v15 = this;
        global::System.Xml.XmlSqlBinaryReader v16 = this;
        int v17 = v16._tokDataPos;
        __cil_F v18 = __cil_call_result_r4(__cil_direct_06000818(v15, v17));
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v19 = __cil_newobj_0A0000B7(v18);
        return v19;
        IL_00B4: ;
        global::System.Xml.XmlSqlBinaryReader v20 = this;
        global::System.Xml.XmlSqlBinaryReader v21 = this;
        int v22 = v21._tokDataPos;
        double v23 = __cil_direct_06000819(v20, v22);
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v24 = __cil_newobj_0A0000B8(v23);
        return v24;
        IL_00C6: ;
        ref __cil_value_094d148f100986f28432885961b9959bc8d16c44 v25 = ref l1;
        global::System.Xml.XmlSqlBinaryReader v26 = this;
        global::System.Xml.XmlSqlBinaryReader v27 = this;
        int v28 = v27._tokDataPos;
        int v29 = __cil_direct_06000814(v26, v28);
        __cil_value_ctor_06000840(ref v25, v29);
        ref __cil_value_094d148f100986f28432885961b9959bc8d16c44 v30 = ref l1;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v31 = __cil_direct_06000842(ref v30);
        return v31;
        IL_00E1: ;
        ref __cil_value_094d148f100986f28432885961b9959bc8d16c44 v32 = ref l2;
        global::System.Xml.XmlSqlBinaryReader v33 = this;
        global::System.Xml.XmlSqlBinaryReader v34 = this;
        int v35 = v34._tokDataPos;
        long v36 = __cil_direct_06000816(v33, v35);
        __cil_value_ctor_06000841(ref v32, v36);
        ref __cil_value_094d148f100986f28432885961b9959bc8d16c44 v37 = ref l2;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v38 = __cil_direct_06000842(ref v37);
        return v38;
        IL_00FC: ;
        ref __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a v39 = ref l3;
        global::System.Xml.XmlSqlBinaryReader v40 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v41 = v40._data;
        global::System.Xml.XmlSqlBinaryReader v42 = this;
        int v43 = v42._tokDataPos;
        global::System.Xml.XmlSqlBinaryReader v44 = this;
        int v45 = unchecked((int)(v44._token));
        int v46 = 135;
        int v47 = (v45 == v46 ? 1 : 0);
        __cil_value_ctor_06000837(ref v39, v41, v43, __cil_bool_store(v47));
        ref __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a v48 = ref l3;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v49 = __cil_direct_0600083C(ref v48);
        return v49;
        IL_0124: ;
        global::System.Xml.XmlSqlBinaryReader v50 = this;
        global::System.Xml.XmlSqlBinaryReader v51 = this;
        int v52 = unchecked((int)(v51._token));
        global::System.Exception v53 = __cil_direct_0600081A(v50, unchecked((__cil_enum_02000073)(v52)));
        throw v53;
    }

    private double ValueAsDouble()
    {
        // structural signature __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f bytes=1169: valuetype [System.Runtime]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        __cil_direct_06000804(this);
        int v2 = unchecked((int)(this._token));
        l0 = unchecked((__cil_enum_02000073)(v2));
        int v3 = unchecked((int)(l0));
        int v5 = unchecked(v3 - 1);
        switch (v5) {
            case 0: {
                goto IL_0087;
            }
            case 1: {
                goto IL_0087;
            }
            case 2: {
                goto IL_0098;
            }
            case 3: {
                goto IL_00A6;
            }
            case 4: {
                goto IL_00B3;
            }
            case 5: {
                goto IL_0087;
            }
            case 6: {
                goto IL_0087;
            }
            case 7: {
                goto IL_0087;
            }
            case 8: {
                goto IL_00C0;
            }
            case 9: {
                goto IL_00B3;
            }
            case 10: {
                goto IL_00B3;
            }
            case 11: {
                goto IL_00C0;
            }
            case 12: {
                goto IL_00C0;
            }
            case 13: {
                goto IL_00C0;
            }
            case 14: {
                goto IL_00C0;
            }
            case 15: {
                goto IL_00C0;
            }
            case 16: {
                goto IL_00C0;
            }
            case 17: {
                goto IL_00C0;
            }
            case 18: {
                goto IL_00C0;
            }
            case 19: {
                goto IL_00B3;
            }
            default: {
                goto IL_0065;
            } }
        IL_0065: ;
        int v6 = unchecked((int)(l0));
        int v8 = unchecked(v6 - 135);
        switch (v8) {
            case 0: {
                goto IL_00B3;
            }
            case 1: {
                goto IL_0087;
            }
            case 2: {
                goto IL_0087;
            }
            case 3: {
                goto IL_0087;
            }
            case 4: {
                goto IL_008F;
            }
            default: {
                goto IL_0085;
            } }
        IL_0085: ;
        goto IL_00C0;
        IL_0087: ;
        long v10 = __cil_direct_06000807(this);
        double v11 = __cil_conv_r8(v10);
        return unchecked((double)(v11));
        IL_008F: ;
        long v13 = unchecked((long)(__cil_direct_06000808(this)));
        double v14 = __cil_conv_r_u8(v13);
        double v15 = __cil_conv_r8(v14);
        return unchecked((double)(v15));
        IL_0098: ;
        int v18 = this._tokDataPos;
        __cil_F v19 = __cil_call_result_r4(__cil_direct_06000818(this, v18));
        double v20 = __cil_conv_r8(v19);
        return unchecked((double)(v20));
        IL_00A6: ;
        int v23 = this._tokDataPos;
        double v24 = __cil_direct_06000819(this, v23);
        return unchecked((double)(v24));
        IL_00B3: ;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v26 = __cil_direct_06000809(this);
        double v27 = System.Decimal.op_Explicit(v26);
        double v28 = __cil_conv_r8(v27);
        return unchecked((double)(v28));
        IL_00C0: ;
        int v31 = unchecked((int)(this._token));
        global::System.Exception v32 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v31)));
        throw v32;
    }

    private System.DateTime ValueAsDateTime()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b bytes=118145: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        uint l3 = default;
        short l5 = default;
        ushort l6 = default;
        __cil_direct_06000804(this);
        int v2 = unchecked((int)(this._token));
        l0 = unchecked((__cil_enum_02000073)(v2));
        int v3 = unchecked((int)(l0));
        if (v3 == 18) {
            goto IL_004D;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        int v5 = unchecked((int)(l0));
        if (v5 == 19) {
            goto IL_006E;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        int v7 = unchecked((int)(l0));
        int v9 = unchecked(v7 - 122);
        switch (v9) {
            case 0: {
                goto IL_0132;
            }
            case 1: {
                goto IL_0120;
            }
            case 2: {
                goto IL_010E;
            }
            case 3: {
                goto IL_00FC;
            }
            case 4: {
                goto IL_00EA;
            }
            case 5: {
                goto IL_00D8;
            }
            case 6: {
                goto IL_0144;
            }
            case 7: {
                goto IL_0096;
            }
            case 8: {
                goto IL_00C2;
            }
            case 9: {
                goto IL_00AC;
            }
            default: {
                goto IL_0048;
            } }
        IL_0048: ;
        goto IL_0144;
        IL_004D: ;
        int v11 = this._tokDataPos;
        int v14 = __cil_direct_06000814(this, v11);
        int v18 = unchecked(v11 + 4);
        int v19 = unchecked((int)(__cil_direct_06000815(this, v18)));
        l3 = unchecked((uint)(v19));
        int v21 = unchecked((int)(l3));
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v22 = System.Xml.BinXmlDateTime.SqlDateTimeToDateTime(v14, unchecked((uint)(v21)));
        return v22;
        IL_006E: ;
        int v24 = this._tokDataPos;
        int v27 = unchecked((int)(__cil_direct_06000812(this, v24)));
        l5 = unchecked((short)(v27));
        int v31 = unchecked(v24 + 2);
        int v32 = unchecked((int)(__cil_direct_06000813(this, v31)));
        l6 = unchecked((ushort)(v32));
        int v33 = unchecked((int)(l5));
        int v34 = unchecked((int)(l6));
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v35 = System.Xml.BinXmlDateTime.SqlSmallDateTimeToDateTime(unchecked((short)(v33)), unchecked((ushort)(v34)));
        return v35;
        IL_0096: ;
        int v38 = this._tokDataPos;
        long v39 = __cil_direct_06000816(this, v38);
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v41 = System.Xml.BinXmlDateTime.XsdTimeToDateTime(v39);
        return v41;
        IL_00AC: ;
        int v44 = this._tokDataPos;
        long v45 = __cil_direct_06000816(this, v44);
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v47 = System.Xml.BinXmlDateTime.XsdDateToDateTime(v45);
        return v47;
        IL_00C2: ;
        int v50 = this._tokDataPos;
        long v51 = __cil_direct_06000816(this, v50);
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v53 = System.Xml.BinXmlDateTime.XsdDateTimeToDateTime(v51);
        return v53;
        IL_00D8: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v55 = this._data;
        int v57 = this._tokDataPos;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v58 = System.Xml.BinXmlDateTime.XsdKatmaiDateToDateTime(v55, v57);
        return v58;
        IL_00EA: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v60 = this._data;
        int v62 = this._tokDataPos;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v63 = System.Xml.BinXmlDateTime.XsdKatmaiDateTimeToDateTime(v60, v62);
        return v63;
        IL_00FC: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v65 = this._data;
        int v67 = this._tokDataPos;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v68 = System.Xml.BinXmlDateTime.XsdKatmaiTimeToDateTime(v65, v67);
        return v68;
        IL_010E: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v70 = this._data;
        int v72 = this._tokDataPos;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v73 = System.Xml.BinXmlDateTime.XsdKatmaiDateOffsetToDateTime(v70, v72);
        return v73;
        IL_0120: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v75 = this._data;
        int v77 = this._tokDataPos;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v78 = System.Xml.BinXmlDateTime.XsdKatmaiDateTimeOffsetToDateTime(v75, v77);
        return v78;
        IL_0132: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v80 = this._data;
        int v82 = this._tokDataPos;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v83 = System.Xml.BinXmlDateTime.XsdKatmaiTimeOffsetToDateTime(v80, v82);
        return v83;
        IL_0144: ;
        int v86 = unchecked((int)(this._token));
        global::System.Exception v87 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v86)));
        throw v87;
    }

    private System.DateTimeOffset ValueAsDateTimeOffset()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 bytes=118159: valuetype [System.Runtime]System.DateTimeOffset; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        __cil_direct_06000804(this);
        int v2 = unchecked((int)(this._token));
        l0 = unchecked((__cil_enum_02000073)(v2));
        int v3 = unchecked((int)(l0));
        int v5 = unchecked(v3 - 122);
        switch (v5) {
            case 0: {
                goto IL_0048;
            }
            case 1: {
                goto IL_0036;
            }
            case 2: {
                goto IL_0024;
            }
            default: {
                goto IL_0022;
            } }
        IL_0022: ;
        goto IL_005A;
        IL_0024: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v7 = this._data;
        int v9 = this._tokDataPos;
        __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 v10 = System.Xml.BinXmlDateTime.XsdKatmaiDateOffsetToDateTimeOffset(v7, v9);
        return v10;
        IL_0036: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v12 = this._data;
        int v14 = this._tokDataPos;
        __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 v15 = System.Xml.BinXmlDateTime.XsdKatmaiDateTimeOffsetToDateTimeOffset(v12, v14);
        return v15;
        IL_0048: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v17 = this._data;
        int v19 = this._tokDataPos;
        __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 v20 = System.Xml.BinXmlDateTime.XsdKatmaiTimeOffsetToDateTimeOffset(v17, v19);
        return v20;
        IL_005A: ;
        int v23 = unchecked((int)(this._token));
        global::System.Exception v24 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v23)));
        throw v24;
    }

    private string ValueAsDateTimeString()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000073 l0 = default;
        uint l3 = default;
        short l5 = default;
        ushort l6 = default;
        __cil_direct_06000804(this);
        int v2 = unchecked((int)(this._token));
        l0 = unchecked((__cil_enum_02000073)(v2));
        int v3 = unchecked((int)(l0));
        if (v3 == 18) {
            goto IL_004D;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        int v5 = unchecked((int)(l0));
        if (v5 == 19) {
            goto IL_006E;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        int v7 = unchecked((int)(l0));
        int v9 = unchecked(v7 - 122);
        switch (v9) {
            case 0: {
                goto IL_0132;
            }
            case 1: {
                goto IL_0120;
            }
            case 2: {
                goto IL_010E;
            }
            case 3: {
                goto IL_00FC;
            }
            case 4: {
                goto IL_00EA;
            }
            case 5: {
                goto IL_00D8;
            }
            case 6: {
                goto IL_0144;
            }
            case 7: {
                goto IL_0096;
            }
            case 8: {
                goto IL_00C2;
            }
            case 9: {
                goto IL_00AC;
            }
            default: {
                goto IL_0048;
            } }
        IL_0048: ;
        goto IL_0144;
        IL_004D: ;
        int v11 = this._tokDataPos;
        int v14 = __cil_direct_06000814(this, v11);
        int v18 = unchecked(v11 + 4);
        int v19 = unchecked((int)(__cil_direct_06000815(this, v18)));
        l3 = unchecked((uint)(v19));
        int v21 = unchecked((int)(l3));
        string v22 = System.Xml.BinXmlDateTime.SqlDateTimeToString(v14, unchecked((uint)(v21)));
        return v22;
        IL_006E: ;
        int v24 = this._tokDataPos;
        int v27 = unchecked((int)(__cil_direct_06000812(this, v24)));
        l5 = unchecked((short)(v27));
        int v31 = unchecked(v24 + 2);
        int v32 = unchecked((int)(__cil_direct_06000813(this, v31)));
        l6 = unchecked((ushort)(v32));
        int v33 = unchecked((int)(l5));
        int v34 = unchecked((int)(l6));
        string v35 = System.Xml.BinXmlDateTime.SqlSmallDateTimeToString(unchecked((short)(v33)), unchecked((ushort)(v34)));
        return v35;
        IL_0096: ;
        int v38 = this._tokDataPos;
        long v39 = __cil_direct_06000816(this, v38);
        string v41 = System.Xml.BinXmlDateTime.XsdTimeToString(v39);
        return v41;
        IL_00AC: ;
        int v44 = this._tokDataPos;
        long v45 = __cil_direct_06000816(this, v44);
        string v47 = System.Xml.BinXmlDateTime.XsdDateToString(v45);
        return v47;
        IL_00C2: ;
        int v50 = this._tokDataPos;
        long v51 = __cil_direct_06000816(this, v50);
        string v53 = System.Xml.BinXmlDateTime.XsdDateTimeToString(v51);
        return v53;
        IL_00D8: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v55 = this._data;
        int v57 = this._tokDataPos;
        string v58 = System.Xml.BinXmlDateTime.XsdKatmaiDateToString(v55, v57);
        return v58;
        IL_00EA: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v60 = this._data;
        int v62 = this._tokDataPos;
        string v63 = System.Xml.BinXmlDateTime.XsdKatmaiDateTimeToString(v60, v62);
        return v63;
        IL_00FC: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v65 = this._data;
        int v67 = this._tokDataPos;
        string v68 = System.Xml.BinXmlDateTime.XsdKatmaiTimeToString(v65, v67);
        return v68;
        IL_010E: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v70 = this._data;
        int v72 = this._tokDataPos;
        string v73 = System.Xml.BinXmlDateTime.XsdKatmaiDateOffsetToString(v70, v72);
        return v73;
        IL_0120: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v75 = this._data;
        int v77 = this._tokDataPos;
        string v78 = System.Xml.BinXmlDateTime.XsdKatmaiDateTimeOffsetToString(v75, v77);
        return v78;
        IL_0132: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v80 = this._data;
        int v82 = this._tokDataPos;
        string v83 = System.Xml.BinXmlDateTime.XsdKatmaiTimeOffsetToString(v80, v82);
        return v83;
        IL_0144: ;
        int v86 = unchecked((int)(this._token));
        global::System.Exception v87 = __cil_direct_0600081A(this, unchecked((__cil_enum_02000073)(v86)));
        throw v87;
    }

    private string ValueAsString(System.Xml.BinXmlToken token)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 14
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, 04, 08, 00, 06, 03, 17, 59, 45, 1B, 00, 00, 00, 97, 00, 00, 00, 97, 00, 00, 00, C9, 00]
        // .code-bytes IL_0018: [00, 00, E0, 00, 00, 00, C4, 01, 00, 00, 97, 00, 00, 00, 97, 00, 00, 00, 97, 00, 00, 00, F7, 00]
        // .code-bytes IL_0030: [00, 00, EA, 01, 00, 00, EA, 01, 00, 00, 52, 02, 00, 00, 18, 02, 00, 00, 5A, 00, 00, 00, 52, 02]
        // .code-bytes IL_0048: [00, 00, 18, 02, 00, 00, 5A, 00, 00, 00, 8C, 02, 00, 00, 8C, 02, 00, 00, 9E, 01, 00, 00, 11, 03]
        // .code-bytes IL_0060: [00, 00, 18, 02, 00, 00, 52, 02, 00, 00, 5A, 00, 00, 00, 11, 03, 00, 00, 11, 03, 00, 00, 52, 02]
        // .code-bytes IL_0078: [00, 00, 03, 1F, 7A, 59, 45, 13, 00, 00, 00, 37, 02, 00, 00, 37, 02, 00, 00, 37, 02, 00, 00, 37]
        // .code-bytes IL_0090: [02, 00, 00, 37, 02, 00, 00, 37, 02, 00, 00, BC, 02, 00, 00, 37, 02, 00, 00, 37, 02, 00, 00, 37]
        // .code-bytes IL_00A8: [02, 00, 00, 1A, 02, 00, 00, FD, 01, 00, 00, 1D, 00, 00, 00, 95, 01, 00, 00, 42, 00, 00, 00, 42]
        // .code-bytes IL_00C0: [00, 00, 00, 42, 00, 00, 00, 5B, 00, 00, 00, 43, 02, 00, 00, 38, B7, 02, 00, 00, 02, 02, 7B, A5]
        // .code-bytes IL_00D8: [01, 00, 04, 02, 7B, A4, 01, 00, 04, 28, DB, 07, 00, 06, 0A, DD, B6, 02, 00, 00, 02, 7B, 86, 01]
        // .code-bytes IL_00F0: [00, 04, 02, 7B, A5, 01, 00, 04, 91, 2D, 0B, 72, 21, 00, 00, 70, 0A, DD, 9C, 02, 00, 00, 72, 2D]
        // .code-bytes IL_0108: [00, 00, 70, 0A, DD, 91, 02, 00, 00, 02, 28, 07, 08, 00, 06, 0B, 12, 01, 28, 5C, 00, 00, 0A, 28]
        // .code-bytes IL_0120: [B9, 00, 00, 0A, 0A, DD, 78, 02, 00, 00, 02, 28, 08, 08, 00, 06, 0C, 12, 02, 28, 5C, 00, 00, 0A]
        // .code-bytes IL_0138: [28, BA, 00, 00, 0A, 0A, DD, 5F, 02, 00, 00, 02, 02, 7B, A5, 01, 00, 04, 28, 18, 08, 00, 06, 28]
        // .code-bytes IL_0150: [64, 09, 00, 06, 0A, DD, 48, 02, 00, 00, 02, 02, 7B, A5, 01, 00, 04, 28, 19, 08, 00, 06, 28, 65]
        // .code-bytes IL_0168: [09, 00, 06, 0A, DD, 31, 02, 00, 00, 02, 7B, A5, 01, 00, 04, 13, 06, 02, 11, 06, 28, 14, 08, 00]
        // .code-bytes IL_0180: [06, 0D, 02, 11, 06, 1A, 58, 28, 12, 08, 00, 06, 13, 04, 02, 11, 06, 1C, 58, 28, 12, 08, 00, 06]
        // .code-bytes IL_0198: [13, 05, 12, 07, 09, 11, 04, 11, 05, 02, 7B, 86, 01, 00, 04, 11, 06, 1E, 58, 91, 02, 7B, 86, 01]
        // .code-bytes IL_01B0: [00, 04, 11, 06, 1F, 09, 58, 91, 02, 7B, 86, 01, 00, 04, 11, 06, 1F, 0A, 58, 91, 02, 7B, 86, 01]
        // .code-bytes IL_01C8: [00, 04, 11, 06, 1F, 0B, 58, 91, 02, 7B, 86, 01, 00, 04, 11, 06, 1F, 0C, 58, 91, 02, 7B, 86, 01]
        // .code-bytes IL_01E0: [00, 04, 11, 06, 1F, 0D, 58, 91, 02, 7B, 86, 01, 00, 04, 11, 06, 1F, 0E, 58, 91, 02, 7B, 86, 01]
        // .code-bytes IL_01F8: [00, 04, 11, 06, 1F, 0F, 58, 91, 28, BB, 00, 00, 0A, 12, 07, FE, 16, 57, 00, 00, 01, 6F, 09, 00]
        // .code-bytes IL_0210: [00, 0A, 0A, DD, 8A, 01, 00, 00, 12, 08, 02, 02, 7B, A5, 01, 00, 04, 28, 14, 08, 00, 06, 28, 40]
        // .code-bytes IL_0228: [08, 00, 06, 12, 08, FE, 16, 75, 00, 00, 02, 6F, 09, 00, 00, 0A, 0A, DD, 64, 01, 00, 00, 12, 09]
        // .code-bytes IL_0240: [02, 02, 7B, A5, 01, 00, 04, 28, 16, 08, 00, 06, 28, 41, 08, 00, 06, 12, 09, FE, 16, 75, 00, 00]
        // .code-bytes IL_0258: [02, 6F, 09, 00, 00, 0A, 0A, DD, 3E, 01, 00, 00, 12, 0A, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01]
        // .code-bytes IL_0270: [00, 04, 03, 20, 87, 00, 00, 00, FE, 01, 28, 37, 08, 00, 06, 12, 0A, FE, 16, 74, 00, 00, 02, 6F]
        // .code-bytes IL_0288: [09, 00, 00, 0A, 0A, DD, 10, 01, 00, 00, 02, 7B, A5, 01, 00, 04, 13, 0B, 02, 11, 0B, 28, 14, 08]
        // .code-bytes IL_02A0: [00, 06, 13, 0C, 11, 0C, 28, BC, 00, 00, 0A, 13, 0D, 11, 0D, 02, 7B, 86, 01, 00, 04, 11, 0B, 1A]
        // .code-bytes IL_02B8: [58, 02, 7B, A4, 01, 00, 04, 1A, 59, 6F, AF, 00, 00, 0A, 0A, DD, D6, 00, 00, 00, 02, 7B, 86, 01]
        // .code-bytes IL_02D0: [00, 04, 02, 7B, A5, 01, 00, 04, 02, 7B, A4, 01, 00, 04, 28, BD, 00, 00, 0A, 0A, DD, B9, 00, 00]
        // .code-bytes IL_02E8: [00, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01, 00, 04, 02, 7B, A4, 01, 00, 04, 28, A9, 08, 00, 06]
        // .code-bytes IL_0300: [0A, DD, 9C, 00, 00, 00, 02, 28, 0D, 08, 00, 06, 0A, DD, 90, 00, 00, 00, 02, 02, 7B, A5, 01, 00]
        // .code-bytes IL_0318: [04, 28, D0, 07, 00, 06, 13, 0E, 11, 0E, 16, 32, 0F, 11, 0E, 02, 7C, 8F, 01, 00, 04, 7B, D6, 01]
        // .code-bytes IL_0330: [00, 04, 32, 10, 28, 08, 06, 00, 06, 7E, 02, 00, 00, 0A, 73, 0B, 0A, 00, 06, 7A, 02, 7C, 8F, 01]
        // .code-bytes IL_0348: [00, 04, 7B, D5, 01, 00, 04, 11, 0E, A3, 6D, 00, 00, 02, 13, 0F, 11, 0F, 7B, C0, 01, 00, 04, 6F]
        // .code-bytes IL_0360: [03, 00, 00, 0A, 2D, 0A, 11, 0F, 7B, C1, 01, 00, 04, 0A, DE, 32, 11, 0F, 7B, C0, 01, 00, 04, 72]
        // .code-bytes IL_0378: [01, 00, 00, 70, 11, 0F, 7B, C1, 01, 00, 04, 28, 2B, 00, 00, 0A, 0A, DE, 17, 02, 02, 7B, 98, 01]
        // .code-bytes IL_0390: [00, 04, 28, 1A, 08, 00, 06, 7A, 26, 02, 1C, 7D, 96, 01, 00, 04, FE, 1A, 06, 2A]
        // .local [0] string
        // .local [1] int64
        // .local [2] uint64
        // .local [3] int32
        // .local [4] int16
        // .local [5] int16
        // .local [6] int32
        // .local [7] valuetype [System.Runtime]System.Guid
        // .local [8] valuetype System.Xml.BinXmlSqlMoney
        // .local [9] valuetype System.Xml.BinXmlSqlMoney
        // .local [10] valuetype System.Xml.BinXmlSqlDecimal
        // .local [11] int32
        // .local [12] int32
        // .local [13] class [System.Runtime]System.Text.Encoding
        // .local [14] int32
        // .local [15] valuetype System.Xml.XmlSqlBinaryReader/QName
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x06000804 System.Xml.XmlSqlBinaryReader::CheckValueTokenBounds
        // IL_0006: ldarg.1 1
        // IL_0007: ldc.i4.1 1
        // IL_0008: sub 
        // IL_0009: switch IL_0111, IL_0111, IL_0143, IL_015A, IL_023E, IL_0111, IL_0111, IL_0111, IL_0171, IL_0264, IL_0264, IL_02CC, IL_0292, IL_00D4, IL_02CC, IL_0292, IL_00D4, IL_0306, IL_0306, IL_0218, IL_038B, IL_0292, IL_02CC, IL_00D4, IL_038B, IL_038B, IL_02CC
        // IL_007A: ldarg.1 1
        // IL_007B: ldc.i4.s 122
        // IL_007D: sub 
        // IL_007E: switch IL_0306, IL_0306, IL_0306, IL_0306, IL_0306, IL_0306, IL_038B, IL_0306, IL_0306, IL_0306, IL_02E9, IL_02CC, IL_00EC, IL_0264, IL_0111, IL_0111, IL_0111, IL_012A, IL_0312
        // IL_00CF: br IL_038B
        // IL_00D4: ldarg.0 0
        // IL_00D5: ldarg.0 0
        // IL_00D6: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00DB: ldarg.0 0
        // IL_00DC: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_00E1: call 0x060007DB System.Xml.XmlSqlBinaryReader::GetString
        // IL_00E6: stloc.0 0
        // IL_00E7: leave IL_03A2
        // IL_00EC: ldarg.0 0
        // IL_00ED: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_00F2: ldarg.0 0
        // IL_00F3: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00F8: ldelem.u1 
        // IL_00F9: brtrue.s IL_0106
        // IL_00FB: ldstr 0x70000021 [102, 97, 108, 115, 101] utf16-bytes=[66, 00, 61, 00, 6C, 00, 73, 00, 65, 00] terminal-flag=Some(0)
        // IL_0100: stloc.0 0
        // IL_0101: leave IL_03A2
        // IL_0106: ldstr 0x7000002D [116, 114, 117, 101] utf16-bytes=[74, 00, 72, 00, 75, 00, 65, 00] terminal-flag=Some(0)
        // IL_010B: stloc.0 0
        // IL_010C: leave IL_03A2
        // IL_0111: ldarg.0 0
        // IL_0112: call 0x06000807 System.Xml.XmlSqlBinaryReader::ValueAsLong
        // IL_0117: stloc.1 1
        // IL_0118: ldloca.s 1
        // IL_011A: call 0x0A00005C [System.Runtime]System.Globalization.CultureInfo::get_InvariantCulture
        // IL_011F: call 0x0A0000B9 [System.Runtime]System.Int64::ToString
        // IL_0124: stloc.0 0
        // IL_0125: leave IL_03A2
        // IL_012A: ldarg.0 0
        // IL_012B: call 0x06000808 System.Xml.XmlSqlBinaryReader::ValueAsULong
        // IL_0130: stloc.2 2
        // IL_0131: ldloca.s 2
        // IL_0133: call 0x0A00005C [System.Runtime]System.Globalization.CultureInfo::get_InvariantCulture
        // IL_0138: call 0x0A0000BA [System.Runtime]System.UInt64::ToString
        // IL_013D: stloc.0 0
        // IL_013E: leave IL_03A2
        // IL_0143: ldarg.0 0
        // IL_0144: ldarg.0 0
        // IL_0145: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_014A: call 0x06000818 System.Xml.XmlSqlBinaryReader::GetSingle
        // IL_014F: call 0x06000964 System.Xml.XmlConvert::ToString
        // IL_0154: stloc.0 0
        // IL_0155: leave IL_03A2
        // IL_015A: ldarg.0 0
        // IL_015B: ldarg.0 0
        // IL_015C: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0161: call 0x06000819 System.Xml.XmlSqlBinaryReader::GetDouble
        // IL_0166: call 0x06000965 System.Xml.XmlConvert::ToString
        // IL_016B: stloc.0 0
        // IL_016C: leave IL_03A2
        // IL_0171: ldarg.0 0
        // IL_0172: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0177: stloc.s 6
        // IL_0179: ldarg.0 0
        // IL_017A: ldloc.s 6
        // IL_017C: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_0181: stloc.3 3
        // IL_0182: ldarg.0 0
        // IL_0183: ldloc.s 6
        // IL_0185: ldc.i4.4 4
        // IL_0186: add 
        // IL_0187: call 0x06000812 System.Xml.XmlSqlBinaryReader::GetInt16
        // IL_018C: stloc.s 4
        // IL_018E: ldarg.0 0
        // IL_018F: ldloc.s 6
        // IL_0191: ldc.i4.6 6
        // IL_0192: add 
        // IL_0193: call 0x06000812 System.Xml.XmlSqlBinaryReader::GetInt16
        // IL_0198: stloc.s 5
        // IL_019A: ldloca.s 7
        // IL_019C: ldloc.3 3
        // IL_019D: ldloc.s 4
        // IL_019F: ldloc.s 5
        // IL_01A1: ldarg.0 0
        // IL_01A2: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01A7: ldloc.s 6
        // IL_01A9: ldc.i4.8 8
        // IL_01AA: add 
        // IL_01AB: ldelem.u1 
        // IL_01AC: ldarg.0 0
        // IL_01AD: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01B2: ldloc.s 6
        // IL_01B4: ldc.i4.s 9
        // IL_01B6: add 
        // IL_01B7: ldelem.u1 
        // IL_01B8: ldarg.0 0
        // IL_01B9: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01BE: ldloc.s 6
        // IL_01C0: ldc.i4.s 10
        // IL_01C2: add 
        // IL_01C3: ldelem.u1 
        // IL_01C4: ldarg.0 0
        // IL_01C5: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01CA: ldloc.s 6
        // IL_01CC: ldc.i4.s 11
        // IL_01CE: add 
        // IL_01CF: ldelem.u1 
        // IL_01D0: ldarg.0 0
        // IL_01D1: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01D6: ldloc.s 6
        // IL_01D8: ldc.i4.s 12
        // IL_01DA: add 
        // IL_01DB: ldelem.u1 
        // IL_01DC: ldarg.0 0
        // IL_01DD: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01E2: ldloc.s 6
        // IL_01E4: ldc.i4.s 13
        // IL_01E6: add 
        // IL_01E7: ldelem.u1 
        // IL_01E8: ldarg.0 0
        // IL_01E9: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01EE: ldloc.s 6
        // IL_01F0: ldc.i4.s 14
        // IL_01F2: add 
        // IL_01F3: ldelem.u1 
        // IL_01F4: ldarg.0 0
        // IL_01F5: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01FA: ldloc.s 6
        // IL_01FC: ldc.i4.s 15
        // IL_01FE: add 
        // IL_01FF: ldelem.u1 
        // IL_0200: call 0x0A0000BB [System.Runtime]System.Guid::.ctor
        // IL_0205: ldloca.s 7
        // IL_0207: constrained. 0x01000057 [System.Runtime]System.Guid
        // IL_020D: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
        // IL_0212: stloc.0 0
        // IL_0213: leave IL_03A2
        // IL_0218: ldloca.s 8
        // IL_021A: ldarg.0 0
        // IL_021B: ldarg.0 0
        // IL_021C: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0221: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_0226: call 0x06000840 System.Xml.BinXmlSqlMoney::.ctor
        // IL_022B: ldloca.s 8
        // IL_022D: constrained. 0x02000075 System.Xml.BinXmlSqlMoney
        // IL_0233: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
        // IL_0238: stloc.0 0
        // IL_0239: leave IL_03A2
        // IL_023E: ldloca.s 9
        // IL_0240: ldarg.0 0
        // IL_0241: ldarg.0 0
        // IL_0242: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0247: call 0x06000816 System.Xml.XmlSqlBinaryReader::GetInt64
        // IL_024C: call 0x06000841 System.Xml.BinXmlSqlMoney::.ctor
        // IL_0251: ldloca.s 9
        // IL_0253: constrained. 0x02000075 System.Xml.BinXmlSqlMoney
        // IL_0259: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
        // IL_025E: stloc.0 0
        // IL_025F: leave IL_03A2
        // IL_0264: ldloca.s 10
        // IL_0266: ldarg.0 0
        // IL_0267: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_026C: ldarg.0 0
        // IL_026D: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0272: ldarg.1 1
        // IL_0273: ldc.i4 135
        // IL_0278: ceq 
        // IL_027A: call 0x06000837 System.Xml.BinXmlSqlDecimal::.ctor
        // IL_027F: ldloca.s 10
        // IL_0281: constrained. 0x02000074 System.Xml.BinXmlSqlDecimal
        // IL_0287: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
        // IL_028C: stloc.0 0
        // IL_028D: leave IL_03A2
        // IL_0292: ldarg.0 0
        // IL_0293: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0298: stloc.s 11
        // IL_029A: ldarg.0 0
        // IL_029B: ldloc.s 11
        // IL_029D: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_02A2: stloc.s 12
        // IL_02A4: ldloc.s 12
        // IL_02A6: call 0x0A0000BC [System.Runtime]System.Text.Encoding::GetEncoding
        // IL_02AB: stloc.s 13
        // IL_02AD: ldloc.s 13
        // IL_02AF: ldarg.0 0
        // IL_02B0: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_02B5: ldloc.s 11
        // IL_02B7: ldc.i4.4 4
        // IL_02B8: add 
        // IL_02B9: ldarg.0 0
        // IL_02BA: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_02BF: ldc.i4.4 4
        // IL_02C0: sub 
        // IL_02C1: callvirt 0x0A0000AF [System.Runtime]System.Text.Encoding::GetString
        // IL_02C6: stloc.0 0
        // IL_02C7: leave IL_03A2
        // IL_02CC: ldarg.0 0
        // IL_02CD: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_02D2: ldarg.0 0
        // IL_02D3: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_02D8: ldarg.0 0
        // IL_02D9: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_02DE: call 0x0A0000BD [System.Runtime.Extensions]System.Convert::ToBase64String
        // IL_02E3: stloc.0 0
        // IL_02E4: leave IL_03A2
        // IL_02E9: ldarg.0 0
        // IL_02EA: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_02EF: ldarg.0 0
        // IL_02F0: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_02F5: ldarg.0 0
        // IL_02F6: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_02FB: call 0x060008A9 System.Xml.BinHexEncoder::Encode
        // IL_0300: stloc.0 0
        // IL_0301: leave IL_03A2
        // IL_0306: ldarg.0 0
        // IL_0307: call 0x0600080D System.Xml.XmlSqlBinaryReader::ValueAsDateTimeString
        // IL_030C: stloc.0 0
        // IL_030D: leave IL_03A2
        // IL_0312: ldarg.0 0
        // IL_0313: ldarg.0 0
        // IL_0314: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0319: call 0x060007D0 System.Xml.XmlSqlBinaryReader::ParseMB32
        // IL_031E: stloc.s 14
        // IL_0320: ldloc.s 14
        // IL_0322: ldc.i4.0 0
        // IL_0323: blt.s IL_0334
        // IL_0325: ldloc.s 14
        // IL_0327: ldarg.0 0
        // IL_0328: ldflda 0x0400018F System.Xml.XmlSqlBinaryReader::_symbolTables
        // IL_032D: ldfld 0x040001D6 System.Xml.XmlSqlBinaryReader/SymbolTables::qnameCount
        // IL_0332: blt.s IL_0344
        // IL_0334: call 0x06000608 System.SR::get_XmlBin_InvalidQNameID
        // IL_0339: ldsfld 0x0A000002 [System.Runtime]System.String::Empty
        // IL_033E: newobj 0x06000A0B System.Xml.XmlException::.ctor
        // IL_0343: throw 
        // IL_0344: ldarg.0 0
        // IL_0345: ldflda 0x0400018F System.Xml.XmlSqlBinaryReader::_symbolTables
        // IL_034A: ldfld 0x040001D5 System.Xml.XmlSqlBinaryReader/SymbolTables::qnametable
        // IL_034F: ldloc.s 14
        // IL_0351: ldelem 0x0200006D System.Xml.XmlSqlBinaryReader/QName
        // IL_0356: stloc.s 15
        // IL_0358: ldloc.s 15
        // IL_035A: ldfld 0x040001C0 System.Xml.XmlSqlBinaryReader/QName::prefix
        // IL_035F: callvirt 0x0A000003 [System.Runtime]System.String::get_Length
        // IL_0364: brtrue.s IL_0370
        // IL_0366: ldloc.s 15
        // IL_0368: ldfld 0x040001C1 System.Xml.XmlSqlBinaryReader/QName::localname
        // IL_036D: stloc.0 0
        // IL_036E: leave.s IL_03A2
        // IL_0370: ldloc.s 15
        // IL_0372: ldfld 0x040001C0 System.Xml.XmlSqlBinaryReader/QName::prefix
        // IL_0377: ldstr 0x70000001 [58] utf16-bytes=[3A, 00] terminal-flag=Some(0)
        // IL_037C: ldloc.s 15
        // IL_037E: ldfld 0x040001C1 System.Xml.XmlSqlBinaryReader/QName::localname
        // IL_0383: call 0x0A00002B [System.Runtime]System.String::Concat
        // IL_0388: stloc.0 0
        // IL_0389: leave.s IL_03A2
        // IL_038B: ldarg.0 0
        // IL_038C: ldarg.0 0
        // IL_038D: ldfld 0x04000198 System.Xml.XmlSqlBinaryReader::_token
        // IL_0392: call 0x0600081A System.Xml.XmlSqlBinaryReader::ThrowUnexpectedToken
        // IL_0397: throw 
        // IL_0398: pop 
        // IL_0399: ldarg.0 0
        // IL_039A: ldc.i4.6 6
        // IL_039B: stfld 0x04000196 System.Xml.XmlSqlBinaryReader::_state
        // IL_03A0: rethrow 
        // IL_03A2: ldloc.0 0
        // IL_03A3: ret 
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[1])), try_offset: 0, try_length: 920, handler_offset: 920, handler_length: 10, raw_flags: 0 }
        // .try IL_0000..IL_0398 catch 0x01000001 [System.Runtime]System.Object IL_0398..IL_03A2
    }

    private object ValueAsObject(System.Xml.BinXmlToken token, bool returnInternalTypes)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 14
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, 04, 08, 00, 06, 03, 17, 59, 45, 1B, 00, 00, 00, A9, 00, 00, 00, BB, 00, 00, 00, 2B, 01]
        // .code-bytes IL_0018: [00, 00, 3D, 01, 00, 00, 18, 02, 00, 00, 83, 00, 00, 00, 96, 00, 00, 00, CD, 00, 00, 00, 4F, 01]
        // .code-bytes IL_0030: [00, 00, 43, 02, 00, 00, 43, 02, 00, 00, AB, 02, 00, 00, 76, 02, 00, 00, 5A, 00, 00, 00, AB, 02]
        // .code-bytes IL_0048: [00, 00, 76, 02, 00, 00, 5A, 00, 00, 00, D5, 02, 00, 00, D5, 02, 00, 00, ED, 01, 00, 00, 47, 03]
        // .code-bytes IL_0060: [00, 00, 76, 02, 00, 00, AB, 02, 00, 00, 5A, 00, 00, 00, 47, 03, 00, 00, 47, 03, 00, 00, AB, 02]
        // .code-bytes IL_0078: [00, 00, 03, 1F, 7A, 59, 45, 13, 00, 00, 00, 8C, 02, 00, 00, 8C, 02, 00, 00, 8C, 02, 00, 00, 80]
        // .code-bytes IL_0090: [02, 00, 00, 80, 02, 00, 00, 80, 02, 00, 00, F2, 02, 00, 00, 80, 02, 00, 00, 80, 02, 00, 00, 80]
        // .code-bytes IL_00A8: [02, 00, 00, 56, 02, 00, 00, 56, 02, 00, 00, 18, 00, 00, 00, EE, 01, 00, 00, 8A, 00, 00, 00, A0]
        // .code-bytes IL_00C0: [00, 00, 00, B2, 00, 00, 00, C4, 00, 00, 00, 98, 02, 00, 00, 38, ED, 02, 00, 00, 02, 02, 7B, A5]
        // .code-bytes IL_00D8: [01, 00, 04, 02, 7B, A4, 01, 00, 04, 28, DB, 07, 00, 06, 2A, 02, 7B, 86, 01, 00, 04, 02, 7B, A5]
        // .code-bytes IL_00F0: [01, 00, 04, 91, 16, FE, 03, 8C, 06, 00, 00, 01, 2A, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01, 00]
        // .code-bytes IL_0108: [04, 91, 8C, 13, 00, 00, 01, 2A, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01, 00, 04, 91, 8C, 3E, 00]
        // .code-bytes IL_0120: [00, 01, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 12, 08, 00, 06, 8C, 14, 00, 00, 01, 2A, 02, 02, 7B]
        // .code-bytes IL_0138: [A5, 01, 00, 04, 28, 14, 08, 00, 06, 8C, 13, 00, 00, 01, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 16]
        // .code-bytes IL_0150: [08, 00, 06, 8C, 15, 00, 00, 01, 2A, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01, 00, 04, 91, 67, 0A]
        // .code-bytes IL_0168: [06, 8C, 55, 00, 00, 01, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 13, 08, 00, 06, 8C, 17, 00, 00, 01]
        // .code-bytes IL_0180: [2A, 02, 02, 7B, A5, 01, 00, 04, 28, 15, 08, 00, 06, 8C, 16, 00, 00, 01, 2A, 02, 02, 7B, A5, 01]
        // .code-bytes IL_0198: [00, 04, 28, 17, 08, 00, 06, 8C, 18, 00, 00, 01, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 18, 08, 00]
        // .code-bytes IL_01B0: [06, 8C, 19, 00, 00, 01, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, 19, 08, 00, 06, 8C, 07, 00, 00, 01]
        // .code-bytes IL_01C8: [2A, 02, 7B, A5, 01, 00, 04, 13, 04, 02, 11, 04, 28, 14, 08, 00, 06, 0B, 02, 11, 04, 1A, 58, 28]
        // .code-bytes IL_01E0: [12, 08, 00, 06, 0C, 02, 11, 04, 1C, 58, 28, 12, 08, 00, 06, 0D, 12, 05, 07, 08, 09, 02, 7B, 86]
        // .code-bytes IL_01F8: [01, 00, 04, 11, 04, 1E, 58, 91, 02, 7B, 86, 01, 00, 04, 11, 04, 1F, 09, 58, 91, 02, 7B, 86, 01]
        // .code-bytes IL_0210: [00, 04, 11, 04, 1F, 0A, 58, 91, 02, 7B, 86, 01, 00, 04, 11, 04, 1F, 0B, 58, 91, 02, 7B, 86, 01]
        // .code-bytes IL_0228: [00, 04, 11, 04, 1F, 0C, 58, 91, 02, 7B, 86, 01, 00, 04, 11, 04, 1F, 0D, 58, 91, 02, 7B, 86, 01]
        // .code-bytes IL_0240: [00, 04, 11, 04, 1F, 0E, 58, 91, 02, 7B, 86, 01, 00, 04, 11, 04, 1F, 0F, 58, 91, 28, BB, 00, 00]
        // .code-bytes IL_0258: [0A, 12, 05, FE, 16, 57, 00, 00, 01, 6F, 09, 00, 00, 0A, 2A, 12, 06, 02, 02, 7B, A5, 01, 00, 04]
        // .code-bytes IL_0270: [28, 14, 08, 00, 06, 28, 40, 08, 00, 06, 04, 2C, 08, 11, 06, 8C, 75, 00, 00, 02, 2A, 12, 06, 28]
        // .code-bytes IL_0288: [42, 08, 00, 06, 8C, 1A, 00, 00, 01, 2A, 12, 07, 02, 02, 7B, A5, 01, 00, 04, 28, 16, 08, 00, 06]
        // .code-bytes IL_02A0: [28, 41, 08, 00, 06, 04, 2C, 08, 11, 07, 8C, 75, 00, 00, 02, 2A, 12, 07, 28, 42, 08, 00, 06, 8C]
        // .code-bytes IL_02B8: [1A, 00, 00, 01, 2A, 12, 08, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01, 00, 04, 03, 20, 87, 00, 00]
        // .code-bytes IL_02D0: [00, FE, 01, 28, 37, 08, 00, 06, 04, 2C, 08, 11, 08, 8C, 74, 00, 00, 02, 2A, 12, 08, 28, 3C, 08]
        // .code-bytes IL_02E8: [00, 06, 8C, 1A, 00, 00, 01, 2A, 02, 7B, A5, 01, 00, 04, 13, 09, 02, 11, 09, 28, 14, 08, 00, 06]
        // .code-bytes IL_0300: [13, 0A, 11, 0A, 28, BC, 00, 00, 0A, 13, 0B, 11, 0B, 02, 7B, 86, 01, 00, 04, 11, 09, 1A, 58, 02]
        // .code-bytes IL_0318: [7B, A4, 01, 00, 04, 1A, 59, 6F, AF, 00, 00, 0A, 2A, 02, 7B, A4, 01, 00, 04, 8D, 3E, 00, 00, 01]
        // .code-bytes IL_0330: [13, 0C, 02, 7B, 86, 01, 00, 04, 02, 7B, A5, 01, 00, 04, 11, 0C, 16, 02, 7B, A4, 01, 00, 04, 28]
        // .code-bytes IL_0348: [65, 00, 00, 0A, 11, 0C, 2A, 02, 28, 0B, 08, 00, 06, 8C, 51, 00, 00, 01, 2A, 02, 28, 0C, 08, 00]
        // .code-bytes IL_0360: [06, 8C, 56, 00, 00, 01, 2A, 02, 02, 7B, A5, 01, 00, 04, 28, D0, 07, 00, 06, 13, 0D, 11, 0D, 16]
        // .code-bytes IL_0378: [32, 0F, 11, 0D, 02, 7C, 8F, 01, 00, 04, 7B, D6, 01, 00, 04, 32, 10, 28, 08, 06, 00, 06, 7E, 02]
        // .code-bytes IL_0390: [00, 00, 0A, 73, 0B, 0A, 00, 06, 7A, 02, 7C, 8F, 01, 00, 04, 7B, D5, 01, 00, 04, 11, 0D, A3, 6D]
        // .code-bytes IL_03A8: [00, 00, 02, 13, 0E, 11, 0E, 7B, C1, 01, 00, 04, 11, 0E, 7B, C2, 01, 00, 04, 73, 3D, 0A, 00, 06]
        // .code-bytes IL_03C0: [2A, 02, 02, 7B, 98, 01, 00, 04, 28, 1A, 08, 00, 06, 7A]
        // .local [0] int8
        // .local [1] int32
        // .local [2] int16
        // .local [3] int16
        // .local [4] int32
        // .local [5] valuetype [System.Runtime]System.Guid
        // .local [6] valuetype System.Xml.BinXmlSqlMoney
        // .local [7] valuetype System.Xml.BinXmlSqlMoney
        // .local [8] valuetype System.Xml.BinXmlSqlDecimal
        // .local [9] int32
        // .local [10] int32
        // .local [11] class [System.Runtime]System.Text.Encoding
        // .local [12] uint8[]
        // .local [13] int32
        // .local [14] valuetype System.Xml.XmlSqlBinaryReader/QName
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x06000804 System.Xml.XmlSqlBinaryReader::CheckValueTokenBounds
        // IL_0006: ldarg.1 1
        // IL_0007: ldc.i4.1 1
        // IL_0008: sub 
        // IL_0009: switch IL_0123, IL_0135, IL_01A5, IL_01B7, IL_0292, IL_00FD, IL_0110, IL_0147, IL_01C9, IL_02BD, IL_02BD, IL_0325, IL_02F0, IL_00D4, IL_0325, IL_02F0, IL_00D4, IL_034F, IL_034F, IL_0267, IL_03C1, IL_02F0, IL_0325, IL_00D4, IL_03C1, IL_03C1, IL_0325
        // IL_007A: ldarg.1 1
        // IL_007B: ldc.i4.s 122
        // IL_007D: sub 
        // IL_007E: switch IL_035B, IL_035B, IL_035B, IL_034F, IL_034F, IL_034F, IL_03C1, IL_034F, IL_034F, IL_034F, IL_0325, IL_0325, IL_00E7, IL_02BD, IL_0159, IL_016F, IL_0181, IL_0193, IL_0367
        // IL_00CF: br IL_03C1
        // IL_00D4: ldarg.0 0
        // IL_00D5: ldarg.0 0
        // IL_00D6: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00DB: ldarg.0 0
        // IL_00DC: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_00E1: call 0x060007DB System.Xml.XmlSqlBinaryReader::GetString
        // IL_00E6: ret 
        // IL_00E7: ldarg.0 0
        // IL_00E8: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_00ED: ldarg.0 0
        // IL_00EE: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_00F3: ldelem.u1 
        // IL_00F4: ldc.i4.0 0
        // IL_00F5: cgt.un 
        // IL_00F7: box 0x01000006 [System.Runtime]System.Boolean
        // IL_00FC: ret 
        // IL_00FD: ldarg.0 0
        // IL_00FE: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0103: ldarg.0 0
        // IL_0104: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0109: ldelem.u1 
        // IL_010A: box 0x01000013 [System.Runtime]System.Int32
        // IL_010F: ret 
        // IL_0110: ldarg.0 0
        // IL_0111: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0116: ldarg.0 0
        // IL_0117: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_011C: ldelem.u1 
        // IL_011D: box 0x0100003E [System.Runtime]System.Byte
        // IL_0122: ret 
        // IL_0123: ldarg.0 0
        // IL_0124: ldarg.0 0
        // IL_0125: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_012A: call 0x06000812 System.Xml.XmlSqlBinaryReader::GetInt16
        // IL_012F: box 0x01000014 [System.Runtime]System.Int16
        // IL_0134: ret 
        // IL_0135: ldarg.0 0
        // IL_0136: ldarg.0 0
        // IL_0137: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_013C: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_0141: box 0x01000013 [System.Runtime]System.Int32
        // IL_0146: ret 
        // IL_0147: ldarg.0 0
        // IL_0148: ldarg.0 0
        // IL_0149: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_014E: call 0x06000816 System.Xml.XmlSqlBinaryReader::GetInt64
        // IL_0153: box 0x01000015 [System.Runtime]System.Int64
        // IL_0158: ret 
        // IL_0159: ldarg.0 0
        // IL_015A: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_015F: ldarg.0 0
        // IL_0160: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0165: ldelem.u1 
        // IL_0166: conv.i1 
        // IL_0167: stloc.0 0
        // IL_0168: ldloc.0 0
        // IL_0169: box 0x01000055 [System.Runtime]System.SByte
        // IL_016E: ret 
        // IL_016F: ldarg.0 0
        // IL_0170: ldarg.0 0
        // IL_0171: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0176: call 0x06000813 System.Xml.XmlSqlBinaryReader::GetUInt16
        // IL_017B: box 0x01000017 [System.Runtime]System.UInt16
        // IL_0180: ret 
        // IL_0181: ldarg.0 0
        // IL_0182: ldarg.0 0
        // IL_0183: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0188: call 0x06000815 System.Xml.XmlSqlBinaryReader::GetUInt32
        // IL_018D: box 0x01000016 [System.Runtime]System.UInt32
        // IL_0192: ret 
        // IL_0193: ldarg.0 0
        // IL_0194: ldarg.0 0
        // IL_0195: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_019A: call 0x06000817 System.Xml.XmlSqlBinaryReader::GetUInt64
        // IL_019F: box 0x01000018 [System.Runtime]System.UInt64
        // IL_01A4: ret 
        // IL_01A5: ldarg.0 0
        // IL_01A6: ldarg.0 0
        // IL_01A7: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_01AC: call 0x06000818 System.Xml.XmlSqlBinaryReader::GetSingle
        // IL_01B1: box 0x01000019 [System.Runtime]System.Single
        // IL_01B6: ret 
        // IL_01B7: ldarg.0 0
        // IL_01B8: ldarg.0 0
        // IL_01B9: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_01BE: call 0x06000819 System.Xml.XmlSqlBinaryReader::GetDouble
        // IL_01C3: box 0x01000007 [System.Runtime]System.Double
        // IL_01C8: ret 
        // IL_01C9: ldarg.0 0
        // IL_01CA: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_01CF: stloc.s 4
        // IL_01D1: ldarg.0 0
        // IL_01D2: ldloc.s 4
        // IL_01D4: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_01D9: stloc.1 1
        // IL_01DA: ldarg.0 0
        // IL_01DB: ldloc.s 4
        // IL_01DD: ldc.i4.4 4
        // IL_01DE: add 
        // IL_01DF: call 0x06000812 System.Xml.XmlSqlBinaryReader::GetInt16
        // IL_01E4: stloc.2 2
        // IL_01E5: ldarg.0 0
        // IL_01E6: ldloc.s 4
        // IL_01E8: ldc.i4.6 6
        // IL_01E9: add 
        // IL_01EA: call 0x06000812 System.Xml.XmlSqlBinaryReader::GetInt16
        // IL_01EF: stloc.3 3
        // IL_01F0: ldloca.s 5
        // IL_01F2: ldloc.1 1
        // IL_01F3: ldloc.2 2
        // IL_01F4: ldloc.3 3
        // IL_01F5: ldarg.0 0
        // IL_01F6: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_01FB: ldloc.s 4
        // IL_01FD: ldc.i4.8 8
        // IL_01FE: add 
        // IL_01FF: ldelem.u1 
        // IL_0200: ldarg.0 0
        // IL_0201: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0206: ldloc.s 4
        // IL_0208: ldc.i4.s 9
        // IL_020A: add 
        // IL_020B: ldelem.u1 
        // IL_020C: ldarg.0 0
        // IL_020D: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0212: ldloc.s 4
        // IL_0214: ldc.i4.s 10
        // IL_0216: add 
        // IL_0217: ldelem.u1 
        // IL_0218: ldarg.0 0
        // IL_0219: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_021E: ldloc.s 4
        // IL_0220: ldc.i4.s 11
        // IL_0222: add 
        // IL_0223: ldelem.u1 
        // IL_0224: ldarg.0 0
        // IL_0225: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_022A: ldloc.s 4
        // IL_022C: ldc.i4.s 12
        // IL_022E: add 
        // IL_022F: ldelem.u1 
        // IL_0230: ldarg.0 0
        // IL_0231: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0236: ldloc.s 4
        // IL_0238: ldc.i4.s 13
        // IL_023A: add 
        // IL_023B: ldelem.u1 
        // IL_023C: ldarg.0 0
        // IL_023D: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0242: ldloc.s 4
        // IL_0244: ldc.i4.s 14
        // IL_0246: add 
        // IL_0247: ldelem.u1 
        // IL_0248: ldarg.0 0
        // IL_0249: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_024E: ldloc.s 4
        // IL_0250: ldc.i4.s 15
        // IL_0252: add 
        // IL_0253: ldelem.u1 
        // IL_0254: call 0x0A0000BB [System.Runtime]System.Guid::.ctor
        // IL_0259: ldloca.s 5
        // IL_025B: constrained. 0x01000057 [System.Runtime]System.Guid
        // IL_0261: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
        // IL_0266: ret 
        // IL_0267: ldloca.s 6
        // IL_0269: ldarg.0 0
        // IL_026A: ldarg.0 0
        // IL_026B: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_0270: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_0275: call 0x06000840 System.Xml.BinXmlSqlMoney::.ctor
        // IL_027A: ldarg.2 2
        // IL_027B: brfalse.s IL_0285
        // IL_027D: ldloc.s 6
        // IL_027F: box 0x02000075 System.Xml.BinXmlSqlMoney
        // IL_0284: ret 
        // IL_0285: ldloca.s 6
        // IL_0287: call 0x06000842 System.Xml.BinXmlSqlMoney::ToDecimal
        // IL_028C: box 0x0100001A [System.Runtime]System.Decimal
        // IL_0291: ret 
        // IL_0292: ldloca.s 7
        // IL_0294: ldarg.0 0
        // IL_0295: ldarg.0 0
        // IL_0296: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_029B: call 0x06000816 System.Xml.XmlSqlBinaryReader::GetInt64
        // IL_02A0: call 0x06000841 System.Xml.BinXmlSqlMoney::.ctor
        // IL_02A5: ldarg.2 2
        // IL_02A6: brfalse.s IL_02B0
        // IL_02A8: ldloc.s 7
        // IL_02AA: box 0x02000075 System.Xml.BinXmlSqlMoney
        // IL_02AF: ret 
        // IL_02B0: ldloca.s 7
        // IL_02B2: call 0x06000842 System.Xml.BinXmlSqlMoney::ToDecimal
        // IL_02B7: box 0x0100001A [System.Runtime]System.Decimal
        // IL_02BC: ret 
        // IL_02BD: ldloca.s 8
        // IL_02BF: ldarg.0 0
        // IL_02C0: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_02C5: ldarg.0 0
        // IL_02C6: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_02CB: ldarg.1 1
        // IL_02CC: ldc.i4 135
        // IL_02D1: ceq 
        // IL_02D3: call 0x06000837 System.Xml.BinXmlSqlDecimal::.ctor
        // IL_02D8: ldarg.2 2
        // IL_02D9: brfalse.s IL_02E3
        // IL_02DB: ldloc.s 8
        // IL_02DD: box 0x02000074 System.Xml.BinXmlSqlDecimal
        // IL_02E2: ret 
        // IL_02E3: ldloca.s 8
        // IL_02E5: call 0x0600083C System.Xml.BinXmlSqlDecimal::ToDecimal
        // IL_02EA: box 0x0100001A [System.Runtime]System.Decimal
        // IL_02EF: ret 
        // IL_02F0: ldarg.0 0
        // IL_02F1: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_02F6: stloc.s 9
        // IL_02F8: ldarg.0 0
        // IL_02F9: ldloc.s 9
        // IL_02FB: call 0x06000814 System.Xml.XmlSqlBinaryReader::GetInt32
        // IL_0300: stloc.s 10
        // IL_0302: ldloc.s 10
        // IL_0304: call 0x0A0000BC [System.Runtime]System.Text.Encoding::GetEncoding
        // IL_0309: stloc.s 11
        // IL_030B: ldloc.s 11
        // IL_030D: ldarg.0 0
        // IL_030E: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0313: ldloc.s 9
        // IL_0315: ldc.i4.4 4
        // IL_0316: add 
        // IL_0317: ldarg.0 0
        // IL_0318: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_031D: ldc.i4.4 4
        // IL_031E: sub 
        // IL_031F: callvirt 0x0A0000AF [System.Runtime]System.Text.Encoding::GetString
        // IL_0324: ret 
        // IL_0325: ldarg.0 0
        // IL_0326: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_032B: newarr 0x0100003E [System.Runtime]System.Byte
        // IL_0330: stloc.s 12
        // IL_0332: ldarg.0 0
        // IL_0333: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0338: ldarg.0 0
        // IL_0339: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_033E: ldloc.s 12
        // IL_0340: ldc.i4.0 0
        // IL_0341: ldarg.0 0
        // IL_0342: ldfld 0x040001A4 System.Xml.XmlSqlBinaryReader::_tokLen
        // IL_0347: call 0x0A000065 [System.Runtime]System.Array::Copy
        // IL_034C: ldloc.s 12
        // IL_034E: ret 
        // IL_034F: ldarg.0 0
        // IL_0350: call 0x0600080B System.Xml.XmlSqlBinaryReader::ValueAsDateTime
        // IL_0355: box 0x01000051 [System.Runtime]System.DateTime
        // IL_035A: ret 
        // IL_035B: ldarg.0 0
        // IL_035C: call 0x0600080C System.Xml.XmlSqlBinaryReader::ValueAsDateTimeOffset
        // IL_0361: box 0x01000056 [System.Runtime]System.DateTimeOffset
        // IL_0366: ret 
        // IL_0367: ldarg.0 0
        // IL_0368: ldarg.0 0
        // IL_0369: ldfld 0x040001A5 System.Xml.XmlSqlBinaryReader::_tokDataPos
        // IL_036E: call 0x060007D0 System.Xml.XmlSqlBinaryReader::ParseMB32
        // IL_0373: stloc.s 13
        // IL_0375: ldloc.s 13
        // IL_0377: ldc.i4.0 0
        // IL_0378: blt.s IL_0389
        // IL_037A: ldloc.s 13
        // IL_037C: ldarg.0 0
        // IL_037D: ldflda 0x0400018F System.Xml.XmlSqlBinaryReader::_symbolTables
        // IL_0382: ldfld 0x040001D6 System.Xml.XmlSqlBinaryReader/SymbolTables::qnameCount
        // IL_0387: blt.s IL_0399
        // IL_0389: call 0x06000608 System.SR::get_XmlBin_InvalidQNameID
        // IL_038E: ldsfld 0x0A000002 [System.Runtime]System.String::Empty
        // IL_0393: newobj 0x06000A0B System.Xml.XmlException::.ctor
        // IL_0398: throw 
        // IL_0399: ldarg.0 0
        // IL_039A: ldflda 0x0400018F System.Xml.XmlSqlBinaryReader::_symbolTables
        // IL_039F: ldfld 0x040001D5 System.Xml.XmlSqlBinaryReader/SymbolTables::qnametable
        // IL_03A4: ldloc.s 13
        // IL_03A6: ldelem 0x0200006D System.Xml.XmlSqlBinaryReader/QName
        // IL_03AB: stloc.s 14
        // IL_03AD: ldloc.s 14
        // IL_03AF: ldfld 0x040001C1 System.Xml.XmlSqlBinaryReader/QName::localname
        // IL_03B4: ldloc.s 14
        // IL_03B6: ldfld 0x040001C2 System.Xml.XmlSqlBinaryReader/QName::namespaceUri
        // IL_03BB: newobj 0x06000A3D System.Xml.XmlQualifiedName::.ctor
        // IL_03C0: ret 
        // IL_03C1: ldarg.0 0
        // IL_03C2: ldarg.0 0
        // IL_03C3: ldfld 0x04000198 System.Xml.XmlSqlBinaryReader::_token
        // IL_03C8: call 0x0600081A System.Xml.XmlSqlBinaryReader::ThrowUnexpectedToken
        // IL_03CD: throw 
    }

    private System.Xml.Schema.XmlValueConverter GetValueConverter(System.Xml.Schema.XmlTypeCode typeCode)
    {
        // enum storage token=0x02000484 alias=__cil_enum_02000484 underlying=int: global::@System.@Xml.@Schema.@XmlTypeCode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(typeCode));
        global::System.Xml.Schema.XmlSchemaSimpleType v1 = System.Xml.Schema.DatatypeImplementation.GetSimpleTypeFromTypeCode(unchecked((__cil_enum_02000484)(v0)));
        global::System.Xml.Schema.XmlValueConverter v3 = __cil_callvirt_06002F48(v1);
        return v3;
    }

    private object ValueAs(System.Xml.BinXmlToken token, System.Type returnType, System.Xml.IXmlNamespaceResolver namespaceResolver)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b bytes=118145: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f bytes=1169: valuetype [System.Runtime]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c bytes=1D1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_094d148f100986f28432885961b9959bc8d16c44 bytes=1181D4: valuetype System.Xml.BinXmlSqlMoney; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a bytes=1181D0: valuetype System.Xml.BinXmlSqlDecimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 bytes=118159: valuetype [System.Runtime]System.DateTimeOffset; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000484 alias=__cil_enum_02000484 underlying=int: global::@System.@Xml.@Schema.@XmlTypeCode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        object l0 = default;
        int l1 = default;
        int l2 = default;
        long l3 = default;
        int l4 = default;
        long l5 = default;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f l6 = default;
        __cil_F l7 = default;
        double l8 = default;
        __cil_value_094d148f100986f28432885961b9959bc8d16c44 l9 = default;
        __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a l10 = default;
        int l11 = default;
        int l12 = default;
        __cil_type_0100004A l13 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 l14 = default;
        int l15 = default;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l16 = default;
        System.Xml.XmlSqlBinaryReader s22_0 = default;
        System.Xml.XmlSqlBinaryReader s23_0 = default;
        System.Xml.XmlSqlBinaryReader s24_0 = default;
        int s24_1 = default;
        IL_0000: ;
        global::System.Xml.XmlSqlBinaryReader v0 = this;
        __cil_direct_06000804(v0);
        int v1 = unchecked((int)(token));
        int v2 = 1;
        int v3 = unchecked(v1 - v2);
        switch (v3) {
            case 0: {
                goto IL_0173;
            }
            case 1: {
                goto IL_019B;
            }
            case 2: {
                goto IL_0297;
            }
            case 3: {
                goto IL_02C1;
            }
            case 4: {
                goto IL_033B;
            }
            case 5: {
                goto IL_0125;
            }
            case 6: {
                goto IL_014C;
            }
            case 7: {
                goto IL_01C3;
            }
            case 8: {
                goto IL_02EB;
            }
            case 9: {
                goto IL_036F;
            }
            case 10: {
                goto IL_036F;
            }
            case 11: {
                goto IL_03F4;
            }
            case 12: {
                goto IL_03AB;
            }
            case 13: {
                goto IL_00D4;
            }
            case 14: {
                goto IL_03F4;
            }
            case 15: {
                goto IL_03AB;
            }
            case 16: {
                goto IL_00D4;
            }
            case 17: {
                goto IL_043E;
            }
            case 18: {
                goto IL_043E;
            }
            case 19: {
                goto IL_0307;
            }
            case 20: {
                goto IL_0526;
            }
            case 21: {
                goto IL_03AB;
            }
            case 22: {
                goto IL_03F4;
            }
            case 23: {
                goto IL_00D4;
            }
            case 24: {
                goto IL_0526;
            }
            case 25: {
                goto IL_0526;
            }
            case 26: {
                goto IL_03F4;
            }
            default: {
                goto IL_007A;
            } }
        IL_007A: ;
        int v4 = unchecked((int)(token));
        int v5 = 122;
        int v6 = unchecked(v4 - v5);
        switch (v6) {
            case 0: {
                goto IL_045E;
            }
            case 1: {
                goto IL_045E;
            }
            case 2: {
                goto IL_045E;
            }
            case 3: {
                goto IL_043E;
            }
            case 4: {
                goto IL_043E;
            }
            case 5: {
                goto IL_043E;
            }
            case 6: {
                goto IL_0526;
            }
            case 7: {
                goto IL_047E;
            }
            case 8: {
                goto IL_043E;
            }
            case 9: {
                goto IL_049E;
            }
            case 10: {
                goto IL_03F4;
            }
            case 11: {
                goto IL_03F4;
            }
            case 12: {
                goto IL_00FB;
            }
            case 13: {
                goto IL_036F;
            }
            case 14: {
                goto IL_01EB;
            }
            case 15: {
                goto IL_0213;
            }
            case 16: {
                goto IL_023D;
            }
            case 17: {
                goto IL_0268;
            }
            case 18: {
                goto IL_04BB;
            }
            default: {
                goto IL_00CF;
            } }
        IL_00CF: ;
        goto IL_0526;
        IL_00D4: ;
        global::System.Xml.XmlSqlBinaryReader v7 = this;
        int v8 = 11;
        global::System.Xml.Schema.XmlValueConverter v9 = __cil_direct_06000810(v7, unchecked((__cil_enum_02000484)(v8)));
        global::System.Xml.XmlSqlBinaryReader v10 = this;
        global::System.Xml.XmlSqlBinaryReader v11 = this;
        int v12 = v11._tokDataPos;
        global::System.Xml.XmlSqlBinaryReader v13 = this;
        int v14 = v13._tokLen;
        string v15 = __cil_direct_060007DB(v10, v12, v14);
        __cil_type_01000004 v16 = returnType;
        global::System.Xml.IXmlNamespaceResolver v17 = namespaceResolver;
        object v18 = __cil_callvirt_0600300D(v9, v15, v16, v17);
        l0 = v18;
        goto IL_0533;
        IL_00FB: ;
        global::System.Xml.XmlSqlBinaryReader v19 = this;
        int v20 = 13;
        global::System.Xml.Schema.XmlValueConverter v21 = __cil_direct_06000810(v19, unchecked((__cil_enum_02000484)(v20)));
        global::System.Xml.XmlSqlBinaryReader v22 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v23 = v22._data;
        global::System.Xml.XmlSqlBinaryReader v24 = this;
        int v25 = v24._tokDataPos;
        int v26 = unchecked((int)(unchecked((byte)(unchecked((int)(v23[v25]))))));
        int v27 = 0;
        int v28 = (unchecked((uint)v26) > unchecked((uint)v27) ? 1 : 0);
        object v29 = ((object)(__cil_bool_store(v28)));
        __cil_type_01000004 v30 = returnType;
        global::System.Xml.IXmlNamespaceResolver v31 = namespaceResolver;
        object v32 = __cil_callvirt_0600300F(v21, v29, v30, v31);
        l0 = v32;
        goto IL_0533;
        IL_0125: ;
        global::System.Xml.XmlSqlBinaryReader v33 = this;
        int v34 = 47;
        global::System.Xml.Schema.XmlValueConverter v35 = __cil_direct_06000810(v33, unchecked((__cil_enum_02000484)(v34)));
        global::System.Xml.XmlSqlBinaryReader v36 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v37 = v36._data;
        global::System.Xml.XmlSqlBinaryReader v38 = this;
        int v39 = v38._tokDataPos;
        int v40 = unchecked((int)(unchecked((byte)(unchecked((int)(v37[v39]))))));
        object v41 = ((object)((int)(v40)));
        __cil_type_01000004 v42 = returnType;
        global::System.Xml.IXmlNamespaceResolver v43 = namespaceResolver;
        object v44 = __cil_callvirt_0600300F(v35, v41, v42, v43);
        l0 = v44;
        goto IL_0533;
        IL_014C: ;
        global::System.Xml.XmlSqlBinaryReader v45 = this;
        int v46 = 51;
        global::System.Xml.Schema.XmlValueConverter v47 = __cil_direct_06000810(v45, unchecked((__cil_enum_02000484)(v46)));
        global::System.Xml.XmlSqlBinaryReader v48 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v49 = v48._data;
        global::System.Xml.XmlSqlBinaryReader v50 = this;
        int v51 = v50._tokDataPos;
        int v52 = unchecked((int)(unchecked((byte)(unchecked((int)(v49[v51]))))));
        object v53 = ((object)((byte)(v52)));
        __cil_type_01000004 v54 = returnType;
        global::System.Xml.IXmlNamespaceResolver v55 = namespaceResolver;
        object v56 = __cil_callvirt_0600300F(v47, v53, v54, v55);
        l0 = v56;
        goto IL_0533;
        IL_0173: ;
        global::System.Xml.XmlSqlBinaryReader v57 = this;
        global::System.Xml.XmlSqlBinaryReader v58 = this;
        int v59 = v58._tokDataPos;
        int v60 = unchecked((int)(__cil_direct_06000812(v57, v59)));
        l1 = v60;
        global::System.Xml.XmlSqlBinaryReader v61 = this;
        int v62 = 45;
        global::System.Xml.Schema.XmlValueConverter v63 = __cil_direct_06000810(v61, unchecked((__cil_enum_02000484)(v62)));
        int v64 = l1;
        object v65 = ((object)((int)(v64)));
        __cil_type_01000004 v66 = returnType;
        global::System.Xml.IXmlNamespaceResolver v67 = namespaceResolver;
        object v68 = __cil_callvirt_0600300F(v63, v65, v66, v67);
        l0 = v68;
        goto IL_0533;
        IL_019B: ;
        global::System.Xml.XmlSqlBinaryReader v69 = this;
        global::System.Xml.XmlSqlBinaryReader v70 = this;
        int v71 = v70._tokDataPos;
        int v72 = __cil_direct_06000814(v69, v71);
        l2 = v72;
        global::System.Xml.XmlSqlBinaryReader v73 = this;
        int v74 = 44;
        global::System.Xml.Schema.XmlValueConverter v75 = __cil_direct_06000810(v73, unchecked((__cil_enum_02000484)(v74)));
        int v76 = l2;
        object v77 = ((object)((int)(v76)));
        __cil_type_01000004 v78 = returnType;
        global::System.Xml.IXmlNamespaceResolver v79 = namespaceResolver;
        object v80 = __cil_callvirt_0600300F(v75, v77, v78, v79);
        l0 = v80;
        goto IL_0533;
        IL_01C3: ;
        global::System.Xml.XmlSqlBinaryReader v81 = this;
        global::System.Xml.XmlSqlBinaryReader v82 = this;
        int v83 = v82._tokDataPos;
        long v84 = __cil_direct_06000816(v81, v83);
        l3 = v84;
        global::System.Xml.XmlSqlBinaryReader v85 = this;
        int v86 = 43;
        global::System.Xml.Schema.XmlValueConverter v87 = __cil_direct_06000810(v85, unchecked((__cil_enum_02000484)(v86)));
        long v88 = l3;
        object v89 = ((object)((long)(v88)));
        __cil_type_01000004 v90 = returnType;
        global::System.Xml.IXmlNamespaceResolver v91 = namespaceResolver;
        object v92 = __cil_callvirt_0600300F(v87, v89, v90, v91);
        l0 = v92;
        goto IL_0533;
        IL_01EB: ;
        global::System.Xml.XmlSqlBinaryReader v93 = this;
        int v94 = 46;
        global::System.Xml.Schema.XmlValueConverter v95 = __cil_direct_06000810(v93, unchecked((__cil_enum_02000484)(v94)));
        global::System.Xml.XmlSqlBinaryReader v96 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v97 = v96._data;
        global::System.Xml.XmlSqlBinaryReader v98 = this;
        int v99 = v98._tokDataPos;
        int v100 = unchecked((int)(unchecked((byte)(unchecked((int)(v97[v99]))))));
        int v101 = unchecked((int)(unchecked((sbyte)(v100))));
        object v102 = ((object)((int)(v101)));
        __cil_type_01000004 v103 = returnType;
        global::System.Xml.IXmlNamespaceResolver v104 = namespaceResolver;
        object v105 = __cil_callvirt_0600300F(v95, v102, v103, v104);
        l0 = v105;
        goto IL_0533;
        IL_0213: ;
        global::System.Xml.XmlSqlBinaryReader v106 = this;
        global::System.Xml.XmlSqlBinaryReader v107 = this;
        int v108 = v107._tokDataPos;
        int v109 = unchecked((int)(__cil_direct_06000813(v106, v108)));
        l4 = v109;
        global::System.Xml.XmlSqlBinaryReader v110 = this;
        int v111 = 50;
        global::System.Xml.Schema.XmlValueConverter v112 = __cil_direct_06000810(v110, unchecked((__cil_enum_02000484)(v111)));
        int v113 = l4;
        object v114 = ((object)((int)(v113)));
        __cil_type_01000004 v115 = returnType;
        global::System.Xml.IXmlNamespaceResolver v116 = namespaceResolver;
        object v117 = __cil_callvirt_0600300F(v112, v114, v115, v116);
        l0 = v117;
        goto IL_0533;
        IL_023D: ;
        global::System.Xml.XmlSqlBinaryReader v118 = this;
        global::System.Xml.XmlSqlBinaryReader v119 = this;
        int v120 = v119._tokDataPos;
        int v121 = unchecked((int)(__cil_direct_06000815(v118, v120)));
        long v122 = unchecked((long)(uint)(v121));
        l5 = v122;
        global::System.Xml.XmlSqlBinaryReader v123 = this;
        int v124 = 49;
        global::System.Xml.Schema.XmlValueConverter v125 = __cil_direct_06000810(v123, unchecked((__cil_enum_02000484)(v124)));
        long v126 = l5;
        object v127 = ((object)((long)(v126)));
        __cil_type_01000004 v128 = returnType;
        global::System.Xml.IXmlNamespaceResolver v129 = namespaceResolver;
        object v130 = __cil_callvirt_0600300F(v125, v127, v128, v129);
        l0 = v130;
        goto IL_0533;
        IL_0268: ;
        global::System.Xml.XmlSqlBinaryReader v131 = this;
        global::System.Xml.XmlSqlBinaryReader v132 = this;
        int v133 = v132._tokDataPos;
        long v134 = unchecked((long)(__cil_direct_06000817(v131, v133)));
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v135 = System.Decimal.op_Implicit(unchecked((ulong)(v134)));
        l6 = v135;
        global::System.Xml.XmlSqlBinaryReader v136 = this;
        int v137 = 48;
        global::System.Xml.Schema.XmlValueConverter v138 = __cil_direct_06000810(v136, unchecked((__cil_enum_02000484)(v137)));
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v139 = l6;
        object v140 = ((object)((__cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f)(v139)));
        __cil_type_01000004 v141 = returnType;
        global::System.Xml.IXmlNamespaceResolver v142 = namespaceResolver;
        object v143 = __cil_callvirt_0600300F(v138, v140, v141, v142);
        l0 = v143;
        goto IL_0533;
        IL_0297: ;
        global::System.Xml.XmlSqlBinaryReader v144 = this;
        global::System.Xml.XmlSqlBinaryReader v145 = this;
        int v146 = v145._tokDataPos;
        __cil_F v147 = __cil_call_result_r4(__cil_direct_06000818(v144, v146));
        l7 = v147;
        global::System.Xml.XmlSqlBinaryReader v148 = this;
        int v149 = 15;
        global::System.Xml.Schema.XmlValueConverter v150 = __cil_direct_06000810(v148, unchecked((__cil_enum_02000484)(v149)));
        __cil_F v151 = l7;
        object v152 = ((object)((float)(v151)));
        __cil_type_01000004 v153 = returnType;
        global::System.Xml.IXmlNamespaceResolver v154 = namespaceResolver;
        object v155 = __cil_callvirt_0600300F(v150, v152, v153, v154);
        l0 = v155;
        goto IL_0533;
        IL_02C1: ;
        global::System.Xml.XmlSqlBinaryReader v156 = this;
        global::System.Xml.XmlSqlBinaryReader v157 = this;
        int v158 = v157._tokDataPos;
        double v159 = __cil_direct_06000819(v156, v158);
        l8 = unchecked((double)(v159));
        global::System.Xml.XmlSqlBinaryReader v160 = this;
        int v161 = 16;
        global::System.Xml.Schema.XmlValueConverter v162 = __cil_direct_06000810(v160, unchecked((__cil_enum_02000484)(v161)));
        double v163 = l8;
        object v164 = ((object)((double)(v163)));
        __cil_type_01000004 v165 = returnType;
        global::System.Xml.IXmlNamespaceResolver v166 = namespaceResolver;
        object v167 = __cil_callvirt_0600300F(v162, v164, v165, v166);
        l0 = v167;
        goto IL_0533;
        IL_02EB: ;
        global::System.Xml.XmlSqlBinaryReader v168 = this;
        int v169 = 12;
        global::System.Xml.Schema.XmlValueConverter v170 = __cil_direct_06000810(v168, unchecked((__cil_enum_02000484)(v169)));
        global::System.Xml.XmlSqlBinaryReader v171 = this;
        int v172 = unchecked((int)(token));
        string v173 = __cil_direct_0600080E(v171, unchecked((__cil_enum_02000073)(v172)));
        __cil_type_01000004 v174 = returnType;
        global::System.Xml.IXmlNamespaceResolver v175 = namespaceResolver;
        object v176 = __cil_callvirt_0600300D(v170, v173, v174, v175);
        l0 = v176;
        goto IL_0533;
        IL_0307: ;
        global::System.Xml.XmlSqlBinaryReader v177 = this;
        int v178 = 14;
        global::System.Xml.Schema.XmlValueConverter v179 = __cil_direct_06000810(v177, unchecked((__cil_enum_02000484)(v178)));
        global::System.Xml.XmlSqlBinaryReader v180 = this;
        global::System.Xml.XmlSqlBinaryReader v181 = this;
        int v182 = v181._tokDataPos;
        int v183 = __cil_direct_06000814(v180, v182);
        __cil_value_094d148f100986f28432885961b9959bc8d16c44 v184 = __cil_value_newobj_06000840(v183);
        l9 = v184;
        ref __cil_value_094d148f100986f28432885961b9959bc8d16c44 v185 = ref l9;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v186 = __cil_direct_06000842(ref v185);
        object v187 = ((object)((__cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f)(v186)));
        __cil_type_01000004 v188 = returnType;
        global::System.Xml.IXmlNamespaceResolver v189 = namespaceResolver;
        object v190 = __cil_callvirt_0600300F(v179, v187, v188, v189);
        l0 = v190;
        goto IL_0533;
        IL_033B: ;
        global::System.Xml.XmlSqlBinaryReader v191 = this;
        int v192 = 14;
        global::System.Xml.Schema.XmlValueConverter v193 = __cil_direct_06000810(v191, unchecked((__cil_enum_02000484)(v192)));
        global::System.Xml.XmlSqlBinaryReader v194 = this;
        global::System.Xml.XmlSqlBinaryReader v195 = this;
        int v196 = v195._tokDataPos;
        long v197 = __cil_direct_06000816(v194, v196);
        __cil_value_094d148f100986f28432885961b9959bc8d16c44 v198 = __cil_value_newobj_06000841(v197);
        l9 = v198;
        ref __cil_value_094d148f100986f28432885961b9959bc8d16c44 v199 = ref l9;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v200 = __cil_direct_06000842(ref v199);
        object v201 = ((object)((__cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f)(v200)));
        __cil_type_01000004 v202 = returnType;
        global::System.Xml.IXmlNamespaceResolver v203 = namespaceResolver;
        object v204 = __cil_callvirt_0600300F(v193, v201, v202, v203);
        l0 = v204;
        goto IL_0533;
        IL_036F: ;
        global::System.Xml.XmlSqlBinaryReader v205 = this;
        int v206 = 14;
        global::System.Xml.Schema.XmlValueConverter v207 = __cil_direct_06000810(v205, unchecked((__cil_enum_02000484)(v206)));
        global::System.Xml.XmlSqlBinaryReader v208 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v209 = v208._data;
        global::System.Xml.XmlSqlBinaryReader v210 = this;
        int v211 = v210._tokDataPos;
        int v212 = unchecked((int)(token));
        int v213 = 135;
        int v214 = (v212 == v213 ? 1 : 0);
        __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a v215 = __cil_value_newobj_06000837(v209, v211, __cil_bool_store(v214));
        l10 = v215;
        ref __cil_value_dff34c0c31466b4aca3f0678c272faf6ca18eb5a v216 = ref l10;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v217 = __cil_direct_0600083C(ref v216);
        object v218 = ((object)((__cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f)(v217)));
        __cil_type_01000004 v219 = returnType;
        global::System.Xml.IXmlNamespaceResolver v220 = namespaceResolver;
        object v221 = __cil_callvirt_0600300F(v207, v218, v219, v220);
        l0 = v221;
        goto IL_0533;
        IL_03AB: ;
        global::System.Xml.XmlSqlBinaryReader v222 = this;
        int v223 = v222._tokDataPos;
        l11 = v223;
        global::System.Xml.XmlSqlBinaryReader v224 = this;
        int v225 = l11;
        int v226 = __cil_direct_06000814(v224, v225);
        l12 = v226;
        int v227 = l12;
        __cil_type_0100004A v228 = System.Text.Encoding.GetEncoding(v227);
        l13 = v228;
        global::System.Xml.XmlSqlBinaryReader v229 = this;
        int v230 = 11;
        global::System.Xml.Schema.XmlValueConverter v231 = __cil_direct_06000810(v229, unchecked((__cil_enum_02000484)(v230)));
        __cil_type_0100004A v232 = l13;
        global::System.Xml.XmlSqlBinaryReader v233 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v234 = v233._data;
        int v235 = l11;
        int v236 = 4;
        int v237 = unchecked(v235 + v236);
        global::System.Xml.XmlSqlBinaryReader v238 = this;
        int v239 = v238._tokLen;
        int v240 = 4;
        int v241 = unchecked(v239 - v240);
        string v242 = v232.GetString(v234, v237, v241);
        __cil_type_01000004 v243 = returnType;
        global::System.Xml.IXmlNamespaceResolver v244 = namespaceResolver;
        object v245 = __cil_callvirt_0600300D(v231, v242, v243, v244);
        l0 = v245;
        goto IL_0533;
        IL_03F4: ;
        global::System.Xml.XmlSqlBinaryReader v246 = this;
        int v247 = v246._tokLen;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v248 = __cil_newarr_0100003E(v247);
        l14 = v248;
        global::System.Xml.XmlSqlBinaryReader v249 = this;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v250 = v249._data;
        global::System.Xml.XmlSqlBinaryReader v251 = this;
        int v252 = v251._tokDataPos;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v253 = l14;
        int v254 = 0;
        global::System.Xml.XmlSqlBinaryReader v255 = this;
        int v256 = v255._tokLen;
        System.Array.Copy(((__cil_type_01000022)(v250)), v252, ((__cil_type_01000022)(v253)), v254, v256);
        global::System.Xml.XmlSqlBinaryReader v257 = this;
        int v258 = unchecked((int)(token));
        int v259 = 132;
        if (v258 == v259) {
            System.Xml.XmlSqlBinaryReader e21_23_0 = v257;
            s23_0 = e21_23_0;
            goto IL_0428;
        } else {
            System.Xml.XmlSqlBinaryReader e21_22_0 = v257;
            s22_0 = e21_22_0;
            goto IL_0424;
        }
        IL_0424: ;
        int v260 = 27;
        System.Xml.XmlSqlBinaryReader e22_24_0 = s22_0;
        int e22_24_1 = v260;
        s24_0 = e22_24_0;
        s24_1 = e22_24_1;
        goto IL_042A;
        IL_0428: ;
        int v261 = 26;
        System.Xml.XmlSqlBinaryReader e23_24_0 = s23_0;
        int e23_24_1 = v261;
        s24_0 = e23_24_0;
        s24_1 = e23_24_1;
        goto IL_042A;
        IL_042A: ;
        global::System.Xml.Schema.XmlValueConverter v262 = __cil_direct_06000810(s24_0, unchecked((__cil_enum_02000484)(s24_1)));
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v263 = l14;
        __cil_type_01000004 v264 = returnType;
        global::System.Xml.IXmlNamespaceResolver v265 = namespaceResolver;
        object v266 = __cil_callvirt_0600300F(v262, ((object)(v263)), v264, v265);
        l0 = v266;
        goto IL_0533;
        IL_043E: ;
        global::System.Xml.XmlSqlBinaryReader v267 = this;
        int v268 = 18;
        global::System.Xml.Schema.XmlValueConverter v269 = __cil_direct_06000810(v267, unchecked((__cil_enum_02000484)(v268)));
        global::System.Xml.XmlSqlBinaryReader v270 = this;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v271 = __cil_direct_0600080B(v270);
        object v272 = ((object)((__cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b)(v271)));
        __cil_type_01000004 v273 = returnType;
        global::System.Xml.IXmlNamespaceResolver v274 = namespaceResolver;
        object v275 = __cil_callvirt_0600300F(v269, v272, v273, v274);
        l0 = v275;
        goto IL_0533;
        IL_045E: ;
        global::System.Xml.XmlSqlBinaryReader v276 = this;
        int v277 = 18;
        global::System.Xml.Schema.XmlValueConverter v278 = __cil_direct_06000810(v276, unchecked((__cil_enum_02000484)(v277)));
        global::System.Xml.XmlSqlBinaryReader v279 = this;
        __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 v280 = __cil_direct_0600080C(v279);
        object v281 = ((object)((__cil_value_854596eda7f39f5bc9692f559802067ccbcb5736)(v280)));
        __cil_type_01000004 v282 = returnType;
        global::System.Xml.IXmlNamespaceResolver v283 = namespaceResolver;
        object v284 = __cil_callvirt_0600300F(v278, v281, v282, v283);
        l0 = v284;
        goto IL_0533;
        IL_047E: ;
        global::System.Xml.XmlSqlBinaryReader v285 = this;
        int v286 = 19;
        global::System.Xml.Schema.XmlValueConverter v287 = __cil_direct_06000810(v285, unchecked((__cil_enum_02000484)(v286)));
        global::System.Xml.XmlSqlBinaryReader v288 = this;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v289 = __cil_direct_0600080B(v288);
        object v290 = ((object)((__cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b)(v289)));
        __cil_type_01000004 v291 = returnType;
        global::System.Xml.IXmlNamespaceResolver v292 = namespaceResolver;
        object v293 = __cil_callvirt_0600300F(v287, v290, v291, v292);
        l0 = v293;
        goto IL_0533;
        IL_049E: ;
        global::System.Xml.XmlSqlBinaryReader v294 = this;
        int v295 = 20;
        global::System.Xml.Schema.XmlValueConverter v296 = __cil_direct_06000810(v294, unchecked((__cil_enum_02000484)(v295)));
        global::System.Xml.XmlSqlBinaryReader v297 = this;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v298 = __cil_direct_0600080B(v297);
        object v299 = ((object)((__cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b)(v298)));
        __cil_type_01000004 v300 = returnType;
        global::System.Xml.IXmlNamespaceResolver v301 = namespaceResolver;
        object v302 = __cil_callvirt_0600300F(v296, v299, v300, v301);
        l0 = v302;
        goto IL_0533;
        IL_04BB: ;
        global::System.Xml.XmlSqlBinaryReader v303 = this;
        global::System.Xml.XmlSqlBinaryReader v304 = this;
        int v305 = v304._tokDataPos;
        int v306 = __cil_direct_060007D0(v303, v305);
        l15 = v306;
        int v307 = l15;
        int v308 = 0;
        if (v307 < v308) {
            goto IL_04DD;
        } else {
            goto IL_04CE;
        }
        IL_04CE: ;
        int v309 = l15;
        global::System.Xml.XmlSqlBinaryReader v310 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v311 = ref v310._symbolTables;
        int v312 = v311.qnameCount;
        if (v309 < v312) {
            goto IL_04ED;
        } else {
            goto IL_04DD;
        }
        IL_04DD: ;
        string v313 = System.SR.get_XmlBin_InvalidQNameID();
        string v314 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlException v315 = __cil_newobj_06000A0B(v313, v314);
        throw v315;
        IL_04ED: ;
        global::System.Xml.XmlSqlBinaryReader v316 = this;
        ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v317 = ref v316._symbolTables;
        __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v318 = v317.qnametable;
        int v319 = l15;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v320 = __cil_ldelem_0200006D(v318, v319);
        l16 = v320;
        global::System.Xml.XmlSqlBinaryReader v321 = this;
        int v322 = 29;
        global::System.Xml.Schema.XmlValueConverter v323 = __cil_direct_06000810(v321, unchecked((__cil_enum_02000484)(v322)));
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v324 = l16;
        string v325 = v324.localname;
        __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v326 = l16;
        string v327 = v326.namespaceUri;
        global::System.Xml.XmlQualifiedName v328 = __cil_newobj_06000A3D(v325, v327);
        __cil_type_01000004 v329 = returnType;
        global::System.Xml.IXmlNamespaceResolver v330 = namespaceResolver;
        object v331 = __cil_callvirt_0600300F(v323, ((object)(v328)), v329, v330);
        l0 = v331;
        goto IL_0533;
        IL_0526: ;
        global::System.Xml.XmlSqlBinaryReader v332 = this;
        global::System.Xml.XmlSqlBinaryReader v333 = this;
        int v334 = unchecked((int)(v333._token));
        global::System.Exception v335 = __cil_direct_0600081A(v332, unchecked((__cil_enum_02000073)(v334)));
        throw v335;
        IL_0533: ;
        object v336 = l0;
        return v336;
    }

    private short GetInt16(int pos)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        int v4 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[pos]))))));
        int v8 = unchecked(pos + 1);
        int v9 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v8]))))));
        int v11 = (v9 << 8);
        int v12 = unchecked(v4 | v11);
        int v13 = unchecked((int)(unchecked((short)(v12))));
        return unchecked((short)(v13));
    }

    private ushort GetUInt16(int pos)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        int v4 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[pos]))))));
        int v8 = unchecked(pos + 1);
        int v9 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v8]))))));
        int v11 = (v9 << 8);
        int v12 = unchecked(v4 | v11);
        int v13 = unchecked((int)(unchecked((ushort)(v12))));
        return unchecked((ushort)(v13));
    }

    private int GetInt32(int pos)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        int v4 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[pos]))))));
        int v8 = unchecked(pos + 1);
        int v9 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v8]))))));
        int v11 = (v9 << 8);
        int v12 = unchecked(v4 | v11);
        int v16 = unchecked(pos + 2);
        int v17 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v16]))))));
        int v19 = (v17 << 16);
        int v20 = unchecked(v12 | v19);
        int v24 = unchecked(pos + 3);
        int v25 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v24]))))));
        int v27 = (v25 << 24);
        return unchecked(v20 | v27);
    }

    private uint GetUInt32(int pos)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        int v4 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[pos]))))));
        int v8 = unchecked(pos + 1);
        int v9 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v8]))))));
        int v11 = (v9 << 8);
        int v12 = unchecked(v4 | v11);
        int v16 = unchecked(pos + 2);
        int v17 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v16]))))));
        int v19 = (v17 << 16);
        int v20 = unchecked(v12 | v19);
        int v24 = unchecked(pos + 3);
        int v25 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v24]))))));
        int v27 = (v25 << 24);
        return unchecked((uint)(unchecked(v20 | v27)));
    }

    private long GetInt64(int pos)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        uint l1 = default;
        uint l2 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        int v4 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[pos]))))));
        int v8 = unchecked(pos + 1);
        int v9 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v8]))))));
        int v11 = (v9 << 8);
        int v12 = unchecked(v4 | v11);
        int v16 = unchecked(pos + 2);
        int v17 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v16]))))));
        int v19 = (v17 << 16);
        int v20 = unchecked(v12 | v19);
        int v24 = unchecked(pos + 3);
        int v25 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v24]))))));
        int v27 = (v25 << 24);
        int v28 = unchecked(v20 | v27);
        l1 = unchecked((uint)(v28));
        int v32 = unchecked(pos + 4);
        int v33 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v32]))))));
        int v37 = unchecked(pos + 5);
        int v38 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v37]))))));
        int v40 = (v38 << 8);
        int v41 = unchecked(v33 | v40);
        int v45 = unchecked(pos + 6);
        int v46 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v45]))))));
        int v48 = (v46 << 16);
        int v49 = unchecked(v41 | v48);
        int v53 = unchecked(pos + 7);
        int v54 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v53]))))));
        int v56 = (v54 << 24);
        int v57 = unchecked(v49 | v56);
        l2 = unchecked((uint)(v57));
        int v58 = unchecked((int)(l2));
        long v59 = unchecked((long)(uint)(v58));
        long v61 = (v59 << 32);
        int v62 = unchecked((int)(l1));
        return unchecked(v61 | unchecked((long)(uint)(v62)));
    }

    private ulong GetUInt64(int pos)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        uint l1 = default;
        uint l2 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v1 = this._data;
        int v4 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[pos]))))));
        int v8 = unchecked(pos + 1);
        int v9 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v8]))))));
        int v11 = (v9 << 8);
        int v12 = unchecked(v4 | v11);
        int v16 = unchecked(pos + 2);
        int v17 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v16]))))));
        int v19 = (v17 << 16);
        int v20 = unchecked(v12 | v19);
        int v24 = unchecked(pos + 3);
        int v25 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v24]))))));
        int v27 = (v25 << 24);
        int v28 = unchecked(v20 | v27);
        l1 = unchecked((uint)(v28));
        int v32 = unchecked(pos + 4);
        int v33 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v32]))))));
        int v37 = unchecked(pos + 5);
        int v38 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v37]))))));
        int v40 = (v38 << 8);
        int v41 = unchecked(v33 | v40);
        int v45 = unchecked(pos + 6);
        int v46 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v45]))))));
        int v48 = (v46 << 16);
        int v49 = unchecked(v41 | v48);
        int v53 = unchecked(pos + 7);
        int v54 = unchecked((int)(unchecked((byte)(unchecked((int)(v1[v53]))))));
        int v56 = (v54 << 24);
        int v57 = unchecked(v49 | v56);
        l2 = unchecked((uint)(v57));
        int v58 = unchecked((int)(l2));
        long v59 = unchecked((long)(uint)(v58));
        long v61 = (v59 << 32);
        int v62 = unchecked((int)(l1));
        return unchecked((ulong)(unchecked(v61 | unchecked((long)(uint)(v62)))));
    }

    private float GetSingle(int offset)
    {
        // IL fallback: conv.u source category needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 86, 01, 00, 04, 0A, 06, 03, 91, 06, 03, 17, 58, 91, 1E, 62, 60, 06, 03, 18, 58, 91, 1F]
        // .code-bytes IL_0018: [10, 62, 60, 06, 03, 19, 58, 91, 1F, 18, 62, 60, 0B, 12, 01, E0, 4E, 2A]
        // .local [0] uint8[]
        // .local [1] uint32
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0006: stloc.0 0
        // IL_0007: ldloc.0 0
        // IL_0008: ldarg.1 1
        // IL_0009: ldelem.u1 
        // IL_000A: ldloc.0 0
        // IL_000B: ldarg.1 1
        // IL_000C: ldc.i4.1 1
        // IL_000D: add 
        // IL_000E: ldelem.u1 
        // IL_000F: ldc.i4.8 8
        // IL_0010: shl 
        // IL_0011: or 
        // IL_0012: ldloc.0 0
        // IL_0013: ldarg.1 1
        // IL_0014: ldc.i4.2 2
        // IL_0015: add 
        // IL_0016: ldelem.u1 
        // IL_0017: ldc.i4.s 16
        // IL_0019: shl 
        // IL_001A: or 
        // IL_001B: ldloc.0 0
        // IL_001C: ldarg.1 1
        // IL_001D: ldc.i4.3 3
        // IL_001E: add 
        // IL_001F: ldelem.u1 
        // IL_0020: ldc.i4.s 24
        // IL_0022: shl 
        // IL_0023: or 
        // IL_0024: stloc.1 1
        // IL_0025: ldloca.s 1
        // IL_0027: conv.u 
        // IL_0028: ldind.r4 
        // IL_0029: ret 
    }

    private double GetDouble(int offset)
    {
        // IL fallback: conv.u source category needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 86, 01, 00, 04, 03, 91, 02, 7B, 86, 01, 00, 04, 03, 17, 58, 91, 1E, 62, 60, 02, 7B, 86]
        // .code-bytes IL_0018: [01, 00, 04, 03, 18, 58, 91, 1F, 10, 62, 60, 02, 7B, 86, 01, 00, 04, 03, 19, 58, 91, 1F, 18, 62]
        // .code-bytes IL_0030: [60, 0A, 02, 7B, 86, 01, 00, 04, 03, 1A, 58, 91, 02, 7B, 86, 01, 00, 04, 03, 1B, 58, 91, 1E, 62]
        // .code-bytes IL_0048: [60, 02, 7B, 86, 01, 00, 04, 03, 1C, 58, 91, 1F, 10, 62, 60, 02, 7B, 86, 01, 00, 04, 03, 1D, 58]
        // .code-bytes IL_0060: [91, 1F, 18, 62, 60, 0B, 07, 6E, 1F, 20, 62, 06, 6E, 60, 0C, 12, 02, E0, 4F, 2A]
        // .local [0] uint32
        // .local [1] uint32
        // .local [2] uint64
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0006: ldarg.1 1
        // IL_0007: ldelem.u1 
        // IL_0008: ldarg.0 0
        // IL_0009: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_000E: ldarg.1 1
        // IL_000F: ldc.i4.1 1
        // IL_0010: add 
        // IL_0011: ldelem.u1 
        // IL_0012: ldc.i4.8 8
        // IL_0013: shl 
        // IL_0014: or 
        // IL_0015: ldarg.0 0
        // IL_0016: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_001B: ldarg.1 1
        // IL_001C: ldc.i4.2 2
        // IL_001D: add 
        // IL_001E: ldelem.u1 
        // IL_001F: ldc.i4.s 16
        // IL_0021: shl 
        // IL_0022: or 
        // IL_0023: ldarg.0 0
        // IL_0024: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0029: ldarg.1 1
        // IL_002A: ldc.i4.3 3
        // IL_002B: add 
        // IL_002C: ldelem.u1 
        // IL_002D: ldc.i4.s 24
        // IL_002F: shl 
        // IL_0030: or 
        // IL_0031: stloc.0 0
        // IL_0032: ldarg.0 0
        // IL_0033: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0038: ldarg.1 1
        // IL_0039: ldc.i4.4 4
        // IL_003A: add 
        // IL_003B: ldelem.u1 
        // IL_003C: ldarg.0 0
        // IL_003D: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_0042: ldarg.1 1
        // IL_0043: ldc.i4.5 5
        // IL_0044: add 
        // IL_0045: ldelem.u1 
        // IL_0046: ldc.i4.8 8
        // IL_0047: shl 
        // IL_0048: or 
        // IL_0049: ldarg.0 0
        // IL_004A: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_004F: ldarg.1 1
        // IL_0050: ldc.i4.6 6
        // IL_0051: add 
        // IL_0052: ldelem.u1 
        // IL_0053: ldc.i4.s 16
        // IL_0055: shl 
        // IL_0056: or 
        // IL_0057: ldarg.0 0
        // IL_0058: ldfld 0x04000186 System.Xml.XmlSqlBinaryReader::_data
        // IL_005D: ldarg.1 1
        // IL_005E: ldc.i4.7 7
        // IL_005F: add 
        // IL_0060: ldelem.u1 
        // IL_0061: ldc.i4.s 24
        // IL_0063: shl 
        // IL_0064: or 
        // IL_0065: stloc.1 1
        // IL_0066: ldloc.1 1
        // IL_0067: conv.u8 
        // IL_0068: ldc.i4.s 32
        // IL_006A: shl 
        // IL_006B: ldloc.0 0
        // IL_006C: conv.u8 
        // IL_006D: or 
        // IL_006E: stloc.2 2
        // IL_006F: ldloca.s 2
        // IL_0071: conv.u 
        // IL_0072: ldind.r8 
        // IL_0073: ret 
    }

    private System.Exception ThrowUnexpectedToken(System.Xml.BinXmlToken token)
    {
        // enum storage token=0x02000073 alias=__cil_enum_02000073 underlying=int: global::@System.@Xml.@BinXmlToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v1 = System.SR.get_XmlBinary_UnexpectedToken();
        global::System.Exception v2 = __cil_direct_0600081B(this, v1);
        return v2;
    }

    private System.Exception ThrowXmlException(string res)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        this._state = unchecked((__cil_enum_0200006C)(6));
        global::System.Xml.XmlException v3 = __cil_newobj_06000A0A(res, null);
        return v3;
    }

    private System.Exception ThrowXmlException(string res, string arg1, string arg2)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        this._state = unchecked((__cil_enum_0200006C)(6));
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v4 = __cil_newarr_01000003(2);
        v4[0] = arg1;
        v4[1] = arg2;
        global::System.Xml.XmlException v9 = __cil_newobj_06000A0A(res, v4);
        return v9;
    }

    private System.Exception ThrowNotSupported(string res)
    {
        // enum storage token=0x0200006C alias=__cil_enum_0200006C underlying=int: global::@System.@Xml.@XmlSqlBinaryReader.@ScanState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        this._state = unchecked((__cil_enum_0200006C)(6));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(res);
        return v3;
    }

    static XmlSqlBinaryReader()
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_dd2fec87d8aee592dd0de064e5bfc45700849e15 bytes=1D1211: class [System.Runtime]System.Type[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5a132f6c65fef2a4038f22cd0d2efe62f0ed6ff0 bytes=1D1183A0: valuetype System.Xml.ReadState[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_37929d0fa2e13ff7d6bb8cb9c48dd50dc43b32a1 bytes=11808D: valuetype [System.Runtime]System.RuntimeFieldHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v0 = __cil_ldtoken_type_01000001;
        __cil_type_01000004 v1 = System.Type.GetTypeFromHandle(v0);
        System.Xml.XmlSqlBinaryReader.TypeOfObject = v1;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v2 = __cil_ldtoken_type_01000003;
        __cil_type_01000004 v3 = System.Type.GetTypeFromHandle(v2);
        System.Xml.XmlSqlBinaryReader.TypeOfString = v3;
        System.Threading.Volatile.Write(ref System.Xml.XmlSqlBinaryReader.s_tokenTypeMap, null);
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v5 = __cil_newarr_0100003E(8);
        __cil_value_37929d0fa2e13ff7d6bb8cb9c48dd50dc43b32a1 v6 = __cil_ldtoken_field_0400246C;
        System.Runtime.CompilerServices.RuntimeHelpers.InitializeArray(((__cil_type_01000022)(v5)), v6);
        System.Xml.XmlSqlBinaryReader.s_xsdKatmaiTimeScaleToValueLengthMap = v5;
        __cil_ref_5a132f6c65fef2a4038f22cd0d2efe62f0ed6ff0 v8 = __cil_newarr_020000E8(9);
        __cil_value_37929d0fa2e13ff7d6bb8cb9c48dd50dc43b32a1 v9 = __cil_ldtoken_field_04002477;
        System.Runtime.CompilerServices.RuntimeHelpers.InitializeArray(((__cil_type_01000022)(v8)), v9);
        System.Xml.XmlSqlBinaryReader.s_scanState2ReadState = v8;
        return;
    }
    // property System.Xml.XmlReaderSettings Settings { get: get_Settings; }
    // property System.Xml.XmlNodeType NodeType { get: get_NodeType; }
    // property string LocalName { get: get_LocalName; }
    // property string NamespaceURI { get: get_NamespaceURI; }
    // property string Prefix { get: get_Prefix; }
    // property bool HasValue { get: get_HasValue; }
    // property string Value { get: get_Value; }
    // property int Depth { get: get_Depth; }
    // property string BaseURI { get: get_BaseURI; }
    // property bool IsEmptyElement { get: get_IsEmptyElement; }
    // property System.Xml.XmlSpace XmlSpace { get: get_XmlSpace; }
    // property string XmlLang { get: get_XmlLang; }
    // property System.Type ValueType { get: get_ValueType; }
    // property int AttributeCount { get: get_AttributeCount; }
    // property bool EOF { get: get_EOF; }
    // property System.Xml.XmlNameTable NameTable { get: get_NameTable; }
    // property System.Xml.ReadState ReadState { get: get_ReadState; }

    private sealed class ScanState : System.Enum
    {
        public int value__;
        public const System.Xml.XmlSqlBinaryReader.ScanState Doc = 0;
        public const System.Xml.XmlSqlBinaryReader.ScanState XmlText = 1;
        public const System.Xml.XmlSqlBinaryReader.ScanState Attr = 2;
        public const System.Xml.XmlSqlBinaryReader.ScanState AttrVal = 3;
        public const System.Xml.XmlSqlBinaryReader.ScanState AttrValPseudoValue = 4;
        public const System.Xml.XmlSqlBinaryReader.ScanState Init = 5;
        public const System.Xml.XmlSqlBinaryReader.ScanState Error = 6;
        public const System.Xml.XmlSqlBinaryReader.ScanState EOF = 7;
        public const System.Xml.XmlSqlBinaryReader.ScanState Closed = 8;
    }

    internal struct QName
    {
        public string prefix;
        public string localname;
        public string namespaceUri;

        public QName(string prefix, string lname, string nsUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v0 = ref this;
            string v1 = prefix;
            v0.prefix = v1;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v2 = ref this;
            string v3 = lname;
            v2.localname = v3;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v4 = ref this;
            string v5 = nsUri;
            v4.namespaceUri = v5;
            return;
        }

        public void Set(string prefix, string lname, string nsUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v0 = ref this;
            string v1 = prefix;
            v0.prefix = v1;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v2 = ref this;
            string v3 = lname;
            v2.localname = v3;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v4 = ref this;
            string v5 = nsUri;
            v4.namespaceUri = v5;
            return;
        }

        public void Clear()
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            string l0 = default;
            IL_0000: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v0 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v2 = ref this;
            string v3 = __cil_ldsfld_0A000002();
            l0 = v3;
            v2.namespaceUri = v3;
            string v4 = l0;
            l0 = v4;
            v1.localname = v4;
            string v5 = l0;
            v0.prefix = v5;
            return;
        }

        public bool MatchNs(string lname, string nsUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            string v0 = lname;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref this;
            string v2 = v1.localname;
            int v3 = __cil_bool_load(System.String.op_Equality(v0, v2));
            if (v3 == 0) {
                goto IL_001B;
            } else {
                goto IL_000E;
            }
            IL_000E: ;
            string v4 = nsUri;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v5 = ref this;
            string v6 = v5.namespaceUri;
            int v7 = __cil_bool_load(System.String.op_Equality(v4, v6));
            return __cil_bool_store(v7);
            IL_001B: ;
            int v8 = 0;
            return __cil_bool_store(v8);
        }

        public bool MatchPrefix(string prefix, string lname)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            string v0 = lname;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref this;
            string v2 = v1.localname;
            int v3 = __cil_bool_load(System.String.op_Equality(v0, v2));
            if (v3 == 0) {
                goto IL_001B;
            } else {
                goto IL_000E;
            }
            IL_000E: ;
            string v4 = prefix;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v5 = ref this;
            string v6 = v5.prefix;
            int v7 = __cil_bool_load(System.String.op_Equality(v4, v6));
            return __cil_bool_store(v7);
            IL_001B: ;
            int v8 = 0;
            return __cil_bool_store(v8);
        }

        public void CheckPrefixNS(string prefix, string namespaceUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            IL_0000: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v0 = ref this;
            string v1 = v0.prefix;
            string v2 = prefix;
            int v3 = __cil_bool_load(System.String.op_Equality(v1, v2));
            if (v3 == 0) {
                goto IL_003E;
            } else {
                goto IL_000E;
            }
            IL_000E: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v4 = ref this;
            string v5 = v4.namespaceUri;
            string v6 = namespaceUri;
            int v7 = __cil_bool_load(System.String.op_Inequality(v5, v6));
            if (v7 == 0) {
                goto IL_003E;
            } else {
                goto IL_001C;
            }
            IL_001C: ;
            string v8 = System.SR.get_XmlBinary_NoRemapPrefix();
            int v9 = 3;
            __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v10 = __cil_newarr_01000003(v9);
            int v11 = 0;
            string v12 = prefix;
            v10[v11] = v12;
            int v13 = 1;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v14 = ref this;
            string v15 = v14.namespaceUri;
            v10[v13] = v15;
            int v16 = 2;
            string v17 = namespaceUri;
            v10[v16] = v17;
            global::System.Xml.XmlException v18 = __cil_newobj_06000A0A(v8, v10);
            throw v18;
            IL_003E: ;
            return;
        }

        public override int GetHashCode()
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v0 = ref this;
            string v1 = v0.prefix;
            int v2 = v1.GetHashCode();
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v3 = ref this;
            string v4 = v3.localname;
            int v5 = v4.GetHashCode();
            int v6 = unchecked(v2 ^ v5);
            return v6;
        }

        public int GetNSHashCode(System.Xml.SecureStringHasher hasher)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            global::System.Xml.SecureStringHasher v0 = hasher;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref this;
            string v2 = v1.namespaceUri;
            int v3 = __cil_callvirt_06000B88(v0, v2);
            global::System.Xml.SecureStringHasher v4 = hasher;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v5 = ref this;
            string v6 = v5.localname;
            int v7 = __cil_callvirt_06000B88(v4, v6);
            int v8 = unchecked(v3 ^ v7);
            return v8;
        }

        public override bool Equals(object other)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 l0 = default;
            IL_0000: ;
            object v0 = other;
            object v1 = ((object)(v0 is __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 ? v0 : null));
            if (v1 is null) {
                goto IL_001C;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            object v2 = other;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v3 = ((__cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01)(object)(v2));
            l0 = v3;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v4 = ref this;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v5 = v4;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v6 = l0;
            int v7 = __cil_bool_load(System.Xml.XmlSqlBinaryReader.QName.op_Equality(v5, v6));
            return __cil_bool_store(v7);
            IL_001C: ;
            int v8 = 0;
            return __cil_bool_store(v8);
        }

        public override string ToString()
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v0 = ref this;
            string v1 = v0.prefix;
            int v2 = ((System.String)v1).Length;
            if (v2 != 0) {
                goto IL_0014;
            } else {
                goto IL_000D;
            }
            IL_000D: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v3 = ref this;
            string v4 = v3.localname;
            return v4;
            IL_0014: ;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v5 = ref this;
            string v6 = v5.prefix;
            string v7 = __cil_ldstr_70000001(":");
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v8 = ref this;
            string v9 = v8.localname;
            string v10 = System.String.Concat(v6, v7, v9);
            return v10;
        }

        public static bool op_Equality(System.Xml.XmlSqlBinaryReader.QName a, System.Xml.XmlSqlBinaryReader.QName b)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            string v1 = a.prefix;
            string v3 = b.prefix;
            int v4 = __cil_bool_load(System.String.op_Equality(v1, v3));
            if (v4 == 0) {
                return false;
            } else {
                goto IL_0013;
            }
            IL_0013: ;
            string v6 = a.localname;
            string v8 = b.localname;
            int v9 = __cil_bool_load(System.String.op_Equality(v6, v8));
            if (v9 == 0) {
                return false;
            } else {
                goto IL_0026;
            }
            IL_0026: ;
            string v11 = a.namespaceUri;
            string v13 = b.namespaceUri;
            return System.String.op_Equality(v11, v13);
        }
    }

    private struct ElemInfo
    {
        public System.Xml.XmlSqlBinaryReader.QName name;
        public string xmlLang;
        public System.Xml.XmlSpace xmlSpace;
        public bool xmlspacePreserve;
        public System.Xml.XmlSqlBinaryReader.NamespaceDecl nsdecls;

        public void Set(System.Xml.XmlSqlBinaryReader.QName name, bool xmlspacePreserve)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // enum storage token=0x0200013A alias=__cil_enum_0200013A underlying=int: global::@System.@Xml.@XmlSpace; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            IL_0000: ;
            ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v0 = ref this;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = name;
            v0.name = v1;
            ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v2 = ref this;
            v2.xmlLang = null;
            ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v3 = ref this;
            int v4 = 0;
            v3.xmlSpace = unchecked((__cil_enum_0200013A)(v4));
            ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v5 = ref this;
            int v6 = __cil_bool_load(xmlspacePreserve);
            v5.xmlspacePreserve = __cil_bool_store(v6);
            return;
        }

        public System.Xml.XmlSqlBinaryReader.NamespaceDecl Clear()
        {
            // structural signature __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea bytes=1181B8: valuetype System.Xml.XmlSqlBinaryReader/ElemInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            System.Xml.XmlSqlBinaryReader.NamespaceDecl l0 = default;
            IL_0000: ;
            ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v0 = ref this;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v1 = v0.nsdecls;
            l0 = v1;
            ref __cil_value_2c7f38b104c9db9ebc1a998fd885c6ab6bbae4ea v2 = ref this;
            v2.nsdecls = null;
            global::System.Xml.XmlSqlBinaryReader.NamespaceDecl v3 = l0;
            return v3;
        }
    }

    private struct AttrInfo
    {
        public System.Xml.XmlSqlBinaryReader.QName name;
        public string val;
        public int contentPos;
        public int hashCode;
        public int prevHash;

        public void Set(System.Xml.XmlSqlBinaryReader.QName n, string v)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v0 = ref this;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = n;
            v0.name = v1;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v2 = ref this;
            string v3 = v;
            v2.val = v3;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v4 = ref this;
            int v5 = 0;
            v4.contentPos = v5;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v6 = ref this;
            int v7 = 0;
            v6.hashCode = v7;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v8 = ref this;
            int v9 = 0;
            v8.prevHash = v9;
            return;
        }

        public void Set(System.Xml.XmlSqlBinaryReader.QName n, int pos)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v0 = ref this;
            __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = n;
            v0.name = v1;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v2 = ref this;
            v2.val = null;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v3 = ref this;
            int v4 = pos;
            v3.contentPos = v4;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v5 = ref this;
            int v6 = 0;
            v5.hashCode = v6;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v7 = ref this;
            int v8 = 0;
            v7.prevHash = v8;
            return;
        }

        public void GetLocalnameAndNamespaceUri(out string localname, out string namespaceUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref string v0 = ref localname;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v1 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v2 = ref v1.name;
            string v3 = v2.localname;
            v0 = v3;
            ref string v4 = ref namespaceUri;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v5 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v6 = ref v5.name;
            string v7 = v6.namespaceUri;
            v4 = v7;
            return;
        }

        public int GetLocalnameAndNamespaceUriAndHash(System.Xml.SecureStringHasher hasher, out string localname, out string namespaceUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int l0 = default;
            IL_0000: ;
            ref string v0 = ref localname;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v1 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v2 = ref v1.name;
            string v3 = v2.localname;
            v0 = v3;
            ref string v4 = ref namespaceUri;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v5 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v6 = ref v5.name;
            string v7 = v6.namespaceUri;
            v4 = v7;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v8 = ref this;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v9 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v10 = ref v9.name;
            global::System.Xml.SecureStringHasher v11 = hasher;
            int v12 = __cil_direct_06000826(ref v10, v11);
            l0 = v12;
            v8.hashCode = v12;
            int v13 = l0;
            return v13;
        }

        public bool MatchNS(string localname, string namespaceUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v0 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v1 = ref v0.name;
            string v2 = localname;
            string v3 = namespaceUri;
            int v4 = __cil_bool_load(__cil_direct_06000822(ref v1, v2, v3));
            return __cil_bool_store(v4);
        }

        public bool MatchHashNS(int hash, string localname, string namespaceUri)
        {
            // structural signature __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 bytes=1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v0 = ref this;
            int v1 = v0.hashCode;
            int v2 = hash;
            if (unchecked((uint)v1) != unchecked((uint)v2)) {
                goto IL_0017;
            } else {
                goto IL_0009;
            }
            IL_0009: ;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v3 = ref this;
            ref __cil_value_432c10019b924dafd8c4ad80009d2e1c6a150d01 v4 = ref v3.name;
            string v5 = localname;
            string v6 = namespaceUri;
            int v7 = __cil_bool_load(__cil_direct_06000822(ref v4, v5, v6));
            return __cil_bool_store(v7);
            IL_0017: ;
            int v8 = 0;
            return __cil_bool_store(v8);
        }

        public void AdjustPosition(int adj)
        {
            // structural signature __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c bytes=1181BC: valuetype System.Xml.XmlSqlBinaryReader/AttrInfo; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v0 = ref this;
            int v1 = v0.contentPos;
            if (v1 == 0) {
                goto IL_0016;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v2 = ref this;
            ref __cil_value_11cb7005a9cb6ef275f1631e1989b010cc5b550c v3 = ref this;
            int v4 = v3.contentPos;
            int v5 = adj;
            int v6 = unchecked(v4 + v5);
            v2.contentPos = v6;
            goto IL_0016;
            IL_0016: ;
            return;
        }
    }

    private class NamespaceDecl
    {
        public string prefix;
        public string uri;
        public System.Xml.XmlSqlBinaryReader.NamespaceDecl scopeLink;
        public System.Xml.XmlSqlBinaryReader.NamespaceDecl prevLink;
        public int scope;
        public bool implied;

        public NamespaceDecl(string prefix, string nsuri, System.Xml.XmlSqlBinaryReader.NamespaceDecl nextInScope, System.Xml.XmlSqlBinaryReader.NamespaceDecl prevDecl, int scope, bool implied) : base()
        {
            this.prefix = prefix;
            this.uri = nsuri;
            this.scopeLink = nextInScope;
            this.prevLink = prevDecl;
            this.scope = scope;
            int v12 = __cil_bool_load(implied);
            this.implied = __cil_bool_store(v12);
            return;
        }
    }

    private struct SymbolTables
    {
        public string[] symtable;
        public int symCount;
        public System.Xml.XmlSqlBinaryReader.QName[] qnametable;
        public int qnameCount;

        public void Init()
        {
            // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c bytes=1D1181B4: valuetype System.Xml.XmlSqlBinaryReader/QName[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            IL_0000: ;
            ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v0 = ref this;
            int v1 = 64;
            __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v2 = __cil_newarr_01000003(v1);
            v0.symtable = v2;
            ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v3 = ref this;
            int v4 = 16;
            __cil_ref_58ab1af886553d82bd1165e7b2b96315ca988a1c v5 = __cil_newarr_0200006D(v4);
            v3.qnametable = v5;
            ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v6 = ref this;
            __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v7 = v6.symtable;
            int v8 = 0;
            string v9 = __cil_ldsfld_0A000002();
            v7[v8] = v9;
            ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v10 = ref this;
            int v11 = 1;
            v10.symCount = v11;
            ref __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 v12 = ref this;
            int v13 = 1;
            v12.qnameCount = v13;
            return;
        }
    }

    private class NestedBinXml
    {
        public System.Xml.XmlSqlBinaryReader.SymbolTables symbolTables;
        public int docState;
        public System.Xml.XmlSqlBinaryReader.NestedBinXml next;

        public NestedBinXml(System.Xml.XmlSqlBinaryReader.SymbolTables symbolTables, int docState, System.Xml.XmlSqlBinaryReader.NestedBinXml next) : base()
        {
            // structural signature __cil_value_8bc067c15bbd5b2a346e997e2382b229a883a589 bytes=1181C4: valuetype System.Xml.XmlSqlBinaryReader/SymbolTables; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            this.symbolTables = symbolTables;
            this.docState = docState;
            this.next = next;
            return;
        }
    }
}
