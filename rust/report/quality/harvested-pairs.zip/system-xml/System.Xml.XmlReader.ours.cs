namespace System.Xml;

public abstract class XmlReader : System.IDisposable
{
    private static uint s_isTextualNodeBitmap;
    private static uint s_canReadContentAsBitmap;
    private static uint s_hasValueBitmap;

    public virtual System.Xml.XmlReaderSettings get_Settings()
    {
        return null;
    }

    public abstract System.Xml.XmlNodeType get_NodeType();

    public virtual string get_Name()
    {
        string v1 = __cil_callvirt_06000EBC(this);
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0014;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        string v4 = __cil_callvirt_06000EBA(this);
        return v4;
        IL_0014: ;
        global::System.Xml.XmlNameTable v6 = __cil_callvirt_06000EFA(this);
        string v8 = __cil_callvirt_06000EBC(this);
        string v9 = __cil_ldstr_70000001(":");
        string v11 = __cil_callvirt_06000EBA(this);
        string v12 = System.String.Concat(v8, v9, v11);
        string v13 = __cil_callvirt_06000A35(v6, v12);
        return v13;
    }

    public abstract string get_LocalName();

    public abstract string get_NamespaceURI();

    public abstract string get_Prefix();

    public virtual bool get_HasValue()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        return System.Xml.XmlReader.HasValueInternal(unchecked((__cil_enum_020000B5)(v1)));
    }

    public abstract string get_Value();

    public abstract int get_Depth();

    public abstract string get_BaseURI();

    public abstract bool get_IsEmptyElement();

    public virtual bool get_IsDefault()
    {
        return false;
    }

    public virtual char get_QuoteChar()
    {
        return unchecked((char)(34));
    }

    public virtual System.Xml.XmlSpace get_XmlSpace()
    {
        // enum storage token=0x0200013A alias=__cil_enum_0200013A underlying=int: global::@System.@Xml.@XmlSpace; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        return unchecked((__cil_enum_0200013A)(0));
    }

    public virtual string get_XmlLang()
    {
        string v0 = __cil_ldsfld_0A000002();
        return v0;
    }

    public virtual System.Xml.Schema.IXmlSchemaInfo get_SchemaInfo()
    {
        global::System.Xml.Schema.IXmlSchemaInfo v1 = ((object)this as System.Xml.Schema.IXmlSchemaInfo);
        return v1;
    }

    public virtual System.Type get_ValueType()
    {
        // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v0 = __cil_ldtoken_type_01000003;
        __cil_type_01000004 v1 = System.Type.GetTypeFromHandle(v0);
        return v1;
    }

    public virtual object ReadContentAsObject()
    {
        int v1 = __cil_bool_load(__cil_direct_06000F2B(this));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        string v3 = __cil_ldstr_7000D079("ReadContentAsObject");
        global::System.Exception v4 = __cil_direct_06000F29(this, v3);
        throw v4;
        IL_0014: ;
        string v6 = __cil_direct_06000F2F(this);
        return v6;
    }

    public virtual bool ReadContentAsBoolean()
    {
        bool l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000CF01("ReadContentAsBoolean");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            int v7 = __cil_bool_load(System.Xml.XmlConvert.ToBoolean(v6));
            l0 = __cil_bool_store(v7);
            goto IL_003B;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0023: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v8 = System.SR.get_Xml_ReadContentAsFormatException();
            string v9 = __cil_ldstr_7000CF2B("Boolean");
            global::System.FormatException v10 = l1;
            global::System.Xml.XmlReader v11 = this;
            global::System.Xml.IXmlLineInfo v12 = ((object)v11 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v13 = __cil_newobj_06000A0E(v8, v9, v10, v12);
            throw v13;
        }
        IL_003B: ;
        int v14 = __cil_bool_load(l0);
        return __cil_bool_store(v14);
    }

    public virtual System.DateTime ReadContentAsDateTime()
    {
        // structural signature __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b bytes=118145: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200009E alias=__cil_enum_0200009E underlying=int: global::@System.@Xml.@XmlDateTimeSerializationMode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000CF3B("ReadContentAsDateTime");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            int v7 = 3;
            __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v8 = System.Xml.XmlConvert.ToDateTime(v6, unchecked((__cil_enum_0200009E)(v7)));
            l0 = v8;
            goto IL_003C;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0024: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v9 = System.SR.get_Xml_ReadContentAsFormatException();
            string v10 = __cil_ldstr_7000CF67("DateTime");
            global::System.FormatException v11 = l1;
            global::System.Xml.XmlReader v12 = this;
            global::System.Xml.IXmlLineInfo v13 = ((object)v12 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v14 = __cil_newobj_06000A0E(v9, v10, v11, v13);
            throw v14;
        }
        IL_003C: ;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v15 = l0;
        return v15;
    }

    public virtual System.DateTimeOffset ReadContentAsDateTimeOffset()
    {
        // structural signature __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 bytes=118159: valuetype [System.Runtime]System.DateTimeOffset; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000DCF1("ReadContentAsDateTimeOffset");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 v7 = System.Xml.XmlConvert.ToDateTimeOffset(v6);
            l0 = v7;
            goto IL_003B;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0023: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v8 = System.SR.get_Xml_ReadContentAsFormatException();
            string v9 = __cil_ldstr_7000DD29("DateTimeOffset");
            global::System.FormatException v10 = l1;
            global::System.Xml.XmlReader v11 = this;
            global::System.Xml.IXmlLineInfo v12 = ((object)v11 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v13 = __cil_newobj_06000A0E(v8, v9, v10, v12);
            throw v13;
        }
        IL_003B: ;
        __cil_value_854596eda7f39f5bc9692f559802067ccbcb5736 v14 = l0;
        return v14;
    }

    public virtual double ReadContentAsDouble()
    {
        double l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000CF79("ReadContentAsDouble");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            double v7 = System.Xml.XmlConvert.ToDouble(v6);
            l0 = unchecked((double)(v7));
            goto IL_003B;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0023: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v8 = System.SR.get_Xml_ReadContentAsFormatException();
            string v9 = __cil_ldstr_7000CFA1("Double");
            global::System.FormatException v10 = l1;
            global::System.Xml.XmlReader v11 = this;
            global::System.Xml.IXmlLineInfo v12 = ((object)v11 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v13 = __cil_newobj_06000A0E(v8, v9, v10, v12);
            throw v13;
        }
        IL_003B: ;
        double v14 = l0;
        return unchecked((double)(v14));
    }

    public virtual float ReadContentAsFloat()
    {
        __cil_F l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000CFAF("ReadContentAsFloat");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            __cil_F v7 = __cil_call_result_r4(System.Xml.XmlConvert.ToSingle(v6));
            l0 = v7;
            goto IL_003B;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0023: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v8 = System.SR.get_Xml_ReadContentAsFormatException();
            string v9 = __cil_ldstr_7000CFD5("Float");
            global::System.FormatException v10 = l1;
            global::System.Xml.XmlReader v11 = this;
            global::System.Xml.IXmlLineInfo v12 = ((object)v11 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v13 = __cil_newobj_06000A0E(v8, v9, v10, v12);
            throw v13;
        }
        IL_003B: ;
        __cil_F v14 = l0;
        return __cil_return_r4(v14);
    }

    public virtual System.Decimal ReadContentAsDecimal()
    {
        // structural signature __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f bytes=1169: valuetype [System.Runtime]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000CFE1("ReadContentAsDecimal");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v7 = System.Xml.XmlConvert.ToDecimal(v6);
            l0 = v7;
            goto IL_003B;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0023: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v8 = System.SR.get_Xml_ReadContentAsFormatException();
            string v9 = __cil_ldstr_7000D00B("Decimal");
            global::System.FormatException v10 = l1;
            global::System.Xml.XmlReader v11 = this;
            global::System.Xml.IXmlLineInfo v12 = ((object)v11 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v13 = __cil_newobj_06000A0E(v8, v9, v10, v12);
            throw v13;
        }
        IL_003B: ;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v14 = l0;
        return v14;
    }

    public virtual int ReadContentAsInt()
    {
        int l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000D01B("ReadContentAsInt");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            int v7 = System.Xml.XmlConvert.ToInt32(v6);
            l0 = v7;
            goto IL_003B;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0023: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v8 = System.SR.get_Xml_ReadContentAsFormatException();
            string v9 = __cil_ldstr_7000DD47("Int");
            global::System.FormatException v10 = l1;
            global::System.Xml.XmlReader v11 = this;
            global::System.Xml.IXmlLineInfo v12 = ((object)v11 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v13 = __cil_newobj_06000A0E(v8, v9, v10, v12);
            throw v13;
        }
        IL_003B: ;
        int v14 = l0;
        return v14;
    }

    public virtual long ReadContentAsLong()
    {
        long l0 = default;
        System.FormatException l1 = default;
        System.FormatException s4_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000D049("ReadContentAsLong");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        try {
            IL_0015: ;
            global::System.Xml.XmlReader v5 = this;
            string v6 = __cil_direct_06000F2F(v5);
            long v7 = System.Xml.XmlConvert.ToInt64(v6);
            l0 = v7;
            goto IL_003B;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_0023: ;
            s4_0 = __cil_exception_0;
            l1 = s4_0;
            string v8 = System.SR.get_Xml_ReadContentAsFormatException();
            string v9 = __cil_ldstr_7000DD4F("Long");
            global::System.FormatException v10 = l1;
            global::System.Xml.XmlReader v11 = this;
            global::System.Xml.IXmlLineInfo v12 = ((object)v11 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v13 = __cil_newobj_06000A0E(v8, v9, v10, v12);
            throw v13;
        }
        IL_003B: ;
        long v14 = l0;
        return v14;
    }

    public virtual string ReadContentAsString()
    {
        int v1 = __cil_bool_load(__cil_direct_06000F2B(this));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        string v3 = __cil_ldstr_7000DD59("ReadContentAsString");
        global::System.Exception v4 = __cil_direct_06000F29(this, v3);
        throw v4;
        IL_0014: ;
        string v6 = __cil_direct_06000F2F(this);
        return v6;
    }

    public virtual object ReadContentAs(System.Type returnType, System.Xml.IXmlNamespaceResolver namespaceResolver)
    {
        // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string l0 = default;
        object l1 = default;
        System.FormatException l2 = default;
        System.InvalidCastException l3 = default;
        System.Xml.Schema.XmlUntypedStringConverter s6_0 = default;
        string s6_1 = default;
        __cil_type_01000004 s6_2 = default;
        System.Xml.Schema.XmlUntypedStringConverter s7_0 = default;
        string s7_1 = default;
        __cil_type_01000004 s7_2 = default;
        System.Xml.Schema.XmlUntypedStringConverter s8_0 = default;
        string s8_1 = default;
        __cil_type_01000004 s8_2 = default;
        System.Xml.IXmlNamespaceResolver s8_3 = default;
        System.FormatException s9_0 = default;
        System.InvalidCastException s10_0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F2B(v0));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::System.Xml.XmlReader v2 = this;
        string v3 = __cil_ldstr_7000D0AF("ReadContentAs");
        global::System.Exception v4 = __cil_direct_06000F29(v2, v3);
        throw v4;
        IL_0014: ;
        global::System.Xml.XmlReader v5 = this;
        string v6 = __cil_direct_06000F2F(v5);
        l0 = v6;
        __cil_type_01000004 v7 = returnType;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v8 = __cil_ldtoken_type_01000003;
        __cil_type_01000004 v9 = System.Type.GetTypeFromHandle(v8);
        int v10 = __cil_bool_load(System.Type.op_Equality(v7, v9));
        if (v10 == 0) {
            goto IL_002F;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        string v11 = l0;
        return v11;
        IL_002F: ;
        try {
            IL_0030: ;
            global::System.Xml.Schema.XmlUntypedStringConverter v12 = System.Xml.Schema.XmlUntypedStringConverter.Instance;
            string v13 = l0;
            __cil_type_01000004 v14 = returnType;
            global::System.Xml.IXmlNamespaceResolver v15 = namespaceResolver;
            if (v15 is null) {
                System.Xml.Schema.XmlUntypedStringConverter e5_7_0 = v12;
                string e5_7_1 = v13;
                __cil_type_01000004 e5_7_2 = v14;
                s7_0 = e5_7_0;
                s7_1 = e5_7_1;
                s7_2 = e5_7_2;
                goto IL_003D;
            } else {
                System.Xml.Schema.XmlUntypedStringConverter e5_6_0 = v12;
                string e5_6_1 = v13;
                __cil_type_01000004 e5_6_2 = v14;
                s6_0 = e5_6_0;
                s6_1 = e5_6_1;
                s6_2 = e5_6_2;
                goto IL_003A;
            }
            IL_003A: ;
            global::System.Xml.IXmlNamespaceResolver v16 = namespaceResolver;
            System.Xml.Schema.XmlUntypedStringConverter e6_8_0 = s6_0;
            string e6_8_1 = s6_1;
            __cil_type_01000004 e6_8_2 = s6_2;
            System.Xml.IXmlNamespaceResolver e6_8_3 = v16;
            s8_0 = e6_8_0;
            s8_1 = e6_8_1;
            s8_2 = e6_8_2;
            s8_3 = e6_8_3;
            goto IL_0043;
            IL_003D: ;
            global::System.Xml.XmlReader v17 = this;
            global::System.Xml.IXmlNamespaceResolver v18 = ((object)v17 as System.Xml.IXmlNamespaceResolver);
            System.Xml.Schema.XmlUntypedStringConverter e7_8_0 = s7_0;
            string e7_8_1 = s7_1;
            __cil_type_01000004 e7_8_2 = s7_2;
            System.Xml.IXmlNamespaceResolver e7_8_3 = v18;
            s8_0 = e7_8_0;
            s8_1 = e7_8_1;
            s8_2 = e7_8_2;
            s8_3 = e7_8_3;
            goto IL_0043;
            IL_0043: ;
            object v19 = __cil_callvirt_06003127(s8_0, s8_1, s8_2, s8_3);
            l1 = v19;
            goto IL_007D;
        }
        catch (System.FormatException __cil_exception_0) {
            IL_004B: ;
            s9_0 = __cil_exception_0;
            l2 = s9_0;
            string v20 = System.SR.get_Xml_ReadContentAsFormatException();
            __cil_type_01000004 v21 = returnType;
            string v22 = v21.ToString();
            global::System.FormatException v23 = l2;
            global::System.Xml.XmlReader v24 = this;
            global::System.Xml.IXmlLineInfo v25 = ((object)v24 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v26 = __cil_newobj_06000A0E(v20, v22, v23, v25);
            throw v26;
        }
        catch (System.InvalidCastException __cil_exception_1) {
            IL_0064: ;
            s10_0 = __cil_exception_1;
            l3 = s10_0;
            string v27 = System.SR.get_Xml_ReadContentAsFormatException();
            __cil_type_01000004 v28 = returnType;
            string v29 = v28.ToString();
            global::System.InvalidCastException v30 = l3;
            global::System.Xml.XmlReader v31 = this;
            global::System.Xml.IXmlLineInfo v32 = ((object)v31 as System.Xml.IXmlLineInfo);
            global::System.Xml.XmlException v33 = __cil_newobj_06000A0E(v27, v29, v30, v32);
            throw v33;
        }
        IL_007D: ;
        object v34 = l1;
        return v34;
    }

    public virtual object ReadElementContentAsObject()
    {
        string v1 = __cil_ldstr_7000DD81("ReadElementContentAsObject");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        object v4 = __cil_callvirt_06000EC8(this);
        __cil_direct_06000F31(this);
        return v4;
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        return v7;
    }

    public virtual object ReadElementContentAsObject(string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        object v4 = __cil_callvirt_06000ED3(this);
        return v4;
    }

    public virtual bool ReadElementContentAsBoolean()
    {
        bool l0 = default;
        string v1 = __cil_ldstr_7000DDB7("ReadElementContentAsBoolean");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v4 = __cil_bool_load(__cil_callvirt_06000EC9(this));
        l0 = __cil_bool_store(v4);
        __cil_direct_06000F31(this);
        return l0;
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        return System.Xml.XmlConvert.ToBoolean(v7);
    }

    public virtual bool ReadElementContentAsBoolean(string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        return __cil_callvirt_06000ED5(this);
    }

    public virtual System.DateTime ReadElementContentAsDateTime()
    {
        // structural signature __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b bytes=118145: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200009E alias=__cil_enum_0200009E underlying=int: global::@System.@Xml.@XmlDateTimeSerializationMode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v1 = __cil_ldstr_7000DDEF("ReadElementContentAsDateTime");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v4 = __cil_callvirt_06000ECA(this);
        __cil_direct_06000F31(this);
        return v4;
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v9 = System.Xml.XmlConvert.ToDateTime(v7, unchecked((__cil_enum_0200009E)(3)));
        return v9;
    }

    public virtual System.DateTime ReadElementContentAsDateTime(string localName, string namespaceURI)
    {
        // structural signature __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b bytes=118145: valuetype [System.Runtime]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_direct_06000F28(this, localName, namespaceURI);
        __cil_value_95ca99e05873d0eaa3a1ffb6461032a9cb11768b v4 = __cil_callvirt_06000ED7(this);
        return v4;
    }

    public virtual double ReadElementContentAsDouble()
    {
        double l0 = default;
        string v1 = __cil_ldstr_7000DE29("ReadElementContentAsDouble");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        double v4 = __cil_callvirt_06000ECC(this);
        l0 = unchecked((double)(v4));
        __cil_direct_06000F31(this);
        double v6 = l0;
        return unchecked((double)(v6));
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        double v8 = System.Xml.XmlConvert.ToDouble(v7);
        return unchecked((double)(v8));
    }

    public virtual double ReadElementContentAsDouble(string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        double v4 = __cil_callvirt_06000ED9(this);
        return unchecked((double)(v4));
    }

    public virtual float ReadElementContentAsFloat()
    {
        string v1 = __cil_ldstr_7000DE5F("ReadElementContentAsFloat");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_F v4 = __cil_call_result_r4(__cil_callvirt_06000ECD(this));
        __cil_direct_06000F31(this);
        return __cil_return_r4(v4);
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        __cil_F v8 = __cil_call_result_r4(System.Xml.XmlConvert.ToSingle(v7));
        return __cil_return_r4(v8);
    }

    public virtual float ReadElementContentAsFloat(string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        __cil_F v4 = __cil_call_result_r4(__cil_callvirt_06000EDB(this));
        return __cil_return_r4(v4);
    }

    public virtual System.Decimal ReadElementContentAsDecimal()
    {
        // structural signature __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f bytes=1169: valuetype [System.Runtime]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string v1 = __cil_ldstr_7000DE93("ReadElementContentAsDecimal");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v4 = __cil_callvirt_06000ECE(this);
        __cil_direct_06000F31(this);
        return v4;
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v8 = System.Xml.XmlConvert.ToDecimal(v7);
        return v8;
    }

    public virtual System.Decimal ReadElementContentAsDecimal(string localName, string namespaceURI)
    {
        // structural signature __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f bytes=1169: valuetype [System.Runtime]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_direct_06000F28(this, localName, namespaceURI);
        __cil_value_801311b914b40a77a1220a1bb23e4fb8fc31ec0f v4 = __cil_callvirt_06000EDD(this);
        return v4;
    }

    public virtual int ReadElementContentAsInt()
    {
        string v1 = __cil_ldstr_7000DECB("ReadElementContentAsInt");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v4 = __cil_callvirt_06000ECF(this);
        __cil_direct_06000F31(this);
        return v4;
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        int v8 = System.Xml.XmlConvert.ToInt32(v7);
        return v8;
    }

    public virtual int ReadElementContentAsInt(string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        int v4 = __cil_callvirt_06000EDF(this);
        return v4;
    }

    public virtual long ReadElementContentAsLong()
    {
        string v1 = __cil_ldstr_7000DEFB("ReadElementContentAsLong");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        long v4 = __cil_callvirt_06000ED0(this);
        __cil_direct_06000F31(this);
        return v4;
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        long v8 = System.Xml.XmlConvert.ToInt64(v7);
        return v8;
    }

    public virtual long ReadElementContentAsLong(string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        long v4 = __cil_callvirt_06000EE1(this);
        return v4;
    }

    public virtual string ReadElementContentAsString()
    {
        string v1 = __cil_ldstr_7000DF2D("ReadElementContentAsString");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001C;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        string v4 = __cil_callvirt_06000ED1(this);
        __cil_direct_06000F31(this);
        return v4;
        IL_001C: ;
        string v7 = __cil_ldsfld_0A000002();
        return v7;
    }

    public virtual string ReadElementContentAsString(string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        string v4 = __cil_callvirt_06000EE3(this);
        return v4;
    }

    public virtual object ReadElementContentAs(System.Type returnType, System.Xml.IXmlNamespaceResolver namespaceResolver)
    {
        // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string v1 = __cil_ldstr_7000DF63("ReadElementContentAs");
        int v2 = __cil_bool_load(__cil_direct_06000F30(this, v1));
        if (v2 == 0) {
            goto IL_001E;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        object v6 = __cil_callvirt_06000ED2(this, returnType, namespaceResolver);
        __cil_direct_06000F31(this);
        return v6;
        IL_001E: ;
        __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v10 = __cil_ldtoken_type_01000003;
        __cil_type_01000004 v11 = System.Type.GetTypeFromHandle(v10);
        int v12 = __cil_bool_load(System.Type.op_Equality(returnType, v11));
        if (v12 != 0) {
            goto IL_0042;
        } else {
            goto IL_0030;
        }
        IL_0030: ;
        global::System.Xml.Schema.XmlUntypedStringConverter v13 = System.Xml.Schema.XmlUntypedStringConverter.Instance;
        string v14 = __cil_ldsfld_0A000002();
        object v17 = __cil_callvirt_06003127(v13, v14, returnType, namespaceResolver);
        return v17;
        IL_0042: ;
        string v18 = __cil_ldsfld_0A000002();
        return v18;
    }

    public virtual object ReadElementContentAs(System.Type returnType, System.Xml.IXmlNamespaceResolver namespaceResolver, string localName, string namespaceURI)
    {
        __cil_direct_06000F28(this, localName, namespaceURI);
        object v6 = __cil_callvirt_06000EE5(this, returnType, namespaceResolver);
        return v6;
    }

    public abstract int get_AttributeCount();

    public abstract string GetAttribute(string name);

    public abstract string GetAttribute(string name, string namespaceURI);

    public abstract string GetAttribute(int i);

    public virtual string get_Item(int i)
    {
        string v2 = __cil_callvirt_06000EEA(this, i);
        return v2;
    }

    public virtual string get_Item(string name)
    {
        string v2 = __cil_callvirt_06000EE8(this, name);
        return v2;
    }

    public virtual string get_Item(string name, string namespaceURI)
    {
        string v3 = __cil_callvirt_06000EE9(this, name, namespaceURI);
        return v3;
    }

    public abstract bool MoveToAttribute(string name);

    public abstract bool MoveToAttribute(string name, string ns);

    public virtual void MoveToAttribute(int i)
    {
        int l0 = default;
        if (i < 0) {
            goto IL_000D;
        } else {
            goto IL_0004;
        }
        IL_0004: ;
        int v4 = __cil_callvirt_06000EE7(this);
        if (i < v4) {
            goto IL_0018;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        string v5 = __cil_ldstr_7000CEFD("i");
        global::System.ArgumentOutOfRangeException v6 = __cil_newobj_0A0000A0(v5);
        throw v6;
        IL_0018: ;
        int v8 = __cil_bool_load(__cil_callvirt_06000EF3(this));
        int v10 = __cil_bool_load(__cil_callvirt_06000EF1(this));
        l0 = 0;
        goto IL_0035;
        IL_002A: ;
        int v13 = __cil_bool_load(__cil_callvirt_06000EF2(this));
        int v14 = l0;
        l0 = unchecked(v14 + 1);
        IL_0035: ;
        int v17 = l0;
        if (v17 < i) {
            goto IL_002A;
        } else {
            goto IL_0039;
        }
        IL_0039: ;
        return;
    }

    public abstract bool MoveToFirstAttribute();

    public abstract bool MoveToNextAttribute();

    public abstract bool MoveToElement();

    public abstract bool ReadAttributeValue();

    public abstract bool Read();

    public abstract bool get_EOF();

    public virtual void Close()
    {
        return;
    }

    public abstract System.Xml.ReadState get_ReadState();

    public virtual void Skip()
    {
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000EF8(this)));
        if (v1 == 1) {
            goto IL_000A;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        return;
        IL_000A: ;
        int v4 = __cil_bool_load(__cil_direct_06000F27(this));
        return;
    }

    public abstract System.Xml.XmlNameTable get_NameTable();

    public abstract string LookupNamespace(string prefix);

    public virtual bool get_CanResolveEntity()
    {
        return false;
    }

    public abstract void ResolveEntity();

    public virtual bool get_CanReadBinaryContent()
    {
        return false;
    }

    public virtual int ReadContentAsBase64(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DB5F("ReadContentAsBase64");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual int ReadElementContentAsBase64(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DBAF("ReadElementContentAsBase64");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual int ReadContentAsBinHex(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DB87("ReadContentAsBinHex");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual int ReadElementContentAsBinHex(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DBE5("ReadElementContentAsBinHex");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual bool get_CanReadValueChunk()
    {
        return false;
    }

    public virtual int ReadValueChunk(char[] buffer, int index, int count)
    {
        // structural signature __cil_ref_b1a6d254c63137a2f722e310f69dee01c797e9e8 bytes=1D03: char[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadValueChunkNotSupported();
        global::System.NotSupportedException v1 = __cil_newobj_0A0000BF(v0);
        throw v1;
    }

    public virtual string ReadString()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        int v1 = unchecked((int)(__cil_callvirt_06000EF8(this)));
        if (v1 == 1) {
            goto IL_000F;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = __cil_ldsfld_0A000002();
        return v3;
        IL_000F: ;
        int v5 = __cil_bool_load(__cil_callvirt_06000EF3(this));
        int v7 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v7) != unchecked((uint)1)) {
            goto IL_0050;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        int v10 = __cil_bool_load(__cil_callvirt_06000EC1(this));
        if (v10 == 0) {
            goto IL_002D;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        string v11 = __cil_ldsfld_0A000002();
        return v11;
        IL_002D: ;
        int v13 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v13 != 0) {
            goto IL_0040;
        } else {
            goto IL_0035;
        }
        IL_0035: ;
        string v14 = System.SR.get_Xml_InvalidOperation();
        global::System.InvalidOperationException v15 = __cil_newobj_0A000029(v14);
        throw v15;
        IL_0040: ;
        int v17 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v17) != unchecked((uint)15)) {
            goto IL_0050;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        string v19 = __cil_ldsfld_0A000002();
        return v19;
        IL_0050: ;
        string v20 = __cil_ldsfld_0A000002();
        l0 = v20;
        goto IL_006D;
        IL_0058: ;
        string v21 = l0;
        string v23 = __cil_callvirt_06000EBE(this);
        string v24 = System.String.Concat(v21, v23);
        l0 = v24;
        int v26 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v26 == 0) {
            goto IL_007A;
        } else {
            goto IL_006D;
        }
        IL_006D: ;
        int v28 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        int v29 = __cil_bool_load(System.Xml.XmlReader.IsTextualNode(unchecked((__cil_enum_020000B5)(v28))));
        if (v29 != 0) {
            goto IL_0058;
        } else {
            goto IL_007A;
        }
        IL_007A: ;
        string v30 = l0;
        return v30;
    }

    public virtual System.Xml.XmlNodeType MoveToContent()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        l0 = unchecked((__cil_enum_020000B5)(v1));
        int v2 = unchecked((int)(l0));
        int v4 = unchecked(v2 - 1);
        switch (v4) {
            case 0: {
                goto IL_0033;
            }
            case 1: {
                goto IL_002C;
            }
            case 2: {
                goto IL_0033;
            }
            case 3: {
                goto IL_0033;
            }
            case 4: {
                goto IL_0033;
            }
            default: {
                goto IL_0023;
            } }
        IL_0023: ;
        int v5 = unchecked((int)(l0));
        int v7 = unchecked(v5 - 15);
        if (unchecked((uint)v7) <= unchecked((uint)1)) {
            goto IL_0033;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        goto IL_003A;
        IL_002C: ;
        int v10 = __cil_bool_load(__cil_callvirt_06000EF3(this));
        IL_0033: ;
        int v12 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        return unchecked((__cil_enum_020000B5)(v12));
        IL_003A: ;
        int v14 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v14 != 0) {
            goto IL_0000;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        int v16 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        return unchecked((__cil_enum_020000B5)(v16));
    }

    public virtual void ReadStartElement()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000F06(v0)));
        int v2 = 1;
        if (v1 == v2) {
            goto IL_002E;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        l0 = unchecked((__cil_enum_020000B5)(v5));
        ref __cil_enum_020000B5 v6 = ref l0;
        string v7 = __cil_constrained_020000B5_0A000009(ref v6);
        global::System.Xml.XmlReader v8 = this;
        global::System.Xml.IXmlLineInfo v9 = ((object)v8 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v10 = __cil_newobj_06000A0D(v3, v7, v9);
        throw v10;
        IL_002E: ;
        global::System.Xml.XmlReader v11 = this;
        int v12 = __cil_bool_load(__cil_callvirt_06000EF5(v11));
        return;
    }

    public virtual void ReadStartElement(string name)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000F06(v0)));
        int v2 = 1;
        if (v1 == v2) {
            goto IL_002E;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        l0 = unchecked((__cil_enum_020000B5)(v5));
        ref __cil_enum_020000B5 v6 = ref l0;
        string v7 = __cil_constrained_020000B5_0A000009(ref v6);
        global::System.Xml.XmlReader v8 = this;
        global::System.Xml.IXmlLineInfo v9 = ((object)v8 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v10 = __cil_newobj_06000A0D(v3, v7, v9);
        throw v10;
        IL_002E: ;
        global::System.Xml.XmlReader v11 = this;
        string v12 = __cil_callvirt_06000EB9(v11);
        string v13 = name;
        int v14 = __cil_bool_load(System.String.op_Equality(v12, v13));
        if (v14 == 0) {
            goto IL_0044;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        global::System.Xml.XmlReader v15 = this;
        int v16 = __cil_bool_load(__cil_callvirt_06000EF5(v15));
        return;
        IL_0044: ;
        string v17 = System.SR.get_Xml_ElementNotFound();
        string v18 = name;
        global::System.Xml.XmlReader v19 = this;
        global::System.Xml.IXmlLineInfo v20 = ((object)v19 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v21 = __cil_newobj_06000A0D(v17, v18, v20);
        throw v21;
    }

    public virtual void ReadStartElement(string localname, string ns)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000F06(v0)));
        int v2 = 1;
        if (v1 == v2) {
            goto IL_002E;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        l0 = unchecked((__cil_enum_020000B5)(v5));
        ref __cil_enum_020000B5 v6 = ref l0;
        string v7 = __cil_constrained_020000B5_0A000009(ref v6);
        global::System.Xml.XmlReader v8 = this;
        global::System.Xml.IXmlLineInfo v9 = ((object)v8 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v10 = __cil_newobj_06000A0D(v3, v7, v9);
        throw v10;
        IL_002E: ;
        global::System.Xml.XmlReader v11 = this;
        string v12 = __cil_callvirt_06000EBA(v11);
        string v13 = localname;
        int v14 = __cil_bool_load(System.String.op_Equality(v12, v13));
        if (v14 == 0) {
            goto IL_0052;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        global::System.Xml.XmlReader v15 = this;
        string v16 = __cil_callvirt_06000EBB(v15);
        string v17 = ns;
        int v18 = __cil_bool_load(System.String.op_Equality(v16, v17));
        if (v18 == 0) {
            goto IL_0052;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        global::System.Xml.XmlReader v19 = this;
        int v20 = __cil_bool_load(__cil_callvirt_06000EF5(v19));
        return;
        IL_0052: ;
        string v21 = System.SR.get_Xml_ElementNotFoundNs();
        int v22 = 2;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v23 = __cil_newarr_01000003(v22);
        int v24 = 0;
        string v25 = localname;
        v23[v24] = v25;
        int v26 = 1;
        string v27 = ns;
        v23[v26] = v27;
        global::System.Xml.XmlReader v28 = this;
        global::System.Xml.IXmlLineInfo v29 = ((object)v28 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v30 = __cil_newobj_06000A0F(v21, v23, v29);
        throw v30;
    }

    public virtual string ReadElementString()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        __cil_enum_020000B5 l1 = default;
        IL_0000: ;
        string v0 = __cil_ldsfld_0A000002();
        l0 = v0;
        global::System.Xml.XmlReader v1 = this;
        int v2 = unchecked((int)(__cil_callvirt_06000F06(v1)));
        int v3 = 1;
        if (v2 == v3) {
            goto IL_0034;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        string v4 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v5 = this;
        int v6 = unchecked((int)(__cil_callvirt_06000EB8(v5)));
        l1 = unchecked((__cil_enum_020000B5)(v6));
        ref __cil_enum_020000B5 v7 = ref l1;
        string v8 = __cil_constrained_020000B5_0A000009(ref v7);
        global::System.Xml.XmlReader v9 = this;
        global::System.Xml.IXmlLineInfo v10 = ((object)v9 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v11 = __cil_newobj_06000A0D(v4, v8, v10);
        throw v11;
        IL_0034: ;
        global::System.Xml.XmlReader v12 = this;
        int v13 = __cil_bool_load(__cil_callvirt_06000EC1(v12));
        if (v13 != 0) {
            goto IL_0093;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        global::System.Xml.XmlReader v14 = this;
        int v15 = __cil_bool_load(__cil_callvirt_06000EF5(v14));
        global::System.Xml.XmlReader v16 = this;
        string v17 = __cil_callvirt_06000F05(v16);
        l0 = v17;
        global::System.Xml.XmlReader v18 = this;
        int v19 = unchecked((int)(__cil_callvirt_06000EB8(v18)));
        int v20 = 15;
        if (v19 == v20) {
            goto IL_008A;
        } else {
            goto IL_0054;
        }
        IL_0054: ;
        string v21 = System.SR.get_Xml_UnexpectedNodeInSimpleContent();
        int v22 = 2;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v23 = __cil_newarr_01000003(v22);
        int v24 = 0;
        global::System.Xml.XmlReader v25 = this;
        int v26 = unchecked((int)(__cil_callvirt_06000EB8(v25)));
        l1 = unchecked((__cil_enum_020000B5)(v26));
        ref __cil_enum_020000B5 v27 = ref l1;
        string v28 = __cil_constrained_020000B5_0A000009(ref v27);
        v23[v24] = v28;
        int v29 = 1;
        string v30 = __cil_ldstr_7000DF8D("ReadElementString");
        v23[v29] = v30;
        global::System.Xml.XmlReader v31 = this;
        global::System.Xml.IXmlLineInfo v32 = ((object)v31 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v33 = __cil_newobj_06000A0F(v21, v23, v32);
        throw v33;
        IL_008A: ;
        global::System.Xml.XmlReader v34 = this;
        int v35 = __cil_bool_load(__cil_callvirt_06000EF5(v34));
        goto IL_009A;
        IL_0093: ;
        global::System.Xml.XmlReader v36 = this;
        int v37 = __cil_bool_load(__cil_callvirt_06000EF5(v36));
        goto IL_009A;
        IL_009A: ;
        string v38 = l0;
        return v38;
    }

    public virtual string ReadElementString(string name)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        __cil_enum_020000B5 l1 = default;
        IL_0000: ;
        string v0 = __cil_ldsfld_0A000002();
        l0 = v0;
        global::System.Xml.XmlReader v1 = this;
        int v2 = unchecked((int)(__cil_callvirt_06000F06(v1)));
        int v3 = 1;
        if (v2 == v3) {
            goto IL_0034;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        string v4 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v5 = this;
        int v6 = unchecked((int)(__cil_callvirt_06000EB8(v5)));
        l1 = unchecked((__cil_enum_020000B5)(v6));
        ref __cil_enum_020000B5 v7 = ref l1;
        string v8 = __cil_constrained_020000B5_0A000009(ref v7);
        global::System.Xml.XmlReader v9 = this;
        global::System.Xml.IXmlLineInfo v10 = ((object)v9 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v11 = __cil_newobj_06000A0D(v4, v8, v10);
        throw v11;
        IL_0034: ;
        global::System.Xml.XmlReader v12 = this;
        string v13 = __cil_callvirt_06000EB9(v12);
        string v14 = name;
        int v15 = __cil_bool_load(System.String.op_Inequality(v13, v14));
        if (v15 == 0) {
            goto IL_0054;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        string v16 = System.SR.get_Xml_ElementNotFound();
        string v17 = name;
        global::System.Xml.XmlReader v18 = this;
        global::System.Xml.IXmlLineInfo v19 = ((object)v18 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v20 = __cil_newobj_06000A0D(v16, v17, v19);
        throw v20;
        IL_0054: ;
        global::System.Xml.XmlReader v21 = this;
        int v22 = __cil_bool_load(__cil_callvirt_06000EC1(v21));
        if (v22 != 0) {
            goto IL_009B;
        } else {
            goto IL_005C;
        }
        IL_005C: ;
        global::System.Xml.XmlReader v23 = this;
        string v24 = __cil_callvirt_06000F05(v23);
        l0 = v24;
        global::System.Xml.XmlReader v25 = this;
        int v26 = unchecked((int)(__cil_callvirt_06000EB8(v25)));
        int v27 = 15;
        if (v26 == v27) {
            goto IL_0092;
        } else {
            goto IL_006D;
        }
        IL_006D: ;
        string v28 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v29 = this;
        int v30 = unchecked((int)(__cil_callvirt_06000EB8(v29)));
        l1 = unchecked((__cil_enum_020000B5)(v30));
        ref __cil_enum_020000B5 v31 = ref l1;
        string v32 = __cil_constrained_020000B5_0A000009(ref v31);
        global::System.Xml.XmlReader v33 = this;
        global::System.Xml.IXmlLineInfo v34 = ((object)v33 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v35 = __cil_newobj_06000A0D(v28, v32, v34);
        throw v35;
        IL_0092: ;
        global::System.Xml.XmlReader v36 = this;
        int v37 = __cil_bool_load(__cil_callvirt_06000EF5(v36));
        goto IL_00A2;
        IL_009B: ;
        global::System.Xml.XmlReader v38 = this;
        int v39 = __cil_bool_load(__cil_callvirt_06000EF5(v38));
        goto IL_00A2;
        IL_00A2: ;
        string v40 = l0;
        return v40;
    }

    public virtual string ReadElementString(string localname, string ns)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        __cil_enum_020000B5 l1 = default;
        IL_0000: ;
        string v0 = __cil_ldsfld_0A000002();
        l0 = v0;
        global::System.Xml.XmlReader v1 = this;
        int v2 = unchecked((int)(__cil_callvirt_06000F06(v1)));
        int v3 = 1;
        if (v2 == v3) {
            goto IL_0034;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        string v4 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v5 = this;
        int v6 = unchecked((int)(__cil_callvirt_06000EB8(v5)));
        l1 = unchecked((__cil_enum_020000B5)(v6));
        ref __cil_enum_020000B5 v7 = ref l1;
        string v8 = __cil_constrained_020000B5_0A000009(ref v7);
        global::System.Xml.XmlReader v9 = this;
        global::System.Xml.IXmlLineInfo v10 = ((object)v9 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v11 = __cil_newobj_06000A0D(v4, v8, v10);
        throw v11;
        IL_0034: ;
        global::System.Xml.XmlReader v12 = this;
        string v13 = __cil_callvirt_06000EBA(v12);
        string v14 = localname;
        int v15 = __cil_bool_load(System.String.op_Inequality(v13, v14));
        if (v15 != 0) {
            goto IL_0050;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        global::System.Xml.XmlReader v16 = this;
        string v17 = __cil_callvirt_06000EBB(v16);
        string v18 = ns;
        int v19 = __cil_bool_load(System.String.op_Inequality(v17, v18));
        if (v19 == 0) {
            goto IL_006F;
        } else {
            goto IL_0050;
        }
        IL_0050: ;
        string v20 = System.SR.get_Xml_ElementNotFoundNs();
        int v21 = 2;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v22 = __cil_newarr_01000003(v21);
        int v23 = 0;
        string v24 = localname;
        v22[v23] = v24;
        int v25 = 1;
        string v26 = ns;
        v22[v25] = v26;
        global::System.Xml.XmlReader v27 = this;
        global::System.Xml.IXmlLineInfo v28 = ((object)v27 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v29 = __cil_newobj_06000A0F(v20, v22, v28);
        throw v29;
        IL_006F: ;
        global::System.Xml.XmlReader v30 = this;
        int v31 = __cil_bool_load(__cil_callvirt_06000EC1(v30));
        if (v31 != 0) {
            goto IL_00B6;
        } else {
            goto IL_0077;
        }
        IL_0077: ;
        global::System.Xml.XmlReader v32 = this;
        string v33 = __cil_callvirt_06000F05(v32);
        l0 = v33;
        global::System.Xml.XmlReader v34 = this;
        int v35 = unchecked((int)(__cil_callvirt_06000EB8(v34)));
        int v36 = 15;
        if (v35 == v36) {
            goto IL_00AD;
        } else {
            goto IL_0088;
        }
        IL_0088: ;
        string v37 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v38 = this;
        int v39 = unchecked((int)(__cil_callvirt_06000EB8(v38)));
        l1 = unchecked((__cil_enum_020000B5)(v39));
        ref __cil_enum_020000B5 v40 = ref l1;
        string v41 = __cil_constrained_020000B5_0A000009(ref v40);
        global::System.Xml.XmlReader v42 = this;
        global::System.Xml.IXmlLineInfo v43 = ((object)v42 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v44 = __cil_newobj_06000A0D(v37, v41, v43);
        throw v44;
        IL_00AD: ;
        global::System.Xml.XmlReader v45 = this;
        int v46 = __cil_bool_load(__cil_callvirt_06000EF5(v45));
        goto IL_00BD;
        IL_00B6: ;
        global::System.Xml.XmlReader v47 = this;
        int v48 = __cil_bool_load(__cil_callvirt_06000EF5(v47));
        goto IL_00BD;
        IL_00BD: ;
        string v49 = l0;
        return v49;
    }

    public virtual void ReadEndElement()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000F06(v0)));
        int v2 = 15;
        if (v1 == v2) {
            goto IL_002F;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        string v3 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        l0 = unchecked((__cil_enum_020000B5)(v5));
        ref __cil_enum_020000B5 v6 = ref l0;
        string v7 = __cil_constrained_020000B5_0A000009(ref v6);
        global::System.Xml.XmlReader v8 = this;
        global::System.Xml.IXmlLineInfo v9 = ((object)v8 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v10 = __cil_newobj_06000A0D(v3, v7, v9);
        throw v10;
        IL_002F: ;
        global::System.Xml.XmlReader v11 = this;
        int v12 = __cil_bool_load(__cil_callvirt_06000EF5(v11));
        return;
    }

    public virtual bool IsStartElement()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000F06(this)));
        return (v1 == 1);
    }

    public virtual bool IsStartElement(string name)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000F06(this)));
        if (unchecked((uint)v1) != unchecked((uint)1)) {
            return false;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v4 = __cil_callvirt_06000EB9(this);
        return System.String.op_Equality(v4, name);
    }

    public virtual bool IsStartElement(string localname, string ns)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000F06(this)));
        if (unchecked((uint)v1) != unchecked((uint)1)) {
            return false;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v4 = __cil_callvirt_06000EBA(this);
        int v6 = __cil_bool_load(System.String.op_Equality(v4, localname));
        if (v6 == 0) {
            return false;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        string v8 = __cil_callvirt_06000EBB(this);
        return System.String.op_Equality(v8, ns);
    }

    public virtual bool ReadToFollowing(string name)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = name;
        if (v0 is null) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = name;
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0017;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        string v3 = name;
        string v4 = __cil_ldstr_70000037("name");
        global::System.ArgumentException v5 = System.Xml.XmlConvert.CreateInvalidNameArgumentException(v3, v4);
        throw v5;
        IL_0017: ;
        global::System.Xml.XmlNameTable v7 = __cil_callvirt_06000EFA(this);
        string v8 = name;
        string v9 = __cil_callvirt_06000A35(v7, v8);
        name = v9;
        goto IL_0040;
        IL_0027: ;
        int v11 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v11) != unchecked((uint)1)) {
            goto IL_0040;
        } else {
            goto IL_0030;
        }
        IL_0030: ;
        string v13 = name;
        string v15 = __cil_callvirt_06000EB9(this);
        int v16 = __cil_bool_load(System.Xml.Ref.Equal(v13, v15));
        if (v16 == 0) {
            goto IL_0040;
        } else {
            return true;
        }
        IL_0040: ;
        int v19 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v19 != 0) {
            goto IL_0027;
        } else {
            return false;
        }
    }

    public virtual bool ReadToFollowing(string localName, string namespaceURI)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = localName;
        if (v0 is null) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = localName;
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0017;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        string v3 = localName;
        string v4 = __cil_ldstr_7000DFB1("localName");
        global::System.ArgumentException v5 = System.Xml.XmlConvert.CreateInvalidNameArgumentException(v3, v4);
        throw v5;
        IL_0017: ;
        string v6 = namespaceURI;
        if (v6 is not null) {
            goto IL_0025;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        string v7 = __cil_ldstr_70000041("namespaceURI");
        global::System.ArgumentNullException v8 = __cil_newobj_0A000062(v7);
        throw v8;
        IL_0025: ;
        global::System.Xml.XmlNameTable v10 = __cil_callvirt_06000EFA(this);
        string v11 = localName;
        string v12 = __cil_callvirt_06000A35(v10, v11);
        localName = v12;
        global::System.Xml.XmlNameTable v14 = __cil_callvirt_06000EFA(this);
        string v15 = namespaceURI;
        string v16 = __cil_callvirt_06000A35(v14, v15);
        namespaceURI = v16;
        goto IL_006A;
        IL_0043: ;
        int v18 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v18) != unchecked((uint)1)) {
            goto IL_006A;
        } else {
            goto IL_004C;
        }
        IL_004C: ;
        string v20 = localName;
        string v22 = __cil_callvirt_06000EBA(this);
        int v23 = __cil_bool_load(System.Xml.Ref.Equal(v20, v22));
        if (v23 == 0) {
            goto IL_006A;
        } else {
            goto IL_005A;
        }
        IL_005A: ;
        string v24 = namespaceURI;
        string v26 = __cil_callvirt_06000EBB(this);
        int v27 = __cil_bool_load(System.Xml.Ref.Equal(v24, v26));
        if (v27 == 0) {
            goto IL_006A;
        } else {
            return true;
        }
        IL_006A: ;
        int v30 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v30 != 0) {
            goto IL_0043;
        } else {
            return false;
        }
    }

    public virtual bool ReadToDescendant(string name)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        string v0 = name;
        if (v0 is null) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = name;
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0017;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        string v3 = name;
        string v4 = __cil_ldstr_70000037("name");
        global::System.ArgumentException v5 = System.Xml.XmlConvert.CreateInvalidNameArgumentException(v3, v4);
        throw v5;
        IL_0017: ;
        int v7 = __cil_callvirt_06000EBF(this);
        l0 = v7;
        int v9 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (v9 == 1) {
            goto IL_0037;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        int v12 = unchecked((int)(__cil_callvirt_06000EF8(this)));
        if (v12 != 0) {
            return false;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        int v13 = unchecked(l0--);
        goto IL_0041;
        IL_0037: ;
        int v18 = __cil_bool_load(__cil_callvirt_06000EC1(this));
        if (v18 == 0) {
            goto IL_0041;
        } else {
            return false;
        }
        IL_0041: ;
        global::System.Xml.XmlNameTable v21 = __cil_callvirt_06000EFA(this);
        string v22 = name;
        string v23 = __cil_callvirt_06000A35(v21, v22);
        name = v23;
        goto IL_006A;
        IL_0051: ;
        int v25 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v25) != unchecked((uint)1)) {
            goto IL_006A;
        } else {
            goto IL_005A;
        }
        IL_005A: ;
        string v27 = name;
        string v29 = __cil_callvirt_06000EB9(this);
        int v30 = __cil_bool_load(System.Xml.Ref.Equal(v27, v29));
        if (v30 == 0) {
            goto IL_006A;
        } else {
            return true;
        }
        IL_006A: ;
        int v33 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v33 == 0) {
            return false;
        } else {
            goto IL_0072;
        }
        IL_0072: ;
        int v35 = __cil_callvirt_06000EBF(this);
        int v36 = l0;
        if (v35 > v36) {
            goto IL_0051;
        } else {
            return false;
        }
    }

    public virtual bool ReadToDescendant(string localName, string namespaceURI)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        string v0 = localName;
        if (v0 is null) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = localName;
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0017;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        string v3 = localName;
        string v4 = __cil_ldstr_7000DFB1("localName");
        global::System.ArgumentException v5 = System.Xml.XmlConvert.CreateInvalidNameArgumentException(v3, v4);
        throw v5;
        IL_0017: ;
        string v6 = namespaceURI;
        if (v6 is not null) {
            goto IL_0025;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        string v7 = __cil_ldstr_70000041("namespaceURI");
        global::System.ArgumentNullException v8 = __cil_newobj_0A000062(v7);
        throw v8;
        IL_0025: ;
        int v10 = __cil_callvirt_06000EBF(this);
        l0 = v10;
        int v12 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (v12 == 1) {
            goto IL_0045;
        } else {
            goto IL_0035;
        }
        IL_0035: ;
        int v15 = unchecked((int)(__cil_callvirt_06000EF8(this)));
        if (v15 != 0) {
            return false;
        } else {
            goto IL_003D;
        }
        IL_003D: ;
        int v16 = unchecked(l0--);
        goto IL_004F;
        IL_0045: ;
        int v21 = __cil_bool_load(__cil_callvirt_06000EC1(this));
        if (v21 == 0) {
            goto IL_004F;
        } else {
            return false;
        }
        IL_004F: ;
        global::System.Xml.XmlNameTable v24 = __cil_callvirt_06000EFA(this);
        string v25 = localName;
        string v26 = __cil_callvirt_06000A35(v24, v25);
        localName = v26;
        global::System.Xml.XmlNameTable v28 = __cil_callvirt_06000EFA(this);
        string v29 = namespaceURI;
        string v30 = __cil_callvirt_06000A35(v28, v29);
        namespaceURI = v30;
        goto IL_0094;
        IL_006D: ;
        int v32 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v32) != unchecked((uint)1)) {
            goto IL_0094;
        } else {
            goto IL_0076;
        }
        IL_0076: ;
        string v34 = localName;
        string v36 = __cil_callvirt_06000EBA(this);
        int v37 = __cil_bool_load(System.Xml.Ref.Equal(v34, v36));
        if (v37 == 0) {
            goto IL_0094;
        } else {
            goto IL_0084;
        }
        IL_0084: ;
        string v38 = namespaceURI;
        string v40 = __cil_callvirt_06000EBB(this);
        int v41 = __cil_bool_load(System.Xml.Ref.Equal(v38, v40));
        if (v41 == 0) {
            goto IL_0094;
        } else {
            return true;
        }
        IL_0094: ;
        int v44 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v44 == 0) {
            return false;
        } else {
            goto IL_009C;
        }
        IL_009C: ;
        int v46 = __cil_callvirt_06000EBF(this);
        int v47 = l0;
        if (v46 > v47) {
            goto IL_006D;
        } else {
            return false;
        }
    }

    public virtual bool ReadToNextSibling(string name)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        string v0 = name;
        if (v0 is null) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = name;
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0017;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        string v3 = name;
        string v4 = __cil_ldstr_70000037("name");
        global::System.ArgumentException v5 = System.Xml.XmlConvert.CreateInvalidNameArgumentException(v3, v4);
        throw v5;
        IL_0017: ;
        global::System.Xml.XmlNameTable v7 = __cil_callvirt_06000EFA(this);
        string v8 = name;
        string v9 = __cil_callvirt_06000A35(v7, v8);
        name = v9;
        IL_0025: ;
        int v11 = __cil_bool_load(__cil_direct_06000F27(this));
        if (v11 == 0) {
            return false;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        int v13 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        l0 = unchecked((__cil_enum_020000B5)(v13));
        int v14 = unchecked((int)(l0));
        if (unchecked((uint)v14) != unchecked((uint)1)) {
            goto IL_0048;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        string v16 = name;
        string v18 = __cil_callvirt_06000EB9(this);
        int v19 = __cil_bool_load(System.Xml.Ref.Equal(v16, v18));
        if (v19 == 0) {
            goto IL_0048;
        } else {
            return true;
        }
        IL_0048: ;
        int v21 = unchecked((int)(l0));
        if (v21 == 15) {
            return false;
        } else {
            goto IL_004D;
        }
        IL_004D: ;
        int v24 = __cil_bool_load(__cil_callvirt_06000EF6(this));
        if (v24 == 0) {
            goto IL_0025;
        } else {
            return false;
        }
    }

    public virtual bool ReadToNextSibling(string localName, string namespaceURI)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        string v0 = localName;
        if (v0 is null) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = localName;
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0017;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        string v3 = localName;
        string v4 = __cil_ldstr_7000DFB1("localName");
        global::System.ArgumentException v5 = System.Xml.XmlConvert.CreateInvalidNameArgumentException(v3, v4);
        throw v5;
        IL_0017: ;
        string v6 = namespaceURI;
        if (v6 is not null) {
            goto IL_0025;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        string v7 = __cil_ldstr_70000041("namespaceURI");
        global::System.ArgumentNullException v8 = __cil_newobj_0A000062(v7);
        throw v8;
        IL_0025: ;
        global::System.Xml.XmlNameTable v10 = __cil_callvirt_06000EFA(this);
        string v11 = localName;
        string v12 = __cil_callvirt_06000A35(v10, v11);
        localName = v12;
        global::System.Xml.XmlNameTable v14 = __cil_callvirt_06000EFA(this);
        string v15 = namespaceURI;
        string v16 = __cil_callvirt_06000A35(v14, v15);
        namespaceURI = v16;
        IL_0041: ;
        int v18 = __cil_bool_load(__cil_direct_06000F27(this));
        if (v18 == 0) {
            return false;
        } else {
            goto IL_0049;
        }
        IL_0049: ;
        int v20 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        l0 = unchecked((__cil_enum_020000B5)(v20));
        int v21 = unchecked((int)(l0));
        if (unchecked((uint)v21) != unchecked((uint)1)) {
            goto IL_0072;
        } else {
            goto IL_0054;
        }
        IL_0054: ;
        string v23 = localName;
        string v25 = __cil_callvirt_06000EBA(this);
        int v26 = __cil_bool_load(System.Xml.Ref.Equal(v23, v25));
        if (v26 == 0) {
            goto IL_0072;
        } else {
            goto IL_0062;
        }
        IL_0062: ;
        string v27 = namespaceURI;
        string v29 = __cil_callvirt_06000EBB(this);
        int v30 = __cil_bool_load(System.Xml.Ref.Equal(v27, v29));
        if (v30 == 0) {
            goto IL_0072;
        } else {
            return true;
        }
        IL_0072: ;
        int v32 = unchecked((int)(l0));
        if (v32 == 15) {
            return false;
        } else {
            goto IL_0077;
        }
        IL_0077: ;
        int v35 = __cil_bool_load(__cil_callvirt_06000EF6(this));
        if (v35 == 0) {
            goto IL_0041;
        } else {
            return false;
        }
    }

    public static bool IsName(string str)
    {
        if (str is not null) {
            goto IL_0009;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.NullReferenceException v1 = __cil_newobj_0A00022A();
        throw v1;
        IL_0009: ;
        return System.Xml.ValidateNames.IsNameNoNamespaces(str);
    }

    public static bool IsNameToken(string str)
    {
        if (str is not null) {
            goto IL_0009;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.NullReferenceException v1 = __cil_newobj_0A00022A();
        throw v1;
        IL_0009: ;
        return System.Xml.ValidateNames.IsNmtokenNoNamespaces(str);
    }

    public virtual string ReadInnerXml()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_010000A1 l0 = default;
        System.Xml.XmlWriter l1 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000EF8(v0)));
        int v2 = 1;
        if (v1 == v2) {
            goto IL_000F;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = __cil_ldsfld_0A000002();
        return v3;
        IL_000F: ;
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        int v6 = 2;
        if (v5 == v6) {
            goto IL_002E;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::System.Xml.XmlReader v7 = this;
        int v8 = unchecked((int)(__cil_callvirt_06000EB8(v7)));
        int v9 = 1;
        if (v8 == v9) {
            goto IL_002E;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        global::System.Xml.XmlReader v10 = this;
        int v11 = __cil_bool_load(__cil_callvirt_06000EF5(v10));
        string v12 = __cil_ldsfld_0A000002();
        return v12;
        IL_002E: ;
        __cil_type_0100000C v13 = System.Globalization.CultureInfo.get_InvariantCulture();
        __cil_type_010000A1 v14 = __cil_newobj_0A00022B(v13);
        l0 = v14;
        global::System.Xml.XmlReader v15 = this;
        __cil_type_010000A1 v16 = l0;
        global::System.Xml.XmlWriter v17 = __cil_direct_06000F1D(v15, v16);
        l1 = v17;
        try {
            IL_0041: ;
            global::System.Xml.XmlReader v18 = this;
            int v19 = unchecked((int)(__cil_callvirt_06000EB8(v18)));
            int v20 = 2;
            if (unchecked((uint)v19) != unchecked((uint)v20)) {
                goto IL_0062;
            } else {
                goto IL_004A;
            }
            IL_004A: ;
            global::System.Xml.XmlWriter v21 = l1;
            global::System.Xml.XmlTextWriter v22 = ((System.Xml.XmlTextWriter)(object)v21);
            global::System.Xml.XmlReader v23 = this;
            int v24 = unchecked((int)(__cil_callvirt_06000EC3(v23)));
            __cil_callvirt_06001338(v22, unchecked((char)(v24)));
            global::System.Xml.XmlReader v25 = this;
            global::System.Xml.XmlWriter v26 = l1;
            __cil_direct_06000F1B(v25, v26);
            goto IL_0062;
            IL_0062: ;
            global::System.Xml.XmlReader v27 = this;
            int v28 = unchecked((int)(__cil_callvirt_06000EB8(v27)));
            int v29 = 1;
            if (unchecked((uint)v28) != unchecked((uint)v29)) {
                goto IL_0073;
            } else {
                goto IL_006B;
            }
            IL_006B: ;
            global::System.Xml.XmlReader v30 = this;
            global::System.Xml.XmlWriter v31 = l1;
            int v32 = 0;
            __cil_direct_06000F1A(v30, v31, __cil_bool_store(v32));
            goto IL_0073;
            IL_0073: ;
            goto IL_007C;
        }
        finally {
            IL_0075: ;
            global::System.Xml.XmlWriter v33 = l1;
            __cil_callvirt_06001668(v33);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_007C: ;
        __cil_type_010000A1 v34 = l0;
        string v35 = v34.ToString();
        return v35;
    }

    private void WriteNode(System.Xml.XmlWriter xtw, bool defattr)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        __cil_enum_020000B5 l1 = default;
        int s3_0 = default;
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (v1 == 0) {
            goto IL_0010;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v3 = __cil_callvirt_06000EBF(this);
        int e1_3_0 = v3;
        s3_0 = e1_3_0;
        goto IL_0011;
        IL_0010: ;
        int e2_3_0 = -1;
        s3_0 = e2_3_0;
        IL_0011: ;
        l0 = s3_0;
        goto IL_0140;
        IL_0017: ;
        int v6 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        l1 = unchecked((__cil_enum_020000B5)(v6));
        int v7 = unchecked((int)(l1));
        int v9 = unchecked(v7 - 1);
        switch (v9) {
            case 0: {
                goto IL_006F;
            }
            case 1: {
                goto IL_0140;
            }
            case 2: {
                goto IL_00B6;
            }
            case 3: {
                goto IL_00D2;
            }
            case 4: {
                goto IL_00E0;
            }
            case 5: {
                goto IL_0140;
            }
            case 6: {
                goto IL_00EE;
            }
            case 7: {
                goto IL_012C;
            }
            case 8: {
                goto IL_0140;
            }
            case 9: {
                goto IL_0102;
            }
            case 10: {
                goto IL_0140;
            }
            case 11: {
                goto IL_0140;
            }
            case 12: {
                goto IL_00C4;
            }
            case 13: {
                goto IL_00C4;
            }
            case 14: {
                goto IL_013A;
            }
            case 15: {
                goto IL_0140;
            }
            case 16: {
                goto IL_00EE;
            }
            default: {
                goto IL_006A;
            } }
        IL_006A: ;
        goto IL_0140;
        IL_006F: ;
        string v12 = __cil_callvirt_06000EBC(this);
        string v14 = __cil_callvirt_06000EBA(this);
        string v16 = __cil_callvirt_06000EBB(this);
        __cil_callvirt_0600164F(xtw, v12, v14, v16);
        global::System.Xml.XmlTextWriter v18 = ((System.Xml.XmlTextWriter)(object)xtw);
        int v20 = unchecked((int)(__cil_callvirt_06000EC3(this)));
        __cil_callvirt_06001338(v18, unchecked((char)(v20)));
        int v23 = __cil_bool_load(defattr);
        __cil_callvirt_0600167A(xtw, this, __cil_bool_store(v23));
        int v25 = __cil_bool_load(__cil_callvirt_06000EC1(this));
        if (v25 == 0) {
            goto IL_0140;
        } else {
            goto IL_00AB;
        }
        IL_00AB: ;
        __cil_callvirt_06001651(xtw);
        goto IL_0140;
        IL_00B6: ;
        string v29 = __cil_callvirt_06000EBE(this);
        __cil_callvirt_06001660(xtw, v29);
        goto IL_0140;
        IL_00C4: ;
        string v32 = __cil_callvirt_06000EBE(this);
        __cil_callvirt_0600165F(xtw, v32);
        goto IL_0140;
        IL_00D2: ;
        string v35 = __cil_callvirt_06000EBE(this);
        __cil_callvirt_0600165A(xtw, v35);
        goto IL_0140;
        IL_00E0: ;
        string v38 = __cil_callvirt_06000EB9(this);
        __cil_callvirt_0600165D(xtw, v38);
        goto IL_0140;
        IL_00EE: ;
        string v41 = __cil_callvirt_06000EB9(this);
        string v43 = __cil_callvirt_06000EBE(this);
        __cil_callvirt_0600165C(xtw, v41, v43);
        goto IL_0140;
        IL_0102: ;
        string v46 = __cil_callvirt_06000EB9(this);
        string v48 = __cil_ldstr_7000D143("PUBLIC");
        string v49 = __cil_callvirt_06000EE8(this, v48);
        string v51 = __cil_ldstr_7000D135("SYSTEM");
        string v52 = __cil_callvirt_06000EE8(this, v51);
        string v54 = __cil_callvirt_06000EBE(this);
        __cil_callvirt_0600164D(xtw, v46, v49, v52, v54);
        goto IL_0140;
        IL_012C: ;
        string v57 = __cil_callvirt_06000EBE(this);
        __cil_callvirt_0600165B(xtw, v57);
        goto IL_0140;
        IL_013A: ;
        __cil_callvirt_06001652(xtw);
        IL_0140: ;
        int v60 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v60 == 0) {
            goto IL_0154;
        } else {
            goto IL_0148;
        }
        IL_0148: ;
        int v61 = l0;
        int v63 = __cil_callvirt_06000EBF(this);
        if (v61 < v63) {
            goto IL_0017;
        } else {
            goto IL_0154;
        }
        IL_0154: ;
        int v64 = l0;
        int v66 = __cil_callvirt_06000EBF(this);
        if (unchecked((uint)v64) != unchecked((uint)v66)) {
            goto IL_016E;
        } else {
            goto IL_015D;
        }
        IL_015D: ;
        int v68 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v68) != unchecked((uint)15)) {
            goto IL_016E;
        } else {
            goto IL_0167;
        }
        IL_0167: ;
        int v71 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        IL_016E: ;
        return;
    }

    private void WriteAttributeValue(System.Xml.XmlWriter xtw)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        string v1 = __cil_callvirt_06000EB9(this);
        l0 = v1;
        goto IL_002C;
        IL_0009: ;
        int v3 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v3) != unchecked((uint)5)) {
            goto IL_0020;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        string v7 = __cil_callvirt_06000EB9(this);
        __cil_callvirt_0600165D(xtw, v7);
        goto IL_002C;
        IL_0020: ;
        string v10 = __cil_callvirt_06000EBE(this);
        __cil_callvirt_06001660(xtw, v10);
        IL_002C: ;
        int v12 = __cil_bool_load(__cil_callvirt_06000EF4(this));
        if (v12 != 0) {
            goto IL_0009;
        } else {
            goto IL_0034;
        }
        IL_0034: ;
        string v14 = l0;
        int v15 = __cil_bool_load(__cil_callvirt_06000EEE(this, v14));
        return;
    }

    public virtual string ReadOuterXml()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_010000A1 l0 = default;
        System.Xml.XmlWriter l1 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000EF8(v0)));
        int v2 = 1;
        if (v1 == v2) {
            goto IL_000F;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = __cil_ldsfld_0A000002();
        return v3;
        IL_000F: ;
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        int v6 = 2;
        if (v5 == v6) {
            goto IL_002E;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::System.Xml.XmlReader v7 = this;
        int v8 = unchecked((int)(__cil_callvirt_06000EB8(v7)));
        int v9 = 1;
        if (v8 == v9) {
            goto IL_002E;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        global::System.Xml.XmlReader v10 = this;
        int v11 = __cil_bool_load(__cil_callvirt_06000EF5(v10));
        string v12 = __cil_ldsfld_0A000002();
        return v12;
        IL_002E: ;
        __cil_type_0100000C v13 = System.Globalization.CultureInfo.get_InvariantCulture();
        __cil_type_010000A1 v14 = __cil_newobj_0A00022B(v13);
        l0 = v14;
        global::System.Xml.XmlReader v15 = this;
        __cil_type_010000A1 v16 = l0;
        global::System.Xml.XmlWriter v17 = __cil_direct_06000F1D(v15, v16);
        l1 = v17;
        try {
            IL_0041: ;
            global::System.Xml.XmlReader v18 = this;
            int v19 = unchecked((int)(__cil_callvirt_06000EB8(v18)));
            int v20 = 2;
            if (unchecked((uint)v19) != unchecked((uint)v20)) {
                goto IL_0071;
            } else {
                goto IL_004A;
            }
            IL_004A: ;
            global::System.Xml.XmlWriter v21 = l1;
            global::System.Xml.XmlReader v22 = this;
            string v23 = __cil_callvirt_06000EBC(v22);
            global::System.Xml.XmlReader v24 = this;
            string v25 = __cil_callvirt_06000EBA(v24);
            global::System.Xml.XmlReader v26 = this;
            string v27 = __cil_callvirt_06000EBB(v26);
            __cil_callvirt_06001657(v21, v23, v25, v27);
            global::System.Xml.XmlReader v28 = this;
            global::System.Xml.XmlWriter v29 = l1;
            __cil_direct_06000F1B(v28, v29);
            global::System.Xml.XmlWriter v30 = l1;
            __cil_callvirt_06001659(v30);
            goto IL_0082;
            IL_0071: ;
            global::System.Xml.XmlWriter v31 = l1;
            global::System.Xml.XmlReader v32 = this;
            int v33 = 0;
            __cil_callvirt_0600167B(v31, v32, __cil_bool_store(v33));
            goto IL_0082;
        }
        finally {
            IL_007B: ;
            global::System.Xml.XmlWriter v34 = l1;
            __cil_callvirt_06001668(v34);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0082: ;
        __cil_type_010000A1 v35 = l0;
        string v36 = v35.ToString();
        return v36;
    }

    private System.Xml.XmlWriter CreateWriterForInnerOuterXml(System.IO.StringWriter sw)
    {
        global::System.Xml.XmlTextWriter v1 = __cil_newobj_0600132D(sw);
        __cil_direct_06000F1E(this, v1);
        return v1;
    }

    private void SetNamespacesFlag(System.Xml.XmlTextWriter xtw)
    {
        System.Xml.XmlTextReader l0 = default;
        System.Xml.XmlValidatingReader l1 = default;
        global::System.Xml.XmlTextReader v1 = ((object)this as System.Xml.XmlTextReader);
        l0 = v1;
        global::System.Xml.XmlTextReader v2 = l0;
        if (v2 is null) {
            goto IL_0017;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::System.Xml.XmlTextReader v4 = l0;
        int v5 = __cil_bool_load(__cil_callvirt_06001070(v4));
        __cil_callvirt_06001330(xtw, __cil_bool_store(v5));
        return;
        IL_0017: ;
        global::System.Xml.XmlValidatingReader v7 = ((object)this as System.Xml.XmlValidatingReader);
        l1 = v7;
        global::System.Xml.XmlValidatingReader v8 = l1;
        if (v8 is null) {
            goto IL_002D;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        global::System.Xml.XmlValidatingReader v10 = l1;
        int v11 = __cil_bool_load(__cil_callvirt_0600148B(v10));
        __cil_callvirt_06001330(xtw, __cil_bool_store(v11));
        IL_002D: ;
        return;
    }

    public virtual System.Xml.XmlReader ReadSubtree()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (v1 == 1) {
            goto IL_0014;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        string v3 = System.SR.get_Xml_ReadSubtreeNotOnElement();
        global::System.InvalidOperationException v4 = __cil_newobj_0A000029(v3);
        throw v4;
        IL_0014: ;
        global::System.Xml.XmlSubtreeReader v6 = __cil_newobj_06000FB7(this);
        return v6;
    }

    public virtual bool get_HasAttributes()
    {
        int v1 = __cil_callvirt_06000EE7(this);
        return (v1 > 0);
    }

    public virtual void Dispose()
    {
        __cil_callvirt_06000F22(this, __cil_bool_store(1));
        return;
    }

    protected virtual void Dispose(bool disposing)
    {
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = __cil_bool_load(disposing);
        if (v0 == 0) {
            goto IL_0012;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        int v2 = unchecked((int)(__cil_callvirt_06000EF8(this)));
        if (v2 == 4) {
            goto IL_0012;
        } else {
            goto IL_000C;
        }
        IL_000C: ;
        __cil_callvirt_06000EF7(this);
        IL_0012: ;
        return;
    }

    internal virtual System.Xml.XmlNamespaceManager get_NamespaceManager()
    {
        return null;
    }

    internal static bool IsTextualNode(System.Xml.XmlNodeType nodeType)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(System.Xml.XmlReader.s_isTextualNodeBitmap));
        long v1 = unchecked((long)(uint)(v0));
        int v3 = unchecked((int)(nodeType));
        int v5 = unchecked(v3 & 31);
        int v6 = (1 << v5);
        return (unchecked((ulong)unchecked(v1 & unchecked((long)(v6)))) > unchecked((ulong)unchecked((long)(0))));
    }

    internal static bool CanReadContentAs(System.Xml.XmlNodeType nodeType)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(System.Xml.XmlReader.s_canReadContentAsBitmap));
        long v1 = unchecked((long)(uint)(v0));
        int v3 = unchecked((int)(nodeType));
        int v5 = unchecked(v3 & 31);
        int v6 = (1 << v5);
        return (unchecked((ulong)unchecked(v1 & unchecked((long)(v6)))) > unchecked((ulong)unchecked((long)(0))));
    }

    internal static bool HasValueInternal(System.Xml.XmlNodeType nodeType)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(System.Xml.XmlReader.s_hasValueBitmap));
        long v1 = unchecked((long)(uint)(v0));
        int v3 = unchecked((int)(nodeType));
        int v5 = unchecked(v3 & 31);
        int v6 = (1 << v5);
        return (unchecked((ulong)unchecked(v1 & unchecked((long)(v6)))) > unchecked((ulong)unchecked((long)(0))));
    }

    private bool SkipSubtree()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int l0 = default;
        int v1 = __cil_bool_load(__cil_callvirt_06000EF3(this));
        int v3 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v3) != unchecked((uint)1)) {
            goto IL_0041;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        int v6 = __cil_bool_load(__cil_callvirt_06000EC1(this));
        if (v6 != 0) {
            goto IL_0041;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        int v8 = __cil_callvirt_06000EBF(this);
        l0 = v8;
        IL_001F: ;
        int v10 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        if (v10 == 0) {
            goto IL_0030;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        int v11 = l0;
        int v13 = __cil_callvirt_06000EBF(this);
        if (v11 < v13) {
            goto IL_001F;
        } else {
            goto IL_0030;
        }
        IL_0030: ;
        int v15 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (unchecked((uint)v15) != unchecked((uint)15)) {
            return false;
        } else {
            goto IL_003A;
        }
        IL_003A: ;
        return __cil_callvirt_06000EF5(this);
        IL_0041: ;
        return __cil_callvirt_06000EF5(this);
    }

    internal void CheckElement(string localName, string namespaceURI)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        string v0 = localName;
        if (v0 is null) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = localName;
        int v2 = ((System.String)v1).Length;
        if (v2 != 0) {
            goto IL_0017;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        string v3 = localName;
        string v4 = __cil_ldstr_7000DFB1("localName");
        global::System.ArgumentException v5 = System.Xml.XmlConvert.CreateInvalidNameArgumentException(v3, v4);
        throw v5;
        IL_0017: ;
        string v6 = namespaceURI;
        if (v6 is not null) {
            goto IL_0025;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        string v7 = __cil_ldstr_70000041("namespaceURI");
        global::System.ArgumentNullException v8 = __cil_newobj_0A000062(v7);
        throw v8;
        IL_0025: ;
        global::System.Xml.XmlReader v9 = this;
        int v10 = unchecked((int)(__cil_callvirt_06000EB8(v9)));
        int v11 = 1;
        if (v10 == v11) {
            goto IL_0053;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        string v12 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v13 = this;
        int v14 = unchecked((int)(__cil_callvirt_06000EB8(v13)));
        l0 = unchecked((__cil_enum_020000B5)(v14));
        ref __cil_enum_020000B5 v15 = ref l0;
        string v16 = __cil_constrained_020000B5_0A000009(ref v15);
        global::System.Xml.XmlReader v17 = this;
        global::System.Xml.IXmlLineInfo v18 = ((object)v17 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v19 = __cil_newobj_06000A0D(v12, v16, v18);
        throw v19;
        IL_0053: ;
        global::System.Xml.XmlReader v20 = this;
        string v21 = __cil_callvirt_06000EBA(v20);
        string v22 = localName;
        int v23 = __cil_bool_load(System.String.op_Inequality(v21, v22));
        if (v23 != 0) {
            goto IL_006F;
        } else {
            goto IL_0061;
        }
        IL_0061: ;
        global::System.Xml.XmlReader v24 = this;
        string v25 = __cil_callvirt_06000EBB(v24);
        string v26 = namespaceURI;
        int v27 = __cil_bool_load(System.String.op_Inequality(v25, v26));
        if (v27 == 0) {
            goto IL_008E;
        } else {
            goto IL_006F;
        }
        IL_006F: ;
        string v28 = System.SR.get_Xml_ElementNotFoundNs();
        int v29 = 2;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v30 = __cil_newarr_01000003(v29);
        int v31 = 0;
        string v32 = localName;
        v30[v31] = v32;
        int v33 = 1;
        string v34 = namespaceURI;
        v30[v33] = v34;
        global::System.Xml.XmlReader v35 = this;
        global::System.Xml.IXmlLineInfo v36 = ((object)v35 as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v37 = __cil_newobj_06000A0F(v28, v30, v36);
        throw v37;
        IL_008E: ;
        return;
    }

    internal System.Exception CreateReadContentAsException(string methodName)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v2 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        global::System.Xml.IXmlLineInfo v4 = ((object)this as System.Xml.IXmlLineInfo);
        global::System.Exception v5 = System.Xml.XmlReader.CreateReadContentAsException(methodName, unchecked((__cil_enum_020000B5)(v2)), v4);
        return v5;
    }

    internal System.Exception CreateReadElementContentAsException(string methodName)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v2 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        global::System.Xml.IXmlLineInfo v4 = ((object)this as System.Xml.IXmlLineInfo);
        global::System.Exception v5 = System.Xml.XmlReader.CreateReadElementContentAsException(methodName, unchecked((__cil_enum_020000B5)(v2)), v4);
        return v5;
    }

    internal bool CanReadContentAs()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        return System.Xml.XmlReader.CanReadContentAs(unchecked((__cil_enum_020000B5)(v1)));
    }

    internal static System.Exception CreateReadContentAsException(string methodName, System.Xml.XmlNodeType nodeType, System.Xml.IXmlLineInfo lineInfo)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [28, B7, 03, 00, 06, 18, 8D, 03, 00, 00, 01, 25, 16, 02, A2, 25, 17, 0F, 01, FE, 16, B5, 00, 00]
        // .code-bytes IL_0018: [02, 6F, 09, 00, 00, 0A, A2, 0A, 06, 28, 61, 03, 00, 06, 04, 28, 2E, 0F, 00, 06, 73, 29, 00, 00]
        // .code-bytes IL_0030: [0A, 2A]
        // .local [0] object[]
        // IL_0000: call 0x060003B7 System.SR::get_Xml_InvalidReadContentAs
        // IL_0005: ldc.i4.2 2
        // IL_0006: newarr 0x01000003 [System.Runtime]System.String
        // IL_000B: dup 
        // IL_000C: ldc.i4.0 0
        // IL_000D: ldarg.0 0
        // IL_000E: stelem.ref 
        // IL_000F: dup 
        // IL_0010: ldc.i4.1 1
        // IL_0011: ldarga.s 1
        // IL_0013: constrained. 0x020000B5 System.Xml.XmlNodeType
        // IL_0019: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
        // IL_001E: stelem.ref 
        // IL_001F: stloc.0 0
        // IL_0020: ldloc.0 0
        // IL_0021: call 0x06000361 System.SR::Format
        // IL_0026: ldarg.2 2
        // IL_0027: call 0x06000F2E System.Xml.XmlReader::AddLineInfo
        // IL_002C: newobj 0x0A000029 [System.Runtime]System.InvalidOperationException::.ctor
        // IL_0031: ret 
    }

    internal static System.Exception CreateReadElementContentAsException(string methodName, System.Xml.XmlNodeType nodeType, System.Xml.IXmlLineInfo lineInfo)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [28, B8, 03, 00, 06, 18, 8D, 03, 00, 00, 01, 25, 16, 02, A2, 25, 17, 0F, 01, FE, 16, B5, 00, 00]
        // .code-bytes IL_0018: [02, 6F, 09, 00, 00, 0A, A2, 0A, 06, 28, 61, 03, 00, 06, 04, 28, 2E, 0F, 00, 06, 73, 29, 00, 00]
        // .code-bytes IL_0030: [0A, 2A]
        // .local [0] object[]
        // IL_0000: call 0x060003B8 System.SR::get_Xml_InvalidReadElementContentAs
        // IL_0005: ldc.i4.2 2
        // IL_0006: newarr 0x01000003 [System.Runtime]System.String
        // IL_000B: dup 
        // IL_000C: ldc.i4.0 0
        // IL_000D: ldarg.0 0
        // IL_000E: stelem.ref 
        // IL_000F: dup 
        // IL_0010: ldc.i4.1 1
        // IL_0011: ldarga.s 1
        // IL_0013: constrained. 0x020000B5 System.Xml.XmlNodeType
        // IL_0019: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
        // IL_001E: stelem.ref 
        // IL_001F: stloc.0 0
        // IL_0020: ldloc.0 0
        // IL_0021: call 0x06000361 System.SR::Format
        // IL_0026: ldarg.2 2
        // IL_0027: call 0x06000F2E System.Xml.XmlReader::AddLineInfo
        // IL_002C: newobj 0x0A000029 [System.Runtime]System.InvalidOperationException::.ctor
        // IL_0031: ret 
    }

    private static string AddLineInfo(string message, System.Xml.IXmlLineInfo lineInfo)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [03, 2C, 4D, 18, 8D, 03, 00, 00, 01, 0A, 06, 16, 03, 6F, EA, 08, 00, 06, 0B, 12, 01, 28, 5C, 00]
        // .code-bytes IL_0018: [00, 0A, 28, CC, 01, 00, 0A, A2, 06, 17, 03, 6F, EB, 08, 00, 06, 0B, 12, 01, 28, 5C, 00, 00, 0A]
        // .code-bytes IL_0030: [28, CC, 01, 00, 0A, A2, 02, 72, 81, D4, 00, 70, 28, 7C, 03, 00, 06, 06, 0C, 08, 28, 61, 03, 00]
        // .code-bytes IL_0048: [06, 28, 2B, 00, 00, 0A, 10, 00, 02, 2A]
        // .local [0] string[]
        // .local [1] int32
        // .local [2] object[]
        // IL_0000: ldarg.1 1
        // IL_0001: brfalse.s IL_0050
        // IL_0003: ldc.i4.2 2
        // IL_0004: newarr 0x01000003 [System.Runtime]System.String
        // IL_0009: stloc.0 0
        // IL_000A: ldloc.0 0
        // IL_000B: ldc.i4.0 0
        // IL_000C: ldarg.1 1
        // IL_000D: callvirt 0x060008EA System.Xml.IXmlLineInfo::get_LineNumber
        // IL_0012: stloc.1 1
        // IL_0013: ldloca.s 1
        // IL_0015: call 0x0A00005C [System.Runtime]System.Globalization.CultureInfo::get_InvariantCulture
        // IL_001A: call 0x0A0001CC [System.Runtime]System.Int32::ToString
        // IL_001F: stelem.ref 
        // IL_0020: ldloc.0 0
        // IL_0021: ldc.i4.1 1
        // IL_0022: ldarg.1 1
        // IL_0023: callvirt 0x060008EB System.Xml.IXmlLineInfo::get_LinePosition
        // IL_0028: stloc.1 1
        // IL_0029: ldloca.s 1
        // IL_002B: call 0x0A00005C [System.Runtime]System.Globalization.CultureInfo::get_InvariantCulture
        // IL_0030: call 0x0A0001CC [System.Runtime]System.Int32::ToString
        // IL_0035: stelem.ref 
        // IL_0036: ldarg.0 0
        // IL_0037: ldstr 0x7000D481 [32] utf16-bytes=[20, 00] terminal-flag=Some(0)
        // IL_003C: call 0x0600037C System.SR::get_Xml_ErrorPosition
        // IL_0041: ldloc.0 0
        // IL_0042: stloc.2 2
        // IL_0043: ldloc.2 2
        // IL_0044: call 0x06000361 System.SR::Format
        // IL_0049: call 0x0A00002B [System.Runtime]System.String::Concat
        // IL_004E: starg.s 0
        // IL_0050: ldarg.0 0
        // IL_0051: ret 
    }

    internal string InternalReadContentAsString()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        __cil_type_0100002E l1 = default;
        __cil_enum_020000B5 l2 = default;
        int s14_0 = default;
        string v0 = __cil_ldsfld_0A000002();
        l0 = v0;
        l1 = null;
        IL_0008: ;
        int v2 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        l2 = unchecked((__cil_enum_020000B5)(v2));
        int v3 = unchecked((int)(l2));
        int v5 = unchecked(v3 - 2);
        switch (v5) {
            case 0: {
                goto IL_0055;
            }
            case 1: {
                goto IL_005C;
            }
            case 2: {
                goto IL_005C;
            }
            case 3: {
                goto IL_008D;
            }
            case 4: {
                goto IL_00B6;
            }
            case 5: {
                goto IL_009B;
            }
            case 6: {
                goto IL_009B;
            }
            case 7: {
                goto IL_00B6;
            }
            case 8: {
                goto IL_00B6;
            }
            case 9: {
                goto IL_00B6;
            }
            case 10: {
                goto IL_00B6;
            }
            case 11: {
                goto IL_005C;
            }
            case 12: {
                goto IL_005C;
            }
            case 13: {
                goto IL_00B6;
            }
            case 14: {
                goto IL_009B;
            }
            default: {
                goto IL_0053;
            } }
        IL_0053: ;
        goto IL_00B6;
        IL_0055: ;
        string v7 = __cil_callvirt_06000EBE(this);
        return v7;
        IL_005C: ;
        string v8 = l0;
        int v9 = ((System.String)v8).Length;
        if (v9 != 0) {
            goto IL_006D;
        } else {
            goto IL_0064;
        }
        IL_0064: ;
        string v11 = __cil_callvirt_06000EBE(this);
        l0 = v11;
        goto IL_009B;
        IL_006D: ;
        __cil_type_0100002E v12 = l1;
        if (v12 is not null) {
            goto IL_007E;
        } else {
            goto IL_0070;
        }
        IL_0070: ;
        __cil_type_0100002E v13 = __cil_newobj_0A000053();
        l1 = v13;
        __cil_type_0100002E v14 = l1;
        string v15 = l0;
        __cil_type_0100002E v16 = v14.Append(v15);
        IL_007E: ;
        __cil_type_0100002E v17 = l1;
        string v19 = __cil_callvirt_06000EBE(this);
        __cil_type_0100002E v20 = v17.Append(v19);
        goto IL_009B;
        IL_008D: ;
        int v22 = __cil_bool_load(__cil_callvirt_06000EFC(this));
        if (v22 == 0) {
            goto IL_00B6;
        } else {
            goto IL_0095;
        }
        IL_0095: ;
        __cil_callvirt_06000EFD(this);
        IL_009B: ;
        int v25 = __cil_callvirt_06000EE7(this);
        if (v25 != 0) {
            goto IL_00AB;
        } else {
            goto IL_00A3;
        }
        IL_00A3: ;
        int v27 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        int e12_14_0 = v27;
        s14_0 = e12_14_0;
        goto IL_00B1;
        IL_00AB: ;
        int v29 = __cil_bool_load(__cil_callvirt_06000EF4(this));
        int e13_14_0 = v29;
        s14_0 = e13_14_0;
        IL_00B1: ;
        if (s14_0 != 0) {
            goto IL_0008;
        } else {
            goto IL_00B6;
        }
        IL_00B6: ;
        __cil_type_0100002E v30 = l1;
        if (v30 is null) {
            goto IL_00C0;
        } else {
            goto IL_00B9;
        }
        IL_00B9: ;
        __cil_type_0100002E v31 = l1;
        string v32 = v31.ToString();
        return v32;
        IL_00C0: ;
        string v33 = l0;
        return v33;
    }

    private bool SetupReadElementContentAsXxx(string methodName)
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        bool l0 = default;
        __cil_enum_020000B5 l1 = default;
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        if (v1 == 1) {
            goto IL_0011;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::System.Exception v5 = __cil_direct_06000F2A(this, methodName);
        throw v5;
        IL_0011: ;
        int v7 = __cil_bool_load(__cil_callvirt_06000EC1(this));
        l0 = __cil_bool_store(v7);
        int v9 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        int v10 = __cil_bool_load(l0);
        if (!(v10 == 0)) {
            return false;
        }
        int v13 = unchecked((int)(__cil_callvirt_06000EB8(this)));
        l1 = unchecked((__cil_enum_020000B5)(v13));
        int v14 = unchecked((int)(l1));
        if (unchecked((uint)v14) != unchecked((uint)15)) {
            goto IL_0039;
        } else {
            goto IL_0030;
        }
        IL_0030: ;
        int v17 = __cil_bool_load(__cil_callvirt_06000EF5(this));
        return false;
        IL_0039: ;
        int v19 = unchecked((int)(l1));
        if (unchecked((uint)v19) != unchecked((uint)1)) {
            return true;
        } else {
            goto IL_003D;
        }
        IL_003D: ;
        string v21 = System.SR.get_Xml_MixedReadElementContentAs();
        string v22 = __cil_ldsfld_0A000002();
        global::System.Xml.IXmlLineInfo v24 = ((object)this as System.Xml.IXmlLineInfo);
        global::System.Xml.XmlException v25 = __cil_newobj_06000A0D(v21, v22, v24);
        throw v25;
    }

    private void FinishReadElementContentAsXxx()
    {
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(v0)));
        int v2 = 15;
        if (v1 == v2) {
            goto IL_0029;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        string v3 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        l0 = unchecked((__cil_enum_020000B5)(v5));
        ref __cil_enum_020000B5 v6 = ref l0;
        string v7 = __cil_constrained_020000B5_0A000009(ref v6);
        global::System.Xml.XmlException v8 = __cil_newobj_06000A0B(v3, v7);
        throw v8;
        IL_0029: ;
        global::System.Xml.XmlReader v9 = this;
        int v10 = __cil_bool_load(__cil_callvirt_06000EF5(v9));
        return;
    }

    internal bool get_IsDefaultInternal()
    {
        System.Xml.Schema.IXmlSchemaInfo l0 = default;
        int v1 = __cil_bool_load(__cil_callvirt_06000EC2(this));
        if (!(v1 == 0)) {
            return true;
        }
        global::System.Xml.Schema.IXmlSchemaInfo v4 = __cil_callvirt_06000EC6(this);
        l0 = v4;
        global::System.Xml.Schema.IXmlSchemaInfo v5 = l0;
        if (v5 is null) {
            return false;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        global::System.Xml.Schema.IXmlSchemaInfo v6 = l0;
        int v7 = __cil_bool_load(__cil_callvirt_06002A0C(v6));
        if (v7 == 0) {
            return false;
        } else {
            return true;
        }
    }

    internal virtual System.Xml.IDtdInfo get_DtdInfo()
    {
        return null;
    }

    internal static System.Xml.ConformanceLevel GetV1ConformanceLevel(System.Xml.XmlReader reader)
    {
        // enum storage token=0x020000BE alias=__cil_enum_020000BE underlying=int: global::@System.@Xml.@ConformanceLevel; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        System.Xml.XmlTextReaderImpl l0 = default;
        global::System.Xml.XmlTextReaderImpl v1 = System.Xml.XmlReader.GetXmlTextReaderImpl(reader);
        l0 = v1;
        global::System.Xml.XmlTextReaderImpl v2 = l0;
        if (v2 is not null) {
            goto IL_000C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        return unchecked((__cil_enum_020000BE)(2));
        IL_000C: ;
        global::System.Xml.XmlTextReaderImpl v4 = l0;
        int v5 = unchecked((int)(__cil_callvirt_060011AA(v4)));
        return unchecked((__cil_enum_020000BE)(v5));
    }

    private static System.Xml.XmlTextReaderImpl GetXmlTextReaderImpl(System.Xml.XmlReader reader)
    {
        System.Xml.XmlTextReaderImpl l0 = default;
        System.Xml.XmlTextReader l1 = default;
        System.Xml.XmlValidatingReaderImpl l2 = default;
        System.Xml.XmlValidatingReader l3 = default;
        global::System.Xml.XmlTextReaderImpl v1 = ((object)reader as System.Xml.XmlTextReaderImpl);
        l0 = v1;
        global::System.Xml.XmlTextReaderImpl v2 = l0;
        if (v2 is null) {
            goto IL_000C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::System.Xml.XmlTextReaderImpl v3 = l0;
        return v3;
        IL_000C: ;
        global::System.Xml.XmlTextReader v5 = ((object)reader as System.Xml.XmlTextReader);
        l1 = v5;
        global::System.Xml.XmlTextReader v6 = l1;
        if (v6 is null) {
            goto IL_001D;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        global::System.Xml.XmlTextReader v7 = l1;
        global::System.Xml.XmlTextReaderImpl v8 = __cil_callvirt_06001083(v7);
        return v8;
        IL_001D: ;
        global::System.Xml.XmlValidatingReaderImpl v10 = ((object)reader as System.Xml.XmlValidatingReaderImpl);
        l2 = v10;
        global::System.Xml.XmlValidatingReaderImpl v11 = l2;
        if (v11 is null) {
            goto IL_002E;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        global::System.Xml.XmlValidatingReaderImpl v12 = l2;
        global::System.Xml.XmlTextReaderImpl v13 = __cil_callvirt_060014CC(v12);
        return v13;
        IL_002E: ;
        global::System.Xml.XmlValidatingReader v15 = ((object)reader as System.Xml.XmlValidatingReader);
        l3 = v15;
        global::System.Xml.XmlValidatingReader v16 = l3;
        if (v16 is null) {
            return null;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        global::System.Xml.XmlValidatingReader v17 = l3;
        global::System.Xml.XmlValidatingReaderImpl v18 = __cil_callvirt_0600148F(v17);
        global::System.Xml.XmlTextReaderImpl v19 = __cil_callvirt_060014CC(v18);
        return v19;
    }

    public static System.Xml.XmlReader Create(string inputUri)
    {
        global::System.Xml.XmlReader v1 = System.Xml.XmlReader.Create(inputUri, ((System.Xml.XmlReaderSettings)(null)), ((System.Xml.XmlParserContext)(null)));
        return v1;
    }

    public static System.Xml.XmlReader Create(string inputUri, System.Xml.XmlReaderSettings settings)
    {
        global::System.Xml.XmlReader v2 = System.Xml.XmlReader.Create(inputUri, settings, ((System.Xml.XmlParserContext)(null)));
        return v2;
    }

    public static System.Xml.XmlReader Create(string inputUri, System.Xml.XmlReaderSettings settings, System.Xml.XmlParserContext inputContext)
    {
        global::System.Xml.XmlReaderSettings v0 = settings;
        if (v0 is not null) {
            goto IL_000A;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.Xml.XmlReaderSettings v1 = __cil_newobj_06000F77();
        settings = v1;
        IL_000A: ;
        global::System.Xml.XmlReaderSettings v2 = settings;
        global::System.Xml.XmlReader v5 = __cil_callvirt_06000FA4(v2, inputUri, inputContext);
        return v5;
    }

    public static System.Xml.XmlReader Create(System.IO.Stream input)
    {
        string v1 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReader v2 = System.Xml.XmlReader.Create(input, ((System.Xml.XmlReaderSettings)(null)), v1);
        return v2;
    }

    public static System.Xml.XmlReader Create(System.IO.Stream input, System.Xml.XmlReaderSettings settings)
    {
        string v2 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReader v3 = System.Xml.XmlReader.Create(input, settings, v2);
        return v3;
    }

    public static System.Xml.XmlReader Create(System.IO.Stream input, System.Xml.XmlReaderSettings settings, string baseUri)
    {
        global::System.Xml.XmlReaderSettings v0 = settings;
        if (v0 is not null) {
            goto IL_000A;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.Xml.XmlReaderSettings v1 = __cil_newobj_06000F77();
        settings = v1;
        IL_000A: ;
        global::System.Xml.XmlReaderSettings v2 = settings;
        global::System.Xml.XmlReader v5 = __cil_callvirt_06000FA5(v2, input, ((__cil_type_0100006E)(null)), baseUri, ((System.Xml.XmlParserContext)(null)));
        return v5;
    }

    public static System.Xml.XmlReader Create(System.IO.Stream input, System.Xml.XmlReaderSettings settings, System.Xml.XmlParserContext inputContext)
    {
        global::System.Xml.XmlReaderSettings v0 = settings;
        if (v0 is not null) {
            goto IL_000A;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.Xml.XmlReaderSettings v1 = __cil_newobj_06000F77();
        settings = v1;
        IL_000A: ;
        global::System.Xml.XmlReaderSettings v2 = settings;
        string v4 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReader v6 = __cil_callvirt_06000FA5(v2, input, ((__cil_type_0100006E)(null)), v4, inputContext);
        return v6;
    }

    public static System.Xml.XmlReader Create(System.IO.TextReader input)
    {
        string v1 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReader v2 = System.Xml.XmlReader.Create(input, ((System.Xml.XmlReaderSettings)(null)), v1);
        return v2;
    }

    public static System.Xml.XmlReader Create(System.IO.TextReader input, System.Xml.XmlReaderSettings settings)
    {
        string v2 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReader v3 = System.Xml.XmlReader.Create(input, settings, v2);
        return v3;
    }

    public static System.Xml.XmlReader Create(System.IO.TextReader input, System.Xml.XmlReaderSettings settings, string baseUri)
    {
        global::System.Xml.XmlReaderSettings v0 = settings;
        if (v0 is not null) {
            goto IL_000A;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.Xml.XmlReaderSettings v1 = __cil_newobj_06000F77();
        settings = v1;
        IL_000A: ;
        global::System.Xml.XmlReaderSettings v2 = settings;
        global::System.Xml.XmlReader v5 = __cil_callvirt_06000FA6(v2, input, baseUri, ((System.Xml.XmlParserContext)(null)));
        return v5;
    }

    public static System.Xml.XmlReader Create(System.IO.TextReader input, System.Xml.XmlReaderSettings settings, System.Xml.XmlParserContext inputContext)
    {
        global::System.Xml.XmlReaderSettings v0 = settings;
        if (v0 is not null) {
            goto IL_000A;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.Xml.XmlReaderSettings v1 = __cil_newobj_06000F77();
        settings = v1;
        IL_000A: ;
        global::System.Xml.XmlReaderSettings v2 = settings;
        string v4 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReader v6 = __cil_callvirt_06000FA6(v2, input, v4, inputContext);
        return v6;
    }

    public static System.Xml.XmlReader Create(System.Xml.XmlReader reader, System.Xml.XmlReaderSettings settings)
    {
        global::System.Xml.XmlReaderSettings v0 = settings;
        if (v0 is not null) {
            goto IL_000A;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::System.Xml.XmlReaderSettings v1 = __cil_newobj_06000F77();
        settings = v1;
        IL_000A: ;
        global::System.Xml.XmlReaderSettings v2 = settings;
        global::System.Xml.XmlReader v4 = __cil_callvirt_06000FA7(v2, reader);
        return v4;
    }

    internal static System.Xml.XmlReader CreateSqlReader(System.IO.Stream input, System.Xml.XmlReaderSettings settings, System.Xml.XmlParserContext inputContext)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000ED alias=__cil_enum_020000ED underlying=int: global::@System.@Xml.@ValidationType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        System.Xml.XmlReader l0 = default;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 l1 = default;
        int l2 = default;
        if (input is not null) {
            goto IL_000E;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = __cil_ldstr_7000DFC5("input");
        global::System.ArgumentNullException v2 = __cil_newobj_0A000062(v1);
        throw v2;
        IL_000E: ;
        global::System.Xml.XmlReaderSettings v3 = settings;
        if (v3 is not null) {
            goto IL_0018;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        global::System.Xml.XmlReaderSettings v4 = __cil_newobj_06000F77();
        settings = v4;
        IL_0018: ;
        int v6 = System.Xml.XmlReader.CalcBufferSize(input);
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v7 = __cil_newarr_0100003E(v6);
        l1 = v7;
        l2 = 0;
        IL_0026: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v10 = l1;
        int v11 = l2;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v12 = l1;
        nint v13 = unchecked((nint)(v12.LongLength));
        int v14 = unchecked((int)(v13));
        int v15 = l2;
        int v16 = unchecked(v14 - v15);
        int v17 = input.Read(v10, v11, v16);
        int v18 = l2;
        l2 = unchecked(v18 + v17);
        int v21 = v17;
        if (v21 <= 0) {
            goto IL_0040;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        int v23 = l2;
        if (v23 < 2) {
            goto IL_0026;
        } else {
            goto IL_0040;
        }
        IL_0040: ;
        int v25 = l2;
        if (v25 < 2) {
            goto IL_0082;
        } else {
            goto IL_0044;
        }
        IL_0044: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v27 = l1;
        int v29 = unchecked((int)(unchecked((byte)(unchecked((int)(v27[0]))))));
        if (unchecked((uint)v29) != unchecked((uint)223)) {
            goto IL_0082;
        } else {
            goto IL_004E;
        }
        IL_004E: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v31 = l1;
        int v33 = unchecked((int)(unchecked((byte)(unchecked((int)(v31[1]))))));
        if (unchecked((uint)v33) != unchecked((uint)255)) {
            goto IL_0082;
        } else {
            goto IL_0058;
        }
        IL_0058: ;
        if (inputContext is null) {
            goto IL_006B;
        } else {
            goto IL_005B;
        }
        IL_005B: ;
        string v36 = System.SR.get_XmlBinary_NoParserContext();
        string v37 = __cil_ldstr_7000DFD1("inputContext");
        global::System.ArgumentException v38 = __cil_newobj_0A00014E(v36, v37);
        throw v38;
        IL_006B: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v40 = l1;
        int v41 = l2;
        string v42 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReaderSettings v43 = settings;
        int v44 = __cil_bool_load(__cil_callvirt_06000F97(v43));
        global::System.Xml.XmlReaderSettings v45 = settings;
        global::System.Xml.XmlSqlBinaryReader v46 = __cil_newobj_06000794(input, v40, v41, v42, v44, v45);
        l0 = v46;
        goto IL_0099;
        IL_0082: ;
        __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v48 = l1;
        int v49 = l2;
        global::System.Xml.XmlReaderSettings v50 = settings;
        string v51 = __cil_ldsfld_0A000002();
        global::System.Xml.XmlReaderSettings v53 = settings;
        int v54 = __cil_bool_load(__cil_callvirt_06000F97(v53));
        global::System.Xml.XmlTextReaderImpl v55 = __cil_newobj_0600109A(input, v48, v49, v50, null, v51, inputContext, v54);
        l0 = v55;
        IL_0099: ;
        global::System.Xml.XmlReaderSettings v56 = settings;
        int v57 = unchecked((int)(__cil_callvirt_06000F99(v56)));
        if (v57 == 0) {
            goto IL_00A9;
        } else {
            goto IL_00A1;
        }
        IL_00A1: ;
        global::System.Xml.XmlReaderSettings v58 = settings;
        global::System.Xml.XmlReader v59 = l0;
        global::System.Xml.XmlReader v60 = __cil_callvirt_06000FAD(v58, v59);
        l0 = v60;
        IL_00A9: ;
        global::System.Xml.XmlReaderSettings v61 = settings;
        int v62 = __cil_bool_load(__cil_callvirt_06000F78(v61));
        if (v62 == 0) {
            goto IL_00B8;
        } else {
            goto IL_00B1;
        }
        IL_00B1: ;
        global::System.Xml.XmlReader v63 = l0;
        global::System.Xml.XmlAsyncCheckReader v64 = System.Xml.XmlAsyncCheckReader.CreateAsyncCheckWrapper(v63);
        l0 = v64;
        IL_00B8: ;
        global::System.Xml.XmlReader v65 = l0;
        return v65;
    }

    internal static int CalcBufferSize(System.IO.Stream input)
    {
        // IL fallback: unsupported opcode conv.ovf.i4 at IL_001B
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [20, 00, 10, 00, 00, 0A, 02, 6F, 18, 02, 00, 0A, 2C, 20, 02, 6F, 2C, 02, 00, 0A, 0B, 07, 06, 6A]
        // .code-bytes IL_0018: [2F, 05, 07, B7, 0A, 2B, 0F, 07, 20, 00, 00, 01, 00, 6A, 31, 06, 20, 00, 20, 00, 00, 0A, 06, 2A]
        // .local [0] int32
        // .local [1] int64
        // IL_0000: ldc.i4 4096
        // IL_0005: stloc.0 0
        // IL_0006: ldarg.0 0
        // IL_0007: callvirt 0x0A000218 [System.Runtime]System.IO.Stream::get_CanSeek
        // IL_000C: brfalse.s IL_002E
        // IL_000E: ldarg.0 0
        // IL_000F: callvirt 0x0A00022C [System.Runtime]System.IO.Stream::get_Length
        // IL_0014: stloc.1 1
        // IL_0015: ldloc.1 1
        // IL_0016: ldloc.0 0
        // IL_0017: conv.i8 
        // IL_0018: bge.s IL_001F
        // IL_001A: ldloc.1 1
        // IL_001B: conv.ovf.i4 
        // IL_001C: stloc.0 0
        // IL_001D: br.s IL_002E
        // IL_001F: ldloc.1 1
        // IL_0020: ldc.i4 65536
        // IL_0025: conv.i8 
        // IL_0026: ble.s IL_002E
        // IL_0028: ldc.i4 8192
        // IL_002D: stloc.0 0
        // IL_002E: ldloc.0 0
        // IL_002F: ret 
    }

    private object get_debuggerDisplayProxy()
    {
        // structural signature __cil_value_102b1436a0f7d300141a23dd94a3e4aeee9ffc34 bytes=1184AC: valuetype System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_102b1436a0f7d300141a23dd94a3e4aeee9ffc34 v1 = __cil_value_newobj_06000F5D(this);
        object v2 = ((object)((__cil_value_102b1436a0f7d300141a23dd94a3e4aeee9ffc34)(v1)));
        return v2;
    }

    public virtual System.Threading.Tasks.Task<string> GetValueAsync()
    {
        // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::System.NotImplementedException v0 = __cil_newobj_0A000074();
        throw v0;
    }

    public virtual System.Threading.Tasks.Task<object> ReadContentAsObjectAsync()
    {
        // structural signature __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 bytes=1512816D011C: class [System.Runtime]System.Threading.Tasks.Task`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 bytes=1184B0: valuetype System.Xml.XmlReader/<ReadContentAsObjectAsync>d__183; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 l0 = default;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 l1 = default;
        IL_0000: ;
        ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_04000574 = v1;
        ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v2 = ref l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v3 = __cil_value_call_0A0001E0();
        v2.__il_field_04000573 = v3;
        ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v4 = ref l0;
        int v5 = -1;
        v4.__il_field_04000572 = v5;
        __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v6 = l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v7 = v6.__il_field_04000573;
        l1 = v7;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v8 = ref l1;
        ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v9 = ref l0;
        __cil_methodspec_call_2B000095(ref v8, ref v9);
        ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v10 = ref l0;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v11 = ref v10.__il_field_04000573;
        __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 v12 = __cil_value_call_0A0001E2(ref v11);
        return v12;
    }

    public virtual System.Threading.Tasks.Task<string> ReadContentAsStringAsync()
    {
        // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(__cil_direct_06000F2B(this));
        if (v1 != 0) {
            goto IL_0014;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        string v3 = __cil_ldstr_7000DD59("ReadContentAsString");
        global::System.Exception v4 = __cil_direct_06000F29(this, v3);
        throw v4;
        IL_0014: ;
        __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v6 = __cil_direct_06000F58(this);
        return v6;
    }

    public virtual System.Threading.Tasks.Task<object> ReadContentAsAsync(System.Type returnType, System.Xml.IXmlNamespaceResolver namespaceResolver)
    {
        // structural signature __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 bytes=1512816D011C: class [System.Runtime]System.Threading.Tasks.Task`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 bytes=1184B4: valuetype System.Xml.XmlReader/<ReadContentAsAsync>d__185; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 l0 = default;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 l1 = default;
        IL_0000: ;
        ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_04000578 = v1;
        ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v2 = ref l0;
        __cil_type_01000004 v3 = returnType;
        v2.returnType = v3;
        ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v4 = ref l0;
        global::System.Xml.IXmlNamespaceResolver v5 = namespaceResolver;
        v4.namespaceResolver = v5;
        ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v6 = ref l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v7 = __cil_value_call_0A0001E0();
        v6.__il_field_04000577 = v7;
        ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v8 = ref l0;
        int v9 = -1;
        v8.__il_field_04000576 = v9;
        __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v10 = l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v11 = v10.__il_field_04000577;
        l1 = v11;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v12 = ref l1;
        ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v13 = ref l0;
        __cil_methodspec_call_2B000096(ref v12, ref v13);
        ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v14 = ref l0;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v15 = ref v14.__il_field_04000577;
        __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 v16 = __cil_value_call_0A0001E2(ref v15);
        return v16;
    }

    public virtual System.Threading.Tasks.Task<object> ReadElementContentAsObjectAsync()
    {
        // structural signature __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 bytes=1512816D011C: class [System.Runtime]System.Threading.Tasks.Task`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 bytes=1184B8: valuetype System.Xml.XmlReader/<ReadElementContentAsObjectAsync>d__186; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 l0 = default;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 l1 = default;
        IL_0000: ;
        ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_0400057E = v1;
        ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v2 = ref l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v3 = __cil_value_call_0A0001E0();
        v2.__il_field_0400057D = v3;
        ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v4 = ref l0;
        int v5 = -1;
        v4.__il_field_0400057C = v5;
        __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v6 = l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v7 = v6.__il_field_0400057D;
        l1 = v7;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v8 = ref l1;
        ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v9 = ref l0;
        __cil_methodspec_call_2B000097(ref v8, ref v9);
        ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v10 = ref l0;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v11 = ref v10.__il_field_0400057D;
        __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 v12 = __cil_value_call_0A0001E2(ref v11);
        return v12;
    }

    public virtual System.Threading.Tasks.Task<string> ReadElementContentAsStringAsync()
    {
        // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 bytes=1184BC: valuetype System.Xml.XmlReader/<ReadElementContentAsStringAsync>d__187; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 l0 = default;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a l1 = default;
        IL_0000: ;
        ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_04000585 = v1;
        ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v2 = ref l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v3 = __cil_value_call_0A00022D();
        v2.__il_field_04000584 = v3;
        ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v4 = ref l0;
        int v5 = -1;
        v4.__il_field_04000583 = v5;
        __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v6 = l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v7 = v6.__il_field_04000584;
        l1 = v7;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v8 = ref l1;
        ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v9 = ref l0;
        __cil_methodspec_call_2B000098(ref v8, ref v9);
        ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v10 = ref l0;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v11 = ref v10.__il_field_04000584;
        __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v12 = __cil_value_call_0A00022F(ref v11);
        return v12;
    }

    public virtual System.Threading.Tasks.Task<object> ReadElementContentAsAsync(System.Type returnType, System.Xml.IXmlNamespaceResolver namespaceResolver)
    {
        // structural signature __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 bytes=1512816D011C: class [System.Runtime]System.Threading.Tasks.Task`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 bytes=1184C0: valuetype System.Xml.XmlReader/<ReadElementContentAsAsync>d__188; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 l0 = default;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 l1 = default;
        IL_0000: ;
        ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_0400058C = v1;
        ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v2 = ref l0;
        __cil_type_01000004 v3 = returnType;
        v2.returnType = v3;
        ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v4 = ref l0;
        global::System.Xml.IXmlNamespaceResolver v5 = namespaceResolver;
        v4.namespaceResolver = v5;
        ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v6 = ref l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v7 = __cil_value_call_0A0001E0();
        v6.__il_field_0400058B = v7;
        ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v8 = ref l0;
        int v9 = -1;
        v8.__il_field_0400058A = v9;
        __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v10 = l0;
        __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v11 = v10.__il_field_0400058B;
        l1 = v11;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v12 = ref l1;
        ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v13 = ref l0;
        __cil_methodspec_call_2B000099(ref v12, ref v13);
        ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v14 = ref l0;
        ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v15 = ref v14.__il_field_0400058B;
        __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 v16 = __cil_value_call_0A0001E2(ref v15);
        return v16;
    }

    public virtual System.Threading.Tasks.Task<bool> ReadAsync()
    {
        // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::System.NotImplementedException v0 = __cil_newobj_0A000074();
        throw v0;
    }

    public virtual System.Threading.Tasks.Task SkipAsync()
    {
        // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000EF8(this)));
        if (v1 == 1) {
            goto IL_000F;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        __cil_type_0100005C v3 = System.Threading.Tasks.Task.get_CompletedTask();
        return v3;
        IL_000F: ;
        __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v5 = __cil_direct_06000F57(this);
        return v5;
    }

    public virtual System.Threading.Tasks.Task<int> ReadContentAsBase64Async(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_776ff80a3e1b8c7c06dfaca054d02ce205771121 bytes=1512816D0108: class [System.Runtime]System.Threading.Tasks.Task`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DB5F("ReadContentAsBase64");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual System.Threading.Tasks.Task<int> ReadElementContentAsBase64Async(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_776ff80a3e1b8c7c06dfaca054d02ce205771121 bytes=1512816D0108: class [System.Runtime]System.Threading.Tasks.Task`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DBAF("ReadElementContentAsBase64");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual System.Threading.Tasks.Task<int> ReadContentAsBinHexAsync(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_776ff80a3e1b8c7c06dfaca054d02ce205771121 bytes=1512816D0108: class [System.Runtime]System.Threading.Tasks.Task`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DB87("ReadContentAsBinHex");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual System.Threading.Tasks.Task<int> ReadElementContentAsBinHexAsync(byte[] buffer, int index, int count)
    {
        // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_776ff80a3e1b8c7c06dfaca054d02ce205771121 bytes=1512816D0108: class [System.Runtime]System.Threading.Tasks.Task`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadBinaryContentNotSupported();
        string v1 = __cil_ldstr_7000DBE5("ReadElementContentAsBinHex");
        string v2 = System.SR.Format(v0, ((object)(v1)));
        global::System.NotSupportedException v3 = __cil_newobj_0A0000BF(v2);
        throw v3;
    }

    public virtual System.Threading.Tasks.Task<int> ReadValueChunkAsync(char[] buffer, int index, int count)
    {
        // structural signature __cil_ref_b1a6d254c63137a2f722e310f69dee01c797e9e8 bytes=1D03: char[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_776ff80a3e1b8c7c06dfaca054d02ce205771121 bytes=1512816D0108: class [System.Runtime]System.Threading.Tasks.Task`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = System.SR.get_Xml_ReadValueChunkNotSupported();
        global::System.NotSupportedException v1 = __cil_newobj_0A0000BF(v0);
        throw v1;
    }

    public virtual System.Threading.Tasks.Task<System.Xml.XmlNodeType> MoveToContentAsync()
    {
        // structural signature __cil_ref_a084de18f040b69bb3ccca580840e49a09504c5d bytes=1512816D011182D4: class [System.Runtime]System.Threading.Tasks.Task`1<valuetype System.Xml.XmlNodeType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b bytes=1184C4: valuetype System.Xml.XmlReader/<MoveToContentAsync>d__196; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 bytes=15118185011182D4: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<valuetype System.Xml.XmlNodeType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b l0 = default;
        __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 l1 = default;
        IL_0000: ;
        ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_04000595 = v1;
        ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v2 = ref l0;
        __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v3 = __cil_value_call_0A000230();
        v2.__il_field_04000594 = v3;
        ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v4 = ref l0;
        int v5 = -1;
        v4.__il_field_04000593 = v5;
        __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v6 = l0;
        __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v7 = v6.__il_field_04000594;
        l1 = v7;
        ref __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v8 = ref l1;
        ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v9 = ref l0;
        __cil_methodspec_call_2B00009A(ref v8, ref v9);
        ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v10 = ref l0;
        ref __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v11 = ref v10.__il_field_04000594;
        __cil_ref_a084de18f040b69bb3ccca580840e49a09504c5d v12 = __cil_value_call_0A000232(ref v11);
        return v12;
    }

    public virtual System.Threading.Tasks.Task<string> ReadInnerXmlAsync()
    {
        // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 bytes=1184C8: valuetype System.Xml.XmlReader/<ReadInnerXmlAsync>d__197; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 l0 = default;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a l1 = default;
        IL_0000: ;
        ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_04000599 = v1;
        ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v2 = ref l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v3 = __cil_value_call_0A00022D();
        v2.__il_field_04000598 = v3;
        ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v4 = ref l0;
        int v5 = -1;
        v4.__il_field_04000597 = v5;
        __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v6 = l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v7 = v6.__il_field_04000598;
        l1 = v7;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v8 = ref l1;
        ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v9 = ref l0;
        __cil_methodspec_call_2B00009B(ref v8, ref v9);
        ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v10 = ref l0;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v11 = ref v10.__il_field_04000598;
        __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v12 = __cil_value_call_0A00022F(ref v11);
        return v12;
    }

    private System.Threading.Tasks.Task WriteNodeAsync(System.Xml.XmlWriter xtw, bool defattr)
    {
        // structural signature __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc bytes=11817D: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 bytes=1184CC: valuetype System.Xml.XmlReader/<WriteNodeAsync>d__198; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 l0 = default;
        __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc l1 = default;
        IL_0000: ;
        ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_040005A0 = v1;
        ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v2 = ref l0;
        global::System.Xml.XmlWriter v3 = xtw;
        v2.xtw = v3;
        ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v4 = ref l0;
        int v5 = __cil_bool_load(defattr);
        v4.defattr = __cil_bool_store(v5);
        ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v6 = ref l0;
        __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v7 = System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Create();
        v6.__il_field_0400059F = v7;
        ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v8 = ref l0;
        int v9 = -1;
        v8.__il_field_0400059E = v9;
        __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v10 = l0;
        __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v11 = v10.__il_field_0400059F;
        l1 = v11;
        ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v12 = ref l1;
        ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v13 = ref l0;
        __cil_methodspec_call_2B00009C(ref v12, ref v13);
        ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v14 = ref l0;
        ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v15 = ref v14.__il_field_0400059F;
        __cil_type_0100005C v16 = __cil_memberref_call_0A0000EF(ref v15);
        return v16;
    }

    public virtual System.Threading.Tasks.Task<string> ReadOuterXmlAsync()
    {
        // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a bytes=1184D0: valuetype System.Xml.XmlReader/<ReadOuterXmlAsync>d__199; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a l0 = default;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a l1 = default;
        IL_0000: ;
        ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_040005A9 = v1;
        ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v2 = ref l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v3 = __cil_value_call_0A00022D();
        v2.__il_field_040005A8 = v3;
        ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v4 = ref l0;
        int v5 = -1;
        v4.__il_field_040005A7 = v5;
        __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v6 = l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v7 = v6.__il_field_040005A8;
        l1 = v7;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v8 = ref l1;
        ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v9 = ref l0;
        __cil_methodspec_call_2B00009D(ref v8, ref v9);
        ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v10 = ref l0;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v11 = ref v10.__il_field_040005A8;
        __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v12 = __cil_value_call_0A00022F(ref v11);
        return v12;
    }

    private System.Threading.Tasks.Task<bool> SkipSubtreeAsync()
    {
        // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 bytes=1184D4: valuetype System.Xml.XmlReader/<SkipSubtreeAsync>d__200; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_03fd3b18870c594f421ab80395c461c692933e99 bytes=151181850102: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 l0 = default;
        __cil_value_03fd3b18870c594f421ab80395c461c692933e99 l1 = default;
        IL_0000: ;
        ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_040005AD = v1;
        ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v2 = ref l0;
        __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v3 = __cil_value_call_0A0000F1();
        v2.__il_field_040005AC = v3;
        ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v4 = ref l0;
        int v5 = -1;
        v4.__il_field_040005AB = v5;
        __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v6 = l0;
        __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v7 = v6.__il_field_040005AC;
        l1 = v7;
        ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v8 = ref l1;
        ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v9 = ref l0;
        __cil_methodspec_call_2B00009E(ref v8, ref v9);
        ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v10 = ref l0;
        ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v11 = ref v10.__il_field_040005AC;
        __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v12 = __cil_value_call_0A0000F3(ref v11);
        return v12;
    }

    internal System.Threading.Tasks.Task<string> InternalReadContentAsStringAsync()
    {
        // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 bytes=1184D8: valuetype System.Xml.XmlReader/<InternalReadContentAsStringAsync>d__201; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 l0 = default;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a l1 = default;
        IL_0000: ;
        ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_040005B2 = v1;
        ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v2 = ref l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v3 = __cil_value_call_0A00022D();
        v2.__il_field_040005B1 = v3;
        ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v4 = ref l0;
        int v5 = -1;
        v4.__il_field_040005B0 = v5;
        __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v6 = l0;
        __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v7 = v6.__il_field_040005B1;
        l1 = v7;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v8 = ref l1;
        ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v9 = ref l0;
        __cil_methodspec_call_2B00009F(ref v8, ref v9);
        ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v10 = ref l0;
        ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v11 = ref v10.__il_field_040005B1;
        __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v12 = __cil_value_call_0A00022F(ref v11);
        return v12;
    }

    private System.Threading.Tasks.Task<bool> SetupReadElementContentAsXxxAsync(string methodName)
    {
        // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_03fd3b18870c594f421ab80395c461c692933e99 bytes=151181850102: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 bytes=1184DC: valuetype System.Xml.XmlReader/<SetupReadElementContentAsXxxAsync>d__202; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 l0 = default;
        __cil_value_03fd3b18870c594f421ab80395c461c692933e99 l1 = default;
        IL_0000: ;
        ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v0 = ref l0;
        global::System.Xml.XmlReader v1 = this;
        v0.__il_field_040005BA = v1;
        ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v2 = ref l0;
        string v3 = methodName;
        v2.methodName = v3;
        ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v4 = ref l0;
        __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v5 = __cil_value_call_0A0000F1();
        v4.__il_field_040005B9 = v5;
        ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v6 = ref l0;
        int v7 = -1;
        v6.__il_field_040005B8 = v7;
        __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v8 = l0;
        __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v9 = v8.__il_field_040005B9;
        l1 = v9;
        ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v10 = ref l1;
        ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v11 = ref l0;
        __cil_methodspec_call_2B0000A0(ref v10, ref v11);
        ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v12 = ref l0;
        ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v13 = ref v12.__il_field_040005B9;
        __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v14 = __cil_value_call_0A0000F3(ref v13);
        return v14;
    }

    private System.Threading.Tasks.Task FinishReadElementContentAsXxxAsync()
    {
        // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020000B5 l0 = default;
        IL_0000: ;
        global::System.Xml.XmlReader v0 = this;
        int v1 = unchecked((int)(__cil_callvirt_06000EB8(v0)));
        int v2 = 15;
        if (v1 == v2) {
            goto IL_0029;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        string v3 = System.SR.get_Xml_InvalidNodeType();
        global::System.Xml.XmlReader v4 = this;
        int v5 = unchecked((int)(__cil_callvirt_06000EB8(v4)));
        l0 = unchecked((__cil_enum_020000B5)(v5));
        ref __cil_enum_020000B5 v6 = ref l0;
        string v7 = __cil_constrained_020000B5_0A000009(ref v6);
        global::System.Xml.XmlException v8 = __cil_newobj_06000A0B(v3, v7);
        throw v8;
        IL_0029: ;
        global::System.Xml.XmlReader v9 = this;
        __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v10 = __cil_callvirt_06000F4C(v9);
        return v10;
    }

    protected XmlReader() : base()
    {
        return;
    }

    static XmlReader()
    {
        System.Xml.XmlReader.s_isTextualNodeBitmap = unchecked((uint)(24600));
        System.Xml.XmlReader.s_canReadContentAsBitmap = unchecked((uint)(123324));
        System.Xml.XmlReader.s_hasValueBitmap = unchecked((uint)(157084));
        return;
    }
    // property System.Xml.XmlReaderSettings Settings { get: get_Settings; }
    // property System.Xml.XmlNodeType NodeType { get: get_NodeType; }
    // property string Name { get: get_Name; }
    // property string LocalName { get: get_LocalName; }
    // property string NamespaceURI { get: get_NamespaceURI; }
    // property string Prefix { get: get_Prefix; }
    // property bool HasValue { get: get_HasValue; }
    // property string Value { get: get_Value; }
    // property int Depth { get: get_Depth; }
    // property string BaseURI { get: get_BaseURI; }
    // property bool IsEmptyElement { get: get_IsEmptyElement; }
    // property bool IsDefault { get: get_IsDefault; }
    // property char QuoteChar { get: get_QuoteChar; }
    // property System.Xml.XmlSpace XmlSpace { get: get_XmlSpace; }
    // property string XmlLang { get: get_XmlLang; }
    // property System.Xml.Schema.IXmlSchemaInfo SchemaInfo { get: get_SchemaInfo; }
    // property System.Type ValueType { get: get_ValueType; }
    // property int AttributeCount { get: get_AttributeCount; }
    // property string this[int index0] { get: get_Item; }
    // property string this[string index0] { get: get_Item; }
    // property string this[string index0, string index1] { get: get_Item; }
    // property bool EOF { get: get_EOF; }
    // property System.Xml.ReadState ReadState { get: get_ReadState; }
    // property System.Xml.XmlNameTable NameTable { get: get_NameTable; }
    // property bool CanResolveEntity { get: get_CanResolveEntity; }
    // property bool CanReadBinaryContent { get: get_CanReadBinaryContent; }
    // property bool CanReadValueChunk { get: get_CanReadValueChunk; }
    // property bool HasAttributes { get: get_HasAttributes; }
    // property System.Xml.XmlNamespaceManager NamespaceManager { get: get_NamespaceManager; }
    // property bool IsDefaultInternal { get: get_IsDefaultInternal; }
    // property System.Xml.IDtdInfo DtdInfo { get: get_DtdInfo; }
    // property object debuggerDisplayProxy { get: get_debuggerDisplayProxy; }

    private struct XmlReaderDebuggerDisplayProxy
    {
        private System.Xml.XmlReader _reader;

        internal XmlReaderDebuggerDisplayProxy(System.Xml.XmlReader reader)
        {
            // structural signature __cil_value_102b1436a0f7d300141a23dd94a3e4aeee9ffc34 bytes=1184AC: valuetype System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_102b1436a0f7d300141a23dd94a3e4aeee9ffc34 v0 = ref this;
            global::System.Xml.XmlReader v1 = reader;
            v0._reader = v1;
            return;
        }

        public override string ToString()
        {
            // IL fallback: invalid user-string encoding: terminal flag differs from code units
            // .maxstack 4
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, 71, 05, 00, 04, 6F, B8, 0E, 00, 06, 0A, 12, 00, FE, 16, B5, 00, 00, 02, 6F, 09, 00, 00]
            // .code-bytes IL_0018: [0A, 0B, 06, 17, 59, 45, 11, 00, 00, 00, 05, 00, 00, 00, 26, 00, 00, 00, 74, 00, 00, 00, 74, 00]
            // .code-bytes IL_0030: [00, 00, 05, 00, 00, 00, 16, 01, 00, 00, 26, 00, 00, 00, 74, 00, 00, 00, 16, 01, 00, 00, 97, 00]
            // .code-bytes IL_0048: [00, 00, 16, 01, 00, 00, 16, 01, 00, 00, 74, 00, 00, 00, 74, 00, 00, 00, 05, 00, 00, 00, 05, 00]
            // .code-bytes IL_0060: [00, 00, 74, 00, 00, 00, 38, 11, 01, 00, 00, 07, 72, EB, DF, 00, 70, 02, 7B, 71, 05, 00, 04, 6F]
            // .code-bytes IL_0078: [B9, 0E, 00, 06, 72, FD, DF, 00, 70, 28, 33, 02, 00, 0A, 0B, 38, F0, 00, 00, 00, 1C, 8D, 03, 00]
            // .code-bytes IL_0090: [00, 01, 25, 16, 07, A2, 25, 17, 72, EB, DF, 00, 70, A2, 25, 18, 02, 7B, 71, 05, 00, 04, 6F, B9]
            // .code-bytes IL_00A8: [0E, 00, 06, A2, 25, 19, 72, 01, E0, 00, 70, A2, 25, 1A, 02, 7B, 71, 05, 00, 04, 6F, BE, 0E, 00]
            // .code-bytes IL_00C0: [06, 28, A8, 09, 00, 06, A2, 25, 1B, 72, FD, DF, 00, 70, A2, 28, 34, 02, 00, 0A, 0B, 38, A2, 00]
            // .code-bytes IL_00D8: [00, 00, 07, 72, 17, E0, 00, 70, 02, 7B, 71, 05, 00, 04, 6F, BE, 0E, 00, 06, 28, A8, 09, 00, 06]
            // .code-bytes IL_00F0: [72, FD, DF, 00, 70, 28, 33, 02, 00, 0A, 0B, 2B, 7F, 07, 72, EB, DF, 00, 70, 02, 7B, 71, 05, 00]
            // .code-bytes IL_0108: [04, 6F, B9, 0E, 00, 06, 72, 2B, E0, 00, 70, 28, 33, 02, 00, 0A, 0B, 07, 72, 2F, E0, 00, 70, 02]
            // .code-bytes IL_0120: [7B, 71, 05, 00, 04, 72, 35, D1, 00, 70, 6F, E8, 0E, 00, 06, 72, FD, DF, 00, 70, 28, 33, 02, 00]
            // .code-bytes IL_0138: [0A, 0B, 07, 72, 45, E0, 00, 70, 02, 7B, 71, 05, 00, 04, 72, 43, D1, 00, 70, 6F, E8, 0E, 00, 06]
            // .code-bytes IL_0150: [72, FD, DF, 00, 70, 28, 33, 02, 00, 0A, 0B, 07, 72, 17, E0, 00, 70, 02, 7B, 71, 05, 00, 04, 6F]
            // .code-bytes IL_0168: [BE, 0E, 00, 06, 28, A8, 09, 00, 06, 72, FD, DF, 00, 70, 28, 33, 02, 00, 0A, 0B, 07, 2A]
            // .local [0] valuetype System.Xml.XmlNodeType
            // .local [1] string
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_0006: callvirt 0x06000EB8 System.Xml.XmlReader::get_NodeType
            // IL_000B: stloc.0 0
            // IL_000C: ldloca.s 0
            // IL_000E: constrained. 0x020000B5 System.Xml.XmlNodeType
            // IL_0014: callvirt 0x0A000009 [System.Runtime]System.Object::ToString
            // IL_0019: stloc.1 1
            // IL_001A: ldloc.0 0
            // IL_001B: ldc.i4.1 1
            // IL_001C: sub 
            // IL_001D: switch IL_006B, IL_008C, IL_00DA, IL_00DA, IL_006B, IL_017C, IL_008C, IL_00DA, IL_017C, IL_00FD, IL_017C, IL_017C, IL_00DA, IL_00DA, IL_006B, IL_006B, IL_00DA
            // IL_0066: br IL_017C
            // IL_006B: ldloc.1 1
            // IL_006C: ldstr 0x7000DFEB [44, 32, 78, 97, 109, 101, 61, 34] utf16-bytes=[2C, 00, 20, 00, 4E, 00, 61, 00, 6D, 00, 65, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_0071: ldarg.0 0
            // IL_0072: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_0077: callvirt 0x06000EB9 System.Xml.XmlReader::get_Name
            // IL_007C: ldstr 0x7000DFFD [34] utf16-bytes=[22, 00] terminal-flag=Some(0)
            // IL_0081: call 0x0A000233 [System.Runtime]System.String::Concat
            // IL_0086: stloc.1 1
            // IL_0087: br IL_017C
            // IL_008C: ldc.i4.6 6
            // IL_008D: newarr 0x01000003 [System.Runtime]System.String
            // IL_0092: dup 
            // IL_0093: ldc.i4.0 0
            // IL_0094: ldloc.1 1
            // IL_0095: stelem.ref 
            // IL_0096: dup 
            // IL_0097: ldc.i4.1 1
            // IL_0098: ldstr 0x7000DFEB [44, 32, 78, 97, 109, 101, 61, 34] utf16-bytes=[2C, 00, 20, 00, 4E, 00, 61, 00, 6D, 00, 65, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_009D: stelem.ref 
            // IL_009E: dup 
            // IL_009F: ldc.i4.2 2
            // IL_00A0: ldarg.0 0
            // IL_00A1: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_00A6: callvirt 0x06000EB9 System.Xml.XmlReader::get_Name
            // IL_00AB: stelem.ref 
            // IL_00AC: dup 
            // IL_00AD: ldc.i4.3 3
            // IL_00AE: ldstr 0x7000E001 [34, 44, 32, 86, 97, 108, 117, 101, 61, 34] utf16-bytes=[22, 00, 2C, 00, 20, 00, 56, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_00B3: stelem.ref 
            // IL_00B4: dup 
            // IL_00B5: ldc.i4.4 4
            // IL_00B6: ldarg.0 0
            // IL_00B7: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_00BC: callvirt 0x06000EBE System.Xml.XmlReader::get_Value
            // IL_00C1: call 0x060009A8 System.Xml.XmlConvert::EscapeValueForDebuggerDisplay
            // IL_00C6: stelem.ref 
            // IL_00C7: dup 
            // IL_00C8: ldc.i4.5 5
            // IL_00C9: ldstr 0x7000DFFD [34] utf16-bytes=[22, 00] terminal-flag=Some(0)
            // IL_00CE: stelem.ref 
            // IL_00CF: call 0x0A000234 [System.Runtime]System.String::Concat
            // IL_00D4: stloc.1 1
            // IL_00D5: br IL_017C
            // IL_00DA: ldloc.1 1
            // IL_00DB: ldstr 0x7000E017 [44, 32, 86, 97, 108, 117, 101, 61, 34] utf16-bytes=[2C, 00, 20, 00, 56, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_00E0: ldarg.0 0
            // IL_00E1: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_00E6: callvirt 0x06000EBE System.Xml.XmlReader::get_Value
            // IL_00EB: call 0x060009A8 System.Xml.XmlConvert::EscapeValueForDebuggerDisplay
            // IL_00F0: ldstr 0x7000DFFD [34] utf16-bytes=[22, 00] terminal-flag=Some(0)
            // IL_00F5: call 0x0A000233 [System.Runtime]System.String::Concat
            // IL_00FA: stloc.1 1
            // IL_00FB: br.s IL_017C
            // IL_00FD: ldloc.1 1
            // IL_00FE: ldstr 0x7000DFEB [44, 32, 78, 97, 109, 101, 61, 34] utf16-bytes=[2C, 00, 20, 00, 4E, 00, 61, 00, 6D, 00, 65, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_0103: ldarg.0 0
            // IL_0104: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_0109: callvirt 0x06000EB9 System.Xml.XmlReader::get_Name
            // IL_010E: ldstr 0x7000E02B [39] utf16-bytes=[27, 00] terminal-flag=Some(0)
            // IL_0113: call 0x0A000233 [System.Runtime]System.String::Concat
            // IL_0118: stloc.1 1
            // IL_0119: ldloc.1 1
            // IL_011A: ldstr 0x7000E02F [44, 32, 83, 89, 83, 84, 69, 77, 61, 34] utf16-bytes=[2C, 00, 20, 00, 53, 00, 59, 00, 53, 00, 54, 00, 45, 00, 4D, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_011F: ldarg.0 0
            // IL_0120: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_0125: ldstr 0x7000D135 [83, 89, 83, 84, 69, 77] utf16-bytes=[53, 00, 59, 00, 53, 00, 54, 00, 45, 00, 4D, 00] terminal-flag=Some(0)
            // IL_012A: callvirt 0x06000EE8 System.Xml.XmlReader::GetAttribute
            // IL_012F: ldstr 0x7000DFFD [34] utf16-bytes=[22, 00] terminal-flag=Some(0)
            // IL_0134: call 0x0A000233 [System.Runtime]System.String::Concat
            // IL_0139: stloc.1 1
            // IL_013A: ldloc.1 1
            // IL_013B: ldstr 0x7000E045 [44, 32, 80, 85, 66, 76, 73, 67, 61, 34] utf16-bytes=[2C, 00, 20, 00, 50, 00, 55, 00, 42, 00, 4C, 00, 49, 00, 43, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_0140: ldarg.0 0
            // IL_0141: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_0146: ldstr 0x7000D143 [80, 85, 66, 76, 73, 67] utf16-bytes=[50, 00, 55, 00, 42, 00, 4C, 00, 49, 00, 43, 00] terminal-flag=Some(0)
            // IL_014B: callvirt 0x06000EE8 System.Xml.XmlReader::GetAttribute
            // IL_0150: ldstr 0x7000DFFD [34] utf16-bytes=[22, 00] terminal-flag=Some(0)
            // IL_0155: call 0x0A000233 [System.Runtime]System.String::Concat
            // IL_015A: stloc.1 1
            // IL_015B: ldloc.1 1
            // IL_015C: ldstr 0x7000E017 [44, 32, 86, 97, 108, 117, 101, 61, 34] utf16-bytes=[2C, 00, 20, 00, 56, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3D, 00, 22, 00] terminal-flag=Some(0)
            // IL_0161: ldarg.0 0
            // IL_0162: ldfld 0x04000571 System.Xml.XmlReader/XmlReaderDebuggerDisplayProxy::_reader
            // IL_0167: callvirt 0x06000EBE System.Xml.XmlReader::get_Value
            // IL_016C: call 0x060009A8 System.Xml.XmlConvert::EscapeValueForDebuggerDisplay
            // IL_0171: ldstr 0x7000DFFD [34] utf16-bytes=[22, 00] terminal-flag=Some(0)
            // IL_0176: call 0x0A000233 [System.Runtime]System.String::Concat
            // IL_017B: stloc.1 1
            // IL_017C: ldloc.1 1
            // IL_017D: ret 
        }
    }

    private struct __name_3C52656164436F6E74656E7441734F626A6563744173796E633E645F5F313833 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_04000572;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object> __il_field_04000573;
        public System.Xml.XmlReader __il_field_04000574;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<string> __il_field_04000575;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 bytes=1184B0: valuetype System.Xml.XmlReader/<ReadContentAsObjectAsync>d__183; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa bytes=151181A1010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa bytes=1511819D010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            object l2 = default;
            string l3 = default;
            __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa l4 = default;
            __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa l5 = default;
            System.Exception l6 = default;
            System.Exception s8_0 = default;
            IL_0000: ;
            ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v0 = ref this;
            int v1 = v0.__il_field_04000572;
            l0 = v1;
            ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_04000574;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                if (v4 == 0) {
                    goto IL_0066;
                } else {
                    goto IL_0011;
                }
                IL_0011: ;
                global::System.Xml.XmlReader v5 = l1;
                int v6 = __cil_bool_load(__cil_direct_06000F2B(v5));
                if (v6 != 0) {
                    goto IL_0025;
                } else {
                    goto IL_0019;
                }
                IL_0019: ;
                global::System.Xml.XmlReader v7 = l1;
                string v8 = __cil_ldstr_7000D079("ReadContentAsObject");
                global::System.Exception v9 = __cil_direct_06000F29(v7, v8);
                throw v9;
                IL_0025: ;
                global::System.Xml.XmlReader v10 = l1;
                __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v11 = __cil_direct_06000F58(v10);
                int v12 = 0;
                __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v13 = __cil_callvirt_0A00020B(v11, __cil_bool_store(v12));
                l5 = v13;
                ref __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v14 = ref l5;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v15 = __cil_value_call_0A00020C(ref v14);
                l4 = v15;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v16 = ref l4;
                int v17 = __cil_bool_load(__cil_value_call_0A00020D(ref v16));
                if (v17 != 0) {
                    goto IL_0083;
                } else {
                    goto IL_0045;
                }
                IL_0045: ;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v18 = ref this;
                int v19 = 0;
                l0 = v19;
                v18.__il_field_04000572 = v19;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v20 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v21 = l4;
                v20.__il_field_04000575 = v21;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v22 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v23 = ref v22.__il_field_04000573;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v24 = ref l4;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v25 = ref this;
                __cil_methodspec_call_2B0000A1(ref v23, ref v24, ref v25);
                goto IL_00BC;
                IL_0066: ;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v26 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v27 = v26.__il_field_04000575;
                l4 = v27;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v28 = ref this;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v29 = ref v28.__il_field_04000575;
                v29 = default;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v30 = ref this;
                int v31 = -1;
                l0 = v31;
                v30.__il_field_04000572 = v31;
                goto IL_0083;
                IL_0083: ;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v32 = ref l4;
                string v33 = __cil_value_call_0A00020E(ref v32);
                l3 = v33;
                string v34 = l3;
                l2 = v34;
                goto IL_00A8;
            }
            catch (System.Exception __cil_exception_0) {
                IL_008F: ;
                s8_0 = __cil_exception_0;
                l6 = s8_0;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v35 = ref this;
                int v36 = -2;
                v35.__il_field_04000572 = v36;
                ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v37 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v38 = ref v37.__il_field_04000573;
                global::System.Exception v39 = l6;
                __cil_value_call_0A0001E8(ref v38, v39);
                goto IL_00BC;
            }
            IL_00A8: ;
            ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v40 = ref this;
            int v41 = -2;
            v40.__il_field_04000572 = v41;
            ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v42 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v43 = ref v42.__il_field_04000573;
            object v44 = l2;
            __cil_value_call_0A0001E9(ref v43, v44);
            goto IL_00BC;
            IL_00BC: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 bytes=1184B0: valuetype System.Xml.XmlReader/<ReadContentAsObjectAsync>d__183; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_090550dd91abe197c5b8f8ede6940af78bf91763 v0 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v1 = ref v0.__il_field_04000573;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A0001EA(ref v1, v2);
            return;
        }
    }

    private struct __name_3C52656164436F6E74656E7441734173796E633E645F5F313835 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_04000576;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object> __il_field_04000577;
        public System.Xml.XmlReader __il_field_04000578;
        public System.Type returnType;
        public System.Xml.IXmlNamespaceResolver namespaceResolver;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<string> __il_field_0400057B;

        private virtual void MoveNext()
        {
            // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 bytes=1184B4: valuetype System.Xml.XmlReader/<ReadContentAsAsync>d__185; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa bytes=151181A1010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa bytes=1511819D010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            object l2 = default;
            string l3 = default;
            string l4 = default;
            __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa l5 = default;
            __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa l6 = default;
            System.FormatException l7 = default;
            System.InvalidCastException l8 = default;
            System.Exception l9 = default;
            System.Xml.Schema.XmlValueConverter s11_0 = default;
            string s11_1 = default;
            __cil_type_01000004 s11_2 = default;
            System.Xml.Schema.XmlValueConverter s12_0 = default;
            string s12_1 = default;
            __cil_type_01000004 s12_2 = default;
            System.Xml.Schema.XmlValueConverter s13_0 = default;
            string s13_1 = default;
            __cil_type_01000004 s13_2 = default;
            System.Xml.IXmlNamespaceResolver s13_3 = default;
            System.FormatException s14_0 = default;
            System.InvalidCastException s15_0 = default;
            System.Exception s16_0 = default;
            IL_0000: ;
            ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v0 = ref this;
            int v1 = v0.__il_field_04000576;
            l0 = v1;
            ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_04000578;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                if (v4 == 0) {
                    goto IL_0069;
                } else {
                    goto IL_0011;
                }
                IL_0011: ;
                global::System.Xml.XmlReader v5 = l1;
                int v6 = __cil_bool_load(__cil_direct_06000F2B(v5));
                if (v6 != 0) {
                    goto IL_0025;
                } else {
                    goto IL_0019;
                }
                IL_0019: ;
                global::System.Xml.XmlReader v7 = l1;
                string v8 = __cil_ldstr_7000D0AF("ReadContentAs");
                global::System.Exception v9 = __cil_direct_06000F29(v7, v8);
                throw v9;
                IL_0025: ;
                global::System.Xml.XmlReader v10 = l1;
                __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v11 = __cil_direct_06000F58(v10);
                int v12 = 0;
                __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v13 = __cil_callvirt_0A00020B(v11, __cil_bool_store(v12));
                l6 = v13;
                ref __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v14 = ref l6;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v15 = __cil_value_call_0A00020C(ref v14);
                l5 = v15;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v16 = ref l5;
                int v17 = __cil_bool_load(__cil_value_call_0A00020D(ref v16));
                if (v17 != 0) {
                    goto IL_0086;
                } else {
                    goto IL_0045;
                }
                IL_0045: ;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v18 = ref this;
                int v19 = 0;
                l0 = v19;
                v18.__il_field_04000576 = v19;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v20 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v21 = l5;
                v20.__il_field_0400057B = v21;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v22 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v23 = ref v22.__il_field_04000577;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v24 = ref l5;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v25 = ref this;
                __cil_methodspec_call_2B0000A2(ref v23, ref v24, ref v25);
                goto IL_0148;
                IL_0069: ;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v26 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v27 = v26.__il_field_0400057B;
                l5 = v27;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v28 = ref this;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v29 = ref v28.__il_field_0400057B;
                v29 = default;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v30 = ref this;
                int v31 = -1;
                l0 = v31;
                v30.__il_field_04000576 = v31;
                goto IL_0086;
                IL_0086: ;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v32 = ref l5;
                string v33 = __cil_value_call_0A00020E(ref v32);
                l4 = v33;
                string v34 = l4;
                l3 = v34;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v35 = ref this;
                __cil_type_01000004 v36 = v35.returnType;
                __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v37 = __cil_ldtoken_type_01000003;
                __cil_type_01000004 v38 = System.Type.GetTypeFromHandle(v37);
                int v39 = __cil_bool_load(System.Type.op_Equality(v36, v38));
                if (v39 == 0) {
                    goto IL_00B0;
                } else {
                    goto IL_00A9;
                }
                IL_00A9: ;
                string v40 = l3;
                l2 = v40;
                goto IL_0134;
                IL_00B0: ;
                try {
                    IL_00B1: ;
                    global::System.Xml.Schema.XmlValueConverter v41 = System.Xml.Schema.XmlUntypedConverter.Untyped;
                    string v42 = l3;
                    ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v43 = ref this;
                    __cil_type_01000004 v44 = v43.returnType;
                    ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v45 = ref this;
                    global::System.Xml.IXmlNamespaceResolver v46 = v45.namespaceResolver;
                    if (v46 is null) {
                        System.Xml.Schema.XmlValueConverter e10_12_0 = v41;
                        string e10_12_1 = v42;
                        __cil_type_01000004 e10_12_2 = v44;
                        s12_0 = e10_12_0;
                        s12_1 = e10_12_1;
                        s12_2 = e10_12_2;
                        goto IL_00CD;
                    } else {
                        System.Xml.Schema.XmlValueConverter e10_11_0 = v41;
                        string e10_11_1 = v42;
                        __cil_type_01000004 e10_11_2 = v44;
                        s11_0 = e10_11_0;
                        s11_1 = e10_11_1;
                        s11_2 = e10_11_2;
                        goto IL_00C5;
                    }
                    IL_00C5: ;
                    ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v47 = ref this;
                    global::System.Xml.IXmlNamespaceResolver v48 = v47.namespaceResolver;
                    System.Xml.Schema.XmlValueConverter e11_13_0 = s11_0;
                    string e11_13_1 = s11_1;
                    __cil_type_01000004 e11_13_2 = s11_2;
                    System.Xml.IXmlNamespaceResolver e11_13_3 = v48;
                    s13_0 = e11_13_0;
                    s13_1 = e11_13_1;
                    s13_2 = e11_13_2;
                    s13_3 = e11_13_3;
                    goto IL_00D3;
                    IL_00CD: ;
                    global::System.Xml.XmlReader v49 = l1;
                    global::System.Xml.IXmlNamespaceResolver v50 = ((object)v49 as System.Xml.IXmlNamespaceResolver);
                    System.Xml.Schema.XmlValueConverter e12_13_0 = s12_0;
                    string e12_13_1 = s12_1;
                    __cil_type_01000004 e12_13_2 = s12_2;
                    System.Xml.IXmlNamespaceResolver e12_13_3 = v50;
                    s13_0 = e12_13_0;
                    s13_1 = e12_13_1;
                    s13_2 = e12_13_2;
                    s13_3 = e12_13_3;
                    goto IL_00D3;
                    IL_00D3: ;
                    object v51 = __cil_callvirt_0600300D(s13_0, s13_1, s13_2, s13_3);
                    l2 = v51;
                    goto IL_0134;
                }
                catch (System.FormatException __cil_exception_0) {
                    IL_00DB: ;
                    s14_0 = __cil_exception_0;
                    l7 = s14_0;
                    string v52 = System.SR.get_Xml_ReadContentAsFormatException();
                    ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v53 = ref this;
                    __cil_type_01000004 v54 = v53.returnType;
                    string v55 = v54.ToString();
                    global::System.FormatException v56 = l7;
                    global::System.Xml.XmlReader v57 = l1;
                    global::System.Xml.IXmlLineInfo v58 = ((object)v57 as System.Xml.IXmlLineInfo);
                    global::System.Xml.XmlException v59 = __cil_newobj_06000A0E(v52, v55, v56, v58);
                    throw v59;
                }
                catch (System.InvalidCastException __cil_exception_1) {
                    IL_00FB: ;
                    s15_0 = __cil_exception_1;
                    l8 = s15_0;
                    string v60 = System.SR.get_Xml_ReadContentAsFormatException();
                    ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v61 = ref this;
                    __cil_type_01000004 v62 = v61.returnType;
                    string v63 = v62.ToString();
                    global::System.InvalidCastException v64 = l8;
                    global::System.Xml.XmlReader v65 = l1;
                    global::System.Xml.IXmlLineInfo v66 = ((object)v65 as System.Xml.IXmlLineInfo);
                    global::System.Xml.XmlException v67 = __cil_newobj_06000A0E(v60, v63, v64, v66);
                    throw v67;
                }
            }
            catch (System.Exception __cil_exception_2) {
                IL_011B: ;
                s16_0 = __cil_exception_2;
                l9 = s16_0;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v68 = ref this;
                int v69 = -2;
                v68.__il_field_04000576 = v69;
                ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v70 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v71 = ref v70.__il_field_04000577;
                global::System.Exception v72 = l9;
                __cil_value_call_0A0001E8(ref v71, v72);
                goto IL_0148;
            }
            IL_0134: ;
            ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v73 = ref this;
            int v74 = -2;
            v73.__il_field_04000576 = v74;
            ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v75 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v76 = ref v75.__il_field_04000577;
            object v77 = l2;
            __cil_value_call_0A0001E9(ref v76, v77);
            goto IL_0148;
            IL_0148: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 bytes=1184B4: valuetype System.Xml.XmlReader/<ReadContentAsAsync>d__185; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_738d848a5cfa62706f09cf4dbb0403fce9aa1f82 v0 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v1 = ref v0.__il_field_04000577;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A0001EA(ref v1, v2);
            return;
        }
    }

    private struct __name_3C52656164456C656D656E74436F6E74656E7441734F626A6563744173796E633E645F5F313836 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_0400057C;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object> __il_field_0400057D;
        public System.Xml.XmlReader __il_field_0400057E;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_0400057F;
        private object __il_field_04000580;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<object> __il_field_04000581;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter __il_field_04000582;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 bytes=1512816D011C: class [System.Runtime]System.Threading.Tasks.Task`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 bytes=1184B8: valuetype System.Xml.XmlReader/<ReadElementContentAsObjectAsync>d__186; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_63056dd3fad1113e527e09dd995815e542b91550 bytes=118191: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_94401df299859030bcc4d926f86808311a890eab bytes=118195: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 bytes=151181A1011C: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 bytes=1511819D011C: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            object l2 = default;
            bool l3 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l4 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l5 = default;
            object l6 = default;
            __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 l7 = default;
            __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 l8 = default;
            __cil_value_94401df299859030bcc4d926f86808311a890eab l9 = default;
            __cil_value_63056dd3fad1113e527e09dd995815e542b91550 l10 = default;
            System.Exception l11 = default;
            System.Exception s14_0 = default;
            IL_0000: ;
            ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v0 = ref this;
            int v1 = v0.__il_field_0400057C;
            l0 = v1;
            ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_0400057E;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                switch (v4) {
                    case 0: {
                        goto IL_0069;
                    }
                    case 1: {
                        goto IL_00D8;
                    }
                    case 2: {
                        goto IL_0147;
                    }
                    default: {
                        goto IL_0020;
                    } }
                IL_0020: ;
                global::System.Xml.XmlReader v5 = l1;
                string v6 = __cil_ldstr_7000DD81("ReadElementContentAsObject");
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v7 = __cil_direct_06000F59(v5, v6);
                int v8 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v9 = __cil_callvirt_0A00012B(v7, __cil_bool_store(v8));
                l5 = v9;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v10 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v11 = __cil_value_call_0A00012C(ref v10);
                l4 = v11;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v12 = ref l4;
                int v13 = __cil_bool_load(__cil_value_call_0A00012D(ref v12));
                if (v13 != 0) {
                    goto IL_0086;
                } else {
                    goto IL_0045;
                }
                IL_0045: ;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v14 = ref this;
                int v15 = 0;
                l0 = v15;
                v14.__il_field_0400057C = v15;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v16 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v17 = l4;
                v16.__il_field_0400057F = v17;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v18 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v19 = ref v18.__il_field_0400057D;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v20 = ref l4;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v21 = ref this;
                __cil_methodspec_call_2B0000A3(ref v19, ref v20, ref v21);
                goto IL_01A9;
                IL_0069: ;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v22 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v23 = v22.__il_field_0400057F;
                l4 = v23;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v24 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v25 = ref v24.__il_field_0400057F;
                v25 = default;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v26 = ref this;
                int v27 = -1;
                l0 = v27;
                v26.__il_field_0400057C = v27;
                goto IL_0086;
                IL_0086: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v28 = ref l4;
                int v29 = __cil_bool_load(__cil_value_call_0A00012F(ref v28));
                l3 = __cil_bool_store(v29);
                int v30 = __cil_bool_load(l3);
                if (v30 == 0) {
                    goto IL_0174;
                } else {
                    goto IL_0094;
                }
                IL_0094: ;
                global::System.Xml.XmlReader v31 = l1;
                __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 v32 = __cil_callvirt_06000F46(v31);
                int v33 = 0;
                __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 v34 = __cil_callvirt_0A000235(v32, __cil_bool_store(v33));
                l8 = v34;
                ref __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 v35 = ref l8;
                __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v36 = __cil_value_call_0A000236(ref v35);
                l7 = v36;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v37 = ref l7;
                int v38 = __cil_bool_load(__cil_value_call_0A000237(ref v37));
                if (v38 != 0) {
                    goto IL_00F5;
                } else {
                    goto IL_00B4;
                }
                IL_00B4: ;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v39 = ref this;
                int v40 = 1;
                l0 = v40;
                v39.__il_field_0400057C = v40;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v41 = ref this;
                __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v42 = l7;
                v41.__il_field_04000581 = v42;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v43 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v44 = ref v43.__il_field_0400057D;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v45 = ref l7;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v46 = ref this;
                __cil_methodspec_call_2B0000A4(ref v44, ref v45, ref v46);
                goto IL_01A9;
                IL_00D8: ;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v47 = ref this;
                __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v48 = v47.__il_field_04000581;
                l7 = v48;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v49 = ref this;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v50 = ref v49.__il_field_04000581;
                v50 = default;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v51 = ref this;
                int v52 = -1;
                l0 = v52;
                v51.__il_field_0400057C = v52;
                goto IL_00F5;
                IL_00F5: ;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v53 = ref l7;
                object v54 = __cil_value_call_0A000238(ref v53);
                l6 = v54;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v55 = ref this;
                object v56 = l6;
                v55.__il_field_04000580 = v56;
                global::System.Xml.XmlReader v57 = l1;
                __cil_type_0100005C v58 = __cil_direct_06000F5A(v57);
                int v59 = 0;
                __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v60 = v58.ConfigureAwait(__cil_bool_store(v59));
                l10 = v60;
                ref __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v61 = ref l10;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v62 = __cil_memberref_call_0A00010A(ref v61);
                l9 = v62;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v63 = ref l9;
                int v64 = __cil_bool_load(__cil_memberref_call_0A00010B(ref v63));
                if (v64 != 0) {
                    goto IL_0164;
                } else {
                    goto IL_0126;
                }
                IL_0126: ;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v65 = ref this;
                int v66 = 2;
                l0 = v66;
                v65.__il_field_0400057C = v66;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v67 = ref this;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v68 = l9;
                v67.__il_field_04000582 = v68;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v69 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v70 = ref v69.__il_field_0400057D;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v71 = ref l9;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v72 = ref this;
                __cil_methodspec_call_2B0000A5(ref v70, ref v71, ref v72);
                goto IL_01A9;
                IL_0147: ;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v73 = ref this;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v74 = v73.__il_field_04000582;
                l9 = v74;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v75 = ref this;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v76 = ref v75.__il_field_04000582;
                v76 = default;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v77 = ref this;
                int v78 = -1;
                l0 = v78;
                v77.__il_field_0400057C = v78;
                goto IL_0164;
                IL_0164: ;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v79 = ref l9;
                __cil_memberref_call_0A00010F(ref v79);
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v80 = ref this;
                object v81 = v80.__il_field_04000580;
                l2 = v81;
                goto IL_0195;
                IL_0174: ;
                string v82 = __cil_ldsfld_0A000002();
                l2 = v82;
                goto IL_0195;
            }
            catch (System.Exception __cil_exception_0) {
                IL_017C: ;
                s14_0 = __cil_exception_0;
                l11 = s14_0;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v83 = ref this;
                int v84 = -2;
                v83.__il_field_0400057C = v84;
                ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v85 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v86 = ref v85.__il_field_0400057D;
                global::System.Exception v87 = l11;
                __cil_value_call_0A0001E8(ref v86, v87);
                goto IL_01A9;
            }
            IL_0195: ;
            ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v88 = ref this;
            int v89 = -2;
            v88.__il_field_0400057C = v89;
            ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v90 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v91 = ref v90.__il_field_0400057D;
            object v92 = l2;
            __cil_value_call_0A0001E9(ref v91, v92);
            goto IL_01A9;
            IL_01A9: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 bytes=1184B8: valuetype System.Xml.XmlReader/<ReadElementContentAsObjectAsync>d__186; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_1b1ada80adc29e358e80d35b8d4f66f38d353190 v0 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v1 = ref v0.__il_field_0400057D;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A0001EA(ref v1, v2);
            return;
        }
    }

    private struct __name_3C52656164456C656D656E74436F6E74656E744173537472696E674173796E633E645F5F313837 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_04000583;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<string> __il_field_04000584;
        public System.Xml.XmlReader __il_field_04000585;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_04000586;
        private string __il_field_04000587;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<string> __il_field_04000588;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter __il_field_04000589;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 bytes=1184BC: valuetype System.Xml.XmlReader/<ReadElementContentAsStringAsync>d__187; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa bytes=151181A1010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa bytes=1511819D010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_63056dd3fad1113e527e09dd995815e542b91550 bytes=118191: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_94401df299859030bcc4d926f86808311a890eab bytes=118195: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            string l2 = default;
            bool l3 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l4 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l5 = default;
            string l6 = default;
            __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa l7 = default;
            __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa l8 = default;
            __cil_value_94401df299859030bcc4d926f86808311a890eab l9 = default;
            __cil_value_63056dd3fad1113e527e09dd995815e542b91550 l10 = default;
            System.Exception l11 = default;
            System.Exception s14_0 = default;
            IL_0000: ;
            ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v0 = ref this;
            int v1 = v0.__il_field_04000583;
            l0 = v1;
            ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_04000585;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                switch (v4) {
                    case 0: {
                        goto IL_0069;
                    }
                    case 1: {
                        goto IL_00D8;
                    }
                    case 2: {
                        goto IL_0147;
                    }
                    default: {
                        goto IL_0020;
                    } }
                IL_0020: ;
                global::System.Xml.XmlReader v5 = l1;
                string v6 = __cil_ldstr_7000DF2D("ReadElementContentAsString");
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v7 = __cil_direct_06000F59(v5, v6);
                int v8 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v9 = __cil_callvirt_0A00012B(v7, __cil_bool_store(v8));
                l5 = v9;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v10 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v11 = __cil_value_call_0A00012C(ref v10);
                l4 = v11;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v12 = ref l4;
                int v13 = __cil_bool_load(__cil_value_call_0A00012D(ref v12));
                if (v13 != 0) {
                    goto IL_0086;
                } else {
                    goto IL_0045;
                }
                IL_0045: ;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v14 = ref this;
                int v15 = 0;
                l0 = v15;
                v14.__il_field_04000583 = v15;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v16 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v17 = l4;
                v16.__il_field_04000586 = v17;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v18 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v19 = ref v18.__il_field_04000584;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v20 = ref l4;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v21 = ref this;
                __cil_methodspec_call_2B0000A6(ref v19, ref v20, ref v21);
                goto IL_01A9;
                IL_0069: ;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v22 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v23 = v22.__il_field_04000586;
                l4 = v23;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v24 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v25 = ref v24.__il_field_04000586;
                v25 = default;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v26 = ref this;
                int v27 = -1;
                l0 = v27;
                v26.__il_field_04000583 = v27;
                goto IL_0086;
                IL_0086: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v28 = ref l4;
                int v29 = __cil_bool_load(__cil_value_call_0A00012F(ref v28));
                l3 = __cil_bool_store(v29);
                int v30 = __cil_bool_load(l3);
                if (v30 == 0) {
                    goto IL_0174;
                } else {
                    goto IL_0094;
                }
                IL_0094: ;
                global::System.Xml.XmlReader v31 = l1;
                __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v32 = __cil_callvirt_06000F47(v31);
                int v33 = 0;
                __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v34 = __cil_callvirt_0A00020B(v32, __cil_bool_store(v33));
                l8 = v34;
                ref __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v35 = ref l8;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v36 = __cil_value_call_0A00020C(ref v35);
                l7 = v36;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v37 = ref l7;
                int v38 = __cil_bool_load(__cil_value_call_0A00020D(ref v37));
                if (v38 != 0) {
                    goto IL_00F5;
                } else {
                    goto IL_00B4;
                }
                IL_00B4: ;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v39 = ref this;
                int v40 = 1;
                l0 = v40;
                v39.__il_field_04000583 = v40;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v41 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v42 = l7;
                v41.__il_field_04000588 = v42;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v43 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v44 = ref v43.__il_field_04000584;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v45 = ref l7;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v46 = ref this;
                __cil_methodspec_call_2B0000A7(ref v44, ref v45, ref v46);
                goto IL_01A9;
                IL_00D8: ;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v47 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v48 = v47.__il_field_04000588;
                l7 = v48;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v49 = ref this;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v50 = ref v49.__il_field_04000588;
                v50 = default;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v51 = ref this;
                int v52 = -1;
                l0 = v52;
                v51.__il_field_04000583 = v52;
                goto IL_00F5;
                IL_00F5: ;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v53 = ref l7;
                string v54 = __cil_value_call_0A00020E(ref v53);
                l6 = v54;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v55 = ref this;
                string v56 = l6;
                v55.__il_field_04000587 = v56;
                global::System.Xml.XmlReader v57 = l1;
                __cil_type_0100005C v58 = __cil_direct_06000F5A(v57);
                int v59 = 0;
                __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v60 = v58.ConfigureAwait(__cil_bool_store(v59));
                l10 = v60;
                ref __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v61 = ref l10;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v62 = __cil_memberref_call_0A00010A(ref v61);
                l9 = v62;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v63 = ref l9;
                int v64 = __cil_bool_load(__cil_memberref_call_0A00010B(ref v63));
                if (v64 != 0) {
                    goto IL_0164;
                } else {
                    goto IL_0126;
                }
                IL_0126: ;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v65 = ref this;
                int v66 = 2;
                l0 = v66;
                v65.__il_field_04000583 = v66;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v67 = ref this;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v68 = l9;
                v67.__il_field_04000589 = v68;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v69 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v70 = ref v69.__il_field_04000584;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v71 = ref l9;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v72 = ref this;
                __cil_methodspec_call_2B0000A8(ref v70, ref v71, ref v72);
                goto IL_01A9;
                IL_0147: ;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v73 = ref this;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v74 = v73.__il_field_04000589;
                l9 = v74;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v75 = ref this;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v76 = ref v75.__il_field_04000589;
                v76 = default;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v77 = ref this;
                int v78 = -1;
                l0 = v78;
                v77.__il_field_04000583 = v78;
                goto IL_0164;
                IL_0164: ;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v79 = ref l9;
                __cil_memberref_call_0A00010F(ref v79);
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v80 = ref this;
                string v81 = v80.__il_field_04000587;
                l2 = v81;
                goto IL_0195;
                IL_0174: ;
                string v82 = __cil_ldsfld_0A000002();
                l2 = v82;
                goto IL_0195;
            }
            catch (System.Exception __cil_exception_0) {
                IL_017C: ;
                s14_0 = __cil_exception_0;
                l11 = s14_0;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v83 = ref this;
                int v84 = -2;
                v83.__il_field_04000583 = v84;
                ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v85 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v86 = ref v85.__il_field_04000584;
                global::System.Exception v87 = l11;
                __cil_value_call_0A00023A(ref v86, v87);
                goto IL_01A9;
            }
            IL_0195: ;
            ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v88 = ref this;
            int v89 = -2;
            v88.__il_field_04000583 = v89;
            ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v90 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v91 = ref v90.__il_field_04000584;
            string v92 = l2;
            __cil_value_call_0A00023B(ref v91, v92);
            goto IL_01A9;
            IL_01A9: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 bytes=1184BC: valuetype System.Xml.XmlReader/<ReadElementContentAsStringAsync>d__187; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_5a065c54266bf4d85e9e7e5f4f7499000570b4f2 v0 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v1 = ref v0.__il_field_04000584;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A00023C(ref v1, v2);
            return;
        }
    }

    private struct __name_3C52656164456C656D656E74436F6E74656E7441734173796E633E645F5F313838 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_0400058A;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object> __il_field_0400058B;
        public System.Xml.XmlReader __il_field_0400058C;
        public System.Type returnType;
        public System.Xml.IXmlNamespaceResolver namespaceResolver;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_0400058F;
        private object __il_field_04000590;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<object> __il_field_04000591;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter __il_field_04000592;

        private virtual void MoveNext()
        {
            // structural signature __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 bytes=1115: valuetype [System.Runtime]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 bytes=1512816D011C: class [System.Runtime]System.Threading.Tasks.Task`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 bytes=1184C0: valuetype System.Xml.XmlReader/<ReadElementContentAsAsync>d__188; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_63056dd3fad1113e527e09dd995815e542b91550 bytes=118191: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_94401df299859030bcc4d926f86808311a890eab bytes=118195: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 bytes=151181A1011C: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 bytes=1511819D011C: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            object l2 = default;
            bool l3 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l4 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l5 = default;
            object l6 = default;
            __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 l7 = default;
            __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 l8 = default;
            __cil_value_94401df299859030bcc4d926f86808311a890eab l9 = default;
            __cil_value_63056dd3fad1113e527e09dd995815e542b91550 l10 = default;
            System.Exception l11 = default;
            object s16_0 = default;
            System.Exception s17_0 = default;
            IL_0000: ;
            ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v0 = ref this;
            int v1 = v0.__il_field_0400058A;
            l0 = v1;
            ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_0400058C;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                switch (v4) {
                    case 0: {
                        goto IL_0069;
                    }
                    case 1: {
                        goto IL_00E4;
                    }
                    case 2: {
                        goto IL_0156;
                    }
                    default: {
                        goto IL_0020;
                    } }
                IL_0020: ;
                global::System.Xml.XmlReader v5 = l1;
                string v6 = __cil_ldstr_7000DF63("ReadElementContentAs");
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v7 = __cil_direct_06000F59(v5, v6);
                int v8 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v9 = __cil_callvirt_0A00012B(v7, __cil_bool_store(v8));
                l5 = v9;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v10 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v11 = __cil_value_call_0A00012C(ref v10);
                l4 = v11;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v12 = ref l4;
                int v13 = __cil_bool_load(__cil_value_call_0A00012D(ref v12));
                if (v13 != 0) {
                    goto IL_0086;
                } else {
                    goto IL_0045;
                }
                IL_0045: ;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v14 = ref this;
                int v15 = 0;
                l0 = v15;
                v14.__il_field_0400058A = v15;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v16 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v17 = l4;
                v16.__il_field_0400058F = v17;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v18 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v19 = ref v18.__il_field_0400058B;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v20 = ref l4;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v21 = ref this;
                __cil_methodspec_call_2B0000A9(ref v19, ref v20, ref v21);
                goto IL_01EC;
                IL_0069: ;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v22 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v23 = v22.__il_field_0400058F;
                l4 = v23;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v24 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v25 = ref v24.__il_field_0400058F;
                v25 = default;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v26 = ref this;
                int v27 = -1;
                l0 = v27;
                v26.__il_field_0400058A = v27;
                goto IL_0086;
                IL_0086: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v28 = ref l4;
                int v29 = __cil_bool_load(__cil_value_call_0A00012F(ref v28));
                l3 = __cil_bool_store(v29);
                int v30 = __cil_bool_load(l3);
                if (v30 == 0) {
                    goto IL_0183;
                } else {
                    goto IL_0094;
                }
                IL_0094: ;
                global::System.Xml.XmlReader v31 = l1;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v32 = ref this;
                __cil_type_01000004 v33 = v32.returnType;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v34 = ref this;
                global::System.Xml.IXmlNamespaceResolver v35 = v34.namespaceResolver;
                __cil_ref_33f53b364e6f6f1fbf446998255de4e55b264359 v36 = __cil_callvirt_06000F48(v31, v33, v35);
                int v37 = 0;
                __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 v38 = __cil_callvirt_0A000235(v36, __cil_bool_store(v37));
                l8 = v38;
                ref __cil_value_316eaeae51222e6b969f3893b320fb787cabad12 v39 = ref l8;
                __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v40 = __cil_value_call_0A000236(ref v39);
                l7 = v40;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v41 = ref l7;
                int v42 = __cil_bool_load(__cil_value_call_0A000237(ref v41));
                if (v42 != 0) {
                    goto IL_0101;
                } else {
                    goto IL_00C0;
                }
                IL_00C0: ;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v43 = ref this;
                int v44 = 1;
                l0 = v44;
                v43.__il_field_0400058A = v44;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v45 = ref this;
                __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v46 = l7;
                v45.__il_field_04000591 = v46;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v47 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v48 = ref v47.__il_field_0400058B;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v49 = ref l7;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v50 = ref this;
                __cil_methodspec_call_2B0000AA(ref v48, ref v49, ref v50);
                goto IL_01EC;
                IL_00E4: ;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v51 = ref this;
                __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v52 = v51.__il_field_04000591;
                l7 = v52;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v53 = ref this;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v54 = ref v53.__il_field_04000591;
                v54 = default;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v55 = ref this;
                int v56 = -1;
                l0 = v56;
                v55.__il_field_0400058A = v56;
                goto IL_0101;
                IL_0101: ;
                ref __cil_value_9c013a7a833762201c335af74a712dda7c4289e6 v57 = ref l7;
                object v58 = __cil_value_call_0A000238(ref v57);
                l6 = v58;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v59 = ref this;
                object v60 = l6;
                v59.__il_field_04000590 = v60;
                global::System.Xml.XmlReader v61 = l1;
                __cil_type_0100005C v62 = __cil_direct_06000F5A(v61);
                int v63 = 0;
                __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v64 = v62.ConfigureAwait(__cil_bool_store(v63));
                l10 = v64;
                ref __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v65 = ref l10;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v66 = __cil_memberref_call_0A00010A(ref v65);
                l9 = v66;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v67 = ref l9;
                int v68 = __cil_bool_load(__cil_memberref_call_0A00010B(ref v67));
                if (v68 != 0) {
                    goto IL_0173;
                } else {
                    goto IL_0132;
                }
                IL_0132: ;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v69 = ref this;
                int v70 = 2;
                l0 = v70;
                v69.__il_field_0400058A = v70;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v71 = ref this;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v72 = l9;
                v71.__il_field_04000592 = v72;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v73 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v74 = ref v73.__il_field_0400058B;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v75 = ref l9;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v76 = ref this;
                __cil_methodspec_call_2B0000AB(ref v74, ref v75, ref v76);
                goto IL_01EC;
                IL_0156: ;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v77 = ref this;
                __cil_value_94401df299859030bcc4d926f86808311a890eab v78 = v77.__il_field_04000592;
                l9 = v78;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v79 = ref this;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v80 = ref v79.__il_field_04000592;
                v80 = default;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v81 = ref this;
                int v82 = -1;
                l0 = v82;
                v81.__il_field_0400058A = v82;
                goto IL_0173;
                IL_0173: ;
                ref __cil_value_94401df299859030bcc4d926f86808311a890eab v83 = ref l9;
                __cil_memberref_call_0A00010F(ref v83);
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v84 = ref this;
                object v85 = v84.__il_field_04000590;
                l2 = v85;
                goto IL_01D8;
                IL_0183: ;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v86 = ref this;
                __cil_type_01000004 v87 = v86.returnType;
                __cil_value_f57c627caf66ad4248bb26cb548649dcf284cae3 v88 = __cil_ldtoken_type_01000003;
                __cil_type_01000004 v89 = System.Type.GetTypeFromHandle(v88);
                int v90 = __cil_bool_load(System.Type.op_Equality(v87, v89));
                if (v90 != 0) {
                    goto IL_01B7;
                } else {
                    goto IL_019A;
                }
                IL_019A: ;
                global::System.Xml.Schema.XmlValueConverter v91 = System.Xml.Schema.XmlUntypedConverter.Untyped;
                string v92 = __cil_ldsfld_0A000002();
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v93 = ref this;
                __cil_type_01000004 v94 = v93.returnType;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v95 = ref this;
                global::System.Xml.IXmlNamespaceResolver v96 = v95.namespaceResolver;
                object v97 = __cil_callvirt_0600300D(v91, v92, v94, v96);
                object e14_16_0 = v97;
                s16_0 = e14_16_0;
                goto IL_01BC;
                IL_01B7: ;
                string v98 = __cil_ldsfld_0A000002();
                object e15_16_0 = v98;
                s16_0 = e15_16_0;
                goto IL_01BC;
                IL_01BC: ;
                l2 = s16_0;
                goto IL_01D8;
            }
            catch (System.Exception __cil_exception_0) {
                IL_01BF: ;
                s17_0 = __cil_exception_0;
                l11 = s17_0;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v99 = ref this;
                int v100 = -2;
                v99.__il_field_0400058A = v100;
                ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v101 = ref this;
                ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v102 = ref v101.__il_field_0400058B;
                global::System.Exception v103 = l11;
                __cil_value_call_0A0001E8(ref v102, v103);
                goto IL_01EC;
            }
            IL_01D8: ;
            ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v104 = ref this;
            int v105 = -2;
            v104.__il_field_0400058A = v105;
            ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v106 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v107 = ref v106.__il_field_0400058B;
            object v108 = l2;
            __cil_value_call_0A0001E9(ref v107, v108);
            goto IL_01EC;
            IL_01EC: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 bytes=15118185011C: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 bytes=1184C0: valuetype System.Xml.XmlReader/<ReadElementContentAsAsync>d__188; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_dfad7003f0870f526ff50914374a1fc18a6f8021 v0 = ref this;
            ref __cil_value_7421dd436cfabec5439224e9533cbac3d301b0b9 v1 = ref v0.__il_field_0400058B;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A0001EA(ref v1, v2);
            return;
        }
    }

    private struct __name_3C4D6F7665546F436F6E74656E744173796E633E645F5F313936 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_04000593;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<System.Xml.XmlNodeType> __il_field_04000594;
        public System.Xml.XmlReader __il_field_04000595;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_04000596;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b bytes=1184C4: valuetype System.Xml.XmlReader/<MoveToContentAsync>d__196; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 bytes=15118185011182D4: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<valuetype System.Xml.XmlNodeType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            __cil_enum_020000B5 l2 = default;
            __cil_enum_020000B5 l3 = default;
            bool l4 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l5 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l6 = default;
            System.Exception l7 = default;
            System.Exception s12_0 = default;
            IL_0000: ;
            ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v0 = ref this;
            int v1 = v0.__il_field_04000593;
            l0 = v1;
            ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_04000595;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                if (v4 == 0) {
                    goto IL_0094;
                } else {
                    goto IL_0014;
                }
                IL_0014: ;
                global::System.Xml.XmlReader v5 = l1;
                int v6 = unchecked((int)(__cil_callvirt_06000EB8(v5)));
                l3 = unchecked((__cil_enum_020000B5)(v6));
                int v7 = unchecked((int)(l3));
                int v8 = 1;
                int v9 = unchecked(v7 - v8);
                switch (v9) {
                    case 0: {
                        goto IL_0047;
                    }
                    case 1: {
                        goto IL_0040;
                    }
                    case 2: {
                        goto IL_0047;
                    }
                    case 3: {
                        goto IL_0047;
                    }
                    case 4: {
                        goto IL_0047;
                    }
                    default: {
                        goto IL_0037;
                    } }
                IL_0037: ;
                int v10 = unchecked((int)(l3));
                int v11 = 15;
                int v12 = unchecked(v10 - v11);
                int v13 = 1;
                if (unchecked((uint)v12) <= unchecked((uint)v13)) {
                    goto IL_0047;
                } else {
                    goto IL_003E;
                }
                IL_003E: ;
                goto IL_0053;
                IL_0040: ;
                global::System.Xml.XmlReader v14 = l1;
                int v15 = __cil_bool_load(__cil_callvirt_06000EF3(v14));
                goto IL_0047;
                IL_0047: ;
                global::System.Xml.XmlReader v16 = l1;
                int v17 = unchecked((int)(__cil_callvirt_06000EB8(v16)));
                l2 = unchecked((__cil_enum_020000B5)(v17));
                goto IL_00E3;
                IL_0053: ;
                global::System.Xml.XmlReader v18 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v19 = __cil_callvirt_06000F4C(v18);
                int v20 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v21 = __cil_callvirt_0A00012B(v19, __cil_bool_store(v20));
                l6 = v21;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v22 = ref l6;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v23 = __cil_value_call_0A00012C(ref v22);
                l5 = v23;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v24 = ref l5;
                int v25 = __cil_bool_load(__cil_value_call_0A00012D(ref v24));
                if (v25 != 0) {
                    goto IL_00B1;
                } else {
                    goto IL_0073;
                }
                IL_0073: ;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v26 = ref this;
                int v27 = 0;
                l0 = v27;
                v26.__il_field_04000593 = v27;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v28 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v29 = l5;
                v28.__il_field_04000596 = v29;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v30 = ref this;
                ref __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v31 = ref v30.__il_field_04000594;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v32 = ref l5;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v33 = ref this;
                __cil_methodspec_call_2B0000AC(ref v31, ref v32, ref v33);
                goto IL_00F7;
                IL_0094: ;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v34 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v35 = v34.__il_field_04000596;
                l5 = v35;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v36 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v37 = ref v36.__il_field_04000596;
                v37 = default;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v38 = ref this;
                int v39 = -1;
                l0 = v39;
                v38.__il_field_04000593 = v39;
                goto IL_00B1;
                IL_00B1: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v40 = ref l5;
                int v41 = __cil_bool_load(__cil_value_call_0A00012F(ref v40));
                l4 = __cil_bool_store(v41);
                int v42 = __cil_bool_load(l4);
                if (v42 != 0) {
                    goto IL_0014;
                } else {
                    goto IL_00C1;
                }
                IL_00C1: ;
                global::System.Xml.XmlReader v43 = l1;
                int v44 = unchecked((int)(__cil_callvirt_06000EB8(v43)));
                l2 = unchecked((__cil_enum_020000B5)(v44));
                goto IL_00E3;
            }
            catch (System.Exception __cil_exception_0) {
                IL_00CA: ;
                s12_0 = __cil_exception_0;
                l7 = s12_0;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v45 = ref this;
                int v46 = -2;
                v45.__il_field_04000593 = v46;
                ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v47 = ref this;
                ref __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v48 = ref v47.__il_field_04000594;
                global::System.Exception v49 = l7;
                __cil_value_call_0A00023E(ref v48, v49);
                goto IL_00F7;
            }
            IL_00E3: ;
            ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v50 = ref this;
            int v51 = -2;
            v50.__il_field_04000593 = v51;
            ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v52 = ref this;
            ref __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v53 = ref v52.__il_field_04000594;
            int v54 = unchecked((int)(l2));
            __cil_value_call_0A00023F(ref v53, unchecked((__cil_enum_020000B5)(v54)));
            goto IL_00F7;
            IL_00F7: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b bytes=1184C4: valuetype System.Xml.XmlReader/<MoveToContentAsync>d__196; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 bytes=15118185011182D4: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<valuetype System.Xml.XmlNodeType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_f73c83e79e3fff9578d4a89f977ca017f631768b v0 = ref this;
            ref __cil_value_9e26705497bae7d1b03a53467156f3b656e01106 v1 = ref v0.__il_field_04000594;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A000240(ref v1, v2);
            return;
        }
    }

    private struct __name_3C52656164496E6E6572586D6C4173796E633E645F5F313937 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_04000597;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<string> __il_field_04000598;
        public System.Xml.XmlReader __il_field_04000599;
        private System.IO.StringWriter __il_field_0400059A;
        private System.Xml.XmlWriter __il_field_0400059B;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_0400059C;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter __il_field_0400059D;

        private virtual void MoveNext()
        {
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 bytes=1184C8: valuetype System.Xml.XmlReader/<ReadInnerXmlAsync>d__197; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_63056dd3fad1113e527e09dd995815e542b91550 bytes=118191: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_94401df299859030bcc4d926f86808311a890eab bytes=118195: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            string l2 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l3 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l4 = default;
            __cil_value_94401df299859030bcc4d926f86808311a890eab l5 = default;
            __cil_value_63056dd3fad1113e527e09dd995815e542b91550 l6 = default;
            System.Exception l7 = default;
            System.Exception s26_0 = default;
            IL_0000: ;
            ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v0 = ref this;
            int v1 = v0.__il_field_04000597;
            l0 = v1;
            ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_04000599;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                if (v4 == 0) {
                    goto IL_0080;
                } else {
                    goto IL_0011;
                }
                IL_0011: ;
                int v5 = l0;
                int v6 = 1;
                if (v5 == v6) {
                    goto IL_00D1;
                } else {
                    goto IL_0018;
                }
                IL_0018: ;
                global::System.Xml.XmlReader v7 = l1;
                int v8 = unchecked((int)(__cil_callvirt_06000EF8(v7)));
                int v9 = 1;
                if (v8 == v9) {
                    goto IL_002C;
                } else {
                    goto IL_0021;
                }
                IL_0021: ;
                string v10 = __cil_ldsfld_0A000002();
                l2 = v10;
                goto IL_01AF;
                IL_002C: ;
                global::System.Xml.XmlReader v11 = l1;
                int v12 = unchecked((int)(__cil_callvirt_06000EB8(v11)));
                int v13 = 2;
                if (v12 == v13) {
                    goto IL_00AF;
                } else {
                    goto IL_0035;
                }
                IL_0035: ;
                global::System.Xml.XmlReader v14 = l1;
                int v15 = unchecked((int)(__cil_callvirt_06000EB8(v14)));
                int v16 = 1;
                if (v15 == v16) {
                    goto IL_00AF;
                } else {
                    goto IL_003E;
                }
                IL_003E: ;
                global::System.Xml.XmlReader v17 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v18 = __cil_callvirt_06000F4C(v17);
                int v19 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v20 = __cil_callvirt_0A00012B(v18, __cil_bool_store(v19));
                l4 = v20;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v21 = ref l4;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v22 = __cil_value_call_0A00012C(ref v21);
                l3 = v22;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v23 = ref l3;
                int v24 = __cil_bool_load(__cil_value_call_0A00012D(ref v23));
                if (v24 != 0) {
                    goto IL_009C;
                } else {
                    goto IL_005D;
                }
                IL_005D: ;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v25 = ref this;
                int v26 = 0;
                l0 = v26;
                v25.__il_field_04000597 = v26;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v27 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v28 = l3;
                v27.__il_field_0400059C = v28;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v29 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v30 = ref v29.__il_field_04000598;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v31 = ref l3;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v32 = ref this;
                __cil_methodspec_call_2B0000AD(ref v30, ref v31, ref v32);
                goto IL_01C3;
                IL_0080: ;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v33 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v34 = v33.__il_field_0400059C;
                l3 = v34;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v35 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v36 = ref v35.__il_field_0400059C;
                v36 = default;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v37 = ref this;
                int v38 = -1;
                l0 = v38;
                v37.__il_field_04000597 = v38;
                goto IL_009C;
                IL_009C: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v39 = ref l3;
                int v40 = __cil_bool_load(__cil_value_call_0A00012F(ref v39));
                string v41 = __cil_ldsfld_0A000002();
                l2 = v41;
                goto IL_01AF;
                IL_00AF: ;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v42 = ref this;
                __cil_type_0100000C v43 = System.Globalization.CultureInfo.get_InvariantCulture();
                __cil_type_010000A1 v44 = __cil_newobj_0A00022B(v43);
                v42.__il_field_0400059A = v44;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v45 = ref this;
                global::System.Xml.XmlReader v46 = l1;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v47 = ref this;
                __cil_type_010000A1 v48 = v47.__il_field_0400059A;
                global::System.Xml.XmlWriter v49 = __cil_direct_06000F1D(v46, v48);
                v45.__il_field_0400059B = v49;
                goto IL_00D1;
                IL_00D1: ;
                try {
                    IL_00D2: ;
                    int v50 = l0;
                    int v51 = 1;
                    if (v50 == v51) {
                        goto IL_0152;
                    } else {
                        goto IL_00D6;
                    }
                    IL_00D6: ;
                    global::System.Xml.XmlReader v52 = l1;
                    int v53 = unchecked((int)(__cil_callvirt_06000EB8(v52)));
                    int v54 = 2;
                    if (unchecked((uint)v53) != unchecked((uint)v54)) {
                        goto IL_0101;
                    } else {
                        goto IL_00DF;
                    }
                    IL_00DF: ;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v55 = ref this;
                    global::System.Xml.XmlWriter v56 = v55.__il_field_0400059B;
                    global::System.Xml.XmlTextWriter v57 = ((System.Xml.XmlTextWriter)(object)v56);
                    global::System.Xml.XmlReader v58 = l1;
                    int v59 = unchecked((int)(__cil_callvirt_06000EC3(v58)));
                    __cil_callvirt_06001338(v57, unchecked((char)(v59)));
                    global::System.Xml.XmlReader v60 = l1;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v61 = ref this;
                    global::System.Xml.XmlWriter v62 = v61.__il_field_0400059B;
                    __cil_direct_06000F1B(v60, v62);
                    goto IL_0101;
                    IL_0101: ;
                    global::System.Xml.XmlReader v63 = l1;
                    int v64 = unchecked((int)(__cil_callvirt_06000EB8(v63)));
                    int v65 = 1;
                    if (unchecked((uint)v64) != unchecked((uint)v65)) {
                        goto IL_0176;
                    } else {
                        goto IL_010A;
                    }
                    IL_010A: ;
                    global::System.Xml.XmlReader v66 = l1;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v67 = ref this;
                    global::System.Xml.XmlWriter v68 = v67.__il_field_0400059B;
                    int v69 = 0;
                    __cil_type_0100005C v70 = __cil_direct_06000F55(v66, v68, __cil_bool_store(v69));
                    int v71 = 0;
                    __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v72 = v70.ConfigureAwait(__cil_bool_store(v71));
                    l6 = v72;
                    ref __cil_value_63056dd3fad1113e527e09dd995815e542b91550 v73 = ref l6;
                    __cil_value_94401df299859030bcc4d926f86808311a890eab v74 = __cil_memberref_call_0A00010A(ref v73);
                    l5 = v74;
                    ref __cil_value_94401df299859030bcc4d926f86808311a890eab v75 = ref l5;
                    int v76 = __cil_bool_load(__cil_memberref_call_0A00010B(ref v75));
                    if (v76 != 0) {
                        goto IL_016F;
                    } else {
                        goto IL_0131;
                    }
                    IL_0131: ;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v77 = ref this;
                    int v78 = 1;
                    l0 = v78;
                    v77.__il_field_04000597 = v78;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v79 = ref this;
                    __cil_value_94401df299859030bcc4d926f86808311a890eab v80 = l5;
                    v79.__il_field_0400059D = v80;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v81 = ref this;
                    ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v82 = ref v81.__il_field_04000598;
                    ref __cil_value_94401df299859030bcc4d926f86808311a890eab v83 = ref l5;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v84 = ref this;
                    __cil_methodspec_call_2B0000AE(ref v82, ref v83, ref v84);
                    goto IL_01C3;
                    IL_0152: ;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v85 = ref this;
                    __cil_value_94401df299859030bcc4d926f86808311a890eab v86 = v85.__il_field_0400059D;
                    l5 = v86;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v87 = ref this;
                    ref __cil_value_94401df299859030bcc4d926f86808311a890eab v88 = ref v87.__il_field_0400059D;
                    v88 = default;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v89 = ref this;
                    int v90 = -1;
                    l0 = v90;
                    v89.__il_field_04000597 = v90;
                    goto IL_016F;
                    IL_016F: ;
                    ref __cil_value_94401df299859030bcc4d926f86808311a890eab v91 = ref l5;
                    __cil_memberref_call_0A00010F(ref v91);
                    goto IL_0176;
                    IL_0176: ;
                    goto IL_0188;
                }
                finally {
                    IL_0178: ;
                    int v92 = l0;
                    int v93 = 0;
                    if (v92 >= v93) {
                        goto IL_0187;
                    } else {
                        goto IL_017C;
                    }
                    IL_017C: ;
                    ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v94 = ref this;
                    global::System.Xml.XmlWriter v95 = v94.__il_field_0400059B;
                    __cil_callvirt_06001668(v95);
                    goto IL_0187;
                    IL_0187: ;
                    goto __cil_finally_end_0;
                    __cil_finally_end_0: ;
                }
                IL_0188: ;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v96 = ref this;
                __cil_type_010000A1 v97 = v96.__il_field_0400059A;
                string v98 = v97.ToString();
                l2 = v98;
                goto IL_01AF;
            }
            catch (System.Exception __cil_exception_1) {
                IL_0196: ;
                s26_0 = __cil_exception_1;
                l7 = s26_0;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v99 = ref this;
                int v100 = -2;
                v99.__il_field_04000597 = v100;
                ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v101 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v102 = ref v101.__il_field_04000598;
                global::System.Exception v103 = l7;
                __cil_value_call_0A00023A(ref v102, v103);
                goto IL_01C3;
            }
            IL_01AF: ;
            ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v104 = ref this;
            int v105 = -2;
            v104.__il_field_04000597 = v105;
            ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v106 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v107 = ref v106.__il_field_04000598;
            string v108 = l2;
            __cil_value_call_0A00023B(ref v107, v108);
            goto IL_01C3;
            IL_01C3: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 bytes=1184C8: valuetype System.Xml.XmlReader/<ReadInnerXmlAsync>d__197; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_0ad513799edbe2a0e74344ccdcb0190d305823a1 v0 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v1 = ref v0.__il_field_04000598;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A00023C(ref v1, v2);
            return;
        }
    }

    private struct __name_3C57726974654E6F64654173796E633E645F5F313938 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_0400059E;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder __il_field_0400059F;
        public System.Xml.XmlReader __il_field_040005A0;
        public System.Xml.XmlWriter xtw;
        public bool defattr;
        private int __il_field_040005A3;
        private System.Xml.XmlWriter __il_field_040005A4;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<string> __il_field_040005A5;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_040005A6;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc bytes=11817D: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 bytes=1184CC: valuetype System.Xml.XmlReader/<WriteNodeAsync>d__198; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa bytes=151181A1010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa bytes=1511819D010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            __cil_enum_020000B5 l2 = default;
            string l3 = default;
            __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa l4 = default;
            __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa l5 = default;
            string l6 = default;
            __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa l7 = default;
            bool l8 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l9 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l10 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l11 = default;
            System.Exception l12 = default;
            scoped ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 s3_0 = ref System.Runtime.CompilerServices.Unsafe.NullRef<__cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7>();
            scoped ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 s4_0 = ref System.Runtime.CompilerServices.Unsafe.NullRef<__cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7>();
            scoped ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 s5_0 = ref System.Runtime.CompilerServices.Unsafe.NullRef<__cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7>();
            int s5_1 = default;
            System.Exception s36_0 = default;
            IL_0000: ;
            ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v0 = ref this;
            int v1 = v0.__il_field_0400059E;
            l0 = v1;
            ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_040005A0;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                switch (v4) {
                    case 0: {
                        goto IL_0148;
                    }
                    case 1: {
                        goto IL_01D5;
                    }
                    case 2: {
                        goto IL_02E4;
                    }
                    case 3: {
                        goto IL_0378;
                    }
                    default: {
                        goto IL_0024;
                    } }
                IL_0024: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v5 = ref this;
                global::System.Xml.XmlReader v6 = l1;
                int v7 = unchecked((int)(__cil_callvirt_06000EB8(v6)));
                if (v7 == 0) {
                    ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 e2_4_0 = ref v5;
                    s4_0 = ref e2_4_0;
                    goto IL_0035;
                } else {
                    ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 e2_3_0 = ref v5;
                    s3_0 = ref e2_3_0;
                    goto IL_002D;
                }
                IL_002D: ;
                global::System.Xml.XmlReader v8 = l1;
                int v9 = __cil_callvirt_06000EBF(v8);
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 e3_5_0 = ref s3_0;
                int e3_5_1 = v9;
                s5_0 = ref e3_5_0;
                s5_1 = e3_5_1;
                goto IL_0036;
                IL_0035: ;
                int v10 = -1;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 e4_5_0 = ref s4_0;
                int e4_5_1 = v10;
                s5_0 = ref e4_5_0;
                s5_1 = e4_5_1;
                goto IL_0036;
                IL_0036: ;
                s5_0.__il_field_040005A3 = s5_1;
                goto IL_02A0;
                IL_0040: ;
                global::System.Xml.XmlReader v11 = l1;
                int v12 = unchecked((int)(__cil_callvirt_06000EB8(v11)));
                l2 = unchecked((__cil_enum_020000B5)(v12));
                int v13 = unchecked((int)(l2));
                int v14 = 1;
                int v15 = unchecked(v13 - v14);
                switch (v15) {
                    case 0: {
                        goto IL_0098;
                    }
                    case 1: {
                        goto IL_02A0;
                    }
                    case 2: {
                        goto IL_00F8;
                    }
                    case 3: {
                        goto IL_0214;
                    }
                    case 4: {
                        goto IL_0227;
                    }
                    case 5: {
                        goto IL_02A0;
                    }
                    case 6: {
                        goto IL_023A;
                    }
                    case 7: {
                        goto IL_0282;
                    }
                    case 8: {
                        goto IL_02A0;
                    }
                    case 9: {
                        goto IL_0253;
                    }
                    case 10: {
                        goto IL_02A0;
                    }
                    case 11: {
                        goto IL_02A0;
                    }
                    case 12: {
                        goto IL_0185;
                    }
                    case 13: {
                        goto IL_0185;
                    }
                    case 14: {
                        goto IL_0295;
                    }
                    case 15: {
                        goto IL_02A0;
                    }
                    case 16: {
                        goto IL_023A;
                    }
                    default: {
                        goto IL_0093;
                    } }
                IL_0093: ;
                goto IL_02A0;
                IL_0098: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v16 = ref this;
                global::System.Xml.XmlWriter v17 = v16.xtw;
                global::System.Xml.XmlReader v18 = l1;
                string v19 = __cil_callvirt_06000EBC(v18);
                global::System.Xml.XmlReader v20 = l1;
                string v21 = __cil_callvirt_06000EBA(v20);
                global::System.Xml.XmlReader v22 = l1;
                string v23 = __cil_callvirt_06000EBB(v22);
                __cil_callvirt_0600164F(v17, v19, v21, v23);
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v24 = ref this;
                global::System.Xml.XmlWriter v25 = v24.xtw;
                global::System.Xml.XmlTextWriter v26 = ((System.Xml.XmlTextWriter)(object)v25);
                global::System.Xml.XmlReader v27 = l1;
                int v28 = unchecked((int)(__cil_callvirt_06000EC3(v27)));
                __cil_callvirt_06001338(v26, unchecked((char)(v28)));
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v29 = ref this;
                global::System.Xml.XmlWriter v30 = v29.xtw;
                global::System.Xml.XmlReader v31 = l1;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v32 = ref this;
                int v33 = __cil_bool_load(v32.defattr);
                __cil_callvirt_0600167A(v30, v31, __cil_bool_store(v33));
                global::System.Xml.XmlReader v34 = l1;
                int v35 = __cil_bool_load(__cil_callvirt_06000EC1(v34));
                if (v35 == 0) {
                    goto IL_02A0;
                } else {
                    goto IL_00E8;
                }
                IL_00E8: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v36 = ref this;
                global::System.Xml.XmlWriter v37 = v36.xtw;
                __cil_callvirt_06001651(v37);
                goto IL_02A0;
                IL_00F8: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v38 = ref this;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v39 = ref this;
                global::System.Xml.XmlWriter v40 = v39.xtw;
                v38.__il_field_040005A4 = v40;
                global::System.Xml.XmlReader v41 = l1;
                __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v42 = __cil_callvirt_06000F45(v41);
                int v43 = 0;
                __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v44 = __cil_callvirt_0A00020B(v42, __cil_bool_store(v43));
                l5 = v44;
                ref __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v45 = ref l5;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v46 = __cil_value_call_0A00020C(ref v45);
                l4 = v46;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v47 = ref l4;
                int v48 = __cil_bool_load(__cil_value_call_0A00020D(ref v47));
                if (v48 != 0) {
                    goto IL_0165;
                } else {
                    goto IL_0124;
                }
                IL_0124: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v49 = ref this;
                int v50 = 0;
                l0 = v50;
                v49.__il_field_0400059E = v50;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v51 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v52 = l4;
                v51.__il_field_040005A5 = v52;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v53 = ref this;
                ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v54 = ref v53.__il_field_0400059F;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v55 = ref l4;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v56 = ref this;
                __cil_methodspec_call_2B0000AF(ref v54, ref v55, ref v56);
                goto IL_03CB;
                IL_0148: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v57 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v58 = v57.__il_field_040005A5;
                l4 = v58;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v59 = ref this;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v60 = ref v59.__il_field_040005A5;
                v60 = default;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v61 = ref this;
                int v62 = -1;
                l0 = v62;
                v61.__il_field_0400059E = v62;
                goto IL_0165;
                IL_0165: ;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v63 = ref l4;
                string v64 = __cil_value_call_0A00020E(ref v63);
                l3 = v64;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v65 = ref this;
                global::System.Xml.XmlWriter v66 = v65.__il_field_040005A4;
                string v67 = l3;
                __cil_callvirt_06001660(v66, v67);
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v68 = ref this;
                v68.__il_field_040005A4 = null;
                goto IL_02A0;
                IL_0185: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v69 = ref this;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v70 = ref this;
                global::System.Xml.XmlWriter v71 = v70.xtw;
                v69.__il_field_040005A4 = v71;
                global::System.Xml.XmlReader v72 = l1;
                __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v73 = __cil_callvirt_06000F45(v72);
                int v74 = 0;
                __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v75 = __cil_callvirt_0A00020B(v73, __cil_bool_store(v74));
                l5 = v75;
                ref __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v76 = ref l5;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v77 = __cil_value_call_0A00020C(ref v76);
                l7 = v77;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v78 = ref l7;
                int v79 = __cil_bool_load(__cil_value_call_0A00020D(ref v78));
                if (v79 != 0) {
                    goto IL_01F2;
                } else {
                    goto IL_01B1;
                }
                IL_01B1: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v80 = ref this;
                int v81 = 1;
                l0 = v81;
                v80.__il_field_0400059E = v81;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v82 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v83 = l7;
                v82.__il_field_040005A5 = v83;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v84 = ref this;
                ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v85 = ref v84.__il_field_0400059F;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v86 = ref l7;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v87 = ref this;
                __cil_methodspec_call_2B0000AF(ref v85, ref v86, ref v87);
                goto IL_03CB;
                IL_01D5: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v88 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v89 = v88.__il_field_040005A5;
                l7 = v89;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v90 = ref this;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v91 = ref v90.__il_field_040005A5;
                v91 = default;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v92 = ref this;
                int v93 = -1;
                l0 = v93;
                v92.__il_field_0400059E = v93;
                goto IL_01F2;
                IL_01F2: ;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v94 = ref l7;
                string v95 = __cil_value_call_0A00020E(ref v94);
                l6 = v95;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v96 = ref this;
                global::System.Xml.XmlWriter v97 = v96.__il_field_040005A4;
                string v98 = l6;
                __cil_callvirt_0600165F(v97, v98);
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v99 = ref this;
                v99.__il_field_040005A4 = null;
                goto IL_02A0;
                IL_0214: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v100 = ref this;
                global::System.Xml.XmlWriter v101 = v100.xtw;
                global::System.Xml.XmlReader v102 = l1;
                string v103 = __cil_callvirt_06000EBE(v102);
                __cil_callvirt_0600165A(v101, v103);
                goto IL_02A0;
                IL_0227: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v104 = ref this;
                global::System.Xml.XmlWriter v105 = v104.xtw;
                global::System.Xml.XmlReader v106 = l1;
                string v107 = __cil_callvirt_06000EB9(v106);
                __cil_callvirt_0600165D(v105, v107);
                goto IL_02A0;
                IL_023A: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v108 = ref this;
                global::System.Xml.XmlWriter v109 = v108.xtw;
                global::System.Xml.XmlReader v110 = l1;
                string v111 = __cil_callvirt_06000EB9(v110);
                global::System.Xml.XmlReader v112 = l1;
                string v113 = __cil_callvirt_06000EBE(v112);
                __cil_callvirt_0600165C(v109, v111, v113);
                goto IL_02A0;
                IL_0253: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v114 = ref this;
                global::System.Xml.XmlWriter v115 = v114.xtw;
                global::System.Xml.XmlReader v116 = l1;
                string v117 = __cil_callvirt_06000EB9(v116);
                global::System.Xml.XmlReader v118 = l1;
                string v119 = __cil_ldstr_7000D143("PUBLIC");
                string v120 = __cil_callvirt_06000EE8(v118, v119);
                global::System.Xml.XmlReader v121 = l1;
                string v122 = __cil_ldstr_7000D135("SYSTEM");
                string v123 = __cil_callvirt_06000EE8(v121, v122);
                global::System.Xml.XmlReader v124 = l1;
                string v125 = __cil_callvirt_06000EBE(v124);
                __cil_callvirt_0600164D(v115, v117, v120, v123, v125);
                goto IL_02A0;
                IL_0282: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v126 = ref this;
                global::System.Xml.XmlWriter v127 = v126.xtw;
                global::System.Xml.XmlReader v128 = l1;
                string v129 = __cil_callvirt_06000EBE(v128);
                __cil_callvirt_0600165B(v127, v129);
                goto IL_02A0;
                IL_0295: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v130 = ref this;
                global::System.Xml.XmlWriter v131 = v130.xtw;
                __cil_callvirt_06001652(v131);
                goto IL_02A0;
                IL_02A0: ;
                global::System.Xml.XmlReader v132 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v133 = __cil_callvirt_06000F4C(v132);
                int v134 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v135 = __cil_callvirt_0A00012B(v133, __cil_bool_store(v134));
                l10 = v135;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v136 = ref l10;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v137 = __cil_value_call_0A00012C(ref v136);
                l9 = v137;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v138 = ref l9;
                int v139 = __cil_bool_load(__cil_value_call_0A00012D(ref v138));
                if (v139 != 0) {
                    goto IL_0301;
                } else {
                    goto IL_02C0;
                }
                IL_02C0: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v140 = ref this;
                int v141 = 2;
                l0 = v141;
                v140.__il_field_0400059E = v141;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v142 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v143 = l9;
                v142.__il_field_040005A6 = v143;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v144 = ref this;
                ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v145 = ref v144.__il_field_0400059F;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v146 = ref l9;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v147 = ref this;
                __cil_methodspec_call_2B0000B0(ref v145, ref v146, ref v147);
                goto IL_03CB;
                IL_02E4: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v148 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v149 = v148.__il_field_040005A6;
                l9 = v149;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v150 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v151 = ref v150.__il_field_040005A6;
                v151 = default;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v152 = ref this;
                int v153 = -1;
                l0 = v153;
                v152.__il_field_0400059E = v153;
                goto IL_0301;
                IL_0301: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v154 = ref l9;
                int v155 = __cil_bool_load(__cil_value_call_0A00012F(ref v154));
                l8 = __cil_bool_store(v155);
                int v156 = __cil_bool_load(l8);
                if (v156 == 0) {
                    goto IL_031F;
                } else {
                    goto IL_030E;
                }
                IL_030E: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v157 = ref this;
                int v158 = v157.__il_field_040005A3;
                global::System.Xml.XmlReader v159 = l1;
                int v160 = __cil_callvirt_06000EBF(v159);
                if (v158 < v160) {
                    goto IL_0040;
                } else {
                    goto IL_031F;
                }
                IL_031F: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v161 = ref this;
                int v162 = v161.__il_field_040005A3;
                global::System.Xml.XmlReader v163 = l1;
                int v164 = __cil_callvirt_06000EBF(v163);
                if (unchecked((uint)v162) != unchecked((uint)v164)) {
                    goto IL_039D;
                } else {
                    goto IL_032D;
                }
                IL_032D: ;
                global::System.Xml.XmlReader v165 = l1;
                int v166 = unchecked((int)(__cil_callvirt_06000EB8(v165)));
                int v167 = 15;
                if (unchecked((uint)v166) != unchecked((uint)v167)) {
                    goto IL_039D;
                } else {
                    goto IL_0337;
                }
                IL_0337: ;
                global::System.Xml.XmlReader v168 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v169 = __cil_callvirt_06000F4C(v168);
                int v170 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v171 = __cil_callvirt_0A00012B(v169, __cil_bool_store(v170));
                l10 = v171;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v172 = ref l10;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v173 = __cil_value_call_0A00012C(ref v172);
                l11 = v173;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v174 = ref l11;
                int v175 = __cil_bool_load(__cil_value_call_0A00012D(ref v174));
                if (v175 != 0) {
                    goto IL_0395;
                } else {
                    goto IL_0357;
                }
                IL_0357: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v176 = ref this;
                int v177 = 3;
                l0 = v177;
                v176.__il_field_0400059E = v177;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v178 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v179 = l11;
                v178.__il_field_040005A6 = v179;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v180 = ref this;
                ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v181 = ref v180.__il_field_0400059F;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v182 = ref l11;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v183 = ref this;
                __cil_methodspec_call_2B0000B0(ref v181, ref v182, ref v183);
                goto IL_03CB;
                IL_0378: ;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v184 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v185 = v184.__il_field_040005A6;
                l11 = v185;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v186 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v187 = ref v186.__il_field_040005A6;
                v187 = default;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v188 = ref this;
                int v189 = -1;
                l0 = v189;
                v188.__il_field_0400059E = v189;
                goto IL_0395;
                IL_0395: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v190 = ref l11;
                int v191 = __cil_bool_load(__cil_value_call_0A00012F(ref v190));
                goto IL_039D;
                IL_039D: ;
                goto IL_03B8;
            }
            catch (System.Exception __cil_exception_0) {
                IL_039F: ;
                s36_0 = __cil_exception_0;
                l12 = s36_0;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v192 = ref this;
                int v193 = -2;
                v192.__il_field_0400059E = v193;
                ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v194 = ref this;
                ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v195 = ref v194.__il_field_0400059F;
                global::System.Exception v196 = l12;
                __cil_memberref_call_0A000113(ref v195, v196);
                goto IL_03CB;
            }
            IL_03B8: ;
            ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v197 = ref this;
            int v198 = -2;
            v197.__il_field_0400059E = v198;
            ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v199 = ref this;
            ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v200 = ref v199.__il_field_0400059F;
            __cil_memberref_call_0A000114(ref v200);
            goto IL_03CB;
            IL_03CB: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc bytes=11817D: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 bytes=1184CC: valuetype System.Xml.XmlReader/<WriteNodeAsync>d__198; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_9d7d2f7028e27b28ea3a4c8097c4369eb7570ef7 v0 = ref this;
            ref __cil_value_d5513bee5eadc1ccd6e807e09686ebd79ee543dc v1 = ref v0.__il_field_0400059F;
            __cil_type_01000063 v2 = stateMachine;
            __cil_memberref_call_0A000116(ref v1, v2);
            return;
        }
    }

    private struct __name_3C526561644F75746572586D6C4173796E633E645F5F313939 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_040005A7;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<string> __il_field_040005A8;
        public System.Xml.XmlReader __il_field_040005A9;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_040005AA;

        private virtual void MoveNext()
        {
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a bytes=1184D0: valuetype System.Xml.XmlReader/<ReadOuterXmlAsync>d__199; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            // enum storage token=0x020000E8 alias=__cil_enum_020000E8 underlying=int: global::@System.@Xml.@ReadState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            string l2 = default;
            __cil_type_010000A1 l3 = default;
            System.Xml.XmlWriter l4 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l5 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l6 = default;
            System.Exception l7 = default;
            System.Exception s19_0 = default;
            IL_0000: ;
            ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v0 = ref this;
            int v1 = v0.__il_field_040005A7;
            l0 = v1;
            ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_040005A9;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                if (v4 == 0) {
                    goto IL_007B;
                } else {
                    goto IL_0011;
                }
                IL_0011: ;
                global::System.Xml.XmlReader v5 = l1;
                int v6 = unchecked((int)(__cil_callvirt_06000EF8(v5)));
                int v7 = 1;
                if (v6 == v7) {
                    goto IL_0025;
                } else {
                    goto IL_001A;
                }
                IL_001A: ;
                string v8 = __cil_ldsfld_0A000002();
                l2 = v8;
                goto IL_012B;
                IL_0025: ;
                global::System.Xml.XmlReader v9 = l1;
                int v10 = unchecked((int)(__cil_callvirt_06000EB8(v9)));
                int v11 = 2;
                if (v10 == v11) {
                    goto IL_00AB;
                } else {
                    goto IL_002E;
                }
                IL_002E: ;
                global::System.Xml.XmlReader v12 = l1;
                int v13 = unchecked((int)(__cil_callvirt_06000EB8(v12)));
                int v14 = 1;
                if (v13 == v14) {
                    goto IL_00AB;
                } else {
                    goto IL_0037;
                }
                IL_0037: ;
                global::System.Xml.XmlReader v15 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v16 = __cil_callvirt_06000F4C(v15);
                int v17 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v18 = __cil_callvirt_0A00012B(v16, __cil_bool_store(v17));
                l6 = v18;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v19 = ref l6;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v20 = __cil_value_call_0A00012C(ref v19);
                l5 = v20;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v21 = ref l5;
                int v22 = __cil_bool_load(__cil_value_call_0A00012D(ref v21));
                if (v22 != 0) {
                    goto IL_0098;
                } else {
                    goto IL_0057;
                }
                IL_0057: ;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v23 = ref this;
                int v24 = 0;
                l0 = v24;
                v23.__il_field_040005A7 = v24;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v25 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v26 = l5;
                v25.__il_field_040005AA = v26;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v27 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v28 = ref v27.__il_field_040005A8;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v29 = ref l5;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v30 = ref this;
                __cil_methodspec_call_2B0000B1(ref v28, ref v29, ref v30);
                goto IL_013F;
                IL_007B: ;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v31 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v32 = v31.__il_field_040005AA;
                l5 = v32;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v33 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v34 = ref v33.__il_field_040005AA;
                v34 = default;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v35 = ref this;
                int v36 = -1;
                l0 = v36;
                v35.__il_field_040005A7 = v36;
                goto IL_0098;
                IL_0098: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v37 = ref l5;
                int v38 = __cil_bool_load(__cil_value_call_0A00012F(ref v37));
                string v39 = __cil_ldsfld_0A000002();
                l2 = v39;
                goto IL_012B;
                IL_00AB: ;
                __cil_type_0100000C v40 = System.Globalization.CultureInfo.get_InvariantCulture();
                __cil_type_010000A1 v41 = __cil_newobj_0A00022B(v40);
                l3 = v41;
                global::System.Xml.XmlReader v42 = l1;
                __cil_type_010000A1 v43 = l3;
                global::System.Xml.XmlWriter v44 = __cil_direct_06000F1D(v42, v43);
                l4 = v44;
                try {
                    IL_00BF: ;
                    global::System.Xml.XmlReader v45 = l1;
                    int v46 = unchecked((int)(__cil_callvirt_06000EB8(v45)));
                    int v47 = 2;
                    if (unchecked((uint)v46) != unchecked((uint)v47)) {
                        goto IL_00F2;
                    } else {
                        goto IL_00C8;
                    }
                    IL_00C8: ;
                    global::System.Xml.XmlWriter v48 = l4;
                    global::System.Xml.XmlReader v49 = l1;
                    string v50 = __cil_callvirt_06000EBC(v49);
                    global::System.Xml.XmlReader v51 = l1;
                    string v52 = __cil_callvirt_06000EBA(v51);
                    global::System.Xml.XmlReader v53 = l1;
                    string v54 = __cil_callvirt_06000EBB(v53);
                    __cil_callvirt_06001657(v48, v50, v52, v54);
                    global::System.Xml.XmlReader v55 = l1;
                    global::System.Xml.XmlWriter v56 = l4;
                    __cil_direct_06000F1B(v55, v56);
                    global::System.Xml.XmlWriter v57 = l4;
                    __cil_callvirt_06001659(v57);
                    goto IL_00FB;
                    IL_00F2: ;
                    global::System.Xml.XmlWriter v58 = l4;
                    global::System.Xml.XmlReader v59 = l1;
                    int v60 = 0;
                    __cil_callvirt_0600167B(v58, v59, __cil_bool_store(v60));
                    goto IL_00FB;
                    IL_00FB: ;
                    goto IL_0109;
                }
                finally {
                    IL_00FD: ;
                    int v61 = l0;
                    int v62 = 0;
                    if (v61 >= v62) {
                        goto IL_0108;
                    } else {
                        goto IL_0101;
                    }
                    IL_0101: ;
                    global::System.Xml.XmlWriter v63 = l4;
                    __cil_callvirt_06001668(v63);
                    goto IL_0108;
                    IL_0108: ;
                    goto __cil_finally_end_0;
                    __cil_finally_end_0: ;
                }
                IL_0109: ;
                __cil_type_010000A1 v64 = l3;
                string v65 = v64.ToString();
                l2 = v65;
                goto IL_012B;
            }
            catch (System.Exception __cil_exception_1) {
                IL_0112: ;
                s19_0 = __cil_exception_1;
                l7 = s19_0;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v66 = ref this;
                int v67 = -2;
                v66.__il_field_040005A7 = v67;
                ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v68 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v69 = ref v68.__il_field_040005A8;
                global::System.Exception v70 = l7;
                __cil_value_call_0A00023A(ref v69, v70);
                goto IL_013F;
            }
            IL_012B: ;
            ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v71 = ref this;
            int v72 = -2;
            v71.__il_field_040005A7 = v72;
            ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v73 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v74 = ref v73.__il_field_040005A8;
            string v75 = l2;
            __cil_value_call_0A00023B(ref v74, v75);
            goto IL_013F;
            IL_013F: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a bytes=1184D0: valuetype System.Xml.XmlReader/<ReadOuterXmlAsync>d__199; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_064a7dbe6878306d8633b5397cd8f2ec80a8a90a v0 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v1 = ref v0.__il_field_040005A8;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A00023C(ref v1, v2);
            return;
        }
    }

    private struct __name_3C536B6970537562747265654173796E633E645F5F323030 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_040005AB;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<bool> __il_field_040005AC;
        public System.Xml.XmlReader __il_field_040005AD;
        private int __il_field_040005AE;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_040005AF;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 bytes=1184D4: valuetype System.Xml.XmlReader/<SkipSubtreeAsync>d__200; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_03fd3b18870c594f421ab80395c461c692933e99 bytes=151181850102: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            bool l2 = default;
            bool l3 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l4 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l5 = default;
            bool l6 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l7 = default;
            bool l8 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l9 = default;
            System.Exception l10 = default;
            System.Exception s20_0 = default;
            IL_0000: ;
            ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v0 = ref this;
            int v1 = v0.__il_field_040005AB;
            l0 = v1;
            ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_040005AD;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                switch (v4) {
                    case 0: {
                        goto IL_008E;
                    }
                    case 1: {
                        goto IL_0115;
                    }
                    case 2: {
                        goto IL_0184;
                    }
                    default: {
                        goto IL_0020;
                    } }
                IL_0020: ;
                global::System.Xml.XmlReader v5 = l1;
                int v6 = __cil_bool_load(__cil_callvirt_06000EF3(v5));
                global::System.Xml.XmlReader v7 = l1;
                int v8 = unchecked((int)(__cil_callvirt_06000EB8(v7)));
                int v9 = 1;
                if (unchecked((uint)v8) != unchecked((uint)v9)) {
                    goto IL_0143;
                } else {
                    goto IL_0033;
                }
                IL_0033: ;
                global::System.Xml.XmlReader v10 = l1;
                int v11 = __cil_bool_load(__cil_callvirt_06000EC1(v10));
                if (v11 != 0) {
                    goto IL_0143;
                } else {
                    goto IL_003E;
                }
                IL_003E: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v12 = ref this;
                global::System.Xml.XmlReader v13 = l1;
                int v14 = __cil_callvirt_06000EBF(v13);
                v12.__il_field_040005AE = v14;
                goto IL_004A;
                IL_004A: ;
                global::System.Xml.XmlReader v15 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v16 = __cil_callvirt_06000F4C(v15);
                int v17 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v18 = __cil_callvirt_0A00012B(v16, __cil_bool_store(v17));
                l5 = v18;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v19 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v20 = __cil_value_call_0A00012C(ref v19);
                l4 = v20;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v21 = ref l4;
                int v22 = __cil_bool_load(__cil_value_call_0A00012D(ref v21));
                if (v22 != 0) {
                    goto IL_00AB;
                } else {
                    goto IL_006A;
                }
                IL_006A: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v23 = ref this;
                int v24 = 0;
                l0 = v24;
                v23.__il_field_040005AB = v24;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v25 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v26 = l4;
                v25.__il_field_040005AF = v26;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v27 = ref this;
                ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v28 = ref v27.__il_field_040005AC;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v29 = ref l4;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v30 = ref this;
                __cil_methodspec_call_2B0000B2(ref v28, ref v29, ref v30);
                goto IL_01E0;
                IL_008E: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v31 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v32 = v31.__il_field_040005AF;
                l4 = v32;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v33 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v34 = ref v33.__il_field_040005AF;
                v34 = default;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v35 = ref this;
                int v36 = -1;
                l0 = v36;
                v35.__il_field_040005AB = v36;
                goto IL_00AB;
                IL_00AB: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v37 = ref l4;
                int v38 = __cil_bool_load(__cil_value_call_0A00012F(ref v37));
                l3 = __cil_bool_store(v38);
                int v39 = __cil_bool_load(l3);
                if (v39 == 0) {
                    goto IL_00C4;
                } else {
                    goto IL_00B6;
                }
                IL_00B6: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v40 = ref this;
                int v41 = v40.__il_field_040005AE;
                global::System.Xml.XmlReader v42 = l1;
                int v43 = __cil_callvirt_06000EBF(v42);
                if (v41 < v43) {
                    goto IL_004A;
                } else {
                    goto IL_00C4;
                }
                IL_00C4: ;
                global::System.Xml.XmlReader v44 = l1;
                int v45 = unchecked((int)(__cil_callvirt_06000EB8(v44)));
                int v46 = 15;
                if (unchecked((uint)v45) != unchecked((uint)v46)) {
                    goto IL_01AF;
                } else {
                    goto IL_00D1;
                }
                IL_00D1: ;
                global::System.Xml.XmlReader v47 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v48 = __cil_callvirt_06000F4C(v47);
                int v49 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v50 = __cil_callvirt_0A00012B(v48, __cil_bool_store(v49));
                l5 = v50;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v51 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v52 = __cil_value_call_0A00012C(ref v51);
                l7 = v52;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v53 = ref l7;
                int v54 = __cil_bool_load(__cil_value_call_0A00012D(ref v53));
                if (v54 != 0) {
                    goto IL_0132;
                } else {
                    goto IL_00F1;
                }
                IL_00F1: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v55 = ref this;
                int v56 = 1;
                l0 = v56;
                v55.__il_field_040005AB = v56;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v57 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v58 = l7;
                v57.__il_field_040005AF = v58;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v59 = ref this;
                ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v60 = ref v59.__il_field_040005AC;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v61 = ref l7;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v62 = ref this;
                __cil_methodspec_call_2B0000B2(ref v60, ref v61, ref v62);
                goto IL_01E0;
                IL_0115: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v63 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v64 = v63.__il_field_040005AF;
                l7 = v64;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v65 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v66 = ref v65.__il_field_040005AF;
                v66 = default;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v67 = ref this;
                int v68 = -1;
                l0 = v68;
                v67.__il_field_040005AB = v68;
                goto IL_0132;
                IL_0132: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v69 = ref l7;
                int v70 = __cil_bool_load(__cil_value_call_0A00012F(ref v69));
                l6 = __cil_bool_store(v70);
                int v71 = __cil_bool_load(l6);
                l2 = __cil_bool_store(v71);
                goto IL_01CC;
                IL_0143: ;
                global::System.Xml.XmlReader v72 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v73 = __cil_callvirt_06000F4C(v72);
                int v74 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v75 = __cil_callvirt_0A00012B(v73, __cil_bool_store(v74));
                l5 = v75;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v76 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v77 = __cil_value_call_0A00012C(ref v76);
                l9 = v77;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v78 = ref l9;
                int v79 = __cil_bool_load(__cil_value_call_0A00012D(ref v78));
                if (v79 != 0) {
                    goto IL_01A1;
                } else {
                    goto IL_0163;
                }
                IL_0163: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v80 = ref this;
                int v81 = 2;
                l0 = v81;
                v80.__il_field_040005AB = v81;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v82 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v83 = l9;
                v82.__il_field_040005AF = v83;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v84 = ref this;
                ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v85 = ref v84.__il_field_040005AC;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v86 = ref l9;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v87 = ref this;
                __cil_methodspec_call_2B0000B2(ref v85, ref v86, ref v87);
                goto IL_01E0;
                IL_0184: ;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v88 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v89 = v88.__il_field_040005AF;
                l9 = v89;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v90 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v91 = ref v90.__il_field_040005AF;
                v91 = default;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v92 = ref this;
                int v93 = -1;
                l0 = v93;
                v92.__il_field_040005AB = v93;
                goto IL_01A1;
                IL_01A1: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v94 = ref l9;
                int v95 = __cil_bool_load(__cil_value_call_0A00012F(ref v94));
                l8 = __cil_bool_store(v95);
                int v96 = __cil_bool_load(l8);
                l2 = __cil_bool_store(v96);
                goto IL_01CC;
                IL_01AF: ;
                int v97 = 0;
                l2 = __cil_bool_store(v97);
                goto IL_01CC;
            }
            catch (System.Exception __cil_exception_0) {
                IL_01B3: ;
                s20_0 = __cil_exception_0;
                l10 = s20_0;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v98 = ref this;
                int v99 = -2;
                v98.__il_field_040005AB = v99;
                ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v100 = ref this;
                ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v101 = ref v100.__il_field_040005AC;
                global::System.Exception v102 = l10;
                __cil_value_call_0A00011A(ref v101, v102);
                goto IL_01E0;
            }
            IL_01CC: ;
            ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v103 = ref this;
            int v104 = -2;
            v103.__il_field_040005AB = v104;
            ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v105 = ref this;
            ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v106 = ref v105.__il_field_040005AC;
            int v107 = __cil_bool_load(l2);
            __cil_value_call_0A00011B(ref v106, __cil_bool_store(v107));
            goto IL_01E0;
            IL_01E0: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 bytes=1184D4: valuetype System.Xml.XmlReader/<SkipSubtreeAsync>d__200; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_03fd3b18870c594f421ab80395c461c692933e99 bytes=151181850102: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_5f64c228c2f79d21c6fc3a66e6c4b3dccdbe0a62 v0 = ref this;
            ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v1 = ref v0.__il_field_040005AC;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A00011C(ref v1, v2);
            return;
        }
    }

    private struct __name_3C496E7465726E616C52656164436F6E74656E744173537472696E674173796E633E645F5F323031 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_040005B0;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<string> __il_field_040005B1;
        public System.Xml.XmlReader __il_field_040005B2;
        private string __il_field_040005B3;
        private System.Text.StringBuilder __il_field_040005B4;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<string> __il_field_040005B5;
        private System.Text.StringBuilder __il_field_040005B6;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_040005B7;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de bytes=1512816D010E: class [System.Runtime]System.Threading.Tasks.Task`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 bytes=1184D8: valuetype System.Xml.XmlReader/<InternalReadContentAsStringAsync>d__201; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa bytes=151181A1010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa bytes=1511819D010E: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            string l2 = default;
            __cil_enum_020000B5 l3 = default;
            string l4 = default;
            __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa l5 = default;
            __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa l6 = default;
            string l7 = default;
            __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa l8 = default;
            bool l9 = default;
            bool l10 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l11 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l12 = default;
            System.Exception l13 = default;
            string s29_0 = default;
            System.Exception s30_0 = default;
            IL_0000: ;
            ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v0 = ref this;
            int v1 = v0.__il_field_040005B0;
            l0 = v1;
            ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_040005B2;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                switch (v4) {
                    case 0: {
                        goto IL_00DF;
                    }
                    case 1: {
                        goto IL_0187;
                    }
                    case 2: {
                        goto IL_0228;
                    }
                    default: {
                        goto IL_0020;
                    } }
                IL_0020: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v5 = ref this;
                string v6 = __cil_ldsfld_0A000002();
                v5.__il_field_040005B3 = v6;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v7 = ref this;
                v7.__il_field_040005B4 = null;
                goto IL_0032;
                IL_0032: ;
                global::System.Xml.XmlReader v8 = l1;
                int v9 = unchecked((int)(__cil_callvirt_06000EB8(v8)));
                l3 = unchecked((__cil_enum_020000B5)(v9));
                int v10 = unchecked((int)(l3));
                int v11 = 2;
                int v12 = unchecked(v10 - v11);
                switch (v12) {
                    case 0: {
                        goto IL_0082;
                    }
                    case 1: {
                        goto IL_008E;
                    }
                    case 2: {
                        goto IL_008E;
                    }
                    case 3: {
                        goto IL_01C4;
                    }
                    case 4: {
                        goto IL_0259;
                    }
                    case 5: {
                        goto IL_01D5;
                    }
                    case 6: {
                        goto IL_01D5;
                    }
                    case 7: {
                        goto IL_0259;
                    }
                    case 8: {
                        goto IL_0259;
                    }
                    case 9: {
                        goto IL_0259;
                    }
                    case 10: {
                        goto IL_0259;
                    }
                    case 11: {
                        goto IL_008E;
                    }
                    case 12: {
                        goto IL_008E;
                    }
                    case 13: {
                        goto IL_0259;
                    }
                    case 14: {
                        goto IL_01D5;
                    }
                    default: {
                        goto IL_007D;
                    } }
                IL_007D: ;
                goto IL_0259;
                IL_0082: ;
                global::System.Xml.XmlReader v13 = l1;
                string v14 = __cil_callvirt_06000EBE(v13);
                l2 = v14;
                goto IL_0290;
                IL_008E: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v15 = ref this;
                string v16 = v15.__il_field_040005B3;
                int v17 = ((System.String)v16).Length;
                if (v17 != 0) {
                    goto IL_0112;
                } else {
                    goto IL_009B;
                }
                IL_009B: ;
                global::System.Xml.XmlReader v18 = l1;
                __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v19 = __cil_callvirt_06000F45(v18);
                int v20 = 0;
                __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v21 = __cil_callvirt_0A00020B(v19, __cil_bool_store(v20));
                l6 = v21;
                ref __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v22 = ref l6;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v23 = __cil_value_call_0A00020C(ref v22);
                l5 = v23;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v24 = ref l5;
                int v25 = __cil_bool_load(__cil_value_call_0A00020D(ref v24));
                if (v25 != 0) {
                    goto IL_00FC;
                } else {
                    goto IL_00BB;
                }
                IL_00BB: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v26 = ref this;
                int v27 = 0;
                l0 = v27;
                v26.__il_field_040005B0 = v27;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v28 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v29 = l5;
                v28.__il_field_040005B5 = v29;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v30 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v31 = ref v30.__il_field_040005B1;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v32 = ref l5;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v33 = ref this;
                __cil_methodspec_call_2B0000B3(ref v31, ref v32, ref v33);
                goto IL_02A4;
                IL_00DF: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v34 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v35 = v34.__il_field_040005B5;
                l5 = v35;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v36 = ref this;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v37 = ref v36.__il_field_040005B5;
                v37 = default;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v38 = ref this;
                int v39 = -1;
                l0 = v39;
                v38.__il_field_040005B0 = v39;
                goto IL_00FC;
                IL_00FC: ;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v40 = ref l5;
                string v41 = __cil_value_call_0A00020E(ref v40);
                l4 = v41;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v42 = ref this;
                string v43 = l4;
                v42.__il_field_040005B3 = v43;
                goto IL_01D5;
                IL_0112: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v44 = ref this;
                __cil_type_0100002E v45 = v44.__il_field_040005B4;
                if (v45 is not null) {
                    goto IL_0137;
                } else {
                    goto IL_011A;
                }
                IL_011A: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v46 = ref this;
                __cil_type_0100002E v47 = __cil_newobj_0A000053();
                v46.__il_field_040005B4 = v47;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v48 = ref this;
                __cil_type_0100002E v49 = v48.__il_field_040005B4;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v50 = ref this;
                string v51 = v50.__il_field_040005B3;
                __cil_type_0100002E v52 = v49.Append(v51);
                goto IL_0137;
                IL_0137: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v53 = ref this;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v54 = ref this;
                __cil_type_0100002E v55 = v54.__il_field_040005B4;
                v53.__il_field_040005B6 = v55;
                global::System.Xml.XmlReader v56 = l1;
                __cil_ref_a4653a8341034fc894ddd20d3c8fcd4b01c622de v57 = __cil_callvirt_06000F45(v56);
                int v58 = 0;
                __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v59 = __cil_callvirt_0A00020B(v57, __cil_bool_store(v58));
                l6 = v59;
                ref __cil_value_20739ad8d566360a85b8fcabc2aec019ef5a15aa v60 = ref l6;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v61 = __cil_value_call_0A00020C(ref v60);
                l8 = v61;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v62 = ref l8;
                int v63 = __cil_bool_load(__cil_value_call_0A00020D(ref v62));
                if (v63 != 0) {
                    goto IL_01A4;
                } else {
                    goto IL_0163;
                }
                IL_0163: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v64 = ref this;
                int v65 = 1;
                l0 = v65;
                v64.__il_field_040005B0 = v65;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v66 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v67 = l8;
                v66.__il_field_040005B5 = v67;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v68 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v69 = ref v68.__il_field_040005B1;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v70 = ref l8;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v71 = ref this;
                __cil_methodspec_call_2B0000B3(ref v69, ref v70, ref v71);
                goto IL_02A4;
                IL_0187: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v72 = ref this;
                __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v73 = v72.__il_field_040005B5;
                l8 = v73;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v74 = ref this;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v75 = ref v74.__il_field_040005B5;
                v75 = default;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v76 = ref this;
                int v77 = -1;
                l0 = v77;
                v76.__il_field_040005B0 = v77;
                goto IL_01A4;
                IL_01A4: ;
                ref __cil_value_5de27b8c20dfb8acad40fd65361a4e957b7b75fa v78 = ref l8;
                string v79 = __cil_value_call_0A00020E(ref v78);
                l7 = v79;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v80 = ref this;
                __cil_type_0100002E v81 = v80.__il_field_040005B6;
                string v82 = l7;
                __cil_type_0100002E v83 = v81.Append(v82);
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v84 = ref this;
                v84.__il_field_040005B6 = null;
                goto IL_01D5;
                IL_01C4: ;
                global::System.Xml.XmlReader v85 = l1;
                int v86 = __cil_bool_load(__cil_callvirt_06000EFC(v85));
                if (v86 == 0) {
                    goto IL_0259;
                } else {
                    goto IL_01CF;
                }
                IL_01CF: ;
                global::System.Xml.XmlReader v87 = l1;
                __cil_callvirt_06000EFD(v87);
                goto IL_01D5;
                IL_01D5: ;
                global::System.Xml.XmlReader v88 = l1;
                int v89 = __cil_callvirt_06000EE7(v88);
                if (v89 == 0) {
                    goto IL_01E7;
                } else {
                    goto IL_01DD;
                }
                IL_01DD: ;
                global::System.Xml.XmlReader v90 = l1;
                int v91 = __cil_bool_load(__cil_callvirt_06000EF4(v90));
                l9 = __cil_bool_store(v91);
                goto IL_0252;
                IL_01E7: ;
                global::System.Xml.XmlReader v92 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v93 = __cil_callvirt_06000F4C(v92);
                int v94 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v95 = __cil_callvirt_0A00012B(v93, __cil_bool_store(v94));
                l12 = v95;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v96 = ref l12;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v97 = __cil_value_call_0A00012C(ref v96);
                l11 = v97;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v98 = ref l11;
                int v99 = __cil_bool_load(__cil_value_call_0A00012D(ref v98));
                if (v99 != 0) {
                    goto IL_0245;
                } else {
                    goto IL_0207;
                }
                IL_0207: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v100 = ref this;
                int v101 = 2;
                l0 = v101;
                v100.__il_field_040005B0 = v101;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v102 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v103 = l11;
                v102.__il_field_040005B7 = v103;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v104 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v105 = ref v104.__il_field_040005B1;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v106 = ref l11;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v107 = ref this;
                __cil_methodspec_call_2B0000B4(ref v105, ref v106, ref v107);
                goto IL_02A4;
                IL_0228: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v108 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v109 = v108.__il_field_040005B7;
                l11 = v109;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v110 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v111 = ref v110.__il_field_040005B7;
                v111 = default;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v112 = ref this;
                int v113 = -1;
                l0 = v113;
                v112.__il_field_040005B0 = v113;
                goto IL_0245;
                IL_0245: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v114 = ref l11;
                int v115 = __cil_bool_load(__cil_value_call_0A00012F(ref v114));
                l10 = __cil_bool_store(v115);
                int v116 = __cil_bool_load(l10);
                l9 = __cil_bool_store(v116);
                goto IL_0252;
                IL_0252: ;
                int v117 = __cil_bool_load(l9);
                if (v117 != 0) {
                    goto IL_0032;
                } else {
                    goto IL_0259;
                }
                IL_0259: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v118 = ref this;
                __cil_type_0100002E v119 = v118.__il_field_040005B4;
                if (v119 is null) {
                    goto IL_026E;
                } else {
                    goto IL_0261;
                }
                IL_0261: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v120 = ref this;
                __cil_type_0100002E v121 = v120.__il_field_040005B4;
                string v122 = v121.ToString();
                string e27_29_0 = v122;
                s29_0 = e27_29_0;
                goto IL_0274;
                IL_026E: ;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v123 = ref this;
                string v124 = v123.__il_field_040005B3;
                string e28_29_0 = v124;
                s29_0 = e28_29_0;
                goto IL_0274;
                IL_0274: ;
                l2 = s29_0;
                goto IL_0290;
            }
            catch (System.Exception __cil_exception_0) {
                IL_0277: ;
                s30_0 = __cil_exception_0;
                l13 = s30_0;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v125 = ref this;
                int v126 = -2;
                v125.__il_field_040005B0 = v126;
                ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v127 = ref this;
                ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v128 = ref v127.__il_field_040005B1;
                global::System.Exception v129 = l13;
                __cil_value_call_0A00023A(ref v128, v129);
                goto IL_02A4;
            }
            IL_0290: ;
            ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v130 = ref this;
            int v131 = -2;
            v130.__il_field_040005B0 = v131;
            ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v132 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v133 = ref v132.__il_field_040005B1;
            string v134 = l2;
            __cil_value_call_0A00023B(ref v133, v134);
            goto IL_02A4;
            IL_02A4: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a bytes=15118185010E: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 bytes=1184D8: valuetype System.Xml.XmlReader/<InternalReadContentAsStringAsync>d__201; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_7a966e3de6dd03de4aecc06cfbf2a7489d45c196 v0 = ref this;
            ref __cil_value_98ed71d349420fc058b6e44df7ef9f82d9bef65a v1 = ref v0.__il_field_040005B1;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A00023C(ref v1, v2);
            return;
        }
    }

    private struct __name_3C536574757052656164456C656D656E74436F6E74656E7441735878784173796E633E645F5F323032 : System.Runtime.CompilerServices.IAsyncStateMachine
    {
        public int __il_field_040005B8;
        public System.Runtime.CompilerServices.AsyncTaskMethodBuilder<bool> __il_field_040005B9;
        public System.Xml.XmlReader __il_field_040005BA;
        public string methodName;
        private bool __il_field_040005BC;
        private System.Runtime.CompilerServices.ConfiguredTaskAwaitable.ConfiguredTaskAwaiter<bool> __il_field_040005BD;

        private virtual void MoveNext()
        {
            // structural signature __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 bytes=1512816D0102: class [System.Runtime]System.Threading.Tasks.Task`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_value_03fd3b18870c594f421ab80395c461c692933e99 bytes=151181850102: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 bytes=1184DC: valuetype System.Xml.XmlReader/<SetupReadElementContentAsXxxAsync>d__202; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_117947d8798be035d2e5ebae33b203663653bbbc bytes=151181A10102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce bytes=1511819D0102: valuetype [System.Runtime]System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x020000B5 alias=__cil_enum_020000B5 underlying=int: global::@System.@Xml.@XmlNodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int l0 = default;
            System.Xml.XmlReader l1 = default;
            bool l2 = default;
            __cil_enum_020000B5 l3 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l4 = default;
            __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce l5 = default;
            __cil_value_117947d8798be035d2e5ebae33b203663653bbbc l6 = default;
            System.Exception l7 = default;
            System.Exception s18_0 = default;
            IL_0000: ;
            ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v0 = ref this;
            int v1 = v0.__il_field_040005B8;
            l0 = v1;
            ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v2 = ref this;
            global::System.Xml.XmlReader v3 = v2.__il_field_040005BA;
            l1 = v3;
            try {
                IL_000E: ;
                int v4 = l0;
                if (v4 == 0) {
                    goto IL_007E;
                } else {
                    goto IL_0011;
                }
                IL_0011: ;
                int v5 = l0;
                int v6 = 1;
                if (v5 == v6) {
                    goto IL_00FF;
                } else {
                    goto IL_0018;
                }
                IL_0018: ;
                global::System.Xml.XmlReader v7 = l1;
                int v8 = unchecked((int)(__cil_callvirt_06000EB8(v7)));
                int v9 = 1;
                if (v8 == v9) {
                    goto IL_002E;
                } else {
                    goto IL_0021;
                }
                IL_0021: ;
                global::System.Xml.XmlReader v10 = l1;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v11 = ref this;
                string v12 = v11.methodName;
                global::System.Exception v13 = __cil_direct_06000F2A(v10, v12);
                throw v13;
                IL_002E: ;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v14 = ref this;
                global::System.Xml.XmlReader v15 = l1;
                int v16 = __cil_bool_load(__cil_callvirt_06000EC1(v15));
                v14.__il_field_040005BC = __cil_bool_store(v16);
                global::System.Xml.XmlReader v17 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v18 = __cil_callvirt_06000F4C(v17);
                int v19 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v20 = __cil_callvirt_0A00012B(v18, __cil_bool_store(v19));
                l5 = v20;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v21 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v22 = __cil_value_call_0A00012C(ref v21);
                l4 = v22;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v23 = ref l4;
                int v24 = __cil_bool_load(__cil_value_call_0A00012D(ref v23));
                if (v24 != 0) {
                    goto IL_009B;
                } else {
                    goto IL_005A;
                }
                IL_005A: ;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v25 = ref this;
                int v26 = 0;
                l0 = v26;
                v25.__il_field_040005B8 = v26;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v27 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v28 = l4;
                v27.__il_field_040005BD = v28;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v29 = ref this;
                ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v30 = ref v29.__il_field_040005B9;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v31 = ref l4;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v32 = ref this;
                __cil_methodspec_call_2B0000B5(ref v30, ref v31, ref v32);
                goto IL_0173;
                IL_007E: ;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v33 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v34 = v33.__il_field_040005BD;
                l4 = v34;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v35 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v36 = ref v35.__il_field_040005BD;
                v36 = default;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v37 = ref this;
                int v38 = -1;
                l0 = v38;
                v37.__il_field_040005B8 = v38;
                goto IL_009B;
                IL_009B: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v39 = ref l4;
                int v40 = __cil_bool_load(__cil_value_call_0A00012F(ref v39));
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v41 = ref this;
                int v42 = __cil_bool_load(v41.__il_field_040005BC);
                if (v42 == 0) {
                    goto IL_00B2;
                } else {
                    goto IL_00AB;
                }
                IL_00AB: ;
                int v43 = 0;
                l2 = __cil_bool_store(v43);
                goto IL_015F;
                IL_00B2: ;
                global::System.Xml.XmlReader v44 = l1;
                int v45 = unchecked((int)(__cil_callvirt_06000EB8(v44)));
                l3 = unchecked((__cil_enum_020000B5)(v45));
                int v46 = unchecked((int)(l3));
                int v47 = 15;
                if (unchecked((uint)v46) != unchecked((uint)v47)) {
                    goto IL_0128;
                } else {
                    goto IL_00BE;
                }
                IL_00BE: ;
                global::System.Xml.XmlReader v48 = l1;
                __cil_ref_7ad38ed20f61089107cbdc4c0e59d8736d94f9a0 v49 = __cil_callvirt_06000F4C(v48);
                int v50 = 0;
                __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v51 = __cil_callvirt_0A00012B(v49, __cil_bool_store(v50));
                l5 = v51;
                ref __cil_value_ed3f7d9203d6952686db7c09e1e71974360017ce v52 = ref l5;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v53 = __cil_value_call_0A00012C(ref v52);
                l6 = v53;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v54 = ref l6;
                int v55 = __cil_bool_load(__cil_value_call_0A00012D(ref v54));
                if (v55 != 0) {
                    goto IL_011C;
                } else {
                    goto IL_00DE;
                }
                IL_00DE: ;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v56 = ref this;
                int v57 = 1;
                l0 = v57;
                v56.__il_field_040005B8 = v57;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v58 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v59 = l6;
                v58.__il_field_040005BD = v59;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v60 = ref this;
                ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v61 = ref v60.__il_field_040005B9;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v62 = ref l6;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v63 = ref this;
                __cil_methodspec_call_2B0000B5(ref v61, ref v62, ref v63);
                goto IL_0173;
                IL_00FF: ;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v64 = ref this;
                __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v65 = v64.__il_field_040005BD;
                l6 = v65;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v66 = ref this;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v67 = ref v66.__il_field_040005BD;
                v67 = default;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v68 = ref this;
                int v69 = -1;
                l0 = v69;
                v68.__il_field_040005B8 = v69;
                goto IL_011C;
                IL_011C: ;
                ref __cil_value_117947d8798be035d2e5ebae33b203663653bbbc v70 = ref l6;
                int v71 = __cil_bool_load(__cil_value_call_0A00012F(ref v70));
                int v72 = 0;
                l2 = __cil_bool_store(v72);
                goto IL_015F;
                IL_0128: ;
                int v73 = unchecked((int)(l3));
                int v74 = 1;
                if (unchecked((uint)v73) != unchecked((uint)v74)) {
                    goto IL_0142;
                } else {
                    goto IL_012C;
                }
                IL_012C: ;
                string v75 = System.SR.get_Xml_MixedReadElementContentAs();
                string v76 = __cil_ldsfld_0A000002();
                global::System.Xml.XmlReader v77 = l1;
                global::System.Xml.IXmlLineInfo v78 = ((object)v77 as System.Xml.IXmlLineInfo);
                global::System.Xml.XmlException v79 = __cil_newobj_06000A0D(v75, v76, v78);
                throw v79;
                IL_0142: ;
                int v80 = 1;
                l2 = __cil_bool_store(v80);
                goto IL_015F;
            }
            catch (System.Exception __cil_exception_0) {
                IL_0146: ;
                s18_0 = __cil_exception_0;
                l7 = s18_0;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v81 = ref this;
                int v82 = -2;
                v81.__il_field_040005B8 = v82;
                ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v83 = ref this;
                ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v84 = ref v83.__il_field_040005B9;
                global::System.Exception v85 = l7;
                __cil_value_call_0A00011A(ref v84, v85);
                goto IL_0173;
            }
            IL_015F: ;
            ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v86 = ref this;
            int v87 = -2;
            v86.__il_field_040005B8 = v87;
            ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v88 = ref this;
            ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v89 = ref v88.__il_field_040005B9;
            int v90 = __cil_bool_load(l2);
            __cil_value_call_0A00011B(ref v89, __cil_bool_store(v90));
            goto IL_0173;
            IL_0173: ;
            return;
        }

        private virtual void SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine)
        {
            // structural signature __cil_value_03fd3b18870c594f421ab80395c461c692933e99 bytes=151181850102: valuetype [System.Threading.Tasks]System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 bytes=1184DC: valuetype System.Xml.XmlReader/<SetupReadElementContentAsXxxAsync>d__202; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_f52b5737e4b6aa25876dfcb93ab5cb7e7ecc8be7 v0 = ref this;
            ref __cil_value_03fd3b18870c594f421ab80395c461c692933e99 v1 = ref v0.__il_field_040005B9;
            __cil_type_01000063 v2 = stateMachine;
            __cil_value_call_0A00011C(ref v1, v2);
            return;
        }
    }
}
