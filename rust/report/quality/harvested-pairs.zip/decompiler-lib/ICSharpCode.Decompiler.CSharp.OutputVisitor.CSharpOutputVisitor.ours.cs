namespace ICSharpCode.Decompiler.CSharp.OutputVisitor;

public class CSharpOutputVisitor : ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor
{
    protected readonly ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter writer;
    protected readonly ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions policy;
    protected readonly System.Collections.Generic.Stack<ICSharpCode.Decompiler.CSharp.Syntax.AstNode> containerStack;
    protected bool isAtStartOfLine;
    private static readonly System.Collections.Generic.HashSet<string> unconditionalKeywords;
    private static readonly System.Collections.Generic.HashSet<string> queryKeywords;

    public CSharpOutputVisitor(System.IO.TextWriter textWriter, ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions formattingPolicy)
    {
        // structural signature __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 bytes=151280CD011287F4: class [System]System.Collections.Generic.Stack`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 v1 = __cil_newobj_0A0000D8();
        this.containerStack = v1;
        this.isAtStartOfLine = __cil_bool_store(1);
        __cil_core_object_ctor_0A000092(this);
        if (textWriter is not null) {
            goto IL_0026;
        } else {
            goto IL_001B;
        }
        IL_001B: ;
        string v6 = __cil_ldstr_70008716("textWriter");
        global::System.ArgumentNullException v7 = __cil_newobj_0A0000C7(v6);
        throw v7;
        IL_0026: ;
        if (formattingPolicy is not null) {
            goto IL_0034;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        string v9 = __cil_ldstr_70008646("formattingPolicy");
        global::System.ArgumentNullException v10 = __cil_newobj_0A0000C7(v9);
        throw v10;
        IL_0034: ;
        string v13 = __cil_ldstr_7000872C("\u0009");
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v14 = ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter.Create(textWriter, v13);
        this.writer = v14;
        this.policy = formattingPolicy;
        return;
    }

    public CSharpOutputVisitor(ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter writer, ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions formattingPolicy)
    {
        // structural signature __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 bytes=151280CD011287F4: class [System]System.Collections.Generic.Stack`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 v1 = __cil_newobj_0A0000D8();
        this.containerStack = v1;
        this.isAtStartOfLine = __cil_bool_store(1);
        __cil_core_object_ctor_0A000092(this);
        if (writer is not null) {
            goto IL_0026;
        } else {
            goto IL_001B;
        }
        IL_001B: ;
        string v6 = __cil_ldstr_700009A6("writer");
        global::System.ArgumentNullException v7 = __cil_newobj_0A0000C7(v6);
        throw v7;
        IL_0026: ;
        if (formattingPolicy is not null) {
            goto IL_0034;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        string v9 = __cil_ldstr_70008646("formattingPolicy");
        global::System.ArgumentNullException v10 = __cil_newobj_0A0000C7(v9);
        throw v10;
        IL_0034: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.InsertRequiredSpacesDecorator v13 = __cil_newobj_060016A5(writer);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.InsertSpecialsDecorator v14 = __cil_newobj_060016AF(v13);
        this.writer = v14;
        this.policy = formattingPolicy;
        return;
    }

    protected virtual void StartNode(ICSharpCode.Decompiler.CSharp.Syntax.AstNode node)
    {
        // structural signature __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 bytes=151280CD011287F4: class [System]System.Collections.Generic.Stack`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 v1 = this.containerStack;
        __cil_callvirt_0A0000E5(v1, node);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v4 = this.writer;
        __cil_callvirt_060016BA(v4, node);
        return;
    }

    protected virtual void EndNode(ICSharpCode.Decompiler.CSharp.Syntax.AstNode node)
    {
        // structural signature __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 bytes=151280CD011287F4: class [System]System.Collections.Generic.Stack`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 v1 = this.containerStack;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v2 = __cil_callvirt_0A0000E6(v1);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v4 = this.writer;
        __cil_callvirt_060016BB(v4, node);
        return;
    }

    protected virtual void Comma(ICSharpCode.Decompiler.CSharp.Syntax.AstNode nextNode, bool noSpaceAfterComma = false)
    {
        ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor s1_0 = default;
        ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor s2_0 = default;
        ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor s3_0 = default;
        int s3_1 = default;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v2 = this.policy;
        int v3 = __cil_bool_load(__cil_callvirt_06001588(v2));
        __cil_callvirt_060015ED(this, __cil_bool_store(v3));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v5 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v6 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Comma;
        string v7 = __cil_ldstr_700042FF(",");
        __cil_callvirt_060016BE(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v6)), v7);
        int v9 = __cil_bool_load(noSpaceAfterComma);
        if (v9 != 0) {
            ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor e0_2_0 = this;
            s2_0 = e0_2_0;
            goto IL_0037;
        } else {
            ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor e0_1_0 = this;
            s1_0 = e0_1_0;
            goto IL_002A;
        }
        IL_002A: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_0600158A(v11));
        ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor e1_3_0 = s1_0;
        int e1_3_1 = v12;
        s3_0 = e1_3_0;
        s3_1 = e1_3_1;
        goto IL_0038;
        IL_0037: ;
        ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor e2_3_0 = s2_0;
        int e2_3_1 = 0;
        s3_0 = e2_3_0;
        s3_1 = e2_3_1;
        IL_0038: ;
        __cil_callvirt_060015ED(s3_0, __cil_bool_store(s3_1));
        return;
    }

    protected virtual void OptionalComma(ICSharpCode.Decompiler.CSharp.Syntax.AstNode pos)
    {
        // enum storage token=0x0200025C alias=__cil_enum_0200025C underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@NodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        goto IL_000A;
        IL_0002: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v0 = pos;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v1 = __cil_callvirt_06001703(v0);
        pos = v1;
        IL_000A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v2 = pos;
        if (v2 is null) {
            goto IL_0016;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v3 = pos;
        int v4 = unchecked((int)(__cil_callvirt_060016F8(v3)));
        if (v4 == 8) {
            goto IL_0002;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v6 = pos;
        if (v6 is null) {
            goto IL_002E;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v7 = pos;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v8 = __cil_callvirt_060016FF(v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Comma;
        if (!System.Object.ReferenceEquals(v8, v9)) {
            goto IL_002E;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        __cil_callvirt_060015DD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(null)), __cil_bool_store(1));
        IL_002E: ;
        return;
    }

    protected virtual void OptionalSemicolon(ICSharpCode.Decompiler.CSharp.Syntax.AstNode pos)
    {
        // enum storage token=0x0200025C alias=__cil_enum_0200025C underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@NodeType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        goto IL_000A;
        IL_0002: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v0 = pos;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v1 = __cil_callvirt_06001704(v0);
        pos = v1;
        IL_000A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v2 = pos;
        if (v2 is null) {
            goto IL_0016;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v3 = pos;
        int v4 = unchecked((int)(__cil_callvirt_060016F8(v3)));
        if (v4 == 8) {
            goto IL_0002;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v6 = pos;
        if (v6 is null) {
            goto IL_002C;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v7 = pos;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v8 = __cil_callvirt_060016FF(v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Semicolon;
        if (!System.Object.ReferenceEquals(v8, v9)) {
            goto IL_002C;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        __cil_callvirt_060015EC(this);
        IL_002C: ;
        return;
    }

    protected virtual void WriteCommaSeparatedList(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.AstNode> list)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 bytes=15128085011287F4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 l1 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l2 = default;
        IL_0000: ;
        int v0 = 1;
        l0 = __cil_bool_store(v0);
        __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 v1 = list;
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v2 = __cil_callvirt_0A00008A(v1);
        l1 = v2;
        try {
            IL_0009: ;
            goto IL_0028;
            IL_000B: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v3 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v4 = __cil_callvirt_0A000089(v3);
            l2 = v4;
            int v5 = __cil_bool_load(l0);
            if (v5 == 0) {
                goto IL_0019;
            } else {
                goto IL_0015;
            }
            IL_0015: ;
            int v6 = 0;
            l0 = __cil_bool_store(v6);
            goto IL_0021;
            IL_0019: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v7 = this;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v8 = l2;
            int v9 = 0;
            __cil_callvirt_060015DD(v7, v8, __cil_bool_store(v9));
            goto IL_0021;
            IL_0021: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v10 = l2;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
            __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v11)));
            goto IL_0028;
            IL_0028: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v12 = l1;
            int v13 = __cil_bool_load(__cil_callvirt_0A000018(v12));
            if (v13 != 0) {
                goto IL_000B;
            } else {
                goto IL_0030;
            }
            IL_0030: ;
            goto IL_003C;
        }
        finally {
            IL_0032: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v14 = l1;
            if (v14 is null) {
                goto IL_003B;
            } else {
                goto IL_0035;
            }
            IL_0035: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v15 = l1;
            __cil_callvirt_0A000017(v15);
            goto IL_003B;
            IL_003B: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_003C: ;
        return;
    }

    protected virtual void WriteCommaSeparatedListInParenthesis(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.AstNode> list, bool spaceWithin)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015EA(this);
        int v2 = __cil_bool_load(__cil_methodspec_call_2B000256(list));
        if (v2 == 0) {
            goto IL_0023;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int v4 = __cil_bool_load(spaceWithin);
        __cil_callvirt_060015ED(this, __cil_bool_store(v4));
        __cil_callvirt_060015E0(this, list);
        int v8 = __cil_bool_load(spaceWithin);
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        IL_0023: ;
        __cil_callvirt_060015EB(this);
        return;
    }

    protected virtual void WriteCommaSeparatedListInBrackets(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration> list, bool spaceWithin)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5 bytes=1512809101128A5C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v1 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBracket;
        __cil_callvirt_060015E8(this, v1);
        int v3 = __cil_bool_load(__cil_methodspec_call_2B000257(list));
        if (v3 == 0) {
            goto IL_0028;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        int v5 = __cil_bool_load(spaceWithin);
        __cil_callvirt_060015ED(this, __cil_bool_store(v5));
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(list)));
        int v9 = __cil_bool_load(spaceWithin);
        __cil_callvirt_060015ED(this, __cil_bool_store(v9));
        IL_0028: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBracket;
        __cil_callvirt_060015E8(this, v11);
        return;
    }

    protected virtual void WriteCommaSeparatedListInBrackets(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.Expression> list)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7383370672445761e187273ec7fd0f853b78f970 bytes=151280910112886C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v1 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBracket;
        __cil_callvirt_060015E8(this, v1);
        int v3 = __cil_bool_load(__cil_methodspec_call_2B0001B5(list));
        if (v3 == 0) {
            goto IL_003C;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_06001584(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(list)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v12 = this.policy;
        int v13 = __cil_bool_load(__cil_callvirt_06001584(v12));
        __cil_callvirt_060015ED(this, __cil_bool_store(v13));
        IL_003C: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v15 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBracket;
        __cil_callvirt_060015E8(this, v15);
        return;
    }

    protected virtual void WriteKeyword(ICSharpCode.Decompiler.CSharp.Syntax.TokenRole tokenRole)
    {
        string v2 = __cil_callvirt_06001FD3(tokenRole);
        __cil_callvirt_060015E5(this, v2, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(tokenRole)));
        return;
    }

    protected virtual void WriteKeyword(string token, ICSharpCode.Decompiler.CSharp.Syntax.Role tokenRole = null)
    {
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v1 = this.writer;
        __cil_callvirt_060016BD(v1, tokenRole, token);
        this.isAtStartOfLine = __cil_bool_store(0);
        return;
    }

    protected virtual void WriteIdentifier(ICSharpCode.Decompiler.CSharp.Syntax.Identifier identifier)
    {
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v1 = this.writer;
        __cil_callvirt_060016BC(v1, identifier);
        this.isAtStartOfLine = __cil_bool_store(0);
        return;
    }

    protected virtual void WriteIdentifier(string identifier)
    {
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v1 = ICSharpCode.Decompiler.CSharp.Syntax.AstType.Create(identifier);
        __cil_callvirt_06001723(v1, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        this.isAtStartOfLine = __cil_bool_store(0);
        return;
    }

    protected virtual void WriteToken(ICSharpCode.Decompiler.CSharp.Syntax.TokenRole tokenRole)
    {
        string v2 = __cil_callvirt_06001FD3(tokenRole);
        __cil_callvirt_060015E9(this, v2, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(tokenRole)));
        return;
    }

    protected virtual void WriteToken(string token, ICSharpCode.Decompiler.CSharp.Syntax.Role tokenRole)
    {
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v1 = this.writer;
        __cil_callvirt_060016BE(v1, tokenRole, token);
        this.isAtStartOfLine = __cil_bool_store(0);
        return;
    }

    protected virtual void LPar()
    {
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v1 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LPar;
        __cil_callvirt_060015E8(this, v1);
        return;
    }

    protected virtual void RPar()
    {
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v1 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RPar;
        __cil_callvirt_060015E8(this, v1);
        return;
    }

    protected virtual void Semicolon()
    {
        // structural signature __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 bytes=151280CD011287F4: class [System]System.Collections.Generic.Stack`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_87a0aa2898d80a81ae337f03ec800e8d763348a0 bytes=1512897C011289CC: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e04cb2e2935e4ceee97aab9a75229ada19e9e56f bytes=1512897C011287F4: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        ICSharpCode.Decompiler.CSharp.Syntax.Role l0 = default;
        __cil_ref_25a85dcf25a90ee17c389ecb4157a25ef2a57d30 v1 = this.containerStack;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v2 = __cil_callvirt_0A0000D9(v1);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v3 = __cil_callvirt_060016FF(v2);
        l0 = v3;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v4 = l0;
        __cil_ref_87a0aa2898d80a81ae337f03ec800e8d763348a0 v5 = ICSharpCode.Decompiler.CSharp.Syntax.ForStatement.InitializerRole;
        if (System.Object.ReferenceEquals(v4, v5)) {
            goto IL_003A;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v6 = l0;
        __cil_ref_87a0aa2898d80a81ae337f03ec800e8d763348a0 v7 = ICSharpCode.Decompiler.CSharp.Syntax.ForStatement.IteratorRole;
        if (System.Object.ReferenceEquals(v6, v7)) {
            goto IL_003A;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v8 = l0;
        __cil_ref_e04cb2e2935e4ceee97aab9a75229ada19e9e56f v9 = ICSharpCode.Decompiler.CSharp.Syntax.UsingStatement.ResourceAcquisitionRole;
        if (System.Object.ReferenceEquals(v8, v9)) {
            goto IL_003A;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Semicolon;
        __cil_callvirt_060015E8(this, v11);
        __cil_callvirt_060015EE(this);
        IL_003A: ;
        return;
    }

    protected virtual void Space(bool addSpace = true)
    {
        int v0 = __cil_bool_load(addSpace);
        if (v0 == 0) {
            goto IL_000E;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v2 = this.writer;
        __cil_callvirt_060016C1(v2);
        IL_000E: ;
        return;
    }

    protected virtual void NewLine()
    {
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v1 = this.writer;
        __cil_callvirt_060016C4(v1);
        this.isAtStartOfLine = __cil_bool_store(1);
        return;
    }

    protected virtual void OpenBrace(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle style)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(style));
        switch (v0) {
            case 0: {
                goto IL_0027;
            }
            case 1: {
                goto IL_0027;
            }
            case 2: {
                goto IL_0054;
            }
            case 3: {
                goto IL_006E;
            }
            case 4: {
                goto IL_0093;
            }
            case 5: {
                goto IL_00C0;
            }
            case 6: {
                goto IL_0027;
            }
            default: {
                goto IL_0022;
            } }
        IL_0022: ;
        goto IL_00E8;
        IL_0027: ;
        int v2 = __cil_bool_load(this.isAtStartOfLine);
        if (v2 != 0) {
            goto IL_003A;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v4 = this.writer;
        __cil_callvirt_060016C1(v4);
        IL_003A: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v6 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v7 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBrace;
        string v8 = __cil_ldstr_700006A1("{");
        __cil_callvirt_060016BE(v6, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v7)), v8);
        goto IL_00EE;
        IL_0054: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v10 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBrace;
        string v12 = __cil_ldstr_700006A1("{");
        __cil_callvirt_060016BE(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v11)), v12);
        goto IL_00EE;
        IL_006E: ;
        int v14 = __cil_bool_load(this.isAtStartOfLine);
        if (v14 != 0) {
            goto IL_007C;
        } else {
            goto IL_0076;
        }
        IL_0076: ;
        __cil_callvirt_060015EE(this);
        IL_007C: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v17 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v18 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBrace;
        string v19 = __cil_ldstr_700006A1("{");
        __cil_callvirt_060016BE(v17, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v18)), v19);
        goto IL_00EE;
        IL_0093: ;
        __cil_callvirt_060015EE(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v22 = this.writer;
        __cil_callvirt_060016C2(v22);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v24 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v25 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBrace;
        string v26 = __cil_ldstr_700006A1("{");
        __cil_callvirt_060016BE(v24, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v25)), v26);
        __cil_callvirt_060015EE(this);
        return;
        IL_00C0: ;
        __cil_callvirt_060015EE(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v30 = this.writer;
        __cil_callvirt_060016C2(v30);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v32 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v33 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBrace;
        string v34 = __cil_ldstr_700006A1("{");
        __cil_callvirt_060016BE(v32, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v33)), v34);
        goto IL_00EE;
        IL_00E8: ;
        global::System.ArgumentOutOfRangeException v35 = __cil_newobj_0A000157();
        throw v35;
        IL_00EE: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v37 = this.writer;
        __cil_callvirt_060016C2(v37);
        __cil_callvirt_060015EE(this);
        return;
    }

    protected virtual void CloseBrace(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle style)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(style));
        switch (v0) {
            case 0: {
                goto IL_0027;
            }
            case 1: {
                goto IL_0027;
            }
            case 2: {
                goto IL_0027;
            }
            case 3: {
                goto IL_0027;
            }
            case 4: {
                goto IL_004F;
            }
            case 5: {
                goto IL_0077;
            }
            case 6: {
                goto IL_004F;
            }
            default: {
                goto IL_0022;
            } }
        IL_0022: ;
        goto IL_00AA;
        IL_0027: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v2 = this.writer;
        __cil_callvirt_060016C3(v2);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v4 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBrace;
        string v6 = __cil_ldstr_7000400F("}");
        __cil_callvirt_060016BE(v4, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v5)), v6);
        this.isAtStartOfLine = __cil_bool_store(0);
        return;
        IL_004F: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v10 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBrace;
        string v12 = __cil_ldstr_7000400F("}");
        __cil_callvirt_060016BE(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v11)), v12);
        this.isAtStartOfLine = __cil_bool_store(0);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v16 = this.writer;
        __cil_callvirt_060016C3(v16);
        return;
        IL_0077: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v18 = this.writer;
        __cil_callvirt_060016C3(v18);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v20 = this.writer;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v21 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBrace;
        string v22 = __cil_ldstr_7000400F("}");
        __cil_callvirt_060016BE(v20, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v21)), v22);
        this.isAtStartOfLine = __cil_bool_store(0);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v26 = this.writer;
        __cil_callvirt_060016C3(v26);
        return;
        IL_00AA: ;
        global::System.ArgumentOutOfRangeException v27 = __cil_newobj_0A000157();
        throw v27;
    }

    public static bool IsKeyword(string identifier, ICSharpCode.Decompiler.CSharp.Syntax.AstNode context)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 bytes=15128085011287F4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a9681c452d39e51792d931751530365504b4297d bytes=151280F5010E: class [System.Core]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200025B alias=__cil_enum_0200025B underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@Modifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        bool l2 = default;
        IL_0000: ;
        __cil_ref_a9681c452d39e51792d931751530365504b4297d v0 = ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor.unconditionalKeywords;
        string v1 = identifier;
        int v2 = __cil_bool_load(__cil_callvirt_0A0003C8(v0, v1));
        if (v2 == 0) {
            goto IL_000F;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v3 = 1;
        return __cil_bool_store(v3);
        IL_000F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v4 = context;
        __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 v5 = __cil_callvirt_06001709(v4);
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v6 = __cil_callvirt_0A00008A(v5);
        l0 = v6;
        try {
            IL_001B: ;
            goto IL_0099;
            IL_001D: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v7 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v8 = __cil_callvirt_0A000089(v7);
            l1 = v8;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v9 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression v10 = ((object)v9 as ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression);
            if (v10 is null) {
                goto IL_003D;
            } else {
                goto IL_002C;
            }
            IL_002C: ;
            __cil_ref_a9681c452d39e51792d931751530365504b4297d v11 = ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor.queryKeywords;
            string v12 = identifier;
            int v13 = __cil_bool_load(__cil_callvirt_0A0003C8(v11, v12));
            if (v13 == 0) {
                goto IL_003D;
            } else {
                goto IL_0039;
            }
            IL_0039: ;
            int v14 = 1;
            l2 = __cil_bool_store(v14);
            goto IL_00B2;
            IL_003D: ;
            string v15 = identifier;
            string v16 = __cil_ldstr_700052C1("await");
            int v17 = __cil_bool_load(System.String.op_Equality(v15, v16));
            if (v17 == 0) {
                goto IL_0099;
            } else {
                goto IL_004A;
            }
            IL_004A: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v18 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression v19 = ((object)v18 as ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression);
            if (v19 is null) {
                goto IL_0060;
            } else {
                goto IL_0052;
            }
            IL_0052: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v20 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression v21 = ((ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression)(object)v20);
            int v22 = __cil_bool_load(__cil_callvirt_06001A28(v21));
            l2 = __cil_bool_store(v22);
            goto IL_00B2;
            IL_0060: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v23 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression v24 = ((object)v23 as ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression);
            if (v24 is null) {
                goto IL_0076;
            } else {
                goto IL_0068;
            }
            IL_0068: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v25 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression v26 = ((ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression)(object)v25);
            int v27 = __cil_bool_load(__cil_callvirt_06001937(v26));
            l2 = __cil_bool_store(v27);
            goto IL_00B2;
            IL_0076: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v28 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v29 = ((object)v28 as ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration);
            if (v29 is null) {
                goto IL_0099;
            } else {
                goto IL_007E;
            }
            IL_007E: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v30 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v31 = ((ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration)(object)v30);
            int v32 = unchecked((int)(__cil_callvirt_0600200E(v31)));
            int v33 = 65536;
            int v34 = unchecked(v32 & v33);
            int v35 = 65536;
            int v36 = (v34 == v35 ? 1 : 0);
            l2 = __cil_bool_store(v36);
            goto IL_00B2;
            IL_0099: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v37 = l0;
            int v38 = __cil_bool_load(__cil_callvirt_0A000018(v37));
            if (v38 != 0) {
                goto IL_001D;
            } else {
                goto IL_00A4;
            }
            IL_00A4: ;
            goto IL_00B0;
        }
        finally {
            IL_00A6: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v39 = l0;
            if (v39 is null) {
                goto IL_00AF;
            } else {
                goto IL_00A9;
            }
            IL_00A9: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v40 = l0;
            __cil_callvirt_0A000017(v40);
            goto IL_00AF;
            IL_00AF: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00B0: ;
        int v41 = 0;
        return __cil_bool_store(v41);
        IL_00B2: ;
        int v42 = __cil_bool_load(l2);
        return __cil_bool_store(v42);
    }

    protected virtual void WriteTypeArguments(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.AstType> typeArguments)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(__cil_methodspec_call_2B000258(typeArguments));
        if (v1 == 0) {
            goto IL_0025;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LChevron;
        __cil_callvirt_060015E8(this, v3);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(typeArguments)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v7 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RChevron;
        __cil_callvirt_060015E8(this, v7);
        IL_0025: ;
        return;
    }

    public virtual void WriteTypeParameters(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration> typeParameters)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_30a8632852da3c5edefb0e9e64c055e7cbc55304 bytes=1512809101128944: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(__cil_methodspec_call_2B000259(typeParameters));
        if (v1 == 0) {
            goto IL_0025;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LChevron;
        __cil_callvirt_060015E8(this, v3);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(typeParameters)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v7 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RChevron;
        __cil_callvirt_060015E8(this, v7);
        IL_0025: ;
        return;
    }

    protected virtual void WriteModifiers(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken> modifierTokens)
    {
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_00b02ccb253eeaeb584ba6c47ed9999fd5fbed56 bytes=1512808501128808: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_00b02ccb253eeaeb584ba6c47ed9999fd5fbed56 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken l1 = default;
        IL_0000: ;
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v0 = modifierTokens;
        __cil_ref_00b02ccb253eeaeb584ba6c47ed9999fd5fbed56 v1 = __cil_callvirt_0A0009D5(v0);
        l0 = v1;
        try {
            IL_0007: ;
            goto IL_0017;
            IL_0009: ;
            __cil_ref_00b02ccb253eeaeb584ba6c47ed9999fd5fbed56 v2 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken v3 = __cil_callvirt_0A0009D6(v2);
            l1 = v3;
            global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken v4 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
            __cil_callvirt_06001723(v4, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v5)));
            goto IL_0017;
            IL_0017: ;
            __cil_ref_00b02ccb253eeaeb584ba6c47ed9999fd5fbed56 v6 = l0;
            int v7 = __cil_bool_load(__cil_callvirt_0A000018(v6));
            if (v7 != 0) {
                goto IL_0009;
            } else {
                goto IL_001F;
            }
            IL_001F: ;
            goto IL_002B;
        }
        finally {
            IL_0021: ;
            __cil_ref_00b02ccb253eeaeb584ba6c47ed9999fd5fbed56 v8 = l0;
            if (v8 is null) {
                goto IL_002A;
            } else {
                goto IL_0024;
            }
            IL_0024: ;
            __cil_ref_00b02ccb253eeaeb584ba6c47ed9999fd5fbed56 v9 = l0;
            __cil_callvirt_0A000017(v9);
            goto IL_002A;
            IL_002A: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_002B: ;
        return;
    }

    protected virtual void WriteQualifiedIdentifier(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.Identifier> identifiers)
    {
        // structural signature __cil_ref_6a14aef97b3bdd33c8003d949d636ce351c5d988 bytes=1512809101128960: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Identifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_01d7d984886635bfe7ba3faaabc2ba43e756b7fb bytes=1512808501128960: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.Identifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        __cil_ref_01d7d984886635bfe7ba3faaabc2ba43e756b7fb l1 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.Identifier l2 = default;
        IL_0000: ;
        int v0 = 1;
        l0 = __cil_bool_store(v0);
        __cil_ref_6a14aef97b3bdd33c8003d949d636ce351c5d988 v1 = identifiers;
        __cil_ref_01d7d984886635bfe7ba3faaabc2ba43e756b7fb v2 = __cil_callvirt_0A0008B7(v1);
        l1 = v2;
        try {
            IL_0009: ;
            goto IL_003A;
            IL_000B: ;
            __cil_ref_01d7d984886635bfe7ba3faaabc2ba43e756b7fb v3 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v4 = __cil_callvirt_0A0008B8(v3);
            l2 = v4;
            int v5 = __cil_bool_load(l0);
            if (v5 == 0) {
                goto IL_0019;
            } else {
                goto IL_0015;
            }
            IL_0015: ;
            int v6 = 0;
            l0 = __cil_bool_store(v6);
            goto IL_002E;
            IL_0019: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v7 = this;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v8 = v7.writer;
            global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Dot;
            string v10 = __cil_ldstr_70001419(".");
            __cil_callvirt_060016BE(v8, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v9)), v10);
            goto IL_002E;
            IL_002E: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v12 = v11.writer;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v13 = l2;
            __cil_callvirt_060016BC(v12, v13);
            goto IL_003A;
            IL_003A: ;
            __cil_ref_01d7d984886635bfe7ba3faaabc2ba43e756b7fb v14 = l1;
            int v15 = __cil_bool_load(__cil_callvirt_0A000018(v14));
            if (v15 != 0) {
                goto IL_000B;
            } else {
                goto IL_0042;
            }
            IL_0042: ;
            goto IL_004E;
        }
        finally {
            IL_0044: ;
            __cil_ref_01d7d984886635bfe7ba3faaabc2ba43e756b7fb v16 = l1;
            if (v16 is null) {
                goto IL_004D;
            } else {
                goto IL_0047;
            }
            IL_0047: ;
            __cil_ref_01d7d984886635bfe7ba3faaabc2ba43e756b7fb v17 = l1;
            __cil_callvirt_0A000017(v17);
            goto IL_004D;
            IL_004D: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_004E: ;
        return;
    }

    protected virtual void WriteEmbeddedStatement(ICSharpCode.Decompiler.CSharp.Syntax.Statement embeddedStatement, ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement nlp = 1)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement l0 = default;
        int v1 = __cil_bool_load(__cil_callvirt_060016F9(embeddedStatement));
        if (v1 == 0) {
            goto IL_000F;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        __cil_callvirt_060015EE(this);
        return;
        IL_000F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v4 = ((object)embeddedStatement as ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement);
        l0 = v4;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v5 = l0;
        if (v5 is null) {
            goto IL_003E;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v7 = l0;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v9 = this.policy;
        int v10 = unchecked((int)(__cil_callvirt_060014DE(v9)));
        __cil_callvirt_06001635(this, v7, unchecked((__cil_enum_020001EC)(v10)));
        int v11 = unchecked((int)(nlp));
        if (unchecked((uint)v11) != unchecked((uint)2)) {
            goto IL_0037;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        return;
        IL_0037: ;
        __cil_callvirt_060015EE(this);
        return;
        IL_003E: ;
        __cil_callvirt_060015EE(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v18 = this.writer;
        __cil_callvirt_060016C2(v18);
        __cil_callvirt_06001723(embeddedStatement, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v22 = this.writer;
        __cil_callvirt_060016C3(v22);
        return;
    }

    protected virtual void WriteMethodBody(ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement body, ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle style)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = __cil_bool_load(__cil_callvirt_060016F9(body));
        if (v1 == 0) {
            goto IL_000F;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        __cil_callvirt_060015EC(this);
        return;
        IL_000F: ;
        int v5 = unchecked((int)(style));
        __cil_callvirt_06001635(this, body, unchecked((__cil_enum_020001EC)(v5)));
        __cil_callvirt_060015EE(this);
        return;
    }

    protected virtual void WriteAttributes(System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection> attributes)
    {
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c738bacaa6e3f7fd717b0cf747b44da2811dea2a bytes=1512808501128908: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_c738bacaa6e3f7fd717b0cf747b44da2811dea2a l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection l1 = default;
        IL_0000: ;
        __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 v0 = attributes;
        __cil_ref_c738bacaa6e3f7fd717b0cf747b44da2811dea2a v1 = __cil_callvirt_0A000885(v0);
        l0 = v1;
        try {
            IL_0007: ;
            goto IL_0017;
            IL_0009: ;
            __cil_ref_c738bacaa6e3f7fd717b0cf747b44da2811dea2a v2 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection v3 = __cil_callvirt_0A0007DB(v2);
            l1 = v3;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection v4 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
            __cil_callvirt_06001723(v4, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v5)));
            goto IL_0017;
            IL_0017: ;
            __cil_ref_c738bacaa6e3f7fd717b0cf747b44da2811dea2a v6 = l0;
            int v7 = __cil_bool_load(__cil_callvirt_0A000018(v6));
            if (v7 != 0) {
                goto IL_0009;
            } else {
                goto IL_001F;
            }
            IL_001F: ;
            goto IL_002B;
        }
        finally {
            IL_0021: ;
            __cil_ref_c738bacaa6e3f7fd717b0cf747b44da2811dea2a v8 = l0;
            if (v8 is null) {
                goto IL_002A;
            } else {
                goto IL_0024;
            }
            IL_0024: ;
            __cil_ref_c738bacaa6e3f7fd717b0cf747b44da2811dea2a v9 = l0;
            __cil_callvirt_0A000017(v9);
            goto IL_002A;
            IL_002A: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_002B: ;
        return;
    }

    protected virtual void WritePrivateImplementationType(ICSharpCode.Decompiler.CSharp.Syntax.AstType privateImplementationType)
    {
        int v1 = __cil_bool_load(__cil_callvirt_060016F9(privateImplementationType));
        if (v1 != 0) {
            goto IL_001A;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        __cil_callvirt_06001723(privateImplementationType, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Dot;
        __cil_callvirt_060015E8(this, v5);
        IL_001A: ;
        return;
    }

    public virtual void VisitAnonymousMethodExpression(ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression anonymousMethodExpression)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(anonymousMethodExpression)));
        int v3 = __cil_bool_load(__cil_callvirt_06001937(anonymousMethodExpression));
        if (v3 == 0) {
            goto IL_0021;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression.AsyncModifierRole;
        __cil_callvirt_060015E4(this, v5);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        IL_0021: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression.DelegateKeywordRole;
        __cil_callvirt_060015E4(this, v9);
        int v11 = __cil_bool_load(__cil_callvirt_06001939(anonymousMethodExpression));
        if (v11 == 0) {
            goto IL_005C;
        } else {
            goto IL_0034;
        }
        IL_0034: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_060014F0(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v18 = __cil_callvirt_0600193D(anonymousMethodExpression);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v20 = this.policy;
        int v21 = __cil_bool_load(__cil_callvirt_060014F8(v20));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v18)), __cil_bool_store(v21));
        IL_005C: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v24 = __cil_callvirt_0600193F(anonymousMethodExpression);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = this.policy;
        int v27 = unchecked((int)(__cil_callvirt_060014C4(v26)));
        __cil_callvirt_06001635(this, v24, unchecked((__cil_enum_020001EC)(v27)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(anonymousMethodExpression)));
        return;
    }

    public virtual void VisitUndocumentedExpression(ICSharpCode.Decompiler.CSharp.Syntax.UndocumentedExpression undocumentedExpression)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200023F alias=__cil_enum_0200023F underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@UndocumentedExpressionType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200023F l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(undocumentedExpression)));
        int v3 = unchecked((int)(__cil_callvirt_06001B88(undocumentedExpression)));
        l0 = unchecked((__cil_enum_0200023F)(v3));
        int v4 = unchecked((int)(l0));
        switch (v4) {
            case 0: {
                goto IL_002A;
            }
            case 1: {
                goto IL_002A;
            }
            case 2: {
                goto IL_0051;
            }
            case 3: {
                goto IL_0044;
            }
            case 4: {
                goto IL_0037;
            }
            default: {
                goto IL_0028;
            } }
        IL_0028: ;
        goto IL_005C;
        IL_002A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v6 = ICSharpCode.Decompiler.CSharp.Syntax.UndocumentedExpression.ArglistKeywordRole;
        __cil_callvirt_060015E4(this, v6);
        goto IL_005C;
        IL_0037: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v8 = ICSharpCode.Decompiler.CSharp.Syntax.UndocumentedExpression.MakerefKeywordRole;
        __cil_callvirt_060015E4(this, v8);
        goto IL_005C;
        IL_0044: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v10 = ICSharpCode.Decompiler.CSharp.Syntax.UndocumentedExpression.ReftypeKeywordRole;
        __cil_callvirt_060015E4(this, v10);
        goto IL_005C;
        IL_0051: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.UndocumentedExpression.RefvalueKeywordRole;
        __cil_callvirt_060015E4(this, v12);
        IL_005C: ;
        int v14 = unchecked((int)(__cil_callvirt_06001B88(undocumentedExpression)));
        if (v14 == 0) {
            goto IL_008C;
        } else {
            goto IL_0064;
        }
        IL_0064: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v17 = this.policy;
        int v18 = __cil_bool_load(__cil_callvirt_060014FA(v17));
        __cil_callvirt_060015ED(this, __cil_bool_store(v18));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v21 = __cil_callvirt_06001B8C(undocumentedExpression);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v23 = this.policy;
        int v24 = __cil_bool_load(__cil_callvirt_06001502(v23));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v21)), __cil_bool_store(v24));
        IL_008C: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(undocumentedExpression)));
        return;
    }

    public virtual void VisitArrayCreateExpression(ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression arrayCreateExpression)
    {
        // structural signature __cil_ref_7383370672445761e187273ec7fd0f853b78f970 bytes=151280910112886C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 bytes=1512808501128804: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_62a86242d2772388ef825cc380712b963af99f57 bytes=151287F801128804: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression v1 = arrayCreateExpression;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression.NewKeywordRole;
        __cil_callvirt_060015E4(v2, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression v4 = arrayCreateExpression;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001956(v4);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v6 = this;
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v6)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression v7 = arrayCreateExpression;
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v8 = __cil_callvirt_06001958(v7);
        int v9 = v8.get_Count();
        int v10 = 0;
        if (v9 <= v10) {
            goto IL_0038;
        } else {
            goto IL_002C;
        }
        IL_002C: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression v12 = arrayCreateExpression;
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v13 = __cil_callvirt_06001958(v12);
        __cil_callvirt_060015E3(v11, ((__cil_ref_7383370672445761e187273ec7fd0f853b78f970)(v13)));
        goto IL_0038;
        IL_0038: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression v14 = arrayCreateExpression;
        __cil_ref_62a86242d2772388ef825cc380712b963af99f57 v15 = __cil_callvirt_06001959(v14);
        __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v16 = v15.GetEnumerator();
        l0 = v16;
        try {
            IL_0044: ;
            goto IL_0054;
            IL_0046: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v17 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier v18 = __cil_callvirt_0A0009D8(v17);
            l1 = v18;
            global::ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier v19 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v20 = this;
            __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v20)));
            goto IL_0054;
            IL_0054: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v21 = l0;
            int v22 = __cil_bool_load(__cil_callvirt_0A000018(v21));
            if (v22 != 0) {
                goto IL_0046;
            } else {
                goto IL_005C;
            }
            IL_005C: ;
            goto IL_0068;
        }
        finally {
            IL_005E: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v23 = l0;
            if (v23 is null) {
                goto IL_0067;
            } else {
                goto IL_0061;
            }
            IL_0061: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v24 = l0;
            __cil_callvirt_0A000017(v24);
            goto IL_0067;
            IL_0067: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0068: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression v25 = arrayCreateExpression;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression v26 = __cil_callvirt_0600195A(v25);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v27 = this;
        __cil_callvirt_06001723(v26, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v27)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression v29 = arrayCreateExpression;
        __cil_callvirt_060015DC(v28, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v29)));
        return;
    }

    public virtual void VisitArrayInitializerExpression(ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression arrayInitializerExpression)
    {
        // structural signature __cil_ref_7383370672445761e187273ec7fd0f853b78f970 bytes=151280910112886C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        int s4_0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(arrayInitializerExpression)));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v3 = __cil_callvirt_06001967(arrayInitializerExpression);
        int v4 = v3.get_Count();
        if (unchecked((uint)v4) != unchecked((uint)1)) {
            goto IL_0039;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v8 = __cil_callvirt_060016FE(arrayInitializerExpression);
        int v9 = __cil_bool_load(__cil_direct_060015FF(this, v8));
        if (v9 == 0) {
            goto IL_0039;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v12 = __cil_callvirt_06001967(arrayInitializerExpression);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v13 = __cil_methodspec_call_2B0001AD(((__cil_ref_7383370672445761e187273ec7fd0f853b78f970)(v12)));
        int v14 = __cil_bool_load(__cil_direct_060015FE(this, v13));
        int v16 = (v14 == 0 ? 1 : 0);
        int e2_4_0 = v16;
        s4_0 = e2_4_0;
        goto IL_003A;
        IL_0039: ;
        int e3_4_0 = 0;
        s4_0 = e3_4_0;
        IL_003A: ;
        l0 = __cil_bool_store(s4_0);
        int v18 = __cil_bool_load(l0);
        if (v18 == 0) {
            goto IL_005E;
        } else {
            goto IL_003E;
        }
        IL_003E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode v20 = __cil_callvirt_06001966(arrayInitializerExpression);
        int v21 = __cil_bool_load(__cil_callvirt_060016F9(v20));
        if (v21 == 0) {
            goto IL_005E;
        } else {
            goto IL_004B;
        }
        IL_004B: ;
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v23 = __cil_callvirt_06001967(arrayInitializerExpression);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v24 = __cil_methodspec_call_2B0001AD(((__cil_ref_7383370672445761e187273ec7fd0f853b78f970)(v23)));
        __cil_callvirt_06001723(v24, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        goto IL_006A;
        IL_005E: ;
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v28 = __cil_callvirt_06001967(arrayInitializerExpression);
        __cil_callvirt_06001600(this, v28);
        IL_006A: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(arrayInitializerExpression)));
        return;
    }

    protected bool CanBeConfusedWithObjectInitializer(ICSharpCode.Decompiler.CSharp.Syntax.Expression expr)
    {
        // enum storage token=0x02000210 alias=__cil_enum_02000210 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@AssignmentOperatorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression l0 = default;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression v1 = ((object)expr as ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression);
        l0 = v1;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression v3 = l0;
        int v4 = unchecked((int)(__cil_callvirt_0600197F(v3)));
        return (v4 == 0);
    }

    protected bool IsObjectOrCollectionInitializer(ICSharpCode.Decompiler.CSharp.Syntax.AstNode node)
    {
        // structural signature __cil_ref_7640d5b201338383ca7e919c7317b51c2e0fbe94 bytes=1512897C01128834: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_952f0b4e18f420f3cbfdd1770a49dc2133f536ef bytes=1512897C0112886C: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression v1 = ((object)node as ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression);
        if (!(v1 is not null)) {
            return false;
        }
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v4 = __cil_callvirt_060016FE(node);
        global::ICSharpCode.Decompiler.CSharp.Syntax.ObjectCreateExpression v5 = ((object)v4 as ICSharpCode.Decompiler.CSharp.Syntax.ObjectCreateExpression);
        if (v5 is null) {
            goto IL_0025;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v7 = __cil_callvirt_060016FF(node);
        __cil_ref_7640d5b201338383ca7e919c7317b51c2e0fbe94 v8 = ICSharpCode.Decompiler.CSharp.Syntax.ObjectCreateExpression.InitializerRole;
        return (System.Object.ReferenceEquals(v7, v8));
        IL_0025: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v11 = __cil_callvirt_060016FE(node);
        global::ICSharpCode.Decompiler.CSharp.Syntax.NamedExpression v12 = ((object)v11 as ICSharpCode.Decompiler.CSharp.Syntax.NamedExpression);
        if (v12 is null) {
            return false;
        } else {
            goto IL_0032;
        }
        IL_0032: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v14 = __cil_callvirt_060016FF(node);
        __cil_ref_952f0b4e18f420f3cbfdd1770a49dc2133f536ef v15 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Expression;
        return (System.Object.ReferenceEquals(v14, v15));
    }

    protected virtual void PrintInitializerElements(ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection<ICSharpCode.Decompiler.CSharp.Syntax.Expression> elements)
    {
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3f0afa92b2eaf1dba81f908cf044631cce4de2a8 bytes=151280850112886C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020001EC l0 = default;
        bool l1 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l2 = default;
        __cil_ref_3f0afa92b2eaf1dba81f908cf044631cce4de2a8 l3 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l4 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v1 = v0.policy;
        int v2 = unchecked((int)(__cil_callvirt_060015AE(v1)));
        int v3 = 2;
        if (unchecked((uint)v2) != unchecked((uint)v3)) {
            goto IL_0012;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        int v4 = 3;
        l0 = unchecked((__cil_enum_020001EC)(v4));
        goto IL_0014;
        IL_0012: ;
        int v5 = 1;
        l0 = unchecked((__cil_enum_020001EC)(v5));
        goto IL_0014;
        IL_0014: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v6 = this;
        int v7 = unchecked((int)(l0));
        __cil_callvirt_060015EF(v6, unchecked((__cil_enum_020001EC)(v7)));
        int v8 = 1;
        l1 = __cil_bool_store(v8);
        l2 = null;
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v9 = elements;
        __cil_ref_3f0afa92b2eaf1dba81f908cf044631cce4de2a8 v10 = v9.GetEnumerator();
        l3 = v10;
        try {
            IL_0026: ;
            goto IL_0051;
            IL_0028: ;
            __cil_ref_3f0afa92b2eaf1dba81f908cf044631cce4de2a8 v11 = l3;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v12 = __cil_callvirt_0A0009DA(v11);
            l4 = v12;
            int v13 = __cil_bool_load(l1);
            if (v13 == 0) {
                goto IL_0037;
            } else {
                goto IL_0033;
            }
            IL_0033: ;
            int v14 = 0;
            l1 = __cil_bool_store(v14);
            goto IL_0046;
            IL_0037: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v16 = l4;
            int v17 = 1;
            __cil_callvirt_060015DD(v15, v16, __cil_bool_store(v17));
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v18 = this;
            __cil_callvirt_060015EE(v18);
            goto IL_0046;
            IL_0046: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v19 = l4;
            l2 = v19;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v20 = l4;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v21 = this;
            __cil_callvirt_06001723(v20, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v21)));
            goto IL_0051;
            IL_0051: ;
            __cil_ref_3f0afa92b2eaf1dba81f908cf044631cce4de2a8 v22 = l3;
            int v23 = __cil_bool_load(__cil_callvirt_0A000018(v22));
            if (v23 != 0) {
                goto IL_0028;
            } else {
                goto IL_0059;
            }
            IL_0059: ;
            goto IL_0065;
        }
        finally {
            IL_005B: ;
            __cil_ref_3f0afa92b2eaf1dba81f908cf044631cce4de2a8 v24 = l3;
            if (v24 is null) {
                goto IL_0064;
            } else {
                goto IL_005E;
            }
            IL_005E: ;
            __cil_ref_3f0afa92b2eaf1dba81f908cf044631cce4de2a8 v25 = l3;
            __cil_callvirt_0A000017(v25);
            goto IL_0064;
            IL_0064: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0065: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v26 = l2;
        if (v26 is null) {
            goto IL_0074;
        } else {
            goto IL_0068;
        }
        IL_0068: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v27 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v28 = l2;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v29 = __cil_callvirt_06001703(v28);
        __cil_callvirt_060015DE(v27, v29);
        goto IL_0074;
        IL_0074: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v30 = this;
        __cil_callvirt_060015EE(v30);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v31 = this;
        int v32 = unchecked((int)(l0));
        __cil_callvirt_060015F0(v31, unchecked((__cil_enum_020001EC)(v32)));
        return;
    }

    public virtual void VisitAsExpression(ICSharpCode.Decompiler.CSharp.Syntax.AsExpression asExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(asExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001970(asExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v8 = ICSharpCode.Decompiler.CSharp.Syntax.AsExpression.AsKeywordRole;
        __cil_callvirt_060015E4(this, v8);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v12 = __cil_callvirt_06001973(asExpression);
        __cil_callvirt_06001723(v12, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(asExpression)));
        return;
    }

    public virtual void VisitAssignmentExpression(ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression assignmentExpression)
    {
        // enum storage token=0x02000210 alias=__cil_enum_02000210 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@AssignmentOperatorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(assignmentExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001981(assignmentExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_0600153E(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        int v11 = unchecked((int)(__cil_callvirt_0600197F(assignmentExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression.GetOperatorRole(unchecked((__cil_enum_02000210)(v11)));
        __cil_callvirt_060015E8(this, v12);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v15 = this.policy;
        int v16 = __cil_bool_load(__cil_callvirt_0600153E(v15));
        __cil_callvirt_060015ED(this, __cil_bool_store(v16));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v18 = __cil_callvirt_06001984(assignmentExpression);
        __cil_callvirt_06001723(v18, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(assignmentExpression)));
        return;
    }

    public virtual void VisitBaseReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.BaseReferenceExpression baseReferenceExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(baseReferenceExpression)));
        string v3 = __cil_ldstr_70008730("base");
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v5 = __cil_callvirt_060016FF(baseReferenceExpression);
        __cil_callvirt_060015E5(this, v3, v5);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(baseReferenceExpression)));
        return;
    }

    public virtual void VisitBinaryOperatorExpression(ICSharpCode.Decompiler.CSharp.Syntax.BinaryOperatorExpression binaryOperatorExpression)
    {
        // enum storage token=0x02000213 alias=__cil_enum_02000213 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@BinaryOperatorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        bool l0 = default;
        __cil_enum_02000213 l1 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(binaryOperatorExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_0600199B(binaryOperatorExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        int v6 = unchecked((int)(__cil_callvirt_06001999(binaryOperatorExpression)));
        l1 = unchecked((__cil_enum_02000213)(v6));
        int v7 = unchecked((int)(l1));
        int v9 = unchecked(v7 - 1);
        switch (v9) {
            case 0: {
                goto IL_0070;
            }
            case 1: {
                goto IL_0070;
            }
            case 2: {
                goto IL_007E;
            }
            case 3: {
                goto IL_007E;
            }
            case 4: {
                goto IL_0070;
            }
            case 5: {
                goto IL_008C;
            }
            case 6: {
                goto IL_008C;
            }
            case 7: {
                goto IL_009A;
            }
            case 8: {
                goto IL_009A;
            }
            case 9: {
                goto IL_008C;
            }
            case 10: {
                goto IL_008C;
            }
            case 11: {
                goto IL_00A8;
            }
            case 12: {
                goto IL_00A8;
            }
            case 13: {
                goto IL_00B6;
            }
            case 14: {
                goto IL_00B6;
            }
            case 15: {
                goto IL_00B6;
            }
            case 16: {
                goto IL_00C4;
            }
            case 17: {
                goto IL_00C4;
            }
            case 18: {
                goto IL_00D2;
            }
            default: {
                goto IL_006E;
            } }
        IL_006E: ;
        goto IL_00D6;
        IL_0070: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_06001546(v11));
        l0 = __cil_bool_store(v12);
        goto IL_00E1;
        IL_007E: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_06001540(v14));
        l0 = __cil_bool_store(v15);
        goto IL_00E1;
        IL_008C: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v17 = this.policy;
        int v18 = __cil_bool_load(__cil_callvirt_06001544(v17));
        l0 = __cil_bool_store(v18);
        goto IL_00E1;
        IL_009A: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v20 = this.policy;
        int v21 = __cil_bool_load(__cil_callvirt_06001542(v20));
        l0 = __cil_bool_store(v21);
        goto IL_00E1;
        IL_00A8: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v23 = this.policy;
        int v24 = __cil_bool_load(__cil_callvirt_06001548(v23));
        l0 = __cil_bool_store(v24);
        goto IL_00E1;
        IL_00B6: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = this.policy;
        int v27 = __cil_bool_load(__cil_callvirt_0600154A(v26));
        l0 = __cil_bool_store(v27);
        goto IL_00E1;
        IL_00C4: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v29 = this.policy;
        int v30 = __cil_bool_load(__cil_callvirt_0600154C(v29));
        l0 = __cil_bool_store(v30);
        goto IL_00E1;
        IL_00D2: ;
        l0 = __cil_bool_store(1);
        goto IL_00E1;
        IL_00D6: ;
        string v32 = __cil_ldstr_7000873A("Invalid value for BinaryOperatorType");
        global::System.NotSupportedException v33 = __cil_newobj_0A000139(v32);
        throw v33;
        IL_00E1: ;
        int v35 = __cil_bool_load(l0);
        __cil_callvirt_060015ED(this, __cil_bool_store(v35));
        int v38 = unchecked((int)(__cil_callvirt_06001999(binaryOperatorExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v39 = ICSharpCode.Decompiler.CSharp.Syntax.BinaryOperatorExpression.GetOperatorRole(unchecked((__cil_enum_02000213)(v38)));
        __cil_callvirt_060015E8(this, v39);
        int v41 = __cil_bool_load(l0);
        __cil_callvirt_060015ED(this, __cil_bool_store(v41));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v43 = __cil_callvirt_0600199E(binaryOperatorExpression);
        __cil_callvirt_06001723(v43, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(binaryOperatorExpression)));
        return;
    }

    public virtual void VisitCastExpression(ICSharpCode.Decompiler.CSharp.Syntax.CastExpression castExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(castExpression)));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v5 = this.policy;
        int v6 = __cil_bool_load(__cil_callvirt_06001568(v5));
        __cil_callvirt_060015ED(this, __cil_bool_store(v6));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v8 = __cil_callvirt_060019A8(castExpression);
        __cil_callvirt_06001723(v8, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v12 = this.policy;
        int v13 = __cil_bool_load(__cil_callvirt_06001568(v12));
        __cil_callvirt_060015ED(this, __cil_bool_store(v13));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v17 = this.policy;
        int v18 = __cil_bool_load(__cil_callvirt_06001590(v17));
        __cil_callvirt_060015ED(this, __cil_bool_store(v18));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v20 = __cil_callvirt_060019AB(castExpression);
        __cil_callvirt_06001723(v20, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(castExpression)));
        return;
    }

    public virtual void VisitCheckedExpression(ICSharpCode.Decompiler.CSharp.Syntax.CheckedExpression checkedExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(checkedExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.CheckedExpression.CheckedKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_0600157A(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v10 = __cil_callvirt_060019B5(checkedExpression);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_0600157A(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_callvirt_060015EB(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(checkedExpression)));
        return;
    }

    public virtual void VisitConditionalExpression(ICSharpCode.Decompiler.CSharp.Syntax.ConditionalExpression conditionalExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(conditionalExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_060019BF(conditionalExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_0600157C(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v10 = ICSharpCode.Decompiler.CSharp.Syntax.ConditionalExpression.QuestionMarkRole;
        __cil_callvirt_060015E8(this, v10);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v13 = this.policy;
        int v14 = __cil_bool_load(__cil_callvirt_0600157E(v13));
        __cil_callvirt_060015ED(this, __cil_bool_store(v14));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v16 = __cil_callvirt_060019C2(conditionalExpression);
        __cil_callvirt_06001723(v16, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v20 = this.policy;
        int v21 = __cil_bool_load(__cil_callvirt_06001580(v20));
        __cil_callvirt_060015ED(this, __cil_bool_store(v21));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v23 = ICSharpCode.Decompiler.CSharp.Syntax.ConditionalExpression.ColonRole;
        __cil_callvirt_060015E8(this, v23);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = this.policy;
        int v27 = __cil_bool_load(__cil_callvirt_06001582(v26));
        __cil_callvirt_060015ED(this, __cil_bool_store(v27));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v29 = __cil_callvirt_060019C5(conditionalExpression);
        __cil_callvirt_06001723(v29, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(conditionalExpression)));
        return;
    }

    public virtual void VisitDefaultValueExpression(ICSharpCode.Decompiler.CSharp.Syntax.DefaultValueExpression defaultValueExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(defaultValueExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.DefaultValueExpression.DefaultKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_0600156E(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v10 = __cil_callvirt_060019D0(defaultValueExpression);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_0600156E(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_callvirt_060015EB(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(defaultValueExpression)));
        return;
    }

    public virtual void VisitDirectionExpression(ICSharpCode.Decompiler.CSharp.Syntax.DirectionExpression directionExpression)
    {
        // enum storage token=0x02000218 alias=__cil_enum_02000218 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@FieldDirection; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000218 l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(directionExpression)));
        int v3 = unchecked((int)(__cil_callvirt_060019DA(directionExpression)));
        l0 = unchecked((__cil_enum_02000218)(v3));
        int v4 = unchecked((int)(l0));
        if (v4 == 1) {
            goto IL_0018;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        int v6 = unchecked((int)(l0));
        if (v6 == 2) {
            goto IL_0025;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        goto IL_0032;
        IL_0018: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.DirectionExpression.OutKeywordRole;
        __cil_callvirt_060015E4(this, v9);
        goto IL_003D;
        IL_0025: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.DirectionExpression.RefKeywordRole;
        __cil_callvirt_060015E4(this, v11);
        goto IL_003D;
        IL_0032: ;
        string v12 = __cil_ldstr_70008784("Invalid value for FieldDirection");
        global::System.NotSupportedException v13 = __cil_newobj_0A000139(v12);
        throw v13;
        IL_003D: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v17 = __cil_callvirt_060019DD(directionExpression);
        __cil_callvirt_06001723(v17, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(directionExpression)));
        return;
    }

    public virtual void VisitOutVarDeclarationExpression(ICSharpCode.Decompiler.CSharp.Syntax.OutVarDeclarationExpression outVarDeclarationExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(outVarDeclarationExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.OutVarDeclarationExpression.OutKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v7 = __cil_callvirt_06001A7B(outVarDeclarationExpression);
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v12 = __cil_callvirt_06001A7D(outVarDeclarationExpression);
        __cil_callvirt_06001723(v12, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(outVarDeclarationExpression)));
        return;
    }

    public virtual void VisitIdentifierExpression(ICSharpCode.Decompiler.CSharp.Syntax.IdentifierExpression identifierExpression)
    {
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(identifierExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v4 = __cil_callvirt_060019FD(identifierExpression);
        __cil_callvirt_060015E6(this, v4);
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v7 = __cil_callvirt_060019FF(identifierExpression);
        __cil_callvirt_060015F2(this, ((__cil_ref_3681fa81e970b76123c0932848c13919b7088424)(v7)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(identifierExpression)));
        return;
    }

    public virtual void VisitIndexerExpression(ICSharpCode.Decompiler.CSharp.Syntax.IndexerExpression indexerExpression)
    {
        // structural signature __cil_ref_7383370672445761e187273ec7fd0f853b78f970 bytes=151280910112886C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(indexerExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001A04(indexerExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_060014FA(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v11 = __cil_callvirt_06001A07(indexerExpression);
        __cil_callvirt_060015E3(this, ((__cil_ref_7383370672445761e187273ec7fd0f853b78f970)(v11)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(indexerExpression)));
        return;
    }

    public virtual void VisitInvocationExpression(ICSharpCode.Decompiler.CSharp.Syntax.InvocationExpression invocationExpression)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(invocationExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001A10(invocationExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_060014FA(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v11 = __cil_callvirt_06001A13(invocationExpression);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v13 = this.policy;
        int v14 = __cil_bool_load(__cil_callvirt_06001502(v13));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v11)), __cil_bool_store(v14));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(invocationExpression)));
        return;
    }

    public virtual void VisitIsExpression(ICSharpCode.Decompiler.CSharp.Syntax.IsExpression isExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(isExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001A1C(isExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v8 = ICSharpCode.Decompiler.CSharp.Syntax.IsExpression.IsKeywordRole;
        __cil_callvirt_060015E4(this, v8);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v10 = __cil_callvirt_06001A1F(isExpression);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(isExpression)));
        return;
    }

    public virtual void VisitLambdaExpression(ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression lambdaExpression)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5 bytes=1512809101128A5C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(lambdaExpression)));
        int v3 = __cil_bool_load(__cil_callvirt_06001A28(lambdaExpression));
        if (v3 == 0) {
            goto IL_0021;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression.AsyncModifierRole;
        __cil_callvirt_060015E4(this, v5);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        IL_0021: ;
        int v10 = __cil_bool_load(__cil_direct_06001610(this, lambdaExpression));
        if (v10 == 0) {
            goto IL_0043;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v13 = __cil_callvirt_06001A2B(lambdaExpression);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v15 = this.policy;
        int v16 = __cil_bool_load(__cil_callvirt_060014F8(v15));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v13)), __cil_bool_store(v16));
        goto IL_0054;
        IL_0043: ;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v18 = __cil_callvirt_06001A2B(lambdaExpression);
        global::ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration v19 = __cil_methodspec_call_2B0001BD(((__cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5)(v18)));
        __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_0054: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v24 = ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression.ArrowRole;
        __cil_callvirt_060015E8(this, v24);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v26 = __cil_callvirt_06001A2E(lambdaExpression);
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v27 = ((object)v26 as ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement);
        if (v27 is null) {
            goto IL_0091;
        } else {
            goto IL_0073;
        }
        IL_0073: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v30 = __cil_callvirt_06001A2E(lambdaExpression);
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v31 = ((ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement)(object)v30);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v33 = this.policy;
        int v34 = unchecked((int)(__cil_callvirt_060014C4(v33)));
        __cil_callvirt_06001635(this, v31, unchecked((__cil_enum_020001EC)(v34)));
        goto IL_00A4;
        IL_0091: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v38 = __cil_callvirt_06001A2E(lambdaExpression);
        __cil_callvirt_06001723(v38, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_00A4: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(lambdaExpression)));
        return;
    }

    protected bool LambdaNeedsParenthesis(ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression lambdaExpression)
    {
        // structural signature __cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5 bytes=1512809101128A5C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000296 alias=__cil_enum_02000296 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@ParameterModifier; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration l0 = default;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v1 = __cil_callvirt_06001A2B(lambdaExpression);
        int v2 = v1.get_Count();
        if (!(v2 == 1)) {
            return true;
        }
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v6 = __cil_callvirt_06001A2B(lambdaExpression);
        global::ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration v7 = __cil_methodspec_call_2B0001BD(((__cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5)(v6)));
        l0 = v7;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration v8 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v9 = __cil_callvirt_060020AA(v8);
        int v10 = __cil_bool_load(__cil_callvirt_060016F9(v9));
        if (v10 == 0) {
            return true;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration v11 = l0;
        int v12 = unchecked((int)(__cil_callvirt_060020A8(v11)));
        return (unchecked((uint)v12) > unchecked((uint)0));
    }

    public virtual void VisitMemberReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.MemberReferenceExpression memberReferenceExpression)
    {
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(memberReferenceExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001A36(memberReferenceExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v6 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Dot;
        __cil_callvirt_060015E8(this, v6);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v9 = __cil_callvirt_06001A3B(memberReferenceExpression);
        __cil_callvirt_060015E6(this, v9);
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v12 = __cil_callvirt_06001A3E(memberReferenceExpression);
        __cil_callvirt_060015F2(this, ((__cil_ref_3681fa81e970b76123c0932848c13919b7088424)(v12)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(memberReferenceExpression)));
        return;
    }

    public virtual void VisitNamedArgumentExpression(ICSharpCode.Decompiler.CSharp.Syntax.NamedArgumentExpression namedArgumentExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(namedArgumentExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v4 = __cil_callvirt_06001A4B(namedArgumentExpression);
        __cil_callvirt_060015E6(this, v4);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v6 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v6);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v10 = __cil_callvirt_06001A4E(namedArgumentExpression);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(namedArgumentExpression)));
        return;
    }

    public virtual void VisitNamedExpression(ICSharpCode.Decompiler.CSharp.Syntax.NamedExpression namedExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(namedExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v4 = __cil_callvirt_06001A58(namedExpression);
        __cil_callvirt_060015E6(this, v4);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v8 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Assign;
        __cil_callvirt_060015E8(this, v8);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v12 = __cil_callvirt_06001A5B(namedExpression);
        __cil_callvirt_06001723(v12, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(namedExpression)));
        return;
    }

    public virtual void VisitNullReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.NullReferenceExpression nullReferenceExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(nullReferenceExpression)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v3 = this.writer;
        __cil_callvirt_060016BF(v3, ((object)(null)), ((string)(null)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(nullReferenceExpression)));
        return;
    }

    public virtual void VisitObjectCreateExpression(ICSharpCode.Decompiler.CSharp.Syntax.ObjectCreateExpression objectCreateExpression)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7383370672445761e187273ec7fd0f853b78f970 bytes=151280910112886C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        int s3_0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(objectCreateExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.ObjectCreateExpression.NewKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001A6B(objectCreateExpression);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v8 = __cil_callvirt_06001A6E(objectCreateExpression);
        int v9 = __cil_bool_load(__cil_methodspec_call_2B0001B5(((__cil_ref_7383370672445761e187273ec7fd0f853b78f970)(v8))));
        if (v9 != 0) {
            goto IL_0038;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression v11 = __cil_callvirt_06001A70(objectCreateExpression);
        int v12 = __cil_bool_load(__cil_callvirt_060016F9(v11));
        int e1_3_0 = v12;
        s3_0 = e1_3_0;
        goto IL_0039;
        IL_0038: ;
        int e2_3_0 = 1;
        s3_0 = e2_3_0;
        IL_0039: ;
        l0 = __cil_bool_store(s3_0);
        global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode v15 = __cil_callvirt_06001A6D(objectCreateExpression);
        int v16 = __cil_bool_load(__cil_callvirt_060016F9(v15));
        if (v16 != 0) {
            goto IL_0049;
        } else {
            goto IL_0047;
        }
        IL_0047: ;
        l0 = __cil_bool_store(1);
        IL_0049: ;
        int v18 = __cil_bool_load(l0);
        if (v18 == 0) {
            goto IL_0074;
        } else {
            goto IL_004C;
        }
        IL_004C: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v21 = this.policy;
        int v22 = __cil_bool_load(__cil_callvirt_060014FA(v21));
        __cil_callvirt_060015ED(this, __cil_bool_store(v22));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v25 = __cil_callvirt_06001A6E(objectCreateExpression);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v27 = this.policy;
        int v28 = __cil_bool_load(__cil_callvirt_06001502(v27));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v25)), __cil_bool_store(v28));
        IL_0074: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression v30 = __cil_callvirt_06001A70(objectCreateExpression);
        __cil_callvirt_06001723(v30, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(objectCreateExpression)));
        return;
    }

    public virtual void VisitAnonymousTypeCreateExpression(ICSharpCode.Decompiler.CSharp.Syntax.AnonymousTypeCreateExpression anonymousTypeCreateExpression)
    {
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(anonymousTypeCreateExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.AnonymousTypeCreateExpression.NewKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v6 = __cil_callvirt_0600194B(anonymousTypeCreateExpression);
        __cil_callvirt_06001600(this, v6);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(anonymousTypeCreateExpression)));
        return;
    }

    public virtual void VisitParenthesizedExpression(ICSharpCode.Decompiler.CSharp.Syntax.ParenthesizedExpression parenthesizedExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(parenthesizedExpression)));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v5 = this.policy;
        int v6 = __cil_bool_load(__cil_callvirt_06001556(v5));
        __cil_callvirt_060015ED(this, __cil_bool_store(v6));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v8 = __cil_callvirt_06001A87(parenthesizedExpression);
        __cil_callvirt_06001723(v8, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v12 = this.policy;
        int v13 = __cil_bool_load(__cil_callvirt_06001556(v12));
        __cil_callvirt_060015ED(this, __cil_bool_store(v13));
        __cil_callvirt_060015EB(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(parenthesizedExpression)));
        return;
    }

    public virtual void VisitPointerReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.PointerReferenceExpression pointerReferenceExpression)
    {
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(pointerReferenceExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001A92(pointerReferenceExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v6 = ICSharpCode.Decompiler.CSharp.Syntax.PointerReferenceExpression.ArrowRole;
        __cil_callvirt_060015E8(this, v6);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v9 = __cil_callvirt_06001A97(pointerReferenceExpression);
        __cil_callvirt_060015E6(this, v9);
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v12 = __cil_callvirt_06001A99(pointerReferenceExpression);
        __cil_callvirt_060015F2(this, ((__cil_ref_3681fa81e970b76123c0932848c13919b7088424)(v12)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(pointerReferenceExpression)));
        return;
    }

    public virtual void VisitPrimitiveExpression(ICSharpCode.Decompiler.CSharp.Syntax.PrimitiveExpression primitiveExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(primitiveExpression)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v3 = this.writer;
        object v5 = __cil_callvirt_06001AA3(primitiveExpression);
        string v7 = __cil_callvirt_06001AA6(primitiveExpression);
        __cil_callvirt_060016BF(v3, v5, v7);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(primitiveExpression)));
        return;
    }

    public virtual void VisitSizeOfExpression(ICSharpCode.Decompiler.CSharp.Syntax.SizeOfExpression sizeOfExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(sizeOfExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.SizeOfExpression.SizeofKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_0600156A(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v10 = __cil_callvirt_06001B30(sizeOfExpression);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_0600156A(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_callvirt_060015EB(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(sizeOfExpression)));
        return;
    }

    public virtual void VisitStackAllocExpression(ICSharpCode.Decompiler.CSharp.Syntax.StackAllocExpression stackAllocExpression)
    {
        // structural signature __cil_ref_7383370672445761e187273ec7fd0f853b78f970 bytes=151280910112886C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_cd0269d08f11fbb12a102e68608d8897e4283eff bytes=1D12886C: class ICSharpCode.Decompiler.CSharp.Syntax.Expression[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(stackAllocExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.StackAllocExpression.StackallocKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001B3B(stackAllocExpression);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_ref_cd0269d08f11fbb12a102e68608d8897e4283eff v9 = __cil_newarr_0200021B(1);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v12 = __cil_callvirt_06001B3E(stackAllocExpression);
        v9[0] = v12;
        __cil_callvirt_060015E3(this, ((__cil_ref_7383370672445761e187273ec7fd0f853b78f970)(v9)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(stackAllocExpression)));
        return;
    }

    public virtual void VisitThisReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.ThisReferenceExpression thisReferenceExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(thisReferenceExpression)));
        string v3 = __cil_ldstr_700053BF("this");
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v5 = __cil_callvirt_060016FF(thisReferenceExpression);
        __cil_callvirt_060015E5(this, v3, v5);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(thisReferenceExpression)));
        return;
    }

    public virtual void VisitThrowExpression(ICSharpCode.Decompiler.CSharp.Syntax.ThrowExpression throwExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(throwExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.ThrowExpression.ThrowKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v7 = __cil_callvirt_06001B51(throwExpression);
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(throwExpression)));
        return;
    }

    public virtual void VisitTypeOfExpression(ICSharpCode.Decompiler.CSharp.Syntax.TypeOfExpression typeOfExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeOfExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.TypeOfExpression.TypeofKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_0600156E(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v10 = __cil_callvirt_06001B5C(typeOfExpression);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_0600156E(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_callvirt_060015EB(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeOfExpression)));
        return;
    }

    public virtual void VisitTypeReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.TypeReferenceExpression typeReferenceExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeReferenceExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v3 = __cil_callvirt_06001B66(typeReferenceExpression);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeReferenceExpression)));
        return;
    }

    public virtual void VisitUnaryOperatorExpression(ICSharpCode.Decompiler.CSharp.Syntax.UnaryOperatorExpression unaryOperatorExpression)
    {
        // enum storage token=0x0200023D alias=__cil_enum_0200023D underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@UnaryOperatorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200023D l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.TokenRole l1 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(unaryOperatorExpression)));
        int v3 = unchecked((int)(__cil_callvirt_06001B70(unaryOperatorExpression)));
        l0 = unchecked((__cil_enum_0200023D)(v3));
        int v4 = unchecked((int)(l0));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.UnaryOperatorExpression.GetOperatorRole(unchecked((__cil_enum_0200023D)(v4)));
        l1 = v5;
        int v6 = unchecked((int)(l0));
        if (unchecked((uint)v6) != unchecked((uint)11)) {
            goto IL_0023;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = l1;
        __cil_callvirt_060015E4(this, v9);
        goto IL_0032;
        IL_0023: ;
        int v10 = unchecked((int)(l0));
        if (v10 == 7) {
            goto IL_0032;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        int v12 = unchecked((int)(l0));
        if (v12 == 8) {
            goto IL_0032;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v15 = l1;
        __cil_callvirt_060015E8(this, v15);
        IL_0032: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v17 = __cil_callvirt_06001B73(unaryOperatorExpression);
        __cil_callvirt_06001723(v17, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        int v19 = unchecked((int)(l0));
        if (v19 == 7) {
            goto IL_0046;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        int v21 = unchecked((int)(l0));
        if (unchecked((uint)v21) != unchecked((uint)8)) {
            goto IL_004D;
        } else {
            goto IL_0046;
        }
        IL_0046: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v24 = l1;
        __cil_callvirt_060015E8(this, v24);
        IL_004D: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(unaryOperatorExpression)));
        return;
    }

    public virtual void VisitUncheckedExpression(ICSharpCode.Decompiler.CSharp.Syntax.UncheckedExpression uncheckedExpression)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(uncheckedExpression)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.UncheckedExpression.UncheckedKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v7 = this.policy;
        int v8 = __cil_bool_load(__cil_callvirt_0600157A(v7));
        __cil_callvirt_060015ED(this, __cil_bool_store(v8));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v10 = __cil_callvirt_06001B7E(uncheckedExpression);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_0600157A(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_callvirt_060015EB(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(uncheckedExpression)));
        return;
    }

    public virtual void VisitQueryExpression(ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression queryExpression)
    {
        // structural signature __cil_ref_2f1078334307bf91043b39b670f98fc85090528b bytes=15128085011288AC: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.QueryClause>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c8ba1d5f673d81b9a532d2d9be84ed59e688566b bytes=151287F8011288AC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.QueryClause>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        bool l1 = default;
        __cil_ref_2f1078334307bf91043b39b670f98fc85090528b l2 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.QueryClause l3 = default;
        int s3_0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression v1 = queryExpression;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression v2 = queryExpression;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v3 = __cil_callvirt_060016FE(v2);
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryClause v4 = ((object)v3 as ICSharpCode.Decompiler.CSharp.Syntax.QueryClause);
        if (v4 is null) {
            goto IL_0027;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression v5 = queryExpression;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v6 = __cil_callvirt_060016FE(v5);
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryContinuationClause v7 = ((object)v6 as ICSharpCode.Decompiler.CSharp.Syntax.QueryContinuationClause);
        int v8 = (!System.Object.ReferenceEquals(v7, null) ? 1 : 0);
        int v9 = 0;
        int v10 = (v8 == v9 ? 1 : 0);
        int e1_3_0 = v10;
        s3_0 = e1_3_0;
        goto IL_0028;
        IL_0027: ;
        int v11 = 0;
        int e2_3_0 = v11;
        s3_0 = e2_3_0;
        goto IL_0028;
        IL_0028: ;
        l0 = __cil_bool_store(s3_0);
        int v12 = __cil_bool_load(l0);
        if (v12 == 0) {
            goto IL_003D;
        } else {
            goto IL_002C;
        }
        IL_002C: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v14 = v13.writer;
        __cil_callvirt_060016C2(v14);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
        __cil_callvirt_060015EE(v15);
        goto IL_003D;
        IL_003D: ;
        int v16 = 1;
        l1 = __cil_bool_store(v16);
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression v17 = queryExpression;
        __cil_ref_c8ba1d5f673d81b9a532d2d9be84ed59e688566b v18 = __cil_callvirt_06001AB1(v17);
        __cil_ref_2f1078334307bf91043b39b670f98fc85090528b v19 = v18.GetEnumerator();
        l2 = v19;
        try {
            IL_004B: ;
            goto IL_0070;
            IL_004D: ;
            __cil_ref_2f1078334307bf91043b39b670f98fc85090528b v20 = l2;
            global::ICSharpCode.Decompiler.CSharp.Syntax.QueryClause v21 = __cil_callvirt_0A000878(v20);
            l3 = v21;
            int v22 = __cil_bool_load(l1);
            if (v22 == 0) {
                goto IL_005B;
            } else {
                goto IL_0057;
            }
            IL_0057: ;
            int v23 = 0;
            l1 = __cil_bool_store(v23);
            goto IL_0069;
            IL_005B: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.QueryClause v24 = l3;
            global::ICSharpCode.Decompiler.CSharp.Syntax.QueryContinuationClause v25 = ((object)v24 as ICSharpCode.Decompiler.CSharp.Syntax.QueryContinuationClause);
            if (v25 is not null) {
                goto IL_0069;
            } else {
                goto IL_0063;
            }
            IL_0063: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v26 = this;
            __cil_callvirt_060015EE(v26);
            goto IL_0069;
            IL_0069: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.QueryClause v27 = l3;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
            __cil_callvirt_06001723(v27, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v28)));
            goto IL_0070;
            IL_0070: ;
            __cil_ref_2f1078334307bf91043b39b670f98fc85090528b v29 = l2;
            int v30 = __cil_bool_load(__cil_callvirt_0A000018(v29));
            if (v30 != 0) {
                goto IL_004D;
            } else {
                goto IL_0078;
            }
            IL_0078: ;
            goto IL_0084;
        }
        finally {
            IL_007A: ;
            __cil_ref_2f1078334307bf91043b39b670f98fc85090528b v31 = l2;
            if (v31 is null) {
                goto IL_0083;
            } else {
                goto IL_007D;
            }
            IL_007D: ;
            __cil_ref_2f1078334307bf91043b39b670f98fc85090528b v32 = l2;
            __cil_callvirt_0A000017(v32);
            goto IL_0083;
            IL_0083: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0084: ;
        int v33 = __cil_bool_load(l0);
        if (v33 == 0) {
            goto IL_0092;
        } else {
            goto IL_0087;
        }
        IL_0087: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v34 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v35 = v34.writer;
        __cil_callvirt_060016C3(v35);
        goto IL_0092;
        IL_0092: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v36 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression v37 = queryExpression;
        __cil_callvirt_060015DC(v36, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v37)));
        return;
    }

    public virtual void VisitQueryContinuationClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryContinuationClause queryContinuationClause)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryContinuationClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression v3 = __cil_callvirt_06001ABA(queryContinuationClause);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v8 = ICSharpCode.Decompiler.CSharp.Syntax.QueryContinuationClause.IntoKeywordRole;
        __cil_callvirt_060015E4(this, v8);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v13 = __cil_callvirt_06001ABF(queryContinuationClause);
        __cil_callvirt_060015E6(this, v13);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryContinuationClause)));
        return;
    }

    public virtual void VisitQueryFromClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryFromClause queryFromClause)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryFromClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.QueryFromClause.FromKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001AC7(queryFromClause);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v11 = __cil_callvirt_06001ACB(queryFromClause);
        __cil_callvirt_060015E6(this, v11);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v15 = ICSharpCode.Decompiler.CSharp.Syntax.QueryFromClause.InKeywordRole;
        __cil_callvirt_060015E4(this, v15);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v19 = __cil_callvirt_06001ACD(queryFromClause);
        __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryFromClause)));
        return;
    }

    public virtual void VisitQueryLetClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryLetClause queryLetClause)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryLetClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.QueryLetClause.LetKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v8 = __cil_callvirt_06001AD8(queryLetClause);
        __cil_callvirt_060015E6(this, v8);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_0600153E(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v14 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Assign;
        __cil_callvirt_060015E8(this, v14);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v17 = this.policy;
        int v18 = __cil_bool_load(__cil_callvirt_0600153E(v17));
        __cil_callvirt_060015ED(this, __cil_bool_store(v18));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v20 = __cil_callvirt_06001ADA(queryLetClause);
        __cil_callvirt_06001723(v20, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryLetClause)));
        return;
    }

    public virtual void VisitQueryWhereClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryWhereClause queryWhereClause)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryWhereClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.QueryWhereClause.WhereKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v7 = __cil_callvirt_06001AE3(queryWhereClause);
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryWhereClause)));
        return;
    }

    public virtual void VisitQueryJoinClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryJoinClause queryJoinClause)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryJoinClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.QueryJoinClause.JoinKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001AED(queryJoinClause);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v11 = __cil_callvirt_06001AF1(queryJoinClause);
        __cil_callvirt_060015E6(this, v11);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v15 = ICSharpCode.Decompiler.CSharp.Syntax.QueryJoinClause.InKeywordRole;
        __cil_callvirt_060015E4(this, v15);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v19 = __cil_callvirt_06001AF3(queryJoinClause);
        __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v24 = ICSharpCode.Decompiler.CSharp.Syntax.QueryJoinClause.OnKeywordRole;
        __cil_callvirt_060015E4(this, v24);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v28 = __cil_callvirt_06001AF6(queryJoinClause);
        __cil_callvirt_06001723(v28, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v33 = ICSharpCode.Decompiler.CSharp.Syntax.QueryJoinClause.EqualsKeywordRole;
        __cil_callvirt_060015E4(this, v33);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v37 = __cil_callvirt_06001AF9(queryJoinClause);
        __cil_callvirt_06001723(v37, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        int v40 = __cil_bool_load(__cil_callvirt_06001AEB(queryJoinClause));
        if (v40 == 0) {
            goto IL_00C6;
        } else {
            goto IL_00A8;
        }
        IL_00A8: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v44 = ICSharpCode.Decompiler.CSharp.Syntax.QueryJoinClause.IntoKeywordRole;
        __cil_callvirt_060015E4(this, v44);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v47 = __cil_callvirt_06001AFE(queryJoinClause);
        __cil_callvirt_060015E6(this, v47);
        IL_00C6: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryJoinClause)));
        return;
    }

    public virtual void VisitQueryOrderClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryOrderClause queryOrderClause)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b1bdb5859fcd6a31c120ceca70b0d3d9e1ac466b bytes=151287F8011288C8: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.QueryOrdering>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryOrderClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.QueryOrderClause.OrderbyKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        __cil_ref_b1bdb5859fcd6a31c120ceca70b0d3d9e1ac466b v8 = __cil_callvirt_06001B06(queryOrderClause);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v8)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryOrderClause)));
        return;
    }

    public virtual void VisitQueryOrdering(ICSharpCode.Decompiler.CSharp.Syntax.QueryOrdering queryOrdering)
    {
        // enum storage token=0x02000233 alias=__cil_enum_02000233 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@QueryOrderingDirection; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000233 l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryOrdering)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001B0E(queryOrdering);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        int v6 = unchecked((int)(__cil_callvirt_06001B10(queryOrdering)));
        l0 = unchecked((__cil_enum_02000233)(v6));
        int v7 = unchecked((int)(l0));
        if (v7 == 1) {
            goto IL_0024;
        } else {
            goto IL_001E;
        }
        IL_001E: ;
        int v9 = unchecked((int)(l0));
        if (v9 == 2) {
            goto IL_0038;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        goto IL_004A;
        IL_0024: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v14 = ICSharpCode.Decompiler.CSharp.Syntax.QueryOrdering.AscendingKeywordRole;
        __cil_callvirt_060015E4(this, v14);
        goto IL_004A;
        IL_0038: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v18 = ICSharpCode.Decompiler.CSharp.Syntax.QueryOrdering.DescendingKeywordRole;
        __cil_callvirt_060015E4(this, v18);
        IL_004A: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryOrdering)));
        return;
    }

    public virtual void VisitQuerySelectClause(ICSharpCode.Decompiler.CSharp.Syntax.QuerySelectClause querySelectClause)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(querySelectClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.QuerySelectClause.SelectKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v7 = __cil_callvirt_06001B1A(querySelectClause);
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(querySelectClause)));
        return;
    }

    public virtual void VisitQueryGroupClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryGroupClause queryGroupClause)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryGroupClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.QueryGroupClause.GroupKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v7 = __cil_callvirt_06001B23(queryGroupClause);
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.QueryGroupClause.ByKeywordRole;
        __cil_callvirt_060015E4(this, v12);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v16 = __cil_callvirt_06001B26(queryGroupClause);
        __cil_callvirt_06001723(v16, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryGroupClause)));
        return;
    }

    public virtual void VisitAttribute(ICSharpCode.Decompiler.CSharp.Syntax.Attribute attribute)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d7fde5a64bc80c9b578cb514af618f3c4fdb0911 bytes=1512897C0112880C: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(attribute)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v3 = __cil_callvirt_06001B95(attribute);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v6 = __cil_callvirt_06001B98(attribute);
        int v7 = v6.get_Count();
        if (v7 != 0) {
            goto IL_0032;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LPar;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode v10 = __cil_callvirt_2B00025A(attribute, ((__cil_ref_d7fde5a64bc80c9b578cb514af618f3c4fdb0911)(v9)));
        int v11 = __cil_bool_load(__cil_callvirt_060016F9(v10));
        if (v11 != 0) {
            goto IL_005A;
        } else {
            goto IL_0032;
        }
        IL_0032: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_060014FA(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v18 = __cil_callvirt_06001B98(attribute);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v20 = this.policy;
        int v21 = __cil_bool_load(__cil_callvirt_06001502(v20));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v18)), __cil_bool_store(v21));
        IL_005A: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(attribute)));
        return;
    }

    public virtual void VisitAttributeSection(ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection attributeSection)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_015bf37b5e20d2e7eea995a564be7cc0cde2720d bytes=151287F801128904: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Attribute>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 bytes=1512897C01128960: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Identifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(attributeSection)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBracket;
        __cil_callvirt_060015E8(this, v3);
        string v5 = __cil_callvirt_06001BA5(attributeSection);
        int v6 = __cil_bool_load(System.String.IsNullOrEmpty(v5));
        if (v6 != 0) {
            goto IL_0042;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        string v9 = __cil_callvirt_06001BA5(attributeSection);
        __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 v10 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Identifier;
        __cil_callvirt_060015E5(this, v9, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v10)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v12);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        IL_0042: ;
        __cil_ref_015bf37b5e20d2e7eea995a564be7cc0cde2720d v17 = __cil_callvirt_06001BA9(attributeSection);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v17)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v19 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBracket;
        __cil_callvirt_060015E8(this, v19);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v21 = __cil_callvirt_060016FE(attributeSection);
        global::ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration v22 = ((object)v21 as ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration);
        if (v22 is not null) {
            goto IL_0073;
        } else {
            goto IL_0066;
        }
        IL_0066: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v24 = __cil_callvirt_060016FE(attributeSection);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration v25 = ((object)v24 as ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration);
        if (v25 is null) {
            goto IL_007C;
        } else {
            goto IL_0073;
        }
        IL_0073: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        goto IL_0082;
        IL_007C: ;
        __cil_callvirt_060015EE(this);
        IL_0082: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(attributeSection)));
        return;
    }

    public virtual void VisitDelegateDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration delegateDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_30a8632852da3c5edefb0e9e64c055e7cbc55304 bytes=1512809101128944: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 bytes=1512808501128914: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.Constraint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d9a3c927255fbcbd7902130ddf4a158447d5b197 bytes=151287F801128944: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e2072c6b6e24754d21b5166074c8ca9c61d85f2b bytes=151287F801128914: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Constraint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.Constraint l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v1 = delegateDeclaration;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v3 = delegateDeclaration;
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(v3);
        __cil_callvirt_060015F8(v2, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v6 = delegateDeclaration;
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(v6);
        __cil_callvirt_060015F4(v5, v7);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v8 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.DelegateKeyword;
        __cil_callvirt_060015E4(v8, v9);
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v10 = delegateDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v11 = __cil_callvirt_06002016(v10);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v12 = this;
        __cil_callvirt_06001723(v11, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v12)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        int v14 = 1;
        __cil_callvirt_060015ED(v13, __cil_bool_store(v14));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v16 = delegateDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v17 = __cil_callvirt_06002014(v16);
        __cil_callvirt_060015E6(v15, v17);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v18 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v19 = delegateDeclaration;
        __cil_ref_d9a3c927255fbcbd7902130ddf4a158447d5b197 v20 = __cil_callvirt_06001BCE(v19);
        __cil_callvirt_060015F3(v18, ((__cil_ref_30a8632852da3c5edefb0e9e64c055e7cbc55304)(v20)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v21 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v22 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v23 = v22.policy;
        int v24 = __cil_bool_load(__cil_callvirt_06001522(v23));
        __cil_callvirt_060015ED(v21, __cil_bool_store(v24));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v25 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v26 = delegateDeclaration;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v27 = __cil_callvirt_06001BD0(v26);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v29 = v28.policy;
        int v30 = __cil_bool_load(__cil_callvirt_060014F8(v29));
        __cil_callvirt_060015E1(v25, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v27)), __cil_bool_store(v30));
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v31 = delegateDeclaration;
        __cil_ref_e2072c6b6e24754d21b5166074c8ca9c61d85f2b v32 = __cil_callvirt_06001BD2(v31);
        __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v33 = v32.GetEnumerator();
        l0 = v33;
        try {
            IL_0089: ;
            goto IL_0099;
            IL_008B: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v34 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Constraint v35 = __cil_callvirt_0A0009DC(v34);
            l1 = v35;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Constraint v36 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v37 = this;
            __cil_callvirt_06001723(v36, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v37)));
            goto IL_0099;
            IL_0099: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v38 = l0;
            int v39 = __cil_bool_load(__cil_callvirt_0A000018(v38));
            if (v39 != 0) {
                goto IL_008B;
            } else {
                goto IL_00A1;
            }
            IL_00A1: ;
            goto IL_00AD;
        }
        finally {
            IL_00A3: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v40 = l0;
            if (v40 is null) {
                goto IL_00AC;
            } else {
                goto IL_00A6;
            }
            IL_00A6: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v41 = l0;
            __cil_callvirt_0A000017(v41);
            goto IL_00AC;
            IL_00AC: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00AD: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v42 = this;
        __cil_callvirt_060015EC(v42);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v43 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration v44 = delegateDeclaration;
        __cil_callvirt_060015DC(v43, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v44)));
        return;
    }

    public virtual void VisitNamespaceDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.NamespaceDeclaration namespaceDeclaration)
    {
        // structural signature __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 bytes=15128085011287F4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4d2a6b8f5b4a93ea17d269420297cfb58f7c71b9 bytes=151287F8011287F4: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.NamespaceDeclaration v1 = namespaceDeclaration;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.NamespaceKeyword;
        __cil_callvirt_060015E4(v2, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.NamespaceDeclaration v4 = namespaceDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001BE7(v4);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v6 = this;
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v6)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v7 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v8 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v9 = v8.policy;
        int v10 = unchecked((int)(__cil_callvirt_060014B8(v9)));
        __cil_callvirt_060015EF(v7, unchecked((__cil_enum_020001EC)(v10)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.NamespaceDeclaration v11 = namespaceDeclaration;
        __cil_ref_4d2a6b8f5b4a93ea17d269420297cfb58f7c71b9 v12 = __cil_callvirt_06001BEF(v11);
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v13 = v12.GetEnumerator();
        l0 = v13;
        try {
            IL_003B: ;
            goto IL_0052;
            IL_003D: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v14 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v15 = __cil_callvirt_0A000089(v14);
            l1 = v15;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v16 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v17 = this;
            __cil_callvirt_06001723(v16, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v17)));
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v18 = this;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v19 = l1;
            __cil_direct_06001663(v18, v19);
            goto IL_0052;
            IL_0052: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v20 = l0;
            int v21 = __cil_bool_load(__cil_callvirt_0A000018(v20));
            if (v21 != 0) {
                goto IL_003D;
            } else {
                goto IL_005A;
            }
            IL_005A: ;
            goto IL_0066;
        }
        finally {
            IL_005C: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v22 = l0;
            if (v22 is null) {
                goto IL_0065;
            } else {
                goto IL_005F;
            }
            IL_005F: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v23 = l0;
            __cil_callvirt_0A000017(v23);
            goto IL_0065;
            IL_0065: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0066: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v24 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v25 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = v25.policy;
        int v27 = unchecked((int)(__cil_callvirt_060014B8(v26)));
        __cil_callvirt_060015F0(v24, unchecked((__cil_enum_020001EC)(v27)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.NamespaceDeclaration v29 = namespaceDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v30 = __cil_callvirt_06001706(v29);
        __cil_callvirt_060015DF(v28, v30);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v31 = this;
        __cil_callvirt_060015EE(v31);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v32 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.NamespaceDeclaration v33 = namespaceDeclaration;
        __cil_callvirt_060015DC(v32, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v33)));
        return;
    }

    public virtual void VisitTypeDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration typeDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_30a8632852da3c5edefb0e9e64c055e7cbc55304 bytes=1512809101128944: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 bytes=1512808501128914: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.Constraint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d9a3c927255fbcbd7902130ddf4a158447d5b197 bytes=151287F801128944: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e2072c6b6e24754d21b5166074c8ca9c61d85f2b bytes=151287F801128914: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Constraint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a bytes=1512808501128A2C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_29ca129884ad6bfe9cf8eb4cb0cc3d70be820cbe bytes=151287F801128A2C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200024F alias=__cil_enum_0200024F underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@ClassType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020001EC l0 = default;
        __cil_enum_0200024F l1 = default;
        __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 l2 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.Constraint l3 = default;
        bool l4 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l5 = default;
        __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a l6 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration l7 = default;
        bool l8 = default;
        __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a l9 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration l10 = default;
        int l11 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v1 = typeDeclaration;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v3 = typeDeclaration;
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(v3);
        __cil_callvirt_060015F8(v2, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v6 = typeDeclaration;
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(v6);
        __cil_callvirt_060015F4(v5, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v8 = typeDeclaration;
        int v9 = unchecked((int)(__cil_callvirt_06001C35(v8)));
        l1 = unchecked((__cil_enum_0200024F)(v9));
        int v10 = unchecked((int)(l1));
        int v11 = 1;
        int v12 = unchecked(v10 - v11);
        switch (v12) {
            case 0: {
                goto IL_006E;
            }
            case 1: {
                goto IL_0055;
            }
            case 2: {
                goto IL_003C;
            }
            default: {
                goto IL_003A;
            } }
        IL_003A: ;
        goto IL_0087;
        IL_003C: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v14 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.EnumKeyword;
        __cil_callvirt_060015E4(v13, v14);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v16 = v15.policy;
        int v17 = unchecked((int)(__cil_callvirt_060014C0(v16)));
        l0 = unchecked((__cil_enum_020001EC)(v17));
        goto IL_009E;
        IL_0055: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v18 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v19 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.InterfaceKeyword;
        __cil_callvirt_060015E4(v18, v19);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v20 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v21 = v20.policy;
        int v22 = unchecked((int)(__cil_callvirt_060014BC(v21)));
        l0 = unchecked((__cil_enum_020001EC)(v22));
        goto IL_009E;
        IL_006E: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v23 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v24 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.StructKeyword;
        __cil_callvirt_060015E4(v23, v24);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v25 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = v25.policy;
        int v27 = unchecked((int)(__cil_callvirt_060014BE(v26)));
        l0 = unchecked((__cil_enum_020001EC)(v27));
        goto IL_009E;
        IL_0087: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v29 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.ClassKeyword;
        __cil_callvirt_060015E4(v28, v29);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v30 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v31 = v30.policy;
        int v32 = unchecked((int)(__cil_callvirt_060014BA(v31)));
        l0 = unchecked((__cil_enum_020001EC)(v32));
        goto IL_009E;
        IL_009E: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v33 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v34 = typeDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v35 = __cil_callvirt_06002014(v34);
        __cil_callvirt_060015E6(v33, v35);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v36 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v37 = typeDeclaration;
        __cil_ref_d9a3c927255fbcbd7902130ddf4a158447d5b197 v38 = __cil_callvirt_06001C38(v37);
        __cil_callvirt_060015F3(v36, ((__cil_ref_30a8632852da3c5edefb0e9e64c055e7cbc55304)(v38)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v39 = typeDeclaration;
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v40 = __cil_callvirt_06001C3B(v39);
        int v41 = __cil_bool_load(__cil_methodspec_call_2B000258(((__cil_ref_3681fa81e970b76123c0932848c13919b7088424)(v40))));
        if (v41 == 0) {
            goto IL_00E8;
        } else {
            goto IL_00C3;
        }
        IL_00C3: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v42 = this;
        int v43 = 1;
        __cil_callvirt_060015ED(v42, __cil_bool_store(v43));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v44 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v45 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(v44, v45);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v46 = this;
        int v47 = 1;
        __cil_callvirt_060015ED(v46, __cil_bool_store(v47));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v48 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v49 = typeDeclaration;
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v50 = __cil_callvirt_06001C3B(v49);
        __cil_callvirt_060015E0(v48, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v50)));
        goto IL_00E8;
        IL_00E8: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v51 = typeDeclaration;
        __cil_ref_e2072c6b6e24754d21b5166074c8ca9c61d85f2b v52 = __cil_callvirt_06001C3C(v51);
        __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v53 = v52.GetEnumerator();
        l2 = v53;
        try {
            IL_00F4: ;
            goto IL_0104;
            IL_00F6: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v54 = l2;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Constraint v55 = __cil_callvirt_0A0009DC(v54);
            l3 = v55;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Constraint v56 = l3;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v57 = this;
            __cil_callvirt_06001723(v56, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v57)));
            goto IL_0104;
            IL_0104: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v58 = l2;
            int v59 = __cil_bool_load(__cil_callvirt_0A000018(v58));
            if (v59 != 0) {
                goto IL_00F6;
            } else {
                goto IL_010C;
            }
            IL_010C: ;
            goto IL_0118;
        }
        finally {
            IL_010E: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v60 = l2;
            if (v60 is null) {
                goto IL_0117;
            } else {
                goto IL_0111;
            }
            IL_0111: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v61 = l2;
            __cil_callvirt_0A000017(v61);
            goto IL_0117;
            IL_0117: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0118: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v62 = this;
        int v63 = unchecked((int)(l0));
        __cil_callvirt_060015EF(v62, unchecked((__cil_enum_020001EC)(v63)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v64 = typeDeclaration;
        int v65 = unchecked((int)(__cil_callvirt_06001C35(v64)));
        int v66 = 3;
        if (unchecked((uint)v65) != unchecked((uint)v66)) {
            goto IL_019A;
        } else {
            goto IL_0128;
        }
        IL_0128: ;
        int v67 = 1;
        l4 = __cil_bool_store(v67);
        l5 = null;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v68 = typeDeclaration;
        __cil_ref_29ca129884ad6bfe9cf8eb4cb0cc3d70be820cbe v69 = __cil_callvirt_06001C3E(v68);
        __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v70 = v69.GetEnumerator();
        l6 = v70;
        try {
            IL_013B: ;
            goto IL_016A;
            IL_013D: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v71 = l6;
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v72 = __cil_callvirt_0A000080(v71);
            l7 = v72;
            int v73 = __cil_bool_load(l4);
            if (v73 == 0) {
                goto IL_014F;
            } else {
                goto IL_014A;
            }
            IL_014A: ;
            int v74 = 0;
            l4 = __cil_bool_store(v74);
            goto IL_015E;
            IL_014F: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v75 = this;
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v76 = l7;
            int v77 = 1;
            __cil_callvirt_060015DD(v75, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v76)), __cil_bool_store(v77));
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v78 = this;
            __cil_callvirt_060015EE(v78);
            goto IL_015E;
            IL_015E: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v79 = l7;
            l5 = v79;
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v80 = l7;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v81 = this;
            __cil_callvirt_06001723(v80, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v81)));
            goto IL_016A;
            IL_016A: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v82 = l6;
            int v83 = __cil_bool_load(__cil_callvirt_0A000018(v82));
            if (v83 != 0) {
                goto IL_013D;
            } else {
                goto IL_0173;
            }
            IL_0173: ;
            goto IL_0181;
        }
        finally {
            IL_0175: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v84 = l6;
            if (v84 is null) {
                goto IL_0180;
            } else {
                goto IL_0179;
            }
            IL_0179: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v85 = l6;
            __cil_callvirt_0A000017(v85);
            goto IL_0180;
            IL_0180: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_0181: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v86 = l5;
        if (v86 is null) {
            goto IL_0192;
        } else {
            goto IL_0185;
        }
        IL_0185: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v87 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v88 = l5;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v89 = __cil_callvirt_06001703(v88);
        __cil_callvirt_060015DE(v87, v89);
        goto IL_0192;
        IL_0192: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v90 = this;
        __cil_callvirt_060015EE(v90);
        goto IL_01FB;
        IL_019A: ;
        int v91 = 1;
        l8 = __cil_bool_store(v91);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v92 = typeDeclaration;
        __cil_ref_29ca129884ad6bfe9cf8eb4cb0cc3d70be820cbe v93 = __cil_callvirt_06001C3E(v92);
        __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v94 = v93.GetEnumerator();
        l9 = v94;
        try {
            IL_01AA: ;
            goto IL_01E4;
            IL_01AC: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v95 = l9;
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v96 = __cil_callvirt_0A000080(v95);
            l10 = v96;
            int v97 = __cil_bool_load(l8);
            if (v97 != 0) {
                goto IL_01D9;
            } else {
                goto IL_01B9;
            }
            IL_01B9: ;
            int v98 = 0;
            l11 = v98;
            goto IL_01CA;
            IL_01BE: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v99 = this;
            __cil_callvirt_060015EE(v99);
            int v100 = l11;
            int v101 = 1;
            int v102 = unchecked(v100 + v101);
            l11 = v102;
            goto IL_01CA;
            IL_01CA: ;
            int v103 = l11;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v104 = this;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v105 = v104.policy;
            int v106 = __cil_callvirt_060015A6(v105);
            if (v103 < v106) {
                goto IL_01BE;
            } else {
                goto IL_01D9;
            }
            IL_01D9: ;
            int v107 = 0;
            l8 = __cil_bool_store(v107);
            global::ICSharpCode.Decompiler.CSharp.Syntax.EntityDeclaration v108 = l10;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v109 = this;
            __cil_callvirt_06001723(v108, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v109)));
            goto IL_01E4;
            IL_01E4: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v110 = l9;
            int v111 = __cil_bool_load(__cil_callvirt_0A000018(v110));
            if (v111 != 0) {
                goto IL_01AC;
            } else {
                goto IL_01ED;
            }
            IL_01ED: ;
            goto IL_01FB;
        }
        finally {
            IL_01EF: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v112 = l9;
            if (v112 is null) {
                goto IL_01FA;
            } else {
                goto IL_01F3;
            }
            IL_01F3: ;
            __cil_ref_3cd5b7aeeb2084cd1572dff29f0c8e236e38ec8a v113 = l9;
            __cil_callvirt_0A000017(v113);
            goto IL_01FA;
            IL_01FA: ;
            goto __cil_finally_end_2;
            __cil_finally_end_2: ;
        }
        IL_01FB: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v114 = this;
        int v115 = unchecked((int)(l0));
        __cil_callvirt_060015F0(v114, unchecked((__cil_enum_020001EC)(v115)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v116 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v117 = typeDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v118 = __cil_callvirt_06001706(v117);
        __cil_callvirt_060015DF(v116, v118);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v119 = this;
        __cil_callvirt_060015EE(v119);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v120 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v121 = typeDeclaration;
        __cil_callvirt_060015DC(v120, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v121)));
        return;
    }

    public virtual void VisitUsingAliasDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration usingAliasDeclaration)
    {
        // structural signature __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 bytes=1512897C01128960: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Identifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingAliasDeclaration)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration.UsingKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 v6 = ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration.AliasRole;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v7 = __cil_callvirt_2B000007(usingAliasDeclaration, v6);
        __cil_callvirt_060015E6(this, v7);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v10 = this.policy;
        int v11 = __cil_bool_load(__cil_callvirt_06001542(v10));
        __cil_callvirt_060015ED(this, __cil_bool_store(v11));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v13 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Assign;
        __cil_callvirt_060015E8(this, v13);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v16 = this.policy;
        int v17 = __cil_bool_load(__cil_callvirt_06001542(v16));
        __cil_callvirt_060015ED(this, __cil_bool_store(v17));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v19 = __cil_callvirt_06001C5A(usingAliasDeclaration);
        __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingAliasDeclaration)));
        return;
    }

    public virtual void VisitUsingDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.UsingDeclaration usingDeclaration)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingDeclaration)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.UsingDeclaration.UsingKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001C67(usingDeclaration);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingDeclaration)));
        return;
    }

    public virtual void VisitExternAliasDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.ExternAliasDeclaration externAliasDeclaration)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(externAliasDeclaration)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.ExternKeyword;
        __cil_callvirt_060015E4(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v7 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.AliasKeyword;
        __cil_callvirt_060015E4(this, v7);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v12 = __cil_callvirt_06001BDD(externAliasDeclaration);
        __cil_callvirt_060015E6(this, v12);
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(externAliasDeclaration)));
        return;
    }

    public virtual void VisitBlockStatement(ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement blockStatement)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v3 = this.policy;
        int v4 = unchecked((int)(__cil_callvirt_060014DE(v3)));
        __cil_callvirt_06001635(this, blockStatement, unchecked((__cil_enum_020001EC)(v4)));
        __cil_callvirt_060015EE(this);
        return;
    }

    protected virtual void WriteBlock(ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement blockStatement, ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle style)
    {
        // structural signature __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c bytes=15128085011289CC: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 bytes=151287F8011289CC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.Statement l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v1 = blockStatement;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        int v3 = unchecked((int)(style));
        __cil_callvirt_060015EF(v2, unchecked((__cil_enum_020001EC)(v3)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v4 = blockStatement;
        __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 v5 = __cil_callvirt_06001E3A(v4);
        __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v6 = v5.GetEnumerator();
        l0 = v6;
        try {
            IL_001A: ;
            goto IL_002A;
            IL_001C: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v7 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v8 = __cil_callvirt_0A0008CF(v7);
            l1 = v8;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v9 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v10 = this;
            __cil_callvirt_06001723(v9, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v10)));
            goto IL_002A;
            IL_002A: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v11 = l0;
            int v12 = __cil_bool_load(__cil_callvirt_0A000018(v11));
            if (v12 != 0) {
                goto IL_001C;
            } else {
                goto IL_0032;
            }
            IL_0032: ;
            goto IL_003E;
        }
        finally {
            IL_0034: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v13 = l0;
            if (v13 is null) {
                goto IL_003D;
            } else {
                goto IL_0037;
            }
            IL_0037: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v14 = l0;
            __cil_callvirt_0A000017(v14);
            goto IL_003D;
            IL_003D: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_003E: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v16 = blockStatement;
        __cil_callvirt_060015DC(v15, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v16)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v17 = this;
        int v18 = unchecked((int)(style));
        __cil_callvirt_060015F0(v17, unchecked((__cil_enum_020001EC)(v18)));
        return;
    }

    public virtual void VisitBreakStatement(ICSharpCode.Decompiler.CSharp.Syntax.BreakStatement breakStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(breakStatement)));
        string v3 = __cil_ldstr_700087C6("break");
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v4 = ICSharpCode.Decompiler.CSharp.Syntax.BreakStatement.BreakKeywordRole;
        __cil_callvirt_060015E5(this, v3, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v4)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(breakStatement)));
        return;
    }

    public virtual void VisitCheckedStatement(ICSharpCode.Decompiler.CSharp.Syntax.CheckedStatement checkedStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(checkedStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.CheckedStatement.CheckedKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v5 = __cil_callvirt_06001E4F(checkedStatement);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(checkedStatement)));
        return;
    }

    public virtual void VisitContinueStatement(ICSharpCode.Decompiler.CSharp.Syntax.ContinueStatement continueStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(continueStatement)));
        string v3 = __cil_ldstr_700087D2("continue");
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v4 = ICSharpCode.Decompiler.CSharp.Syntax.ContinueStatement.ContinueKeywordRole;
        __cil_callvirt_060015E5(this, v3, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v4)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(continueStatement)));
        return;
    }

    public virtual void VisitDoWhileStatement(ICSharpCode.Decompiler.CSharp.Syntax.DoWhileStatement doWhileStatement)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(doWhileStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.DoWhileStatement.DoKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v6 = __cil_callvirt_06001E61(doWhileStatement);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v8 = this.policy;
        int v9 = unchecked((int)(__cil_callvirt_060014EC(v8)));
        __cil_callvirt_060015F6(this, v6, unchecked((__cil_enum_020001EF)(v9)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.DoWhileStatement.WhileKeywordRole;
        __cil_callvirt_060015E4(this, v11);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_06001530(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v19 = this.policy;
        int v20 = __cil_bool_load(__cil_callvirt_0600155A(v19));
        __cil_callvirt_060015ED(this, __cil_bool_store(v20));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v22 = __cil_callvirt_06001E65(doWhileStatement);
        __cil_callvirt_06001723(v22, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = this.policy;
        int v27 = __cil_bool_load(__cil_callvirt_0600155A(v26));
        __cil_callvirt_060015ED(this, __cil_bool_store(v27));
        __cil_callvirt_060015EB(this);
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(doWhileStatement)));
        return;
    }

    public virtual void VisitEmptyStatement(ICSharpCode.Decompiler.CSharp.Syntax.EmptyStatement emptyStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(emptyStatement)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(emptyStatement)));
        return;
    }

    public virtual void VisitExpressionStatement(ICSharpCode.Decompiler.CSharp.Syntax.ExpressionStatement expressionStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(expressionStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001E79(expressionStatement);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(expressionStatement)));
        return;
    }

    public virtual void VisitFixedStatement(ICSharpCode.Decompiler.CSharp.Syntax.FixedStatement fixedStatement)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 bytes=151287F801128A64: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.VariableInitializer>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.FixedStatement.FixedKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_0600153C(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_06001566(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v14 = __cil_callvirt_06001E84(fixedStatement);
        __cil_callvirt_06001723(v14, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 v20 = __cil_callvirt_06001E86(fixedStatement);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v20)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v23 = this.policy;
        int v24 = __cil_bool_load(__cil_callvirt_06001566(v23));
        __cil_callvirt_060015ED(this, __cil_bool_store(v24));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v28 = __cil_callvirt_06001E88(fixedStatement);
        __cil_callvirt_060015F6(this, v28, unchecked((__cil_enum_020001EF)(1)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedStatement)));
        return;
    }

    public virtual void VisitForeachStatement(ICSharpCode.Decompiler.CSharp.Syntax.ForeachStatement foreachStatement)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(foreachStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.ForeachStatement.ForeachKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_06001534(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_0600155E(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v14 = __cil_callvirt_06001E92(foreachStatement);
        __cil_callvirt_06001723(v14, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v20 = __cil_callvirt_06001E96(foreachStatement);
        __cil_callvirt_060015E6(this, v20);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v22 = ICSharpCode.Decompiler.CSharp.Syntax.ForeachStatement.InKeywordRole;
        __cil_callvirt_060015E4(this, v22);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v26 = __cil_callvirt_06001E99(foreachStatement);
        __cil_callvirt_06001723(v26, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v30 = this.policy;
        int v31 = __cil_bool_load(__cil_callvirt_0600155E(v30));
        __cil_callvirt_060015ED(this, __cil_bool_store(v31));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v35 = __cil_callvirt_06001E9C(foreachStatement);
        __cil_callvirt_060015F6(this, v35, unchecked((__cil_enum_020001EF)(1)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(foreachStatement)));
        return;
    }

    public virtual void VisitForStatement(ICSharpCode.Decompiler.CSharp.Syntax.ForStatement forStatement)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 bytes=151287F8011289CC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2eb3ad1cd778e7bacf08e5881cc9990250c8fcae bytes=15128091011289CC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(forStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.ForStatement.ForKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_06001532(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_0600155C(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 v15 = __cil_callvirt_06001EA6(forStatement);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v15)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v18 = this.policy;
        int v19 = __cil_bool_load(__cil_callvirt_0600158C(v18));
        __cil_callvirt_060015ED(this, __cil_bool_store(v19));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v21 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Semicolon;
        __cil_callvirt_060015E8(this, v21);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v24 = this.policy;
        int v25 = __cil_bool_load(__cil_callvirt_0600158E(v24));
        __cil_callvirt_060015ED(this, __cil_bool_store(v25));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v27 = __cil_callvirt_06001EA7(forStatement);
        __cil_callvirt_06001723(v27, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v31 = this.policy;
        int v32 = __cil_bool_load(__cil_callvirt_0600158C(v31));
        __cil_callvirt_060015ED(this, __cil_bool_store(v32));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v34 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Semicolon;
        __cil_callvirt_060015E8(this, v34);
        __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 v36 = __cil_callvirt_06001EA9(forStatement);
        int v37 = __cil_bool_load(__cil_methodspec_call_2B00025B(((__cil_ref_2eb3ad1cd778e7bacf08e5881cc9990250c8fcae)(v36))));
        if (v37 == 0) {
            goto IL_00C5;
        } else {
            goto IL_00A8;
        }
        IL_00A8: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v40 = this.policy;
        int v41 = __cil_bool_load(__cil_callvirt_0600158E(v40));
        __cil_callvirt_060015ED(this, __cil_bool_store(v41));
        __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 v44 = __cil_callvirt_06001EA9(forStatement);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v44)));
        IL_00C5: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v47 = this.policy;
        int v48 = __cil_bool_load(__cil_callvirt_0600155C(v47));
        __cil_callvirt_060015ED(this, __cil_bool_store(v48));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v52 = __cil_callvirt_06001EAB(forStatement);
        __cil_callvirt_060015F6(this, v52, unchecked((__cil_enum_020001EF)(1)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(forStatement)));
        return;
    }

    public virtual void VisitGotoCaseStatement(ICSharpCode.Decompiler.CSharp.Syntax.GotoCaseStatement gotoCaseStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoCaseStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.GotoCaseStatement.GotoKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.GotoCaseStatement.CaseKeywordRole;
        __cil_callvirt_060015E4(this, v5);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v9 = __cil_callvirt_06001EC0(gotoCaseStatement);
        __cil_callvirt_06001723(v9, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoCaseStatement)));
        return;
    }

    public virtual void VisitGotoDefaultStatement(ICSharpCode.Decompiler.CSharp.Syntax.GotoDefaultStatement gotoDefaultStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoDefaultStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.GotoDefaultStatement.GotoKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.GotoDefaultStatement.DefaultKeywordRole;
        __cil_callvirt_060015E4(this, v5);
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoDefaultStatement)));
        return;
    }

    public virtual void VisitGotoStatement(ICSharpCode.Decompiler.CSharp.Syntax.GotoStatement gotoStatement)
    {
        // structural signature __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 bytes=1512897C01128960: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Identifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.GotoStatement.GotoKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 v6 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Identifier;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v7 = __cil_callvirt_2B000007(gotoStatement, v6);
        __cil_callvirt_060015E6(this, v7);
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoStatement)));
        return;
    }

    public virtual void VisitIfElseStatement(ICSharpCode.Decompiler.CSharp.Syntax.IfElseStatement ifElseStatement)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(ifElseStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.IfElseStatement.IfKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_0600152E(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_06001558(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v14 = __cil_callvirt_06001ED4(ifElseStatement);
        __cil_callvirt_06001723(v14, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v18 = this.policy;
        int v19 = __cil_bool_load(__cil_callvirt_06001558(v18));
        __cil_callvirt_060015ED(this, __cil_bool_store(v19));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v22 = __cil_callvirt_06001EDA(ifElseStatement);
        int v23 = __cil_bool_load(__cil_callvirt_060016F9(v22));
        if (v23 == 0) {
            goto IL_0079;
        } else {
            goto IL_006A;
        }
        IL_006A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v26 = __cil_callvirt_06001ED7(ifElseStatement);
        __cil_callvirt_060015F6(this, v26, unchecked((__cil_enum_020001EF)(1)));
        goto IL_00C3;
        IL_0079: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v30 = __cil_callvirt_06001ED7(ifElseStatement);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v32 = this.policy;
        int v33 = unchecked((int)(__cil_callvirt_060014E4(v32)));
        __cil_callvirt_060015F6(this, v30, unchecked((__cil_enum_020001EF)(v33)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v35 = ICSharpCode.Decompiler.CSharp.Syntax.IfElseStatement.ElseKeywordRole;
        __cil_callvirt_060015E4(this, v35);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v37 = __cil_callvirt_06001EDA(ifElseStatement);
        global::ICSharpCode.Decompiler.CSharp.Syntax.IfElseStatement v38 = ((object)v37 as ICSharpCode.Decompiler.CSharp.Syntax.IfElseStatement);
        if (v38 is null) {
            goto IL_00B6;
        } else {
            goto IL_00A8;
        }
        IL_00A8: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v40 = __cil_callvirt_06001EDA(ifElseStatement);
        __cil_callvirt_06001723(v40, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        goto IL_00C3;
        IL_00B6: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v44 = __cil_callvirt_06001EDA(ifElseStatement);
        __cil_callvirt_060015F6(this, v44, unchecked((__cil_enum_020001EF)(1)));
        IL_00C3: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(ifElseStatement)));
        return;
    }

    public virtual void VisitLabelStatement(ICSharpCode.Decompiler.CSharp.Syntax.LabelStatement labelStatement)
    {
        // structural signature __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 bytes=1512897C01128960: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Identifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(labelStatement)));
        __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 v4 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Identifier;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v5 = __cil_callvirt_2B000007(labelStatement, v4);
        __cil_callvirt_060015E6(this, v5);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v7 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v7);
        l0 = __cil_bool_store(0);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v10 = __cil_callvirt_06001703(labelStatement);
        l1 = v10;
        goto IL_0045;
        IL_002E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v11 = l1;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v12 = __cil_callvirt_060016FF(v11);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v14 = __cil_callvirt_060016FF(labelStatement);
        if (!System.Object.ReferenceEquals(v12, v14)) {
            goto IL_003E;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        l0 = __cil_bool_store(1);
        IL_003E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v16 = l1;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v17 = __cil_callvirt_06001703(v16);
        l1 = v17;
        IL_0045: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v18 = l1;
        if (v18 is not null) {
            goto IL_002E;
        } else {
            goto IL_0048;
        }
        IL_0048: ;
        int v19 = __cil_bool_load(l0);
        if (v19 != 0) {
            goto IL_0056;
        } else {
            goto IL_004B;
        }
        IL_004B: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v21 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Semicolon;
        __cil_callvirt_060015E8(this, v21);
        IL_0056: ;
        __cil_callvirt_060015EE(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(labelStatement)));
        return;
    }

    public virtual void VisitLockStatement(ICSharpCode.Decompiler.CSharp.Syntax.LockStatement lockStatement)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(lockStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.LockStatement.LockKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_0600153A(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_06001564(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v14 = __cil_callvirt_06001EEF(lockStatement);
        __cil_callvirt_06001723(v14, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v18 = this.policy;
        int v19 = __cil_bool_load(__cil_callvirt_06001564(v18));
        __cil_callvirt_060015ED(this, __cil_bool_store(v19));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v23 = __cil_callvirt_06001EF2(lockStatement);
        __cil_callvirt_060015F6(this, v23, unchecked((__cil_enum_020001EF)(1)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(lockStatement)));
        return;
    }

    public virtual void VisitReturnStatement(ICSharpCode.Decompiler.CSharp.Syntax.ReturnStatement returnStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(returnStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.ReturnStatement.ReturnKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v5 = __cil_callvirt_06001EFB(returnStatement);
        int v6 = __cil_bool_load(__cil_callvirt_060016F9(v5));
        if (v6 != 0) {
            goto IL_0032;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v10 = __cil_callvirt_06001EFB(returnStatement);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_0032: ;
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(returnStatement)));
        return;
    }

    public virtual void VisitSwitchStatement(ICSharpCode.Decompiler.CSharp.Syntax.SwitchStatement switchStatement)
    {
        // structural signature __cil_ref_dcf8f000887e8346f4c6683fe48db965e13799d3 bytes=15128085011289D4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_63a180d191c8d9a08c5c7e0b48b1d68eec0bc969 bytes=151287F8011289D4: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_dcf8f000887e8346f4c6683fe48db965e13799d3 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchStatement v1 = switchStatement;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.SwitchStatement.SwitchKeywordRole;
        __cil_callvirt_060015E4(v2, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v4 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = v5.policy;
        int v7 = __cil_bool_load(__cil_callvirt_06001538(v6));
        __cil_callvirt_060015ED(v4, __cil_bool_store(v7));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v8 = this;
        __cil_callvirt_060015EA(v8);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v9 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v10 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = v10.policy;
        int v12 = __cil_bool_load(__cil_callvirt_06001562(v11));
        __cil_callvirt_060015ED(v9, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchStatement v13 = switchStatement;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v14 = __cil_callvirt_06001F0D(v13);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
        __cil_callvirt_06001723(v14, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v15)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v16 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v17 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v18 = v17.policy;
        int v19 = __cil_bool_load(__cil_callvirt_06001562(v18));
        __cil_callvirt_060015ED(v16, __cil_bool_store(v19));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v20 = this;
        __cil_callvirt_060015EB(v20);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v21 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v22 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v23 = v22.policy;
        int v24 = unchecked((int)(__cil_callvirt_060014DE(v23)));
        __cil_callvirt_060015EF(v21, unchecked((__cil_enum_020001EC)(v24)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v25 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = v25.policy;
        int v27 = __cil_bool_load(__cil_callvirt_060014A2(v26));
        if (v27 != 0) {
            goto IL_0086;
        } else {
            goto IL_007B;
        }
        IL_007B: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v29 = v28.writer;
        __cil_callvirt_060016C3(v29);
        goto IL_0086;
        IL_0086: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchStatement v30 = switchStatement;
        __cil_ref_63a180d191c8d9a08c5c7e0b48b1d68eec0bc969 v31 = __cil_callvirt_06001F11(v30);
        __cil_ref_dcf8f000887e8346f4c6683fe48db965e13799d3 v32 = v31.GetEnumerator();
        l0 = v32;
        try {
            IL_0092: ;
            goto IL_00A2;
            IL_0094: ;
            __cil_ref_dcf8f000887e8346f4c6683fe48db965e13799d3 v33 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v34 = __cil_callvirt_0A0008DA(v33);
            l1 = v34;
            global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v35 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v36 = this;
            __cil_callvirt_06001723(v35, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v36)));
            goto IL_00A2;
            IL_00A2: ;
            __cil_ref_dcf8f000887e8346f4c6683fe48db965e13799d3 v37 = l0;
            int v38 = __cil_bool_load(__cil_callvirt_0A000018(v37));
            if (v38 != 0) {
                goto IL_0094;
            } else {
                goto IL_00AA;
            }
            IL_00AA: ;
            goto IL_00B6;
        }
        finally {
            IL_00AC: ;
            __cil_ref_dcf8f000887e8346f4c6683fe48db965e13799d3 v39 = l0;
            if (v39 is null) {
                goto IL_00B5;
            } else {
                goto IL_00AF;
            }
            IL_00AF: ;
            __cil_ref_dcf8f000887e8346f4c6683fe48db965e13799d3 v40 = l0;
            __cil_callvirt_0A000017(v40);
            goto IL_00B5;
            IL_00B5: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00B6: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v41 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v42 = v41.policy;
        int v43 = __cil_bool_load(__cil_callvirt_060014A2(v42));
        if (v43 != 0) {
            goto IL_00CE;
        } else {
            goto IL_00C3;
        }
        IL_00C3: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v44 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v45 = v44.writer;
        __cil_callvirt_060016C2(v45);
        goto IL_00CE;
        IL_00CE: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v46 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v47 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v48 = v47.policy;
        int v49 = unchecked((int)(__cil_callvirt_060014DE(v48)));
        __cil_callvirt_060015F0(v46, unchecked((__cil_enum_020001EC)(v49)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v50 = this;
        __cil_callvirt_060015EE(v50);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v51 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchStatement v52 = switchStatement;
        __cil_callvirt_060015DC(v51, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v52)));
        return;
    }

    public virtual void VisitSwitchSection(ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection switchSection)
    {
        // structural signature __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c bytes=15128085011289CC: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 bytes=151287F8011289CC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2eb3ad1cd778e7bacf08e5881cc9990250c8fcae bytes=15128091011289CC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.Statement>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0bddc71f571f5bdd7940c5ac95c259fabf7a0915 bytes=15128085011289D8: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9ca383cef5f870a0ee524876d7d8ce50c49cda83 bytes=151287F8011289D8: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        bool l1 = default;
        __cil_ref_0bddc71f571f5bdd7940c5ac95c259fabf7a0915 l2 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel l3 = default;
        __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c l4 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.Statement l5 = default;
        int s13_0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v1 = switchSection;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        int v2 = 1;
        l0 = __cil_bool_store(v2);
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v3 = switchSection;
        __cil_ref_9ca383cef5f870a0ee524876d7d8ce50c49cda83 v4 = __cil_callvirt_06001F1B(v3);
        __cil_ref_0bddc71f571f5bdd7940c5ac95c259fabf7a0915 v5 = v4.GetEnumerator();
        l2 = v5;
        try {
            IL_0015: ;
            goto IL_0030;
            IL_0017: ;
            __cil_ref_0bddc71f571f5bdd7940c5ac95c259fabf7a0915 v6 = l2;
            global::ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel v7 = __cil_callvirt_0A0009E1(v6);
            l3 = v7;
            int v8 = __cil_bool_load(l0);
            if (v8 != 0) {
                goto IL_0027;
            } else {
                goto IL_0021;
            }
            IL_0021: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v9 = this;
            __cil_callvirt_060015EE(v9);
            goto IL_0027;
            IL_0027: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel v10 = l3;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
            __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v11)));
            int v12 = 0;
            l0 = __cil_bool_store(v12);
            goto IL_0030;
            IL_0030: ;
            __cil_ref_0bddc71f571f5bdd7940c5ac95c259fabf7a0915 v13 = l2;
            int v14 = __cil_bool_load(__cil_callvirt_0A000018(v13));
            if (v14 != 0) {
                goto IL_0017;
            } else {
                goto IL_0038;
            }
            IL_0038: ;
            goto IL_0044;
        }
        finally {
            IL_003A: ;
            __cil_ref_0bddc71f571f5bdd7940c5ac95c259fabf7a0915 v15 = l2;
            if (v15 is null) {
                goto IL_0043;
            } else {
                goto IL_003D;
            }
            IL_003D: ;
            __cil_ref_0bddc71f571f5bdd7940c5ac95c259fabf7a0915 v16 = l2;
            __cil_callvirt_0A000017(v16);
            goto IL_0043;
            IL_0043: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0044: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v17 = switchSection;
        __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 v18 = __cil_callvirt_06001F1C(v17);
        int v19 = v18.get_Count();
        int v20 = 1;
        if (unchecked((uint)v19) != unchecked((uint)v20)) {
            goto IL_0067;
        } else {
            goto IL_0052;
        }
        IL_0052: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v21 = switchSection;
        __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 v22 = __cil_callvirt_06001F1C(v21);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v23 = __cil_methodspec_call_2B00016E(((__cil_ref_2eb3ad1cd778e7bacf08e5881cc9990250c8fcae)(v22)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v24 = ((object)v23 as ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement);
        int v25 = (!System.Object.ReferenceEquals(v24, null) ? 1 : 0);
        int e11_13_0 = v25;
        s13_0 = e11_13_0;
        goto IL_0068;
        IL_0067: ;
        int v26 = 0;
        int e12_13_0 = v26;
        s13_0 = e12_13_0;
        goto IL_0068;
        IL_0068: ;
        l1 = __cil_bool_store(s13_0);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v27 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v28 = v27.policy;
        int v29 = __cil_bool_load(__cil_callvirt_060014A4(v28));
        if (v29 == 0) {
            goto IL_0084;
        } else {
            goto IL_0076;
        }
        IL_0076: ;
        int v30 = __cil_bool_load(l1);
        if (v30 != 0) {
            goto IL_0084;
        } else {
            goto IL_0079;
        }
        IL_0079: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v31 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v32 = v31.writer;
        __cil_callvirt_060016C2(v32);
        goto IL_0084;
        IL_0084: ;
        int v33 = __cil_bool_load(l1);
        if (v33 != 0) {
            goto IL_008D;
        } else {
            goto IL_0087;
        }
        IL_0087: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v34 = this;
        __cil_callvirt_060015EE(v34);
        goto IL_008D;
        IL_008D: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v35 = switchSection;
        __cil_ref_9dfae7ca29620d476733031c377f8096a9d0f0f6 v36 = __cil_callvirt_06001F1C(v35);
        __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v37 = v36.GetEnumerator();
        l4 = v37;
        try {
            IL_009A: ;
            goto IL_00AD;
            IL_009C: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v38 = l4;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v39 = __cil_callvirt_0A0008CF(v38);
            l5 = v39;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v40 = l5;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v41 = this;
            __cil_callvirt_06001723(v40, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v41)));
            goto IL_00AD;
            IL_00AD: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v42 = l4;
            int v43 = __cil_bool_load(__cil_callvirt_0A000018(v42));
            if (v43 != 0) {
                goto IL_009C;
            } else {
                goto IL_00B6;
            }
            IL_00B6: ;
            goto IL_00C4;
        }
        finally {
            IL_00B8: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v44 = l4;
            if (v44 is null) {
                goto IL_00C3;
            } else {
                goto IL_00BC;
            }
            IL_00BC: ;
            __cil_ref_c04ccdfad9c3cc9b33bef3c5bde5ea100f8d6d7c v45 = l4;
            __cil_callvirt_0A000017(v45);
            goto IL_00C3;
            IL_00C3: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_00C4: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v46 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v47 = v46.policy;
        int v48 = __cil_bool_load(__cil_callvirt_060014A4(v47));
        if (v48 == 0) {
            goto IL_00DF;
        } else {
            goto IL_00D1;
        }
        IL_00D1: ;
        int v49 = __cil_bool_load(l1);
        if (v49 != 0) {
            goto IL_00DF;
        } else {
            goto IL_00D4;
        }
        IL_00D4: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v50 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v51 = v50.writer;
        __cil_callvirt_060016C3(v51);
        goto IL_00DF;
        IL_00DF: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v52 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection v53 = switchSection;
        __cil_callvirt_060015DC(v52, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v53)));
        return;
    }

    public virtual void VisitCaseLabel(ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel caseLabel)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(caseLabel)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v3 = __cil_callvirt_06001F24(caseLabel);
        int v4 = __cil_bool_load(__cil_callvirt_060016F9(v3));
        if (v4 == 0) {
            goto IL_0021;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v6 = ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel.DefaultKeywordRole;
        __cil_callvirt_060015E4(this, v6);
        goto IL_003F;
        IL_0021: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v8 = ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel.CaseKeywordRole;
        __cil_callvirt_060015E4(this, v8);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v12 = __cil_callvirt_06001F24(caseLabel);
        __cil_callvirt_06001723(v12, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_003F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v15 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v15);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(caseLabel)));
        return;
    }

    public virtual void VisitThrowStatement(ICSharpCode.Decompiler.CSharp.Syntax.ThrowStatement throwStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(throwStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.ThrowStatement.ThrowKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v5 = __cil_callvirt_06001F2F(throwStatement);
        int v6 = __cil_bool_load(__cil_callvirt_060016F9(v5));
        if (v6 != 0) {
            goto IL_0032;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v10 = __cil_callvirt_06001F2F(throwStatement);
        __cil_callvirt_06001723(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_0032: ;
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(throwStatement)));
        return;
    }

    public virtual void VisitTryCatchStatement(ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement tryCatchStatement)
    {
        // structural signature __cil_ref_301e7a2363ec2ec8c286e23e3316ff6f68519671 bytes=15128085011289E4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.CatchClause>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_54e24c228483a9650fb35348c853f48d0455da71 bytes=151287F8011289E4: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.CatchClause>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_301e7a2363ec2ec8c286e23e3316ff6f68519671 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.CatchClause l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement v1 = tryCatchStatement;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement.TryKeywordRole;
        __cil_callvirt_060015E4(v2, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v4 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement v5 = tryCatchStatement;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v6 = __cil_callvirt_06001F3A(v5);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v7 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v8 = v7.policy;
        int v9 = unchecked((int)(__cil_callvirt_060014DE(v8)));
        __cil_callvirt_06001635(v4, v6, unchecked((__cil_enum_020001EC)(v9)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement v10 = tryCatchStatement;
        __cil_ref_54e24c228483a9650fb35348c853f48d0455da71 v11 = __cil_callvirt_06001F3C(v10);
        __cil_ref_301e7a2363ec2ec8c286e23e3316ff6f68519671 v12 = v11.GetEnumerator();
        l0 = v12;
        try {
            IL_0035: ;
            goto IL_0062;
            IL_0037: ;
            __cil_ref_301e7a2363ec2ec8c286e23e3316ff6f68519671 v13 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.CatchClause v14 = __cil_callvirt_0A0009E3(v13);
            l1 = v14;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v16 = v15.policy;
            int v17 = unchecked((int)(__cil_callvirt_060014E8(v16)));
            int v18 = 2;
            if (unchecked((uint)v17) != unchecked((uint)v18)) {
                goto IL_0055;
            } else {
                goto IL_004C;
            }
            IL_004C: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v19 = this;
            int v20 = 1;
            __cil_callvirt_060015ED(v19, __cil_bool_store(v20));
            goto IL_005B;
            IL_0055: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v21 = this;
            __cil_callvirt_060015EE(v21);
            goto IL_005B;
            IL_005B: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.CatchClause v22 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v23 = this;
            __cil_callvirt_06001723(v22, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v23)));
            goto IL_0062;
            IL_0062: ;
            __cil_ref_301e7a2363ec2ec8c286e23e3316ff6f68519671 v24 = l0;
            int v25 = __cil_bool_load(__cil_callvirt_0A000018(v24));
            if (v25 != 0) {
                goto IL_0037;
            } else {
                goto IL_006A;
            }
            IL_006A: ;
            goto IL_0076;
        }
        finally {
            IL_006C: ;
            __cil_ref_301e7a2363ec2ec8c286e23e3316ff6f68519671 v26 = l0;
            if (v26 is null) {
                goto IL_0075;
            } else {
                goto IL_006F;
            }
            IL_006F: ;
            __cil_ref_301e7a2363ec2ec8c286e23e3316ff6f68519671 v27 = l0;
            __cil_callvirt_0A000017(v27);
            goto IL_0075;
            IL_0075: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0076: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement v28 = tryCatchStatement;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v29 = __cil_callvirt_06001F3E(v28);
        int v30 = __cil_bool_load(__cil_callvirt_060016F9(v29));
        if (v30 != 0) {
            goto IL_00C2;
        } else {
            goto IL_0083;
        }
        IL_0083: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v31 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v32 = v31.policy;
        int v33 = unchecked((int)(__cil_callvirt_060014EA(v32)));
        int v34 = 2;
        if (unchecked((uint)v33) != unchecked((uint)v34)) {
            goto IL_009A;
        } else {
            goto IL_0091;
        }
        IL_0091: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v35 = this;
        int v36 = 1;
        __cil_callvirt_060015ED(v35, __cil_bool_store(v36));
        goto IL_00A0;
        IL_009A: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v37 = this;
        __cil_callvirt_060015EE(v37);
        goto IL_00A0;
        IL_00A0: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v38 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v39 = ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement.FinallyKeywordRole;
        __cil_callvirt_060015E4(v38, v39);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v40 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement v41 = tryCatchStatement;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v42 = __cil_callvirt_06001F3E(v41);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v43 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v44 = v43.policy;
        int v45 = unchecked((int)(__cil_callvirt_060014DE(v44)));
        __cil_callvirt_06001635(v40, v42, unchecked((__cil_enum_020001EC)(v45)));
        goto IL_00C2;
        IL_00C2: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v46 = this;
        __cil_callvirt_060015EE(v46);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v47 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement v48 = tryCatchStatement;
        __cil_callvirt_060015DC(v47, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v48)));
        return;
    }

    public virtual void VisitCatchClause(ICSharpCode.Decompiler.CSharp.Syntax.CatchClause catchClause)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(catchClause)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.CatchClause.CatchKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v5 = __cil_callvirt_06001F4A(catchClause);
        int v6 = __cil_bool_load(__cil_callvirt_060016F9(v5));
        if (v6 != 0) {
            goto IL_008A;
        } else {
            goto IL_001F;
        }
        IL_001F: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v9 = this.policy;
        int v10 = __cil_bool_load(__cil_callvirt_06001536(v9));
        __cil_callvirt_060015ED(this, __cil_bool_store(v10));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v14 = this.policy;
        int v15 = __cil_bool_load(__cil_callvirt_06001560(v14));
        __cil_callvirt_060015ED(this, __cil_bool_store(v15));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v17 = __cil_callvirt_06001F4A(catchClause);
        __cil_callvirt_06001723(v17, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        string v20 = __cil_callvirt_06001F4C(catchClause);
        int v21 = __cil_bool_load(System.String.IsNullOrEmpty(v20));
        if (v21 != 0) {
            goto IL_0073;
        } else {
            goto IL_0060;
        }
        IL_0060: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v26 = __cil_callvirt_06001F4E(catchClause);
        __cil_callvirt_060015E6(this, v26);
        IL_0073: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v29 = this.policy;
        int v30 = __cil_bool_load(__cil_callvirt_06001560(v29));
        __cil_callvirt_060015ED(this, __cil_bool_store(v30));
        __cil_callvirt_060015EB(this);
        IL_008A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v33 = __cil_callvirt_06001F52(catchClause);
        int v34 = __cil_bool_load(__cil_callvirt_060016F9(v33));
        if (v34 != 0) {
            goto IL_00F4;
        } else {
            goto IL_0097;
        }
        IL_0097: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v38 = ICSharpCode.Decompiler.CSharp.Syntax.CatchClause.WhenKeywordRole;
        __cil_callvirt_060015E4(this, v38);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v41 = this.policy;
        int v42 = __cil_bool_load(__cil_callvirt_0600152E(v41));
        __cil_callvirt_060015ED(this, __cil_bool_store(v42));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v46 = this.policy;
        int v47 = __cil_bool_load(__cil_callvirt_06001558(v46));
        __cil_callvirt_060015ED(this, __cil_bool_store(v47));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v49 = __cil_callvirt_06001F52(catchClause);
        __cil_callvirt_06001723(v49, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v53 = this.policy;
        int v54 = __cil_bool_load(__cil_callvirt_06001558(v53));
        __cil_callvirt_060015ED(this, __cil_bool_store(v54));
        __cil_callvirt_060015EB(this);
        IL_00F4: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v58 = __cil_callvirt_06001F54(catchClause);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v60 = this.policy;
        int v61 = unchecked((int)(__cil_callvirt_060014DE(v60)));
        __cil_callvirt_06001635(this, v58, unchecked((__cil_enum_020001EC)(v61)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(catchClause)));
        return;
    }

    public virtual void VisitUncheckedStatement(ICSharpCode.Decompiler.CSharp.Syntax.UncheckedStatement uncheckedStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(uncheckedStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.UncheckedStatement.UncheckedKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v5 = __cil_callvirt_06001F5D(uncheckedStatement);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(uncheckedStatement)));
        return;
    }

    public virtual void VisitUnsafeStatement(ICSharpCode.Decompiler.CSharp.Syntax.UnsafeStatement unsafeStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(unsafeStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.UnsafeStatement.UnsafeKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v5 = __cil_callvirt_06001F67(unsafeStatement);
        __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(unsafeStatement)));
        return;
    }

    public virtual void VisitUsingStatement(ICSharpCode.Decompiler.CSharp.Syntax.UsingStatement usingStatement)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.UsingStatement.UsingKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_0600153C(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_06001566(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v14 = __cil_callvirt_06001F71(usingStatement);
        __cil_callvirt_06001723(v14, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v18 = this.policy;
        int v19 = __cil_bool_load(__cil_callvirt_06001566(v18));
        __cil_callvirt_060015ED(this, __cil_bool_store(v19));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v23 = __cil_callvirt_06001F74(usingStatement);
        __cil_callvirt_060015F6(this, v23, unchecked((__cil_enum_020001EF)(1)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingStatement)));
        return;
    }

    public virtual void VisitVariableDeclarationStatement(ICSharpCode.Decompiler.CSharp.Syntax.VariableDeclarationStatement variableDeclarationStatement)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 bytes=151287F801128A64: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.VariableInitializer>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_005c296b94a0347c85138bf1eafd91cc005eddaa bytes=1512897C01128808: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9c98372bbcd7b8b4fb8509d3e4f8c4c038ed9710 bytes=151287F801128808: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(variableDeclarationStatement)));
        __cil_ref_005c296b94a0347c85138bf1eafd91cc005eddaa v4 = ICSharpCode.Decompiler.CSharp.Syntax.VariableDeclarationStatement.ModifierRole;
        __cil_ref_9c98372bbcd7b8b4fb8509d3e4f8c4c038ed9710 v5 = __cil_callvirt_2B00025C(variableDeclarationStatement, v4);
        __cil_callvirt_060015F4(this, ((__cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f)(v5)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v7 = __cil_callvirt_06001F80(variableDeclarationStatement);
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 v13 = __cil_callvirt_06001F82(variableDeclarationStatement);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v13)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(variableDeclarationStatement)));
        return;
    }

    public virtual void VisitWhileStatement(ICSharpCode.Decompiler.CSharp.Syntax.WhileStatement whileStatement)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(whileStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.WhileStatement.WhileKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v6 = this.policy;
        int v7 = __cil_bool_load(__cil_callvirt_06001530(v6));
        __cil_callvirt_060015ED(this, __cil_bool_store(v7));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v11 = this.policy;
        int v12 = __cil_bool_load(__cil_callvirt_0600155A(v11));
        __cil_callvirt_060015ED(this, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v14 = __cil_callvirt_06001F8C(whileStatement);
        __cil_callvirt_06001723(v14, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v18 = this.policy;
        int v19 = __cil_bool_load(__cil_callvirt_0600155A(v18));
        __cil_callvirt_060015ED(this, __cil_bool_store(v19));
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Statement v23 = __cil_callvirt_06001F8F(whileStatement);
        __cil_callvirt_060015F6(this, v23, unchecked((__cil_enum_020001EF)(1)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(whileStatement)));
        return;
    }

    public virtual void VisitYieldBreakStatement(ICSharpCode.Decompiler.CSharp.Syntax.YieldBreakStatement yieldBreakStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(yieldBreakStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.YieldBreakStatement.YieldKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.YieldBreakStatement.BreakKeywordRole;
        __cil_callvirt_060015E4(this, v5);
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(yieldBreakStatement)));
        return;
    }

    public virtual void VisitYieldReturnStatement(ICSharpCode.Decompiler.CSharp.Syntax.YieldReturnStatement yieldReturnStatement)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(yieldReturnStatement)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.YieldReturnStatement.YieldKeywordRole;
        __cil_callvirt_060015E4(this, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.YieldReturnStatement.ReturnKeywordRole;
        __cil_callvirt_060015E4(this, v5);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v9 = __cil_callvirt_06001FA3(yieldReturnStatement);
        __cil_callvirt_06001723(v9, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(yieldReturnStatement)));
        return;
    }

    public virtual void VisitAccessor(ICSharpCode.Decompiler.CSharp.Syntax.Accessor accessor)
    {
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf bytes=1512897C01128A18: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Accessor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_020001EC l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(accessor)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(accessor);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(accessor);
        __cil_callvirt_060015F4(this, v7);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v9 = this.policy;
        int v10 = unchecked((int)(__cil_callvirt_060014DE(v9)));
        l0 = unchecked((__cil_enum_020001EC)(v10));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v12 = __cil_callvirt_060016FF(accessor);
        __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v13 = ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration.GetterRole;
        if (!System.Object.ReferenceEquals(v12, v13)) {
            goto IL_0056;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        string v15 = __cil_ldstr_700086D2("get");
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v16 = ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration.GetKeywordRole;
        __cil_callvirt_060015E5(this, v15, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v16)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v18 = this.policy;
        int v19 = unchecked((int)(__cil_callvirt_060014CC(v18)));
        l0 = unchecked((__cil_enum_020001EC)(v19));
        goto IL_00D5;
        IL_0056: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v21 = __cil_callvirt_060016FF(accessor);
        __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v22 = ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration.SetterRole;
        if (!System.Object.ReferenceEquals(v21, v22)) {
            goto IL_0081;
        } else {
            goto IL_0063;
        }
        IL_0063: ;
        string v24 = __cil_ldstr_700086DE("set");
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v25 = ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration.SetKeywordRole;
        __cil_callvirt_060015E5(this, v24, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v25)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v27 = this.policy;
        int v28 = unchecked((int)(__cil_callvirt_060014CE(v27)));
        l0 = unchecked((__cil_enum_020001EC)(v28));
        goto IL_00D5;
        IL_0081: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v30 = __cil_callvirt_060016FF(accessor);
        __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v31 = ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration.AddAccessorRole;
        if (!System.Object.ReferenceEquals(v30, v31)) {
            goto IL_00AC;
        } else {
            goto IL_008E;
        }
        IL_008E: ;
        string v33 = __cil_ldstr_70004BD5("add");
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v34 = ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration.AddKeywordRole;
        __cil_callvirt_060015E5(this, v33, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v34)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v36 = this.policy;
        int v37 = unchecked((int)(__cil_callvirt_060014D6(v36)));
        l0 = unchecked((__cil_enum_020001EC)(v37));
        goto IL_00D5;
        IL_00AC: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v39 = __cil_callvirt_060016FF(accessor);
        __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v40 = ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration.RemoveAccessorRole;
        if (!System.Object.ReferenceEquals(v39, v40)) {
            goto IL_00D5;
        } else {
            goto IL_00B9;
        }
        IL_00B9: ;
        string v42 = __cil_ldstr_700087E4("remove");
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v43 = ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration.RemoveKeywordRole;
        __cil_callvirt_060015E5(this, v42, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v43)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v45 = this.policy;
        int v46 = unchecked((int)(__cil_callvirt_060014D8(v45)));
        l0 = unchecked((__cil_enum_020001EC)(v46));
        IL_00D5: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v49 = __cil_callvirt_06001FDB(accessor);
        int v50 = unchecked((int)(l0));
        __cil_callvirt_060015F7(this, v49, unchecked((__cil_enum_020001EC)(v50)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(accessor)));
        return;
    }

    public virtual void VisitConstructorDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.ConstructorDeclaration constructorDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constructorDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(constructorDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(constructorDeclaration);
        __cil_callvirt_060015F4(this, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v9 = __cil_callvirt_060016FE(constructorDeclaration);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v10 = ((object)v9 as ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration);
        l0 = v10;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v11 = l0;
        if (v11 is null) {
            goto IL_0059;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v12 = l0;
        string v13 = __cil_callvirt_06002012(v12);
        string v15 = __cil_callvirt_06002012(constructorDeclaration);
        int v16 = __cil_bool_load(System.String.op_Inequality(v13, v15));
        if (v16 == 0) {
            goto IL_0059;
        } else {
            goto IL_0041;
        }
        IL_0041: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v18 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v19 = __cil_callvirt_06002014(v18);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v20 = __cil_callvirt_06001721(v19);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v21 = ((ICSharpCode.Decompiler.CSharp.Syntax.Identifier)(object)v20);
        __cil_callvirt_060015E6(this, v21);
        goto IL_0065;
        IL_0059: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v24 = __cil_callvirt_06002014(constructorDeclaration);
        __cil_callvirt_060015E6(this, v24);
        IL_0065: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v27 = this.policy;
        int v28 = __cil_bool_load(__cil_callvirt_0600150C(v27));
        __cil_callvirt_060015ED(this, __cil_bool_store(v28));
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v31 = __cil_callvirt_06001FE5(constructorDeclaration);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v33 = this.policy;
        int v34 = __cil_bool_load(__cil_callvirt_060014F8(v33));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v31)), __cil_bool_store(v34));
        global::ICSharpCode.Decompiler.CSharp.Syntax.ConstructorInitializer v36 = __cil_callvirt_06001FE8(constructorDeclaration);
        int v37 = __cil_bool_load(__cil_callvirt_060016F9(v36));
        if (v37 != 0) {
            goto IL_00AD;
        } else {
            goto IL_009A;
        }
        IL_009A: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.ConstructorInitializer v41 = __cil_callvirt_06001FE8(constructorDeclaration);
        __cil_callvirt_06001723(v41, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_00AD: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v45 = __cil_callvirt_06001FEA(constructorDeclaration);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v47 = this.policy;
        int v48 = unchecked((int)(__cil_callvirt_060014C6(v47)));
        __cil_callvirt_060015F7(this, v45, unchecked((__cil_enum_020001EC)(v48)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constructorDeclaration)));
        return;
    }

    public virtual void VisitConstructorInitializer(ICSharpCode.Decompiler.CSharp.Syntax.ConstructorInitializer constructorInitializer)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c bytes=151287F80112886C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Expression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000288 alias=__cil_enum_02000288 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@ConstructorInitializerType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constructorInitializer)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v3);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        int v7 = unchecked((int)(__cil_callvirt_06001FF3(constructorInitializer)));
        if (unchecked((uint)v7) != unchecked((uint)2)) {
            goto IL_002F;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v10 = ICSharpCode.Decompiler.CSharp.Syntax.ConstructorInitializer.ThisKeywordRole;
        __cil_callvirt_060015E4(this, v10);
        goto IL_003A;
        IL_002F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.ConstructorInitializer.BaseKeywordRole;
        __cil_callvirt_060015E4(this, v12);
        IL_003A: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v15 = this.policy;
        int v16 = __cil_bool_load(__cil_callvirt_060014FA(v15));
        __cil_callvirt_060015ED(this, __cil_bool_store(v16));
        __cil_ref_181df90001bd214d96ce4746ea50a337e1a00a9c v19 = __cil_callvirt_06001FF7(constructorInitializer);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v21 = this.policy;
        int v22 = __cil_bool_load(__cil_callvirt_06001502(v21));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v19)), __cil_bool_store(v22));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constructorInitializer)));
        return;
    }

    public virtual void VisitDestructorDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.DestructorDeclaration destructorDeclaration)
    {
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(destructorDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(destructorDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(destructorDeclaration);
        __cil_callvirt_060015F4(this, v7);
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v9 = __cil_callvirt_06002011(destructorDeclaration);
        int v10 = __cil_bool_load(__cil_methodspec_call_2B00025D(v9));
        if (v10 == 0) {
            goto IL_0033;
        } else {
            goto IL_002C;
        }
        IL_002C: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        IL_0033: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v14 = ICSharpCode.Decompiler.CSharp.Syntax.DestructorDeclaration.TildeRole;
        __cil_callvirt_060015E8(this, v14);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v16 = __cil_callvirt_060016FE(destructorDeclaration);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v17 = ((object)v16 as ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration);
        l0 = v17;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v18 = l0;
        if (v18 is null) {
            goto IL_0078;
        } else {
            goto IL_004D;
        }
        IL_004D: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v19 = l0;
        string v20 = __cil_callvirt_06002012(v19);
        string v22 = __cil_callvirt_06002012(destructorDeclaration);
        int v23 = __cil_bool_load(System.String.op_Inequality(v20, v22));
        if (v23 == 0) {
            goto IL_0078;
        } else {
            goto IL_0060;
        }
        IL_0060: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration v25 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v26 = __cil_callvirt_06002014(v25);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v27 = __cil_callvirt_06001721(v26);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v28 = ((ICSharpCode.Decompiler.CSharp.Syntax.Identifier)(object)v27);
        __cil_callvirt_060015E6(this, v28);
        goto IL_0084;
        IL_0078: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v31 = __cil_callvirt_06002014(destructorDeclaration);
        __cil_callvirt_060015E6(this, v31);
        IL_0084: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v34 = this.policy;
        int v35 = __cil_bool_load(__cil_callvirt_0600150C(v34));
        __cil_callvirt_060015ED(this, __cil_bool_store(v35));
        __cil_callvirt_060015EA(this);
        __cil_callvirt_060015EB(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v40 = __cil_callvirt_06002003(destructorDeclaration);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v42 = this.policy;
        int v43 = unchecked((int)(__cil_callvirt_060014C8(v42)));
        __cil_callvirt_060015F7(this, v40, unchecked((__cil_enum_020001EC)(v43)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(destructorDeclaration)));
        return;
    }

    public virtual void VisitEnumMemberDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.EnumMemberDeclaration enumMemberDeclaration)
    {
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(enumMemberDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(enumMemberDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(enumMemberDeclaration);
        __cil_callvirt_060015F4(this, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v10 = __cil_callvirt_06002014(enumMemberDeclaration);
        __cil_callvirt_060015E6(this, v10);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v12 = __cil_callvirt_06002020(enumMemberDeclaration);
        int v13 = __cil_bool_load(__cil_callvirt_060016F9(v12));
        if (v13 != 0) {
            goto IL_0071;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v16 = this.policy;
        int v17 = __cil_bool_load(__cil_callvirt_0600153E(v16));
        __cil_callvirt_060015ED(this, __cil_bool_store(v17));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v19 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Assign;
        __cil_callvirt_060015E8(this, v19);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v22 = this.policy;
        int v23 = __cil_bool_load(__cil_callvirt_0600153E(v22));
        __cil_callvirt_060015ED(this, __cil_bool_store(v23));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v25 = __cil_callvirt_06002020(enumMemberDeclaration);
        __cil_callvirt_06001723(v25, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_0071: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(enumMemberDeclaration)));
        return;
    }

    public virtual void VisitEventDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.EventDeclaration eventDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 bytes=151287F801128A64: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.VariableInitializer>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(eventDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(eventDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(eventDeclaration);
        __cil_callvirt_060015F4(this, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.EventDeclaration.EventKeywordRole;
        __cil_callvirt_060015E4(this, v9);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v11 = __cil_callvirt_06002016(eventDeclaration);
        __cil_callvirt_06001723(v11, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 v17 = __cil_callvirt_0600202A(eventDeclaration);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v17)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(eventDeclaration)));
        return;
    }

    public virtual void VisitCustomEventDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration customEventDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 bytes=15128085011287F4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf bytes=1512897C01128A18: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Accessor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v1 = customEventDeclaration;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v3 = customEventDeclaration;
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(v3);
        __cil_callvirt_060015F8(v2, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v6 = customEventDeclaration;
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(v6);
        __cil_callvirt_060015F4(v5, v7);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v8 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration.EventKeywordRole;
        __cil_callvirt_060015E4(v8, v9);
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v10 = customEventDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v11 = __cil_callvirt_06002016(v10);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v12 = this;
        __cil_callvirt_06001723(v11, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v12)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        int v14 = 1;
        __cil_callvirt_060015ED(v13, __cil_bool_store(v14));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v16 = customEventDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v17 = __cil_callvirt_06002036(v16);
        __cil_callvirt_060015F9(v15, v17);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v18 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v19 = customEventDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v20 = __cil_callvirt_06002014(v19);
        __cil_callvirt_060015E6(v18, v20);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v21 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v22 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v23 = v22.policy;
        int v24 = unchecked((int)(__cil_callvirt_060014D4(v23)));
        __cil_callvirt_060015EF(v21, unchecked((__cil_enum_020001EC)(v24)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v25 = customEventDeclaration;
        __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 v26 = __cil_callvirt_06001708(v25);
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v27 = __cil_callvirt_0A00008A(v26);
        l0 = v27;
        try {
            IL_0072: ;
            goto IL_009C;
            IL_0074: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v28 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v29 = __cil_callvirt_0A000089(v28);
            l1 = v29;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v30 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Role v31 = __cil_callvirt_060016FF(v30);
            __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v32 = ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration.AddAccessorRole;
            if (System.Object.ReferenceEquals(v31, v32)) {
                goto IL_0095;
            } else {
                goto IL_0088;
            }
            IL_0088: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v33 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Role v34 = __cil_callvirt_060016FF(v33);
            __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v35 = ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration.RemoveAccessorRole;
            if (!System.Object.ReferenceEquals(v34, v35)) {
                goto IL_009C;
            } else {
                goto IL_0095;
            }
            IL_0095: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v36 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v37 = this;
            __cil_callvirt_06001723(v36, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v37)));
            goto IL_009C;
            IL_009C: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v38 = l0;
            int v39 = __cil_bool_load(__cil_callvirt_0A000018(v38));
            if (v39 != 0) {
                goto IL_0074;
            } else {
                goto IL_00A4;
            }
            IL_00A4: ;
            goto IL_00B0;
        }
        finally {
            IL_00A6: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v40 = l0;
            if (v40 is null) {
                goto IL_00AF;
            } else {
                goto IL_00A9;
            }
            IL_00A9: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v41 = l0;
            __cil_callvirt_0A000017(v41);
            goto IL_00AF;
            IL_00AF: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00B0: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v42 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v43 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v44 = v43.policy;
        int v45 = unchecked((int)(__cil_callvirt_060014D4(v44)));
        __cil_callvirt_060015F0(v42, unchecked((__cil_enum_020001EC)(v45)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v46 = this;
        __cil_callvirt_060015EE(v46);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v47 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration v48 = customEventDeclaration;
        __cil_callvirt_060015DC(v47, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v48)));
        return;
    }

    public virtual void VisitFieldDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.FieldDeclaration fieldDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 bytes=151287F801128A64: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.VariableInitializer>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fieldDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(fieldDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(fieldDeclaration);
        __cil_callvirt_060015F4(this, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v9 = __cil_callvirt_06002016(fieldDeclaration);
        __cil_callvirt_06001723(v9, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        __cil_ref_2db7100dbd4f2ced1fb591ced50d76a7e18af775 v15 = __cil_callvirt_06002045(fieldDeclaration);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v15)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fieldDeclaration)));
        return;
    }

    public virtual void VisitFixedFieldDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.FixedFieldDeclaration fixedFieldDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f667883989a0e5ebdba94ed65ecd938b46edbea1 bytes=151287F801128A44: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.FixedVariableInitializer>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedFieldDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(fixedFieldDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(fixedFieldDeclaration);
        __cil_callvirt_060015F4(this, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.FixedFieldDeclaration.FixedKeywordRole;
        __cil_callvirt_060015E4(this, v9);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v13 = __cil_callvirt_06002016(fixedFieldDeclaration);
        __cil_callvirt_06001723(v13, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        __cil_ref_f667883989a0e5ebdba94ed65ecd938b46edbea1 v19 = __cil_callvirt_06002051(fixedFieldDeclaration);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v19)));
        __cil_callvirt_060015EC(this);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedFieldDeclaration)));
        return;
    }

    public virtual void VisitFixedVariableInitializer(ICSharpCode.Decompiler.CSharp.Syntax.FixedVariableInitializer fixedVariableInitializer)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedVariableInitializer)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v4 = __cil_callvirt_0600205D(fixedVariableInitializer);
        __cil_callvirt_060015E6(this, v4);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v6 = __cil_callvirt_06002060(fixedVariableInitializer);
        int v7 = __cil_bool_load(__cil_callvirt_060016F9(v6));
        if (v7 != 0) {
            goto IL_0064;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBracket;
        __cil_callvirt_060015E8(this, v9);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v12 = this.policy;
        int v13 = __cil_bool_load(__cil_callvirt_06001584(v12));
        __cil_callvirt_060015ED(this, __cil_bool_store(v13));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v15 = __cil_callvirt_06002060(fixedVariableInitializer);
        __cil_callvirt_06001723(v15, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v19 = this.policy;
        int v20 = __cil_bool_load(__cil_callvirt_06001584(v19));
        __cil_callvirt_060015ED(this, __cil_bool_store(v20));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v22 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBracket;
        __cil_callvirt_060015E8(this, v22);
        IL_0064: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedVariableInitializer)));
        return;
    }

    public virtual void VisitIndexerDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration indexerDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 bytes=15128085011287F4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5 bytes=1512809101128A5C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf bytes=1512897C01128A18: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Accessor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v1 = indexerDeclaration;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v3 = indexerDeclaration;
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(v3);
        __cil_callvirt_060015F8(v2, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v6 = indexerDeclaration;
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(v6);
        __cil_callvirt_060015F4(v5, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v8 = indexerDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v9 = __cil_callvirt_06002016(v8);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v10 = this;
        __cil_callvirt_06001723(v9, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v10)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
        int v12 = 1;
        __cil_callvirt_060015ED(v11, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v14 = indexerDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v15 = __cil_callvirt_06002068(v14);
        __cil_callvirt_060015F9(v13, v15);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v16 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v17 = ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration.ThisKeywordRole;
        __cil_callvirt_060015E4(v16, v17);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v18 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v19 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v20 = v19.policy;
        int v21 = __cil_bool_load(__cil_callvirt_060014F0(v20));
        __cil_callvirt_060015ED(v18, __cil_bool_store(v21));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v22 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v23 = indexerDeclaration;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v24 = __cil_callvirt_06002070(v23);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v25 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v26 = v25.policy;
        int v27 = __cil_bool_load(__cil_callvirt_060014F8(v26));
        __cil_callvirt_060015E2(v22, ((__cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5)(v24)), __cil_bool_store(v27));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v29 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v30 = v29.policy;
        int v31 = unchecked((int)(__cil_callvirt_060014CA(v30)));
        __cil_callvirt_060015EF(v28, unchecked((__cil_enum_020001EC)(v31)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v32 = indexerDeclaration;
        __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 v33 = __cil_callvirt_06001708(v32);
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v34 = __cil_callvirt_0A00008A(v33);
        l0 = v34;
        try {
            IL_008E: ;
            goto IL_00B8;
            IL_0090: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v35 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v36 = __cil_callvirt_0A000089(v35);
            l1 = v36;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v37 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Role v38 = __cil_callvirt_060016FF(v37);
            __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v39 = ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration.GetterRole;
            if (System.Object.ReferenceEquals(v38, v39)) {
                goto IL_00B1;
            } else {
                goto IL_00A4;
            }
            IL_00A4: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v40 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Role v41 = __cil_callvirt_060016FF(v40);
            __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v42 = ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration.SetterRole;
            if (!System.Object.ReferenceEquals(v41, v42)) {
                goto IL_00B8;
            } else {
                goto IL_00B1;
            }
            IL_00B1: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v43 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v44 = this;
            __cil_callvirt_06001723(v43, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v44)));
            goto IL_00B8;
            IL_00B8: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v45 = l0;
            int v46 = __cil_bool_load(__cil_callvirt_0A000018(v45));
            if (v46 != 0) {
                goto IL_0090;
            } else {
                goto IL_00C0;
            }
            IL_00C0: ;
            goto IL_00CC;
        }
        finally {
            IL_00C2: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v47 = l0;
            if (v47 is null) {
                goto IL_00CB;
            } else {
                goto IL_00C5;
            }
            IL_00C5: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v48 = l0;
            __cil_callvirt_0A000017(v48);
            goto IL_00CB;
            IL_00CB: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00CC: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v49 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v50 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v51 = v50.policy;
        int v52 = unchecked((int)(__cil_callvirt_060014CA(v51)));
        __cil_callvirt_060015F0(v49, unchecked((__cil_enum_020001EC)(v52)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v53 = this;
        __cil_callvirt_060015EE(v53);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v54 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration v55 = indexerDeclaration;
        __cil_callvirt_060015DC(v54, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v55)));
        return;
    }

    public virtual void VisitMethodDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration methodDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_30a8632852da3c5edefb0e9e64c055e7cbc55304 bytes=1512809101128944: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 bytes=1512808501128914: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.Constraint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d9a3c927255fbcbd7902130ddf4a158447d5b197 bytes=151287F801128944: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e2072c6b6e24754d21b5166074c8ca9c61d85f2b bytes=151287F801128914: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.Constraint>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.Constraint l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v1 = methodDeclaration;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v3 = methodDeclaration;
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(v3);
        __cil_callvirt_060015F8(v2, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v6 = methodDeclaration;
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(v6);
        __cil_callvirt_060015F4(v5, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v8 = methodDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v9 = __cil_callvirt_06002016(v8);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v10 = this;
        __cil_callvirt_06001723(v9, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v10)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
        int v12 = 1;
        __cil_callvirt_060015ED(v11, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v14 = methodDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v15 = __cil_callvirt_0600207F(v14);
        __cil_callvirt_060015F9(v13, v15);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v16 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v17 = methodDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v18 = __cil_callvirt_06002014(v17);
        __cil_callvirt_060015E6(v16, v18);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v19 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v20 = methodDeclaration;
        __cil_ref_d9a3c927255fbcbd7902130ddf4a158447d5b197 v21 = __cil_callvirt_06002081(v20);
        __cil_callvirt_060015F3(v19, ((__cil_ref_30a8632852da3c5edefb0e9e64c055e7cbc55304)(v21)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v22 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v23 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v24 = v23.policy;
        int v25 = __cil_bool_load(__cil_callvirt_060014F0(v24));
        __cil_callvirt_060015ED(v22, __cil_bool_store(v25));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v26 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v27 = methodDeclaration;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v28 = __cil_callvirt_06002083(v27);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v29 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v30 = v29.policy;
        int v31 = __cil_bool_load(__cil_callvirt_060014F8(v30));
        __cil_callvirt_060015E1(v26, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v28)), __cil_bool_store(v31));
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v32 = methodDeclaration;
        __cil_ref_e2072c6b6e24754d21b5166074c8ca9c61d85f2b v33 = __cil_callvirt_06002085(v32);
        __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v34 = v33.GetEnumerator();
        l0 = v34;
        try {
            IL_008A: ;
            goto IL_009A;
            IL_008C: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v35 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Constraint v36 = __cil_callvirt_0A0009DC(v35);
            l1 = v36;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Constraint v37 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v38 = this;
            __cil_callvirt_06001723(v37, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v38)));
            goto IL_009A;
            IL_009A: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v39 = l0;
            int v40 = __cil_bool_load(__cil_callvirt_0A000018(v39));
            if (v40 != 0) {
                goto IL_008C;
            } else {
                goto IL_00A2;
            }
            IL_00A2: ;
            goto IL_00AE;
        }
        finally {
            IL_00A4: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v41 = l0;
            if (v41 is null) {
                goto IL_00AD;
            } else {
                goto IL_00A7;
            }
            IL_00A7: ;
            __cil_ref_026ad836e6863c26ea9d642eff8df83aa5baffe0 v42 = l0;
            __cil_callvirt_0A000017(v42);
            goto IL_00AD;
            IL_00AD: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00AE: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v43 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v44 = methodDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v45 = __cil_callvirt_06002086(v44);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v46 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v47 = v46.policy;
        int v48 = unchecked((int)(__cil_callvirt_060014C2(v47)));
        __cil_callvirt_060015F7(v43, v45, unchecked((__cil_enum_020001EC)(v48)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v49 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration v50 = methodDeclaration;
        __cil_callvirt_060015DC(v49, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v50)));
        return;
    }

    public virtual void VisitOperatorDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration operatorDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000294 alias=__cil_enum_02000294 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@OperatorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(operatorDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(operatorDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(operatorDeclaration);
        __cil_callvirt_060015F4(this, v7);
        int v9 = unchecked((int)(__cil_callvirt_06002090(operatorDeclaration)));
        if (unchecked((uint)v9) != unchecked((uint)25)) {
            goto IL_0036;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.ExplicitRole;
        __cil_callvirt_060015E4(this, v12);
        goto IL_0059;
        IL_0036: ;
        int v14 = unchecked((int)(__cil_callvirt_06002090(operatorDeclaration)));
        if (unchecked((uint)v14) != unchecked((uint)24)) {
            goto IL_004D;
        } else {
            goto IL_0040;
        }
        IL_0040: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v17 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.ImplicitRole;
        __cil_callvirt_060015E4(this, v17);
        goto IL_0059;
        IL_004D: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v19 = __cil_callvirt_06002016(operatorDeclaration);
        __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_0059: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v22 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.OperatorKeywordRole;
        __cil_callvirt_060015E4(this, v22);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        int v26 = unchecked((int)(__cil_callvirt_06002090(operatorDeclaration)));
        if (v26 == 25) {
            goto IL_007F;
        } else {
            goto IL_0075;
        }
        IL_0075: ;
        int v29 = unchecked((int)(__cil_callvirt_06002090(operatorDeclaration)));
        if (unchecked((uint)v29) != unchecked((uint)24)) {
            goto IL_008D;
        } else {
            goto IL_007F;
        }
        IL_007F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v32 = __cil_callvirt_06002016(operatorDeclaration);
        __cil_callvirt_06001723(v32, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        goto IL_00A9;
        IL_008D: ;
        int v36 = unchecked((int)(__cil_callvirt_06002090(operatorDeclaration)));
        string v37 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.GetToken(unchecked((__cil_enum_02000294)(v36)));
        int v39 = unchecked((int)(__cil_callvirt_06002090(operatorDeclaration)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v40 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.GetRole(unchecked((__cil_enum_02000294)(v39)));
        __cil_callvirt_060015E9(this, v37, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v40)));
        IL_00A9: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v43 = this.policy;
        int v44 = __cil_bool_load(__cil_callvirt_060014F0(v43));
        __cil_callvirt_060015ED(this, __cil_bool_store(v44));
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v47 = __cil_callvirt_06002095(operatorDeclaration);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v49 = this.policy;
        int v50 = __cil_bool_load(__cil_callvirt_060014F8(v49));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v47)), __cil_bool_store(v50));
        global::ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement v53 = __cil_callvirt_06002097(operatorDeclaration);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v55 = this.policy;
        int v56 = unchecked((int)(__cil_callvirt_060014C2(v55)));
        __cil_callvirt_060015F7(this, v53, unchecked((__cil_enum_020001EC)(v56)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(operatorDeclaration)));
        return;
    }

    public virtual void VisitParameterDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration parameterDeclaration)
    {
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000296 alias=__cil_enum_02000296 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@ParameterModifier; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000296 l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(parameterDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_060020A7(parameterDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        int v6 = unchecked((int)(__cil_callvirt_060020A8(parameterDeclaration)));
        l0 = unchecked((__cil_enum_02000296)(v6));
        int v7 = unchecked((int)(l0));
        int v9 = unchecked(v7 - 1);
        switch (v9) {
            case 0: {
                goto IL_0034;
            }
            case 1: {
                goto IL_0041;
            }
            case 2: {
                goto IL_004E;
            }
            case 3: {
                goto IL_005B;
            }
            default: {
                goto IL_0032;
            } }
        IL_0032: ;
        goto IL_0066;
        IL_0034: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration.RefModifierRole;
        __cil_callvirt_060015E4(this, v11);
        goto IL_0066;
        IL_0041: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v13 = ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration.OutModifierRole;
        __cil_callvirt_060015E4(this, v13);
        goto IL_0066;
        IL_004E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v15 = ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration.ParamsModifierRole;
        __cil_callvirt_060015E4(this, v15);
        goto IL_0066;
        IL_005B: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v17 = ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration.ThisModifierRole;
        __cil_callvirt_060015E4(this, v17);
        IL_0066: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v19 = __cil_callvirt_060020AA(parameterDeclaration);
        __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v22 = __cil_callvirt_060020AA(parameterDeclaration);
        int v23 = __cil_bool_load(__cil_callvirt_060016F9(v22));
        if (v23 != 0) {
            goto IL_0093;
        } else {
            goto IL_007F;
        }
        IL_007F: ;
        string v25 = __cil_callvirt_060020AC(parameterDeclaration);
        int v26 = __cil_bool_load(System.String.IsNullOrEmpty(v25));
        if (v26 != 0) {
            goto IL_0093;
        } else {
            goto IL_008C;
        }
        IL_008C: ;
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        IL_0093: ;
        string v30 = __cil_callvirt_060020AC(parameterDeclaration);
        int v31 = __cil_bool_load(System.String.IsNullOrEmpty(v30));
        if (v31 != 0) {
            goto IL_00AC;
        } else {
            goto IL_00A0;
        }
        IL_00A0: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v34 = __cil_callvirt_060020AE(parameterDeclaration);
        __cil_callvirt_060015E6(this, v34);
        IL_00AC: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v36 = __cil_callvirt_060020B1(parameterDeclaration);
        int v37 = __cil_bool_load(__cil_callvirt_060016F9(v36));
        if (v37 != 0) {
            goto IL_00F2;
        } else {
            goto IL_00B9;
        }
        IL_00B9: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v40 = this.policy;
        int v41 = __cil_bool_load(__cil_callvirt_0600153E(v40));
        __cil_callvirt_060015ED(this, __cil_bool_store(v41));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v43 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Assign;
        __cil_callvirt_060015E8(this, v43);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v46 = this.policy;
        int v47 = __cil_bool_load(__cil_callvirt_0600153E(v46));
        __cil_callvirt_060015ED(this, __cil_bool_store(v47));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v49 = __cil_callvirt_060020B1(parameterDeclaration);
        __cil_callvirt_06001723(v49, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_00F2: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(parameterDeclaration)));
        return;
    }

    public virtual void VisitPropertyDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration propertyDeclaration)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 bytes=15128085011287F4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f bytes=1512809101128808: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf bytes=1512897C01128A18: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Accessor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v1 = propertyDeclaration;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v3 = propertyDeclaration;
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_0600200D(v3);
        __cil_callvirt_060015F8(v2, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v6 = propertyDeclaration;
        __cil_ref_525f08b3233c6009c9289135bfdb5dccfd59a60f v7 = __cil_callvirt_06002011(v6);
        __cil_callvirt_060015F4(v5, v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v8 = propertyDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v9 = __cil_callvirt_06002016(v8);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v10 = this;
        __cil_callvirt_06001723(v9, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v10)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
        int v12 = 1;
        __cil_callvirt_060015ED(v11, __cil_bool_store(v12));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v14 = propertyDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v15 = __cil_callvirt_060020BD(v14);
        __cil_callvirt_060015F9(v13, v15);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v16 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v17 = propertyDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v18 = __cil_callvirt_06002014(v17);
        __cil_callvirt_060015E6(v16, v18);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v19 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v20 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v21 = v20.policy;
        int v22 = unchecked((int)(__cil_callvirt_060014CA(v21)));
        __cil_callvirt_060015EF(v19, unchecked((__cil_enum_020001EC)(v22)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v23 = propertyDeclaration;
        __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 v24 = __cil_callvirt_06001708(v23);
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v25 = __cil_callvirt_0A00008A(v24);
        l0 = v25;
        try {
            IL_0067: ;
            goto IL_0091;
            IL_0069: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v26 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v27 = __cil_callvirt_0A000089(v26);
            l1 = v27;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v28 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Role v29 = __cil_callvirt_060016FF(v28);
            __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v30 = ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration.GetterRole;
            if (System.Object.ReferenceEquals(v29, v30)) {
                goto IL_008A;
            } else {
                goto IL_007D;
            }
            IL_007D: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v31 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.Role v32 = __cil_callvirt_060016FF(v31);
            __cil_ref_a3af7b4c537b546d737666e89ec1a45dada89dbf v33 = ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration.SetterRole;
            if (!System.Object.ReferenceEquals(v32, v33)) {
                goto IL_0091;
            } else {
                goto IL_008A;
            }
            IL_008A: ;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v34 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v35 = this;
            __cil_callvirt_06001723(v34, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v35)));
            goto IL_0091;
            IL_0091: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v36 = l0;
            int v37 = __cil_bool_load(__cil_callvirt_0A000018(v36));
            if (v37 != 0) {
                goto IL_0069;
            } else {
                goto IL_0099;
            }
            IL_0099: ;
            goto IL_00A5;
        }
        finally {
            IL_009B: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v38 = l0;
            if (v38 is null) {
                goto IL_00A4;
            } else {
                goto IL_009E;
            }
            IL_009E: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v39 = l0;
            __cil_callvirt_0A000017(v39);
            goto IL_00A4;
            IL_00A4: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00A5: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v40 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v41 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v42 = v41.policy;
        int v43 = unchecked((int)(__cil_callvirt_060014CA(v42)));
        __cil_callvirt_060015F0(v40, unchecked((__cil_enum_020001EC)(v43)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v44 = propertyDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v45 = __cil_callvirt_060020C6(v44);
        int v46 = __cil_bool_load(__cil_callvirt_060016F9(v45));
        if (v46 != 0) {
            goto IL_0102;
        } else {
            goto IL_00C3;
        }
        IL_00C3: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v47 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v48 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v49 = v48.policy;
        int v50 = __cil_bool_load(__cil_callvirt_0600153E(v49));
        __cil_callvirt_060015ED(v47, __cil_bool_store(v50));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v51 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v52 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Assign;
        __cil_callvirt_060015E8(v51, v52);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v53 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v54 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v55 = v54.policy;
        int v56 = __cil_bool_load(__cil_callvirt_0600153E(v55));
        __cil_callvirt_060015ED(v53, __cil_bool_store(v56));
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v57 = propertyDeclaration;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v58 = __cil_callvirt_060020C6(v57);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v59 = this;
        __cil_callvirt_06001723(v58, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v59)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v60 = this;
        __cil_callvirt_060015EC(v60);
        goto IL_0102;
        IL_0102: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v61 = this;
        __cil_callvirt_060015EE(v61);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v62 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration v63 = propertyDeclaration;
        __cil_callvirt_060015DC(v62, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v63)));
        return;
    }

    public virtual void VisitVariableInitializer(ICSharpCode.Decompiler.CSharp.Syntax.VariableInitializer variableInitializer)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(variableInitializer)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v4 = __cil_callvirt_060020D4(variableInitializer);
        __cil_callvirt_060015E6(this, v4);
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v6 = __cil_callvirt_060020D7(variableInitializer);
        int v7 = __cil_bool_load(__cil_callvirt_060016F9(v6));
        if (v7 != 0) {
            goto IL_0059;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v10 = this.policy;
        int v11 = __cil_bool_load(__cil_callvirt_0600153E(v10));
        __cil_callvirt_060015ED(this, __cil_bool_store(v11));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v13 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Assign;
        __cil_callvirt_060015E8(this, v13);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v16 = this.policy;
        int v17 = __cil_bool_load(__cil_callvirt_0600153E(v16));
        __cil_callvirt_060015ED(this, __cil_bool_store(v17));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Expression v19 = __cil_callvirt_060020D7(variableInitializer);
        __cil_callvirt_06001723(v19, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        IL_0059: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(variableInitializer)));
        return;
    }

    private void MaybeNewLinesAfterUsings(ICSharpCode.Decompiler.CSharp.Syntax.AstNode node)
    {
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l0 = default;
        int l1 = default;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v1 = __cil_callvirt_06001703(node);
        l0 = v1;
        goto IL_0010;
        IL_0009: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v2 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v3 = __cil_callvirt_06001703(v2);
        l0 = v3;
        IL_0010: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v4 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.WhitespaceNode v5 = ((object)v4 as ICSharpCode.Decompiler.CSharp.Syntax.WhitespaceNode);
        if (v5 is not null) {
            goto IL_0009;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v6 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.NewLineNode v7 = ((object)v6 as ICSharpCode.Decompiler.CSharp.Syntax.NewLineNode);
        if (v7 is not null) {
            goto IL_0009;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.UsingDeclaration v9 = ((object)node as ICSharpCode.Decompiler.CSharp.Syntax.UsingDeclaration);
        if (v9 is not null) {
            goto IL_0030;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration v11 = ((object)node as ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration);
        if (v11 is null) {
            goto IL_005C;
        } else {
            goto IL_0030;
        }
        IL_0030: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v12 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.UsingDeclaration v13 = ((object)v12 as ICSharpCode.Decompiler.CSharp.Syntax.UsingDeclaration);
        if (v13 is not null) {
            goto IL_005C;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v14 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration v15 = ((object)v14 as ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration);
        if (v15 is not null) {
            goto IL_005C;
        } else {
            goto IL_0040;
        }
        IL_0040: ;
        l1 = 0;
        goto IL_004E;
        IL_0044: ;
        __cil_callvirt_060015EE(this);
        int v18 = l1;
        l1 = unchecked(v18 + 1);
        IL_004E: ;
        int v21 = l1;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v23 = this.policy;
        int v24 = __cil_callvirt_0600159C(v23);
        if (v21 < v24) {
            goto IL_0044;
        } else {
            goto IL_005C;
        }
        IL_005C: ;
        return;
    }

    public virtual void VisitSyntaxTree(ICSharpCode.Decompiler.CSharp.Syntax.SyntaxTree syntaxTree)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 bytes=15128085011287F4: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.SyntaxTree v0 = syntaxTree;
        __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 v1 = __cil_callvirt_06001708(v0);
        __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v2 = __cil_callvirt_0A00008A(v1);
        l0 = v2;
        try {
            IL_000C: ;
            goto IL_0023;
            IL_000E: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v3 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v4 = __cil_callvirt_0A000089(v3);
            l1 = v4;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v5 = l1;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v6 = this;
            __cil_callvirt_06001723(v5, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v6)));
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v7 = this;
            global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v8 = l1;
            __cil_direct_06001663(v7, v8);
            goto IL_0023;
            IL_0023: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v9 = l0;
            int v10 = __cil_bool_load(__cil_callvirt_0A000018(v9));
            if (v10 != 0) {
                goto IL_000E;
            } else {
                goto IL_002B;
            }
            IL_002B: ;
            goto IL_0037;
        }
        finally {
            IL_002D: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v11 = l0;
            if (v11 is null) {
                goto IL_0036;
            } else {
                goto IL_0030;
            }
            IL_0030: ;
            __cil_ref_2471f4a20a3ecbb626e86f8e66193f5985d6f6a5 v12 = l0;
            __cil_callvirt_0A000017(v12);
            goto IL_0036;
            IL_0036: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0037: ;
        return;
    }

    public virtual void VisitSimpleType(ICSharpCode.Decompiler.CSharp.Syntax.SimpleType simpleType)
    {
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(simpleType)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v4 = __cil_callvirt_06001E2F(simpleType);
        __cil_callvirt_060015E6(this, v4);
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v7 = __cil_callvirt_06001E31(simpleType);
        __cil_callvirt_060015F2(this, ((__cil_ref_3681fa81e970b76123c0932848c13919b7088424)(v7)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(simpleType)));
        return;
    }

    public virtual void VisitMemberType(ICSharpCode.Decompiler.CSharp.Syntax.MemberType memberType)
    {
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(memberType)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v3 = __cil_callvirt_06001DFB(memberType);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        int v6 = __cil_bool_load(__cil_callvirt_06001DF9(memberType));
        if (v6 == 0) {
            goto IL_0028;
        } else {
            goto IL_001B;
        }
        IL_001B: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v8 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.DoubleColon;
        __cil_callvirt_060015E8(this, v8);
        goto IL_0033;
        IL_0028: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v10 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Dot;
        __cil_callvirt_060015E8(this, v10);
        IL_0033: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v13 = __cil_callvirt_06001DFF(memberType);
        __cil_callvirt_060015E6(this, v13);
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v16 = __cil_callvirt_06001E01(memberType);
        __cil_callvirt_060015F2(this, ((__cil_ref_3681fa81e970b76123c0932848c13919b7088424)(v16)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(memberType)));
        return;
    }

    public virtual void VisitComposedType(ICSharpCode.Decompiler.CSharp.Syntax.ComposedType composedType)
    {
        // structural signature __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 bytes=1512808501128804: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_62a86242d2772388ef825cc380712b963af99f57 bytes=151287F801128804: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 l1 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier l2 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ComposedType v1 = composedType;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.ComposedType v2 = composedType;
        int v3 = __cil_bool_load(__cil_callvirt_0600176D(v2));
        if (v3 == 0) {
            goto IL_001A;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v4 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.ComposedType.RefRole;
        __cil_callvirt_060015E4(v4, v5);
        goto IL_001A;
        IL_001A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ComposedType v6 = composedType;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v7 = __cil_callvirt_0600176F(v6);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v8 = this;
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v8)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.ComposedType v9 = composedType;
        int v10 = __cil_bool_load(__cil_callvirt_06001771(v9));
        if (v10 == 0) {
            goto IL_0039;
        } else {
            goto IL_002E;
        }
        IL_002E: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v11 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.ComposedType.NullableRole;
        __cil_callvirt_060015E8(v11, v12);
        goto IL_0039;
        IL_0039: ;
        int v13 = 0;
        l0 = v13;
        goto IL_004C;
        IL_003D: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v14 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v15 = ICSharpCode.Decompiler.CSharp.Syntax.ComposedType.PointerRole;
        __cil_callvirt_060015E8(v14, v15);
        int v16 = l0;
        int v17 = 1;
        int v18 = unchecked(v16 + v17);
        l0 = v18;
        goto IL_004C;
        IL_004C: ;
        int v19 = l0;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ComposedType v20 = composedType;
        int v21 = __cil_callvirt_06001774(v20);
        if (v19 < v21) {
            goto IL_003D;
        } else {
            goto IL_0055;
        }
        IL_0055: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ComposedType v22 = composedType;
        __cil_ref_62a86242d2772388ef825cc380712b963af99f57 v23 = __cil_callvirt_06001776(v22);
        __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v24 = v23.GetEnumerator();
        l1 = v24;
        try {
            IL_0061: ;
            goto IL_0071;
            IL_0063: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v25 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier v26 = __cil_callvirt_0A0009D8(v25);
            l2 = v26;
            global::ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier v27 = l2;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v28 = this;
            __cil_callvirt_06001723(v27, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(v28)));
            goto IL_0071;
            IL_0071: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v29 = l1;
            int v30 = __cil_bool_load(__cil_callvirt_0A000018(v29));
            if (v30 != 0) {
                goto IL_0063;
            } else {
                goto IL_0079;
            }
            IL_0079: ;
            goto IL_0085;
        }
        finally {
            IL_007B: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v31 = l1;
            if (v31 is null) {
                goto IL_0084;
            } else {
                goto IL_007E;
            }
            IL_007E: ;
            __cil_ref_884387bff31c3b5fe52755d836db76f62a489152 v32 = l1;
            __cil_callvirt_0A000017(v32);
            goto IL_0084;
            IL_0084: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0085: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v33 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ComposedType v34 = composedType;
        __cil_callvirt_060015DC(v33, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v34)));
        return;
    }

    public virtual void VisitArraySpecifier(ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier arraySpecifier)
    {
        // structural signature __cil_ref_d7fde5a64bc80c9b578cb514af618f3c4fdb0911 bytes=1512897C0112880C: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 bytes=151280850112880C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_769287a3ecca01a590cff2ad7c5cd3cc5c2315d7 bytes=151287F80112880C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier v1 = arraySpecifier;
        __cil_callvirt_060015DB(v0, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v1)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v3 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.LBracket;
        __cil_callvirt_060015E8(v2, v3);
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier v4 = arraySpecifier;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Comma;
        __cil_ref_769287a3ecca01a590cff2ad7c5cd3cc5c2315d7 v6 = __cil_callvirt_2B00025E(v4, ((__cil_ref_d7fde5a64bc80c9b578cb514af618f3c4fdb0911)(v5)));
        __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v7 = v6.GetEnumerator();
        l0 = v7;
        try {
            IL_0023: ;
            goto IL_0041;
            IL_0025: ;
            __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v8 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode v9 = __cil_callvirt_0A0009E5(v8);
            l1 = v9;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v10 = this;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v11 = v10.writer;
            global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Comma;
            string v13 = __cil_ldstr_700042FF(",");
            __cil_callvirt_060016BE(v11, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v12)), v13);
            goto IL_0041;
            IL_0041: ;
            __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v14 = l0;
            int v15 = __cil_bool_load(__cil_callvirt_0A000018(v14));
            if (v15 != 0) {
                goto IL_0025;
            } else {
                goto IL_0049;
            }
            IL_0049: ;
            goto IL_0055;
        }
        finally {
            IL_004B: ;
            __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v16 = l0;
            if (v16 is null) {
                goto IL_0054;
            } else {
                goto IL_004E;
            }
            IL_004E: ;
            __cil_ref_9e33208ad900d2c7481311e10a9cf4e1b9184654 v17 = l0;
            __cil_callvirt_0A000017(v17);
            goto IL_0054;
            IL_0054: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0055: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v18 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v19 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.RBracket;
        __cil_callvirt_060015E8(v18, v19);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v20 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier v21 = arraySpecifier;
        __cil_callvirt_060015DC(v20, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(v21)));
        return;
    }

    public virtual void VisitPrimitiveType(ICSharpCode.Decompiler.CSharp.Syntax.PrimitiveType primitiveType)
    {
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(primitiveType)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v3 = this.writer;
        string v5 = __cil_callvirt_06001E0C(primitiveType);
        __cil_callvirt_060016C0(v3, v5);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(primitiveType)));
        return;
    }

    public virtual void VisitComment(ICSharpCode.Decompiler.CSharp.Syntax.Comment comment)
    {
        // enum storage token=0x02000243 alias=__cil_enum_02000243 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@CommentType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v1 = this.writer;
        __cil_callvirt_060016BA(v1, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(comment)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v4 = this.writer;
        int v6 = unchecked((int)(__cil_callvirt_06001BB2(comment)));
        string v8 = __cil_callvirt_06001BB7(comment);
        __cil_callvirt_060016C5(v4, unchecked((__cil_enum_02000243)(v6)), v8);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v10 = this.writer;
        __cil_callvirt_060016BB(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(comment)));
        return;
    }

    public virtual void VisitNewLine(ICSharpCode.Decompiler.CSharp.Syntax.NewLineNode newLineNode)
    {
        return;
    }

    public virtual void VisitWhitespace(ICSharpCode.Decompiler.CSharp.Syntax.WhitespaceNode whitespaceNode)
    {
        return;
    }

    public virtual void VisitText(ICSharpCode.Decompiler.CSharp.Syntax.TextNode textNode)
    {
        return;
    }

    public virtual void VisitPreProcessorDirective(ICSharpCode.Decompiler.CSharp.Syntax.PreProcessorDirective preProcessorDirective)
    {
        // enum storage token=0x0200024A alias=__cil_enum_0200024A underlying=byte: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@PreProcessorDirectiveType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v1 = this.writer;
        __cil_callvirt_060016BA(v1, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(preProcessorDirective)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v4 = this.writer;
        int v6 = unchecked((int)(unchecked((byte)(__cil_callvirt_06001C19(preProcessorDirective)))));
        string v8 = __cil_callvirt_06001C1B(preProcessorDirective);
        __cil_callvirt_060016C6(v4, unchecked((__cil_enum_0200024A)(unchecked((byte)(v6)))), v8);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v10 = this.writer;
        __cil_callvirt_060016BB(v10, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(preProcessorDirective)));
        return;
    }

    public virtual void VisitTypeParameterDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration typeParameterDeclaration)
    {
        // structural signature __cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091 bytes=1512809101128908: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 bytes=151287F801128908: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000056 alias=__cil_enum_02000056 underlying=byte: global::@ICSharpCode.@Decompiler.@TypeSystem.@VarianceModifier; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000056 l0 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeParameterDeclaration)));
        __cil_ref_fe647825def4985f48df7b1587cd06a2a7025c56 v4 = __cil_callvirt_06001C46(typeParameterDeclaration);
        __cil_callvirt_060015F8(this, ((__cil_ref_41101f1ef2b36d65673b396d63c98edcf5141091)(v4)));
        int v6 = unchecked((int)(unchecked((byte)(__cil_callvirt_06001C47(typeParameterDeclaration)))));
        l0 = unchecked((__cil_enum_02000056)(unchecked((byte)(v6))));
        int v7 = unchecked((int)(unchecked((byte)(l0))));
        switch (v7) {
            case 0: {
                goto IL_0053;
            }
            case 1: {
                goto IL_002E;
            }
            case 2: {
                goto IL_003B;
            }
            default: {
                goto IL_002C;
            } }
        IL_002C: ;
        goto IL_0048;
        IL_002E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v9 = ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration.OutVarianceKeywordRole;
        __cil_callvirt_060015E4(this, v9);
        goto IL_0053;
        IL_003B: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v11 = ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration.InVarianceKeywordRole;
        __cil_callvirt_060015E4(this, v11);
        goto IL_0053;
        IL_0048: ;
        string v12 = __cil_ldstr_700087F2("Invalid value for VarianceModifier");
        global::System.NotSupportedException v13 = __cil_newobj_0A000139(v12);
        throw v13;
        IL_0053: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v16 = __cil_callvirt_06001C4C(typeParameterDeclaration);
        __cil_callvirt_060015E6(this, v16);
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeParameterDeclaration)));
        return;
    }

    public virtual void VisitConstraint(ICSharpCode.Decompiler.CSharp.Syntax.Constraint constraint)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constraint)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v5 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.WhereKeyword;
        __cil_callvirt_060015E4(this, v5);
        global::ICSharpCode.Decompiler.CSharp.Syntax.SimpleType v7 = __cil_callvirt_06001BC3(constraint);
        __cil_callvirt_06001723(v7, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v12);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v17 = __cil_callvirt_06001BC5(constraint);
        __cil_callvirt_060015E0(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v17)));
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constraint)));
        return;
    }

    public virtual void VisitCSharpTokenNode(ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode cSharpTokenNode)
    {
        // enum storage token=0x0200025B alias=__cil_enum_0200025B underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@Modifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken l0 = default;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken v1 = ((object)cSharpTokenNode as ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken);
        l0 = v1;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken v2 = l0;
        if (v2 is null) {
            goto IL_0022;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken v4 = l0;
        int v5 = unchecked((int)(__cil_callvirt_0600178F(v4)));
        string v6 = ICSharpCode.Decompiler.CSharp.Syntax.CSharpModifierToken.GetModifierName(unchecked((__cil_enum_0200025B)(v5)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.Role v8 = __cil_callvirt_060016FF(cSharpTokenNode);
        __cil_callvirt_060015E5(this, v6, v8);
        return;
        IL_0022: ;
        string v9 = __cil_ldstr_70008838("Should never visit individual tokens");
        global::System.NotSupportedException v10 = __cil_newobj_0A000139(v9);
        throw v10;
    }

    public virtual void VisitIdentifier(ICSharpCode.Decompiler.CSharp.Syntax.Identifier identifier)
    {
        __cil_callvirt_060015E6(this, identifier);
        return;
    }

    private virtual void __name_49435368617270436F64652E4465636F6D70696C65722E4353686172702E53796E7461782E4941737456697369746F722E56697369744E756C6C4E6F6465(ICSharpCode.Decompiler.CSharp.Syntax.AstNode nullNode)
    {
        return;
    }

    private virtual void __name_49435368617270436F64652E4465636F6D70696C65722E4353686172702E53796E7461782E4941737456697369746F722E56697369744572726F724E6F6465(ICSharpCode.Decompiler.CSharp.Syntax.AstNode errorNode)
    {
        __cil_callvirt_060015DB(this, errorNode);
        __cil_callvirt_060015DC(this, errorNode);
        return;
    }

    public virtual void VisitPatternPlaceholder(ICSharpCode.Decompiler.CSharp.Syntax.AstNode placeholder, ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Pattern pattern)
    {
        __cil_callvirt_060015DB(this, placeholder);
        __cil_direct_0600167D(this, ((ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode)(pattern)));
        __cil_callvirt_060015DC(this, placeholder);
        return;
    }

    private void VisitAnyNode(ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.AnyNode anyNode)
    {
        string v1 = __cil_callvirt_06002145(anyNode);
        int v2 = __cil_bool_load(System.String.IsNullOrEmpty(v1));
        if (v2 != 0) {
            goto IL_0024;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        string v5 = __cil_callvirt_06002145(anyNode);
        __cil_callvirt_060015E7(this, v5);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v7 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v7);
        IL_0024: ;
        return;
    }

    private void VisitBackreference(ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Backreference backreference)
    {
        string v1 = __cil_ldstr_70008882("backreference");
        __cil_callvirt_060015E5(this, v1, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(null)));
        __cil_callvirt_060015EA(this);
        string v5 = __cil_callvirt_0600214B(backreference);
        __cil_callvirt_060015E7(this, v5);
        __cil_callvirt_060015EB(this);
        return;
    }

    private void VisitIdentifierExpressionBackreference(ICSharpCode.Decompiler.CSharp.Syntax.IdentifierExpressionBackreference identifierExpressionBackreference)
    {
        string v1 = __cil_ldstr_7000889E("identifierBackreference");
        __cil_callvirt_060015E5(this, v1, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(null)));
        __cil_callvirt_060015EA(this);
        string v5 = __cil_callvirt_06001DF6(identifierExpressionBackreference);
        __cil_callvirt_060015E7(this, v5);
        __cil_callvirt_060015EB(this);
        return;
    }

    private void VisitChoice(ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Choice choice)
    {
        // structural signature __cil_ref_51db8dc41f48b0f727f1a51b1ba806ca85406491 bytes=1512808501128A88: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f50c6b2dc0cd38031358da150595f35383e3fa33 bytes=1512809101128A88: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_51db8dc41f48b0f727f1a51b1ba806ca85406491 l0 = default;
        ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        string v1 = __cil_ldstr_700088CE("choice");
        __cil_callvirt_060015E5(v0, v1, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(null)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        int v3 = 1;
        __cil_callvirt_060015ED(v2, __cil_bool_store(v3));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v4 = this;
        __cil_callvirt_060015EA(v4);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v5 = this;
        __cil_callvirt_060015EE(v5);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v6 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v7 = v6.writer;
        __cil_callvirt_060016C2(v7);
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Choice v8 = choice;
        __cil_ref_51db8dc41f48b0f727f1a51b1ba806ca85406491 v9 = __cil_callvirt_0A00008E(v8);
        l0 = v9;
        try {
            IL_0031: ;
            goto IL_005B;
            IL_0033: ;
            __cil_ref_51db8dc41f48b0f727f1a51b1ba806ca85406491 v10 = l0;
            global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode v11 = __cil_callvirt_0A00008F(v10);
            l1 = v11;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v12 = this;
            global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode v13 = l1;
            __cil_direct_0600167D(v12, v13);
            global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode v14 = l1;
            global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Choice v15 = choice;
            global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode v16 = __cil_methodspec_call_2B00025F(((__cil_ref_f50c6b2dc0cd38031358da150595f35383e3fa33)(v15)));
            if (System.Object.ReferenceEquals(v14, v16)) {
                goto IL_0055;
            } else {
                goto IL_004A;
            }
            IL_004A: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v17 = this;
            global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v18 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Comma;
            __cil_callvirt_060015E8(v17, v18);
            goto IL_0055;
            IL_0055: ;
            global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v19 = this;
            __cil_callvirt_060015EE(v19);
            goto IL_005B;
            IL_005B: ;
            __cil_ref_51db8dc41f48b0f727f1a51b1ba806ca85406491 v20 = l0;
            int v21 = __cil_bool_load(__cil_callvirt_0A000018(v20));
            if (v21 != 0) {
                goto IL_0033;
            } else {
                goto IL_0063;
            }
            IL_0063: ;
            goto IL_006F;
        }
        finally {
            IL_0065: ;
            __cil_ref_51db8dc41f48b0f727f1a51b1ba806ca85406491 v22 = l0;
            if (v22 is null) {
                goto IL_006E;
            } else {
                goto IL_0068;
            }
            IL_0068: ;
            __cil_ref_51db8dc41f48b0f727f1a51b1ba806ca85406491 v23 = l0;
            __cil_callvirt_0A000017(v23);
            goto IL_006E;
            IL_006E: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_006F: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v24 = this;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.TokenWriter v25 = v24.writer;
        __cil_callvirt_060016C3(v25);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v26 = this;
        __cil_callvirt_060015EB(v26);
        return;
    }

    private void VisitNamedNode(ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.NamedNode namedNode)
    {
        string v1 = __cil_callvirt_06002166(namedNode);
        int v2 = __cil_bool_load(System.String.IsNullOrEmpty(v1));
        if (v2 != 0) {
            goto IL_0024;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        string v5 = __cil_callvirt_06002166(namedNode);
        __cil_callvirt_060015E7(this, v5);
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v7 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Colon;
        __cil_callvirt_060015E8(this, v7);
        IL_0024: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode v10 = __cil_callvirt_06002167(namedNode);
        __cil_direct_0600167D(this, v10);
        return;
    }

    private void VisitRepeat(ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat repeat)
    {
        int l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v0 = this;
        string v1 = __cil_ldstr_700088DC("repeat");
        __cil_callvirt_060015E5(v0, v1, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(null)));
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v2 = this;
        __cil_callvirt_060015EA(v2);
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat v3 = repeat;
        int v4 = __cil_callvirt_06002179(v3);
        if (v4 != 0) {
            goto IL_0027;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat v5 = repeat;
        int v6 = __cil_callvirt_0600217B(v5);
        int v7 = 2147483647;
        if (v6 == v7) {
            goto IL_0065;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v8 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat v9 = repeat;
        int v10 = __cil_callvirt_06002179(v9);
        l0 = v10;
        ref int v11 = ref l0;
        string v12 = __cil_memberref_call_0A0003CB(ref v11);
        __cil_callvirt_060015E7(v8, v12);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v13 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v14 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Comma;
        __cil_callvirt_060015E8(v13, v14);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v15 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat v16 = repeat;
        int v17 = __cil_callvirt_0600217B(v16);
        l0 = v17;
        ref int v18 = ref l0;
        string v19 = __cil_memberref_call_0A0003CB(ref v18);
        __cil_callvirt_060015E7(v15, v19);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v20 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v21 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Comma;
        __cil_callvirt_060015E8(v20, v21);
        goto IL_0065;
        IL_0065: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v22 = this;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat v23 = repeat;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode v24 = __cil_callvirt_0600217D(v23);
        __cil_direct_0600167D(v22, v24);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor v25 = this;
        __cil_callvirt_060015EB(v25);
        return;
    }

    private void VisitOptionalNode(ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.OptionalNode optionalNode)
    {
        string v1 = __cil_ldstr_700088EA("optional");
        __cil_callvirt_060015E5(this, v1, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(null)));
        __cil_callvirt_060015EA(this);
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode v5 = __cil_callvirt_0600216A(optionalNode);
        __cil_direct_0600167D(this, v5);
        __cil_callvirt_060015EB(this);
        return;
    }

    private void VisitNodeInPattern(ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.INode childNode)
    {
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v1 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.AstNode);
        if (v1 is null) {
            goto IL_0015;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v3 = ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(object)childNode);
        __cil_callvirt_06001723(v3, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        return;
        IL_0015: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IdentifierExpressionBackreference v6 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.IdentifierExpressionBackreference);
        if (v6 is null) {
            goto IL_002A;
        } else {
            goto IL_001D;
        }
        IL_001D: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.IdentifierExpressionBackreference v9 = ((ICSharpCode.Decompiler.CSharp.Syntax.IdentifierExpressionBackreference)(object)childNode);
        __cil_direct_06001678(this, v9);
        return;
        IL_002A: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Choice v11 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Choice);
        if (v11 is null) {
            goto IL_003F;
        } else {
            goto IL_0032;
        }
        IL_0032: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Choice v14 = ((ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Choice)(object)childNode);
        __cil_direct_06001679(this, v14);
        return;
        IL_003F: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.AnyNode v16 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.AnyNode);
        if (v16 is null) {
            goto IL_0054;
        } else {
            goto IL_0047;
        }
        IL_0047: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.AnyNode v19 = ((ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.AnyNode)(object)childNode);
        __cil_direct_06001676(this, v19);
        return;
        IL_0054: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Backreference v21 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Backreference);
        if (v21 is null) {
            goto IL_0069;
        } else {
            goto IL_005C;
        }
        IL_005C: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Backreference v24 = ((ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Backreference)(object)childNode);
        __cil_direct_06001677(this, v24);
        return;
        IL_0069: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.NamedNode v26 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.NamedNode);
        if (v26 is null) {
            goto IL_007E;
        } else {
            goto IL_0071;
        }
        IL_0071: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.NamedNode v29 = ((ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.NamedNode)(object)childNode);
        __cil_direct_0600167A(this, v29);
        return;
        IL_007E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.OptionalNode v31 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.OptionalNode);
        if (v31 is null) {
            goto IL_0093;
        } else {
            goto IL_0086;
        }
        IL_0086: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.OptionalNode v34 = ((ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.OptionalNode)(object)childNode);
        __cil_direct_0600167C(this, v34);
        return;
        IL_0093: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat v36 = ((object)childNode as ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat);
        if (v36 is null) {
            goto IL_00A8;
        } else {
            goto IL_009B;
        }
        IL_009B: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat v39 = ((ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Repeat)(object)childNode);
        __cil_direct_0600167B(this, v39);
        return;
        IL_00A8: ;
        string v41 = ICSharpCode.Decompiler.CSharp.OutputVisitor.TextWriterTokenWriter.PrintPrimitiveValue(((object)(childNode)));
        return;
    }

    public virtual void VisitDocumentationReference(ICSharpCode.Decompiler.CSharp.Syntax.DocumentationReference documentationReference)
    {
        // structural signature __cil_ref_9f837d23389b205546fa6d930e797839b9bbe063 bytes=15128091011287F4: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5 bytes=1512809101128A5C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3681fa81e970b76123c0932848c13919b7088424 bytes=15128091011287FC: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d bytes=151287F801128A5C: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 bytes=151287F8011287FC: class ICSharpCode.Decompiler.CSharp.Syntax.AstNodeCollection`1<class ICSharpCode.Decompiler.CSharp.Syntax.AstType>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 bytes=1512897C01128960: class ICSharpCode.Decompiler.CSharp.Syntax.Role`1<class ICSharpCode.Decompiler.CSharp.Syntax.Identifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200004D alias=__cil_enum_0200004D underlying=byte: global::@ICSharpCode.@Decompiler.@TypeSystem.@SymbolKind; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000294 alias=__cil_enum_02000294 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@Syntax.@OperatorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_0200004D l0 = default;
        __cil_enum_02000294 l1 = default;
        __cil_callvirt_060015DB(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(documentationReference)));
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v3 = __cil_callvirt_0600191F(documentationReference);
        int v4 = __cil_bool_load(__cil_callvirt_060016F9(v3));
        if (v4 != 0) {
            goto IL_0034;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v6 = __cil_callvirt_0600191F(documentationReference);
        __cil_callvirt_06001723(v6, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        int v9 = unchecked((int)(unchecked((byte)(__cil_callvirt_06001918(documentationReference)))));
        if (v9 == 1) {
            goto IL_0034;
        } else {
            goto IL_0029;
        }
        IL_0029: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v12 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Dot;
        __cil_callvirt_060015E8(this, v12);
        IL_0034: ;
        int v14 = unchecked((int)(unchecked((byte)(__cil_callvirt_06001918(documentationReference)))));
        l0 = unchecked((__cil_enum_0200004D)(unchecked((byte)(v14))));
        int v15 = unchecked((int)(unchecked((byte)(l0))));
        if (v15 == 1) {
            goto IL_00D1;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        int v17 = unchecked((int)(unchecked((byte)(l0))));
        if (v17 == 4) {
            goto IL_004C;
        } else {
            goto IL_0046;
        }
        IL_0046: ;
        int v19 = unchecked((int)(unchecked((byte)(l0))));
        if (v19 == 7) {
            goto IL_0059;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        goto IL_00C0;
        IL_004C: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v22 = ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration.ThisKeywordRole;
        __cil_callvirt_060015E4(this, v22);
        goto IL_00D1;
        IL_0059: ;
        int v24 = unchecked((int)(__cil_callvirt_0600191A(documentationReference)));
        l1 = unchecked((__cil_enum_02000294)(v24));
        int v25 = unchecked((int)(l1));
        if (unchecked((uint)v25) != unchecked((uint)25)) {
            goto IL_0072;
        } else {
            goto IL_0065;
        }
        IL_0065: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v28 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.ExplicitRole;
        __cil_callvirt_060015E4(this, v28);
        goto IL_0082;
        IL_0072: ;
        int v29 = unchecked((int)(l1));
        if (unchecked((uint)v29) != unchecked((uint)24)) {
            goto IL_0082;
        } else {
            goto IL_0077;
        }
        IL_0077: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v32 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.ImplicitRole;
        __cil_callvirt_060015E4(this, v32);
        IL_0082: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v34 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.OperatorKeywordRole;
        __cil_callvirt_060015E4(this, v34);
        __cil_callvirt_060015ED(this, __cil_bool_store(1));
        int v37 = unchecked((int)(l1));
        if (v37 == 25) {
            goto IL_009E;
        } else {
            goto IL_0099;
        }
        IL_0099: ;
        int v39 = unchecked((int)(l1));
        if (unchecked((uint)v39) != unchecked((uint)24)) {
            goto IL_00AC;
        } else {
            goto IL_009E;
        }
        IL_009E: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstType v42 = __cil_callvirt_06001923(documentationReference);
        __cil_callvirt_06001723(v42, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        goto IL_00D1;
        IL_00AC: ;
        int v45 = unchecked((int)(l1));
        string v46 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.GetToken(unchecked((__cil_enum_02000294)(v45)));
        int v47 = unchecked((int)(l1));
        global::ICSharpCode.Decompiler.CSharp.Syntax.TokenRole v48 = ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration.GetRole(unchecked((__cil_enum_02000294)(v47)));
        __cil_callvirt_060015E9(this, v46, ((ICSharpCode.Decompiler.CSharp.Syntax.Role)(v48)));
        goto IL_00D1;
        IL_00C0: ;
        __cil_ref_2c87ac2ef830e68d6fabfacc1b2842ed29ddded6 v51 = ICSharpCode.Decompiler.CSharp.Syntax.Roles.Identifier;
        global::ICSharpCode.Decompiler.CSharp.Syntax.Identifier v52 = __cil_callvirt_2B000007(documentationReference, v51);
        __cil_callvirt_060015E6(this, v52);
        IL_00D1: ;
        __cil_ref_b4fda3a827877198952aac2f4da907572d4b2618 v55 = __cil_callvirt_06001925(documentationReference);
        __cil_callvirt_060015F2(this, ((__cil_ref_3681fa81e970b76123c0932848c13919b7088424)(v55)));
        int v57 = __cil_bool_load(__cil_callvirt_0600191C(documentationReference));
        if (v57 == 0) {
            goto IL_012F;
        } else {
            goto IL_00E5;
        }
        IL_00E5: ;
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v60 = this.policy;
        int v61 = __cil_bool_load(__cil_callvirt_060014F0(v60));
        __cil_callvirt_060015ED(this, __cil_bool_store(v61));
        int v63 = unchecked((int)(unchecked((byte)(__cil_callvirt_06001918(documentationReference)))));
        if (unchecked((uint)v63) != unchecked((uint)4)) {
            goto IL_0118;
        } else {
            goto IL_00FF;
        }
        IL_00FF: ;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v67 = __cil_callvirt_06001926(documentationReference);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v69 = this.policy;
        int v70 = __cil_bool_load(__cil_callvirt_060014F8(v69));
        __cil_callvirt_060015E2(this, ((__cil_ref_f44e0cd3f71fc389e1fcb1952f794e826e72ada5)(v67)), __cil_bool_store(v70));
        goto IL_012F;
        IL_0118: ;
        __cil_ref_9895921e17a8537c2e7139d4a0249f44cc54105d v73 = __cil_callvirt_06001926(documentationReference);
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v75 = this.policy;
        int v76 = __cil_bool_load(__cil_callvirt_060014F8(v75));
        __cil_callvirt_060015E1(this, ((__cil_ref_9f837d23389b205546fa6d930e797839b9bbe063)(v73)), __cil_bool_store(v76));
        IL_012F: ;
        __cil_callvirt_060015DC(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(documentationReference)));
        return;
    }

    public static string ConvertString(string text)
    {
        string v1 = ICSharpCode.Decompiler.CSharp.OutputVisitor.TextWriterTokenWriter.ConvertString(text);
        return v1;
    }

    static CSharpOutputVisitor()
    {
        // structural signature __cil_ref_a9681c452d39e51792d931751530365504b4297d bytes=151280F5010E: class [System.Core]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_a9681c452d39e51792d931751530365504b4297d v0 = __cil_newobj_0A0007D2();
        string v1 = __cil_ldstr_70002FB5("abstract");
        int v2 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v1));
        string v3 = __cil_ldstr_70003011("as");
        int v4 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v3));
        string v5 = __cil_ldstr_70008730("base");
        int v6 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v5));
        string v7 = __cil_ldstr_700006C7("bool");
        int v8 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v7));
        string v9 = __cil_ldstr_700087C6("break");
        int v10 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v9));
        string v11 = __cil_ldstr_700006D1("byte");
        int v12 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v11));
        string v13 = __cil_ldstr_700088FC("case");
        int v14 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v13));
        string v15 = __cil_ldstr_7000311D("catch");
        int v16 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v15));
        string v17 = __cil_ldstr_70000753("char");
        int v18 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v17));
        string v19 = __cil_ldstr_70008906("checked");
        int v20 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v19));
        string v21 = __cil_ldstr_70003143("class");
        int v22 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v21));
        string v23 = __cil_ldstr_7000315B("const");
        int v24 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v23));
        string v25 = __cil_ldstr_700087D2("continue");
        int v26 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v25));
        string v27 = __cil_ldstr_70000743("decimal");
        int v28 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v27));
        string v29 = __cil_ldstr_70003191("default");
        int v30 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v29));
        string v31 = __cil_ldstr_700086A0("delegate");
        int v32 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v31));
        string v33 = __cil_ldstr_70008916("do");
        int v34 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v33));
        string v35 = __cil_ldstr_70000735("double");
        int v36 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v35));
        string v37 = __cil_ldstr_7000891C("else");
        int v38 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v37));
        string v39 = __cil_ldstr_700031C7("enum");
        int v40 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v39));
        string v41 = __cil_ldstr_700086B2("event");
        int v42 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v41));
        string v43 = __cil_ldstr_700031DD("explicit");
        int v44 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v43));
        string v45 = __cil_ldstr_700031FF("extern");
        int v46 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v45));
        string v47 = __cil_ldstr_70002D4B("false");
        int v48 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v47));
        string v49 = __cil_ldstr_70003293("finally");
        int v50 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v49));
        string v51 = __cil_ldstr_700032A3("fixed");
        int v52 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v51));
        string v53 = __cil_ldstr_70000729("float");
        int v54 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v53));
        string v55 = __cil_ldstr_70008926("for");
        int v56 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v55));
        string v57 = __cil_ldstr_7000892E("foreach");
        int v58 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v57));
        string v59 = __cil_ldstr_7000893E("goto");
        int v60 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v59));
        string v61 = __cil_ldstr_70004F55("if");
        int v62 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v61));
        string v63 = __cil_ldstr_700086EA("implicit");
        int v64 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v63));
        string v65 = __cil_ldstr_70003393("in");
        int v66 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v65));
        string v67 = __cil_ldstr_70000701("int");
        int v68 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v67));
        string v69 = __cil_ldstr_700033E1("interface");
        int v70 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v69));
        string v71 = __cil_ldstr_70008948("internal");
        int v72 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v71));
        string v73 = __cil_ldstr_7000895A("is");
        int v74 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v73));
        string v75 = __cil_ldstr_70008960("lock");
        int v76 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v75));
        string v77 = __cil_ldstr_70000713("long");
        int v78 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v77));
        string v79 = __cil_ldstr_700086BE("namespace");
        int v80 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v79));
        string v81 = __cil_ldstr_700006BF("new");
        int v82 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v81));
        string v83 = __cil_ldstr_70001C0D("null");
        int v84 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v83));
        string v85 = __cil_ldstr_7000076B("object");
        int v86 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v85));
        string v87 = __cil_ldstr_700086FC("operator");
        int v88 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v87));
        string v89 = __cil_ldstr_70002A5D("out");
        int v90 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v89));
        string v91 = __cil_ldstr_7000896A("override");
        int v92 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v91));
        string v93 = __cil_ldstr_7000897C("params");
        int v94 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v93));
        string v95 = __cil_ldstr_700037A7("private");
        int v96 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v95));
        string v97 = __cil_ldstr_700037D1("protected");
        int v98 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v97));
        string v99 = __cil_ldstr_700037E5("public");
        int v100 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v99));
        string v101 = __cil_ldstr_7000898A("readonly");
        int v102 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v101));
        string v103 = __cil_ldstr_70002A55("ref");
        int v104 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v103));
        string v105 = __cil_ldstr_7000899C("return");
        int v106 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v105));
        string v107 = __cil_ldstr_700006DB("sbyte");
        int v108 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v107));
        string v109 = __cil_ldstr_700038B1("sealed");
        int v110 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v109));
        string v111 = __cil_ldstr_700006E7("short");
        int v112 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v111));
        string v113 = __cil_ldstr_7000521F("sizeof");
        int v114 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v113));
        string v115 = __cil_ldstr_700089AA("stackalloc");
        int v116 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v115));
        string v117 = __cil_ldstr_70003917("static");
        int v118 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v117));
        string v119 = __cil_ldstr_7000075D("string");
        int v120 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v119));
        string v121 = __cil_ldstr_7000398F("struct");
        int v122 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v121));
        string v123 = __cil_ldstr_70004F71("switch");
        int v124 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v123));
        string v125 = __cil_ldstr_700053BF("this");
        int v126 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v125));
        string v127 = __cil_ldstr_70005203("throw");
        int v128 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v127));
        string v129 = __cil_ldstr_70002D57("true");
        int v130 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v129));
        string v131 = __cil_ldstr_700089C0("try");
        int v132 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v131));
        string v133 = __cil_ldstr_700089C8("typeof");
        int v134 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v133));
        string v135 = __cil_ldstr_70000709("uint");
        int v136 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v135));
        string v137 = __cil_ldstr_7000071D("ulong");
        int v138 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v137));
        string v139 = __cil_ldstr_700089D6("unchecked");
        int v140 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v139));
        string v141 = __cil_ldstr_700089EA("unsafe");
        int v142 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v141));
        string v143 = __cil_ldstr_700006F3("ushort");
        int v144 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v143));
        string v145 = __cil_ldstr_700089F8("using");
        int v146 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v145));
        string v147 = __cil_ldstr_70003ACF("virtual");
        int v148 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v147));
        string v149 = __cil_ldstr_7000141D("void");
        int v150 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v149));
        string v151 = __cil_ldstr_70008A04("volatile");
        int v152 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v151));
        string v153 = __cil_ldstr_70008A16("while");
        int v154 = __cil_bool_load(__cil_callvirt_0A0003C7(v0, v153));
        ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor.unconditionalKeywords = v0;
        __cil_ref_a9681c452d39e51792d931751530365504b4297d v155 = __cil_newobj_0A0007D2();
        string v156 = __cil_ldstr_70008A22("from");
        int v157 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v156));
        string v158 = __cil_ldstr_70008A2C("where");
        int v159 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v158));
        string v160 = __cil_ldstr_70008A38("join");
        int v161 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v160));
        string v162 = __cil_ldstr_70008A42("on");
        int v163 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v162));
        string v164 = __cil_ldstr_70008A48("equals");
        int v165 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v164));
        string v166 = __cil_ldstr_70008A56("into");
        int v167 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v166));
        string v168 = __cil_ldstr_70008A60("let");
        int v169 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v168));
        string v170 = __cil_ldstr_70008A68("orderby");
        int v171 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v170));
        string v172 = __cil_ldstr_70008A78("ascending");
        int v173 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v172));
        string v174 = __cil_ldstr_70008A8C("descending");
        int v175 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v174));
        string v176 = __cil_ldstr_70008AA2("select");
        int v177 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v176));
        string v178 = __cil_ldstr_70008AB0("group");
        int v179 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v178));
        string v180 = __cil_ldstr_70008ABC("by");
        int v181 = __cil_bool_load(__cil_callvirt_0A0003C7(v155, v180));
        ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpOutputVisitor.queryKeywords = v155;
        return;
    }
}
