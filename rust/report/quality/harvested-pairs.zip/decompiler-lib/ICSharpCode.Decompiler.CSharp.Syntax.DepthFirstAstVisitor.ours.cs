namespace ICSharpCode.Decompiler.CSharp.Syntax;

public abstract class DepthFirstAstVisitor : ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor
{
    protected virtual void VisitChildren(ICSharpCode.Decompiler.CSharp.Syntax.AstNode node)
    {
        ICSharpCode.Decompiler.CSharp.Syntax.AstNode l1 = default;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v1 = __cil_callvirt_06001705(node);
        l1 = v1;
        goto IL_0019;
        IL_0009: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v2 = l1;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v3 = __cil_callvirt_06001703(v2);
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v4 = l1;
        __cil_callvirt_06001723(v4, ((ICSharpCode.Decompiler.CSharp.Syntax.IAstVisitor)(this)));
        l1 = v3;
        IL_0019: ;
        global::ICSharpCode.Decompiler.CSharp.Syntax.AstNode v7 = l1;
        if (v7 is not null) {
            goto IL_0009;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        return;
    }

    public virtual void VisitNullNode(ICSharpCode.Decompiler.CSharp.Syntax.AstNode nullNode)
    {
        return;
    }

    public virtual void VisitSyntaxTree(ICSharpCode.Decompiler.CSharp.Syntax.SyntaxTree syntaxTree)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(syntaxTree)));
        return;
    }

    public virtual void VisitComment(ICSharpCode.Decompiler.CSharp.Syntax.Comment comment)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(comment)));
        return;
    }

    public virtual void VisitNewLine(ICSharpCode.Decompiler.CSharp.Syntax.NewLineNode newLineNode)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(newLineNode)));
        return;
    }

    public virtual void VisitWhitespace(ICSharpCode.Decompiler.CSharp.Syntax.WhitespaceNode whitespaceNode)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(whitespaceNode)));
        return;
    }

    public virtual void VisitText(ICSharpCode.Decompiler.CSharp.Syntax.TextNode textNode)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(textNode)));
        return;
    }

    public virtual void VisitDocumentationReference(ICSharpCode.Decompiler.CSharp.Syntax.DocumentationReference documentationReference)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(documentationReference)));
        return;
    }

    public virtual void VisitPreProcessorDirective(ICSharpCode.Decompiler.CSharp.Syntax.PreProcessorDirective preProcessorDirective)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(preProcessorDirective)));
        return;
    }

    public virtual void VisitIdentifier(ICSharpCode.Decompiler.CSharp.Syntax.Identifier identifier)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(identifier)));
        return;
    }

    public virtual void VisitCSharpTokenNode(ICSharpCode.Decompiler.CSharp.Syntax.CSharpTokenNode token)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(token)));
        return;
    }

    public virtual void VisitPrimitiveType(ICSharpCode.Decompiler.CSharp.Syntax.PrimitiveType primitiveType)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(primitiveType)));
        return;
    }

    public virtual void VisitComposedType(ICSharpCode.Decompiler.CSharp.Syntax.ComposedType composedType)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(composedType)));
        return;
    }

    public virtual void VisitSimpleType(ICSharpCode.Decompiler.CSharp.Syntax.SimpleType simpleType)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(simpleType)));
        return;
    }

    public virtual void VisitMemberType(ICSharpCode.Decompiler.CSharp.Syntax.MemberType memberType)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(memberType)));
        return;
    }

    public virtual void VisitAttribute(ICSharpCode.Decompiler.CSharp.Syntax.Attribute attribute)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(attribute)));
        return;
    }

    public virtual void VisitAttributeSection(ICSharpCode.Decompiler.CSharp.Syntax.AttributeSection attributeSection)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(attributeSection)));
        return;
    }

    public virtual void VisitDelegateDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.DelegateDeclaration delegateDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(delegateDeclaration)));
        return;
    }

    public virtual void VisitNamespaceDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.NamespaceDeclaration namespaceDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(namespaceDeclaration)));
        return;
    }

    public virtual void VisitTypeDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.TypeDeclaration typeDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeDeclaration)));
        return;
    }

    public virtual void VisitTypeParameterDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.TypeParameterDeclaration typeParameterDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeParameterDeclaration)));
        return;
    }

    public virtual void VisitEnumMemberDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.EnumMemberDeclaration enumMemberDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(enumMemberDeclaration)));
        return;
    }

    public virtual void VisitUsingDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.UsingDeclaration usingDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingDeclaration)));
        return;
    }

    public virtual void VisitUsingAliasDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.UsingAliasDeclaration usingDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingDeclaration)));
        return;
    }

    public virtual void VisitExternAliasDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.ExternAliasDeclaration externAliasDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(externAliasDeclaration)));
        return;
    }

    public virtual void VisitConstructorDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.ConstructorDeclaration constructorDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constructorDeclaration)));
        return;
    }

    public virtual void VisitConstructorInitializer(ICSharpCode.Decompiler.CSharp.Syntax.ConstructorInitializer constructorInitializer)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constructorInitializer)));
        return;
    }

    public virtual void VisitDestructorDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.DestructorDeclaration destructorDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(destructorDeclaration)));
        return;
    }

    public virtual void VisitEventDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.EventDeclaration eventDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(eventDeclaration)));
        return;
    }

    public virtual void VisitCustomEventDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.CustomEventDeclaration eventDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(eventDeclaration)));
        return;
    }

    public virtual void VisitFieldDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.FieldDeclaration fieldDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fieldDeclaration)));
        return;
    }

    public virtual void VisitFixedFieldDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.FixedFieldDeclaration fixedFieldDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedFieldDeclaration)));
        return;
    }

    public virtual void VisitFixedVariableInitializer(ICSharpCode.Decompiler.CSharp.Syntax.FixedVariableInitializer fixedVariableInitializer)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedVariableInitializer)));
        return;
    }

    public virtual void VisitIndexerDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.IndexerDeclaration indexerDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(indexerDeclaration)));
        return;
    }

    public virtual void VisitMethodDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.MethodDeclaration methodDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(methodDeclaration)));
        return;
    }

    public virtual void VisitOperatorDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.OperatorDeclaration operatorDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(operatorDeclaration)));
        return;
    }

    public virtual void VisitPropertyDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.PropertyDeclaration propertyDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(propertyDeclaration)));
        return;
    }

    public virtual void VisitAccessor(ICSharpCode.Decompiler.CSharp.Syntax.Accessor accessor)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(accessor)));
        return;
    }

    public virtual void VisitVariableInitializer(ICSharpCode.Decompiler.CSharp.Syntax.VariableInitializer variableInitializer)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(variableInitializer)));
        return;
    }

    public virtual void VisitParameterDeclaration(ICSharpCode.Decompiler.CSharp.Syntax.ParameterDeclaration parameterDeclaration)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(parameterDeclaration)));
        return;
    }

    public virtual void VisitConstraint(ICSharpCode.Decompiler.CSharp.Syntax.Constraint constraint)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(constraint)));
        return;
    }

    public virtual void VisitBlockStatement(ICSharpCode.Decompiler.CSharp.Syntax.BlockStatement blockStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(blockStatement)));
        return;
    }

    public virtual void VisitExpressionStatement(ICSharpCode.Decompiler.CSharp.Syntax.ExpressionStatement expressionStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(expressionStatement)));
        return;
    }

    public virtual void VisitBreakStatement(ICSharpCode.Decompiler.CSharp.Syntax.BreakStatement breakStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(breakStatement)));
        return;
    }

    public virtual void VisitCheckedStatement(ICSharpCode.Decompiler.CSharp.Syntax.CheckedStatement checkedStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(checkedStatement)));
        return;
    }

    public virtual void VisitContinueStatement(ICSharpCode.Decompiler.CSharp.Syntax.ContinueStatement continueStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(continueStatement)));
        return;
    }

    public virtual void VisitDoWhileStatement(ICSharpCode.Decompiler.CSharp.Syntax.DoWhileStatement doWhileStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(doWhileStatement)));
        return;
    }

    public virtual void VisitEmptyStatement(ICSharpCode.Decompiler.CSharp.Syntax.EmptyStatement emptyStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(emptyStatement)));
        return;
    }

    public virtual void VisitFixedStatement(ICSharpCode.Decompiler.CSharp.Syntax.FixedStatement fixedStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(fixedStatement)));
        return;
    }

    public virtual void VisitForeachStatement(ICSharpCode.Decompiler.CSharp.Syntax.ForeachStatement foreachStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(foreachStatement)));
        return;
    }

    public virtual void VisitForStatement(ICSharpCode.Decompiler.CSharp.Syntax.ForStatement forStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(forStatement)));
        return;
    }

    public virtual void VisitGotoCaseStatement(ICSharpCode.Decompiler.CSharp.Syntax.GotoCaseStatement gotoCaseStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoCaseStatement)));
        return;
    }

    public virtual void VisitGotoDefaultStatement(ICSharpCode.Decompiler.CSharp.Syntax.GotoDefaultStatement gotoDefaultStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoDefaultStatement)));
        return;
    }

    public virtual void VisitGotoStatement(ICSharpCode.Decompiler.CSharp.Syntax.GotoStatement gotoStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(gotoStatement)));
        return;
    }

    public virtual void VisitIfElseStatement(ICSharpCode.Decompiler.CSharp.Syntax.IfElseStatement ifElseStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(ifElseStatement)));
        return;
    }

    public virtual void VisitLabelStatement(ICSharpCode.Decompiler.CSharp.Syntax.LabelStatement labelStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(labelStatement)));
        return;
    }

    public virtual void VisitLockStatement(ICSharpCode.Decompiler.CSharp.Syntax.LockStatement lockStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(lockStatement)));
        return;
    }

    public virtual void VisitReturnStatement(ICSharpCode.Decompiler.CSharp.Syntax.ReturnStatement returnStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(returnStatement)));
        return;
    }

    public virtual void VisitSwitchStatement(ICSharpCode.Decompiler.CSharp.Syntax.SwitchStatement switchStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(switchStatement)));
        return;
    }

    public virtual void VisitSwitchSection(ICSharpCode.Decompiler.CSharp.Syntax.SwitchSection switchSection)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(switchSection)));
        return;
    }

    public virtual void VisitCaseLabel(ICSharpCode.Decompiler.CSharp.Syntax.CaseLabel caseLabel)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(caseLabel)));
        return;
    }

    public virtual void VisitThrowStatement(ICSharpCode.Decompiler.CSharp.Syntax.ThrowStatement throwStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(throwStatement)));
        return;
    }

    public virtual void VisitTryCatchStatement(ICSharpCode.Decompiler.CSharp.Syntax.TryCatchStatement tryCatchStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(tryCatchStatement)));
        return;
    }

    public virtual void VisitCatchClause(ICSharpCode.Decompiler.CSharp.Syntax.CatchClause catchClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(catchClause)));
        return;
    }

    public virtual void VisitUncheckedStatement(ICSharpCode.Decompiler.CSharp.Syntax.UncheckedStatement uncheckedStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(uncheckedStatement)));
        return;
    }

    public virtual void VisitUnsafeStatement(ICSharpCode.Decompiler.CSharp.Syntax.UnsafeStatement unsafeStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(unsafeStatement)));
        return;
    }

    public virtual void VisitUsingStatement(ICSharpCode.Decompiler.CSharp.Syntax.UsingStatement usingStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(usingStatement)));
        return;
    }

    public virtual void VisitVariableDeclarationStatement(ICSharpCode.Decompiler.CSharp.Syntax.VariableDeclarationStatement variableDeclarationStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(variableDeclarationStatement)));
        return;
    }

    public virtual void VisitWhileStatement(ICSharpCode.Decompiler.CSharp.Syntax.WhileStatement whileStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(whileStatement)));
        return;
    }

    public virtual void VisitYieldBreakStatement(ICSharpCode.Decompiler.CSharp.Syntax.YieldBreakStatement yieldBreakStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(yieldBreakStatement)));
        return;
    }

    public virtual void VisitYieldReturnStatement(ICSharpCode.Decompiler.CSharp.Syntax.YieldReturnStatement yieldReturnStatement)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(yieldReturnStatement)));
        return;
    }

    public virtual void VisitAnonymousMethodExpression(ICSharpCode.Decompiler.CSharp.Syntax.AnonymousMethodExpression anonymousMethodExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(anonymousMethodExpression)));
        return;
    }

    public virtual void VisitLambdaExpression(ICSharpCode.Decompiler.CSharp.Syntax.LambdaExpression lambdaExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(lambdaExpression)));
        return;
    }

    public virtual void VisitAssignmentExpression(ICSharpCode.Decompiler.CSharp.Syntax.AssignmentExpression assignmentExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(assignmentExpression)));
        return;
    }

    public virtual void VisitBaseReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.BaseReferenceExpression baseReferenceExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(baseReferenceExpression)));
        return;
    }

    public virtual void VisitBinaryOperatorExpression(ICSharpCode.Decompiler.CSharp.Syntax.BinaryOperatorExpression binaryOperatorExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(binaryOperatorExpression)));
        return;
    }

    public virtual void VisitCastExpression(ICSharpCode.Decompiler.CSharp.Syntax.CastExpression castExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(castExpression)));
        return;
    }

    public virtual void VisitCheckedExpression(ICSharpCode.Decompiler.CSharp.Syntax.CheckedExpression checkedExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(checkedExpression)));
        return;
    }

    public virtual void VisitConditionalExpression(ICSharpCode.Decompiler.CSharp.Syntax.ConditionalExpression conditionalExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(conditionalExpression)));
        return;
    }

    public virtual void VisitIdentifierExpression(ICSharpCode.Decompiler.CSharp.Syntax.IdentifierExpression identifierExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(identifierExpression)));
        return;
    }

    public virtual void VisitIndexerExpression(ICSharpCode.Decompiler.CSharp.Syntax.IndexerExpression indexerExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(indexerExpression)));
        return;
    }

    public virtual void VisitInvocationExpression(ICSharpCode.Decompiler.CSharp.Syntax.InvocationExpression invocationExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(invocationExpression)));
        return;
    }

    public virtual void VisitDirectionExpression(ICSharpCode.Decompiler.CSharp.Syntax.DirectionExpression directionExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(directionExpression)));
        return;
    }

    public virtual void VisitMemberReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.MemberReferenceExpression memberReferenceExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(memberReferenceExpression)));
        return;
    }

    public virtual void VisitNullReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.NullReferenceExpression nullReferenceExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(nullReferenceExpression)));
        return;
    }

    public virtual void VisitObjectCreateExpression(ICSharpCode.Decompiler.CSharp.Syntax.ObjectCreateExpression objectCreateExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(objectCreateExpression)));
        return;
    }

    public virtual void VisitOutVarDeclarationExpression(ICSharpCode.Decompiler.CSharp.Syntax.OutVarDeclarationExpression outVarDeclarationExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(outVarDeclarationExpression)));
        return;
    }

    public virtual void VisitAnonymousTypeCreateExpression(ICSharpCode.Decompiler.CSharp.Syntax.AnonymousTypeCreateExpression anonymousTypeCreateExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(anonymousTypeCreateExpression)));
        return;
    }

    public virtual void VisitArrayCreateExpression(ICSharpCode.Decompiler.CSharp.Syntax.ArrayCreateExpression arrayCreateExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(arrayCreateExpression)));
        return;
    }

    public virtual void VisitParenthesizedExpression(ICSharpCode.Decompiler.CSharp.Syntax.ParenthesizedExpression parenthesizedExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(parenthesizedExpression)));
        return;
    }

    public virtual void VisitPointerReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.PointerReferenceExpression pointerReferenceExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(pointerReferenceExpression)));
        return;
    }

    public virtual void VisitPrimitiveExpression(ICSharpCode.Decompiler.CSharp.Syntax.PrimitiveExpression primitiveExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(primitiveExpression)));
        return;
    }

    public virtual void VisitSizeOfExpression(ICSharpCode.Decompiler.CSharp.Syntax.SizeOfExpression sizeOfExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(sizeOfExpression)));
        return;
    }

    public virtual void VisitStackAllocExpression(ICSharpCode.Decompiler.CSharp.Syntax.StackAllocExpression stackAllocExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(stackAllocExpression)));
        return;
    }

    public virtual void VisitThisReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.ThisReferenceExpression thisReferenceExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(thisReferenceExpression)));
        return;
    }

    public virtual void VisitThrowExpression(ICSharpCode.Decompiler.CSharp.Syntax.ThrowExpression throwExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(throwExpression)));
        return;
    }

    public virtual void VisitTypeOfExpression(ICSharpCode.Decompiler.CSharp.Syntax.TypeOfExpression typeOfExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeOfExpression)));
        return;
    }

    public virtual void VisitTypeReferenceExpression(ICSharpCode.Decompiler.CSharp.Syntax.TypeReferenceExpression typeReferenceExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(typeReferenceExpression)));
        return;
    }

    public virtual void VisitUnaryOperatorExpression(ICSharpCode.Decompiler.CSharp.Syntax.UnaryOperatorExpression unaryOperatorExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(unaryOperatorExpression)));
        return;
    }

    public virtual void VisitUncheckedExpression(ICSharpCode.Decompiler.CSharp.Syntax.UncheckedExpression uncheckedExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(uncheckedExpression)));
        return;
    }

    public virtual void VisitQueryExpression(ICSharpCode.Decompiler.CSharp.Syntax.QueryExpression queryExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryExpression)));
        return;
    }

    public virtual void VisitQueryContinuationClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryContinuationClause queryContinuationClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryContinuationClause)));
        return;
    }

    public virtual void VisitQueryFromClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryFromClause queryFromClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryFromClause)));
        return;
    }

    public virtual void VisitQueryLetClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryLetClause queryLetClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryLetClause)));
        return;
    }

    public virtual void VisitQueryWhereClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryWhereClause queryWhereClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryWhereClause)));
        return;
    }

    public virtual void VisitQueryJoinClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryJoinClause queryJoinClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryJoinClause)));
        return;
    }

    public virtual void VisitQueryOrderClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryOrderClause queryOrderClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryOrderClause)));
        return;
    }

    public virtual void VisitQueryOrdering(ICSharpCode.Decompiler.CSharp.Syntax.QueryOrdering queryOrdering)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryOrdering)));
        return;
    }

    public virtual void VisitQuerySelectClause(ICSharpCode.Decompiler.CSharp.Syntax.QuerySelectClause querySelectClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(querySelectClause)));
        return;
    }

    public virtual void VisitQueryGroupClause(ICSharpCode.Decompiler.CSharp.Syntax.QueryGroupClause queryGroupClause)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(queryGroupClause)));
        return;
    }

    public virtual void VisitAsExpression(ICSharpCode.Decompiler.CSharp.Syntax.AsExpression asExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(asExpression)));
        return;
    }

    public virtual void VisitIsExpression(ICSharpCode.Decompiler.CSharp.Syntax.IsExpression isExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(isExpression)));
        return;
    }

    public virtual void VisitDefaultValueExpression(ICSharpCode.Decompiler.CSharp.Syntax.DefaultValueExpression defaultValueExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(defaultValueExpression)));
        return;
    }

    public virtual void VisitUndocumentedExpression(ICSharpCode.Decompiler.CSharp.Syntax.UndocumentedExpression undocumentedExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(undocumentedExpression)));
        return;
    }

    public virtual void VisitArrayInitializerExpression(ICSharpCode.Decompiler.CSharp.Syntax.ArrayInitializerExpression arrayInitializerExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(arrayInitializerExpression)));
        return;
    }

    public virtual void VisitArraySpecifier(ICSharpCode.Decompiler.CSharp.Syntax.ArraySpecifier arraySpecifier)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(arraySpecifier)));
        return;
    }

    public virtual void VisitNamedArgumentExpression(ICSharpCode.Decompiler.CSharp.Syntax.NamedArgumentExpression namedArgumentExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(namedArgumentExpression)));
        return;
    }

    public virtual void VisitNamedExpression(ICSharpCode.Decompiler.CSharp.Syntax.NamedExpression namedExpression)
    {
        __cil_callvirt_060017AD(this, ((ICSharpCode.Decompiler.CSharp.Syntax.AstNode)(namedExpression)));
        return;
    }

    public virtual void VisitErrorNode(ICSharpCode.Decompiler.CSharp.Syntax.AstNode errorNode)
    {
        __cil_callvirt_060017AD(this, errorNode);
        return;
    }

    public virtual void VisitPatternPlaceholder(ICSharpCode.Decompiler.CSharp.Syntax.AstNode placeholder, ICSharpCode.Decompiler.CSharp.Syntax.PatternMatching.Pattern pattern)
    {
        __cil_callvirt_060017AD(this, placeholder);
        return;
    }

    protected DepthFirstAstVisitor() : base()
    {
        return;
    }
}
