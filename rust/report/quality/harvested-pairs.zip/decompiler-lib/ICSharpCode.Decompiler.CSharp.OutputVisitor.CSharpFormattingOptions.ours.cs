namespace ICSharpCode.Decompiler.CSharp.OutputVisitor;

public class CSharpFormattingOptions
{
    private string __il_field_04000743;
    private bool __il_field_04000744;
    private bool __il_field_04000745;
    private bool __il_field_04000746;
    private bool __il_field_04000747;
    private bool __il_field_04000748;
    private bool __il_field_04000749;
    private bool __il_field_0400074A;
    private bool __il_field_0400074B;
    private bool __il_field_0400074C;
    private bool __il_field_0400074D;
    private bool __il_field_0400074E;
    private bool __il_field_0400074F;
    private bool __il_field_04000750;
    private bool __il_field_04000751;
    private bool __il_field_04000752;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting __il_field_04000753;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting __il_field_04000754;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.EmptyLineFormatting __il_field_04000755;
    private bool __il_field_04000756;
    private bool __il_field_04000757;
    private bool __il_field_04000758;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000759;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_0400075A;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_0400075B;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_0400075C;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_0400075D;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_0400075E;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_0400075F;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000760;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000761;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000762;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000763;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000764;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting __il_field_04000765;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting __il_field_04000766;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000767;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000768;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_04000769;
    private bool __il_field_0400076A;
    private bool __il_field_0400076B;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_0400076C;
    private bool __il_field_0400076D;
    private bool allowOneLinedArrayInitialziers;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_0400076F;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_04000770;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_04000771;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_04000772;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_04000773;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement embeddedStatementPlacement;
    private bool __il_field_04000775;
    private bool __il_field_04000776;
    private bool __il_field_04000777;
    private bool __il_field_04000778;
    private bool __il_field_04000779;
    private bool __il_field_0400077A;
    private bool __il_field_0400077B;
    private bool __il_field_0400077C;
    private bool __il_field_0400077D;
    private bool __il_field_0400077E;
    private bool __il_field_0400077F;
    private bool __il_field_04000780;
    private bool __il_field_04000781;
    private bool __il_field_04000782;
    private bool __il_field_04000783;
    private bool __il_field_04000784;
    private bool __il_field_04000785;
    private bool __il_field_04000786;
    private bool __il_field_04000787;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_04000788;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_04000789;
    private bool __il_field_0400078A;
    private bool __il_field_0400078B;
    private bool __il_field_0400078C;
    private bool __il_field_0400078D;
    private bool __il_field_0400078E;
    private bool __il_field_0400078F;
    private bool __il_field_04000790;
    private bool __il_field_04000791;
    private bool __il_field_04000792;
    private bool __il_field_04000793;
    private bool __il_field_04000794;
    private bool __il_field_04000795;
    private bool __il_field_04000796;
    private bool __il_field_04000797;
    private bool __il_field_04000798;
    private bool __il_field_04000799;
    private bool __il_field_0400079A;
    private bool __il_field_0400079B;
    private bool __il_field_0400079C;
    private bool __il_field_0400079D;
    private bool __il_field_0400079E;
    private bool __il_field_0400079F;
    private bool __il_field_040007A0;
    private bool __il_field_040007A1;
    private bool __il_field_040007A2;
    private bool __il_field_040007A3;
    private bool __il_field_040007A4;
    private bool __il_field_040007A5;
    private bool __il_field_040007A6;
    private bool __il_field_040007A7;
    private bool __il_field_040007A8;
    private bool __il_field_040007A9;
    private bool __il_field_040007AA;
    private bool __il_field_040007AB;
    private bool __il_field_040007AC;
    private bool __il_field_040007AD;
    private bool __il_field_040007AE;
    private bool __il_field_040007AF;
    private bool __il_field_040007B0;
    private bool __il_field_040007B1;
    private bool __il_field_040007B2;
    private bool __il_field_040007B3;
    private bool __il_field_040007B4;
    private bool __il_field_040007B5;
    private bool __il_field_040007B6;
    private bool __il_field_040007B7;
    private bool __il_field_040007B8;
    private bool __il_field_040007B9;
    private bool __il_field_040007BA;
    private bool __il_field_040007BB;
    private bool __il_field_040007BC;
    private bool __il_field_040007BD;
    private bool __il_field_040007BE;
    private bool __il_field_040007BF;
    private bool __il_field_040007C0;
    private bool __il_field_040007C1;
    private bool __il_field_040007C2;
    private bool __il_field_040007C3;
    private bool __il_field_040007C4;
    private bool __il_field_040007C5;
    private bool __il_field_040007C6;
    private bool __il_field_040007C7;
    private bool __il_field_040007C8;
    private bool __il_field_040007C9;
    private int __il_field_040007CA;
    private int __il_field_040007CB;
    private int __il_field_040007CC;
    private int __il_field_040007CD;
    private int __il_field_040007CE;
    private int __il_field_040007CF;
    private int __il_field_040007D0;
    private int __il_field_040007D1;
    private int __il_field_040007D2;
    private bool __il_field_040007D3;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping __il_field_040007D4;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle __il_field_040007D5;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping __il_field_040007D6;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping __il_field_040007D7;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007D8;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007D9;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping __il_field_040007DA;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007DB;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007DC;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping __il_field_040007DD;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007DE;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007DF;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping __il_field_040007E0;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007E1;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007E2;
    private bool __il_field_040007E3;
    private bool __il_field_040007E4;
    private bool __il_field_040007E5;
    private bool __il_field_040007E6;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement __il_field_040007E7;
    private ICSharpCode.Decompiler.CSharp.OutputVisitor.UsingPlacement __il_field_040007E8;

    public string get_Name()
    {
        string v1 = this.__il_field_04000743;
        return v1;
    }

    public void set_Name(string value)
    {
        this.__il_field_04000743 = value;
        return;
    }

    public bool get_IsBuiltIn()
    {
        return this.__il_field_04000744;
    }

    public void set_IsBuiltIn(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000744 = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions Clone()
    {
        object v1 = this.MemberwiseClone();
        global::ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions v2 = ((ICSharpCode.Decompiler.CSharp.OutputVisitor.CSharpFormattingOptions)(object)v1);
        return v2;
    }

    public bool get_IndentNamespaceBody()
    {
        return this.__il_field_04000745;
    }

    public void set_IndentNamespaceBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000745 = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentClassBody()
    {
        return this.__il_field_04000746;
    }

    public void set_IndentClassBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000746 = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentInterfaceBody()
    {
        return this.__il_field_04000747;
    }

    public void set_IndentInterfaceBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000747 = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentStructBody()
    {
        return this.__il_field_04000748;
    }

    public void set_IndentStructBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000748 = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentEnumBody()
    {
        return this.__il_field_04000749;
    }

    public void set_IndentEnumBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000749 = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentMethodBody()
    {
        return this.__il_field_0400074A;
    }

    public void set_IndentMethodBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400074A = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentPropertyBody()
    {
        return this.__il_field_0400074B;
    }

    public void set_IndentPropertyBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400074B = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentEventBody()
    {
        return this.__il_field_0400074C;
    }

    public void set_IndentEventBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400074C = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentBlocks()
    {
        return this.__il_field_0400074D;
    }

    public void set_IndentBlocks(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400074D = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentSwitchBody()
    {
        return this.__il_field_0400074E;
    }

    public void set_IndentSwitchBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400074E = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentCaseBody()
    {
        return this.__il_field_0400074F;
    }

    public void set_IndentCaseBody(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400074F = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentBreakStatements()
    {
        return this.__il_field_04000750;
    }

    public void set_IndentBreakStatements(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000750 = __cil_bool_store(v1);
        return;
    }

    public bool get_AlignEmbeddedStatements()
    {
        return this.__il_field_04000751;
    }

    public void set_AlignEmbeddedStatements(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000751 = __cil_bool_store(v1);
        return;
    }

    public bool get_AlignElseInIfStatements()
    {
        return this.__il_field_04000752;
    }

    public void set_AlignElseInIfStatements(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000752 = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting get_AutoPropertyFormatting()
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000753));
        return unchecked((__cil_enum_020001ED)(v1));
    }

    public void set_AutoPropertyFormatting(ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting value)
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000753 = unchecked((__cil_enum_020001ED)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting get_SimplePropertyFormatting()
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000754));
        return unchecked((__cil_enum_020001ED)(v1));
    }

    public void set_SimplePropertyFormatting(ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting value)
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000754 = unchecked((__cil_enum_020001ED)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.EmptyLineFormatting get_EmptyLineFormatting()
    {
        // enum storage token=0x020001F1 alias=__cil_enum_020001F1 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@EmptyLineFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000755));
        return unchecked((__cil_enum_020001F1)(v1));
    }

    public void set_EmptyLineFormatting(ICSharpCode.Decompiler.CSharp.OutputVisitor.EmptyLineFormatting value)
    {
        // enum storage token=0x020001F1 alias=__cil_enum_020001F1 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@EmptyLineFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000755 = unchecked((__cil_enum_020001F1)(v1));
        return;
    }

    public bool get_IndentPreprocessorDirectives()
    {
        return this.__il_field_04000756;
    }

    public void set_IndentPreprocessorDirectives(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000756 = __cil_bool_store(v1);
        return;
    }

    public bool get_AlignToMemberReferenceDot()
    {
        return this.__il_field_04000757;
    }

    public void set_AlignToMemberReferenceDot(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000757 = __cil_bool_store(v1);
        return;
    }

    public bool get_IndentBlocksInsideExpressions()
    {
        return this.__il_field_04000758;
    }

    public void set_IndentBlocksInsideExpressions(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000758 = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_NamespaceBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000759));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_NamespaceBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000759 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_ClassBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400075A));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_ClassBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400075A = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_InterfaceBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400075B));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_InterfaceBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400075B = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_StructBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400075C));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_StructBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400075C = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_EnumBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400075D));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_EnumBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400075D = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_MethodBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400075E));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_MethodBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400075E = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_AnonymousMethodBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400075F));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_AnonymousMethodBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400075F = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_ConstructorBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000760));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_ConstructorBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000760 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_DestructorBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000761));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_DestructorBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000761 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_PropertyBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000762));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_PropertyBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000762 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_PropertyGetBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000763));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_PropertyGetBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000763 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_PropertySetBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000764));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_PropertySetBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000764 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting get_SimpleGetBlockFormatting()
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000765));
        return unchecked((__cil_enum_020001ED)(v1));
    }

    public void set_SimpleGetBlockFormatting(ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting value)
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000765 = unchecked((__cil_enum_020001ED)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting get_SimpleSetBlockFormatting()
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000766));
        return unchecked((__cil_enum_020001ED)(v1));
    }

    public void set_SimpleSetBlockFormatting(ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting value)
    {
        // enum storage token=0x020001ED alias=__cil_enum_020001ED underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@PropertyFormatting; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000766 = unchecked((__cil_enum_020001ED)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_EventBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000767));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_EventBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000767 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_EventAddBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000768));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_EventAddBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000768 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_EventRemoveBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000769));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_EventRemoveBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000769 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public bool get_AllowEventAddBlockInline()
    {
        return this.__il_field_0400076A;
    }

    public void set_AllowEventAddBlockInline(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400076A = __cil_bool_store(v1);
        return;
    }

    public bool get_AllowEventRemoveBlockInline()
    {
        return this.__il_field_0400076B;
    }

    public void set_AllowEventRemoveBlockInline(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400076B = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_StatementBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400076C));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_StatementBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400076C = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public bool get_AllowIfBlockInline()
    {
        return this.__il_field_0400076D;
    }

    public void set_AllowIfBlockInline(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400076D = __cil_bool_store(v1);
        return;
    }

    public bool get_AllowOneLinedArrayInitialziers()
    {
        return this.allowOneLinedArrayInitialziers;
    }

    public void set_AllowOneLinedArrayInitialziers(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.allowOneLinedArrayInitialziers = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_ElseNewLinePlacement()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_0400076F));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_ElseNewLinePlacement(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_0400076F = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_ElseIfNewLinePlacement()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000770));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_ElseIfNewLinePlacement(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000770 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_CatchNewLinePlacement()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000771));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_CatchNewLinePlacement(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000771 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_FinallyNewLinePlacement()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000772));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_FinallyNewLinePlacement(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000772 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_WhileNewLinePlacement()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000773));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_WhileNewLinePlacement(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000773 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_EmbeddedStatementPlacement()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.embeddedStatementPlacement));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_EmbeddedStatementPlacement(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.embeddedStatementPlacement = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public bool get_SpaceBeforeMethodDeclarationParentheses()
    {
        return this.__il_field_04000775;
    }

    public void set_SpaceBeforeMethodDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000775 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBetweenEmptyMethodDeclarationParentheses()
    {
        return this.__il_field_04000776;
    }

    public void set_SpaceBetweenEmptyMethodDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000776 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeMethodDeclarationParameterComma()
    {
        return this.__il_field_04000777;
    }

    public void set_SpaceBeforeMethodDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000777 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterMethodDeclarationParameterComma()
    {
        return this.__il_field_04000778;
    }

    public void set_SpaceAfterMethodDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000778 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceWithinMethodDeclarationParentheses()
    {
        return this.__il_field_04000779;
    }

    public void set_SpaceWithinMethodDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000779 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeMethodCallParentheses()
    {
        return this.__il_field_0400077A;
    }

    public void set_SpaceBeforeMethodCallParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400077A = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBetweenEmptyMethodCallParentheses()
    {
        return this.__il_field_0400077B;
    }

    public void set_SpaceBetweenEmptyMethodCallParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400077B = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeMethodCallParameterComma()
    {
        return this.__il_field_0400077C;
    }

    public void set_SpaceBeforeMethodCallParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400077C = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterMethodCallParameterComma()
    {
        return this.__il_field_0400077D;
    }

    public void set_SpaceAfterMethodCallParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400077D = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceWithinMethodCallParentheses()
    {
        return this.__il_field_0400077E;
    }

    public void set_SpaceWithinMethodCallParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400077E = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeFieldDeclarationComma()
    {
        return this.__il_field_0400077F;
    }

    public void set_SpaceBeforeFieldDeclarationComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400077F = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterFieldDeclarationComma()
    {
        return this.__il_field_04000780;
    }

    public void set_SpaceAfterFieldDeclarationComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000780 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeLocalVariableDeclarationComma()
    {
        return this.__il_field_04000781;
    }

    public void set_SpaceBeforeLocalVariableDeclarationComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000781 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterLocalVariableDeclarationComma()
    {
        return this.__il_field_04000782;
    }

    public void set_SpaceAfterLocalVariableDeclarationComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000782 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeConstructorDeclarationParentheses()
    {
        return this.__il_field_04000783;
    }

    public void set_SpaceBeforeConstructorDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000783 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBetweenEmptyConstructorDeclarationParentheses()
    {
        return this.__il_field_04000784;
    }

    public void set_SpaceBetweenEmptyConstructorDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000784 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeConstructorDeclarationParameterComma()
    {
        return this.__il_field_04000785;
    }

    public void set_SpaceBeforeConstructorDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000785 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterConstructorDeclarationParameterComma()
    {
        return this.__il_field_04000786;
    }

    public void set_SpaceAfterConstructorDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000786 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceWithinConstructorDeclarationParentheses()
    {
        return this.__il_field_04000787;
    }

    public void set_SpaceWithinConstructorDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000787 = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_NewLineBeforeConstructorInitializerColon()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000788));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_NewLineBeforeConstructorInitializerColon(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000788 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_NewLineAfterConstructorInitializerColon()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04000789));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_NewLineAfterConstructorInitializerColon(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04000789 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public bool get_SpaceBeforeIndexerDeclarationBracket()
    {
        return this.__il_field_0400078A;
    }

    public void set_SpaceBeforeIndexerDeclarationBracket(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400078A = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceWithinIndexerDeclarationBracket()
    {
        return this.__il_field_0400078B;
    }

    public void set_SpaceWithinIndexerDeclarationBracket(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400078B = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeIndexerDeclarationParameterComma()
    {
        return this.__il_field_0400078C;
    }

    public void set_SpaceBeforeIndexerDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400078C = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterIndexerDeclarationParameterComma()
    {
        return this.__il_field_0400078D;
    }

    public void set_SpaceAfterIndexerDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400078D = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeDelegateDeclarationParentheses()
    {
        return this.__il_field_0400078E;
    }

    public void set_SpaceBeforeDelegateDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400078E = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBetweenEmptyDelegateDeclarationParentheses()
    {
        return this.__il_field_0400078F;
    }

    public void set_SpaceBetweenEmptyDelegateDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400078F = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeDelegateDeclarationParameterComma()
    {
        return this.__il_field_04000790;
    }

    public void set_SpaceBeforeDelegateDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000790 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterDelegateDeclarationParameterComma()
    {
        return this.__il_field_04000791;
    }

    public void set_SpaceAfterDelegateDeclarationParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000791 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceWithinDelegateDeclarationParentheses()
    {
        return this.__il_field_04000792;
    }

    public void set_SpaceWithinDelegateDeclarationParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000792 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeNewParentheses()
    {
        return this.__il_field_04000793;
    }

    public void set_SpaceBeforeNewParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000793 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeIfParentheses()
    {
        return this.__il_field_04000794;
    }

    public void set_SpaceBeforeIfParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000794 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeWhileParentheses()
    {
        return this.__il_field_04000795;
    }

    public void set_SpaceBeforeWhileParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000795 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeForParentheses()
    {
        return this.__il_field_04000796;
    }

    public void set_SpaceBeforeForParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000796 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeForeachParentheses()
    {
        return this.__il_field_04000797;
    }

    public void set_SpaceBeforeForeachParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000797 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeCatchParentheses()
    {
        return this.__il_field_04000798;
    }

    public void set_SpaceBeforeCatchParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000798 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeSwitchParentheses()
    {
        return this.__il_field_04000799;
    }

    public void set_SpaceBeforeSwitchParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000799 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeLockParentheses()
    {
        return this.__il_field_0400079A;
    }

    public void set_SpaceBeforeLockParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400079A = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeUsingParentheses()
    {
        return this.__il_field_0400079B;
    }

    public void set_SpaceBeforeUsingParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400079B = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundAssignment()
    {
        return this.__il_field_0400079C;
    }

    public void set_SpaceAroundAssignment(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400079C = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundLogicalOperator()
    {
        return this.__il_field_0400079D;
    }

    public void set_SpaceAroundLogicalOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400079D = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundEqualityOperator()
    {
        return this.__il_field_0400079E;
    }

    public void set_SpaceAroundEqualityOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400079E = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundRelationalOperator()
    {
        return this.__il_field_0400079F;
    }

    public void set_SpaceAroundRelationalOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_0400079F = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundBitwiseOperator()
    {
        return this.__il_field_040007A0;
    }

    public void set_SpaceAroundBitwiseOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A0 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundAdditiveOperator()
    {
        return this.__il_field_040007A1;
    }

    public void set_SpaceAroundAdditiveOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A1 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundMultiplicativeOperator()
    {
        return this.__il_field_040007A2;
    }

    public void set_SpaceAroundMultiplicativeOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A2 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundShiftOperator()
    {
        return this.__il_field_040007A3;
    }

    public void set_SpaceAroundShiftOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A3 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundNullCoalescingOperator()
    {
        return this.__il_field_040007A4;
    }

    public void set_SpaceAroundNullCoalescingOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A4 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterUnsafeAddressOfOperator()
    {
        return this.__il_field_040007A5;
    }

    public void set_SpaceAfterUnsafeAddressOfOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A5 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterUnsafeAsteriskOfOperator()
    {
        return this.__il_field_040007A6;
    }

    public void set_SpaceAfterUnsafeAsteriskOfOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A6 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAroundUnsafeArrowOperator()
    {
        return this.__il_field_040007A7;
    }

    public void set_SpaceAroundUnsafeArrowOperator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A7 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinParentheses()
    {
        return this.__il_field_040007A8;
    }

    public void set_SpacesWithinParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A8 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinIfParentheses()
    {
        return this.__il_field_040007A9;
    }

    public void set_SpacesWithinIfParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007A9 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinWhileParentheses()
    {
        return this.__il_field_040007AA;
    }

    public void set_SpacesWithinWhileParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007AA = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinForParentheses()
    {
        return this.__il_field_040007AB;
    }

    public void set_SpacesWithinForParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007AB = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinForeachParentheses()
    {
        return this.__il_field_040007AC;
    }

    public void set_SpacesWithinForeachParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007AC = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinCatchParentheses()
    {
        return this.__il_field_040007AD;
    }

    public void set_SpacesWithinCatchParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007AD = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinSwitchParentheses()
    {
        return this.__il_field_040007AE;
    }

    public void set_SpacesWithinSwitchParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007AE = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinLockParentheses()
    {
        return this.__il_field_040007AF;
    }

    public void set_SpacesWithinLockParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007AF = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinUsingParentheses()
    {
        return this.__il_field_040007B0;
    }

    public void set_SpacesWithinUsingParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B0 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinCastParentheses()
    {
        return this.__il_field_040007B1;
    }

    public void set_SpacesWithinCastParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B1 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinSizeOfParentheses()
    {
        return this.__il_field_040007B2;
    }

    public void set_SpacesWithinSizeOfParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B2 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeSizeOfParentheses()
    {
        return this.__il_field_040007B3;
    }

    public void set_SpaceBeforeSizeOfParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B3 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinTypeOfParentheses()
    {
        return this.__il_field_040007B4;
    }

    public void set_SpacesWithinTypeOfParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B4 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinNewParentheses()
    {
        return this.__il_field_040007B5;
    }

    public void set_SpacesWithinNewParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B5 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesBetweenEmptyNewParentheses()
    {
        return this.__il_field_040007B6;
    }

    public void set_SpacesBetweenEmptyNewParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B6 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeNewParameterComma()
    {
        return this.__il_field_040007B7;
    }

    public void set_SpaceBeforeNewParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B7 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterNewParameterComma()
    {
        return this.__il_field_040007B8;
    }

    public void set_SpaceAfterNewParameterComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B8 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeTypeOfParentheses()
    {
        return this.__il_field_040007B9;
    }

    public void set_SpaceBeforeTypeOfParentheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007B9 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinCheckedExpressionParantheses()
    {
        return this.__il_field_040007BA;
    }

    public void set_SpacesWithinCheckedExpressionParantheses(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007BA = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeConditionalOperatorCondition()
    {
        return this.__il_field_040007BB;
    }

    public void set_SpaceBeforeConditionalOperatorCondition(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007BB = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterConditionalOperatorCondition()
    {
        return this.__il_field_040007BC;
    }

    public void set_SpaceAfterConditionalOperatorCondition(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007BC = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeConditionalOperatorSeparator()
    {
        return this.__il_field_040007BD;
    }

    public void set_SpaceBeforeConditionalOperatorSeparator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007BD = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterConditionalOperatorSeparator()
    {
        return this.__il_field_040007BE;
    }

    public void set_SpaceAfterConditionalOperatorSeparator(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007BE = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesWithinBrackets()
    {
        return this.__il_field_040007BF;
    }

    public void set_SpacesWithinBrackets(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007BF = __cil_bool_store(v1);
        return;
    }

    public bool get_SpacesBeforeBrackets()
    {
        return this.__il_field_040007C0;
    }

    public void set_SpacesBeforeBrackets(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C0 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeBracketComma()
    {
        return this.__il_field_040007C1;
    }

    public void set_SpaceBeforeBracketComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C1 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterBracketComma()
    {
        return this.__il_field_040007C2;
    }

    public void set_SpaceAfterBracketComma(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C2 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeForSemicolon()
    {
        return this.__il_field_040007C3;
    }

    public void set_SpaceBeforeForSemicolon(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C3 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterForSemicolon()
    {
        return this.__il_field_040007C4;
    }

    public void set_SpaceAfterForSemicolon(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C4 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceAfterTypecast()
    {
        return this.__il_field_040007C5;
    }

    public void set_SpaceAfterTypecast(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C5 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeArrayDeclarationBrackets()
    {
        return this.__il_field_040007C6;
    }

    public void set_SpaceBeforeArrayDeclarationBrackets(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C6 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceInNamedArgumentAfterDoubleColon()
    {
        return this.__il_field_040007C7;
    }

    public void set_SpaceInNamedArgumentAfterDoubleColon(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C7 = __cil_bool_store(v1);
        return;
    }

    public bool get_RemoveEndOfLineWhiteSpace()
    {
        return this.__il_field_040007C8;
    }

    public void set_RemoveEndOfLineWhiteSpace(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C8 = __cil_bool_store(v1);
        return;
    }

    public bool get_SpaceBeforeSemicolon()
    {
        return this.__il_field_040007C9;
    }

    public void set_SpaceBeforeSemicolon(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007C9 = __cil_bool_store(v1);
        return;
    }

    public int get_MinimumBlankLinesBeforeUsings()
    {
        int v1 = this.__il_field_040007CA;
        return v1;
    }

    public void set_MinimumBlankLinesBeforeUsings(int value)
    {
        this.__il_field_040007CA = value;
        return;
    }

    public int get_MinimumBlankLinesAfterUsings()
    {
        int v1 = this.__il_field_040007CB;
        return v1;
    }

    public void set_MinimumBlankLinesAfterUsings(int value)
    {
        this.__il_field_040007CB = value;
        return;
    }

    public int get_MinimumBlankLinesBeforeFirstDeclaration()
    {
        int v1 = this.__il_field_040007CC;
        return v1;
    }

    public void set_MinimumBlankLinesBeforeFirstDeclaration(int value)
    {
        this.__il_field_040007CC = value;
        return;
    }

    public int get_MinimumBlankLinesBetweenTypes()
    {
        int v1 = this.__il_field_040007CD;
        return v1;
    }

    public void set_MinimumBlankLinesBetweenTypes(int value)
    {
        this.__il_field_040007CD = value;
        return;
    }

    public int get_MinimumBlankLinesBetweenFields()
    {
        int v1 = this.__il_field_040007CE;
        return v1;
    }

    public void set_MinimumBlankLinesBetweenFields(int value)
    {
        this.__il_field_040007CE = value;
        return;
    }

    public int get_MinimumBlankLinesBetweenEventFields()
    {
        int v1 = this.__il_field_040007CF;
        return v1;
    }

    public void set_MinimumBlankLinesBetweenEventFields(int value)
    {
        this.__il_field_040007CF = value;
        return;
    }

    public int get_MinimumBlankLinesBetweenMembers()
    {
        int v1 = this.__il_field_040007D0;
        return v1;
    }

    public void set_MinimumBlankLinesBetweenMembers(int value)
    {
        this.__il_field_040007D0 = value;
        return;
    }

    public int get_MinimumBlankLinesAroundRegion()
    {
        int v1 = this.__il_field_040007D1;
        return v1;
    }

    public void set_MinimumBlankLinesAroundRegion(int value)
    {
        this.__il_field_040007D1 = value;
        return;
    }

    public int get_MinimumBlankLinesInsideRegion()
    {
        int v1 = this.__il_field_040007D2;
        return v1;
    }

    public void set_MinimumBlankLinesInsideRegion(int value)
    {
        this.__il_field_040007D2 = value;
        return;
    }

    public bool get_KeepCommentsAtFirstColumn()
    {
        return this.__il_field_040007D3;
    }

    public void set_KeepCommentsAtFirstColumn(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007D3 = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping get_ArrayInitializerWrapping()
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007D4));
        return unchecked((__cil_enum_020001EE)(v1));
    }

    public void set_ArrayInitializerWrapping(ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping value)
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007D4 = unchecked((__cil_enum_020001EE)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle get_ArrayInitializerBraceStyle()
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007D5));
        return unchecked((__cil_enum_020001EC)(v1));
    }

    public void set_ArrayInitializerBraceStyle(ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle value)
    {
        // enum storage token=0x020001EC alias=__cil_enum_020001EC underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@BraceStyle; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007D5 = unchecked((__cil_enum_020001EC)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping get_ChainedMethodCallWrapping()
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007D6));
        return unchecked((__cil_enum_020001EE)(v1));
    }

    public void set_ChainedMethodCallWrapping(ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping value)
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007D6 = unchecked((__cil_enum_020001EE)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping get_MethodCallArgumentWrapping()
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007D7));
        return unchecked((__cil_enum_020001EE)(v1));
    }

    public void set_MethodCallArgumentWrapping(ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping value)
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007D7 = unchecked((__cil_enum_020001EE)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_NewLineAferMethodCallOpenParentheses()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007D8));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_NewLineAferMethodCallOpenParentheses(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007D8 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_MethodCallClosingParenthesesOnNewLine()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007D9));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_MethodCallClosingParenthesesOnNewLine(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007D9 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping get_IndexerArgumentWrapping()
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007DA));
        return unchecked((__cil_enum_020001EE)(v1));
    }

    public void set_IndexerArgumentWrapping(ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping value)
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007DA = unchecked((__cil_enum_020001EE)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_NewLineAferIndexerOpenBracket()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007DB));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_NewLineAferIndexerOpenBracket(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007DB = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_IndexerClosingBracketOnNewLine()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007DC));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_IndexerClosingBracketOnNewLine(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007DC = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping get_MethodDeclarationParameterWrapping()
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007DD));
        return unchecked((__cil_enum_020001EE)(v1));
    }

    public void set_MethodDeclarationParameterWrapping(ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping value)
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007DD = unchecked((__cil_enum_020001EE)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_NewLineAferMethodDeclarationOpenParentheses()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007DE));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_NewLineAferMethodDeclarationOpenParentheses(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007DE = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_MethodDeclarationClosingParenthesesOnNewLine()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007DF));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_MethodDeclarationClosingParenthesesOnNewLine(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007DF = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping get_IndexerDeclarationParameterWrapping()
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007E0));
        return unchecked((__cil_enum_020001EE)(v1));
    }

    public void set_IndexerDeclarationParameterWrapping(ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping value)
    {
        // enum storage token=0x020001EE alias=__cil_enum_020001EE underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@Wrapping; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007E0 = unchecked((__cil_enum_020001EE)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_NewLineAferIndexerDeclarationOpenBracket()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007E1));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_NewLineAferIndexerDeclarationOpenBracket(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007E1 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_IndexerDeclarationClosingBracketOnNewLine()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007E2));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_IndexerDeclarationClosingBracketOnNewLine(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007E2 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public bool get_AlignToFirstIndexerArgument()
    {
        return this.__il_field_040007E3;
    }

    public void set_AlignToFirstIndexerArgument(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007E3 = __cil_bool_store(v1);
        return;
    }

    public bool get_AlignToFirstIndexerDeclarationParameter()
    {
        return this.__il_field_040007E4;
    }

    public void set_AlignToFirstIndexerDeclarationParameter(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007E4 = __cil_bool_store(v1);
        return;
    }

    public bool get_AlignToFirstMethodCallArgument()
    {
        return this.__il_field_040007E5;
    }

    public void set_AlignToFirstMethodCallArgument(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007E5 = __cil_bool_store(v1);
        return;
    }

    public bool get_AlignToFirstMethodDeclarationParameter()
    {
        return this.__il_field_040007E6;
    }

    public void set_AlignToFirstMethodDeclarationParameter(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_040007E6 = __cil_bool_store(v1);
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement get_NewLineBeforeNewQueryClause()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007E7));
        return unchecked((__cil_enum_020001EF)(v1));
    }

    public void set_NewLineBeforeNewQueryClause(ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement value)
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007E7 = unchecked((__cil_enum_020001EF)(v1));
        return;
    }

    public ICSharpCode.Decompiler.CSharp.OutputVisitor.UsingPlacement get_UsingPlacement()
    {
        // enum storage token=0x020001F0 alias=__cil_enum_020001F0 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@UsingPlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_040007E8));
        return unchecked((__cil_enum_020001F0)(v1));
    }

    public void set_UsingPlacement(ICSharpCode.Decompiler.CSharp.OutputVisitor.UsingPlacement value)
    {
        // enum storage token=0x020001F0 alias=__cil_enum_020001F0 underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@UsingPlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_040007E8 = unchecked((__cil_enum_020001F0)(v1));
        return;
    }

    internal CSharpFormattingOptions()
    {
        // enum storage token=0x020001EF alias=__cil_enum_020001EF underlying=int: global::@ICSharpCode.@Decompiler.@CSharp.@OutputVisitor.@NewLinePlacement; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        this.allowOneLinedArrayInitialziers = __cil_bool_store(1);
        this.embeddedStatementPlacement = unchecked((__cil_enum_020001EF)(1));
        __cil_core_object_ctor_0A000092(this);
        return;
    }
    // property string Name { get: get_Name; set: set_Name; }
    // property bool IsBuiltIn { get: get_IsBuiltIn; set: set_IsBuiltIn; }
    // property bool IndentNamespaceBody { get: get_IndentNamespaceBody; set: set_IndentNamespaceBody; }
    // property bool IndentClassBody { get: get_IndentClassBody; set: set_IndentClassBody; }
    // property bool IndentInterfaceBody { get: get_IndentInterfaceBody; set: set_IndentInterfaceBody; }
    // property bool IndentStructBody { get: get_IndentStructBody; set: set_IndentStructBody; }
    // property bool IndentEnumBody { get: get_IndentEnumBody; set: set_IndentEnumBody; }
    // property bool IndentMethodBody { get: get_IndentMethodBody; set: set_IndentMethodBody; }
    // property bool IndentPropertyBody { get: get_IndentPropertyBody; set: set_IndentPropertyBody; }
    // property bool IndentEventBody { get: get_IndentEventBody; set: set_IndentEventBody; }
    // property bool IndentBlocks { get: get_IndentBlocks; set: set_IndentBlocks; }
    // property bool IndentSwitchBody { get: get_IndentSwitchBody; set: set_IndentSwitchBody; }
    // property bool IndentCaseBody { get: get_IndentCaseBody; set: set_IndentCaseBody; }
    // property bool IndentBreakStatements { get: get_IndentBreakStatements; set: set_IndentBreakStatements; }
    // property bool AlignEmbeddedStatements { get: get_AlignEmbeddedStatements; set: set_AlignEmbeddedStatements; }
    // property bool AlignElseInIfStatements { get: get_AlignElseInIfStatements; set: set_AlignElseInIfStatements; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting AutoPropertyFormatting { get: get_AutoPropertyFormatting; set: set_AutoPropertyFormatting; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting SimplePropertyFormatting { get: get_SimplePropertyFormatting; set: set_SimplePropertyFormatting; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.EmptyLineFormatting EmptyLineFormatting { get: get_EmptyLineFormatting; set: set_EmptyLineFormatting; }
    // property bool IndentPreprocessorDirectives { get: get_IndentPreprocessorDirectives; set: set_IndentPreprocessorDirectives; }
    // property bool AlignToMemberReferenceDot { get: get_AlignToMemberReferenceDot; set: set_AlignToMemberReferenceDot; }
    // property bool IndentBlocksInsideExpressions { get: get_IndentBlocksInsideExpressions; set: set_IndentBlocksInsideExpressions; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle NamespaceBraceStyle { get: get_NamespaceBraceStyle; set: set_NamespaceBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle ClassBraceStyle { get: get_ClassBraceStyle; set: set_ClassBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle InterfaceBraceStyle { get: get_InterfaceBraceStyle; set: set_InterfaceBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle StructBraceStyle { get: get_StructBraceStyle; set: set_StructBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle EnumBraceStyle { get: get_EnumBraceStyle; set: set_EnumBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle MethodBraceStyle { get: get_MethodBraceStyle; set: set_MethodBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle AnonymousMethodBraceStyle { get: get_AnonymousMethodBraceStyle; set: set_AnonymousMethodBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle ConstructorBraceStyle { get: get_ConstructorBraceStyle; set: set_ConstructorBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle DestructorBraceStyle { get: get_DestructorBraceStyle; set: set_DestructorBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle PropertyBraceStyle { get: get_PropertyBraceStyle; set: set_PropertyBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle PropertyGetBraceStyle { get: get_PropertyGetBraceStyle; set: set_PropertyGetBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle PropertySetBraceStyle { get: get_PropertySetBraceStyle; set: set_PropertySetBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting SimpleGetBlockFormatting { get: get_SimpleGetBlockFormatting; set: set_SimpleGetBlockFormatting; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.PropertyFormatting SimpleSetBlockFormatting { get: get_SimpleSetBlockFormatting; set: set_SimpleSetBlockFormatting; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle EventBraceStyle { get: get_EventBraceStyle; set: set_EventBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle EventAddBraceStyle { get: get_EventAddBraceStyle; set: set_EventAddBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle EventRemoveBraceStyle { get: get_EventRemoveBraceStyle; set: set_EventRemoveBraceStyle; }
    // property bool AllowEventAddBlockInline { get: get_AllowEventAddBlockInline; set: set_AllowEventAddBlockInline; }
    // property bool AllowEventRemoveBlockInline { get: get_AllowEventRemoveBlockInline; set: set_AllowEventRemoveBlockInline; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle StatementBraceStyle { get: get_StatementBraceStyle; set: set_StatementBraceStyle; }
    // property bool AllowIfBlockInline { get: get_AllowIfBlockInline; set: set_AllowIfBlockInline; }
    // property bool AllowOneLinedArrayInitialziers { get: get_AllowOneLinedArrayInitialziers; set: set_AllowOneLinedArrayInitialziers; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement ElseNewLinePlacement { get: get_ElseNewLinePlacement; set: set_ElseNewLinePlacement; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement ElseIfNewLinePlacement { get: get_ElseIfNewLinePlacement; set: set_ElseIfNewLinePlacement; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement CatchNewLinePlacement { get: get_CatchNewLinePlacement; set: set_CatchNewLinePlacement; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement FinallyNewLinePlacement { get: get_FinallyNewLinePlacement; set: set_FinallyNewLinePlacement; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement WhileNewLinePlacement { get: get_WhileNewLinePlacement; set: set_WhileNewLinePlacement; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement EmbeddedStatementPlacement { get: get_EmbeddedStatementPlacement; set: set_EmbeddedStatementPlacement; }
    // property bool SpaceBeforeMethodDeclarationParentheses { get: get_SpaceBeforeMethodDeclarationParentheses; set: set_SpaceBeforeMethodDeclarationParentheses; }
    // property bool SpaceBetweenEmptyMethodDeclarationParentheses { get: get_SpaceBetweenEmptyMethodDeclarationParentheses; set: set_SpaceBetweenEmptyMethodDeclarationParentheses; }
    // property bool SpaceBeforeMethodDeclarationParameterComma { get: get_SpaceBeforeMethodDeclarationParameterComma; set: set_SpaceBeforeMethodDeclarationParameterComma; }
    // property bool SpaceAfterMethodDeclarationParameterComma { get: get_SpaceAfterMethodDeclarationParameterComma; set: set_SpaceAfterMethodDeclarationParameterComma; }
    // property bool SpaceWithinMethodDeclarationParentheses { get: get_SpaceWithinMethodDeclarationParentheses; set: set_SpaceWithinMethodDeclarationParentheses; }
    // property bool SpaceBeforeMethodCallParentheses { get: get_SpaceBeforeMethodCallParentheses; set: set_SpaceBeforeMethodCallParentheses; }
    // property bool SpaceBetweenEmptyMethodCallParentheses { get: get_SpaceBetweenEmptyMethodCallParentheses; set: set_SpaceBetweenEmptyMethodCallParentheses; }
    // property bool SpaceBeforeMethodCallParameterComma { get: get_SpaceBeforeMethodCallParameterComma; set: set_SpaceBeforeMethodCallParameterComma; }
    // property bool SpaceAfterMethodCallParameterComma { get: get_SpaceAfterMethodCallParameterComma; set: set_SpaceAfterMethodCallParameterComma; }
    // property bool SpaceWithinMethodCallParentheses { get: get_SpaceWithinMethodCallParentheses; set: set_SpaceWithinMethodCallParentheses; }
    // property bool SpaceBeforeFieldDeclarationComma { get: get_SpaceBeforeFieldDeclarationComma; set: set_SpaceBeforeFieldDeclarationComma; }
    // property bool SpaceAfterFieldDeclarationComma { get: get_SpaceAfterFieldDeclarationComma; set: set_SpaceAfterFieldDeclarationComma; }
    // property bool SpaceBeforeLocalVariableDeclarationComma { get: get_SpaceBeforeLocalVariableDeclarationComma; set: set_SpaceBeforeLocalVariableDeclarationComma; }
    // property bool SpaceAfterLocalVariableDeclarationComma { get: get_SpaceAfterLocalVariableDeclarationComma; set: set_SpaceAfterLocalVariableDeclarationComma; }
    // property bool SpaceBeforeConstructorDeclarationParentheses { get: get_SpaceBeforeConstructorDeclarationParentheses; set: set_SpaceBeforeConstructorDeclarationParentheses; }
    // property bool SpaceBetweenEmptyConstructorDeclarationParentheses { get: get_SpaceBetweenEmptyConstructorDeclarationParentheses; set: set_SpaceBetweenEmptyConstructorDeclarationParentheses; }
    // property bool SpaceBeforeConstructorDeclarationParameterComma { get: get_SpaceBeforeConstructorDeclarationParameterComma; set: set_SpaceBeforeConstructorDeclarationParameterComma; }
    // property bool SpaceAfterConstructorDeclarationParameterComma { get: get_SpaceAfterConstructorDeclarationParameterComma; set: set_SpaceAfterConstructorDeclarationParameterComma; }
    // property bool SpaceWithinConstructorDeclarationParentheses { get: get_SpaceWithinConstructorDeclarationParentheses; set: set_SpaceWithinConstructorDeclarationParentheses; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement NewLineBeforeConstructorInitializerColon { get: get_NewLineBeforeConstructorInitializerColon; set: set_NewLineBeforeConstructorInitializerColon; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement NewLineAfterConstructorInitializerColon { get: get_NewLineAfterConstructorInitializerColon; set: set_NewLineAfterConstructorInitializerColon; }
    // property bool SpaceBeforeIndexerDeclarationBracket { get: get_SpaceBeforeIndexerDeclarationBracket; set: set_SpaceBeforeIndexerDeclarationBracket; }
    // property bool SpaceWithinIndexerDeclarationBracket { get: get_SpaceWithinIndexerDeclarationBracket; set: set_SpaceWithinIndexerDeclarationBracket; }
    // property bool SpaceBeforeIndexerDeclarationParameterComma { get: get_SpaceBeforeIndexerDeclarationParameterComma; set: set_SpaceBeforeIndexerDeclarationParameterComma; }
    // property bool SpaceAfterIndexerDeclarationParameterComma { get: get_SpaceAfterIndexerDeclarationParameterComma; set: set_SpaceAfterIndexerDeclarationParameterComma; }
    // property bool SpaceBeforeDelegateDeclarationParentheses { get: get_SpaceBeforeDelegateDeclarationParentheses; set: set_SpaceBeforeDelegateDeclarationParentheses; }
    // property bool SpaceBetweenEmptyDelegateDeclarationParentheses { get: get_SpaceBetweenEmptyDelegateDeclarationParentheses; set: set_SpaceBetweenEmptyDelegateDeclarationParentheses; }
    // property bool SpaceBeforeDelegateDeclarationParameterComma { get: get_SpaceBeforeDelegateDeclarationParameterComma; set: set_SpaceBeforeDelegateDeclarationParameterComma; }
    // property bool SpaceAfterDelegateDeclarationParameterComma { get: get_SpaceAfterDelegateDeclarationParameterComma; set: set_SpaceAfterDelegateDeclarationParameterComma; }
    // property bool SpaceWithinDelegateDeclarationParentheses { get: get_SpaceWithinDelegateDeclarationParentheses; set: set_SpaceWithinDelegateDeclarationParentheses; }
    // property bool SpaceBeforeNewParentheses { get: get_SpaceBeforeNewParentheses; set: set_SpaceBeforeNewParentheses; }
    // property bool SpaceBeforeIfParentheses { get: get_SpaceBeforeIfParentheses; set: set_SpaceBeforeIfParentheses; }
    // property bool SpaceBeforeWhileParentheses { get: get_SpaceBeforeWhileParentheses; set: set_SpaceBeforeWhileParentheses; }
    // property bool SpaceBeforeForParentheses { get: get_SpaceBeforeForParentheses; set: set_SpaceBeforeForParentheses; }
    // property bool SpaceBeforeForeachParentheses { get: get_SpaceBeforeForeachParentheses; set: set_SpaceBeforeForeachParentheses; }
    // property bool SpaceBeforeCatchParentheses { get: get_SpaceBeforeCatchParentheses; set: set_SpaceBeforeCatchParentheses; }
    // property bool SpaceBeforeSwitchParentheses { get: get_SpaceBeforeSwitchParentheses; set: set_SpaceBeforeSwitchParentheses; }
    // property bool SpaceBeforeLockParentheses { get: get_SpaceBeforeLockParentheses; set: set_SpaceBeforeLockParentheses; }
    // property bool SpaceBeforeUsingParentheses { get: get_SpaceBeforeUsingParentheses; set: set_SpaceBeforeUsingParentheses; }
    // property bool SpaceAroundAssignment { get: get_SpaceAroundAssignment; set: set_SpaceAroundAssignment; }
    // property bool SpaceAroundLogicalOperator { get: get_SpaceAroundLogicalOperator; set: set_SpaceAroundLogicalOperator; }
    // property bool SpaceAroundEqualityOperator { get: get_SpaceAroundEqualityOperator; set: set_SpaceAroundEqualityOperator; }
    // property bool SpaceAroundRelationalOperator { get: get_SpaceAroundRelationalOperator; set: set_SpaceAroundRelationalOperator; }
    // property bool SpaceAroundBitwiseOperator { get: get_SpaceAroundBitwiseOperator; set: set_SpaceAroundBitwiseOperator; }
    // property bool SpaceAroundAdditiveOperator { get: get_SpaceAroundAdditiveOperator; set: set_SpaceAroundAdditiveOperator; }
    // property bool SpaceAroundMultiplicativeOperator { get: get_SpaceAroundMultiplicativeOperator; set: set_SpaceAroundMultiplicativeOperator; }
    // property bool SpaceAroundShiftOperator { get: get_SpaceAroundShiftOperator; set: set_SpaceAroundShiftOperator; }
    // property bool SpaceAroundNullCoalescingOperator { get: get_SpaceAroundNullCoalescingOperator; set: set_SpaceAroundNullCoalescingOperator; }
    // property bool SpaceAfterUnsafeAddressOfOperator { get: get_SpaceAfterUnsafeAddressOfOperator; set: set_SpaceAfterUnsafeAddressOfOperator; }
    // property bool SpaceAfterUnsafeAsteriskOfOperator { get: get_SpaceAfterUnsafeAsteriskOfOperator; set: set_SpaceAfterUnsafeAsteriskOfOperator; }
    // property bool SpaceAroundUnsafeArrowOperator { get: get_SpaceAroundUnsafeArrowOperator; set: set_SpaceAroundUnsafeArrowOperator; }
    // property bool SpacesWithinParentheses { get: get_SpacesWithinParentheses; set: set_SpacesWithinParentheses; }
    // property bool SpacesWithinIfParentheses { get: get_SpacesWithinIfParentheses; set: set_SpacesWithinIfParentheses; }
    // property bool SpacesWithinWhileParentheses { get: get_SpacesWithinWhileParentheses; set: set_SpacesWithinWhileParentheses; }
    // property bool SpacesWithinForParentheses { get: get_SpacesWithinForParentheses; set: set_SpacesWithinForParentheses; }
    // property bool SpacesWithinForeachParentheses { get: get_SpacesWithinForeachParentheses; set: set_SpacesWithinForeachParentheses; }
    // property bool SpacesWithinCatchParentheses { get: get_SpacesWithinCatchParentheses; set: set_SpacesWithinCatchParentheses; }
    // property bool SpacesWithinSwitchParentheses { get: get_SpacesWithinSwitchParentheses; set: set_SpacesWithinSwitchParentheses; }
    // property bool SpacesWithinLockParentheses { get: get_SpacesWithinLockParentheses; set: set_SpacesWithinLockParentheses; }
    // property bool SpacesWithinUsingParentheses { get: get_SpacesWithinUsingParentheses; set: set_SpacesWithinUsingParentheses; }
    // property bool SpacesWithinCastParentheses { get: get_SpacesWithinCastParentheses; set: set_SpacesWithinCastParentheses; }
    // property bool SpacesWithinSizeOfParentheses { get: get_SpacesWithinSizeOfParentheses; set: set_SpacesWithinSizeOfParentheses; }
    // property bool SpaceBeforeSizeOfParentheses { get: get_SpaceBeforeSizeOfParentheses; set: set_SpaceBeforeSizeOfParentheses; }
    // property bool SpacesWithinTypeOfParentheses { get: get_SpacesWithinTypeOfParentheses; set: set_SpacesWithinTypeOfParentheses; }
    // property bool SpacesWithinNewParentheses { get: get_SpacesWithinNewParentheses; set: set_SpacesWithinNewParentheses; }
    // property bool SpacesBetweenEmptyNewParentheses { get: get_SpacesBetweenEmptyNewParentheses; set: set_SpacesBetweenEmptyNewParentheses; }
    // property bool SpaceBeforeNewParameterComma { get: get_SpaceBeforeNewParameterComma; set: set_SpaceBeforeNewParameterComma; }
    // property bool SpaceAfterNewParameterComma { get: get_SpaceAfterNewParameterComma; set: set_SpaceAfterNewParameterComma; }
    // property bool SpaceBeforeTypeOfParentheses { get: get_SpaceBeforeTypeOfParentheses; set: set_SpaceBeforeTypeOfParentheses; }
    // property bool SpacesWithinCheckedExpressionParantheses { get: get_SpacesWithinCheckedExpressionParantheses; set: set_SpacesWithinCheckedExpressionParantheses; }
    // property bool SpaceBeforeConditionalOperatorCondition { get: get_SpaceBeforeConditionalOperatorCondition; set: set_SpaceBeforeConditionalOperatorCondition; }
    // property bool SpaceAfterConditionalOperatorCondition { get: get_SpaceAfterConditionalOperatorCondition; set: set_SpaceAfterConditionalOperatorCondition; }
    // property bool SpaceBeforeConditionalOperatorSeparator { get: get_SpaceBeforeConditionalOperatorSeparator; set: set_SpaceBeforeConditionalOperatorSeparator; }
    // property bool SpaceAfterConditionalOperatorSeparator { get: get_SpaceAfterConditionalOperatorSeparator; set: set_SpaceAfterConditionalOperatorSeparator; }
    // property bool SpacesWithinBrackets { get: get_SpacesWithinBrackets; set: set_SpacesWithinBrackets; }
    // property bool SpacesBeforeBrackets { get: get_SpacesBeforeBrackets; set: set_SpacesBeforeBrackets; }
    // property bool SpaceBeforeBracketComma { get: get_SpaceBeforeBracketComma; set: set_SpaceBeforeBracketComma; }
    // property bool SpaceAfterBracketComma { get: get_SpaceAfterBracketComma; set: set_SpaceAfterBracketComma; }
    // property bool SpaceBeforeForSemicolon { get: get_SpaceBeforeForSemicolon; set: set_SpaceBeforeForSemicolon; }
    // property bool SpaceAfterForSemicolon { get: get_SpaceAfterForSemicolon; set: set_SpaceAfterForSemicolon; }
    // property bool SpaceAfterTypecast { get: get_SpaceAfterTypecast; set: set_SpaceAfterTypecast; }
    // property bool SpaceBeforeArrayDeclarationBrackets { get: get_SpaceBeforeArrayDeclarationBrackets; set: set_SpaceBeforeArrayDeclarationBrackets; }
    // property bool SpaceInNamedArgumentAfterDoubleColon { get: get_SpaceInNamedArgumentAfterDoubleColon; set: set_SpaceInNamedArgumentAfterDoubleColon; }
    // property bool RemoveEndOfLineWhiteSpace { get: get_RemoveEndOfLineWhiteSpace; set: set_RemoveEndOfLineWhiteSpace; }
    // property bool SpaceBeforeSemicolon { get: get_SpaceBeforeSemicolon; set: set_SpaceBeforeSemicolon; }
    // property int MinimumBlankLinesBeforeUsings { get: get_MinimumBlankLinesBeforeUsings; set: set_MinimumBlankLinesBeforeUsings; }
    // property int MinimumBlankLinesAfterUsings { get: get_MinimumBlankLinesAfterUsings; set: set_MinimumBlankLinesAfterUsings; }
    // property int MinimumBlankLinesBeforeFirstDeclaration { get: get_MinimumBlankLinesBeforeFirstDeclaration; set: set_MinimumBlankLinesBeforeFirstDeclaration; }
    // property int MinimumBlankLinesBetweenTypes { get: get_MinimumBlankLinesBetweenTypes; set: set_MinimumBlankLinesBetweenTypes; }
    // property int MinimumBlankLinesBetweenFields { get: get_MinimumBlankLinesBetweenFields; set: set_MinimumBlankLinesBetweenFields; }
    // property int MinimumBlankLinesBetweenEventFields { get: get_MinimumBlankLinesBetweenEventFields; set: set_MinimumBlankLinesBetweenEventFields; }
    // property int MinimumBlankLinesBetweenMembers { get: get_MinimumBlankLinesBetweenMembers; set: set_MinimumBlankLinesBetweenMembers; }
    // property int MinimumBlankLinesAroundRegion { get: get_MinimumBlankLinesAroundRegion; set: set_MinimumBlankLinesAroundRegion; }
    // property int MinimumBlankLinesInsideRegion { get: get_MinimumBlankLinesInsideRegion; set: set_MinimumBlankLinesInsideRegion; }
    // property bool KeepCommentsAtFirstColumn { get: get_KeepCommentsAtFirstColumn; set: set_KeepCommentsAtFirstColumn; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping ArrayInitializerWrapping { get: get_ArrayInitializerWrapping; set: set_ArrayInitializerWrapping; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.BraceStyle ArrayInitializerBraceStyle { get: get_ArrayInitializerBraceStyle; set: set_ArrayInitializerBraceStyle; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping ChainedMethodCallWrapping { get: get_ChainedMethodCallWrapping; set: set_ChainedMethodCallWrapping; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping MethodCallArgumentWrapping { get: get_MethodCallArgumentWrapping; set: set_MethodCallArgumentWrapping; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement NewLineAferMethodCallOpenParentheses { get: get_NewLineAferMethodCallOpenParentheses; set: set_NewLineAferMethodCallOpenParentheses; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement MethodCallClosingParenthesesOnNewLine { get: get_MethodCallClosingParenthesesOnNewLine; set: set_MethodCallClosingParenthesesOnNewLine; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping IndexerArgumentWrapping { get: get_IndexerArgumentWrapping; set: set_IndexerArgumentWrapping; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement NewLineAferIndexerOpenBracket { get: get_NewLineAferIndexerOpenBracket; set: set_NewLineAferIndexerOpenBracket; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement IndexerClosingBracketOnNewLine { get: get_IndexerClosingBracketOnNewLine; set: set_IndexerClosingBracketOnNewLine; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping MethodDeclarationParameterWrapping { get: get_MethodDeclarationParameterWrapping; set: set_MethodDeclarationParameterWrapping; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement NewLineAferMethodDeclarationOpenParentheses { get: get_NewLineAferMethodDeclarationOpenParentheses; set: set_NewLineAferMethodDeclarationOpenParentheses; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement MethodDeclarationClosingParenthesesOnNewLine { get: get_MethodDeclarationClosingParenthesesOnNewLine; set: set_MethodDeclarationClosingParenthesesOnNewLine; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.Wrapping IndexerDeclarationParameterWrapping { get: get_IndexerDeclarationParameterWrapping; set: set_IndexerDeclarationParameterWrapping; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement NewLineAferIndexerDeclarationOpenBracket { get: get_NewLineAferIndexerDeclarationOpenBracket; set: set_NewLineAferIndexerDeclarationOpenBracket; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement IndexerDeclarationClosingBracketOnNewLine { get: get_IndexerDeclarationClosingBracketOnNewLine; set: set_IndexerDeclarationClosingBracketOnNewLine; }
    // property bool AlignToFirstIndexerArgument { get: get_AlignToFirstIndexerArgument; set: set_AlignToFirstIndexerArgument; }
    // property bool AlignToFirstIndexerDeclarationParameter { get: get_AlignToFirstIndexerDeclarationParameter; set: set_AlignToFirstIndexerDeclarationParameter; }
    // property bool AlignToFirstMethodCallArgument { get: get_AlignToFirstMethodCallArgument; set: set_AlignToFirstMethodCallArgument; }
    // property bool AlignToFirstMethodDeclarationParameter { get: get_AlignToFirstMethodDeclarationParameter; set: set_AlignToFirstMethodDeclarationParameter; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.NewLinePlacement NewLineBeforeNewQueryClause { get: get_NewLineBeforeNewQueryClause; set: set_NewLineBeforeNewQueryClause; }
    // property ICSharpCode.Decompiler.CSharp.OutputVisitor.UsingPlacement UsingPlacement { get: get_UsingPlacement; set: set_UsingPlacement; }
}
