using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using ICSharpCode.Decompiler.IL.Patterns;
using ICSharpCode.Decompiler.TypeSystem;
using ICSharpCode.Decompiler.Util;

namespace ICSharpCode.Decompiler.IL;

public abstract class ILInstruction
{
	public struct ChildrenCollection : IReadOnlyList<ILInstruction>, IReadOnlyCollection<ILInstruction>, IEnumerable<ILInstruction>, IEnumerable
	{
		private readonly ILInstruction inst;

		public int Count => inst.GetChildCount();

		public ILInstruction this[int index] => inst.GetChild(index);

		internal ChildrenCollection(ILInstruction inst)
		{
			this.inst = inst;
		}

		public ChildrenEnumerator GetEnumerator()
		{
			return new ChildrenEnumerator(inst);
		}

		IEnumerator<ILInstruction> IEnumerable<ILInstruction>.GetEnumerator()
		{
			return GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}

	public struct ChildrenEnumerator : IEnumerator<ILInstruction>, IDisposable, IEnumerator
	{
		private ILInstruction inst;

		private readonly int end;

		private int pos;

		public ILInstruction Current => inst.GetChild(pos);

		object IEnumerator.Current => Current;

		internal ChildrenEnumerator(ILInstruction inst)
		{
			this.inst = inst;
			pos = -1;
			end = inst.GetChildCount();
		}

		public bool MoveNext()
		{
			return ++pos < end;
		}

		public void Dispose()
		{
		}

		void IEnumerator.Reset()
		{
			pos = -1;
		}
	}

	public readonly OpCode OpCode;

	private const InstructionFlags invalidFlags = (InstructionFlags)(-1);

	private InstructionFlags flags = (InstructionFlags)(-1);

	public Interval ILRange;

	private byte refCount;

	private ILInstruction parent;

	public abstract StackType ResultType { get; }

	public bool IsDirty { get; private set; }

	public InstructionFlags Flags
	{
		get
		{
			if (flags == (InstructionFlags)(-1))
			{
				flags = ComputeFlags();
			}
			return flags;
		}
	}

	public abstract InstructionFlags DirectFlags { get; }

	public ChildrenCollection Children => new ChildrenCollection(this);

	public IEnumerable<ILInstruction> Descendants
	{
		get
		{
			Stack<ChildrenEnumerator> stack = new Stack<ChildrenEnumerator>();
			ChildrenEnumerator enumerator = new ChildrenEnumerator(this);
			try
			{
				while (true)
				{
					if (enumerator.MoveNext())
					{
						ILInstruction current = enumerator.Current;
						stack.Push(enumerator);
						enumerator = new ChildrenEnumerator(current);
						continue;
					}
					enumerator.Dispose();
					if (stack.Count <= 0)
					{
						break;
					}
					enumerator = stack.Pop();
					yield return enumerator.Current;
				}
			}
			finally
			{
				enumerator.Dispose();
				while (stack.Count > 0)
				{
					stack.Pop().Dispose();
				}
			}
			yield return this;
		}
	}

	public IEnumerable<ILInstruction> Ancestors
	{
		get
		{
			for (ILInstruction node = this; node != null; node = node.Parent)
			{
				yield return node;
			}
		}
	}

	protected internal bool IsConnected => refCount > 0;

	public ILInstruction Parent => parent;

	public int ChildIndex { get; internal set; } = -1;

	public SlotInfo SlotInfo => parent.GetChildSlot(ChildIndex);

	public bool MatchInvalidBranch()
	{
		if (this is InvalidBranch)
		{
			return true;
		}
		return false;
	}

	public bool MatchInvalidExpression()
	{
		if (this is InvalidExpression)
		{
			return true;
		}
		return false;
	}

	public bool MatchNop()
	{
		if (this is Nop)
		{
			return true;
		}
		return false;
	}

	public bool MatchPinnedRegion(out ILVariable variable, out ILInstruction init, out ILInstruction body)
	{
		if (this is PinnedRegion pinnedRegion)
		{
			variable = pinnedRegion.Variable;
			init = pinnedRegion.Init;
			body = pinnedRegion.Body;
			return true;
		}
		variable = null;
		init = null;
		body = null;
		return false;
	}

	public bool MatchLogicNot(out ILInstruction argument)
	{
		if (this is LogicNot logicNot)
		{
			argument = logicNot.Argument;
			return true;
		}
		argument = null;
		return false;
	}

	public bool MatchBitNot(out ILInstruction argument)
	{
		if (this is BitNot bitNot)
		{
			argument = bitNot.Argument;
			return true;
		}
		argument = null;
		return false;
	}

	public bool MatchArglist()
	{
		if (this is Arglist)
		{
			return true;
		}
		return false;
	}

	public bool MatchTryCatchHandler(out ILInstruction filter, out ILInstruction body, out ILVariable variable)
	{
		if (this is TryCatchHandler tryCatchHandler)
		{
			filter = tryCatchHandler.Filter;
			body = tryCatchHandler.Body;
			variable = tryCatchHandler.Variable;
			return true;
		}
		filter = null;
		body = null;
		variable = null;
		return false;
	}

	public bool MatchDebugBreak()
	{
		if (this is DebugBreak)
		{
			return true;
		}
		return false;
	}

	public bool MatchCkfinite(out ILInstruction argument)
	{
		if (this is Ckfinite ckfinite)
		{
			argument = ckfinite.Argument;
			return true;
		}
		argument = null;
		return false;
	}

	public bool MatchLdLoc(out ILVariable variable)
	{
		if (this is LdLoc ldLoc)
		{
			variable = ldLoc.Variable;
			return true;
		}
		variable = null;
		return false;
	}

	public bool MatchLdLoca(out ILVariable variable)
	{
		if (this is LdLoca ldLoca)
		{
			variable = ldLoca.Variable;
			return true;
		}
		variable = null;
		return false;
	}

	public bool MatchStLoc(out ILVariable variable, out ILInstruction value)
	{
		if (this is StLoc stLoc)
		{
			variable = stLoc.Variable;
			value = stLoc.Value;
			return true;
		}
		variable = null;
		value = null;
		return false;
	}

	public bool MatchAddressOf(out ILInstruction value)
	{
		if (this is AddressOf addressOf)
		{
			value = addressOf.Value;
			return true;
		}
		value = null;
		return false;
	}

	public bool MatchLdStr(out string value)
	{
		if (this is LdStr ldStr)
		{
			value = ldStr.Value;
			return true;
		}
		value = null;
		return false;
	}

	public bool MatchLdcI4(out int value)
	{
		if (this is LdcI4 ldcI)
		{
			value = ldcI.Value;
			return true;
		}
		value = 0;
		return false;
	}

	public bool MatchLdcI8(out long value)
	{
		if (this is LdcI8 ldcI)
		{
			value = ldcI.Value;
			return true;
		}
		value = 0L;
		return false;
	}

	public bool MatchLdcF(out double value)
	{
		if (this is LdcF ldcF)
		{
			value = ldcF.Value;
			return true;
		}
		value = 0.0;
		return false;
	}

	public bool MatchLdcDecimal(out decimal value)
	{
		if (this is LdcDecimal ldcDecimal)
		{
			value = ldcDecimal.Value;
			return true;
		}
		value = 0m;
		return false;
	}

	public bool MatchLdNull()
	{
		if (this is LdNull)
		{
			return true;
		}
		return false;
	}

	public bool MatchLdFtn(out IMethod method)
	{
		if (this is LdFtn ldFtn)
		{
			method = ldFtn.Method;
			return true;
		}
		method = null;
		return false;
	}

	public bool MatchLdVirtFtn(out ILInstruction argument, out IMethod method)
	{
		if (this is LdVirtFtn ldVirtFtn)
		{
			argument = ldVirtFtn.Argument;
			method = ldVirtFtn.Method;
			return true;
		}
		argument = null;
		method = null;
		return false;
	}

	public bool MatchLdTypeToken(out IType type)
	{
		if (this is LdTypeToken ldTypeToken)
		{
			type = ldTypeToken.Type;
			return true;
		}
		type = null;
		return false;
	}

	public bool MatchLdMemberToken(out IMember member)
	{
		if (this is LdMemberToken ldMemberToken)
		{
			member = ldMemberToken.Member;
			return true;
		}
		member = null;
		return false;
	}

	public bool MatchLocAlloc(out ILInstruction argument)
	{
		if (this is LocAlloc locAlloc)
		{
			argument = locAlloc.Argument;
			return true;
		}
		argument = null;
		return false;
	}

	public bool MatchReturn(out ILInstruction value)
	{
		if (this is Return obj)
		{
			value = obj.Value;
			return true;
		}
		value = null;
		return false;
	}

	public bool MatchLdFlda(out ILInstruction target, out IField field)
	{
		if (this is LdFlda ldFlda)
		{
			target = ldFlda.Target;
			field = ldFlda.Field;
			return true;
		}
		target = null;
		field = null;
		return false;
	}

	public bool MatchLdsFlda(out IField field)
	{
		if (this is LdsFlda ldsFlda)
		{
			field = ldsFlda.Field;
			return true;
		}
		field = null;
		return false;
	}

	public bool MatchCastClass(out ILInstruction argument, out IType type)
	{
		if (this is CastClass castClass)
		{
			argument = castClass.Argument;
			type = castClass.Type;
			return true;
		}
		argument = null;
		type = null;
		return false;
	}

	public bool MatchIsInst(out ILInstruction argument, out IType type)
	{
		if (this is IsInst isInst)
		{
			argument = isInst.Argument;
			type = isInst.Type;
			return true;
		}
		argument = null;
		type = null;
		return false;
	}

	public bool MatchLdObj(out ILInstruction target, out IType type)
	{
		if (this is LdObj ldObj)
		{
			target = ldObj.Target;
			type = ldObj.Type;
			return true;
		}
		target = null;
		type = null;
		return false;
	}

	public bool MatchStObj(out ILInstruction target, out ILInstruction value, out IType type)
	{
		if (this is StObj stObj)
		{
			target = stObj.Target;
			value = stObj.Value;
			type = stObj.Type;
			return true;
		}
		target = null;
		value = null;
		type = null;
		return false;
	}

	public bool MatchBox(out ILInstruction argument, out IType type)
	{
		if (this is Box box)
		{
			argument = box.Argument;
			type = box.Type;
			return true;
		}
		argument = null;
		type = null;
		return false;
	}

	public bool MatchUnbox(out ILInstruction argument, out IType type)
	{
		if (this is Unbox unbox)
		{
			argument = unbox.Argument;
			type = unbox.Type;
			return true;
		}
		argument = null;
		type = null;
		return false;
	}

	public bool MatchUnboxAny(out ILInstruction argument, out IType type)
	{
		if (this is UnboxAny unboxAny)
		{
			argument = unboxAny.Argument;
			type = unboxAny.Type;
			return true;
		}
		argument = null;
		type = null;
		return false;
	}

	public bool MatchNewArr(out IType type)
	{
		if (this is NewArr newArr)
		{
			type = newArr.Type;
			return true;
		}
		type = null;
		return false;
	}

	public bool MatchDefaultValue(out IType type)
	{
		if (this is DefaultValue defaultValue)
		{
			type = defaultValue.Type;
			return true;
		}
		type = null;
		return false;
	}

	public bool MatchThrow(out ILInstruction argument)
	{
		if (this is Throw obj)
		{
			argument = obj.Argument;
			return true;
		}
		argument = null;
		return false;
	}

	public bool MatchRethrow()
	{
		if (this is Rethrow)
		{
			return true;
		}
		return false;
	}

	public bool MatchSizeOf(out IType type)
	{
		if (this is SizeOf sizeOf)
		{
			type = sizeOf.Type;
			return true;
		}
		type = null;
		return false;
	}

	public bool MatchLdElema(out IType type, out ILInstruction array)
	{
		if (this is LdElema ldElema)
		{
			type = ldElema.Type;
			array = ldElema.Array;
			return true;
		}
		type = null;
		array = null;
		return false;
	}

	public bool MatchArrayToPointer(out ILInstruction array)
	{
		if (this is ArrayToPointer arrayToPointer)
		{
			array = arrayToPointer.Array;
			return true;
		}
		array = null;
		return false;
	}

	public bool MatchMakeRefAny(out ILInstruction argument, out IType type)
	{
		if (this is MakeRefAny makeRefAny)
		{
			argument = makeRefAny.Argument;
			type = makeRefAny.Type;
			return true;
		}
		argument = null;
		type = null;
		return false;
	}

	public bool MatchRefAnyType(out ILInstruction argument)
	{
		if (this is RefAnyType refAnyType)
		{
			argument = refAnyType.Argument;
			return true;
		}
		argument = null;
		return false;
	}

	public bool MatchRefAnyValue(out ILInstruction argument, out IType type)
	{
		if (this is RefAnyValue refAnyValue)
		{
			argument = refAnyValue.Argument;
			type = refAnyValue.Type;
			return true;
		}
		argument = null;
		type = null;
		return false;
	}

	public bool MatchYieldReturn(out ILInstruction value)
	{
		if (this is YieldReturn yieldReturn)
		{
			value = yieldReturn.Value;
			return true;
		}
		value = null;
		return false;
	}

	public bool MatchAwait(out ILInstruction value)
	{
		if (this is Await obj)
		{
			value = obj.Value;
			return true;
		}
		value = null;
		return false;
	}

	protected ILInstruction(OpCode opCode)
	{
		OpCode = opCode;
	}

	protected void ValidateChild(ILInstruction inst)
	{
		if (inst == null)
		{
			throw new ArgumentNullException("inst");
		}
	}

	[Conditional("DEBUG")]
	internal virtual void CheckInvariant(ILPhase phase)
	{
		foreach (ILInstruction child in Children)
		{
		}
	}

	public bool IsDescendantOf(ILInstruction possibleAncestor)
	{
		for (ILInstruction iLInstruction = this; iLInstruction != null; iLInstruction = iLInstruction.Parent)
		{
			if (iLInstruction == possibleAncestor)
			{
				return true;
			}
		}
		return false;
	}

	internal static StackType CommonResultType(StackType a, StackType b)
	{
		if (a == StackType.I || b == StackType.I)
		{
			return StackType.I;
		}
		return a;
	}

	protected void MakeDirty()
	{
		ILInstruction iLInstruction = this;
		while (iLInstruction != null && !iLInstruction.IsDirty)
		{
			iLInstruction.IsDirty = true;
			iLInstruction = iLInstruction.parent;
		}
	}

	public void ResetDirty()
	{
		foreach (ILInstruction descendant in Descendants)
		{
			descendant.IsDirty = false;
		}
	}

	public bool HasFlag(InstructionFlags flags)
	{
		return (Flags & flags) != 0;
	}

	public bool HasDirectFlag(InstructionFlags flags)
	{
		return (DirectFlags & flags) != 0;
	}

	protected void InvalidateFlags()
	{
		ILInstruction iLInstruction = this;
		while (iLInstruction != null && iLInstruction.flags != (InstructionFlags)(-1))
		{
			iLInstruction.flags = (InstructionFlags)(-1);
			iLInstruction = iLInstruction.parent;
		}
	}

	protected abstract InstructionFlags ComputeFlags();

	public void AddILRange(Interval ilRange)
	{
		ILRange = ilRange;
	}

	public abstract void WriteTo(ITextOutput output);

	public override string ToString()
	{
		PlainTextOutput plainTextOutput = new PlainTextOutput();
		WriteTo(plainTextOutput);
		if (!ILRange.IsEmpty)
		{
			int start = ILRange.Start;
			plainTextOutput.Write(" at IL_" + start.ToString("x4"));
		}
		return plainTextOutput.ToString();
	}

	public abstract void AcceptVisitor(ILVisitor visitor);

	public abstract T AcceptVisitor<T>(ILVisitor<T> visitor);

	public abstract T AcceptVisitor<C, T>(ILVisitor<C, T> visitor, C context);

	protected abstract int GetChildCount();

	protected abstract ILInstruction GetChild(int index);

	protected abstract void SetChild(int index, ILInstruction value);

	protected abstract SlotInfo GetChildSlot(int index);

	[Conditional("DEBUG")]
	internal void AssertNoEnumerators()
	{
	}

	public void ReplaceWith(ILInstruction replacement)
	{
		if (replacement != this)
		{
			parent.SetChild(ChildIndex, replacement);
		}
	}

	internal void AddRef()
	{
		if (refCount++ == 0)
		{
			Connected();
		}
	}

	internal void ReleaseRef()
	{
		if (--refCount == 0)
		{
			Disconnected();
		}
	}

	protected virtual void Connected()
	{
		foreach (ILInstruction child in Children)
		{
			child.AddRef();
		}
	}

	protected virtual void Disconnected()
	{
		foreach (ILInstruction child in Children)
		{
			child.ReleaseRef();
		}
	}

	protected internal void SetChildInstruction(ref ILInstruction childPointer, ILInstruction newValue, int index)
	{
		ILInstruction iLInstruction = childPointer;
		if (iLInstruction != newValue)
		{
			childPointer = newValue;
			if (newValue != null)
			{
				newValue.parent = this;
				newValue.ChildIndex = index;
			}
			InvalidateFlags();
			MakeDirty();
			if (refCount > 0)
			{
				newValue?.AddRef();
				iLInstruction?.ReleaseRef();
			}
		}
	}

	protected internal void InstructionCollectionAdded(ILInstruction newChild)
	{
		newChild.parent = this;
		if (refCount > 0)
		{
			newChild.AddRef();
		}
	}

	protected internal void InstructionCollectionRemoved(ILInstruction oldChild)
	{
		if (refCount > 0)
		{
			oldChild.ReleaseRef();
		}
	}

	protected internal virtual void InstructionCollectionUpdateComplete()
	{
		InvalidateFlags();
		MakeDirty();
	}

	public abstract ILInstruction Clone();

	protected ILInstruction ShallowClone()
	{
		ILInstruction iLInstruction = (ILInstruction)MemberwiseClone();
		iLInstruction.refCount = 0;
		iLInstruction.parent = null;
		iLInstruction.flags = (InstructionFlags)(-1);
		return iLInstruction;
	}

	public Match Match(ILInstruction node)
	{
		Match match = default;
		match.Success = PerformMatch(node, ref match);
		return match;
	}

	protected internal abstract bool PerformMatch(ILInstruction other, ref Match match);

	protected internal virtual bool PerformMatch(ref ListMatch listMatch, ref Match match)
	{
		if (listMatch.SyntaxIndex < listMatch.SyntaxList.Count && PerformMatch(listMatch.SyntaxList[listMatch.SyntaxIndex], ref match))
		{
			listMatch.SyntaxIndex++;
			return true;
		}
		return false;
	}

	public bool MatchLdcI4(int val)
	{
		if (OpCode == OpCode.LdcI4)
		{
			return ((LdcI4)this).Value == val;
		}
		return false;
	}

	public bool MatchLdcI(out long val)
	{
		if (MatchLdcI8(out val))
		{
			return true;
		}
		if (MatchLdcI4(out var value))
		{
			val = value;
			return true;
		}
		return false;
	}

	public bool MatchLdLoc(ILVariable variable)
	{
		if (this is LdLoc ldLoc)
		{
			return ldLoc.Variable == variable;
		}
		return false;
	}

	public bool MatchLdLoca(ILVariable variable)
	{
		if (this is LdLoca ldLoca)
		{
			return ldLoca.Variable == variable;
		}
		return false;
	}

	public bool MatchLdLocRef(ILVariable variable)
	{
		if (variable.Type.IsReferenceType == true)
		{
			return MatchLdLoc(variable);
		}
		return MatchLdLoca(variable);
	}

	public bool MatchLdLocRef(out ILVariable variable)
	{
		if (this != null)
		{
			if (this is LdLoc ldLoc)
			{
				LdLoc ldLoc2 = ldLoc;
				variable = ldLoc2.Variable;
				return variable.Type.IsReferenceType == true;
			}
			if (this is LdLoca ldLoca)
			{
				LdLoca ldLoca2 = ldLoca;
				variable = ldLoca2.Variable;
				return variable.Type.IsReferenceType != true;
			}
		}
		variable = null;
		return false;
	}

	public bool MatchLdThis()
	{
		if (this is LdLoc ldLoc && ldLoc.Variable.Kind == VariableKind.Parameter)
		{
			return ldLoc.Variable.Index < 0;
		}
		return false;
	}

	public bool MatchStLoc(out ILVariable variable)
	{
		if (this is StLoc stLoc)
		{
			variable = stLoc.Variable;
			return true;
		}
		variable = null;
		return false;
	}

	public bool MatchStLoc(ILVariable variable, out ILInstruction value)
	{
		if (this is StLoc stLoc && stLoc.Variable == variable)
		{
			value = stLoc.Value;
			return true;
		}
		value = null;
		return false;
	}

	public bool MatchLdLen(StackType type, out ILInstruction array)
	{
		if (this is LdLen ldLen && ldLen.ResultType == type)
		{
			array = ldLen.Array;
			return true;
		}
		array = null;
		return false;
	}

	public bool MatchBranch(out Block targetBlock)
	{
		if (this is Branch branch)
		{
			targetBlock = branch.TargetBlock;
			return true;
		}
		targetBlock = null;
		return false;
	}

	public bool MatchBranch(Block targetBlock)
	{
		if (this is Branch branch)
		{
			return branch.TargetBlock == targetBlock;
		}
		return false;
	}

	public bool MatchLeave(out BlockContainer targetContainer)
	{
		if (this is Leave leave)
		{
			targetContainer = leave.TargetContainer;
			return true;
		}
		targetContainer = null;
		return false;
	}

	public bool MatchLeave(BlockContainer targetContainer)
	{
		if (this is Leave leave)
		{
			return leave.TargetContainer == targetContainer;
		}
		return false;
	}

	public bool MatchIfInstruction(out ILInstruction condition, out ILInstruction trueInst, out ILInstruction falseInst)
	{
		if (this is IfInstruction ifInstruction)
		{
			condition = ifInstruction.Condition;
			trueInst = ifInstruction.TrueInst;
			falseInst = ifInstruction.FalseInst;
			return true;
		}
		condition = null;
		trueInst = null;
		falseInst = null;
		return false;
	}

	public bool MatchIfInstruction(out ILInstruction condition, out ILInstruction trueInst)
	{
		if (this is IfInstruction ifInstruction && ifInstruction.FalseInst.MatchNop())
		{
			condition = ifInstruction.Condition;
			trueInst = ifInstruction.TrueInst;
			return true;
		}
		condition = null;
		trueInst = null;
		return false;
	}

	public bool MatchLogicAnd(out ILInstruction lhs, out ILInstruction rhs)
	{
		if (this is IfInstruction ifInstruction && ifInstruction.FalseInst.MatchLdcI4(0))
		{
			lhs = ifInstruction.Condition;
			rhs = ifInstruction.TrueInst;
			return true;
		}
		lhs = null;
		rhs = null;
		return false;
	}

	public bool MatchLogicOr(out ILInstruction lhs, out ILInstruction rhs)
	{
		if (this is IfInstruction ifInstruction && ifInstruction.TrueInst.MatchLdcI4(1))
		{
			lhs = ifInstruction.Condition;
			rhs = ifInstruction.FalseInst;
			return true;
		}
		lhs = null;
		rhs = null;
		return false;
	}

	public bool MatchTryCatchHandler(out ILVariable variable)
	{
		if (this is TryCatchHandler tryCatchHandler)
		{
			variable = tryCatchHandler.Variable;
			return true;
		}
		variable = null;
		return false;
	}

	public bool MatchCompEquals(out ILInstruction left, out ILInstruction right)
	{
		ComparisonKind comparisonKind;
		Comp comp;
		if (this is LogicNot logicNot)
		{
			comparisonKind = ComparisonKind.Inequality;
			comp = logicNot.Argument as Comp;
		}
		else
		{
			comparisonKind = ComparisonKind.Equality;
			comp = this as Comp;
		}
		if (comp != null && comp.Kind == comparisonKind)
		{
			left = comp.Left;
			right = comp.Right;
			return true;
		}
		left = null;
		right = null;
		return false;
	}

	public bool MatchLdsFld(IField field)
	{
		if (this is LdObj { Target: LdsFlda target })
		{
			return field.Equals(target.Field);
		}
		return false;
	}

	public bool MatchLdFld(out ILInstruction target, out IField field)
	{
		if (this is LdObj { Target: LdFlda target2 })
		{
			target = target2.Target;
			field = target2.Field;
			return true;
		}
		target = null;
		field = null;
		return false;
	}

	public bool MatchLdsFld(out IField field)
	{
		if (this is LdObj { Target: LdsFlda target })
		{
			field = target.Field;
			return true;
		}
		field = null;
		return false;
	}

	public bool MatchStsFld(out IField field, out ILInstruction value)
	{
		if (this is StObj { Target: LdsFlda target } stObj)
		{
			field = target.Field;
			value = stObj.Value;
			return true;
		}
		field = null;
		value = null;
		return false;
	}

	public bool MatchStFld(out ILInstruction target, out IField field, out ILInstruction value)
	{
		if (this is StObj { Target: LdFlda target2 } stObj)
		{
			target = target2.Target;
			field = target2.Field;
			value = stObj.Value;
			return true;
		}
		target = null;
		field = null;
		value = null;
		return false;
	}

	public bool MatchBinaryNumericInstruction(BinaryNumericOperator @operator)
	{
		if (this is BinaryNumericInstruction binaryNumericInstruction)
		{
			return binaryNumericInstruction.Operator == @operator;
		}
		return false;
	}

	public bool MatchBinaryNumericInstruction(BinaryNumericOperator @operator, out ILInstruction left, out ILInstruction right)
	{
		if (this is BinaryNumericInstruction binaryNumericInstruction && binaryNumericInstruction.Operator == @operator)
		{
			left = binaryNumericInstruction.Left;
			right = binaryNumericInstruction.Right;
			return true;
		}
		left = null;
		right = null;
		return false;
	}

	public bool MatchBinaryNumericInstruction(out BinaryNumericOperator @operator, out ILInstruction left, out ILInstruction right)
	{
		if (this is BinaryNumericInstruction binaryNumericInstruction)
		{
			@operator = binaryNumericInstruction.Operator;
			left = binaryNumericInstruction.Left;
			right = binaryNumericInstruction.Right;
			return true;
		}
		@operator = BinaryNumericOperator.None;
		left = null;
		right = null;
		return false;
	}

	public virtual ILInstruction UnwrapConv(ConversionKind kind)
	{
		return this;
	}
}
