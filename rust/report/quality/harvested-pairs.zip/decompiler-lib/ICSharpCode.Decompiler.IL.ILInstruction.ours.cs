namespace ICSharpCode.Decompiler.IL;

public abstract class ILInstruction
{
    public readonly ICSharpCode.Decompiler.IL.OpCode OpCode;
    private bool __il_field_04000412;
    private const ICSharpCode.Decompiler.IL.InstructionFlags invalidFlags = -1;
    private ICSharpCode.Decompiler.IL.InstructionFlags flags;
    public ICSharpCode.Decompiler.Util.Interval ILRange;
    private byte refCount;
    private ICSharpCode.Decompiler.IL.ILInstruction parent;
    private int __il_field_04000418;

    public bool MatchInvalidBranch()
    {
        global::ICSharpCode.Decompiler.IL.InvalidBranch v1 = ((object)this as ICSharpCode.Decompiler.IL.InvalidBranch);
        global::ICSharpCode.Decompiler.IL.InvalidBranch v2 = v1;
        if (v2 is null) {
            return false;
        } else {
            return true;
        }
    }

    public bool MatchInvalidExpression()
    {
        global::ICSharpCode.Decompiler.IL.InvalidExpression v1 = ((object)this as ICSharpCode.Decompiler.IL.InvalidExpression);
        global::ICSharpCode.Decompiler.IL.InvalidExpression v2 = v1;
        if (v2 is null) {
            return false;
        } else {
            return true;
        }
    }

    public bool MatchNop()
    {
        global::ICSharpCode.Decompiler.IL.Nop v1 = ((object)this as ICSharpCode.Decompiler.IL.Nop);
        global::ICSharpCode.Decompiler.IL.Nop v2 = v1;
        if (v2 is null) {
            return false;
        } else {
            return true;
        }
    }

    public bool MatchPinnedRegion(out ICSharpCode.Decompiler.IL.ILVariable variable, out ICSharpCode.Decompiler.IL.ILInstruction init, out ICSharpCode.Decompiler.IL.ILInstruction body)
    {
        ICSharpCode.Decompiler.IL.PinnedRegion l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.PinnedRegion v1 = ((object)v0 as ICSharpCode.Decompiler.IL.PinnedRegion);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.PinnedRegion v2 = l0;
        if (v2 is null) {
            goto IL_0024;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v3 = ref variable;
        global::ICSharpCode.Decompiler.IL.PinnedRegion v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v5 = __cil_callvirt_06000A7F(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref init;
        global::ICSharpCode.Decompiler.IL.PinnedRegion v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000A88(v7);
        v6 = v8;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v9 = ref body;
        global::ICSharpCode.Decompiler.IL.PinnedRegion v10 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v11 = __cil_callvirt_06000A8A(v10);
        v9 = v11;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0024: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v13 = ref variable;
        v13 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref init;
        v14 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v15 = ref body;
        v15 = null;
        int v16 = 0;
        return __cil_bool_store(v16);
    }

    public bool MatchLogicNot(out ICSharpCode.Decompiler.IL.ILInstruction argument)
    {
        ICSharpCode.Decompiler.IL.LogicNot l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LogicNot v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LogicNot);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LogicNot v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.LogicNot v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref argument;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchBitNot(out ICSharpCode.Decompiler.IL.ILInstruction argument)
    {
        ICSharpCode.Decompiler.IL.BitNot l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.BitNot v1 = ((object)v0 as ICSharpCode.Decompiler.IL.BitNot);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.BitNot v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.BitNot v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref argument;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchArglist()
    {
        global::ICSharpCode.Decompiler.IL.Arglist v1 = ((object)this as ICSharpCode.Decompiler.IL.Arglist);
        global::ICSharpCode.Decompiler.IL.Arglist v2 = v1;
        if (v2 is null) {
            return false;
        } else {
            return true;
        }
    }

    public bool MatchTryCatchHandler(out ICSharpCode.Decompiler.IL.ILInstruction filter, out ICSharpCode.Decompiler.IL.ILInstruction body, out ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        ICSharpCode.Decompiler.IL.TryCatchHandler l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v1 = ((object)v0 as ICSharpCode.Decompiler.IL.TryCatchHandler);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v2 = l0;
        if (v2 is null) {
            goto IL_0024;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref filter;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000B3D(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref body;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000B3F(v7);
        v6 = v8;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v9 = ref variable;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v10 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v11 = __cil_callvirt_06000B46(v10);
        v9 = v11;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0024: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v13 = ref filter;
        v13 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref body;
        v14 = null;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v15 = ref variable;
        v15 = null;
        int v16 = 0;
        return __cil_bool_store(v16);
    }

    public bool MatchDebugBreak()
    {
        global::ICSharpCode.Decompiler.IL.DebugBreak v1 = ((object)this as ICSharpCode.Decompiler.IL.DebugBreak);
        global::ICSharpCode.Decompiler.IL.DebugBreak v2 = v1;
        if (v2 is null) {
            return false;
        } else {
            return true;
        }
    }

    public bool MatchCkfinite(out ICSharpCode.Decompiler.IL.ILInstruction argument)
    {
        ICSharpCode.Decompiler.IL.Ckfinite l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Ckfinite v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Ckfinite);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Ckfinite v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.Ckfinite v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref argument;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdLoc(out ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        ICSharpCode.Decompiler.IL.LdLoc l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdLoc v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdLoc);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdLoc v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v3 = ref variable;
        global::ICSharpCode.Decompiler.IL.LdLoc v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v5 = __cil_callvirt_06000BA7(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v7 = ref variable;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdLoca(out ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        ICSharpCode.Decompiler.IL.LdLoca l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdLoca v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdLoca);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdLoca v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v3 = ref variable;
        global::ICSharpCode.Decompiler.IL.LdLoca v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v5 = __cil_callvirt_06000BBA(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v7 = ref variable;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchStLoc(out ICSharpCode.Decompiler.IL.ILVariable variable, out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.StLoc l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.StLoc v1 = ((object)v0 as ICSharpCode.Decompiler.IL.StLoc);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.StLoc v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v3 = ref variable;
        global::ICSharpCode.Decompiler.IL.StLoc v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v5 = __cil_callvirt_06000BC9(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref value;
        global::ICSharpCode.Decompiler.IL.StLoc v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000BD2(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v10 = ref variable;
        v10 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v11 = ref value;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchAddressOf(out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.AddressOf l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.AddressOf v1 = ((object)v0 as ICSharpCode.Decompiler.IL.AddressOf);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.AddressOf v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref value;
        global::ICSharpCode.Decompiler.IL.AddressOf v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000BE3(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref value;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdStr(out string value)
    {
        ICSharpCode.Decompiler.IL.LdStr l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdStr v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdStr);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdStr v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref string v3 = ref value;
        global::ICSharpCode.Decompiler.IL.LdStr v4 = l0;
        string v5 = v4.Value;
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref string v7 = ref value;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdcI4(out int value)
    {
        ICSharpCode.Decompiler.IL.LdcI4 l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdcI4 v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdcI4);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdcI4 v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref int v3 = ref value;
        global::ICSharpCode.Decompiler.IL.LdcI4 v4 = l0;
        int v5 = v4.Value;
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref int v7 = ref value;
        int v8 = 0;
        v7 = v8;
        int v9 = 0;
        return __cil_bool_store(v9);
    }

    public bool MatchLdcI8(out long value)
    {
        ICSharpCode.Decompiler.IL.LdcI8 l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdcI8 v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdcI8);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdcI8 v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref long v3 = ref value;
        global::ICSharpCode.Decompiler.IL.LdcI8 v4 = l0;
        long v5 = v4.Value;
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref long v7 = ref value;
        int v8 = 0;
        long v9 = unchecked((long)(v8));
        v7 = v9;
        int v10 = 0;
        return __cil_bool_store(v10);
    }

    public bool MatchLdcF(out double value)
    {
        ICSharpCode.Decompiler.IL.LdcF l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdcF v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdcF);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdcF v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref double v3 = ref value;
        global::ICSharpCode.Decompiler.IL.LdcF v4 = l0;
        double v5 = v4.Value;
        v3 = unchecked((double)(v5));
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref double v7 = ref value;
        double v8 = __cil_ldc_r8_bits(0x0000000000000000uL);
        v7 = unchecked((double)(v8));
        int v9 = 0;
        return __cil_bool_store(v9);
    }

    public bool MatchLdcDecimal(out System.Decimal value)
    {
        // structural signature __cil_value_5172196946695217e06514bac03ef6c13553640e bytes=1181B1: valuetype [mscorlib]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        ICSharpCode.Decompiler.IL.LdcDecimal l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdcDecimal v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdcDecimal);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdcDecimal v2 = l0;
        if (v2 is null) {
            goto IL_0018;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref __cil_value_5172196946695217e06514bac03ef6c13553640e v3 = ref value;
        global::ICSharpCode.Decompiler.IL.LdcDecimal v4 = l0;
        __cil_value_5172196946695217e06514bac03ef6c13553640e v5 = v4.Value;
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0018: ;
        ref __cil_value_5172196946695217e06514bac03ef6c13553640e v7 = ref value;
        v7 = default;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdNull()
    {
        global::ICSharpCode.Decompiler.IL.LdNull v1 = ((object)this as ICSharpCode.Decompiler.IL.LdNull);
        global::ICSharpCode.Decompiler.IL.LdNull v2 = v1;
        if (v2 is null) {
            return false;
        } else {
            return true;
        }
    }

    public bool MatchLdFtn(out ICSharpCode.Decompiler.TypeSystem.IMethod method)
    {
        ICSharpCode.Decompiler.IL.LdFtn l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdFtn v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdFtn);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdFtn v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IMethod v3 = ref method;
        global::ICSharpCode.Decompiler.IL.LdFtn v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IMethod v5 = __cil_callvirt_06000C1D(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IMethod v7 = ref method;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdVirtFtn(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IMethod method)
    {
        ICSharpCode.Decompiler.IL.LdVirtFtn l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdVirtFtn v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdVirtFtn);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdVirtFtn v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.LdVirtFtn v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IMethod v6 = ref method;
        global::ICSharpCode.Decompiler.IL.LdVirtFtn v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IMethod v8 = __cil_callvirt_06000C25(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IMethod v11 = ref method;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchLdTypeToken(out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.LdTypeToken l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdTypeToken v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdTypeToken);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdTypeToken v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v3 = ref type;
        global::ICSharpCode.Decompiler.IL.LdTypeToken v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v5 = __cil_callvirt_06000C2F(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v7 = ref type;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdMemberToken(out ICSharpCode.Decompiler.TypeSystem.IMember member)
    {
        ICSharpCode.Decompiler.IL.LdMemberToken l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdMemberToken v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdMemberToken);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdMemberToken v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IMember v3 = ref member;
        global::ICSharpCode.Decompiler.IL.LdMemberToken v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IMember v5 = __cil_callvirt_06000C37(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IMember v7 = ref member;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLocAlloc(out ICSharpCode.Decompiler.IL.ILInstruction argument)
    {
        ICSharpCode.Decompiler.IL.LocAlloc l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LocAlloc v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LocAlloc);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LocAlloc v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.LocAlloc v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref argument;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchReturn(out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.Return l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Return v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Return);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Return v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref value;
        global::ICSharpCode.Decompiler.IL.Return v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000C47(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref value;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdFlda(out ICSharpCode.Decompiler.IL.ILInstruction target, out ICSharpCode.Decompiler.TypeSystem.IField field)
    {
        ICSharpCode.Decompiler.IL.LdFlda l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdFlda v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdFlda);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdFlda v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref target;
        global::ICSharpCode.Decompiler.IL.LdFlda v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000C58(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v6 = ref field;
        global::ICSharpCode.Decompiler.IL.LdFlda v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IField v8 = __cil_callvirt_06000C5F(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref target;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v11 = ref field;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchLdsFlda(out ICSharpCode.Decompiler.TypeSystem.IField field)
    {
        ICSharpCode.Decompiler.IL.LdsFlda l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdsFlda v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdsFlda);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdsFlda v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v3 = ref field;
        global::ICSharpCode.Decompiler.IL.LdsFlda v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IField v5 = __cil_callvirt_06000C6B(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v7 = ref field;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchCastClass(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.CastClass l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.CastClass v1 = ((object)v0 as ICSharpCode.Decompiler.IL.CastClass);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.CastClass v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.CastClass v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.CastClass v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000C72(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchIsInst(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.IsInst l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.IsInst v1 = ((object)v0 as ICSharpCode.Decompiler.IL.IsInst);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.IsInst v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.IsInst v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.IsInst v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000C7C(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchLdObj(out ICSharpCode.Decompiler.IL.ILInstruction target, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.LdObj l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdObj v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdObj);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdObj v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref target;
        global::ICSharpCode.Decompiler.IL.LdObj v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000C84(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.LdObj v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000C8B(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref target;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchStObj(out ICSharpCode.Decompiler.IL.ILInstruction target, out ICSharpCode.Decompiler.IL.ILInstruction value, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.StObj l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.StObj v1 = ((object)v0 as ICSharpCode.Decompiler.IL.StObj);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.StObj v2 = l0;
        if (v2 is null) {
            goto IL_0024;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref target;
        global::ICSharpCode.Decompiler.IL.StObj v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000C9A(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref value;
        global::ICSharpCode.Decompiler.IL.StObj v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000C9C(v7);
        v6 = v8;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v9 = ref type;
        global::ICSharpCode.Decompiler.IL.StObj v10 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v11 = __cil_callvirt_06000CA3(v10);
        v9 = v11;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0024: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v13 = ref target;
        v13 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref value;
        v14 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v15 = ref type;
        v15 = null;
        int v16 = 0;
        return __cil_bool_store(v16);
    }

    public bool MatchBox(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.Box l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Box v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Box);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Box v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.Box v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.Box v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000CB2(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchUnbox(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.Unbox l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Unbox v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Unbox);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Unbox v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.Unbox v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.Unbox v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000CBC(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchUnboxAny(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.UnboxAny l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.UnboxAny v1 = ((object)v0 as ICSharpCode.Decompiler.IL.UnboxAny);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.UnboxAny v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.UnboxAny v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.UnboxAny v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000CC6(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchNewArr(out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.NewArr l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.NewArr v1 = ((object)v0 as ICSharpCode.Decompiler.IL.NewArr);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.NewArr v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v3 = ref type;
        global::ICSharpCode.Decompiler.IL.NewArr v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v5 = __cil_callvirt_06000CD5(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v7 = ref type;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchDefaultValue(out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.DefaultValue l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.DefaultValue v1 = ((object)v0 as ICSharpCode.Decompiler.IL.DefaultValue);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.DefaultValue v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v3 = ref type;
        global::ICSharpCode.Decompiler.IL.DefaultValue v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v5 = __cil_callvirt_06000CE7(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v7 = ref type;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchThrow(out ICSharpCode.Decompiler.IL.ILInstruction argument)
    {
        ICSharpCode.Decompiler.IL.Throw l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Throw v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Throw);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Throw v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.Throw v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref argument;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchRethrow()
    {
        global::ICSharpCode.Decompiler.IL.Rethrow v1 = ((object)this as ICSharpCode.Decompiler.IL.Rethrow);
        global::ICSharpCode.Decompiler.IL.Rethrow v2 = v1;
        if (v2 is null) {
            return false;
        } else {
            return true;
        }
    }

    public bool MatchSizeOf(out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.SizeOf l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.SizeOf v1 = ((object)v0 as ICSharpCode.Decompiler.IL.SizeOf);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.SizeOf v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v3 = ref type;
        global::ICSharpCode.Decompiler.IL.SizeOf v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v5 = __cil_callvirt_06000CFF(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v7 = ref type;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLdElema(out ICSharpCode.Decompiler.TypeSystem.IType type, out ICSharpCode.Decompiler.IL.ILInstruction array)
    {
        ICSharpCode.Decompiler.IL.LdElema l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdElema v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdElema);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdElema v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v3 = ref type;
        global::ICSharpCode.Decompiler.IL.LdElema v4 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v5 = __cil_callvirt_06000D18(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref array;
        global::ICSharpCode.Decompiler.IL.LdElema v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000D19(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v10 = ref type;
        v10 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v11 = ref array;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchArrayToPointer(out ICSharpCode.Decompiler.IL.ILInstruction array)
    {
        ICSharpCode.Decompiler.IL.ArrayToPointer l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.ArrayToPointer v1 = ((object)v0 as ICSharpCode.Decompiler.IL.ArrayToPointer);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.ArrayToPointer v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref array;
        global::ICSharpCode.Decompiler.IL.ArrayToPointer v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000D2E(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref array;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchMakeRefAny(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.MakeRefAny l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.MakeRefAny v1 = ((object)v0 as ICSharpCode.Decompiler.IL.MakeRefAny);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.MakeRefAny v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.MakeRefAny v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.MakeRefAny v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000D3F(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchRefAnyType(out ICSharpCode.Decompiler.IL.ILInstruction argument)
    {
        ICSharpCode.Decompiler.IL.RefAnyType l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.RefAnyType v1 = ((object)v0 as ICSharpCode.Decompiler.IL.RefAnyType);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.RefAnyType v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.RefAnyType v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref argument;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchRefAnyValue(out ICSharpCode.Decompiler.IL.ILInstruction argument, out ICSharpCode.Decompiler.TypeSystem.IType type)
    {
        ICSharpCode.Decompiler.IL.RefAnyValue l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.RefAnyValue v1 = ((object)v0 as ICSharpCode.Decompiler.IL.RefAnyValue);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.RefAnyValue v2 = l0;
        if (v2 is null) {
            goto IL_001C;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref argument;
        global::ICSharpCode.Decompiler.IL.RefAnyValue v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_060009F1(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v6 = ref type;
        global::ICSharpCode.Decompiler.IL.RefAnyValue v7 = l0;
        global::ICSharpCode.Decompiler.TypeSystem.IType v8 = __cil_callvirt_06000D4D(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001C: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref argument;
        v10 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IType v11 = ref type;
        v11 = null;
        int v12 = 0;
        return __cil_bool_store(v12);
    }

    public bool MatchYieldReturn(out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.YieldReturn l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.YieldReturn v1 = ((object)v0 as ICSharpCode.Decompiler.IL.YieldReturn);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.YieldReturn v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref value;
        global::ICSharpCode.Decompiler.IL.YieldReturn v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000D57(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref value;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchAwait(out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.Await l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Await v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Await);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Await v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref value;
        global::ICSharpCode.Decompiler.IL.Await v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_0600099D(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref value;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    protected ILInstruction(ICSharpCode.Decompiler.IL.OpCode opCode)
    {
        // enum storage token=0x020000F9 alias=__cil_enum_020000F9 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@OpCode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000160 alias=__cil_enum_02000160 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@InstructionFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        this.flags = unchecked((__cil_enum_02000160)(-1));
        this.__il_field_04000418 = -1;
        __cil_core_object_ctor_0A000092(this);
        int v6 = unchecked((int)(opCode));
        this.OpCode = unchecked((__cil_enum_020000F9)(v6));
        return;
    }

    protected void ValidateChild(ICSharpCode.Decompiler.IL.ILInstruction inst)
    {
        if (inst is not null) {
            goto IL_000E;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        string v1 = __cil_ldstr_7000077F("inst");
        global::System.ArgumentNullException v2 = __cil_newobj_0A0000C7(v1);
        throw v2;
        IL_000E: ;
        return;
    }

    internal virtual void CheckInvariant(ICSharpCode.Decompiler.IL.ILPhase phase)
    {
        // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200014A alias=__cil_enum_0200014A underlying=int: global::@ICSharpCode.@Decompiler.@IL.@ILPhase; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 l0 = default;
        __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 l1 = default;
        ICSharpCode.Decompiler.IL.ILInstruction l2 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v1 = __cil_direct_06000E81(v0);
        l1 = v1;
        ref __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v2 = ref l1;
        __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v3 = __cil_direct_060024AC(ref v2);
        l0 = v3;
        try {
            IL_000F: ;
            goto IL_0019;
            IL_0011: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v4 = ref l0;
            global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_direct_060024B0(ref v4);
            l2 = v5;
            goto IL_0019;
            IL_0019: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v6 = ref l0;
            int v7 = __cil_bool_load(__cil_direct_060024B1(ref v6));
            if (v7 != 0) {
                goto IL_0011;
            } else {
                goto IL_0022;
            }
            IL_0022: ;
            goto IL_0032;
        }
        finally {
            IL_0024: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v8 = ref l0;
            __cil_constrained_02000347_0A000017(ref v8);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0032: ;
        return;
    }

    public bool IsDescendantOf(ICSharpCode.Decompiler.IL.ILInstruction possibleAncestor)
    {
        ICSharpCode.Decompiler.IL.ILInstruction l0 = default;
        l0 = this;
        goto IL_0011;
        IL_0004: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = l0;
        if (!(!System.Object.ReferenceEquals(v1, possibleAncestor))) {
            return true;
        }
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000E8F(v4);
        l0 = v5;
        IL_0011: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v6 = l0;
        if (v6 is not null) {
            goto IL_0004;
        } else {
            return false;
        }
    }

    public abstract ICSharpCode.Decompiler.IL.StackType get_ResultType();

    internal static ICSharpCode.Decompiler.IL.StackType CommonResultType(ICSharpCode.Decompiler.IL.StackType a, ICSharpCode.Decompiler.IL.StackType b)
    {
        // enum storage token=0x02000162 alias=__cil_enum_02000162 underlying=byte: global::@ICSharpCode.@Decompiler.@IL.@StackType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(unchecked((byte)(a))));
        if (v0 == 3) {
            goto IL_0008;
        } else {
            goto IL_0004;
        }
        IL_0004: ;
        int v2 = unchecked((int)(unchecked((byte)(b))));
        if (unchecked((uint)v2) != unchecked((uint)3)) {
            goto IL_000A;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return unchecked((__cil_enum_02000162)(unchecked((byte)(3))));
        IL_000A: ;
        int v5 = unchecked((int)(unchecked((byte)(a))));
        return unchecked((__cil_enum_02000162)(unchecked((byte)(v5))));
    }

    public bool get_IsDirty()
    {
        return this.__il_field_04000412;
    }

    private void set_IsDirty(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000412 = __cil_bool_store(v1);
        return;
    }

    protected void MakeDirty()
    {
        ICSharpCode.Decompiler.IL.ILInstruction l0 = default;
        l0 = this;
        goto IL_0012;
        IL_0004: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = l0;
        __cil_callvirt_06000E72(v1, __cil_bool_store(1));
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = v3.parent;
        l0 = v4;
        IL_0012: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = l0;
        if (v5 is null) {
            goto IL_001D;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v6 = l0;
        int v7 = __cil_bool_load(__cil_callvirt_06000E71(v6));
        if (v7 == 0) {
            goto IL_0004;
        } else {
            goto IL_001D;
        }
        IL_001D: ;
        return;
    }

    public void ResetDirty()
    {
        // structural signature __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 bytes=151280850112850C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4e9909e1f428f51b420abcf1b5371bddae757a37 bytes=151280910112850C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 l0 = default;
        ICSharpCode.Decompiler.IL.ILInstruction l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        __cil_ref_4e9909e1f428f51b420abcf1b5371bddae757a37 v1 = __cil_direct_06000E88(v0);
        __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 v2 = __cil_callvirt_0A00004F(v1);
        l0 = v2;
        try {
            IL_000C: ;
            goto IL_001C;
            IL_000E: ;
            __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 v3 = l0;
            global::ICSharpCode.Decompiler.IL.ILInstruction v4 = __cil_callvirt_0A00004E(v3);
            l1 = v4;
            global::ICSharpCode.Decompiler.IL.ILInstruction v5 = l1;
            int v6 = 0;
            __cil_callvirt_06000E72(v5, __cil_bool_store(v6));
            goto IL_001C;
            IL_001C: ;
            __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 v7 = l0;
            int v8 = __cil_bool_load(__cil_callvirt_0A000018(v7));
            if (v8 != 0) {
                goto IL_000E;
            } else {
                goto IL_0024;
            }
            IL_0024: ;
            goto IL_0030;
        }
        finally {
            IL_0026: ;
            __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 v9 = l0;
            if (v9 is null) {
                goto IL_002F;
            } else {
                goto IL_0029;
            }
            IL_0029: ;
            __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 v10 = l0;
            __cil_callvirt_0A000017(v10);
            goto IL_002F;
            IL_002F: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0030: ;
        return;
    }

    public ICSharpCode.Decompiler.IL.InstructionFlags get_Flags()
    {
        // enum storage token=0x02000160 alias=__cil_enum_02000160 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@InstructionFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.flags));
        if (unchecked((uint)v1) != unchecked((uint)-1)) {
            goto IL_0015;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        int v5 = unchecked((int)(__cil_callvirt_06000E79(this)));
        this.flags = unchecked((__cil_enum_02000160)(v5));
        IL_0015: ;
        int v7 = unchecked((int)(this.flags));
        return unchecked((__cil_enum_02000160)(v7));
    }

    public bool HasFlag(ICSharpCode.Decompiler.IL.InstructionFlags flags)
    {
        // enum storage token=0x02000160 alias=__cil_enum_02000160 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@InstructionFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.Flags));
        return (unchecked((uint)unchecked(v1 & unchecked((int)(flags)))) > unchecked((uint)0));
    }

    public bool HasDirectFlag(ICSharpCode.Decompiler.IL.InstructionFlags flags)
    {
        // enum storage token=0x02000160 alias=__cil_enum_02000160 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@InstructionFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(__cil_callvirt_06000E7A(this)));
        return (unchecked((uint)unchecked(v1 & unchecked((int)(flags)))) > unchecked((uint)0));
    }

    protected void InvalidateFlags()
    {
        // enum storage token=0x02000160 alias=__cil_enum_02000160 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@InstructionFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.IL.ILInstruction l0 = default;
        l0 = this;
        goto IL_0012;
        IL_0004: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = l0;
        v1.flags = unchecked((__cil_enum_02000160)(-1));
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = v3.parent;
        l0 = v4;
        IL_0012: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = l0;
        if (v5 is null) {
            goto IL_001E;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v6 = l0;
        int v7 = unchecked((int)(v6.flags));
        if (unchecked((uint)v7) != unchecked((uint)-1)) {
            goto IL_0004;
        } else {
            goto IL_001E;
        }
        IL_001E: ;
        return;
    }

    protected abstract ICSharpCode.Decompiler.IL.InstructionFlags ComputeFlags();

    public abstract ICSharpCode.Decompiler.IL.InstructionFlags get_DirectFlags();

    public void AddILRange(ICSharpCode.Decompiler.Util.Interval ilRange)
    {
        // structural signature __cil_value_95b0fb0c40788d8e86410ac81b4cf56a2d0b0041 bytes=1183A4: valuetype ICSharpCode.Decompiler.Util.Interval; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.ILRange = ilRange;
        return;
    }

    public abstract void WriteTo(ICSharpCode.Decompiler.ITextOutput output);

    public override string ToString()
    {
        // structural signature __cil_value_95b0fb0c40788d8e86410ac81b4cf56a2d0b0041 bytes=1183A4: valuetype ICSharpCode.Decompiler.Util.Interval; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        ICSharpCode.Decompiler.PlainTextOutput l0 = default;
        int l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.PlainTextOutput v0 = __cil_newobj_060000A5();
        l0 = v0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = this;
        global::ICSharpCode.Decompiler.PlainTextOutput v2 = l0;
        __cil_callvirt_06000E7C(v1, ((ICSharpCode.Decompiler.ITextOutput)(v2)));
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = this;
        ref __cil_value_95b0fb0c40788d8e86410ac81b4cf56a2d0b0041 v4 = ref v3.ILRange;
        int v5 = __cil_bool_load(__cil_direct_0600092D(ref v4));
        if (v5 != 0) {
            goto IL_0042;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        global::ICSharpCode.Decompiler.PlainTextOutput v6 = l0;
        string v7 = __cil_ldstr_700052DD(" at IL_");
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = this;
        ref __cil_value_95b0fb0c40788d8e86410ac81b4cf56a2d0b0041 v9 = ref v8.ILRange;
        int v10 = v9.Start;
        l1 = v10;
        ref int v11 = ref l1;
        string v12 = __cil_ldstr_70002DB5("x4");
        string v13 = __cil_memberref_call_0A0003C1(ref v11, v12);
        string v14 = System.String.Concat(v7, v13);
        __cil_callvirt_060000AC(v6, v14);
        goto IL_0042;
        IL_0042: ;
        global::ICSharpCode.Decompiler.PlainTextOutput v15 = l0;
        string v16 = v15.ToString();
        return v16;
    }

    public abstract void AcceptVisitor(ICSharpCode.Decompiler.IL.ILVisitor visitor);

    public abstract T AcceptVisitor<T>(ICSharpCode.Decompiler.IL.ILVisitor<T> visitor);

    public abstract T AcceptVisitor<C, T>(ICSharpCode.Decompiler.IL.ILVisitor<C, T> visitor, C context);

    public ICSharpCode.Decompiler.IL.ILInstruction.ChildrenCollection get_Children()
    {
        // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v1 = __cil_value_newobj_060024A9(this);
        return v1;
    }

    protected abstract int GetChildCount();

    protected abstract ICSharpCode.Decompiler.IL.ILInstruction GetChild(int index);

    protected abstract void SetChild(int index, ICSharpCode.Decompiler.IL.ILInstruction value);

    protected abstract ICSharpCode.Decompiler.IL.SlotInfo GetChildSlot(int index);

    internal void AssertNoEnumerators()
    {
        return;
    }

    public void ReplaceWith(ICSharpCode.Decompiler.IL.ILInstruction replacement)
    {
        if (!System.Object.ReferenceEquals(replacement, this)) {
            goto IL_0005;
        } else {
            goto IL_0004;
        }
        IL_0004: ;
        return;
        IL_0005: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = this.parent;
        int v5 = this.ChildIndex;
        __cil_callvirt_06000E84(v3, v5, replacement);
        return;
    }

    public System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.IL.ILInstruction> get_Descendants()
    {
        // structural signature __cil_ref_4e9909e1f428f51b420abcf1b5371bddae757a37 bytes=151280910112850C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v1 = __cil_newobj_060024B5(-2);
        v1.__il_field_04000C98 = this;
        return v1;
    }

    public System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.IL.ILInstruction> get_Ancestors()
    {
        // structural signature __cil_ref_4e9909e1f428f51b420abcf1b5371bddae757a37 bytes=151280910112850C: class [mscorlib]System.Collections.Generic.IEnumerable`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F416E636573746F72733E645F5F3931 v1 = __cil_newobj_060024BE(-2);
        v1.__il_field_04000C9E = this;
        return v1;
    }

    internal void AddRef()
    {
        byte l0 = default;
        int v2 = unchecked((int)(this.refCount));
        l0 = unchecked((byte)(v2));
        int v3 = unchecked((int)(l0));
        int v5 = unchecked(v3 + 1);
        int v6 = unchecked((int)(unchecked((byte)(v5))));
        this.refCount = unchecked((byte)(v6));
        int v7 = unchecked((int)(l0));
        if (v7 != 0) {
            goto IL_001A;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        __cil_callvirt_06000E8D(this);
        IL_001A: ;
        return;
    }

    internal void ReleaseRef()
    {
        byte l0 = default;
        int v2 = unchecked((int)(this.refCount));
        int v4 = unchecked(v2 - 1);
        int v5 = unchecked((int)(unchecked((byte)(v4))));
        l0 = unchecked((byte)(v5));
        int v6 = unchecked((int)(l0));
        this.refCount = unchecked((byte)(v6));
        int v7 = unchecked((int)(l0));
        if (v7 != 0) {
            goto IL_001A;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        __cil_callvirt_06000E8E(this);
        IL_001A: ;
        return;
    }

    protected internal bool get_IsConnected()
    {
        int v1 = unchecked((int)(this.refCount));
        return (v1 > 0);
    }

    protected virtual void Connected()
    {
        // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 l0 = default;
        __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 l1 = default;
        ICSharpCode.Decompiler.IL.ILInstruction l2 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v1 = __cil_direct_06000E81(v0);
        l1 = v1;
        ref __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v2 = ref l1;
        __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v3 = __cil_direct_060024AC(ref v2);
        l0 = v3;
        try {
            IL_000F: ;
            goto IL_001F;
            IL_0011: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v4 = ref l0;
            global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_direct_060024B0(ref v4);
            l2 = v5;
            global::ICSharpCode.Decompiler.IL.ILInstruction v6 = l2;
            __cil_callvirt_06000E8A(v6);
            goto IL_001F;
            IL_001F: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v7 = ref l0;
            int v8 = __cil_bool_load(__cil_direct_060024B1(ref v7));
            if (v8 != 0) {
                goto IL_0011;
            } else {
                goto IL_0028;
            }
            IL_0028: ;
            goto IL_0038;
        }
        finally {
            IL_002A: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v9 = ref l0;
            __cil_constrained_02000347_0A000017(ref v9);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0038: ;
        return;
    }

    protected virtual void Disconnected()
    {
        // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 l0 = default;
        __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 l1 = default;
        ICSharpCode.Decompiler.IL.ILInstruction l2 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v1 = __cil_direct_06000E81(v0);
        l1 = v1;
        ref __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v2 = ref l1;
        __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v3 = __cil_direct_060024AC(ref v2);
        l0 = v3;
        try {
            IL_000F: ;
            goto IL_001F;
            IL_0011: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v4 = ref l0;
            global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_direct_060024B0(ref v4);
            l2 = v5;
            global::ICSharpCode.Decompiler.IL.ILInstruction v6 = l2;
            __cil_callvirt_06000E8B(v6);
            goto IL_001F;
            IL_001F: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v7 = ref l0;
            int v8 = __cil_bool_load(__cil_direct_060024B1(ref v7));
            if (v8 != 0) {
                goto IL_0011;
            } else {
                goto IL_0028;
            }
            IL_0028: ;
            goto IL_0038;
        }
        finally {
            IL_002A: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v9 = ref l0;
            __cil_constrained_02000347_0A000017(ref v9);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0038: ;
        return;
    }

    public ICSharpCode.Decompiler.IL.ILInstruction get_Parent()
    {
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = this.parent;
        return v1;
    }

    public int get_ChildIndex()
    {
        int v1 = this.__il_field_04000418;
        return v1;
    }

    internal void set_ChildIndex(int value)
    {
        this.__il_field_04000418 = value;
        return;
    }

    public ICSharpCode.Decompiler.IL.SlotInfo get_SlotInfo()
    {
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = this.parent;
        int v3 = this.ChildIndex;
        global::ICSharpCode.Decompiler.IL.SlotInfo v4 = __cil_callvirt_06000E85(v1, v3);
        return v4;
    }

    protected internal void SetChildInstruction(ref ICSharpCode.Decompiler.IL.ILInstruction childPointer, ICSharpCode.Decompiler.IL.ILInstruction newValue, int index)
    {
        ICSharpCode.Decompiler.IL.ILInstruction l0 = default;
        IL_0000: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v0 = ref childPointer;
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = v0;
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.ILInstruction v2 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = newValue;
        if (!System.Object.ReferenceEquals(v2, v3)) {
            goto IL_0008;
        } else {
            goto IL_0007;
        }
        IL_0007: ;
        return;
        IL_0008: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v4 = ref childPointer;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = newValue;
        v4 = v5;
        global::ICSharpCode.Decompiler.IL.ILInstruction v6 = newValue;
        if (v6 is null) {
            goto IL_001C;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v7 = newValue;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = this;
        v7.parent = v8;
        global::ICSharpCode.Decompiler.IL.ILInstruction v9 = newValue;
        int v10 = index;
        __cil_callvirt_06000E91(v9, v10);
        goto IL_001C;
        IL_001C: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v11 = this;
        __cil_direct_06000E78(v11);
        global::ICSharpCode.Decompiler.IL.ILInstruction v12 = this;
        __cil_direct_06000E73(v12);
        global::ICSharpCode.Decompiler.IL.ILInstruction v13 = this;
        int v14 = unchecked((int)(v13.refCount));
        int v15 = 0;
        if (v14 <= v15) {
            goto IL_0043;
        } else {
            goto IL_0031;
        }
        IL_0031: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v16 = newValue;
        if (v16 is null) {
            goto IL_003A;
        } else {
            goto IL_0034;
        }
        IL_0034: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v17 = newValue;
        __cil_callvirt_06000E8A(v17);
        goto IL_003A;
        IL_003A: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v18 = l0;
        if (v18 is null) {
            goto IL_0043;
        } else {
            goto IL_003D;
        }
        IL_003D: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v19 = l0;
        __cil_callvirt_06000E8B(v19);
        goto IL_0043;
        IL_0043: ;
        return;
    }

    protected internal void InstructionCollectionAdded(ICSharpCode.Decompiler.IL.ILInstruction newChild)
    {
        newChild.parent = this;
        int v3 = unchecked((int)(this.refCount));
        if (v3 <= 0) {
            goto IL_0016;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        __cil_callvirt_06000E8A(newChild);
        IL_0016: ;
        return;
    }

    protected internal void InstructionCollectionRemoved(ICSharpCode.Decompiler.IL.ILInstruction oldChild)
    {
        int v1 = unchecked((int)(this.refCount));
        if (v1 <= 0) {
            goto IL_000F;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        __cil_callvirt_06000E8B(oldChild);
        IL_000F: ;
        return;
    }

    protected internal virtual void InstructionCollectionUpdateComplete()
    {
        __cil_direct_06000E78(this);
        __cil_direct_06000E73(this);
        return;
    }

    public abstract ICSharpCode.Decompiler.IL.ILInstruction Clone();

    protected ICSharpCode.Decompiler.IL.ILInstruction ShallowClone()
    {
        // enum storage token=0x02000160 alias=__cil_enum_02000160 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@InstructionFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        object v1 = this.MemberwiseClone();
        global::ICSharpCode.Decompiler.IL.ILInstruction v2 = ((ICSharpCode.Decompiler.IL.ILInstruction)(object)v1);
        v2.refCount = unchecked((byte)(0));
        v2.parent = null;
        v2.flags = unchecked((__cil_enum_02000160)(-1));
        return v2;
    }

    public ICSharpCode.Decompiler.IL.Patterns.Match Match(ICSharpCode.Decompiler.IL.ILInstruction node)
    {
        // structural signature __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc bytes=1185F8: valuetype ICSharpCode.Decompiler.IL.Patterns.Match; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc l0 = default;
        IL_0000: ;
        ref __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc v0 = ref l0;
        v0 = default;
        ref __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc v1 = ref l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v2 = this;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = node;
        ref __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc v4 = ref l0;
        int v5 = __cil_bool_load(__cil_callvirt_06000E9A(v2, v3, ref v4));
        __cil_direct_06001021(ref v1, __cil_bool_store(v5));
        __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc v6 = l0;
        return v6;
    }

    protected internal abstract bool PerformMatch(ICSharpCode.Decompiler.IL.ILInstruction other, ref ICSharpCode.Decompiler.IL.Patterns.Match match);

    protected internal virtual bool PerformMatch(ref ICSharpCode.Decompiler.IL.Patterns.ListMatch listMatch, ref ICSharpCode.Decompiler.IL.Patterns.Match match)
    {
        // structural signature __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc bytes=1185F8: valuetype ICSharpCode.Decompiler.IL.Patterns.Match; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_8b79dc9eef821beb42c20098e67611b5e0f955be bytes=1185F0: valuetype ICSharpCode.Decompiler.IL.Patterns.ListMatch; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_e0c21b2a40a4a2df5312322eaa9137098e557a88 bytes=151282D50112850C: class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        IL_0000: ;
        ref __cil_value_8b79dc9eef821beb42c20098e67611b5e0f955be v0 = ref listMatch;
        int v1 = v0.SyntaxIndex;
        ref __cil_value_8b79dc9eef821beb42c20098e67611b5e0f955be v2 = ref listMatch;
        __cil_ref_e0c21b2a40a4a2df5312322eaa9137098e557a88 v3 = v2.SyntaxList;
        int v4 = __cil_callvirt_0A000632(v3);
        if (v1 >= v4) {
            goto IL_003A;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = this;
        ref __cil_value_8b79dc9eef821beb42c20098e67611b5e0f955be v6 = ref listMatch;
        __cil_ref_e0c21b2a40a4a2df5312322eaa9137098e557a88 v7 = v6.SyntaxList;
        ref __cil_value_8b79dc9eef821beb42c20098e67611b5e0f955be v8 = ref listMatch;
        int v9 = v8.SyntaxIndex;
        global::ICSharpCode.Decompiler.IL.ILInstruction v10 = __cil_callvirt_0A000633(v7, v9);
        ref __cil_value_ddb4d65c337d37ded72084a61e708390f592b8bc v11 = ref match;
        int v12 = __cil_bool_load(__cil_callvirt_06000E9A(v5, v10, ref v11));
        if (v12 == 0) {
            goto IL_003A;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        ref __cil_value_8b79dc9eef821beb42c20098e67611b5e0f955be v13 = ref listMatch;
        ref int v14 = ref v13.SyntaxIndex;
        int v15 = unchecked((int)(v14));
        int v16 = 1;
        int v17 = unchecked(v15 + v16);
        v14 = v17;
        int v18 = 1;
        return __cil_bool_store(v18);
        IL_003A: ;
        int v19 = 0;
        return __cil_bool_store(v19);
    }

    public bool MatchLdcI4(int val)
    {
        // enum storage token=0x020000F9 alias=__cil_enum_020000F9 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@OpCode; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.OpCode));
        if (unchecked((uint)v1) != unchecked((uint)33)) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdcI4 v4 = ((ICSharpCode.Decompiler.IL.LdcI4)(object)this);
        int v5 = v4.Value;
        return (v5 == val);
    }

    public bool MatchLdcI(out long val)
    {
        int l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        ref long v1 = ref val;
        int v2 = __cil_bool_load(__cil_direct_06000E4C(v0, ref v1));
        if (v2 == 0) {
            goto IL_000B;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        int v3 = 1;
        return __cil_bool_store(v3);
        IL_000B: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = this;
        ref int v5 = ref l0;
        int v6 = __cil_bool_load(__cil_direct_06000E4B(v4, ref v5));
        if (v6 == 0) {
            goto IL_001B;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        ref long v7 = ref val;
        int v8 = l0;
        long v9 = unchecked((long)(v8));
        v7 = v9;
        int v10 = 1;
        return __cil_bool_store(v10);
        IL_001B: ;
        int v11 = 0;
        return __cil_bool_store(v11);
    }

    public bool MatchLdLoc(ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        ICSharpCode.Decompiler.IL.LdLoc l0 = default;
        global::ICSharpCode.Decompiler.IL.LdLoc v1 = ((object)this as ICSharpCode.Decompiler.IL.LdLoc);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdLoc v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdLoc v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v4 = __cil_callvirt_06000BA7(v3);
        return (System.Object.ReferenceEquals(v4, variable));
    }

    public bool MatchLdLoca(ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        ICSharpCode.Decompiler.IL.LdLoca l0 = default;
        global::ICSharpCode.Decompiler.IL.LdLoca v1 = ((object)this as ICSharpCode.Decompiler.IL.LdLoca);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdLoca v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdLoca v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v4 = __cil_callvirt_06000BBA(v3);
        return (System.Object.ReferenceEquals(v4, variable));
    }

    public bool MatchLdLocRef(ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        // structural signature __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 bytes=151180E90102: valuetype [mscorlib]System.Nullable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 l0 = default;
        bool l1 = default;
        int s3_0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILVariable v0 = variable;
        global::ICSharpCode.Decompiler.TypeSystem.IType v1 = __cil_callvirt_06000F33(v0);
        __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v2 = __cil_callvirt_0600029E(v1);
        l0 = v2;
        int v3 = 1;
        l1 = __cil_bool_store(v3);
        ref __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v4 = ref l0;
        int v5 = __cil_bool_load(__cil_value_call_0A000281(ref v4));
        int v6 = __cil_bool_load(l1);
        if (v5 == v6) {
            goto IL_001B;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        int v7 = 0;
        int e1_3_0 = v7;
        s3_0 = e1_3_0;
        goto IL_0022;
        IL_001B: ;
        ref __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v8 = ref l0;
        int v9 = __cil_bool_load(__cil_value_call_0A000276(ref v8));
        int e2_3_0 = v9;
        s3_0 = e2_3_0;
        goto IL_0022;
        IL_0022: ;
        if (s3_0 == 0) {
            goto IL_002C;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v10 = this;
        global::ICSharpCode.Decompiler.IL.ILVariable v11 = variable;
        int v12 = __cil_bool_load(__cil_direct_06000E9E(v10, v11));
        return __cil_bool_store(v12);
        IL_002C: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v13 = this;
        global::ICSharpCode.Decompiler.IL.ILVariable v14 = variable;
        int v15 = __cil_bool_load(__cil_direct_06000E9F(v13, v14));
        return __cil_bool_store(v15);
    }

    public bool MatchLdLocRef(out ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        // structural signature __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 bytes=151180E90102: valuetype [mscorlib]System.Nullable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        ICSharpCode.Decompiler.IL.ILInstruction l0 = default;
        ICSharpCode.Decompiler.IL.LdLoc l1 = default;
        ICSharpCode.Decompiler.IL.LdLoca l2 = default;
        ICSharpCode.Decompiler.IL.LdLoc l3 = default;
        ICSharpCode.Decompiler.IL.LdLoca l4 = default;
        __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 l5 = default;
        bool l6 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        l0 = v0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v1 = l0;
        if (v1 is null) {
            goto IL_0080;
        } else {
            goto IL_0005;
        }
        IL_0005: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v2 = l0;
        global::ICSharpCode.Decompiler.IL.LdLoc v3 = ((object)v2 as ICSharpCode.Decompiler.IL.LdLoc);
        l1 = v3;
        if (v3 is not null) {
            goto IL_001B;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = l0;
        global::ICSharpCode.Decompiler.IL.LdLoca v5 = ((object)v4 as ICSharpCode.Decompiler.IL.LdLoca);
        l2 = v5;
        if (v5 is null) {
            goto IL_0080;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        goto IL_004B;
        IL_001B: ;
        global::ICSharpCode.Decompiler.IL.LdLoc v6 = l1;
        l3 = v6;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v7 = ref variable;
        global::ICSharpCode.Decompiler.IL.LdLoc v8 = l3;
        global::ICSharpCode.Decompiler.IL.ILVariable v9 = __cil_callvirt_06000BA7(v8);
        v7 = v9;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v10 = ref variable;
        global::ICSharpCode.Decompiler.IL.ILVariable v11 = v10;
        global::ICSharpCode.Decompiler.TypeSystem.IType v12 = __cil_callvirt_06000F33(v11);
        __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v13 = __cil_callvirt_0600029E(v12);
        l5 = v13;
        int v14 = 1;
        l6 = __cil_bool_store(v14);
        ref __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v15 = ref l5;
        int v16 = __cil_bool_load(__cil_value_call_0A000281(ref v15));
        int v17 = __cil_bool_load(l6);
        if (v16 == v17) {
            goto IL_0043;
        } else {
            goto IL_0041;
        }
        IL_0041: ;
        int v18 = 0;
        return __cil_bool_store(v18);
        IL_0043: ;
        ref __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v19 = ref l5;
        int v20 = __cil_bool_load(__cil_value_call_0A000276(ref v19));
        return __cil_bool_store(v20);
        IL_004B: ;
        global::ICSharpCode.Decompiler.IL.LdLoca v21 = l2;
        l4 = v21;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v22 = ref variable;
        global::ICSharpCode.Decompiler.IL.LdLoca v23 = l4;
        global::ICSharpCode.Decompiler.IL.ILVariable v24 = __cil_callvirt_06000BBA(v23);
        v22 = v24;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v25 = ref variable;
        global::ICSharpCode.Decompiler.IL.ILVariable v26 = v25;
        global::ICSharpCode.Decompiler.TypeSystem.IType v27 = __cil_callvirt_06000F33(v26);
        __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v28 = __cil_callvirt_0600029E(v27);
        l5 = v28;
        int v29 = 1;
        l6 = __cil_bool_store(v29);
        ref __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v30 = ref l5;
        int v31 = __cil_bool_load(__cil_value_call_0A000281(ref v30));
        int v32 = __cil_bool_load(l6);
        if (v31 == v32) {
            goto IL_0075;
        } else {
            goto IL_0073;
        }
        IL_0073: ;
        int v33 = 1;
        return __cil_bool_store(v33);
        IL_0075: ;
        ref __cil_value_00710df60610a90807b50cf4f7a6dc7389aaf236 v34 = ref l5;
        int v35 = __cil_bool_load(__cil_value_call_0A000276(ref v34));
        int v36 = 0;
        int v37 = (v35 == v36 ? 1 : 0);
        return __cil_bool_store(v37);
        IL_0080: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v38 = ref variable;
        v38 = null;
        int v39 = 0;
        return __cil_bool_store(v39);
    }

    public bool MatchLdThis()
    {
        // enum storage token=0x02000159 alias=__cil_enum_02000159 underlying=int: global::@ICSharpCode.@Decompiler.@IL.@VariableKind; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.IL.LdLoc l0 = default;
        global::ICSharpCode.Decompiler.IL.LdLoc v1 = ((object)this as ICSharpCode.Decompiler.IL.LdLoc);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdLoc v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdLoc v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v4 = __cil_callvirt_06000BA7(v3);
        int v5 = unchecked((int)(__cil_callvirt_06000F31(v4)));
        if (unchecked((uint)v5) != unchecked((uint)4)) {
            return false;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::ICSharpCode.Decompiler.IL.LdLoc v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v8 = __cil_callvirt_06000BA7(v7);
        int v9 = v8.Index;
        return (v9 < 0);
    }

    public bool MatchStLoc(out ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        ICSharpCode.Decompiler.IL.StLoc l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.StLoc v1 = ((object)v0 as ICSharpCode.Decompiler.IL.StLoc);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.StLoc v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v3 = ref variable;
        global::ICSharpCode.Decompiler.IL.StLoc v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v5 = __cil_callvirt_06000BC9(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v7 = ref variable;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchStLoc(ICSharpCode.Decompiler.IL.ILVariable variable, out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.StLoc l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.StLoc v1 = ((object)v0 as ICSharpCode.Decompiler.IL.StLoc);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.StLoc v2 = l0;
        if (v2 is null) {
            goto IL_001D;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.StLoc v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v4 = __cil_callvirt_06000BC9(v3);
        global::ICSharpCode.Decompiler.IL.ILVariable v5 = variable;
        if (!System.Object.ReferenceEquals(v4, v5)) {
            goto IL_001D;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref value;
        global::ICSharpCode.Decompiler.IL.StLoc v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000BD2(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001D: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref value;
        v10 = null;
        int v11 = 0;
        return __cil_bool_store(v11);
    }

    public bool MatchLdLen(ICSharpCode.Decompiler.IL.StackType type, out ICSharpCode.Decompiler.IL.ILInstruction array)
    {
        // enum storage token=0x02000162 alias=__cil_enum_02000162 underlying=byte: global::@ICSharpCode.@Decompiler.@IL.@StackType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.IL.LdLen l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdLen v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdLen);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.LdLen v2 = l0;
        if (v2 is null) {
            goto IL_001D;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdLen v3 = l0;
        int v4 = unchecked((int)(unchecked((byte)(__cil_callvirt_06000E6F(v3)))));
        int v5 = unchecked((int)(unchecked((byte)(type))));
        if (unchecked((uint)v4) != unchecked((uint)v5)) {
            goto IL_001D;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref array;
        global::ICSharpCode.Decompiler.IL.LdLen v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000D06(v7);
        v6 = v8;
        int v9 = 1;
        return __cil_bool_store(v9);
        IL_001D: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref array;
        v10 = null;
        int v11 = 0;
        return __cil_bool_store(v11);
    }

    public bool MatchBranch(out ICSharpCode.Decompiler.IL.Block targetBlock)
    {
        ICSharpCode.Decompiler.IL.Branch l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Branch v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Branch);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Branch v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.Block v3 = ref targetBlock;
        global::ICSharpCode.Decompiler.IL.Branch v4 = l0;
        global::ICSharpCode.Decompiler.IL.Block v5 = __cil_callvirt_06000AD6(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.Block v7 = ref targetBlock;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchBranch(ICSharpCode.Decompiler.IL.Block targetBlock)
    {
        ICSharpCode.Decompiler.IL.Branch l0 = default;
        global::ICSharpCode.Decompiler.IL.Branch v1 = ((object)this as ICSharpCode.Decompiler.IL.Branch);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Branch v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.Branch v3 = l0;
        global::ICSharpCode.Decompiler.IL.Block v4 = __cil_callvirt_06000AD6(v3);
        return (System.Object.ReferenceEquals(v4, targetBlock));
    }

    public bool MatchLeave(out ICSharpCode.Decompiler.IL.BlockContainer targetContainer)
    {
        ICSharpCode.Decompiler.IL.Leave l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.Leave v1 = ((object)v0 as ICSharpCode.Decompiler.IL.Leave);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Leave v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.BlockContainer v3 = ref targetContainer;
        global::ICSharpCode.Decompiler.IL.Leave v4 = l0;
        global::ICSharpCode.Decompiler.IL.BlockContainer v5 = __cil_callvirt_06000AE6(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.BlockContainer v7 = ref targetContainer;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchLeave(ICSharpCode.Decompiler.IL.BlockContainer targetContainer)
    {
        ICSharpCode.Decompiler.IL.Leave l0 = default;
        global::ICSharpCode.Decompiler.IL.Leave v1 = ((object)this as ICSharpCode.Decompiler.IL.Leave);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.Leave v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.Leave v3 = l0;
        global::ICSharpCode.Decompiler.IL.BlockContainer v4 = __cil_callvirt_06000AE6(v3);
        return (System.Object.ReferenceEquals(v4, targetContainer));
    }

    public bool MatchIfInstruction(out ICSharpCode.Decompiler.IL.ILInstruction condition, out ICSharpCode.Decompiler.IL.ILInstruction trueInst, out ICSharpCode.Decompiler.IL.ILInstruction falseInst)
    {
        ICSharpCode.Decompiler.IL.IfInstruction l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.IfInstruction v1 = ((object)v0 as ICSharpCode.Decompiler.IL.IfInstruction);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.IfInstruction v2 = l0;
        if (v2 is null) {
            goto IL_0024;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v3 = ref condition;
        global::ICSharpCode.Decompiler.IL.IfInstruction v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v5 = __cil_callvirt_06000AEE(v4);
        v3 = v5;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref trueInst;
        global::ICSharpCode.Decompiler.IL.IfInstruction v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000AF0(v7);
        v6 = v8;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v9 = ref falseInst;
        global::ICSharpCode.Decompiler.IL.IfInstruction v10 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v11 = __cil_callvirt_06000AF2(v10);
        v9 = v11;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0024: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v13 = ref condition;
        v13 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref trueInst;
        v14 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v15 = ref falseInst;
        v15 = null;
        int v16 = 0;
        return __cil_bool_store(v16);
    }

    public bool MatchIfInstruction(out ICSharpCode.Decompiler.IL.ILInstruction condition, out ICSharpCode.Decompiler.IL.ILInstruction trueInst)
    {
        ICSharpCode.Decompiler.IL.IfInstruction l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.IfInstruction v1 = ((object)v0 as ICSharpCode.Decompiler.IL.IfInstruction);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.IfInstruction v2 = l0;
        if (v2 is null) {
            goto IL_0029;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.IfInstruction v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = __cil_callvirt_06000AF2(v3);
        int v5 = __cil_bool_load(__cil_callvirt_06000E3E(v4));
        if (v5 == 0) {
            goto IL_0029;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref condition;
        global::ICSharpCode.Decompiler.IL.IfInstruction v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_06000AEE(v7);
        v6 = v8;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v9 = ref trueInst;
        global::ICSharpCode.Decompiler.IL.IfInstruction v10 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v11 = __cil_callvirt_06000AF0(v10);
        v9 = v11;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0029: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v13 = ref condition;
        v13 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref trueInst;
        v14 = null;
        int v15 = 0;
        return __cil_bool_store(v15);
    }

    public bool MatchLogicAnd(out ICSharpCode.Decompiler.IL.ILInstruction lhs, out ICSharpCode.Decompiler.IL.ILInstruction rhs)
    {
        ICSharpCode.Decompiler.IL.IfInstruction l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.IfInstruction v1 = ((object)v0 as ICSharpCode.Decompiler.IL.IfInstruction);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.IfInstruction v2 = l0;
        if (v2 is null) {
            goto IL_002A;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.IfInstruction v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = __cil_callvirt_06000AF2(v3);
        int v5 = 0;
        int v6 = __cil_bool_load(__cil_callvirt_06000E9C(v4, v5));
        if (v6 == 0) {
            goto IL_002A;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref lhs;
        global::ICSharpCode.Decompiler.IL.IfInstruction v8 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v9 = __cil_callvirt_06000AEE(v8);
        v7 = v9;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref rhs;
        global::ICSharpCode.Decompiler.IL.IfInstruction v11 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v12 = __cil_callvirt_06000AF0(v11);
        v10 = v12;
        int v13 = 1;
        return __cil_bool_store(v13);
        IL_002A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref lhs;
        v14 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v15 = ref rhs;
        v15 = null;
        int v16 = 0;
        return __cil_bool_store(v16);
    }

    public bool MatchLogicOr(out ICSharpCode.Decompiler.IL.ILInstruction lhs, out ICSharpCode.Decompiler.IL.ILInstruction rhs)
    {
        ICSharpCode.Decompiler.IL.IfInstruction l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.IfInstruction v1 = ((object)v0 as ICSharpCode.Decompiler.IL.IfInstruction);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.IfInstruction v2 = l0;
        if (v2 is null) {
            goto IL_002A;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.IfInstruction v3 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = __cil_callvirt_06000AF0(v3);
        int v5 = 1;
        int v6 = __cil_bool_load(__cil_callvirt_06000E9C(v4, v5));
        if (v6 == 0) {
            goto IL_002A;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v7 = ref lhs;
        global::ICSharpCode.Decompiler.IL.IfInstruction v8 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v9 = __cil_callvirt_06000AEE(v8);
        v7 = v9;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v10 = ref rhs;
        global::ICSharpCode.Decompiler.IL.IfInstruction v11 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v12 = __cil_callvirt_06000AF2(v11);
        v10 = v12;
        int v13 = 1;
        return __cil_bool_store(v13);
        IL_002A: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref lhs;
        v14 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v15 = ref rhs;
        v15 = null;
        int v16 = 0;
        return __cil_bool_store(v16);
    }

    public bool MatchTryCatchHandler(out ICSharpCode.Decompiler.IL.ILVariable variable)
    {
        ICSharpCode.Decompiler.IL.TryCatchHandler l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v1 = ((object)v0 as ICSharpCode.Decompiler.IL.TryCatchHandler);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v2 = l0;
        if (v2 is null) {
            goto IL_0014;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v3 = ref variable;
        global::ICSharpCode.Decompiler.IL.TryCatchHandler v4 = l0;
        global::ICSharpCode.Decompiler.IL.ILVariable v5 = __cil_callvirt_06000B46(v4);
        v3 = v5;
        int v6 = 1;
        return __cil_bool_store(v6);
        IL_0014: ;
        ref global::ICSharpCode.Decompiler.IL.ILVariable v7 = ref variable;
        v7 = null;
        int v8 = 0;
        return __cil_bool_store(v8);
    }

    public bool MatchCompEquals(out ICSharpCode.Decompiler.IL.ILInstruction left, out ICSharpCode.Decompiler.IL.ILInstruction right)
    {
        // enum storage token=0x02000144 alias=__cil_enum_02000144 underlying=byte: global::@ICSharpCode.@Decompiler.@IL.@ComparisonKind; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000144 l0 = default;
        ICSharpCode.Decompiler.IL.Comp l1 = default;
        ICSharpCode.Decompiler.IL.LogicNot l2 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LogicNot v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LogicNot);
        l2 = v1;
        if (v1 is null) {
            goto IL_001A;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        int v2 = 1;
        l0 = unchecked((__cil_enum_02000144)(unchecked((byte)(v2))));
        global::ICSharpCode.Decompiler.IL.LogicNot v3 = l2;
        global::ICSharpCode.Decompiler.IL.ILInstruction v4 = __cil_callvirt_060009F1(v3);
        global::ICSharpCode.Decompiler.IL.Comp v5 = ((object)v4 as ICSharpCode.Decompiler.IL.Comp);
        l1 = v5;
        goto IL_0023;
        IL_001A: ;
        int v6 = 0;
        l0 = unchecked((__cil_enum_02000144)(unchecked((byte)(v6))));
        global::ICSharpCode.Decompiler.IL.ILInstruction v7 = this;
        global::ICSharpCode.Decompiler.IL.Comp v8 = ((object)v7 as ICSharpCode.Decompiler.IL.Comp);
        l1 = v8;
        goto IL_0023;
        IL_0023: ;
        global::ICSharpCode.Decompiler.IL.Comp v9 = l1;
        if (v9 is null) {
            goto IL_0041;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        global::ICSharpCode.Decompiler.IL.Comp v10 = l1;
        int v11 = unchecked((int)(unchecked((byte)(__cil_callvirt_06000B87(v10)))));
        int v12 = unchecked((int)(unchecked((byte)(l0))));
        if (unchecked((uint)v11) != unchecked((uint)v12)) {
            goto IL_0041;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v13 = ref left;
        global::ICSharpCode.Decompiler.IL.Comp v14 = l1;
        global::ICSharpCode.Decompiler.IL.ILInstruction v15 = __cil_callvirt_060009FD(v14);
        v13 = v15;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v16 = ref right;
        global::ICSharpCode.Decompiler.IL.Comp v17 = l1;
        global::ICSharpCode.Decompiler.IL.ILInstruction v18 = __cil_callvirt_060009FF(v17);
        v16 = v18;
        int v19 = 1;
        return __cil_bool_store(v19);
        IL_0041: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v20 = ref left;
        v20 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v21 = ref right;
        v21 = null;
        int v22 = 0;
        return __cil_bool_store(v22);
    }

    public bool MatchLdsFld(ICSharpCode.Decompiler.TypeSystem.IField field)
    {
        ICSharpCode.Decompiler.IL.LdObj l0 = default;
        ICSharpCode.Decompiler.IL.LdsFlda l1 = default;
        global::ICSharpCode.Decompiler.IL.LdObj v1 = ((object)this as ICSharpCode.Decompiler.IL.LdObj);
        l0 = v1;
        if (v1 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdObj v2 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = __cil_callvirt_06000C84(v2);
        global::ICSharpCode.Decompiler.IL.LdsFlda v4 = ((object)v3 as ICSharpCode.Decompiler.IL.LdsFlda);
        l1 = v4;
        if (v4 is null) {
            return false;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        global::ICSharpCode.Decompiler.IL.LdsFlda v6 = l1;
        global::ICSharpCode.Decompiler.TypeSystem.IField v7 = __cil_callvirt_06000C6B(v6);
        return field.Equals(((object)(v7)));
    }

    public bool MatchLdFld(out ICSharpCode.Decompiler.IL.ILInstruction target, out ICSharpCode.Decompiler.TypeSystem.IField field)
    {
        ICSharpCode.Decompiler.IL.LdObj l0 = default;
        ICSharpCode.Decompiler.IL.LdFlda l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdObj v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdObj);
        l0 = v1;
        if (v1 is null) {
            goto IL_002B;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdObj v2 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = __cil_callvirt_06000C84(v2);
        global::ICSharpCode.Decompiler.IL.LdFlda v4 = ((object)v3 as ICSharpCode.Decompiler.IL.LdFlda);
        l1 = v4;
        if (v4 is null) {
            goto IL_002B;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v5 = ref target;
        global::ICSharpCode.Decompiler.IL.LdFlda v6 = l1;
        global::ICSharpCode.Decompiler.IL.ILInstruction v7 = __cil_callvirt_06000C58(v6);
        v5 = v7;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v8 = ref field;
        global::ICSharpCode.Decompiler.IL.LdFlda v9 = l1;
        global::ICSharpCode.Decompiler.TypeSystem.IField v10 = __cil_callvirt_06000C5F(v9);
        v8 = v10;
        int v11 = 1;
        return __cil_bool_store(v11);
        IL_002B: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v12 = ref target;
        v12 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v13 = ref field;
        v13 = null;
        int v14 = 0;
        return __cil_bool_store(v14);
    }

    public bool MatchLdsFld(out ICSharpCode.Decompiler.TypeSystem.IField field)
    {
        ICSharpCode.Decompiler.IL.LdObj l0 = default;
        ICSharpCode.Decompiler.IL.LdsFlda l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.LdObj v1 = ((object)v0 as ICSharpCode.Decompiler.IL.LdObj);
        l0 = v1;
        if (v1 is null) {
            goto IL_0023;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.LdObj v2 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = __cil_callvirt_06000C84(v2);
        global::ICSharpCode.Decompiler.IL.LdsFlda v4 = ((object)v3 as ICSharpCode.Decompiler.IL.LdsFlda);
        l1 = v4;
        if (v4 is null) {
            goto IL_0023;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v5 = ref field;
        global::ICSharpCode.Decompiler.IL.LdsFlda v6 = l1;
        global::ICSharpCode.Decompiler.TypeSystem.IField v7 = __cil_callvirt_06000C6B(v6);
        v5 = v7;
        int v8 = 1;
        return __cil_bool_store(v8);
        IL_0023: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v9 = ref field;
        v9 = null;
        int v10 = 0;
        return __cil_bool_store(v10);
    }

    public bool MatchStsFld(out ICSharpCode.Decompiler.TypeSystem.IField field, out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.StObj l0 = default;
        ICSharpCode.Decompiler.IL.LdsFlda l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.StObj v1 = ((object)v0 as ICSharpCode.Decompiler.IL.StObj);
        l0 = v1;
        if (v1 is null) {
            goto IL_002B;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.StObj v2 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = __cil_callvirt_06000C9A(v2);
        global::ICSharpCode.Decompiler.IL.LdsFlda v4 = ((object)v3 as ICSharpCode.Decompiler.IL.LdsFlda);
        l1 = v4;
        if (v4 is null) {
            goto IL_002B;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v5 = ref field;
        global::ICSharpCode.Decompiler.IL.LdsFlda v6 = l1;
        global::ICSharpCode.Decompiler.TypeSystem.IField v7 = __cil_callvirt_06000C6B(v6);
        v5 = v7;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v8 = ref value;
        global::ICSharpCode.Decompiler.IL.StObj v9 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v10 = __cil_callvirt_06000C9C(v9);
        v8 = v10;
        int v11 = 1;
        return __cil_bool_store(v11);
        IL_002B: ;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v12 = ref field;
        v12 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v13 = ref value;
        v13 = null;
        int v14 = 0;
        return __cil_bool_store(v14);
    }

    public bool MatchStFld(out ICSharpCode.Decompiler.IL.ILInstruction target, out ICSharpCode.Decompiler.TypeSystem.IField field, out ICSharpCode.Decompiler.IL.ILInstruction value)
    {
        ICSharpCode.Decompiler.IL.StObj l0 = default;
        ICSharpCode.Decompiler.IL.LdFlda l1 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.StObj v1 = ((object)v0 as ICSharpCode.Decompiler.IL.StObj);
        l0 = v1;
        if (v1 is null) {
            goto IL_0033;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.StObj v2 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v3 = __cil_callvirt_06000C9A(v2);
        global::ICSharpCode.Decompiler.IL.LdFlda v4 = ((object)v3 as ICSharpCode.Decompiler.IL.LdFlda);
        l1 = v4;
        if (v4 is null) {
            goto IL_0033;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v5 = ref target;
        global::ICSharpCode.Decompiler.IL.LdFlda v6 = l1;
        global::ICSharpCode.Decompiler.IL.ILInstruction v7 = __cil_callvirt_06000C58(v6);
        v5 = v7;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v8 = ref field;
        global::ICSharpCode.Decompiler.IL.LdFlda v9 = l1;
        global::ICSharpCode.Decompiler.TypeSystem.IField v10 = __cil_callvirt_06000C5F(v9);
        v8 = v10;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v11 = ref value;
        global::ICSharpCode.Decompiler.IL.StObj v12 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v13 = __cil_callvirt_06000C9C(v12);
        v11 = v13;
        int v14 = 1;
        return __cil_bool_store(v14);
        IL_0033: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v15 = ref target;
        v15 = null;
        ref global::ICSharpCode.Decompiler.TypeSystem.IField v16 = ref field;
        v16 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v17 = ref value;
        v17 = null;
        int v18 = 0;
        return __cil_bool_store(v18);
    }

    public bool MatchBinaryNumericInstruction(ICSharpCode.Decompiler.IL.BinaryNumericOperator @operator)
    {
        // enum storage token=0x02000146 alias=__cil_enum_02000146 underlying=byte: global::@ICSharpCode.@Decompiler.@IL.@BinaryNumericOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.IL.BinaryNumericInstruction l0 = default;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v1 = ((object)this as ICSharpCode.Decompiler.IL.BinaryNumericInstruction);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v2 = l0;
        if (v2 is null) {
            return false;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v3 = l0;
        int v4 = unchecked((int)(unchecked((byte)(v3.Operator))));
        int v5 = unchecked((int)(unchecked((byte)(@operator))));
        return (v4 == v5);
    }

    public bool MatchBinaryNumericInstruction(ICSharpCode.Decompiler.IL.BinaryNumericOperator @operator, out ICSharpCode.Decompiler.IL.ILInstruction left, out ICSharpCode.Decompiler.IL.ILInstruction right)
    {
        // enum storage token=0x02000146 alias=__cil_enum_02000146 underlying=byte: global::@ICSharpCode.@Decompiler.@IL.@BinaryNumericOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.IL.BinaryNumericInstruction l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v1 = ((object)v0 as ICSharpCode.Decompiler.IL.BinaryNumericInstruction);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v2 = l0;
        if (v2 is null) {
            goto IL_0025;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v3 = l0;
        int v4 = unchecked((int)(unchecked((byte)(v3.Operator))));
        int v5 = unchecked((int)(unchecked((byte)(@operator))));
        if (unchecked((uint)v4) != unchecked((uint)v5)) {
            goto IL_0025;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref left;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_060009FD(v7);
        v6 = v8;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v9 = ref right;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v10 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v11 = __cil_callvirt_060009FF(v10);
        v9 = v11;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0025: ;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v13 = ref left;
        v13 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v14 = ref right;
        v14 = null;
        int v15 = 0;
        return __cil_bool_store(v15);
    }

    public bool MatchBinaryNumericInstruction(out ICSharpCode.Decompiler.IL.BinaryNumericOperator @operator, out ICSharpCode.Decompiler.IL.ILInstruction left, out ICSharpCode.Decompiler.IL.ILInstruction right)
    {
        // enum storage token=0x02000146 alias=__cil_enum_02000146 underlying=byte: global::@ICSharpCode.@Decompiler.@IL.@BinaryNumericOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        ICSharpCode.Decompiler.IL.BinaryNumericInstruction l0 = default;
        IL_0000: ;
        global::ICSharpCode.Decompiler.IL.ILInstruction v0 = this;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v1 = ((object)v0 as ICSharpCode.Decompiler.IL.BinaryNumericInstruction);
        l0 = v1;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v2 = l0;
        if (v2 is null) {
            goto IL_0024;
        } else {
            goto IL_000A;
        }
        IL_000A: ;
        ref __cil_enum_02000146 v3 = ref @operator;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v4 = l0;
        int v5 = unchecked((int)(unchecked((byte)(v4.Operator))));
        v3 = unchecked((__cil_enum_02000146)(unchecked((byte)(v5))));
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v6 = ref left;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v7 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v8 = __cil_callvirt_060009FD(v7);
        v6 = v8;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v9 = ref right;
        global::ICSharpCode.Decompiler.IL.BinaryNumericInstruction v10 = l0;
        global::ICSharpCode.Decompiler.IL.ILInstruction v11 = __cil_callvirt_060009FF(v10);
        v9 = v11;
        int v12 = 1;
        return __cil_bool_store(v12);
        IL_0024: ;
        ref __cil_enum_02000146 v13 = ref @operator;
        int v14 = 0;
        v13 = unchecked((__cil_enum_02000146)(unchecked((byte)(v14))));
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v15 = ref left;
        v15 = null;
        ref global::ICSharpCode.Decompiler.IL.ILInstruction v16 = ref right;
        v16 = null;
        int v17 = 0;
        return __cil_bool_store(v17);
    }

    public virtual ICSharpCode.Decompiler.IL.ILInstruction UnwrapConv(ICSharpCode.Decompiler.IL.ConversionKind kind)
    {
        // enum storage token=0x02000149 alias=__cil_enum_02000149 underlying=byte: global::@ICSharpCode.@Decompiler.@IL.@ConversionKind; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        return this;
    }
    // property ICSharpCode.Decompiler.IL.StackType ResultType { get: get_ResultType; }
    // property bool IsDirty { get: get_IsDirty; set: set_IsDirty; }
    // property ICSharpCode.Decompiler.IL.InstructionFlags Flags { get: get_Flags; }
    // property ICSharpCode.Decompiler.IL.InstructionFlags DirectFlags { get: get_DirectFlags; }
    // property ICSharpCode.Decompiler.IL.ILInstruction.ChildrenCollection Children { get: get_Children; }
    // property System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.IL.ILInstruction> Descendants { get: get_Descendants; }
    // property System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.IL.ILInstruction> Ancestors { get: get_Ancestors; }
    // property bool IsConnected { get: get_IsConnected; }
    // property ICSharpCode.Decompiler.IL.ILInstruction Parent { get: get_Parent; }
    // property int ChildIndex { get: get_ChildIndex; set: set_ChildIndex; }
    // property ICSharpCode.Decompiler.IL.SlotInfo SlotInfo { get: get_SlotInfo; }

    public struct ChildrenCollection : System.Collections.Generic.IReadOnlyList<ICSharpCode.Decompiler.IL.ILInstruction>, System.Collections.Generic.IReadOnlyCollection<ICSharpCode.Decompiler.IL.ILInstruction>, System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.IL.ILInstruction>, System.Collections.IEnumerable
    {
        private readonly ICSharpCode.Decompiler.IL.ILInstruction inst;

        internal ChildrenCollection(ICSharpCode.Decompiler.IL.ILInstruction inst)
        {
            // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v0 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = inst;
            v0.inst = v1;
            return;
        }

        public virtual int get_Count()
        {
            // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v0 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = v0.inst;
            int v2 = __cil_callvirt_06000E82(v1);
            return v2;
        }

        public virtual ICSharpCode.Decompiler.IL.ILInstruction get_Item(int index)
        {
            // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v0 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = v0.inst;
            int v2 = index;
            global::ICSharpCode.Decompiler.IL.ILInstruction v3 = __cil_callvirt_06000E83(v1, v2);
            return v3;
        }

        public ICSharpCode.Decompiler.IL.ILInstruction.ChildrenEnumerator GetEnumerator()
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 bytes=118D18: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_9a6ed8a960d15ffa8f9d7bf728b36ba9e718ff74 v0 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = v0.inst;
            __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v2 = __cil_value_newobj_060024AF(v1);
            return v2;
        }

        private virtual System.Collections.Generic.IEnumerator<ICSharpCode.Decompiler.IL.ILInstruction> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E476574456E756D657261746F72()
        {
            // IL fallback: incompatible value/receiver types
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 28, AC, 24, 00, 06, 8C, 47, 03, 00, 02, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: call 0x060024AC ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection::GetEnumerator
            // IL_0006: box 0x02000347 ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator
            // IL_000B: ret 
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // IL fallback: incompatible value/receiver types
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 28, AC, 24, 00, 06, 8C, 47, 03, 00, 02, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: call 0x060024AC ICSharpCode.Decompiler.IL.ILInstruction/ChildrenCollection::GetEnumerator
            // IL_0006: box 0x02000347 ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator
            // IL_000B: ret 
        }
        // property int Count { get: get_Count; }
        // property ICSharpCode.Decompiler.IL.ILInstruction this[int index0] { get: get_Item; }
    }

    public struct ChildrenEnumerator : System.Collections.Generic.IEnumerator<ICSharpCode.Decompiler.IL.ILInstruction>, System.IDisposable, System.Collections.IEnumerator
    {
        private ICSharpCode.Decompiler.IL.ILInstruction inst;
        private readonly int end;
        private int pos;

        internal ChildrenEnumerator(ICSharpCode.Decompiler.IL.ILInstruction inst)
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v0 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = inst;
            v0.inst = v1;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v2 = ref this;
            int v3 = -1;
            v2.pos = v3;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v4 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v5 = inst;
            int v6 = __cil_callvirt_06000E82(v5);
            v4.end = v6;
            return;
        }

        public virtual ICSharpCode.Decompiler.IL.ILInstruction get_Current()
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v0 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = v0.inst;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v2 = ref this;
            int v3 = v2.pos;
            global::ICSharpCode.Decompiler.IL.ILInstruction v4 = __cil_callvirt_06000E83(v1, v3);
            return v4;
        }

        public virtual bool MoveNext()
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            int l0 = default;
            IL_0000: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v0 = ref this;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v1 = ref this;
            int v2 = v1.pos;
            int v3 = 1;
            int v4 = unchecked(v2 + v3);
            l0 = v4;
            int v5 = l0;
            v0.pos = v5;
            int v6 = l0;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v7 = ref this;
            int v8 = v7.end;
            int v9 = (v6 < v8 ? 1 : 0);
            return __cil_bool_store(v9);
        }

        public virtual void Dispose()
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            return;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v0 = ref this;
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = __cil_direct_060024B0(ref v0);
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v0 = ref this;
            int v1 = -1;
            v0.pos = v1;
            return;
        }
        // property ICSharpCode.Decompiler.IL.ILInstruction Current { get: get_Current; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }

    private sealed class __name_3C6765745F44657363656E64616E74733E645F5F3839 : System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.IL.ILInstruction>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<ICSharpCode.Decompiler.IL.ILInstruction>, System.IDisposable, System.Collections.IEnumerator
    {
        private int __il_field_04000C95;
        private ICSharpCode.Decompiler.IL.ILInstruction __il_field_04000C96;
        private int __il_field_04000C97;
        public ICSharpCode.Decompiler.IL.ILInstruction __il_field_04000C98;
        private System.Collections.Generic.Stack<ICSharpCode.Decompiler.IL.ILInstruction.ChildrenEnumerator> __il_field_04000C99;
        private ICSharpCode.Decompiler.IL.ILInstruction.ChildrenEnumerator __il_field_04000C9A;

        public __name_3C6765745F44657363656E64616E74733E645F5F3839(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_04000C95 = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04000C97 = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            int l0 = default;
            IL_0000: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v0 = this;
            int v1 = v0.__il_field_04000C95;
            l0 = v1;
            int v2 = l0;
            int v3 = -3;
            if (v2 == v3) {
                goto IL_0010;
            } else {
                goto IL_000C;
            }
            IL_000C: ;
            int v4 = l0;
            int v5 = 1;
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_001A;
            } else {
                goto IL_0010;
            }
            IL_0010: ;
            try {
                IL_0011: ;
                goto IL_001A;
            }
            finally {
                IL_0013: ;
                global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v6 = this;
                __cil_direct_060024B8(v6);
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_001A: ;
            return;
        }

        private virtual bool MoveNext()
        {
            // IL fallback: EH fault handlers need exceptional-only cleanup
            // .maxstack 2
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, 95, 0C, 00, 04, 0B, 02, 7B, 98, 0C, 00, 04, 0C, 07, 45, 03, 00, 00, 00, 07, 00, 00, 00]
            // .code-bytes IL_0018: [AB, 00, 00, 00, CD, 00, 00, 00, 16, 0A, DD, D8, 00, 00, 00, 02, 15, 7D, 95, 0C, 00, 04, 02, 73]
            // .code-bytes IL_0030: [3E, 0C, 00, 0A, 7D, 99, 0C, 00, 04, 02, 08, 73, AF, 24, 00, 06, 7D, 9A, 0C, 00, 04, 02, 1F, FD]
            // .code-bytes IL_0048: [7D, 95, 0C, 00, 04, 2B, 29, 02, 7C, 9A, 0C, 00, 04, 28, B0, 24, 00, 06, 0D, 02, 7B, 99, 0C, 00]
            // .code-bytes IL_0060: [04, 02, 7B, 9A, 0C, 00, 04, 6F, 3F, 0C, 00, 0A, 02, 09, 73, AF, 24, 00, 06, 7D, 9A, 0C, 00, 04]
            // .code-bytes IL_0078: [02, 7C, 9A, 0C, 00, 04, 28, B1, 24, 00, 06, 2D, CA, 02, 7C, 9A, 0C, 00, 04, 28, B2, 24, 00, 06]
            // .code-bytes IL_0090: [02, 7B, 99, 0C, 00, 04, 6F, 40, 0C, 00, 0A, 16, 31, 37, 02, 02, 7B, 99, 0C, 00, 04, 6F, 41, 0C]
            // .code-bytes IL_00A8: [00, 0A, 7D, 9A, 0C, 00, 04, 02, 02, 7C, 9A, 0C, 00, 04, 28, B0, 24, 00, 06, 7D, 96, 0C, 00, 04]
            // .code-bytes IL_00C0: [02, 17, 7D, 95, 0C, 00, 04, 17, 0A, DE, 34, 02, 1F, FD, 7D, 95, 0C, 00, 04, 2B, A3, 02, 28, B8]
            // .code-bytes IL_00D8: [24, 00, 06, 02, 08, 7D, 96, 0C, 00, 04, 02, 18, 7D, 95, 0C, 00, 04, 17, 0A, DE, 12, 02, 15, 7D]
            // .code-bytes IL_00F0: [95, 0C, 00, 04, 16, 0A, DE, 07, 02, 28, B6, 24, 00, 06, DC, 06, 2A]
            // .local [0] bool
            // .local [1] int32
            // .local [2] class ICSharpCode.Decompiler.IL.ILInstruction
            // .local [3] class ICSharpCode.Decompiler.IL.ILInstruction
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04000C95 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>1__state
            // IL_0006: stloc.1 1
            // IL_0007: ldarg.0 0
            // IL_0008: ldfld 0x04000C98 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>4__this
            // IL_000D: stloc.2 2
            // IL_000E: ldloc.1 1
            // IL_000F: switch IL_0027, IL_00CB, IL_00ED
            // IL_0020: ldc.i4.0 0
            // IL_0021: stloc.0 0
            // IL_0022: leave IL_00FF
            // IL_0027: ldarg.0 0
            // IL_0028: ldc.i4.m1 -1
            // IL_0029: stfld 0x04000C95 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>1__state
            // IL_002E: ldarg.0 0
            // IL_002F: newobj 0x0A000C3E class [System]System.Collections.Generic.Stack`1<valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator>::.ctor
            // IL_0034: stfld 0x04000C99 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<stack>5__1
            // IL_0039: ldarg.0 0
            // IL_003A: ldloc.2 2
            // IL_003B: newobj 0x060024AF ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator::.ctor
            // IL_0040: stfld 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_0045: ldarg.0 0
            // IL_0046: ldc.i4.s -3
            // IL_0048: stfld 0x04000C95 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>1__state
            // IL_004D: br.s IL_0078
            // IL_004F: ldarg.0 0
            // IL_0050: ldflda 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_0055: call 0x060024B0 ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator::get_Current
            // IL_005A: stloc.3 3
            // IL_005B: ldarg.0 0
            // IL_005C: ldfld 0x04000C99 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<stack>5__1
            // IL_0061: ldarg.0 0
            // IL_0062: ldfld 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_0067: callvirt 0x0A000C3F class [System]System.Collections.Generic.Stack`1<valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator>::Push
            // IL_006C: ldarg.0 0
            // IL_006D: ldloc.3 3
            // IL_006E: newobj 0x060024AF ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator::.ctor
            // IL_0073: stfld 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_0078: ldarg.0 0
            // IL_0079: ldflda 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_007E: call 0x060024B1 ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator::MoveNext
            // IL_0083: brtrue.s IL_004F
            // IL_0085: ldarg.0 0
            // IL_0086: ldflda 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_008B: call 0x060024B2 ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator::Dispose
            // IL_0090: ldarg.0 0
            // IL_0091: ldfld 0x04000C99 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<stack>5__1
            // IL_0096: callvirt 0x0A000C40 class [System]System.Collections.Generic.Stack`1<valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator>::get_Count
            // IL_009B: ldc.i4.0 0
            // IL_009C: ble.s IL_00D5
            // IL_009E: ldarg.0 0
            // IL_009F: ldarg.0 0
            // IL_00A0: ldfld 0x04000C99 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<stack>5__1
            // IL_00A5: callvirt 0x0A000C41 class [System]System.Collections.Generic.Stack`1<valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator>::Pop
            // IL_00AA: stfld 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_00AF: ldarg.0 0
            // IL_00B0: ldarg.0 0
            // IL_00B1: ldflda 0x04000C9A ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<enumerator>5__2
            // IL_00B6: call 0x060024B0 ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator::get_Current
            // IL_00BB: stfld 0x04000C96 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>2__current
            // IL_00C0: ldarg.0 0
            // IL_00C1: ldc.i4.1 1
            // IL_00C2: stfld 0x04000C95 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>1__state
            // IL_00C7: ldc.i4.1 1
            // IL_00C8: stloc.0 0
            // IL_00C9: leave.s IL_00FF
            // IL_00CB: ldarg.0 0
            // IL_00CC: ldc.i4.s -3
            // IL_00CE: stfld 0x04000C95 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>1__state
            // IL_00D3: br.s IL_0078
            // IL_00D5: ldarg.0 0
            // IL_00D6: call 0x060024B8 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>m__Finally1
            // IL_00DB: ldarg.0 0
            // IL_00DC: ldloc.2 2
            // IL_00DD: stfld 0x04000C96 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>2__current
            // IL_00E2: ldarg.0 0
            // IL_00E3: ldc.i4.2 2
            // IL_00E4: stfld 0x04000C95 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>1__state
            // IL_00E9: ldc.i4.1 1
            // IL_00EA: stloc.0 0
            // IL_00EB: leave.s IL_00FF
            // IL_00ED: ldarg.0 0
            // IL_00EE: ldc.i4.m1 -1
            // IL_00EF: stfld 0x04000C95 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::<>1__state
            // IL_00F4: ldc.i4.0 0
            // IL_00F5: stloc.0 0
            // IL_00F6: leave.s IL_00FF
            // IL_00F8: ldarg.0 0
            // IL_00F9: call 0x060024B6 ICSharpCode.Decompiler.IL.ILInstruction/<get_Descendants>d__89::System.IDisposable.Dispose
            // IL_00FE: endfinally 
            // IL_00FF: ldloc.0 0
            // IL_0100: ret 
            // .eh-raw ExceptionHandler { kind: Fault, try_offset: 0, try_length: 248, handler_offset: 248, handler_length: 7, raw_flags: 4 }
            // .try IL_0000..IL_00F8 fault IL_00F8..IL_00FF
        }

        private void __name_3C3E6D5F5F46696E616C6C7931()
        {
            // structural signature __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 bytes=118D1C: valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_41d5310377b95d011bb49c6ed4c843a5f56a5426 bytes=151280CD01118D1C: class [System]System.Collections.Generic.Stack`1<valuetype ICSharpCode.Decompiler.IL.ILInstruction/ChildrenEnumerator>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 l0 = default;
            IL_0000: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v0 = this;
            int v1 = -1;
            v0.__il_field_04000C95 = v1;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v2 = this;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v3 = ref v2.__il_field_04000C9A;
            __cil_direct_060024B2(ref v3);
            goto IL_0027;
            IL_0014: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v4 = this;
            __cil_ref_41d5310377b95d011bb49c6ed4c843a5f56a5426 v5 = v4.__il_field_04000C99;
            __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v6 = __cil_callvirt_0A000C41(v5);
            l0 = v6;
            ref __cil_value_c71fdd30ab997760d3e4dae75a1b2e0562b6b629 v7 = ref l0;
            __cil_direct_060024B2(ref v7);
            goto IL_0027;
            IL_0027: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v8 = this;
            __cil_ref_41d5310377b95d011bb49c6ed4c843a5f56a5426 v9 = v8.__il_field_04000C99;
            int v10 = __cil_callvirt_0A000C40(v9);
            int v11 = 0;
            if (v10 > v11) {
                goto IL_0014;
            } else {
                goto IL_0035;
            }
            IL_0035: ;
            return;
        }

        private virtual ICSharpCode.Decompiler.IL.ILInstruction __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E6765745F43757272656E74()
        {
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = this.__il_field_04000C96;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A0000ED();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = this.__il_field_04000C96;
            return v1;
        }

        private virtual System.Collections.Generic.IEnumerator<ICSharpCode.Decompiler.IL.ILInstruction> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 bytes=151280850112850C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 l0 = default;
            int v1 = this.__il_field_04000C95;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04000C97;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_04000C95 = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v10 = __cil_newobj_060024B5(0);
            l0 = v10;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v11 = l0;
            global::ICSharpCode.Decompiler.IL.ILInstruction v13 = this.__il_field_04000C98;
            v11.__il_field_04000C98 = v13;
            IL_0035: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F44657363656E64616E74733E645F5F3839 v14 = l0;
            return v14;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 bytes=151280850112850C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 v1 = __cil_direct_060024BC(this);
            return v1;
        }
        // property ICSharpCode.Decompiler.IL.ILInstruction __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }

    private sealed class __name_3C6765745F416E636573746F72733E645F5F3931 : System.Collections.Generic.IEnumerable<ICSharpCode.Decompiler.IL.ILInstruction>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<ICSharpCode.Decompiler.IL.ILInstruction>, System.IDisposable, System.Collections.IEnumerator
    {
        private int __il_field_04000C9B;
        private ICSharpCode.Decompiler.IL.ILInstruction __il_field_04000C9C;
        private int __il_field_04000C9D;
        public ICSharpCode.Decompiler.IL.ILInstruction __il_field_04000C9E;
        private ICSharpCode.Decompiler.IL.ILInstruction __il_field_04000C9F;

        public __name_3C6765745F416E636573746F72733E645F5F3931(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_04000C9B = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04000C9D = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            return;
        }

        private virtual bool MoveNext()
        {
            int l0 = default;
            ICSharpCode.Decompiler.IL.ILInstruction l1 = default;
            int v1 = this.__il_field_04000C9B;
            l0 = v1;
            global::ICSharpCode.Decompiler.IL.ILInstruction v3 = this.__il_field_04000C9E;
            l1 = v3;
            int v4 = l0;
            if (v4 == 0) {
                goto IL_0017;
            } else {
                goto IL_0011;
            }
            IL_0011: ;
            int v5 = l0;
            if (v5 == 1) {
                goto IL_003C;
            } else {
                return false;
            }
            IL_0017: ;
            this.__il_field_04000C9B = -1;
            global::ICSharpCode.Decompiler.IL.ILInstruction v11 = l1;
            this.__il_field_04000C9F = v11;
            goto IL_0054;
            IL_0027: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction v14 = this.__il_field_04000C9F;
            this.__il_field_04000C9C = v14;
            this.__il_field_04000C9B = 1;
            return true;
            IL_003C: ;
            this.__il_field_04000C9B = -1;
            global::ICSharpCode.Decompiler.IL.ILInstruction v22 = this.__il_field_04000C9F;
            global::ICSharpCode.Decompiler.IL.ILInstruction v23 = __cil_callvirt_06000E8F(v22);
            this.__il_field_04000C9F = v23;
            IL_0054: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction v25 = this.__il_field_04000C9F;
            if (v25 is not null) {
                goto IL_0027;
            } else {
                goto IL_005C;
            }
            IL_005C: ;
            this.__il_field_04000C9F = null;
            return false;
        }

        private virtual ICSharpCode.Decompiler.IL.ILInstruction __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E6765745F43757272656E74()
        {
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = this.__il_field_04000C9C;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A0000ED();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            global::ICSharpCode.Decompiler.IL.ILInstruction v1 = this.__il_field_04000C9C;
            return v1;
        }

        private virtual System.Collections.Generic.IEnumerator<ICSharpCode.Decompiler.IL.ILInstruction> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 bytes=151280850112850C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F416E636573746F72733E645F5F3931 l0 = default;
            int v1 = this.__il_field_04000C9B;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04000C9D;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_04000C9B = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F416E636573746F72733E645F5F3931 v10 = __cil_newobj_060024BE(0);
            l0 = v10;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F416E636573746F72733E645F5F3931 v11 = l0;
            global::ICSharpCode.Decompiler.IL.ILInstruction v13 = this.__il_field_04000C9E;
            v11.__il_field_04000C9E = v13;
            IL_0035: ;
            global::ICSharpCode.Decompiler.IL.ILInstruction.__name_3C6765745F416E636573746F72733E645F5F3931 v14 = l0;
            return v14;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 bytes=151280850112850C: class [mscorlib]System.Collections.Generic.IEnumerator`1<class ICSharpCode.Decompiler.IL.ILInstruction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_16c2605e53ab5d1a61aac8342d9743852fa306c8 v1 = __cil_direct_060024C4(this);
            return v1;
        }
        // property ICSharpCode.Decompiler.IL.ILInstruction __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C49435368617270436F64652E4465636F6D70696C65722E494C2E494C496E737472756374696F6E3E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }
}
