namespace OpenRA.Mods.Common.Traits;

public class Aircraft : OpenRA.Mods.Common.Traits.PausableConditionalTrait<OpenRA.Mods.Common.Traits.AircraftInfo>, OpenRA.Traits.ITick, OpenRA.ISync, OpenRA.Traits.IFacing, OpenRA.Mods.Common.Traits.IPositionable, OpenRA.Traits.IOccupySpace, OpenRA.Mods.Common.Traits.IMove, OpenRA.Traits.INotifyAddedToWorld, OpenRA.Traits.INotifyRemovedFromWorld, OpenRA.Traits.INotifyActorDisposing, OpenRA.Traits.INotifyBecomingIdle, OpenRA.Traits.ICreationActivity, OpenRA.Mods.Common.Traits.IActorPreviewInitModifier, OpenRA.Mods.Common.Traits.IDeathActorInitModifier, OpenRA.Mods.Common.Traits.IIssueDeployOrder, OpenRA.Traits.IIssueOrder, OpenRA.Traits.IResolveOrder, OpenRA.Traits.IOrderVoice
{
    private readonly OpenRA.Actor self;
    private OpenRA.Mods.Common.Traits.Repairable repairable;
    private OpenRA.Mods.Common.Traits.Rearmable rearmable;
    private OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset[] positionOffsets;
    private System.IDisposable reservation;
    private System.Collections.Generic.IEnumerable<int> speedModifiers;
    private OpenRA.Mods.Common.Traits.INotifyMoving[] notifyMoving;
    private OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged[] notifyCenterPositionChanged;
    private OpenRA.Mods.Common.Traits.IOverrideAircraftLanding overrideAircraftLanding;
    private OpenRA.WRot __il_field_04000CE2;
    private OpenRA.WPos __il_field_04000CE3;
    private OpenRA.Actor __il_field_04000CE4;
    private bool __il_field_04000CE5;
    private bool __il_field_04000CE6;
    private System.ValueTuple<OpenRA.CPos, OpenRA.Traits.SubCell>[] landingCells;
    public bool RequireForceMove;
    private readonly int creationActivityDelay;
    private readonly bool creationByMap;
    private readonly OpenRA.CPos[] creationRallyPoint;
    private bool notify;
    private bool airborne;
    private bool cruising;
    private int airborneToken;
    private int cruisingToken;
    private OpenRA.Mods.Common.Traits.MovementType movementTypes;
    private OpenRA.WPos cachedPosition;
    private OpenRA.WAngle cachedFacing;

    public virtual OpenRA.WAngle get_Facing()
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06000F2C kept: direct virtual this accessor needs exact call notation.
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v1 = __cil_direct_06000F2C(this);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v2 = v1.Yaw;
        return v2;
    }

    public virtual void set_Facing(OpenRA.WAngle value)
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v1 = this;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v2 = __cil_direct_06000F2C(v1);
        l0 = v2;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v3 = ref l0;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v4 = value;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v5 = __cil_memberref_call_0A00110C(ref v3, v4);
        __cil_direct_06000F2D(v0, v5);
        return;
    }

    public OpenRA.WAngle get_Pitch()
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06000F2C kept: direct virtual this accessor needs exact call notation.
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v1 = __cil_direct_06000F2C(this);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v2 = v1.Pitch;
        return v2;
    }

    public void set_Pitch(OpenRA.WAngle value)
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v1 = this;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v2 = __cil_direct_06000F2C(v1);
        l0 = v2;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v3 = ref l0;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v4 = value;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v5 = __cil_memberref_call_0A00110E(ref v3, v4);
        __cil_direct_06000F2D(v0, v5);
        return;
    }

    public OpenRA.WAngle get_Roll()
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06000F2C kept: direct virtual this accessor needs exact call notation.
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v1 = __cil_direct_06000F2C(this);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v2 = v1.Roll;
        return v2;
    }

    public void set_Roll(OpenRA.WAngle value)
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v1 = this;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v2 = __cil_direct_06000F2C(v1);
        l0 = v2;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v3 = ref l0;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v4 = value;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v5 = __cil_memberref_call_0A001110(ref v3, v4);
        __cil_direct_06000F2D(v0, v5);
        return;
    }

    public virtual OpenRA.WRot get_Orientation()
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v1 = this.__il_field_04000CE2;
        return v1;
    }

    private void set_Orientation(OpenRA.WRot value)
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_04000CE2 = value;
        return;
    }

    public virtual OpenRA.WPos get_CenterPosition()
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v1 = this.__il_field_04000CE3;
        return v1;
    }

    private void set_CenterPosition(OpenRA.WPos value)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_04000CE3 = value;
        return;
    }

    public virtual OpenRA.CPos get_TopLeft()
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_type_01000025 v1 = this.self;
        __cil_type_0100002D v2 = v1.World;
        __cil_type_01000026 v3 = v2.Map;
        // Exact call 0x06000F2E kept: direct virtual this accessor needs exact call notation.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v5 = __cil_direct_06000F2E(this);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v6 = v3.CellContaining(v5);
        return v6;
    }

    public virtual OpenRA.WAngle get_TurnSpeed()
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x0A0010FD kept: property syntax needs a nongeneric class owner.
        int v1 = __cil_bool_load(__cil_direct_0A0010FD(this));
        if (v1 != 0) {
            goto IL_001C;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        // Exact call 0x0A0010FE kept: property syntax needs a nongeneric class owner.
        int v3 = __cil_bool_load(__cil_direct_0A0010FE(this));
        if (v3 != 0) {
            goto IL_001C;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v5 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v6 = v5.TurnSpeed;
        return v6;
        IL_001C: ;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v7 = __cil_ldsfld_0A0002D5();
        return v7;
    }

    public System.Nullable<OpenRA.WAngle> get_IdleTurnSpeed()
    {
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        int v1 = __cil_bool_load(__cil_direct_0A0010FD(v0));
        if (v1 != 0) {
            goto IL_001C;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v2 = this;
        int v3 = __cil_bool_load(__cil_direct_0A0010FE(v2));
        if (v3 != 0) {
            goto IL_001C;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v4 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v5 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v4).Info;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v6 = v5.IdleTurnSpeed;
        return v6;
        IL_001C: ;
        ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v7 = ref l0;
        v7 = default;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v8 = l0;
        return v8;
    }

    public OpenRA.WAngle GetTurnSpeed(bool isIdleTurn)
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae l0 = default;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 l1 = default;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae s9_0 = default;
        IL_0000: ;
        int v0 = __cil_bool_load(isIdleTurn);
        if (v0 == 0) {
            goto IL_000B;
        } else {
            goto IL_0003;
        }
        IL_0003: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v1 = this;
        int v2 = __cil_direct_06000F53(v1);
        if (v2 == 0) {
            goto IL_0013;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v3 = this;
        int v4 = __cil_direct_06000F52(v3);
        if (v4 != 0) {
            goto IL_0019;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v5 = __cil_ldsfld_0A0002D5();
        return v5;
        IL_0019: ;
        int v6 = __cil_bool_load(isIdleTurn);
        if (v6 != 0) {
            goto IL_0024;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v7 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v8 = __cil_direct_06000F31(v7);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae e5_9_0 = v8;
        s9_0 = e5_9_0;
        goto IL_0043;
        IL_0024: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v9 = this;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v10 = __cil_direct_06000F32(v9);
        l1 = v10;
        ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v11 = ref l1;
        int v12 = __cil_bool_load(__cil_value_call_0A001111(ref v11));
        if (v12 != 0) {
            goto IL_003C;
        } else {
            goto IL_0034;
        }
        IL_0034: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v13 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v14 = __cil_direct_06000F31(v13);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae e7_9_0 = v14;
        s9_0 = e7_9_0;
        goto IL_0043;
        IL_003C: ;
        ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v15 = ref l1;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v16 = __cil_value_call_0A001112(ref v15);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae e8_9_0 = v16;
        s9_0 = e8_9_0;
        goto IL_0043;
        IL_0043: ;
        l0 = s9_0;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v17 = l0;
        int v18 = v17.Angle;
        global::OpenRA.Mods.Common.Traits.Aircraft v19 = this;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v20 = v19.speedModifiers;
        int v21 = OpenRA.Mods.Common.Util.ApplyPercentageModifiers(v18, v20);
        int v22 = 1;
        int v23 = 1024;
        int v24 = __cil_methodspec_call_2B0000FC(v21, v22, v23);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v25 = __cil_newobj_0A000219(v24);
        return v25;
    }

    public OpenRA.Actor get_ReservedActor()
    {
        __cil_type_01000025 v1 = this.__il_field_04000CE4;
        return v1;
    }

    private void set_ReservedActor(OpenRA.Actor value)
    {
        this.__il_field_04000CE4 = value;
        return;
    }

    public bool get_MayYieldReservation()
    {
        return this.__il_field_04000CE5;
    }

    private void set_MayYieldReservation(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000CE5 = __cil_bool_store(v1);
        return;
    }

    public bool get_ForceLanding()
    {
        return this.__il_field_04000CE6;
    }

    private void set_ForceLanding(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04000CE6 = __cil_bool_store(v1);
        return;
    }

    public static OpenRA.WPos GroundPosition(OpenRA.Actor self)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l0 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l1 = default;
        IL_0000: ;
        __cil_type_01000025 v0 = self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v1 = ((OpenRA.Actor)v0).CenterPosition;
        l0 = v1;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v2 = ref l0;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v3 = __cil_ldsfld_0A00023E();
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v4 = __cil_ldsfld_0A00023E();
        __cil_type_01000025 v5 = self;
        __cil_type_0100002D v6 = v5.World;
        __cil_type_01000026 v7 = v6.Map;
        __cil_type_01000025 v8 = self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v9 = ((OpenRA.Actor)v8).CenterPosition;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v10 = v7.DistanceAboveTerrain(v9);
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v11 = __cil_newobj_0A000766(v3, v4, v10);
        l1 = v11;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v12 = ref l1;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v13 = OpenRA.WPos.op_Subtraction(ref v2, ref v12);
        return v13;
    }

    public bool get_AtLandAltitude()
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_type_01000025 v1 = this.self;
        __cil_type_0100002D v2 = v1.World;
        __cil_type_01000026 v3 = v2.Map;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v5 = __cil_direct_06000F3E(this);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v6 = v3.DistanceAboveTerrain(v5);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v8 = this.LandAltitude;
        return OpenRA.WDist.op_Equality(v6, v8);
    }

    public Aircraft(OpenRA.ActorInitializer init, OpenRA.Mods.Common.Traits.AircraftInfo info)
    {
        // IL fallback: generic virtual dispatch needs runtime lookup-order modeling
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, 5F, 04, 00, 2B, 7D, E7, 0C, 00, 04, 02, 17, 7D, EC, 0C, 00, 04, 02, 15, 7D, EF, 0C, 00]
        // .code-bytes IL_0018: [04, 02, 15, 7D, F0, 0C, 00, 04, 02, 04, 28, 13, 11, 00, 0A, 02, 03, 7B, 1E, 07, 00, 0A, 7D, D9]
        // .code-bytes IL_0030: [0C, 00, 04, 03, 6F, 60, 04, 00, 2B, 0A, 03, 6F, 61, 04, 00, 2B, 0B, 06, 2D, 03, 07, 2C, 40, 07]
        // .code-bytes IL_0048: [2D, 1D, 02, 7B, D9, 0C, 00, 04, 7B, 59, 01, 00, 0A, 7B, 5A, 01, 00, 0A, 06, 6F, B0, 04, 00, 0A]
        // .code-bytes IL_0060: [6F, 1C, 02, 00, 0A, 2B, 06, 07, 6F, 15, 11, 00, 0A, 0C, 02, 03, 6F, 62, 04, 00, 2B, 7D, EA, 0C]
        // .code-bytes IL_0078: [00, 04, 02, 02, 7B, D9, 0C, 00, 04, 08, 28, 67, 0F, 00, 06, 02, 03, 02, 7B, DB, 06, 00, 0A, 7B]
        // .code-bytes IL_0090: [AF, 0C, 00, 04, 6F, 63, 04, 00, 2B, 28, 27, 0F, 00, 06, 02, 03, 16, 6F, 64, 04, 00, 2B, 7D, E9]
        // .code-bytes IL_00A8: [0C, 00, 04, 02, 03, 6F, 65, 04, 00, 2B, 25, 2D, 04, 26, 14, 2B, 05, 6F, 18, 11, 00, 0A, 7D, EB]
        // .code-bytes IL_00C0: [0C, 00, 04, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.LocationInit
        // .local [1] class OpenRA.Mods.Common.CenterPositionInit
        // .local [2] valuetype [OpenRA.Game]OpenRA.WPos
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x2B00045F [System.Runtime]System.Array::Empty<valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>>
        // IL_0006: stfld 0x04000CE7 OpenRA.Mods.Common.Traits.Aircraft::landingCells
        // IL_000B: ldarg.0 0
        // IL_000C: ldc.i4.1 1
        // IL_000D: stfld 0x04000CEC OpenRA.Mods.Common.Traits.Aircraft::notify
        // IL_0012: ldarg.0 0
        // IL_0013: ldc.i4.m1 -1
        // IL_0014: stfld 0x04000CEF OpenRA.Mods.Common.Traits.Aircraft::airborneToken
        // IL_0019: ldarg.0 0
        // IL_001A: ldc.i4.m1 -1
        // IL_001B: stfld 0x04000CF0 OpenRA.Mods.Common.Traits.Aircraft::cruisingToken
        // IL_0020: ldarg.0 0
        // IL_0021: ldarg.2 2
        // IL_0022: call 0x0A001113 class OpenRA.Mods.Common.Traits.PausableConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::.ctor
        // IL_0027: ldarg.0 0
        // IL_0028: ldarg.1 1
        // IL_0029: ldfld 0x0A00071E [OpenRA.Game]OpenRA.ActorInitializer::Self
        // IL_002E: stfld 0x04000CD9 OpenRA.Mods.Common.Traits.Aircraft::self
        // IL_0033: ldarg.1 1
        // IL_0034: callvirt 0x2B000460 [OpenRA.Game]OpenRA.ActorInitializer::GetOrDefault<class [OpenRA.Game]OpenRA.LocationInit>
        // IL_0039: stloc.0 0
        // IL_003A: ldarg.1 1
        // IL_003B: callvirt 0x2B000461 [OpenRA.Game]OpenRA.ActorInitializer::GetOrDefault<class OpenRA.Mods.Common.CenterPositionInit>
        // IL_0040: stloc.1 1
        // IL_0041: ldloc.0 0
        // IL_0042: brtrue.s IL_0047
        // IL_0044: ldloc.1 1
        // IL_0045: brfalse.s IL_0087
        // IL_0047: ldloc.1 1
        // IL_0048: brtrue.s IL_0067
        // IL_004A: ldarg.0 0
        // IL_004B: ldfld 0x04000CD9 OpenRA.Mods.Common.Traits.Aircraft::self
        // IL_0050: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0055: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_005A: ldloc.0 0
        // IL_005B: callvirt 0x0A0004B0 class [OpenRA.Game]OpenRA.ValueActorInit`1<valuetype [OpenRA.Game]OpenRA.CPos>::get_Value
        // IL_0060: callvirt 0x0A00021C [OpenRA.Game]OpenRA.Map::CenterOfCell
        // IL_0065: br.s IL_006D
        // IL_0067: ldloc.1 1
        // IL_0068: callvirt 0x0A001115 class [OpenRA.Game]OpenRA.ValueActorInit`1<valuetype [OpenRA.Game]OpenRA.WPos>::get_Value
        // IL_006D: stloc.2 2
        // IL_006E: ldarg.0 0
        // IL_006F: ldarg.1 1
        // IL_0070: callvirt 0x2B000462 [OpenRA.Game]OpenRA.ActorInitializer::Contains<class OpenRA.Mods.Common.Traits.SpawnedByMapInit>
        // IL_0075: stfld 0x04000CEA OpenRA.Mods.Common.Traits.Aircraft::creationByMap
        // IL_007A: ldarg.0 0
        // IL_007B: ldarg.0 0
        // IL_007C: ldfld 0x04000CD9 OpenRA.Mods.Common.Traits.Aircraft::self
        // IL_0081: ldloc.2 2
        // IL_0082: call 0x06000F67 OpenRA.Mods.Common.Traits.Aircraft::SetPosition
        // IL_0087: ldarg.0 0
        // IL_0088: ldarg.1 1
        // IL_0089: ldarg.0 0
        // IL_008A: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_008F: ldfld 0x04000CAF OpenRA.Mods.Common.Traits.AircraftInfo::InitialFacing
        // IL_0094: callvirt 0x2B000463 [OpenRA.Game]OpenRA.ActorInitializer::GetValue<class OpenRA.Mods.Common.FacingInit, valuetype [OpenRA.Game]OpenRA.WAngle>
        // IL_0099: call 0x06000F27 OpenRA.Mods.Common.Traits.Aircraft::set_Facing
        // IL_009E: ldarg.0 0
        // IL_009F: ldarg.1 1
        // IL_00A0: ldc.i4.0 0
        // IL_00A1: callvirt 0x2B000464 [OpenRA.Game]OpenRA.ActorInitializer::GetValue<class OpenRA.Mods.Common.CreationActivityDelayInit, int32>
        // IL_00A6: stfld 0x04000CE9 OpenRA.Mods.Common.Traits.Aircraft::creationActivityDelay
        // IL_00AB: ldarg.0 0
        // IL_00AC: ldarg.1 1
        // IL_00AD: callvirt 0x2B000465 [OpenRA.Game]OpenRA.ActorInitializer::GetOrDefault<class OpenRA.Mods.Common.Traits.RallyPointInit>
        // IL_00B2: dup 
        // IL_00B3: brtrue.s IL_00B9
        // IL_00B5: pop 
        // IL_00B6: ldnull 
        // IL_00B7: br.s IL_00BE
        // IL_00B9: callvirt 0x0A001118 class [OpenRA.Game]OpenRA.ValueActorInit`1<valuetype [OpenRA.Game]OpenRA.CPos[]>::get_Value
        // IL_00BE: stfld 0x04000CEB OpenRA.Mods.Common.Traits.Aircraft::creationRallyPoint
        // IL_00C3: ret 
    }

    public OpenRA.WDist get_LandAltitude()
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 bytes=1D1299F4: class OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d l0 = default;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 l1 = default;
        int l2 = default;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v1 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v2 = v1.LandAltitude;
        l0 = v2;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 v4 = this.positionOffsets;
        l1 = v4;
        l2 = 0;
        goto IL_0036;
        IL_0017: ;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 v6 = l1;
        int v7 = l2;
        global::OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset v8 = v6[v7];
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v9 = l0;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v11 = __cil_callvirt_06001FC5(v8);
        int v12 = v11.Z;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v13 = __cil_newobj_0A00023F(v12);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v14 = OpenRA.WDist.op_Subtraction(v9, v13);
        l0 = v14;
        int v15 = l2;
        l2 = unchecked(v15 + 1);
        IL_0036: ;
        int v18 = l2;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 v19 = l1;
        nint v20 = unchecked((nint)(v19.LongLength));
        int v21 = unchecked((int)(v20));
        if (v18 < v21) {
            goto IL_0017;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v22 = l0;
        return v22;
    }

    public OpenRA.WPos GetPosition()
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 bytes=1D1299F4: class OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l0 = default;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 l1 = default;
        int l2 = default;
        OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset l3 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l4 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_type_01000025 v1 = v0.self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v2 = ((OpenRA.Actor)v1).CenterPosition;
        l0 = v2;
        global::OpenRA.Mods.Common.Traits.Aircraft v3 = this;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 v4 = v3.positionOffsets;
        l1 = v4;
        int v5 = 0;
        l2 = v5;
        goto IL_0031;
        IL_0017: ;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 v6 = l1;
        int v7 = l2;
        global::OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset v8 = v6[v7];
        l3 = v8;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v9 = ref l0;
        global::OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset v10 = l3;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v11 = __cil_callvirt_06001FC5(v10);
        l4 = v11;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v12 = ref l4;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v13 = OpenRA.WPos.op_Addition(ref v9, ref v12);
        l0 = v13;
        int v14 = l2;
        int v15 = 1;
        int v16 = unchecked(v14 + v15);
        l2 = v16;
        goto IL_0031;
        IL_0031: ;
        int v17 = l2;
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 v18 = l1;
        nint v19 = unchecked((nint)(v18.LongLength));
        int v20 = unchecked((int)(v19));
        if (v17 < v20) {
            goto IL_0017;
        } else {
            goto IL_0037;
        }
        IL_0037: ;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v21 = l0;
        return v21;
    }

    public override System.Collections.Generic.IEnumerable<OpenRA.Traits.VariableObserver> GetVariableObservers()
    {
        // structural signature __cil_ref_01e870d823b7fa5ebe8ad38c5e4fee9884ac243a bytes=151280A1011187C5: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v1 = __cil_newobj_0600399D(-2);
        v1.__il_field_04002FE2 = this;
        return v1;
    }

    private void RequireForceMoveConditionChanged(OpenRA.Actor self, System.Collections.Generic.IReadOnlyDictionary<string, int> conditions)
    {
        // structural signature __cil_ref_beeddf9dea012b3eb1ea23704adc8273e644e143 bytes=1512833D020E08: class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.AircraftInfo v2 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        __cil_type_010001EB v3 = v2.RequireForceMoveCondition;
        int v5 = __cil_bool_load(v3.Evaluate(conditions));
        this.RequireForceMove = __cil_bool_store(v5);
        return;
    }

    protected override void Created(OpenRA.Actor self)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 bytes=1D1299F4: class OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_723ccaa1cf5b61a0b7e2292717be84d90587b5a0 bytes=151280A1011299A0: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ISpeedModifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 bytes=1D1299A0: class OpenRA.Mods.Common.Traits.ISpeedModifier[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 bytes=15128121021299A008: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ISpeedModifier, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5f8b144b2c75c3ef443c9c3fbffdbce636e41778 bytes=151280A101129A5C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyMoving>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec bytes=1D129A5C: class OpenRA.Mods.Common.Traits.INotifyMoving[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_937345d07fe10b56277feb245ea2325b42e79be4 bytes=151280A1011299F4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.IAircraftCenterPositionOffset>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9986e596bb81344ef676a122c3804e4a93fd3b50 bytes=151280A101129874: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d bytes=1D129874: class OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.Aircraft s1_0 = default;
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 s1_1 = default;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 s1_2 = default;
        OpenRA.Mods.Common.Traits.Aircraft s2_0 = default;
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 s2_1 = default;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 s2_2 = default;
        global::OpenRA.Mods.Common.Traits.Repairable v2 = __cil_callvirt_2B000466(self);
        this.repairable = v2;
        global::OpenRA.Mods.Common.Traits.Rearmable v5 = __cil_callvirt_2B000467(self);
        this.rearmable = v5;
        __cil_ref_723ccaa1cf5b61a0b7e2292717be84d90587b5a0 v8 = __cil_callvirt_2B000468(self);
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 v9 = __cil_methodspec_call_2B000469(v8);
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 v10 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD0;
        if (v10 is not null) {
            OpenRA.Mods.Common.Traits.Aircraft e0_2_0 = this;
            __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 e0_2_1 = v9;
            __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 e0_2_2 = v10;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            s2_2 = e0_2_2;
            goto IL_0043;
        } else {
            OpenRA.Mods.Common.Traits.Aircraft e0_1_0 = this;
            __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 e0_1_1 = v9;
            __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 e0_1_2 = v10;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            s1_2 = e0_1_2;
            goto IL_002C;
        }
        IL_002C: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v11 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF;
        nint v12 = __cil_ldftn_0600398D;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 v13 = __cil_newobj_0A00111B(v11, v12);
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD0 = v13;
        OpenRA.Mods.Common.Traits.Aircraft e1_2_0 = s1_0;
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 e1_2_1 = s1_1;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 e1_2_2 = v13;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        s2_2 = e1_2_2;
        IL_0043: ;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v14 = __cil_methodspec_call_2B00046A(((__cil_ref_723ccaa1cf5b61a0b7e2292717be84d90587b5a0)(s2_1)), s2_2);
        s2_0.speedModifiers = v14;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v17 = ((OpenRA.Actor)self).CenterPosition;
        this.cachedPosition = v17;
        __cil_ref_5f8b144b2c75c3ef443c9c3fbffdbce636e41778 v20 = __cil_callvirt_2B00046B(self);
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v21 = __cil_methodspec_call_2B00046C(v20);
        this.notifyMoving = v21;
        __cil_ref_937345d07fe10b56277feb245ea2325b42e79be4 v24 = __cil_callvirt_2B00046D(self);
        __cil_ref_69c324e0d6b7011367d4b5a63359604d48b06dd2 v25 = __cil_methodspec_call_2B00046E(v24);
        this.positionOffsets = v25;
        global::OpenRA.Mods.Common.Traits.IOverrideAircraftLanding v28 = __cil_callvirt_2B00046F(self);
        this.overrideAircraftLanding = v28;
        __cil_ref_9986e596bb81344ef676a122c3804e4a93fd3b50 v31 = __cil_callvirt_2B000470(self);
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v32 = __cil_methodspec_call_2B000471(v31);
        this.notifyCenterPositionChanged = v32;
        __cil_direct_0A00111C(this, self);
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F746966794164646564546F576F726C642E4164646564546F576F726C64(OpenRA.Actor self)
    {
        __cil_callvirt_06000F43(this, self);
        return;
    }

    protected virtual void AddedToWorld(OpenRA.Actor self)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d l0 = default;
        __cil_type_0100002D v1 = self.World;
        v1.AddToMaps(self, ((__cil_type_010001EE)(this)));
        __cil_type_0100002D v5 = self.World;
        __cil_type_01000026 v6 = v5.Map;
        // Exact call 0x06000F2E kept: direct virtual this accessor needs exact call notation.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v8 = __cil_direct_06000F2E(this);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v9 = v6.DistanceAboveTerrain(v8);
        l0 = v9;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v10 = l0;
        int v11 = v10.Length;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v13 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v14 = v13.MinAirborneAltitude;
        if (v11 < v14) {
            goto IL_003D;
        } else {
            goto IL_0037;
        }
        IL_0037: ;
        __cil_direct_06000F83(this);
        IL_003D: ;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v16 = l0;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v18 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v19 = v18.CruiseAltitude;
        int v20 = __cil_bool_load(OpenRA.WDist.op_Equality(v16, v19));
        if (v20 == 0) {
            goto IL_0056;
        } else {
            goto IL_0050;
        }
        IL_0050: ;
        __cil_direct_06000F85(this);
        IL_0056: ;
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F7469667952656D6F76656446726F6D576F726C642E52656D6F76656446726F6D576F726C64(OpenRA.Actor self)
    {
        __cil_callvirt_06000F45(this, self);
        return;
    }

    protected virtual void RemovedFromWorld(OpenRA.Actor self)
    {
        __cil_direct_06000F4E(this);
        __cil_type_0100002D v2 = self.World;
        v2.RemoveFromMaps(self, ((__cil_type_010001EE)(this)));
        __cil_direct_06000F86(this);
        __cil_direct_06000F84(this);
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E495469636B2E5469636B(OpenRA.Actor self)
    {
        __cil_callvirt_06000F47(this, self);
        return;
    }

    protected virtual void Tick(OpenRA.Actor self)
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // enum storage token=0x020002AE alias=__cil_enum_020002AE underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@IdleBehaviorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x02000695 alias=__cil_enum_02000695 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MovementType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae l0 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l1 = default;
        __cil_enum_02000695 l2 = default;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 l3 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l4 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l5 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        int v1 = __cil_bool_load(__cil_direct_06000F38(v0));
        if (v1 != 0) {
            goto IL_0069;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v2 = this;
        int v3 = __cil_bool_load(__cil_direct_0A0010FE(v2));
        if (v3 == 0) {
            goto IL_0069;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v4 = this;
        int v5 = __cil_bool_load(v4.airborne);
        if (v5 == 0) {
            goto IL_0069;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v6 = this;
        __cil_type_01000025 v7 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v8 = ((OpenRA.Actor)v7).Location;
        int v9 = 1;
        int v10 = __cil_bool_load(__cil_direct_06000F59(v6, v8, ((__cil_type_01000025)(null)), __cil_bool_store(v9)));
        if (v10 == 0) {
            goto IL_0069;
        } else {
            goto IL_0028;
        }
        IL_0028: ;
        __cil_type_01000025 v11 = self;
        __cil_type_0100010F v12 = ((OpenRA.Actor)v11).CurrentActivity;
        global::OpenRA.Mods.Common.Activities.Land v13 = ((object)v12 as OpenRA.Mods.Common.Activities.Land);
        if (v13 is not null) {
            goto IL_0069;
        } else {
            goto IL_0035;
        }
        IL_0035: ;
        __cil_type_01000025 v14 = self;
        __cil_type_0100010F v15 = ((OpenRA.Actor)v14).CurrentActivity;
        global::OpenRA.Mods.Common.Activities.Turn v16 = ((object)v15 as OpenRA.Mods.Common.Activities.Turn);
        if (v16 is not null) {
            goto IL_0069;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        __cil_type_01000025 v17 = self;
        int v18 = 0;
        __cil_type_01000025 v19 = self;
        ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v20 = ref l3;
        v20 = default;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v21 = l3;
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v22 = ref l4;
        v22 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v23 = l4;
        global::OpenRA.Mods.Common.Activities.Land v24 = __cil_newobj_06002342(v19, v21, v23);
        v17.QueueActivity(__cil_bool_store(v18), ((__cil_type_0100010F)(v24)));
        global::OpenRA.Mods.Common.Traits.Aircraft v25 = this;
        int v26 = 1;
        __cil_direct_06000F39(v25, __cil_bool_store(v26));
        goto IL_0069;
        IL_0069: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v27 = this;
        int v28 = __cil_bool_load(__cil_direct_06000F38(v27));
        if (v28 == 0) {
            goto IL_00B0;
        } else {
            goto IL_0071;
        }
        IL_0071: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v29 = this;
        int v30 = __cil_bool_load(__cil_direct_0A0010FE(v29));
        if (v30 != 0) {
            goto IL_00B0;
        } else {
            goto IL_0079;
        }
        IL_0079: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v31 = this;
        int v32 = __cil_bool_load(v31.cruising);
        if (v32 != 0) {
            goto IL_00B0;
        } else {
            goto IL_0081;
        }
        IL_0081: ;
        __cil_type_01000025 v33 = self;
        __cil_type_0100010F v34 = ((OpenRA.Actor)v33).CurrentActivity;
        global::OpenRA.Mods.Common.Activities.TakeOff v35 = ((object)v34 as OpenRA.Mods.Common.Activities.TakeOff);
        if (v35 is not null) {
            goto IL_00B0;
        } else {
            goto IL_008E;
        }
        IL_008E: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v36 = this;
        int v37 = 0;
        __cil_direct_06000F39(v36, __cil_bool_store(v37));
        global::OpenRA.Mods.Common.Traits.Aircraft v38 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v39 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v38).Info;
        int v40 = unchecked((int)(v39.IdleBehavior));
        int v41 = 1;
        if (v40 == v41) {
            goto IL_00B0;
        } else {
            goto IL_00A3;
        }
        IL_00A3: ;
        __cil_type_01000025 v42 = self;
        int v43 = 0;
        __cil_type_01000025 v44 = self;
        global::OpenRA.Mods.Common.Activities.TakeOff v45 = __cil_newobj_0600234F(v44);
        v42.QueueActivity(__cil_bool_store(v43), ((__cil_type_0100010F)(v45)));
        goto IL_00B0;
        IL_00B0: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v46 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v47 = v46.cachedFacing;
        l0 = v47;
        global::OpenRA.Mods.Common.Traits.Aircraft v48 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v49 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v50 = __cil_direct_06000F26(v49);
        v48.cachedFacing = v50;
        global::OpenRA.Mods.Common.Traits.Aircraft v51 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v52 = v51.cachedPosition;
        l1 = v52;
        global::OpenRA.Mods.Common.Traits.Aircraft v53 = this;
        __cil_type_01000025 v54 = self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v55 = ((OpenRA.Actor)v54).CenterPosition;
        v53.cachedPosition = v55;
        int v56 = 0;
        l2 = unchecked((__cil_enum_02000695)(v56));
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v57 = l0;
        global::OpenRA.Mods.Common.Traits.Aircraft v58 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v59 = __cil_direct_06000F26(v58);
        int v60 = __cil_bool_load(OpenRA.WAngle.op_Inequality(v57, v59));
        if (v60 == 0) {
            goto IL_00EA;
        } else {
            goto IL_00E6;
        }
        IL_00E6: ;
        int v61 = unchecked((int)(l2));
        int v62 = 4;
        int v63 = unchecked(v61 | v62);
        l2 = unchecked((__cil_enum_02000695)(v63));
        goto IL_00EA;
        IL_00EA: ;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v64 = ref l1;
        global::OpenRA.Mods.Common.Traits.Aircraft v65 = this;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v66 = ref v65.cachedPosition;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v67 = OpenRA.WPos.op_Subtraction(ref v64, ref v66);
        l5 = v67;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v68 = ref l5;
        long v69 = __cil_memberref_call_0A00027C(ref v68);
        if (v69 == 0) {
            goto IL_0106;
        } else {
            goto IL_0102;
        }
        IL_0102: ;
        int v70 = unchecked((int)(l2));
        int v71 = 1;
        int v72 = unchecked(v70 | v71);
        l2 = unchecked((__cil_enum_02000695)(v72));
        goto IL_0106;
        IL_0106: ;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v73 = ref l1;
        global::OpenRA.Mods.Common.Traits.Aircraft v74 = this;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v75 = ref v74.cachedPosition;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v76 = OpenRA.WPos.op_Subtraction(ref v73, ref v75);
        l5 = v76;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v77 = ref l5;
        long v78 = __cil_memberref_call_0A001121(ref v77);
        if (v78 == 0) {
            goto IL_0122;
        } else {
            goto IL_011E;
        }
        IL_011E: ;
        int v79 = unchecked((int)(l2));
        int v80 = 2;
        int v81 = unchecked(v79 | v80);
        l2 = unchecked((__cil_enum_02000695)(v81));
        goto IL_0122;
        IL_0122: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v82 = this;
        int v83 = unchecked((int)(l2));
        __cil_direct_06000F7B(v82, unchecked((__cil_enum_02000695)(v83)));
        global::OpenRA.Mods.Common.Traits.Aircraft v84 = this;
        int v85 = unchecked((int)(__cil_direct_06000F7A(v84)));
        int v86 = 1;
        int v87 = __cil_bool_load(OpenRA.Mods.Common.Traits.LocomoterExts.HasMovementType(unchecked((__cil_enum_02000695)(v85)), unchecked((__cil_enum_02000695)(v86))));
        if (v87 != 0) {
            goto IL_01CE;
        } else {
            goto IL_013A;
        }
        IL_013A: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v88 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v89 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v88).Info;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v90 = v89.Roll;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v91 = __cil_ldsfld_0A0002D5();
        int v92 = __cil_bool_load(OpenRA.WAngle.op_Inequality(v90, v91));
        if (v92 == 0) {
            goto IL_0184;
        } else {
            goto IL_0151;
        }
        IL_0151: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v93 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v94 = __cil_direct_06000F2A(v93);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v95 = __cil_ldsfld_0A0002D5();
        int v96 = __cil_bool_load(OpenRA.WAngle.op_Inequality(v94, v95));
        if (v96 == 0) {
            goto IL_0184;
        } else {
            goto IL_0163;
        }
        IL_0163: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v97 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v98 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v99 = __cil_direct_06000F2A(v98);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v100 = __cil_ldsfld_0A0002D5();
        global::OpenRA.Mods.Common.Traits.Aircraft v101 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v102 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v101).Info;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v103 = v102.RollSpeed;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v104 = OpenRA.Mods.Common.Util.TickFacing(v99, v100, v103);
        __cil_direct_06000F2B(v97, v104);
        goto IL_0184;
        IL_0184: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v105 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v106 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v105).Info;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v107 = v106.Pitch;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v108 = __cil_ldsfld_0A0002D5();
        int v109 = __cil_bool_load(OpenRA.WAngle.op_Inequality(v107, v108));
        if (v109 == 0) {
            goto IL_01CE;
        } else {
            goto IL_019B;
        }
        IL_019B: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v110 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v111 = __cil_direct_06000F28(v110);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v112 = __cil_ldsfld_0A0002D5();
        int v113 = __cil_bool_load(OpenRA.WAngle.op_Inequality(v111, v112));
        if (v113 == 0) {
            goto IL_01CE;
        } else {
            goto IL_01AD;
        }
        IL_01AD: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v114 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v115 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v116 = __cil_direct_06000F28(v115);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v117 = __cil_ldsfld_0A0002D5();
        global::OpenRA.Mods.Common.Traits.Aircraft v118 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v119 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v118).Info;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v120 = v119.PitchSpeed;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v121 = OpenRA.Mods.Common.Util.TickFacing(v116, v117, v120);
        __cil_direct_06000F29(v114, v121);
        goto IL_01CE;
        IL_01CE: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v122 = this;
        __cil_direct_06000F48(v122);
        return;
    }

    public void Repulse()
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l0 = default;
        int l1 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l2 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l3 = default;
        int s5_0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v1 = __cil_callvirt_06000F49(v0);
        l0 = v1;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v2 = ref l0;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v3 = ref __cil_ldsflda_0A000240();
        int v4 = __cil_bool_load(OpenRA.WVec.op_Equality(ref v2, ref v3));
        if (v4 == 0) {
            goto IL_0016;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        return;
        IL_0016: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v5 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v6 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v5).Info;
        int v7 = v6.RepulsionSpeed;
        int v8 = -1;
        if (unchecked((uint)v7) != unchecked((uint)v8)) {
            goto IL_002C;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v9 = this;
        int v10 = __cil_direct_06000F52(v9);
        int e3_5_0 = v10;
        s5_0 = e3_5_0;
        goto IL_0037;
        IL_002C: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v11 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v12 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v11).Info;
        int v13 = v12.RepulsionSpeed;
        int e4_5_0 = v13;
        s5_0 = e4_5_0;
        goto IL_0037;
        IL_0037: ;
        l1 = s5_0;
        global::OpenRA.Mods.Common.Traits.Aircraft v14 = this;
        int v15 = 0;
        v14.notify = __cil_bool_store(v15);
        global::OpenRA.Mods.Common.Traits.Aircraft v16 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v17 = this;
        __cil_type_01000025 v18 = v17.self;
        global::OpenRA.Mods.Common.Traits.Aircraft v19 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v20 = __cil_direct_06000F2E(v19);
        l2 = v20;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v21 = ref l2;
        global::OpenRA.Mods.Common.Traits.Aircraft v22 = this;
        int v23 = l1;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v24 = ref l0;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v25 = __cil_memberref_call_0A000222(ref v24);
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v26 = __cil_direct_06000F56(v22, v23, v25);
        l3 = v26;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v27 = ref l3;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v28 = OpenRA.WPos.op_Addition(ref v21, ref v27);
        __cil_direct_06000F67(v16, v18, v28);
        global::OpenRA.Mods.Common.Traits.Aircraft v29 = this;
        int v30 = 1;
        v29.notify = __cil_bool_store(v30);
        return;
    }

    public virtual OpenRA.WVec GetRepulsionForce()
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 bytes=151280A501128095: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l0 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l1 = default;
        int l2 = default;
        int l3 = default;
        int l4 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l5 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l6 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l7 = default;
        __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 l8 = default;
        __cil_type_01000025 l9 = default;
        OpenRA.Mods.Common.Traits.AircraftInfo l10 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l11 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l12 = default;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 l13 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v1 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v0).Info;
        int v2 = __cil_bool_load(v1.Repulsable);
        if (v2 != 0) {
            goto IL_0013;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v3 = __cil_ldsfld_0A000240();
        return v3;
        IL_0013: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v4 = this;
        __cil_type_0100002C v5 = v4.reservation;
        if (v5 is null) {
            goto IL_0063;
        } else {
            goto IL_001B;
        }
        IL_001B: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v6 = this;
        __cil_type_01000025 v7 = __cil_direct_06000F34(v6);
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v8 = ((OpenRA.Actor)v7).CenterPosition;
        l5 = v8;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v9 = ref l5;
        global::OpenRA.Mods.Common.Traits.Aircraft v10 = this;
        __cil_type_01000025 v11 = v10.self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v12 = ((OpenRA.Actor)v11).CenterPosition;
        l6 = v12;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v13 = ref l6;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v14 = OpenRA.WPos.op_Subtraction(ref v9, ref v13);
        l7 = v14;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v15 = ref l7;
        int v16 = __cil_memberref_call_0A00021F(ref v15);
        l4 = v16;
        int v17 = l4;
        global::OpenRA.Mods.Common.Traits.Aircraft v18 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v19 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v18).Info;
        ref __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v20 = ref __cil_ldflda_04000CD0(v19);
        int v21 = v20.Length;
        if (v17 >= v21) {
            goto IL_0063;
        } else {
            goto IL_005D;
        }
        IL_005D: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v22 = __cil_ldsfld_0A000240();
        return v22;
        IL_0063: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v23 = this;
        int v24 = __cil_bool_load(v23.cruising);
        if (v24 != 0) {
            goto IL_0071;
        } else {
            goto IL_006B;
        }
        IL_006B: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v25 = __cil_ldsfld_0A000240();
        return v25;
        IL_0071: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v26 = __cil_ldsfld_0A000240();
        l0 = v26;
        global::OpenRA.Mods.Common.Traits.Aircraft v27 = this;
        __cil_type_01000025 v28 = v27.self;
        __cil_type_0100002D v29 = v28.World;
        global::OpenRA.Mods.Common.Traits.Aircraft v30 = this;
        __cil_type_01000025 v31 = v30.self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v32 = ((OpenRA.Actor)v31).CenterPosition;
        global::OpenRA.Mods.Common.Traits.Aircraft v33 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v34 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v33).Info;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v35 = v34.IdealSeparation;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v36 = OpenRA.WorldUtils.FindActorsInCircle(v29, v32, v35);
        __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v37 = __cil_callvirt_0A000085(v36);
        l8 = v37;
        try {
            IL_00A4: ;
            goto IL_0100;
            IL_00A6: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v38 = l8;
            __cil_type_01000025 v39 = __cil_callvirt_0A000084(v38);
            l9 = v39;
            __cil_type_01000025 v40 = l9;
            int v41 = __cil_bool_load(((OpenRA.Actor)v40).IsDead);
            if (v41 != 0) {
                goto IL_0100;
            } else {
                goto IL_00B8;
            }
            IL_00B8: ;
            __cil_type_01000025 v42 = l9;
            __cil_type_01000108 v43 = v42.Info;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v44 = __cil_callvirt_2B00013A(v43);
            l10 = v44;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v45 = l10;
            if (v45 is null) {
                goto IL_0100;
            } else {
                goto IL_00CA;
            }
            IL_00CA: ;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v46 = l10;
            int v47 = __cil_bool_load(v46.Repulsable);
            if (v47 == 0) {
                goto IL_0100;
            } else {
                goto IL_00D3;
            }
            IL_00D3: ;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v48 = l10;
            __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v49 = v48.CruiseAltitude;
            global::OpenRA.Mods.Common.Traits.Aircraft v50 = this;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v51 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v50).Info;
            __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v52 = v51.CruiseAltitude;
            int v53 = __cil_bool_load(OpenRA.WDist.op_Inequality(v49, v52));
            if (v53 != 0) {
                goto IL_0100;
            } else {
                goto IL_00EC;
            }
            IL_00EC: ;
            ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v54 = ref l0;
            global::OpenRA.Mods.Common.Traits.Aircraft v55 = this;
            __cil_type_01000025 v56 = l9;
            __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v57 = __cil_direct_06000F4A(v55, v56);
            l7 = v57;
            ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v58 = ref l7;
            __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v59 = OpenRA.WVec.op_Addition(ref v54, ref v58);
            l0 = v59;
            goto IL_0100;
            IL_0100: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v60 = l8;
            int v61 = __cil_bool_load(__cil_callvirt_0A00001B(v60));
            if (v61 != 0) {
                goto IL_00A6;
            } else {
                goto IL_0109;
            }
            IL_0109: ;
            goto IL_0117;
        }
        finally {
            IL_010B: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v62 = l8;
            if (v62 is null) {
                goto IL_0116;
            } else {
                goto IL_010F;
            }
            IL_010F: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v63 = l8;
            __cil_callvirt_0A00001A(v63);
            goto IL_0116;
            IL_0116: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0117: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v64 = this;
        __cil_type_01000025 v65 = v64.self;
        __cil_type_0100002D v66 = v65.World;
        __cil_type_01000026 v67 = v66.Map;
        global::OpenRA.Mods.Common.Traits.Aircraft v68 = this;
        __cil_type_01000025 v69 = v68.self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v70 = ((OpenRA.Actor)v69).Location;
        int v71 = __cil_bool_load(v67.Contains(v70));
        if (v71 != 0) {
            goto IL_01C0;
        } else {
            goto IL_013C;
        }
        IL_013C: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v72 = this;
        __cil_type_01000025 v73 = v72.self;
        __cil_type_0100002D v74 = v73.World;
        __cil_type_01000026 v75 = v74.Map;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v76 = ((OpenRA.Map)v75).ProjectedTopLeft;
        l5 = v76;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v77 = ref l5;
        global::OpenRA.Mods.Common.Traits.Aircraft v78 = this;
        __cil_type_01000025 v79 = v78.self;
        __cil_type_0100002D v80 = v79.World;
        __cil_type_01000026 v81 = v80.Map;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v82 = ((OpenRA.Map)v81).ProjectedBottomRight;
        l6 = v82;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v83 = ref l6;
        int v84 = 1;
        int v85 = 2;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v86 = OpenRA.WPos.Lerp(ref v77, ref v83, v84, v85);
        l11 = v86;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v87 = ref l0;
        int v88 = 0;
        int v89 = 1024;
        int v90 = 0;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v91 = __cil_newobj_0A000221(v88, v89, v90);
        l7 = v91;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v92 = ref l7;
        global::OpenRA.Mods.Common.Traits.Aircraft v93 = this;
        __cil_type_01000025 v94 = v93.self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v95 = ((OpenRA.Actor)v94).CenterPosition;
        l5 = v95;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v96 = ref l5;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v97 = ref l11;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v98 = OpenRA.WPos.op_Subtraction(ref v96, ref v97);
        l12 = v98;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v99 = ref l12;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v100 = __cil_memberref_call_0A000222(ref v99);
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v101 = OpenRA.WRot.FromYaw(v100);
        l13 = v101;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v102 = ref l13;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v103 = __cil_memberref_call_0A00075A(ref v92, ref v102);
        l7 = v103;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v104 = ref l7;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v105 = OpenRA.WVec.op_Addition(ref v87, ref v104);
        l0 = v105;
        goto IL_01C0;
        IL_01C0: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v106 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v107 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v106).Info;
        int v108 = __cil_bool_load(v107.CanSlide);
        if (v108 == 0) {
            goto IL_01CF;
        } else {
            goto IL_01CD;
        }
        IL_01CD: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v109 = l0;
        return v109;
        IL_01CF: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v110 = this;
        global::OpenRA.Mods.Common.Traits.Aircraft v111 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v112 = __cil_direct_06000F26(v111);
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v113 = __cil_direct_06000F55(v110, v112);
        l1 = v113;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v114 = ref l1;
        int v115 = __cil_memberref_call_0A00021F(ref v114);
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v116 = ref l0;
        int v117 = __cil_memberref_call_0A00021F(ref v116);
        int v118 = unchecked(v115 * v117);
        l2 = v118;
        int v119 = l2;
        if (v119 != 0) {
            goto IL_01F5;
        } else {
            goto IL_01EF;
        }
        IL_01EF: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v120 = __cil_ldsfld_0A000240();
        return v120;
        IL_01F5: ;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v121 = ref l1;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v122 = ref l0;
        int v123 = OpenRA.WVec.Dot(ref v121, ref v122);
        int v124 = l2;
        int v125 = unchecked(v123 / v124);
        l3 = v125;
        int v126 = l3;
        int v127 = 0;
        if (v126 >= v127) {
            goto IL_020B;
        } else {
            goto IL_0205;
        }
        IL_0205: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v128 = __cil_ldsfld_0A000240();
        return v128;
        IL_020B: ;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v129 = l0;
        return v129;
    }

    public OpenRA.WVec GetRepulsionForce(OpenRA.Actor other)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, D9, 0C, 00, 04, 03, 2E, 1D, 03, 6F, 5D, 01, 00, 0A, 7B, 76, 07, 00, 0A, 02, 7B, D9, 0C]
        // .code-bytes IL_0018: [00, 04, 6F, 5D, 01, 00, 0A, 7B, 76, 07, 00, 0A, 2F, 06, 7E, 40, 02, 00, 0A, 2A, 02, 7B, D9, 0C]
        // .code-bytes IL_0030: [00, 04, 6F, 5D, 01, 00, 0A, 0C, 12, 02, 03, 6F, 5D, 01, 00, 0A, 0D, 12, 03, 28, 1E, 02, 00, 0A]
        // .code-bytes IL_0048: [0A, 12, 00, 28, 7C, 02, 00, 0A, 0B, 07, 02, 7B, DB, 06, 00, 0A, 7C, AD, 0C, 00, 04, 28, 81, 07]
        // .code-bytes IL_0060: [00, 0A, 31, 06, 7E, 40, 02, 00, 0A, 2A, 07, 17, 6A, 2F, 4D, 02, 7B, D9, 0C, 00, 04, 7B, 59, 01]
        // .code-bytes IL_0078: [00, 0A, 7B, 88, 02, 00, 0A, 16, 20, FF, 03, 00, 00, 6F, 35, 02, 00, 0A, 13, 04, 12, 05, 7E, D5]
        // .code-bytes IL_0090: [02, 00, 0A, 7E, D5, 02, 00, 0A, 11, 04, 73, 19, 02, 00, 0A, 28, D6, 02, 00, 0A, 20, 00, 04, 00]
        // .code-bytes IL_00A8: [00, 16, 16, 73, 21, 02, 00, 0A, 13, 06, 12, 06, 12, 05, 28, 5A, 07, 00, 0A, 2A, 12, 00, 20, 00]
        // .code-bytes IL_00C0: [04, 00, 00, 28, 6F, 02, 00, 0A, 13, 06, 12, 06, 1E, 28, 6F, 02, 00, 0A, 13, 07, 12, 07, 07, 69]
        // .code-bytes IL_00D8: [28, 8A, 02, 00, 0A, 2A]
        // .local [0] valuetype [OpenRA.Game]OpenRA.WVec
        // .local [1] int64
        // .local [2] valuetype [OpenRA.Game]OpenRA.WPos
        // .local [3] valuetype [OpenRA.Game]OpenRA.WPos
        // .local [4] int32
        // .local [5] valuetype [OpenRA.Game]OpenRA.WRot
        // .local [6] valuetype [OpenRA.Game]OpenRA.WVec
        // .local [7] valuetype [OpenRA.Game]OpenRA.WVec
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x04000CD9 OpenRA.Mods.Common.Traits.Aircraft::self
        // IL_0006: ldarg.1 1
        // IL_0007: beq.s IL_0026
        // IL_0009: ldarg.1 1
        // IL_000A: callvirt 0x0A00015D [OpenRA.Game]OpenRA.Actor::get_CenterPosition
        // IL_000F: ldfld 0x0A000776 [OpenRA.Game]OpenRA.WPos::Z
        // IL_0014: ldarg.0 0
        // IL_0015: ldfld 0x04000CD9 OpenRA.Mods.Common.Traits.Aircraft::self
        // IL_001A: callvirt 0x0A00015D [OpenRA.Game]OpenRA.Actor::get_CenterPosition
        // IL_001F: ldfld 0x0A000776 [OpenRA.Game]OpenRA.WPos::Z
        // IL_0024: bge.s IL_002C
        // IL_0026: ldsfld 0x0A000240 [OpenRA.Game]OpenRA.WVec::Zero
        // IL_002B: ret 
        // IL_002C: ldarg.0 0
        // IL_002D: ldfld 0x04000CD9 OpenRA.Mods.Common.Traits.Aircraft::self
        // IL_0032: callvirt 0x0A00015D [OpenRA.Game]OpenRA.Actor::get_CenterPosition
        // IL_0037: stloc.2 2
        // IL_0038: ldloca.s 2
        // IL_003A: ldarg.1 1
        // IL_003B: callvirt 0x0A00015D [OpenRA.Game]OpenRA.Actor::get_CenterPosition
        // IL_0040: stloc.3 3
        // IL_0041: ldloca.s 3
        // IL_0043: call 0x0A00021E [OpenRA.Game]OpenRA.WPos::op_Subtraction
        // IL_0048: stloc.0 0
        // IL_0049: ldloca.s 0
        // IL_004B: call 0x0A00027C [OpenRA.Game]OpenRA.WVec::get_HorizontalLengthSquared
        // IL_0050: stloc.1 1
        // IL_0051: ldloc.1 1
        // IL_0052: ldarg.0 0
        // IL_0053: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_0058: ldflda 0x04000CAD OpenRA.Mods.Common.Traits.AircraftInfo::IdealSeparation
        // IL_005D: call 0x0A000781 [OpenRA.Game]OpenRA.WDist::get_LengthSquared
        // IL_0062: ble.s IL_006A
        // IL_0064: ldsfld 0x0A000240 [OpenRA.Game]OpenRA.WVec::Zero
        // IL_0069: ret 
        // IL_006A: ldloc.1 1
        // IL_006B: ldc.i4.1 1
        // IL_006C: conv.i8 
        // IL_006D: bge.s IL_00BC
        // IL_006F: ldarg.0 0
        // IL_0070: ldfld 0x04000CD9 OpenRA.Mods.Common.Traits.Aircraft::self
        // IL_0075: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_007A: ldfld 0x0A000288 [OpenRA.Game]OpenRA.World::SharedRandom
        // IL_007F: ldc.i4.0 0
        // IL_0080: ldc.i4 1023
        // IL_0085: callvirt 0x0A000235 [OpenRA.Game]OpenRA.Support.MersenneTwister::Next
        // IL_008A: stloc.s 4
        // IL_008C: ldloca.s 5
        // IL_008E: ldsfld 0x0A0002D5 [OpenRA.Game]OpenRA.WAngle::Zero
        // IL_0093: ldsfld 0x0A0002D5 [OpenRA.Game]OpenRA.WAngle::Zero
        // IL_0098: ldloc.s 4
        // IL_009A: newobj 0x0A000219 [OpenRA.Game]OpenRA.WAngle::.ctor
        // IL_009F: call 0x0A0002D6 [OpenRA.Game]OpenRA.WRot::.ctor
        // IL_00A4: ldc.i4 1024
        // IL_00A9: ldc.i4.0 0
        // IL_00AA: ldc.i4.0 0
        // IL_00AB: newobj 0x0A000221 [OpenRA.Game]OpenRA.WVec::.ctor
        // IL_00B0: stloc.s 6
        // IL_00B2: ldloca.s 6
        // IL_00B4: ldloca.s 5
        // IL_00B6: call 0x0A00075A [OpenRA.Game]OpenRA.WVec::Rotate
        // IL_00BB: ret 
        // IL_00BC: ldloca.s 0
        // IL_00BE: ldc.i4 1024
        // IL_00C3: call 0x0A00026F [OpenRA.Game]OpenRA.WVec::op_Multiply
        // IL_00C8: stloc.s 6
        // IL_00CA: ldloca.s 6
        // IL_00CC: ldc.i4.8 8
        // IL_00CD: call 0x0A00026F [OpenRA.Game]OpenRA.WVec::op_Multiply
        // IL_00D2: stloc.s 7
        // IL_00D4: ldloca.s 7
        // IL_00D6: ldloc.1 1
        // IL_00D7: conv.i4 
        // IL_00D8: call 0x0A00028A [OpenRA.Game]OpenRA.WVec::op_Division
        // IL_00DD: ret 
    }

    public OpenRA.Actor GetActorBelow()
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s3_0 = default;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 s3_1 = default;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s4_0 = default;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 s4_1 = default;
        __cil_type_01000025 v1 = this.self;
        __cil_type_0100002D v2 = v1.World;
        __cil_type_01000026 v3 = v2.Map;
        // Exact call 0x06000F2E kept: direct virtual this accessor needs exact call notation.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v5 = __cil_direct_06000F2E(this);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v6 = v3.DistanceAboveTerrain(v5);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v8 = this.LandAltitude;
        int v9 = __cil_bool_load(OpenRA.WDist.op_Inequality(v6, v8));
        if (!(v9 == 0)) {
            return null;
        }
        __cil_type_01000025 v11 = this.self;
        __cil_type_0100002D v12 = v11.World;
        __cil_type_01000130 v13 = v12.ActorMap;
        __cil_type_01000025 v15 = this.self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v16 = ((OpenRA.Actor)v15).Location;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v17 = __cil_callvirt_0A000169(v13, v16);
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v18 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD1;
        if (v18 is not null) {
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e2_4_0 = v17;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 e2_4_1 = v18;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0069;
        } else {
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e2_3_0 = v17;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 e2_3_1 = v18;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_0052;
        }
        IL_0052: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v19 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF;
        nint v20 = __cil_ldftn_0600398E;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v21 = __cil_newobj_0A00019A(v19, v20);
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD1 = v21;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e3_4_0 = s3_0;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 e3_4_1 = v21;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        IL_0069: ;
        __cil_type_01000025 v22 = __cil_methodspec_call_2B00044F(s4_0, s4_1);
        return v22;
    }

    public void MakeReservation(OpenRA.Actor target)
    {
        OpenRA.Mods.Common.Traits.Reservable l0 = default;
        __cil_direct_06000F4E(this);
        global::OpenRA.Mods.Common.Traits.Reservable v2 = __cil_callvirt_2B000472(target);
        l0 = v2;
        global::OpenRA.Mods.Common.Traits.Reservable v3 = l0;
        if (v3 is null) {
            goto IL_002B;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Mods.Common.Traits.Reservable v5 = l0;
        __cil_type_01000025 v8 = this.self;
        __cil_type_0100002C v10 = __cil_callvirt_0600126E(v5, target, v8, this);
        this.reservation = v10;
        this.ReservedActor = target;
        IL_002B: ;
        return;
    }

    public void AllowYieldingReservation()
    {
        __cil_type_0100002C v1 = this.reservation;
        if (v1 is not null) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        this.MayYieldReservation = __cil_bool_store(1);
        return;
    }

    public void UnReserve()
    {
        __cil_type_0100002C v1 = this.reservation;
        if (v1 is not null) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        __cil_type_0100002C v3 = this.reservation;
        __cil_callvirt_0A00001A(v3);
        this.reservation = null;
        this.ReservedActor = ((__cil_type_01000025)(null));
        this.MayYieldReservation = __cil_bool_store(0);
        return;
    }

    private bool AircraftCanEnter(OpenRA.Actor a, OpenRA.Traits.TargetModifiers modifiers)
    {
        // enum storage token=0x0200012E alias=__cil_enum_0200012E underlying=int: global::@OpenRA.@Traits.@TargetModifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = __cil_bool_load(this.RequireForceMove);
        if (v1 == 0) {
            goto IL_0013;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v2 = unchecked((int)(modifiers));
        int v4 = __cil_bool_load(OpenRA.Traits.TargetModifiersExts.HasModifier(unchecked((OpenRA.Traits.TargetModifiers)(v2)), unchecked((OpenRA.Traits.TargetModifiers)(4))));
        if (v4 != 0) {
            goto IL_0013;
        } else {
            return false;
        }
        IL_0013: ;
        return __cil_direct_06000F50(this, a);
    }

    private bool AircraftCanEnter(OpenRA.Actor a)
    {
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        bool l1 = default;
        int s5_0 = default;
        int s8_0 = default;
        __cil_type_01000025 v1 = this.self;
        int v3 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.AppearsHostileTo(v1, a));
        if (!(v3 == 0)) {
            return false;
        }
        global::OpenRA.Mods.Common.Traits.Rearmable v6 = this.rearmable;
        if (v6 is null) {
            goto IL_003A;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v8 = this.rearmable;
        global::OpenRA.Mods.Common.Traits.RearmableInfo v9 = v8.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v10 = v9.RearmActors;
        __cil_type_01000108 v12 = a.Info;
        string v13 = v12.Name;
        int v14 = __cil_bool_load(__cil_callvirt_0A0002A0(v10, v13));
        int e3_5_0 = v14;
        s5_0 = e3_5_0;
        goto IL_003B;
        IL_003A: ;
        int e4_5_0 = 0;
        s5_0 = e4_5_0;
        IL_003B: ;
        l0 = __cil_bool_store(s5_0);
        global::OpenRA.Mods.Common.Traits.Repairable v17 = this.repairable;
        if (v17 is null) {
            goto IL_0066;
        } else {
            goto IL_0044;
        }
        IL_0044: ;
        global::OpenRA.Mods.Common.Traits.Repairable v19 = this.repairable;
        global::OpenRA.Mods.Common.Traits.RepairableInfo v20 = v19.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v21 = v20.RepairActors;
        __cil_type_01000108 v23 = a.Info;
        string v24 = v23.Name;
        int v25 = __cil_bool_load(__cil_callvirt_0A0002A0(v21, v24));
        int e6_8_0 = v25;
        s8_0 = e6_8_0;
        goto IL_0067;
        IL_0066: ;
        int e7_8_0 = 0;
        s8_0 = e7_8_0;
        IL_0067: ;
        l1 = __cil_bool_store(s8_0);
        int v27 = __cil_bool_load(l0);
        int v28 = __cil_bool_load(l1);
        return __cil_bool_store(unchecked(v27 | v28));
    }

    private bool AircraftCanResupplyAt(OpenRA.Actor a, bool allowedToForceEnter = false)
    {
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 bytes=1D128AE4: class OpenRA.Mods.Common.Traits.AmmoPool[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 bytes=1512812102128AE402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.AmmoPool, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_678f2da3f3f9619e8c9b9f98bdf4a558ce89055e bytes=151280A101128AE4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.AmmoPool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200011F alias=__cil_enum_0200011F underlying=int: global::@OpenRA.@Traits.@DamageState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        bool l0 = default;
        bool l1 = default;
        bool l2 = default;
        bool l3 = default;
        int s5_0 = default;
        int s8_0 = default;
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 s11_0 = default;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 s11_1 = default;
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 s12_0 = default;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 s12_1 = default;
        int s15_0 = default;
        int s20_0 = default;
        __cil_type_01000025 v1 = this.self;
        int v3 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.AppearsHostileTo(v1, a));
        if (!(v3 == 0)) {
            return false;
        }
        global::OpenRA.Mods.Common.Traits.Rearmable v6 = this.rearmable;
        if (v6 is null) {
            goto IL_003A;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v8 = this.rearmable;
        global::OpenRA.Mods.Common.Traits.RearmableInfo v9 = v8.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v10 = v9.RearmActors;
        __cil_type_01000108 v12 = a.Info;
        string v13 = v12.Name;
        int v14 = __cil_bool_load(__cil_callvirt_0A0002A0(v10, v13));
        int e3_5_0 = v14;
        s5_0 = e3_5_0;
        goto IL_003B;
        IL_003A: ;
        int e4_5_0 = 0;
        s5_0 = e4_5_0;
        IL_003B: ;
        l0 = __cil_bool_store(s5_0);
        global::OpenRA.Mods.Common.Traits.Repairable v17 = this.repairable;
        if (v17 is null) {
            goto IL_0066;
        } else {
            goto IL_0044;
        }
        IL_0044: ;
        global::OpenRA.Mods.Common.Traits.Repairable v19 = this.repairable;
        global::OpenRA.Mods.Common.Traits.RepairableInfo v20 = v19.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v21 = v20.RepairActors;
        __cil_type_01000108 v23 = a.Info;
        string v24 = v23.Name;
        int v25 = __cil_bool_load(__cil_callvirt_0A0002A0(v21, v24));
        int e6_8_0 = v25;
        s8_0 = e6_8_0;
        goto IL_0067;
        IL_0066: ;
        int e7_8_0 = 0;
        s8_0 = e7_8_0;
        IL_0067: ;
        l1 = __cil_bool_store(s8_0);
        int v27 = __cil_bool_load(l0);
        if (v27 == 0) {
            goto IL_00A2;
        } else {
            goto IL_006B;
        }
        IL_006B: ;
        int v28 = __cil_bool_load(allowedToForceEnter);
        if (v28 != 0) {
            goto IL_009F;
        } else {
            goto IL_006E;
        }
        IL_006E: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v30 = this.rearmable;
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 v31 = __cil_callvirt_06001A67(v30);
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 v32 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD2;
        if (v32 is not null) {
            __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 e10_12_0 = v31;
            __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 e10_12_1 = v32;
            s12_0 = e10_12_0;
            s12_1 = e10_12_1;
            goto IL_0098;
        } else {
            __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 e10_11_0 = v31;
            __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 e10_11_1 = v32;
            s11_0 = e10_11_0;
            s11_1 = e10_11_1;
            goto IL_0081;
        }
        IL_0081: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v33 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF;
        nint v34 = __cil_ldftn_0600398F;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 v35 = __cil_newobj_0A001123(v33, v34);
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD2 = v35;
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 e11_12_0 = s11_0;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 e11_12_1 = v35;
        s12_0 = e11_12_0;
        s12_1 = e11_12_1;
        IL_0098: ;
        int v36 = __cil_bool_load(__cil_methodspec_call_2B000473(((__cil_ref_678f2da3f3f9619e8c9b9f98bdf4a558ce89055e)(s12_0)), s12_1));
        int e12_15_0 = v36;
        s15_0 = e12_15_0;
        goto IL_00A3;
        IL_009F: ;
        int e13_15_0 = 1;
        s15_0 = e13_15_0;
        goto IL_00A3;
        IL_00A2: ;
        int e14_15_0 = 0;
        s15_0 = e14_15_0;
        IL_00A3: ;
        l2 = __cil_bool_store(s15_0);
        int v39 = __cil_bool_load(l1);
        if (v39 == 0) {
            goto IL_00C0;
        } else {
            goto IL_00A7;
        }
        IL_00A7: ;
        int v40 = __cil_bool_load(allowedToForceEnter);
        if (v40 != 0) {
            goto IL_00BD;
        } else {
            goto IL_00AA;
        }
        IL_00AA: ;
        __cil_type_01000025 v42 = this.self;
        int v43 = unchecked((int)(v42.GetDamageState()));
        int v45 = (v43 == 1 ? 1 : 0);
        int v47 = (v45 == 0 ? 1 : 0);
        int e17_20_0 = v47;
        s20_0 = e17_20_0;
        goto IL_00C1;
        IL_00BD: ;
        int e18_20_0 = 1;
        s20_0 = e18_20_0;
        goto IL_00C1;
        IL_00C0: ;
        int e19_20_0 = 0;
        s20_0 = e19_20_0;
        IL_00C1: ;
        l3 = __cil_bool_store(s20_0);
        int v50 = __cil_bool_load(l2);
        int v51 = __cil_bool_load(l3);
        return __cil_bool_store(unchecked(v50 | v51));
    }

    public int get_MovementSpeed()
    {
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // Exact call 0x0A0010FD kept: property syntax needs a nongeneric class owner.
        int v1 = __cil_bool_load(__cil_direct_0A0010FD(this));
        if (v1 != 0) {
            return 0;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        // Exact call 0x0A0010FE kept: property syntax needs a nongeneric class owner.
        int v3 = __cil_bool_load(__cil_direct_0A0010FE(this));
        if (!(v3 == 0)) {
            return 0;
        }
        global::OpenRA.Mods.Common.Traits.AircraftInfo v6 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v7 = v6.Speed;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v9 = this.speedModifiers;
        int v10 = OpenRA.Mods.Common.Util.ApplyPercentageModifiers(v7, v9);
        return v10;
    }

    public int get_IdleMovementSpeed()
    {
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.AircraftInfo v1 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v2 = v1.IdleSpeed;
        if (v2 < 0) {
            goto IL_0037;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        // Exact call 0x0A0010FD kept: property syntax needs a nongeneric class owner.
        int v5 = __cil_bool_load(__cil_direct_0A0010FD(this));
        if (v5 != 0) {
            return 0;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        // Exact call 0x0A0010FE kept: property syntax needs a nongeneric class owner.
        int v7 = __cil_bool_load(__cil_direct_0A0010FE(this));
        if (!(v7 == 0)) {
            return 0;
        }
        global::OpenRA.Mods.Common.Traits.AircraftInfo v10 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v11 = v10.IdleSpeed;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v13 = this.speedModifiers;
        int v14 = OpenRA.Mods.Common.Util.ApplyPercentageModifiers(v11, v13);
        return v14;
        IL_0037: ;
        int v16 = this.MovementSpeed;
        return v16;
    }

    public virtual System.ValueTuple<OpenRA.CPos, OpenRA.Traits.SubCell>[] OccupiedCells()
    {
        // structural signature __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 bytes=1D151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v1 = this.landingCells;
        return v1;
    }

    public OpenRA.WVec FlyStep(OpenRA.WAngle facing)
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int v2 = this.MovementSpeed;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v4 = __cil_direct_06000F56(this, v2, facing);
        return v4;
    }

    public OpenRA.WVec FlyStep(int speed, OpenRA.WAngle facing)
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l0 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l1 = default;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 l2 = default;
        IL_0000: ;
        int v0 = 0;
        int v1 = -1024;
        int v2 = 0;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v3 = __cil_newobj_0A000221(v0, v1, v2);
        l1 = v3;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v4 = ref l1;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v5 = facing;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v6 = OpenRA.WRot.FromYaw(v5);
        l2 = v6;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v7 = ref l2;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v8 = __cil_memberref_call_0A00075A(ref v4, ref v7);
        l0 = v8;
        int v9 = speed;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v10 = ref l0;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v11 = OpenRA.WVec.op_Multiply(v9, ref v10);
        l1 = v11;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v12 = ref l1;
        int v13 = 1024;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v14 = OpenRA.WVec.op_Division(ref v12, v13);
        return v14;
    }

    public System.Nullable<OpenRA.CPos> FindLandingLocation(OpenRA.CPos targetCell, OpenRA.WDist maxSearchDistance)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2a38231b7620144b7e2926345dd445b782449779 bytes=15118141011180A9: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d bytes=151280A5011180A9: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e bytes=151280A1011180A9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l1 = default;
        __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d l2 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l3 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l4 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l5 = default;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 l6 = default;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 l7 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = targetCell;
        int v2 = 0;
        int v3 = __cil_bool_load(__cil_direct_06000F59(v0, v1, ((__cil_type_01000025)(null)), __cil_bool_store(v2)));
        if (v3 == 0) {
            goto IL_0012;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v4 = targetCell;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 v5 = __cil_value_newobj_0A0006B4(v4);
        return v5;
        IL_0012: ;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v6 = maxSearchDistance;
        int v7 = v6.Length;
        int v8 = 1023;
        int v9 = unchecked(v7 + v8);
        int v10 = 1024;
        int v11 = unchecked(v9 / v10);
        l0 = v11;
        global::OpenRA.Mods.Common.Traits.Aircraft v12 = this;
        __cil_type_01000025 v13 = v12.self;
        __cil_type_0100002D v14 = v13.World;
        __cil_type_01000026 v15 = v14.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v16 = targetCell;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v17 = v15.CenterOfCell(v16);
        l1 = v17;
        global::OpenRA.Mods.Common.Traits.Aircraft v18 = this;
        __cil_type_01000025 v19 = v18.self;
        __cil_type_0100002D v20 = v19.World;
        __cil_type_01000026 v21 = v20.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v22 = targetCell;
        int v23 = l0;
        int v24 = 0;
        __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e v25 = v21.FindTilesInCircle(v22, v23, __cil_bool_store(v24));
        __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v26 = __cil_callvirt_0A00002B(v25);
        l2 = v26;
        try {
            IL_005A: ;
            goto IL_00AB;
            IL_005C: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v27 = l2;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v28 = __cil_callvirt_0A00002A(v27);
            l3 = v28;
            global::OpenRA.Mods.Common.Traits.Aircraft v29 = this;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v30 = l3;
            int v31 = 0;
            int v32 = __cil_bool_load(__cil_direct_06000F59(v29, v30, ((__cil_type_01000025)(null)), __cil_bool_store(v31)));
            if (v32 == 0) {
                goto IL_00AB;
            } else {
                goto IL_006E;
            }
            IL_006E: ;
            global::OpenRA.Mods.Common.Traits.Aircraft v33 = this;
            __cil_type_01000025 v34 = v33.self;
            __cil_type_0100002D v35 = v34.World;
            __cil_type_01000026 v36 = v35.Map;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v37 = l3;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v38 = v36.CenterOfCell(v37);
            l5 = v38;
            ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v39 = ref l5;
            ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v40 = ref l1;
            __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v41 = OpenRA.WPos.op_Subtraction(ref v39, ref v40);
            l4 = v41;
            ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v42 = ref l4;
            long v43 = __cil_memberref_call_0A00078A(ref v42);
            ref __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v44 = ref maxSearchDistance;
            long v45 = __cil_memberref_call_0A000781(ref v44);
            if (v43 >= v45) {
                goto IL_00AB;
            } else {
                goto IL_00A1;
            }
            IL_00A1: ;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v46 = l3;
            __cil_value_2a38231b7620144b7e2926345dd445b782449779 v47 = __cil_value_newobj_0A0006B4(v46);
            l6 = v47;
            goto IL_00CA;
            IL_00AB: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v48 = l2;
            int v49 = __cil_bool_load(__cil_callvirt_0A00001B(v48));
            if (v49 != 0) {
                goto IL_005C;
            } else {
                goto IL_00B3;
            }
            IL_00B3: ;
            goto IL_00BF;
        }
        finally {
            IL_00B5: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v50 = l2;
            if (v50 is null) {
                goto IL_00BE;
            } else {
                goto IL_00B8;
            }
            IL_00B8: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v51 = l2;
            __cil_callvirt_0A00001A(v51);
            goto IL_00BE;
            IL_00BE: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_00BF: ;
        ref __cil_value_2a38231b7620144b7e2926345dd445b782449779 v52 = ref l7;
        v52 = default;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 v53 = l7;
        return v53;
        IL_00CA: ;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 v54 = l6;
        return v54;
    }

    public bool CanLand(System.Collections.Generic.IEnumerable<OpenRA.CPos> cells, OpenRA.Actor dockingActor = null, bool blockedByMobile = true)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d bytes=151280A5011180A9: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e bytes=151280A1011180A9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d l0 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l1 = default;
        bool l2 = default;
        IL_0000: ;
        __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e v0 = cells;
        __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v1 = __cil_callvirt_0A00002B(v0);
        l0 = v1;
        try {
            IL_0007: ;
            goto IL_001F;
            IL_0009: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v2 = l0;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v3 = __cil_callvirt_0A00002A(v2);
            l1 = v3;
            global::OpenRA.Mods.Common.Traits.Aircraft v4 = this;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v5 = l1;
            __cil_type_01000025 v6 = dockingActor;
            int v7 = __cil_bool_load(blockedByMobile);
            int v8 = __cil_bool_load(__cil_direct_06000F59(v4, v5, v6, __cil_bool_store(v7)));
            if (v8 != 0) {
                goto IL_001F;
            } else {
                goto IL_001B;
            }
            IL_001B: ;
            int v9 = 0;
            l2 = __cil_bool_store(v9);
            goto IL_0035;
            IL_001F: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v10 = l0;
            int v11 = __cil_bool_load(__cil_callvirt_0A00001B(v10));
            if (v11 != 0) {
                goto IL_0009;
            } else {
                goto IL_0027;
            }
            IL_0027: ;
            goto IL_0033;
        }
        finally {
            IL_0029: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v12 = l0;
            if (v12 is null) {
                goto IL_0032;
            } else {
                goto IL_002C;
            }
            IL_002C: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v13 = l0;
            __cil_callvirt_0A00001A(v13);
            goto IL_0032;
            IL_0032: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0033: ;
        int v14 = 1;
        return __cil_bool_store(v14);
        IL_0035: ;
        int v15 = __cil_bool_load(l2);
        return __cil_bool_store(v15);
    }

    public bool CanLand(OpenRA.CPos cell, OpenRA.Actor dockingActor = null, bool blockedByMobile = true)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 bytes=151280A501128095: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 l0 = default;
        __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 l1 = default;
        __cil_type_01000025 l2 = default;
        bool l3 = default;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 s16_0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_type_01000025 v1 = v0.self;
        __cil_type_0100002D v2 = v1.World;
        __cil_type_01000026 v3 = v2.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v4 = cell;
        int v5 = __cil_bool_load(v3.Contains(v4));
        if (v5 != 0) {
            goto IL_001A;
        } else {
            goto IL_0018;
        }
        IL_0018: ;
        int v6 = 0;
        return __cil_bool_store(v6);
        IL_001A: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v7 = this;
        __cil_type_01000025 v8 = v7.self;
        __cil_type_0100002D v9 = v8.World;
        __cil_type_01000130 v10 = v9.ActorMap;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v11 = cell;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v12 = __cil_callvirt_0A000169(v10, v11);
        __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v13 = __cil_callvirt_0A000085(v12);
        l1 = v13;
        try {
            IL_0036: ;
            goto IL_0054;
            IL_0038: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v14 = l1;
            __cil_type_01000025 v15 = __cil_callvirt_0A000084(v14);
            l2 = v15;
            global::OpenRA.Mods.Common.Traits.Aircraft v16 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v17 = this;
            __cil_type_01000025 v18 = v17.self;
            __cil_type_01000025 v19 = l2;
            __cil_type_01000025 v20 = dockingActor;
            int v21 = __cil_bool_load(blockedByMobile);
            int v22 = __cil_bool_load(__cil_direct_06000F5A(v16, v18, v19, v20, __cil_bool_store(v21)));
            if (v22 == 0) {
                goto IL_0054;
            } else {
                goto IL_0050;
            }
            IL_0050: ;
            int v23 = 0;
            l3 = __cil_bool_store(v23);
            goto IL_00B0;
            IL_0054: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v24 = l1;
            int v25 = __cil_bool_load(__cil_callvirt_0A00001B(v24));
            if (v25 != 0) {
                goto IL_0038;
            } else {
                goto IL_005C;
            }
            IL_005C: ;
            goto IL_0068;
        }
        finally {
            IL_005E: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v26 = l1;
            if (v26 is null) {
                goto IL_0067;
            } else {
                goto IL_0061;
            }
            IL_0061: ;
            __cil_ref_be587bb7f4110ef807a396544980be23a3e4b0c2 v27 = l1;
            __cil_callvirt_0A00001A(v27);
            goto IL_0067;
            IL_0067: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0068: ;
        __cil_type_01000025 v28 = dockingActor;
        if (v28 is null) {
            goto IL_006D;
        } else {
            goto IL_006B;
        }
        IL_006B: ;
        int v29 = 1;
        return __cil_bool_store(v29);
        IL_006D: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v30 = this;
        global::OpenRA.Mods.Common.Traits.IOverrideAircraftLanding v31 = v30.overrideAircraftLanding;
        if (v31 is not null) {
            goto IL_0082;
        } else {
            goto IL_0075;
        }
        IL_0075: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v32 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v33 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v32).Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v34 = v33.LandableTerrainTypes;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 e14_16_0 = v34;
        s16_0 = e14_16_0;
        goto IL_008D;
        IL_0082: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v35 = this;
        global::OpenRA.Mods.Common.Traits.IOverrideAircraftLanding v36 = v35.overrideAircraftLanding;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v37 = __cil_callvirt_06001FC6(v36);
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 e15_16_0 = v37;
        s16_0 = e15_16_0;
        goto IL_008D;
        IL_008D: ;
        l0 = s16_0;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v38 = l0;
        global::OpenRA.Mods.Common.Traits.Aircraft v39 = this;
        __cil_type_01000025 v40 = v39.self;
        __cil_type_0100002D v41 = v40.World;
        __cil_type_01000026 v42 = v41.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v43 = cell;
        __cil_type_010000CD v44 = v42.GetTerrainInfo(v43);
        string v45 = v44.Type;
        int v46 = __cil_bool_load(__cil_callvirt_0A0002A0(v38, v45));
        return __cil_bool_store(v46);
        IL_00B0: ;
        int v47 = __cil_bool_load(l3);
        return __cil_bool_store(v47);
    }

    private bool IsBlockedBy(OpenRA.Actor self, OpenRA.Actor otherActor, OpenRA.Actor ignoreActor, bool blockedByMobile = true)
    {
        // structural signature __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc bytes=1D1284C9: class [OpenRA.Game]OpenRA.Traits.ICrushable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 bytes=151181E5011287A1: valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000123 alias=__cil_enum_02000123 underlying=int: global::@OpenRA.@Traits.@PlayerRelationship; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_010001F2 l0 = default;
        __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc l1 = default;
        int l2 = default;
        __cil_type_01000132 l3 = default;
        IL_0000: ;
        __cil_type_01000025 v0 = otherActor;
        __cil_type_01000025 v1 = self;
        if (System.Object.ReferenceEquals(v0, v1)) {
            goto IL_0008;
        } else {
            goto IL_0004;
        }
        IL_0004: ;
        __cil_type_01000025 v2 = otherActor;
        __cil_type_01000025 v3 = ignoreActor;
        if (!System.Object.ReferenceEquals(v2, v3)) {
            goto IL_000A;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v4 = 0;
        return __cil_bool_store(v4);
        IL_000A: ;
        int v5 = __cil_bool_load(blockedByMobile);
        if (v5 != 0) {
            goto IL_0034;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        __cil_type_01000025 v6 = self;
        __cil_type_01000030 v7 = ((OpenRA.Actor)v6).Owner;
        __cil_type_01000025 v8 = otherActor;
        __cil_type_01000030 v9 = ((OpenRA.Actor)v8).Owner;
        int v10 = unchecked((int)(v7.RelationshipWith(v9)));
        int v11 = 4;
        if (unchecked((uint)v10) != unchecked((uint)v11)) {
            goto IL_0034;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        __cil_type_01000025 v12 = otherActor;
        global::OpenRA.Mods.Common.Traits.Mobile v13 = __cil_callvirt_2B000023(v12);
        if (v13 is null) {
            goto IL_0034;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        __cil_type_01000025 v14 = otherActor;
        __cil_type_0100010F v15 = ((OpenRA.Actor)v14).CurrentActivity;
        if (v15 is not null) {
            goto IL_0034;
        } else {
            goto IL_0032;
        }
        IL_0032: ;
        int v16 = 0;
        return __cil_bool_store(v16);
        IL_0034: ;
        __cil_type_01000025 v17 = self;
        __cil_type_0100002D v18 = v17.World;
        int v19 = __cil_bool_load(((OpenRA.World)v18).RulesContainTemporaryBlocker);
        if (v19 == 0) {
            goto IL_0057;
        } else {
            goto IL_0041;
        }
        IL_0041: ;
        __cil_type_01000025 v20 = otherActor;
        __cil_type_010001F2 v21 = __cil_callvirt_2B0001B1(v20);
        l0 = v21;
        __cil_type_010001F2 v22 = l0;
        if (v22 is null) {
            goto IL_0057;
        } else {
            goto IL_004B;
        }
        IL_004B: ;
        __cil_type_010001F2 v23 = l0;
        __cil_type_01000025 v24 = otherActor;
        __cil_type_01000025 v25 = self;
        int v26 = __cil_bool_load(__cil_callvirt_0A0000B5(v23, v24, v25));
        if (v26 == 0) {
            goto IL_0057;
        } else {
            goto IL_0055;
        }
        IL_0055: ;
        int v27 = 0;
        return __cil_bool_store(v27);
        IL_0057: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v28 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v29 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v28).Info;
        ref __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 v30 = ref __cil_ldflda_04000CBD(v29);
        int v31 = __cil_bool_load(__cil_value_call_0A001126(ref v30));
        if (v31 == 0) {
            goto IL_006B;
        } else {
            goto IL_0069;
        }
        IL_0069: ;
        int v32 = 1;
        return __cil_bool_store(v32);
        IL_006B: ;
        __cil_type_01000025 v33 = otherActor;
        __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc v34 = ((OpenRA.Actor)v33).Crushables;
        l1 = v34;
        int v35 = 0;
        l2 = v35;
        goto IL_0095;
        IL_0076: ;
        __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc v36 = l1;
        int v37 = l2;
        __cil_type_01000132 v38 = v36[v37];
        l3 = v38;
        __cil_type_01000132 v39 = l3;
        __cil_type_01000025 v40 = otherActor;
        __cil_type_01000025 v41 = self;
        global::OpenRA.Mods.Common.Traits.Aircraft v42 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v43 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v42).Info;
        __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 v44 = v43.Crushes;
        int v45 = __cil_bool_load(__cil_callvirt_0A0000BB(v39, v40, v41, v44));
        if (v45 == 0) {
            goto IL_0091;
        } else {
            goto IL_008F;
        }
        IL_008F: ;
        int v46 = 0;
        return __cil_bool_store(v46);
        IL_0091: ;
        int v47 = l2;
        int v48 = 1;
        int v49 = unchecked(v47 + v48);
        l2 = v49;
        goto IL_0095;
        IL_0095: ;
        int v50 = l2;
        __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc v51 = l1;
        nint v52 = unchecked((nint)(v51.LongLength));
        int v53 = unchecked((int)(v52));
        if (v50 < v53) {
            goto IL_0076;
        } else {
            goto IL_009B;
        }
        IL_009B: ;
        int v54 = 1;
        return __cil_bool_store(v54);
    }

    public bool CanRearmAt(OpenRA.Actor host)
    {
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 bytes=1D128AE4: class OpenRA.Mods.Common.Traits.AmmoPool[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 bytes=1512812102128AE402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.AmmoPool, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_678f2da3f3f9619e8c9b9f98bdf4a558ce89055e bytes=151280A101128AE4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.AmmoPool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 s3_0 = default;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 s3_1 = default;
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 s4_0 = default;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 s4_1 = default;
        global::OpenRA.Mods.Common.Traits.Rearmable v1 = this.rearmable;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v3 = this.rearmable;
        global::OpenRA.Mods.Common.Traits.RearmableInfo v4 = v3.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v5 = v4.RearmActors;
        __cil_type_01000108 v7 = host.Info;
        string v8 = v7.Name;
        int v9 = __cil_bool_load(__cil_callvirt_0A0002A0(v5, v8));
        if (v9 == 0) {
            return false;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v11 = this.rearmable;
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 v12 = __cil_callvirt_06001A67(v11);
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 v13 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD3;
        if (v13 is not null) {
            __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 e2_4_0 = v12;
            __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 e2_4_1 = v13;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0054;
        } else {
            __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 e2_3_0 = v12;
            __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 e2_3_1 = v13;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_003D;
        }
        IL_003D: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v14 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF;
        nint v15 = __cil_ldftn_06003990;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 v16 = __cil_newobj_0A001123(v14, v15);
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD3 = v16;
        __cil_ref_07fd951193f698dd642bdd000cecd0fb7abe6a58 e3_4_0 = s3_0;
        __cil_ref_e4f4afc57d13bd7da30129d2a434b96b4eb06a87 e3_4_1 = v16;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        IL_0054: ;
        return __cil_methodspec_call_2B000473(((__cil_ref_678f2da3f3f9619e8c9b9f98bdf4a558ce89055e)(s4_0)), s4_1);
    }

    public bool CanRepairAt(OpenRA.Actor host)
    {
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200011F alias=__cil_enum_0200011F underlying=int: global::@OpenRA.@Traits.@DamageState; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.Mods.Common.Traits.Repairable v1 = this.repairable;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Mods.Common.Traits.Repairable v3 = this.repairable;
        global::OpenRA.Mods.Common.Traits.RepairableInfo v4 = v3.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v5 = v4.RepairActors;
        __cil_type_01000108 v7 = host.Info;
        string v8 = v7.Name;
        int v9 = __cil_bool_load(__cil_callvirt_0A0002A0(v5, v8));
        if (v9 == 0) {
            return false;
        } else {
            goto IL_002A;
        }
        IL_002A: ;
        __cil_type_01000025 v11 = this.self;
        int v12 = unchecked((int)(v11.GetDamageState()));
        int v14 = (v12 == 1 ? 1 : 0);
        return (v14 == 0);
    }

    public virtual void ModifyDeathActorInit(OpenRA.Actor self, OpenRA.Primitives.TypeDictionary init)
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06000F26 kept: direct virtual this accessor needs exact call notation.
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v2 = __cil_direct_06000F26(this);
        global::OpenRA.Mods.Common.FacingInit v3 = __cil_newobj_0600008B(v2);
        init.Add(((object)(v3)));
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F746966794265636F6D696E6749646C652E4F6E4265636F6D696E6749646C65(OpenRA.Actor self)
    {
        __cil_callvirt_06000F5F(this, self);
        return;
    }

    protected virtual void OnBecomingIdle(OpenRA.Actor self)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020002AE alias=__cil_enum_020002AE underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@IdleBehaviorType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l0 = default;
        __cil_value_afed037d079105c214a094897df496882260d1c3 l1 = default;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d l2 = default;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 l3 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l4 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v1 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v0).Info;
        int v2 = unchecked((int)(v1.IdleBehavior));
        int v3 = 3;
        if (unchecked((uint)v2) != unchecked((uint)v3)) {
            goto IL_0028;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        __cil_type_01000025 v4 = self;
        __cil_type_01000025 v5 = self;
        int v6 = 25;
        global::OpenRA.Mods.Common.Activities.FlyOffMap v7 = __cil_newobj_0600233E(v5, v6);
        v4.QueueActivity(((__cil_type_0100010F)(v7)));
        __cil_type_01000025 v8 = self;
        global::OpenRA.Mods.Common.Activities.RemoveSelf v9 = __cil_newobj_060023F4();
        v8.QueueActivity(((__cil_type_0100010F)(v9)));
        return;
        IL_0028: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v10 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v11 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v10).Info;
        int v12 = unchecked((int)(v11.IdleBehavior));
        int v13 = 4;
        if (unchecked((uint)v12) != unchecked((uint)v13)) {
            goto IL_0077;
        } else {
            goto IL_0036;
        }
        IL_0036: ;
        __cil_type_01000025 v14 = self;
        __cil_type_0100002D v15 = v14.World;
        __cil_type_01000026 v16 = v15.Map;
        __cil_type_01000025 v17 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v18 = ((OpenRA.Actor)v17).Location;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v19 = v16.ChooseClosestEdgeCell(v18);
        l0 = v19;
        __cil_type_01000025 v20 = self;
        __cil_type_01000025 v21 = self;
        __cil_type_01000025 v22 = self;
        __cil_type_0100002D v23 = v22.World;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v24 = l0;
        int v25 = 0;
        __cil_value_afed037d079105c214a094897df496882260d1c3 v26 = OpenRA.Traits.Target.FromCell(v23, v24, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v25)))));
        l1 = v26;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v27 = ref l1;
        int v28 = 25;
        global::OpenRA.Mods.Common.Activities.FlyOffMap v29 = __cil_newobj_0600233F(v21, ref v27, v28);
        v20.QueueActivity(((__cil_type_0100010F)(v29)));
        __cil_type_01000025 v30 = self;
        global::OpenRA.Mods.Common.Activities.RemoveSelf v31 = __cil_newobj_060023F4();
        v30.QueueActivity(((__cil_type_0100010F)(v31)));
        return;
        IL_0077: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v32 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v33 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v32).Info;
        int v34 = unchecked((int)(v33.IdleBehavior));
        int v35 = 2;
        if (unchecked((uint)v34) != unchecked((uint)v35)) {
            goto IL_00A9;
        } else {
            goto IL_0085;
        }
        IL_0085: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v36 = this;
        __cil_type_01000025 v37 = __cil_direct_06000F4B(v36);
        if (v37 is not null) {
            goto IL_00A9;
        } else {
            goto IL_008D;
        }
        IL_008D: ;
        __cil_type_01000025 v38 = self;
        __cil_type_01000025 v39 = self;
        global::OpenRA.Mods.Common.Traits.Aircraft v40 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v41 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v40).Info;
        int v42 = __cil_bool_load(v41.TakeOffOnResupply);
        int v43 = 0;
        int v44 = (v42 == v43 ? 1 : 0);
        global::OpenRA.Mods.Common.Activities.ReturnToBase v45 = __cil_newobj_0600234A(v39, null, v44);
        v38.QueueActivity(((__cil_type_0100010F)(v45)));
        return;
        IL_00A9: ;
        __cil_type_01000025 v46 = self;
        __cil_type_0100002D v47 = v46.World;
        __cil_type_01000026 v48 = v47.Map;
        global::OpenRA.Mods.Common.Traits.Aircraft v49 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v50 = __cil_direct_06000F2E(v49);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v51 = v48.DistanceAboveTerrain(v50);
        l2 = v51;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v52 = l2;
        global::OpenRA.Mods.Common.Traits.Aircraft v53 = this;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v54 = __cil_direct_06000F3D(v53);
        int v55 = __cil_bool_load(OpenRA.WDist.op_Equality(v52, v54));
        if (v55 == 0) {
            goto IL_00F3;
        } else {
            goto IL_00CE;
        }
        IL_00CE: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v56 = this;
        __cil_type_01000025 v57 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v58 = ((OpenRA.Actor)v57).Location;
        int v59 = 1;
        int v60 = __cil_bool_load(__cil_direct_06000F59(v56, v58, ((__cil_type_01000025)(null)), __cil_bool_store(v59)));
        if (v60 != 0) {
            goto IL_00F2;
        } else {
            goto IL_00DE;
        }
        IL_00DE: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v61 = this;
        __cil_type_01000025 v62 = __cil_direct_06000F34(v61);
        if (v62 is not null) {
            goto IL_00F2;
        } else {
            goto IL_00E6;
        }
        IL_00E6: ;
        __cil_type_01000025 v63 = self;
        __cil_type_01000025 v64 = self;
        global::OpenRA.Mods.Common.Activities.TakeOff v65 = __cil_newobj_0600234F(v64);
        v63.QueueActivity(((__cil_type_0100010F)(v65)));
        goto IL_00F2;
        IL_00F2: ;
        return;
        IL_00F3: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v66 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v67 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v66).Info;
        int v68 = unchecked((int)(v67.IdleBehavior));
        int v69 = 1;
        if (unchecked((uint)v68) != unchecked((uint)v69)) {
            goto IL_0134;
        } else {
            goto IL_0101;
        }
        IL_0101: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v70 = this;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v71 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v70).Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v72 = v71.LandableTerrainTypes;
        int v73 = __cil_callvirt_0A00029F(v72);
        int v74 = 0;
        if (v73 <= v74) {
            goto IL_0134;
        } else {
            goto IL_0114;
        }
        IL_0114: ;
        __cil_type_01000025 v75 = self;
        __cil_type_01000025 v76 = self;
        ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v77 = ref l3;
        v77 = default;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v78 = l3;
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v79 = ref l4;
        v79 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v80 = l4;
        global::OpenRA.Mods.Common.Activities.Land v81 = __cil_newobj_06002342(v76, v78, v80);
        v75.QueueActivity(((__cil_type_0100010F)(v81)));
        return;
        IL_0134: ;
        __cil_type_01000025 v82 = self;
        __cil_type_01000025 v83 = self;
        int v84 = -1;
        int v85 = 1;
        global::OpenRA.Mods.Common.Activities.FlyIdle v86 = __cil_newobj_0600233C(v83, v84, v85);
        v82.QueueActivity(((__cil_type_0100010F)(v86)));
        return;
    }

    public virtual bool CanExistInCell(OpenRA.CPos cell)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        return true;
    }

    public virtual bool IsLeavingCell(OpenRA.CPos location, OpenRA.Traits.SubCell subCell = 254)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        return false;
    }

    public virtual bool CanEnterCell(OpenRA.CPos cell, OpenRA.Actor ignoreActor = null, OpenRA.Mods.Common.Traits.BlockedByActor check = 3)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x020006A1 alias=__cil_enum_020006A1 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@BlockedByActor; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        return true;
    }

    public virtual OpenRA.Traits.SubCell GetValidSubCell(OpenRA.Traits.SubCell preferred)
    {
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        return unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(255))));
    }

    public virtual OpenRA.Traits.SubCell GetAvailableSubCell(OpenRA.CPos a, OpenRA.Traits.SubCell preferredSubCell = 254, OpenRA.Actor ignoreActor = null, OpenRA.Mods.Common.Traits.BlockedByActor check = 3)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020006A1 alias=__cil_enum_020006A1 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@BlockedByActor; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        return unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(255))));
    }

    public virtual void SetCenterPosition(OpenRA.Actor self, OpenRA.WPos pos)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_direct_06000F67(this, self, pos);
        return;
    }

    public virtual void SetPosition(OpenRA.Actor self, OpenRA.CPos cell, OpenRA.Traits.SubCell subCell = 254)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l0 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l1 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_type_01000025 v1 = self;
        __cil_type_01000025 v2 = self;
        __cil_type_0100002D v3 = v2.World;
        __cil_type_01000026 v4 = v3.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v5 = cell;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v6 = v4.CenterOfCell(v5);
        l0 = v6;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v7 = ref l0;
        int v8 = 0;
        int v9 = 0;
        global::OpenRA.Mods.Common.Traits.Aircraft v10 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v11 = __cil_direct_06000F2E(v10);
        int v12 = v11.Z;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v13 = __cil_newobj_0A000221(v8, v9, v12);
        l1 = v13;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v14 = ref l1;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v15 = OpenRA.WPos.op_Addition(ref v7, ref v14);
        __cil_direct_06000F67(v0, v1, v15);
        return;
    }

    public virtual void SetPosition(OpenRA.Actor self, OpenRA.WPos pos)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_763732cf543d047a5287a4266098cf29f7836f4a bytes=151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 bytes=1D151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d bytes=1D129874: class OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4087415c3703bfbaa7f9c4aa7fbcda2e2866b352 bytes=151280A101151181A9021180A91180E5: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d l0 = default;
        bool l1 = default;
        bool l2 = default;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 l3 = default;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d l4 = default;
        int l5 = default;
        this.CenterPosition = pos;
        int v3 = __cil_bool_load(((OpenRA.Actor)self).IsInWorld);
        if (v3 != 0) {
            goto IL_0010;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        return;
        IL_0010: ;
        __cil_type_0100002D v5 = self.World;
        __cil_type_01000026 v6 = v5.Map;
        // Exact call 0x06000F2E kept: direct virtual this accessor needs exact call notation.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v8 = __cil_direct_06000F2E(this);
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v9 = v6.DistanceAboveTerrain(v8);
        l0 = v9;
        int v11 = __cil_bool_load(__cil_direct_06000F6E(this));
        if (v11 == 0) {
            goto IL_0095;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v12 = l0;
        int v13 = v12.Length;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v15 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v16 = v15.MinAirborneAltitude;
        if (v13 > v16) {
            goto IL_0095;
        } else {
            goto IL_0042;
        }
        IL_0042: ;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v18 = __cil_newarr_1B0001CB(1);
        // Exact call 0x06000F30 kept: direct virtual this accessor needs exact call notation.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v21 = __cil_direct_06000F30(this);
        __cil_value_763732cf543d047a5287a4266098cf29f7836f4a v23 = __cil_value_newobj_0A001127(v21, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(0)))));
        __cil_stelem_1B0001CB(v18, 0, v23);
        l3 = v18;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v25 = this.landingCells;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v26 = l3;
        int v27 = __cil_bool_load(__cil_methodspec_call_2B000474(((__cil_ref_4087415c3703bfbaa7f9c4aa7fbcda2e2866b352)(v25)), ((__cil_ref_4087415c3703bfbaa7f9c4aa7fbcda2e2866b352)(v26))));
        if (v27 == 0) {
            goto IL_0095;
        } else {
            goto IL_006A;
        }
        IL_006A: ;
        __cil_type_0100002D v29 = self.World;
        __cil_type_01000130 v30 = v29.ActorMap;
        __cil_callvirt_0A001128(v30, self, ((__cil_type_010001EE)(this)));
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v34 = l3;
        this.landingCells = v34;
        __cil_type_0100002D v36 = self.World;
        __cil_type_01000130 v37 = v36.ActorMap;
        __cil_callvirt_0A001129(v37, self, ((__cil_type_010001EE)(this)));
        IL_0095: ;
        __cil_type_0100002D v41 = self.World;
        v41.UpdateMaps(self, ((__cil_type_010001EE)(this)));
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v44 = l0;
        int v45 = v44.Length;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v47 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v48 = v47.MinAirborneAltitude;
        int v49 = (v45 < v48 ? 1 : 0);
        int v51 = (v49 == 0 ? 1 : 0);
        l1 = __cil_bool_store(v51);
        int v52 = __cil_bool_load(l1);
        if (v52 == 0) {
            goto IL_00CC;
        } else {
            goto IL_00BC;
        }
        IL_00BC: ;
        int v54 = __cil_bool_load(this.airborne);
        if (v54 != 0) {
            goto IL_00CC;
        } else {
            goto IL_00C4;
        }
        IL_00C4: ;
        __cil_direct_06000F83(this);
        goto IL_00DD;
        IL_00CC: ;
        int v56 = __cil_bool_load(l1);
        if (v56 != 0) {
            goto IL_00DD;
        } else {
            goto IL_00CF;
        }
        IL_00CF: ;
        int v58 = __cil_bool_load(this.airborne);
        if (v58 == 0) {
            goto IL_00DD;
        } else {
            goto IL_00D7;
        }
        IL_00D7: ;
        __cil_direct_06000F84(this);
        IL_00DD: ;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v60 = l0;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v62 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v63 = v62.CruiseAltitude;
        int v64 = __cil_bool_load(OpenRA.WDist.op_Equality(v60, v63));
        l2 = __cil_bool_store(v64);
        int v65 = __cil_bool_load(l2);
        if (v65 == 0) {
            goto IL_0102;
        } else {
            goto IL_00F2;
        }
        IL_00F2: ;
        int v67 = __cil_bool_load(this.cruising);
        if (v67 != 0) {
            goto IL_0102;
        } else {
            goto IL_00FA;
        }
        IL_00FA: ;
        __cil_direct_06000F85(this);
        goto IL_0113;
        IL_0102: ;
        int v69 = __cil_bool_load(l2);
        if (v69 != 0) {
            goto IL_0113;
        } else {
            goto IL_0105;
        }
        IL_0105: ;
        int v71 = __cil_bool_load(this.cruising);
        if (v71 == 0) {
            goto IL_0113;
        } else {
            goto IL_010D;
        }
        IL_010D: ;
        __cil_direct_06000F86(this);
        IL_0113: ;
        int v74 = __cil_bool_load(this.notify);
        if (v74 == 0) {
            goto IL_014F;
        } else {
            goto IL_011B;
        }
        IL_011B: ;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v76 = this.notifyCenterPositionChanged;
        if (v76 is null) {
            goto IL_014F;
        } else {
            goto IL_0123;
        }
        IL_0123: ;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v78 = this.notifyCenterPositionChanged;
        l4 = v78;
        l5 = 0;
        goto IL_0147;
        IL_0130: ;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v80 = l4;
        int v81 = l5;
        global::OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged v82 = v80[v81];
        __cil_callvirt_06001F1B(v82, self, unchecked((byte)(0)), unchecked((byte)(0)));
        int v87 = l5;
        l5 = unchecked(v87 + 1);
        IL_0147: ;
        int v90 = l5;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v91 = l4;
        nint v92 = unchecked((nint)(v91.LongLength));
        int v93 = unchecked((int)(v92));
        if (v90 < v93) {
            goto IL_0130;
        } else {
            goto IL_014F;
        }
        IL_014F: ;
        __cil_direct_06000F68(this, self);
        return;
    }

    public void FinishedMoving(OpenRA.Actor self)
    {
        // structural signature __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d bytes=15128121021298841512872D03128095128095151181E5011287A1: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.INotifyCrushed, class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.Aircraft s3_0 = default;
        __cil_type_01000025 s3_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s3_2 = default;
        OpenRA.Mods.Common.Traits.Aircraft s4_0 = default;
        __cil_type_01000025 s4_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s4_2 = default;
        int v1 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.IsAtGroundLevel(self));
        if (v1 != 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v4 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD4;
        if (v4 is not null) {
            OpenRA.Mods.Common.Traits.Aircraft e2_4_0 = this;
            __cil_type_01000025 e2_4_1 = self;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e2_4_2 = v4;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            s4_2 = e2_4_2;
            goto IL_002A;
        } else {
            OpenRA.Mods.Common.Traits.Aircraft e2_3_0 = this;
            __cil_type_01000025 e2_3_1 = self;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e2_3_2 = v4;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            s3_2 = e2_3_2;
            goto IL_0013;
        }
        IL_0013: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v5 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF;
        nint v6 = __cil_ldftn_06003991;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v7 = __cil_newobj_0A00112B(v5, v6);
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD4 = v7;
        OpenRA.Mods.Common.Traits.Aircraft e3_4_0 = s3_0;
        __cil_type_01000025 e3_4_1 = s3_1;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e3_4_2 = v7;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        s4_2 = e3_4_2;
        IL_002A: ;
        __cil_direct_06000F6A(s4_0, s4_1, s4_2);
        return;
    }

    public void EnteringCell(OpenRA.Actor self)
    {
        // structural signature __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d bytes=15128121021298841512872D03128095128095151181E5011287A1: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.INotifyCrushed, class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.Aircraft s1_0 = default;
        __cil_type_01000025 s1_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s1_2 = default;
        OpenRA.Mods.Common.Traits.Aircraft s2_0 = default;
        __cil_type_01000025 s2_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s2_2 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v2 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD5;
        if (v2 is not null) {
            OpenRA.Mods.Common.Traits.Aircraft e0_2_0 = this;
            __cil_type_01000025 e0_2_1 = self;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e0_2_2 = v2;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            s2_2 = e0_2_2;
            goto IL_0021;
        } else {
            OpenRA.Mods.Common.Traits.Aircraft e0_1_0 = this;
            __cil_type_01000025 e0_1_1 = self;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e0_1_2 = v2;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            s1_2 = e0_1_2;
            goto IL_000A;
        }
        IL_000A: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v3 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF;
        nint v4 = __cil_ldftn_06003992;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v5 = __cil_newobj_0A00112B(v3, v4);
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD5 = v5;
        OpenRA.Mods.Common.Traits.Aircraft e1_2_0 = s1_0;
        __cil_type_01000025 e1_2_1 = s1_1;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e1_2_2 = v5;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        s2_2 = e1_2_2;
        IL_0021: ;
        __cil_direct_06000F6A(s2_0, s2_1, s2_2);
        return;
    }

    private void CrushAction(OpenRA.Actor self, System.Func<OpenRA.Mods.Common.Traits.INotifyCrushed, System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>>> action)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 bytes=151181E5011287A1: valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d bytes=15128121021298841512872D03128095128095151181E5011287A1: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.INotifyCrushed, class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 bytes=151280A10115118125011284C9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af bytes=151280A50115118125011284C9: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 bytes=15118125011284C9: valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 bytes=151280A501129884: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Mods.Common.Traits.INotifyCrushed>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 bytes=1512812102128095151280A10115118125011284C9: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d995c0c526708ec78848b40add5041ee43b0e621 bytes=151280A101129884: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyCrushed>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_395110448511d63be4531c40c9e73da5028734d3 bytes=1512872D03128095128095151181E5011287A1: class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F30 l0 = default;
        __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 l1 = default;
        __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af l2 = default;
        __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 l3 = default;
        __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 l4 = default;
        OpenRA.Mods.Common.Traits.INotifyCrushed l5 = default;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s1_0 = default;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 s1_1 = default;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s2_0 = default;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 s2_1 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F30 v0 = __cil_newobj_06003994();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F30 v1 = l0;
        __cil_type_01000025 v2 = self;
        v1.self = v2;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F30 v3 = l0;
        __cil_type_01000025 v4 = v3.self;
        __cil_type_0100002D v5 = v4.World;
        __cil_type_01000130 v6 = v5.ActorMap;
        global::OpenRA.Mods.Common.Traits.Aircraft v7 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v8 = __cil_direct_06000F30(v7);
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v9 = __cil_callvirt_0A000169(v6, v8);
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F30 v10 = l0;
        nint v11 = __cil_ldftn_06003995;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v12 = __cil_newobj_0A00019A(v10, v11);
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v13 = __cil_methodspec_call_2B000009(v9, v12);
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 v14 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD6;
        if (v14 is not null) {
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e0_2_0 = v13;
            __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 e0_2_1 = v14;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_0058;
        } else {
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e0_1_0 = v13;
            __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 e0_1_1 = v14;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_0041;
        }
        IL_0041: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v15 = OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF;
        nint v16 = __cil_ldftn_06003993;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 v17 = __cil_newobj_0A00112C(v15, v16);
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FD6 = v17;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e1_2_0 = s1_0;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 e1_2_1 = v17;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        goto IL_0058;
        IL_0058: ;
        __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 v18 = __cil_methodspec_call_2B000475(s2_0, s2_1);
        l1 = v18;
        __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 v19 = l1;
        __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v20 = __cil_callvirt_0A00112D(v19);
        l2 = v20;
        try {
            IL_0065: ;
            goto IL_00FA;
            IL_006A: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v21 = l2;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v22 = __cil_callvirt_0A00112E(v21);
            l3 = v22;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v23 = l3;
            __cil_type_01000132 v24 = v23.Trait;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v25 = l3;
            __cil_type_01000025 v26 = v25.Actor;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F30 v27 = l0;
            __cil_type_01000025 v28 = v27.self;
            global::OpenRA.Mods.Common.Traits.Aircraft v29 = this;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v30 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v29).Info;
            __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 v31 = v30.Crushes;
            int v32 = __cil_bool_load(__cil_callvirt_0A0000BB(v24, v26, v28, v31));
            if (v32 == 0) {
                goto IL_00FA;
            } else {
                goto IL_0095;
            }
            IL_0095: ;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v33 = l3;
            __cil_type_01000025 v34 = v33.Actor;
            int v35 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.IsAtGroundLevel(v34));
            if (v35 == 0) {
                goto IL_00FA;
            } else {
                goto IL_00A2;
            }
            IL_00A2: ;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v36 = l3;
            __cil_type_01000025 v37 = v36.Actor;
            __cil_ref_d995c0c526708ec78848b40add5041ee43b0e621 v38 = __cil_callvirt_2B000476(v37);
            __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v39 = __cil_callvirt_0A001131(v38);
            l4 = v39;
            try {
                IL_00B4: ;
                goto IL_00E3;
                IL_00B6: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v40 = l4;
                global::OpenRA.Mods.Common.Traits.INotifyCrushed v41 = __cil_callvirt_0A001132(v40);
                l5 = v41;
                __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v42 = action;
                global::OpenRA.Mods.Common.Traits.INotifyCrushed v43 = l5;
                __cil_ref_395110448511d63be4531c40c9e73da5028734d3 v44 = __cil_callvirt_0A001133(v42, v43);
                __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v45 = l3;
                __cil_type_01000025 v46 = v45.Actor;
                global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F30 v47 = l0;
                __cil_type_01000025 v48 = v47.self;
                global::OpenRA.Mods.Common.Traits.Aircraft v49 = this;
                global::OpenRA.Mods.Common.Traits.AircraftInfo v50 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v49).Info;
                __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 v51 = v50.Crushes;
                __cil_callvirt_0A001134(v44, v46, v48, v51);
                goto IL_00E3;
                IL_00E3: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v52 = l4;
                int v53 = __cil_bool_load(__cil_callvirt_0A00001B(v52));
                if (v53 != 0) {
                    goto IL_00B6;
                } else {
                    goto IL_00EC;
                }
                IL_00EC: ;
                goto IL_00FA;
            }
            finally {
                IL_00EE: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v54 = l4;
                if (v54 is null) {
                    goto IL_00F9;
                } else {
                    goto IL_00F2;
                }
                IL_00F2: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v55 = l4;
                __cil_callvirt_0A00001A(v55);
                goto IL_00F9;
                IL_00F9: ;
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_00FA: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v56 = l2;
            int v57 = __cil_bool_load(__cil_callvirt_0A00001B(v56));
            if (v57 != 0) {
                goto IL_006A;
            } else {
                goto IL_0105;
            }
            IL_0105: ;
            goto IL_0111;
        }
        finally {
            IL_0107: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v58 = l2;
            if (v58 is null) {
                goto IL_0110;
            } else {
                goto IL_010A;
            }
            IL_010A: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v59 = l2;
            __cil_callvirt_0A00001A(v59);
            goto IL_0110;
            IL_0110: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_0111: ;
        return;
    }

    public void AddInfluence(System.ValueTuple<OpenRA.CPos, OpenRA.Traits.SubCell>[] landingCells)
    {
        // structural signature __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 bytes=1D151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(__cil_direct_06000F6E(this));
        if (v1 == 0) {
            goto IL_0013;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        string v2 = __cil_ldstr_7001FDD4("Cannot AddInfluence until previous influence is removed with RemoveInfluence");
        global::System.InvalidOperationException v3 = __cil_newobj_0A00038A(v2);
        throw v3;
        IL_0013: ;
        this.landingCells = landingCells;
        __cil_type_01000025 v7 = this.self;
        int v8 = __cil_bool_load(((OpenRA.Actor)v7).IsInWorld);
        if (v8 == 0) {
            goto IL_0043;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        __cil_type_01000025 v10 = this.self;
        __cil_type_0100002D v11 = v10.World;
        __cil_type_01000130 v12 = v11.ActorMap;
        __cil_type_01000025 v14 = this.self;
        __cil_callvirt_0A001129(v12, v14, ((__cil_type_010001EE)(this)));
        IL_0043: ;
        return;
    }

    public void AddInfluence(OpenRA.CPos landingCell)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_763732cf543d047a5287a4266098cf29f7836f4a bytes=151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 bytes=1D151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v2 = __cil_newarr_1B0001CB(1);
        __cil_value_763732cf543d047a5287a4266098cf29f7836f4a v6 = __cil_value_newobj_0A001127(landingCell, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(0)))));
        __cil_stelem_1B0001CB(v2, 0, v6);
        __cil_direct_06000F6B(this, v2);
        return;
    }

    public void RemoveInfluence()
    {
        // structural signature __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 bytes=1D151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000025 v1 = this.self;
        int v2 = __cil_bool_load(((OpenRA.Actor)v1).IsInWorld);
        if (v2 == 0) {
            goto IL_0029;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_type_01000025 v4 = this.self;
        __cil_type_0100002D v5 = v4.World;
        __cil_type_01000130 v6 = v5.ActorMap;
        __cil_type_01000025 v8 = this.self;
        __cil_callvirt_0A001128(v6, v8, ((__cil_type_010001EE)(this)));
        IL_0029: ;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v11 = __cil_methodspec_call_2B00045F();
        this.landingCells = v11;
        return;
    }

    public bool HasInfluence()
    {
        // IL fallback: incompatible stack categories
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 7B, E7, 0C, 00, 04, 8E, 16, FE, 03, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x04000CE7 OpenRA.Mods.Common.Traits.Aircraft::landingCells
        // IL_0006: ldlen 
        // IL_0007: ldc.i4.0 0
        // IL_0008: cgt.un 
        // IL_000A: ret 
    }

    public virtual OpenRA.Activities.Activity MoveTo(OpenRA.CPos cell, int nearEnough = 0, OpenRA.Actor ignoreActor = null, bool evaluateNearestMovableCell = false, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l0 = default;
        __cil_value_afed037d079105c214a094897df496882260d1c3 l1 = default;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 l2 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_type_01000025 v1 = v0.self;
        global::OpenRA.Mods.Common.Traits.Aircraft v2 = this;
        __cil_type_01000025 v3 = v2.self;
        __cil_type_0100002D v4 = v3.World;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v5 = cell;
        int v6 = 0;
        __cil_value_afed037d079105c214a094897df496882260d1c3 v7 = OpenRA.Traits.Target.FromCell(v4, v5, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v6)))));
        l1 = v7;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v8 = ref l1;
        int v9 = nearEnough;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v10 = OpenRA.WDist.FromCells(v9);
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v11 = targetLineColor;
        l0 = v11;
        ref __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v12 = ref l2;
        v12 = default;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v13 = l2;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v14 = l0;
        global::OpenRA.Mods.Common.Activities.Fly v15 = __cil_newobj_06002320(v1, ref v8, v10, v13, v14);
        return v15;
    }

    public OpenRA.Activities.Activity MoveWithinRange(ref OpenRA.Traits.Target target, OpenRA.WDist range, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_type_01000025 v1 = v0.self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v2 = ref target;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v3 = __cil_ldsfld_0A00023E();
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v4 = range;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v5 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v6 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.Fly v7 = __cil_newobj_06002322(v1, ref v2, v3, v4, v5, v6);
        return v7;
    }

    public OpenRA.Activities.Activity MoveWithinRange(ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        __cil_type_01000025 v1 = v0.self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v2 = ref target;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v3 = minRange;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v4 = maxRange;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v5 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v6 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.Fly v7 = __cil_newobj_06002322(v1, ref v2, v3, v4, v5, v6);
        return v7;
    }

    public OpenRA.Activities.Activity MoveFollow(OpenRA.Actor self, ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        __cil_type_01000025 v0 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v1 = ref target;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v2 = minRange;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v3 = maxRange;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v4 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v5 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.FlyFollow v6 = __cil_newobj_06002335(v0, ref v1, v2, v3, v4, v5);
        return v6;
    }

    public virtual OpenRA.Activities.Activity ReturnToCell(OpenRA.Actor self)
    {
        return null;
    }

    public OpenRA.Activities.Activity MoveToTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        __cil_type_01000025 v0 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v1 = ref target;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v2 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v3 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.Fly v4 = __cil_newobj_06002321(v0, ref v1, v2, v3);
        return v4;
    }

    public OpenRA.Activities.Activity MoveIntoTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 l0 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l1 = default;
        IL_0000: ;
        __cil_type_01000025 v0 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v1 = ref target;
        ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v2 = ref l0;
        v2 = default;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v3 = l0;
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v4 = ref l1;
        v4 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v5 = l1;
        global::OpenRA.Mods.Common.Activities.Land v6 = __cil_newobj_06002343(v0, ref v1, v3, v5);
        return v6;
    }

    public OpenRA.Activities.Activity MoveOntoTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target, ref OpenRA.WVec offset, System.Nullable<OpenRA.WAngle> facing, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        __cil_type_01000025 v0 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v1 = ref target;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v2 = ref offset;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v3 = facing;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v4 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.Land v5 = __cil_newobj_06002345(v0, ref v1, ref v2, v3, v4);
        return v5;
    }

    public virtual OpenRA.Activities.Activity LocalMove(OpenRA.Actor self, OpenRA.WPos fromPos, OpenRA.WPos toPos)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132335F30 l0 = default;
        __cil_type_010001F3 l1 = default;
        __cil_value_afed037d079105c214a094897df496882260d1c3 l2 = default;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 l3 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l4 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132335F30 v0 = __cil_newobj_06003998();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132335F30 v1 = l0;
        global::OpenRA.Mods.Common.Traits.Aircraft v2 = this;
        v1.__il_field_04002FD9 = v2;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132335F30 v3 = l0;
        __cil_type_01000025 v4 = self;
        v3.self = v4;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132335F30 v5 = l0;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v6 = fromPos;
        v5.fromPos = v6;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132335F30 v7 = l0;
        nint v8 = __cil_ldftn_06003999;
        __cil_type_010000B2 v9 = __cil_newobj_0A0001CD(v7, v8);
        __cil_type_010001F3 v10 = __cil_newobj_0A0006B5(v9);
        l1 = v10;
        __cil_type_010001F3 v11 = l1;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132335F30 v12 = l0;
        __cil_type_01000025 v13 = v12.self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v14 = toPos;
        __cil_value_afed037d079105c214a094897df496882260d1c3 v15 = OpenRA.Traits.Target.FromPos(v14);
        l2 = v15;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v16 = ref l2;
        ref __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v17 = ref l3;
        v17 = default;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v18 = l3;
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v19 = ref l4;
        v19 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v20 = l4;
        global::OpenRA.Mods.Common.Activities.Fly v21 = __cil_newobj_06002321(v13, ref v16, v18, v20);
        v11.Queue(((__cil_type_0100010F)(v21)));
        __cil_type_010001F3 v22 = l1;
        return v22;
    }

    public virtual int EstimatedMoveDuration(OpenRA.Actor self, OpenRA.WPos fromPos, OpenRA.WPos toPos)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l1 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v0 = this;
        int v1 = __cil_direct_06000F52(v0);
        l0 = v1;
        int v2 = l0;
        int v3 = 0;
        if (v2 > v3) {
            goto IL_000D;
        } else {
            goto IL_000B;
        }
        IL_000B: ;
        int v4 = 0;
        return v4;
        IL_000D: ;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v5 = ref toPos;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v6 = ref fromPos;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v7 = OpenRA.WPos.op_Subtraction(ref v5, ref v6);
        l1 = v7;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v8 = ref l1;
        int v9 = __cil_memberref_call_0A000257(ref v8);
        int v10 = l0;
        int v11 = unchecked(v9 / v10);
        return v11;
    }

    public virtual OpenRA.CPos NearestMoveableCell(OpenRA.CPos cell)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        return cell;
    }

    public virtual OpenRA.Mods.Common.Traits.MovementType get_CurrentMovementTypes()
    {
        // enum storage token=0x02000695 alias=__cil_enum_02000695 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MovementType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.movementTypes));
        return unchecked((__cil_enum_02000695)(v1));
    }

    public virtual void set_CurrentMovementTypes(OpenRA.Mods.Common.Traits.MovementType value)
    {
        // structural signature __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec bytes=1D129A5C: class OpenRA.Mods.Common.Traits.INotifyMoving[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000695 alias=__cil_enum_02000695 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MovementType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000695 l0 = default;
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec l1 = default;
        int l2 = default;
        int v1 = unchecked((int)(this.movementTypes));
        l0 = unchecked((__cil_enum_02000695)(v1));
        int v3 = unchecked((int)(value));
        this.movementTypes = unchecked((__cil_enum_02000695)(v3));
        int v4 = unchecked((int)(value));
        int v5 = unchecked((int)(l0));
        if (v4 == v5) {
            goto IL_0038;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v7 = this.notifyMoving;
        l1 = v7;
        l2 = 0;
        goto IL_0032;
        IL_001D: ;
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v9 = l1;
        int v10 = l2;
        global::OpenRA.Mods.Common.Traits.INotifyMoving v11 = v9[v10];
        __cil_type_01000025 v14 = this.self;
        int v15 = unchecked((int)(value));
        __cil_callvirt_06001FE5(v11, v14, unchecked((__cil_enum_02000695)(v15)));
        int v16 = l2;
        l2 = unchecked(v16 + 1);
        IL_0032: ;
        int v19 = l2;
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v20 = l1;
        nint v21 = unchecked((nint)(v20.LongLength));
        int v22 = unchecked((int)(v21));
        if (v19 < v22) {
            goto IL_001D;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        return;
    }

    public bool CanEnterTargetNow(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_25bc23a1432014435d024b04c075b8fb4eae0690 bytes=151280A1011180ED: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_533868158cdd7853e46444536f569edd3744b65f bytes=15128121021180ED02: class [System.Runtime]System.Func`2<valuetype [OpenRA.Game]OpenRA.WPos, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132395F30 l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132395F30 v0 = __cil_newobj_0600399A();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132395F30 v1 = l0;
        __cil_type_01000025 v2 = self;
        v1.self = v2;
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132395F30 v3 = l0;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v4 = ref target;
        __cil_value_afed037d079105c214a094897df496882260d1c3 v5 = v4;
        v3.targetActor = v5;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v6 = ref target;
        __cil_ref_25bc23a1432014435d024b04c075b8fb4eae0690 v7 = __cil_memberref_call_0A00022C(ref v6);
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132395F30 v8 = l0;
        nint v9 = __cil_ldftn_0600399B;
        __cil_ref_533868158cdd7853e46444536f569edd3744b65f v10 = __cil_newobj_0A000265(v8, v9);
        int v11 = __cil_bool_load(__cil_methodspec_call_2B000477(v7, v10));
        if (v11 == 0) {
            goto IL_0034;
        } else {
            goto IL_0032;
        }
        IL_0032: ;
        int v12 = 0;
        return __cil_bool_store(v12);
        IL_0034: ;
        global::OpenRA.Mods.Common.Traits.Aircraft v13 = this;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v14 = ref target;
        __cil_type_01000025 v15 = __cil_memberref_call_0A000209(ref v14);
        __cil_direct_06000F4C(v13, v15);
        int v16 = 1;
        return __cil_bool_store(v16);
    }

    public virtual System.Collections.Generic.IEnumerable<OpenRA.Traits.IOrderTargeter> get_Orders()
    {
        // structural signature __cil_ref_d8a04e490f85e1e44ceb20f3de6c2ef1e488e08d bytes=151280A1011284ED: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.IOrderTargeter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C6765745F4F72646572733E645F5F313331 v1 = __cil_newobj_060039A6(-2);
        v1.__il_field_04002FE7 = this;
        return v1;
    }

    public OpenRA.Order IssueOrder(OpenRA.Actor self, OpenRA.Traits.IOrderTargeter order, ref OpenRA.Traits.Target target, bool queued)
    {
        // IL fallback: external allocation needs dependency facts: constructor parameter is byref or modified
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, FD, 10, 00, 0A, 2D, 5A, 04, 6F, 5C, 08, 00, 0A, 72, 6F, FE, 01, 70, 28, BD, 02, 00, 0A]
        // .code-bytes IL_0018: [2D, 36, 04, 6F, 5C, 08, 00, 0A, 72, 7B, FE, 01, 70, 28, BD, 02, 00, 0A, 2D, 24, 04, 6F, 5C, 08]
        // .code-bytes IL_0030: [00, 0A, 72, 85, FE, 01, 70, 28, BD, 02, 00, 0A, 2D, 12, 04, 6F, 5C, 08, 00, 0A, 72, 8F, FE, 01]
        // .code-bytes IL_0048: [70, 28, BD, 02, 00, 0A, 2C, 12, 04, 6F, 5C, 08, 00, 0A, 03, 05, 0E, 04, 14, 14, 73, E2, 10, 00]
        // .code-bytes IL_0060: [0A, 2A, 14, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x0A0010FD class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::get_IsTraitDisabled
        // IL_0006: brtrue.s IL_0062
        // IL_0008: ldarg.2 2
        // IL_0009: callvirt 0x0A00085C [OpenRA.Game]OpenRA.Traits.IOrderTargeter::get_OrderID
        // IL_000E: ldstr 0x7001FE6F [69, 110, 116, 101, 114] utf16-bytes=[45, 00, 6E, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0013: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0018: brtrue.s IL_0050
        // IL_001A: ldarg.2 2
        // IL_001B: callvirt 0x0A00085C [OpenRA.Game]OpenRA.Traits.IOrderTargeter::get_OrderID
        // IL_0020: ldstr 0x7001FE7B [77, 111, 118, 101] utf16-bytes=[4D, 00, 6F, 00, 76, 00, 65, 00] terminal-flag=Some(0)
        // IL_0025: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_002A: brtrue.s IL_0050
        // IL_002C: ldarg.2 2
        // IL_002D: callvirt 0x0A00085C [OpenRA.Game]OpenRA.Traits.IOrderTargeter::get_OrderID
        // IL_0032: ldstr 0x7001FE85 [76, 97, 110, 100] utf16-bytes=[4C, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_0037: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_003C: brtrue.s IL_0050
        // IL_003E: ldarg.2 2
        // IL_003F: callvirt 0x0A00085C [OpenRA.Game]OpenRA.Traits.IOrderTargeter::get_OrderID
        // IL_0044: ldstr 0x7001FE8F [70, 111, 114, 99, 101, 69, 110, 116, 101, 114] utf16-bytes=[46, 00, 6F, 00, 72, 00, 63, 00, 65, 00, 45, 00, 6E, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0049: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_004E: brfalse.s IL_0062
        // IL_0050: ldarg.2 2
        // IL_0051: callvirt 0x0A00085C [OpenRA.Game]OpenRA.Traits.IOrderTargeter::get_OrderID
        // IL_0056: ldarg.1 1
        // IL_0057: ldarg.3 3
        // IL_0058: ldarg.s 4
        // IL_005A: ldnull 
        // IL_005B: ldnull 
        // IL_005C: newobj 0x0A0010E2 [OpenRA.Game]OpenRA.Order::.ctor
        // IL_0061: ret 
        // IL_0062: ldnull 
        // IL_0063: ret 
    }

    private virtual OpenRA.Order __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E4949737375654465706C6F794F726465722E49737375654465706C6F794F72646572(OpenRA.Actor self, bool queued)
    {
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d382e2d71aa569a08589f6a7ea7aeebdbeeb8f57 bytes=1D128095: class [OpenRA.Game]OpenRA.Actor[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // Exact call 0x0A0010FD kept: property syntax needs a nongeneric class owner.
        int v1 = __cil_bool_load(__cil_direct_0A0010FD(this));
        if (v1 != 0) {
            return null;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v3 = this.rearmable;
        if (v3 is null) {
            return null;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v5 = this.rearmable;
        global::OpenRA.Mods.Common.Traits.RearmableInfo v6 = v5.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v7 = v6.RearmActors;
        int v8 = __cil_callvirt_0A00029F(v7);
        if (!(v8 != 0)) {
            return null;
        }
        string v9 = __cil_ldstr_7001FEA5("ReturnToBase");
        int v11 = __cil_bool_load(queued);
        __cil_type_01000046 v12 = __cil_newobj_0A000BDD(v9, self, v11, null, null);
        return v12;
    }

    private virtual bool __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E4949737375654465706C6F794F726465722E43616E49737375654465706C6F794F72646572(OpenRA.Actor self, bool queued)
    {
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.Rearmable v1 = this.rearmable;
        if (v1 is null) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Mods.Common.Traits.Rearmable v3 = this.rearmable;
        global::OpenRA.Mods.Common.Traits.RearmableInfo v4 = v3.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v5 = v4.RearmActors;
        int v6 = __cil_callvirt_0A00029F(v5);
        return (v6 > 0);
    }

    public virtual string VoicePhraseForOrder(OpenRA.Actor self, OpenRA.Order order)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, FD, 10, 00, 0A, 2C, 02, 14, 2A, 04, 7B, 5D, 08, 00, 0A, 0A, 06, 39, 6C, 01, 00, 00, 06]
        // .code-bytes IL_0018: [28, D8, 03, 00, 0A, 0B, 07, 1A, 59, 45, 09, 00, 00, 00, 05, 00, 00, 00, 5A, 00, 00, 00, 39, 01]
        // .code-bytes IL_0030: [00, 00, 84, 00, 00, 00, 39, 01, 00, 00, 39, 01, 00, 00, 6F, 00, 00, 00, 39, 01, 00, 00, 96, 00]
        // .code-bytes IL_0048: [00, 00, 38, 34, 01, 00, 00, 06, 16, 28, 74, 04, 00, 0A, 0C, 08, 1F, 4C, 2E, 0F, 08, 1F, 4D, 2E]
        // .code-bytes IL_0060: [1C, 08, 1F, 53, 2E, 29, 38, 18, 01, 00, 00, 06, 72, 85, FE, 01, 70, 28, BD, 02, 00, 0A, 2D, 7A]
        // .code-bytes IL_0078: [38, 06, 01, 00, 00, 06, 72, 7B, FE, 01, 70, 28, BD, 02, 00, 0A, 2D, 68, 38, F4, 00, 00, 00, 06]
        // .code-bytes IL_0090: [72, BF, FE, 01, 70, 28, BD, 02, 00, 0A, 3A, AA, 00, 00, 00, 38, DF, 00, 00, 00, 06, 72, 6F, FE]
        // .code-bytes IL_00A8: [01, 70, 28, BD, 02, 00, 0A, 3A, 95, 00, 00, 00, 38, CA, 00, 00, 00, 06, 72, 8F, FE, 01, 70, 28]
        // .code-bytes IL_00C0: [BD, 02, 00, 0A, 3A, 80, 00, 00, 00, 38, B5, 00, 00, 00, 06, 72, C9, FE, 01, 70, 28, BD, 02, 00]
        // .code-bytes IL_00D8: [0A, 2D, 6E, 38, A3, 00, 00, 00, 06, 72, A5, FE, 01, 70, 28, BD, 02, 00, 0A, 2D, 68, 38, 91, 00]
        // .code-bytes IL_00F0: [00, 00, 02, 7B, DB, 06, 00, 0A, 7B, BC, 0C, 00, 04, 2D, 3E, 04, 6F, 7F, 0D, 00, 0A, 28, 08, 02]
        // .code-bytes IL_0108: [00, 0A, 2C, 31, 03, 7B, 59, 01, 00, 0A, 7B, 5A, 01, 00, 0A, 04, 6F, 7F, 0D, 00, 0A, 28, 7F, 02]
        // .code-bytes IL_0120: [00, 0A, 6F, 90, 02, 00, 0A, 0D, 03, 6F, 60, 01, 00, 0A, 7B, 3F, 08, 00, 0A, 09, 6F, 04, 02, 00]
        // .code-bytes IL_0138: [0A, 2D, 02, 14, 2A, 02, 7B, DB, 06, 00, 0A, 7B, BF, 0C, 00, 04, 2A, 02, 7B, DB, 06, 00, 0A, 7B]
        // .code-bytes IL_0150: [BF, 0C, 00, 04, 2A, 02, 7B, DB, 0C, 00, 04, 2C, 18, 02, 7B, DB, 0C, 00, 04, 7B, CB, 15, 00, 04]
        // .code-bytes IL_0168: [7B, C9, 15, 00, 04, 6F, 9F, 02, 00, 0A, 16, 30, 02, 14, 2A, 02, 7B, DB, 06, 00, 0A, 7B, BF, 0C]
        // .code-bytes IL_0180: [00, 04, 2A, 14, 2A]
        // .local [0] string
        // .local [1] int32
        // .local [2] char
        // .local [3] valuetype [OpenRA.Game]OpenRA.CPos
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x0A0010FD class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::get_IsTraitDisabled
        // IL_0006: brfalse.s IL_000A
        // IL_0008: ldnull 
        // IL_0009: ret 
        // IL_000A: ldarg.2 2
        // IL_000B: ldfld 0x0A00085D [OpenRA.Game]OpenRA.Order::OrderString
        // IL_0010: stloc.0 0
        // IL_0011: ldloc.0 0
        // IL_0012: brfalse IL_0183
        // IL_0017: ldloc.0 0
        // IL_0018: call 0x0A0003D8 [System.Runtime]System.String::get_Length
        // IL_001D: stloc.1 1
        // IL_001E: ldloc.1 1
        // IL_001F: ldc.i4.4 4
        // IL_0020: sub 
        // IL_0021: switch IL_004F, IL_00A4, IL_0183, IL_00CE, IL_0183, IL_0183, IL_00B9, IL_0183, IL_00E0
        // IL_004A: br IL_0183
        // IL_004F: ldloc.0 0
        // IL_0050: ldc.i4.0 0
        // IL_0051: call 0x0A000474 [System.Runtime]System.String::get_Chars
        // IL_0056: stloc.2 2
        // IL_0057: ldloc.2 2
        // IL_0058: ldc.i4.s 76
        // IL_005A: beq.s IL_006B
        // IL_005C: ldloc.2 2
        // IL_005D: ldc.i4.s 77
        // IL_005F: beq.s IL_007D
        // IL_0061: ldloc.2 2
        // IL_0062: ldc.i4.s 83
        // IL_0064: beq.s IL_008F
        // IL_0066: br IL_0183
        // IL_006B: ldloc.0 0
        // IL_006C: ldstr 0x7001FE85 [76, 97, 110, 100] utf16-bytes=[4C, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_0071: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0076: brtrue.s IL_00F2
        // IL_0078: br IL_0183
        // IL_007D: ldloc.0 0
        // IL_007E: ldstr 0x7001FE7B [77, 111, 118, 101] utf16-bytes=[4D, 00, 6F, 00, 76, 00, 65, 00] terminal-flag=Some(0)
        // IL_0083: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0088: brtrue.s IL_00F2
        // IL_008A: br IL_0183
        // IL_008F: ldloc.0 0
        // IL_0090: ldstr 0x7001FEBF [83, 116, 111, 112] utf16-bytes=[53, 00, 74, 00, 6F, 00, 70, 00] terminal-flag=Some(0)
        // IL_0095: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_009A: brtrue IL_0149
        // IL_009F: br IL_0183
        // IL_00A4: ldloc.0 0
        // IL_00A5: ldstr 0x7001FE6F [69, 110, 116, 101, 114] utf16-bytes=[45, 00, 6E, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00AA: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_00AF: brtrue IL_0149
        // IL_00B4: br IL_0183
        // IL_00B9: ldloc.0 0
        // IL_00BA: ldstr 0x7001FE8F [70, 111, 114, 99, 101, 69, 110, 116, 101, 114] utf16-bytes=[46, 00, 6F, 00, 72, 00, 63, 00, 65, 00, 45, 00, 6E, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00BF: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_00C4: brtrue IL_0149
        // IL_00C9: br IL_0183
        // IL_00CE: ldloc.0 0
        // IL_00CF: ldstr 0x7001FEC9 [83, 99, 97, 116, 116, 101, 114] utf16-bytes=[53, 00, 63, 00, 61, 00, 74, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00D4: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_00D9: brtrue.s IL_0149
        // IL_00DB: br IL_0183
        // IL_00E0: ldloc.0 0
        // IL_00E1: ldstr 0x7001FEA5 [82, 101, 116, 117, 114, 110, 84, 111, 66, 97, 115, 101] utf16-bytes=[52, 00, 65, 00, 74, 00, 75, 00, 72, 00, 6E, 00, 54, 00, 6F, 00, 42, 00, 61, 00, 73, 00, 65, 00] terminal-flag=Some(0)
        // IL_00E6: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_00EB: brtrue.s IL_0155
        // IL_00ED: br IL_0183
        // IL_00F2: ldarg.0 0
        // IL_00F3: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_00F8: ldfld 0x04000CBC OpenRA.Mods.Common.Traits.AircraftInfo::MoveIntoShroud
        // IL_00FD: brtrue.s IL_013D
        // IL_00FF: ldarg.2 2
        // IL_0100: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_0105: call 0x0A000208 [OpenRA.Game]OpenRA.Traits.Target::get_Type
        // IL_010A: brfalse.s IL_013D
        // IL_010C: ldarg.1 1
        // IL_010D: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0112: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0117: ldarg.2 2
        // IL_0118: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_011D: call 0x0A00027F [OpenRA.Game]OpenRA.Traits.Target::get_CenterPosition
        // IL_0122: callvirt 0x0A000290 [OpenRA.Game]OpenRA.Map::CellContaining
        // IL_0127: stloc.3 3
        // IL_0128: ldarg.1 1
        // IL_0129: callvirt 0x0A000160 [OpenRA.Game]OpenRA.Actor::get_Owner
        // IL_012E: ldfld 0x0A00083F [OpenRA.Game]OpenRA.Player::Shroud
        // IL_0133: ldloc.3 3
        // IL_0134: callvirt 0x0A000204 [OpenRA.Game]OpenRA.Traits.Shroud::IsExplored
        // IL_0139: brtrue.s IL_013D
        // IL_013B: ldnull 
        // IL_013C: ret 
        // IL_013D: ldarg.0 0
        // IL_013E: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_0143: ldfld 0x04000CBF OpenRA.Mods.Common.Traits.AircraftInfo::Voice
        // IL_0148: ret 
        // IL_0149: ldarg.0 0
        // IL_014A: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_014F: ldfld 0x04000CBF OpenRA.Mods.Common.Traits.AircraftInfo::Voice
        // IL_0154: ret 
        // IL_0155: ldarg.0 0
        // IL_0156: ldfld 0x04000CDB OpenRA.Mods.Common.Traits.Aircraft::rearmable
        // IL_015B: brfalse.s IL_0175
        // IL_015D: ldarg.0 0
        // IL_015E: ldfld 0x04000CDB OpenRA.Mods.Common.Traits.Aircraft::rearmable
        // IL_0163: ldfld 0x040015CB OpenRA.Mods.Common.Traits.Rearmable::Info
        // IL_0168: ldfld 0x040015C9 OpenRA.Mods.Common.Traits.RearmableInfo::RearmActors
        // IL_016D: callvirt 0x0A00029F class [System.Collections]System.Collections.Generic.HashSet`1<string>::get_Count
        // IL_0172: ldc.i4.0 0
        // IL_0173: bgt.s IL_0177
        // IL_0175: ldnull 
        // IL_0176: ret 
        // IL_0177: ldarg.0 0
        // IL_0178: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_017D: ldfld 0x04000CBF OpenRA.Mods.Common.Traits.AircraftInfo::Voice
        // IL_0182: ret 
        // IL_0183: ldnull 
        // IL_0184: ret 
    }

    public virtual void ResolveOrder(OpenRA.Actor self, OpenRA.Order order)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, FD, 10, 00, 0A, 2C, 01, 2A, 04, 7B, 5D, 08, 00, 0A, 0A, 06, 72, 7B, FE, 01, 70, 28, BD]
        // .code-bytes IL_0018: [02, 00, 0A, 39, B6, 00, 00, 00, 04, 6F, 7F, 0D, 00, 0A, 03, 28, E1, 06, 00, 0A, 2D, 01, 2A, 03]
        // .code-bytes IL_0030: [7B, 59, 01, 00, 0A, 7B, 5A, 01, 00, 0A, 03, 7B, 59, 01, 00, 0A, 7B, 5A, 01, 00, 0A, 04, 6F, 7F]
        // .code-bytes IL_0048: [0D, 00, 0A, 28, 7F, 02, 00, 0A, 6F, 90, 02, 00, 0A, 6F, 36, 11, 00, 0A, 0B, 02, 7B, DB, 06, 00]
        // .code-bytes IL_0060: [0A, 7B, BC, 0C, 00, 04, 2D, 14, 03, 6F, 60, 01, 00, 0A, 7B, 3F, 08, 00, 0A, 07, 6F, 04, 02, 00]
        // .code-bytes IL_0078: [0A, 2D, 01, 2A, 04, 7B, 37, 11, 00, 0A, 2D, 06, 02, 28, 4E, 0F, 00, 06, 03, 7B, 59, 01, 00, 0A]
        // .code-bytes IL_0090: [07, 16, 28, AA, 02, 00, 0A, 0C, 03, 04, 7B, 37, 11, 00, 0A, 03, 12, 02, 1E, 28, 82, 02, 00, 0A]
        // .code-bytes IL_00A8: [12, 03, 02, 7B, DB, 06, 00, 0A, 7B, C0, 0C, 00, 04, 28, A4, 06, 00, 0A, 12, 04, FE, 15, D9, 01]
        // .code-bytes IL_00C0: [00, 1B, 11, 04, 09, 73, 20, 23, 00, 06, 6F, FA, 06, 00, 0A, 03, 28, A2, 1A, 00, 06, 2A, 06, 72]
        // .code-bytes IL_00D8: [85, FE, 01, 70, 28, BD, 02, 00, 0A, 39, B4, 00, 00, 00, 04, 6F, 7F, 0D, 00, 0A, 03, 28, E1, 06]
        // .code-bytes IL_00F0: [00, 0A, 2D, 01, 2A, 03, 7B, 59, 01, 00, 0A, 7B, 5A, 01, 00, 0A, 03, 7B, 59, 01, 00, 0A, 7B, 5A]
        // .code-bytes IL_0108: [01, 00, 0A, 04, 6F, 7F, 0D, 00, 0A, 28, 7F, 02, 00, 0A, 6F, 90, 02, 00, 0A, 6F, 36, 11, 00, 0A]
        // .code-bytes IL_0120: [13, 05, 02, 7B, DB, 06, 00, 0A, 7B, BC, 0C, 00, 04, 2D, 15, 03, 6F, 60, 01, 00, 0A, 7B, 3F, 08]
        // .code-bytes IL_0138: [00, 0A, 11, 05, 6F, 04, 02, 00, 0A, 2D, 01, 2A, 04, 7B, 37, 11, 00, 0A, 2D, 06, 02, 28, 4E, 0F]
        // .code-bytes IL_0150: [00, 06, 03, 7B, 59, 01, 00, 0A, 11, 05, 16, 28, AA, 02, 00, 0A, 13, 06, 03, 04, 7B, 37, 11, 00]
        // .code-bytes IL_0168: [0A, 03, 12, 06, 12, 03, 02, 7B, DB, 06, 00, 0A, 7B, C0, 0C, 00, 04, 28, A4, 06, 00, 0A, 12, 07]
        // .code-bytes IL_0180: [FE, 15, 04, 03, 00, 1B, 11, 07, 09, 73, 43, 23, 00, 06, 6F, FA, 06, 00, 0A, 03, 28, A2, 1A, 00]
        // .code-bytes IL_0198: [06, 2A, 06, 72, 6F, FE, 01, 70, 28, BD, 02, 00, 0A, 2D, 1D, 06, 72, 8F, FE, 01, 70, 28, BD, 02]
        // .code-bytes IL_01B0: [00, 0A, 2D, 10, 06, 72, D9, FE, 01, 70, 28, BD, 02, 00, 0A, 39, 99, 00, 00, 00, 04, 6F, 7F, 0D]
        // .code-bytes IL_01C8: [00, 0A, 28, 08, 02, 00, 0A, 17, 2E, 01, 2A, 04, 6F, 7F, 0D, 00, 0A, 28, 09, 02, 00, 0A, 13, 08]
        // .code-bytes IL_01E0: [06, 72, 8F, FE, 01, 70, 28, BD, 02, 00, 0A, 13, 09, 02, 11, 08, 11, 09, 2D, 10, 02, 7B, DB, 06]
        // .code-bytes IL_01F8: [00, 0A, 7B, C7, 0C, 00, 04, 16, FE, 01, 2B, 01, 17, 28, 51, 0F, 00, 06, 13, 0A, 11, 0A, 2C, 0A]
        // .code-bytes IL_0210: [11, 08, 03, 28, 70, 12, 00, 06, 2D, 01, 2A, 04, 7B, 37, 11, 00, 0A, 2D, 06, 02, 28, 4E, 0F, 00]
        // .code-bytes IL_0228: [06, 11, 09, 2D, 10, 02, 7B, DB, 06, 00, 0A, 7B, C7, 0C, 00, 04, 16, FE, 01, 2B, 01, 17, 13, 0B]
        // .code-bytes IL_0240: [03, 04, 7B, 37, 11, 00, 0A, 03, 11, 08, 11, 0B, 73, 4A, 23, 00, 06, 6F, FA, 06, 00, 0A, 03, 28]
        // .code-bytes IL_0258: [A2, 1A, 00, 06, 2A, 06, 72, BF, FE, 01, 70, 28, BD, 02, 00, 0A, 2C, 30, 03, 6F, 1F, 11, 00, 0A]
        // .code-bytes IL_0270: [75, 9D, 07, 00, 02, 2D, 15, 03, 6F, 1F, 11, 00, 0A, 75, 7C, 07, 00, 02, 2C, 09, 02, 28, 4B, 0F]
        // .code-bytes IL_0288: [00, 06, 2C, 01, 2A, 03, 6F, 81, 02, 00, 0A, 02, 28, 4E, 0F, 00, 06, 2A, 06, 72, A5, FE, 01, 70]
        // .code-bytes IL_02A0: [28, BD, 02, 00, 0A, 2C, 6B, 02, 7B, DB, 0C, 00, 04, 2C, 2C, 02, 7B, DB, 0C, 00, 04, 7B, CB, 15]
        // .code-bytes IL_02B8: [00, 04, 7B, C9, 15, 00, 04, 6F, 9F, 02, 00, 0A, 2C, 15, 03, 6F, 1F, 11, 00, 0A, 75, 7C, 07, 00]
        // .code-bytes IL_02D0: [02, 2D, 08, 02, 28, 4B, 0F, 00, 06, 2C, 01, 2A, 04, 7B, 37, 11, 00, 0A, 2D, 06, 02, 28, 4E, 0F]
        // .code-bytes IL_02E8: [00, 06, 03, 04, 7B, 37, 11, 00, 0A, 03, 14, 02, 7B, DB, 06, 00, 0A, 7B, C7, 0C, 00, 04, 16, FE]
        // .code-bytes IL_0300: [01, 73, 4A, 23, 00, 06, 6F, FA, 06, 00, 0A, 03, 28, A2, 1A, 00, 06, 2A, 06, 72, C9, FE, 01, 70]
        // .code-bytes IL_0318: [28, BD, 02, 00, 0A, 2C, 18, 03, 04, 7B, 37, 11, 00, 0A, 03, 73, FD, 0E, 00, 06, 6F, FA, 06, 00]
        // .code-bytes IL_0330: [0A, 03, 28, A2, 1A, 00, 06, 2A]
        // .local [0] string
        // .local [1] valuetype [OpenRA.Game]OpenRA.CPos
        // .local [2] valuetype [OpenRA.Game]OpenRA.Traits.Target
        // .local [3] valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // .local [4] valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>
        // .local [5] valuetype [OpenRA.Game]OpenRA.CPos
        // .local [6] valuetype [OpenRA.Game]OpenRA.Traits.Target
        // .local [7] valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>
        // .local [8] class [OpenRA.Game]OpenRA.Actor
        // .local [9] bool
        // .local [10] bool
        // .local [11] bool
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x0A0010FD class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::get_IsTraitDisabled
        // IL_0006: brfalse.s IL_0009
        // IL_0008: ret 
        // IL_0009: ldarg.2 2
        // IL_000A: ldfld 0x0A00085D [OpenRA.Game]OpenRA.Order::OrderString
        // IL_000F: stloc.0 0
        // IL_0010: ldloc.0 0
        // IL_0011: ldstr 0x7001FE7B [77, 111, 118, 101] utf16-bytes=[4D, 00, 6F, 00, 76, 00, 65, 00] terminal-flag=Some(0)
        // IL_0016: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_001B: brfalse IL_00D6
        // IL_0020: ldarg.2 2
        // IL_0021: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_0026: ldarg.1 1
        // IL_0027: call 0x0A0006E1 [OpenRA.Game]OpenRA.Traits.Target::IsValidFor
        // IL_002C: brtrue.s IL_002F
        // IL_002E: ret 
        // IL_002F: ldarg.1 1
        // IL_0030: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0035: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_003A: ldarg.1 1
        // IL_003B: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0040: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0045: ldarg.2 2
        // IL_0046: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_004B: call 0x0A00027F [OpenRA.Game]OpenRA.Traits.Target::get_CenterPosition
        // IL_0050: callvirt 0x0A000290 [OpenRA.Game]OpenRA.Map::CellContaining
        // IL_0055: callvirt 0x0A001136 [OpenRA.Game]OpenRA.Map::Clamp
        // IL_005A: stloc.1 1
        // IL_005B: ldarg.0 0
        // IL_005C: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_0061: ldfld 0x04000CBC OpenRA.Mods.Common.Traits.AircraftInfo::MoveIntoShroud
        // IL_0066: brtrue.s IL_007C
        // IL_0068: ldarg.1 1
        // IL_0069: callvirt 0x0A000160 [OpenRA.Game]OpenRA.Actor::get_Owner
        // IL_006E: ldfld 0x0A00083F [OpenRA.Game]OpenRA.Player::Shroud
        // IL_0073: ldloc.1 1
        // IL_0074: callvirt 0x0A000204 [OpenRA.Game]OpenRA.Traits.Shroud::IsExplored
        // IL_0079: brtrue.s IL_007C
        // IL_007B: ret 
        // IL_007C: ldarg.2 2
        // IL_007D: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_0082: brtrue.s IL_008A
        // IL_0084: ldarg.0 0
        // IL_0085: call 0x06000F4E OpenRA.Mods.Common.Traits.Aircraft::UnReserve
        // IL_008A: ldarg.1 1
        // IL_008B: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0090: ldloc.1 1
        // IL_0091: ldc.i4.0 0
        // IL_0092: call 0x0A0002AA [OpenRA.Game]OpenRA.Traits.Target::FromCell
        // IL_0097: stloc.2 2
        // IL_0098: ldarg.1 1
        // IL_0099: ldarg.2 2
        // IL_009A: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_009F: ldarg.1 1
        // IL_00A0: ldloca.s 2
        // IL_00A2: ldc.i4.8 8
        // IL_00A3: call 0x0A000282 [OpenRA.Game]OpenRA.WDist::FromCells
        // IL_00A8: ldloca.s 3
        // IL_00AA: ldarg.0 0
        // IL_00AB: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_00B0: ldfld 0x04000CC0 OpenRA.Mods.Common.Traits.AircraftInfo::TargetLineColor
        // IL_00B5: call 0x0A0006A4 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>::.ctor
        // IL_00BA: ldloca.s 4
        // IL_00BC: initobj 0x1B0001D9 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>
        // IL_00C2: ldloc.s 4
        // IL_00C4: ldloc.3 3
        // IL_00C5: newobj 0x06002320 OpenRA.Mods.Common.Activities.Fly::.ctor
        // IL_00CA: callvirt 0x0A0006FA [OpenRA.Game]OpenRA.Actor::QueueActivity
        // IL_00CF: ldarg.1 1
        // IL_00D0: call 0x06001AA2 OpenRA.Mods.Common.Traits.LineTargetExts::ShowTargetLines
        // IL_00D5: ret 
        // IL_00D6: ldloc.0 0
        // IL_00D7: ldstr 0x7001FE85 [76, 97, 110, 100] utf16-bytes=[4C, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_00DC: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_00E1: brfalse IL_019A
        // IL_00E6: ldarg.2 2
        // IL_00E7: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_00EC: ldarg.1 1
        // IL_00ED: call 0x0A0006E1 [OpenRA.Game]OpenRA.Traits.Target::IsValidFor
        // IL_00F2: brtrue.s IL_00F5
        // IL_00F4: ret 
        // IL_00F5: ldarg.1 1
        // IL_00F6: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_00FB: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0100: ldarg.1 1
        // IL_0101: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0106: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_010B: ldarg.2 2
        // IL_010C: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_0111: call 0x0A00027F [OpenRA.Game]OpenRA.Traits.Target::get_CenterPosition
        // IL_0116: callvirt 0x0A000290 [OpenRA.Game]OpenRA.Map::CellContaining
        // IL_011B: callvirt 0x0A001136 [OpenRA.Game]OpenRA.Map::Clamp
        // IL_0120: stloc.s 5
        // IL_0122: ldarg.0 0
        // IL_0123: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_0128: ldfld 0x04000CBC OpenRA.Mods.Common.Traits.AircraftInfo::MoveIntoShroud
        // IL_012D: brtrue.s IL_0144
        // IL_012F: ldarg.1 1
        // IL_0130: callvirt 0x0A000160 [OpenRA.Game]OpenRA.Actor::get_Owner
        // IL_0135: ldfld 0x0A00083F [OpenRA.Game]OpenRA.Player::Shroud
        // IL_013A: ldloc.s 5
        // IL_013C: callvirt 0x0A000204 [OpenRA.Game]OpenRA.Traits.Shroud::IsExplored
        // IL_0141: brtrue.s IL_0144
        // IL_0143: ret 
        // IL_0144: ldarg.2 2
        // IL_0145: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_014A: brtrue.s IL_0152
        // IL_014C: ldarg.0 0
        // IL_014D: call 0x06000F4E OpenRA.Mods.Common.Traits.Aircraft::UnReserve
        // IL_0152: ldarg.1 1
        // IL_0153: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0158: ldloc.s 5
        // IL_015A: ldc.i4.0 0
        // IL_015B: call 0x0A0002AA [OpenRA.Game]OpenRA.Traits.Target::FromCell
        // IL_0160: stloc.s 6
        // IL_0162: ldarg.1 1
        // IL_0163: ldarg.2 2
        // IL_0164: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_0169: ldarg.1 1
        // IL_016A: ldloca.s 6
        // IL_016C: ldloca.s 3
        // IL_016E: ldarg.0 0
        // IL_016F: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_0174: ldfld 0x04000CC0 OpenRA.Mods.Common.Traits.AircraftInfo::TargetLineColor
        // IL_0179: call 0x0A0006A4 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>::.ctor
        // IL_017E: ldloca.s 7
        // IL_0180: initobj 0x1B000304 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>
        // IL_0186: ldloc.s 7
        // IL_0188: ldloc.3 3
        // IL_0189: newobj 0x06002343 OpenRA.Mods.Common.Activities.Land::.ctor
        // IL_018E: callvirt 0x0A0006FA [OpenRA.Game]OpenRA.Actor::QueueActivity
        // IL_0193: ldarg.1 1
        // IL_0194: call 0x06001AA2 OpenRA.Mods.Common.Traits.LineTargetExts::ShowTargetLines
        // IL_0199: ret 
        // IL_019A: ldloc.0 0
        // IL_019B: ldstr 0x7001FE6F [69, 110, 116, 101, 114] utf16-bytes=[45, 00, 6E, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01A0: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_01A5: brtrue.s IL_01C4
        // IL_01A7: ldloc.0 0
        // IL_01A8: ldstr 0x7001FE8F [70, 111, 114, 99, 101, 69, 110, 116, 101, 114] utf16-bytes=[46, 00, 6F, 00, 72, 00, 63, 00, 65, 00, 45, 00, 6E, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01AD: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_01B2: brtrue.s IL_01C4
        // IL_01B4: ldloc.0 0
        // IL_01B5: ldstr 0x7001FED9 [82, 101, 112, 97, 105, 114] utf16-bytes=[52, 00, 65, 00, 70, 00, 61, 00, 69, 00, 72, 00] terminal-flag=Some(0)
        // IL_01BA: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_01BF: brfalse IL_025D
        // IL_01C4: ldarg.2 2
        // IL_01C5: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_01CA: call 0x0A000208 [OpenRA.Game]OpenRA.Traits.Target::get_Type
        // IL_01CF: ldc.i4.1 1
        // IL_01D0: beq.s IL_01D3
        // IL_01D2: ret 
        // IL_01D3: ldarg.2 2
        // IL_01D4: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_01D9: call 0x0A000209 [OpenRA.Game]OpenRA.Traits.Target::get_Actor
        // IL_01DE: stloc.s 8
        // IL_01E0: ldloc.0 0
        // IL_01E1: ldstr 0x7001FE8F [70, 111, 114, 99, 101, 69, 110, 116, 101, 114] utf16-bytes=[46, 00, 6F, 00, 72, 00, 63, 00, 65, 00, 45, 00, 6E, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01E6: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_01EB: stloc.s 9
        // IL_01ED: ldarg.0 0
        // IL_01EE: ldloc.s 8
        // IL_01F0: ldloc.s 9
        // IL_01F2: brtrue.s IL_0204
        // IL_01F4: ldarg.0 0
        // IL_01F5: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_01FA: ldfld 0x04000CC7 OpenRA.Mods.Common.Traits.AircraftInfo::TakeOffOnResupply
        // IL_01FF: ldc.i4.0 0
        // IL_0200: ceq 
        // IL_0202: br.s IL_0205
        // IL_0204: ldc.i4.1 1
        // IL_0205: call 0x06000F51 OpenRA.Mods.Common.Traits.Aircraft::AircraftCanResupplyAt
        // IL_020A: stloc.s 10
        // IL_020C: ldloc.s 10
        // IL_020E: brfalse.s IL_021A
        // IL_0210: ldloc.s 8
        // IL_0212: ldarg.1 1
        // IL_0213: call 0x06001270 OpenRA.Mods.Common.Traits.Reservable::IsAvailableFor
        // IL_0218: brtrue.s IL_021B
        // IL_021A: ret 
        // IL_021B: ldarg.2 2
        // IL_021C: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_0221: brtrue.s IL_0229
        // IL_0223: ldarg.0 0
        // IL_0224: call 0x06000F4E OpenRA.Mods.Common.Traits.Aircraft::UnReserve
        // IL_0229: ldloc.s 9
        // IL_022B: brtrue.s IL_023D
        // IL_022D: ldarg.0 0
        // IL_022E: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_0233: ldfld 0x04000CC7 OpenRA.Mods.Common.Traits.AircraftInfo::TakeOffOnResupply
        // IL_0238: ldc.i4.0 0
        // IL_0239: ceq 
        // IL_023B: br.s IL_023E
        // IL_023D: ldc.i4.1 1
        // IL_023E: stloc.s 11
        // IL_0240: ldarg.1 1
        // IL_0241: ldarg.2 2
        // IL_0242: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_0247: ldarg.1 1
        // IL_0248: ldloc.s 8
        // IL_024A: ldloc.s 11
        // IL_024C: newobj 0x0600234A OpenRA.Mods.Common.Activities.ReturnToBase::.ctor
        // IL_0251: callvirt 0x0A0006FA [OpenRA.Game]OpenRA.Actor::QueueActivity
        // IL_0256: ldarg.1 1
        // IL_0257: call 0x06001AA2 OpenRA.Mods.Common.Traits.LineTargetExts::ShowTargetLines
        // IL_025C: ret 
        // IL_025D: ldloc.0 0
        // IL_025E: ldstr 0x7001FEBF [83, 116, 111, 112] utf16-bytes=[53, 00, 74, 00, 6F, 00, 70, 00] terminal-flag=Some(0)
        // IL_0263: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0268: brfalse.s IL_029A
        // IL_026A: ldarg.1 1
        // IL_026B: callvirt 0x0A00111F [OpenRA.Game]OpenRA.Actor::get_CurrentActivity
        // IL_0270: isinst 0x0200079D OpenRA.Mods.Common.Activities.Resupply
        // IL_0275: brtrue.s IL_028C
        // IL_0277: ldarg.1 1
        // IL_0278: callvirt 0x0A00111F [OpenRA.Game]OpenRA.Actor::get_CurrentActivity
        // IL_027D: isinst 0x0200077C OpenRA.Mods.Common.Activities.ReturnToBase
        // IL_0282: brfalse.s IL_028D
        // IL_0284: ldarg.0 0
        // IL_0285: call 0x06000F4B OpenRA.Mods.Common.Traits.Aircraft::GetActorBelow
        // IL_028A: brfalse.s IL_028D
        // IL_028C: ret 
        // IL_028D: ldarg.1 1
        // IL_028E: callvirt 0x0A000281 [OpenRA.Game]OpenRA.Actor::CancelActivity
        // IL_0293: ldarg.0 0
        // IL_0294: call 0x06000F4E OpenRA.Mods.Common.Traits.Aircraft::UnReserve
        // IL_0299: ret 
        // IL_029A: ldloc.0 0
        // IL_029B: ldstr 0x7001FEA5 [82, 101, 116, 117, 114, 110, 84, 111, 66, 97, 115, 101] utf16-bytes=[52, 00, 65, 00, 74, 00, 75, 00, 72, 00, 6E, 00, 54, 00, 6F, 00, 42, 00, 61, 00, 73, 00, 65, 00] terminal-flag=Some(0)
        // IL_02A0: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_02A5: brfalse.s IL_0312
        // IL_02A7: ldarg.0 0
        // IL_02A8: ldfld 0x04000CDB OpenRA.Mods.Common.Traits.Aircraft::rearmable
        // IL_02AD: brfalse.s IL_02DB
        // IL_02AF: ldarg.0 0
        // IL_02B0: ldfld 0x04000CDB OpenRA.Mods.Common.Traits.Aircraft::rearmable
        // IL_02B5: ldfld 0x040015CB OpenRA.Mods.Common.Traits.Rearmable::Info
        // IL_02BA: ldfld 0x040015C9 OpenRA.Mods.Common.Traits.RearmableInfo::RearmActors
        // IL_02BF: callvirt 0x0A00029F class [System.Collections]System.Collections.Generic.HashSet`1<string>::get_Count
        // IL_02C4: brfalse.s IL_02DB
        // IL_02C6: ldarg.1 1
        // IL_02C7: callvirt 0x0A00111F [OpenRA.Game]OpenRA.Actor::get_CurrentActivity
        // IL_02CC: isinst 0x0200077C OpenRA.Mods.Common.Activities.ReturnToBase
        // IL_02D1: brtrue.s IL_02DB
        // IL_02D3: ldarg.0 0
        // IL_02D4: call 0x06000F4B OpenRA.Mods.Common.Traits.Aircraft::GetActorBelow
        // IL_02D9: brfalse.s IL_02DC
        // IL_02DB: ret 
        // IL_02DC: ldarg.2 2
        // IL_02DD: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_02E2: brtrue.s IL_02EA
        // IL_02E4: ldarg.0 0
        // IL_02E5: call 0x06000F4E OpenRA.Mods.Common.Traits.Aircraft::UnReserve
        // IL_02EA: ldarg.1 1
        // IL_02EB: ldarg.2 2
        // IL_02EC: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_02F1: ldarg.1 1
        // IL_02F2: ldnull 
        // IL_02F3: ldarg.0 0
        // IL_02F4: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
        // IL_02F9: ldfld 0x04000CC7 OpenRA.Mods.Common.Traits.AircraftInfo::TakeOffOnResupply
        // IL_02FE: ldc.i4.0 0
        // IL_02FF: ceq 
        // IL_0301: newobj 0x0600234A OpenRA.Mods.Common.Activities.ReturnToBase::.ctor
        // IL_0306: callvirt 0x0A0006FA [OpenRA.Game]OpenRA.Actor::QueueActivity
        // IL_030B: ldarg.1 1
        // IL_030C: call 0x06001AA2 OpenRA.Mods.Common.Traits.LineTargetExts::ShowTargetLines
        // IL_0311: ret 
        // IL_0312: ldloc.0 0
        // IL_0313: ldstr 0x7001FEC9 [83, 99, 97, 116, 116, 101, 114] utf16-bytes=[53, 00, 63, 00, 61, 00, 74, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0318: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_031D: brfalse.s IL_0337
        // IL_031F: ldarg.1 1
        // IL_0320: ldarg.2 2
        // IL_0321: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_0326: ldarg.1 1
        // IL_0327: newobj 0x06000EFD OpenRA.Mods.Common.Traits.Nudge::.ctor
        // IL_032C: callvirt 0x0A0006FA [OpenRA.Game]OpenRA.Actor::QueueActivity
        // IL_0331: ldarg.1 1
        // IL_0332: call 0x06001AA2 OpenRA.Mods.Common.Traits.LineTargetExts::ShowTargetLines
        // IL_0337: ret 
    }

    private void OnAirborneAltitudeReached()
    {
        int v1 = __cil_bool_load(this.airborne);
        if (v1 == 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        this.airborne = __cil_bool_store(1);
        int v5 = this.airborneToken;
        if (unchecked((uint)v5) != unchecked((uint)-1)) {
            goto IL_0035;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        __cil_type_01000025 v9 = this.self;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v11 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        string v12 = v11.AirborneCondition;
        int v13 = v9.GrantCondition(v12);
        this.airborneToken = v13;
        IL_0035: ;
        return;
    }

    private void OnAirborneAltitudeLeft()
    {
        int v1 = __cil_bool_load(this.airborne);
        if (v1 != 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        this.airborne = __cil_bool_store(0);
        int v5 = this.airborneToken;
        if (v5 == -1) {
            goto IL_0030;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        __cil_type_01000025 v9 = this.self;
        int v11 = this.airborneToken;
        int v12 = v9.RevokeCondition(v11);
        this.airborneToken = v12;
        IL_0030: ;
        return;
    }

    private void OnCruisingAltitudeReached()
    {
        int v1 = __cil_bool_load(this.cruising);
        if (v1 == 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        this.cruising = __cil_bool_store(1);
        int v5 = this.cruisingToken;
        if (unchecked((uint)v5) != unchecked((uint)-1)) {
            goto IL_0035;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        __cil_type_01000025 v9 = this.self;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v11 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        string v12 = v11.CruisingCondition;
        int v13 = v9.GrantCondition(v12);
        this.cruisingToken = v13;
        IL_0035: ;
        return;
    }

    private void OnCruisingAltitudeLeft()
    {
        int v1 = __cil_bool_load(this.cruising);
        if (v1 != 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        this.cruising = __cil_bool_store(0);
        int v5 = this.cruisingToken;
        if (v5 == -1) {
            goto IL_0030;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        __cil_type_01000025 v9 = this.self;
        int v11 = this.cruisingToken;
        int v12 = v9.RevokeCondition(v11);
        this.cruisingToken = v12;
        IL_0030: ;
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F746966794163746F72446973706F73696E672E446973706F73696E67(OpenRA.Actor self)
    {
        __cil_direct_06000F4E(this);
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494163746F7250726576696577496E69744D6F6469666965722E4D6F646966794163746F7250726576696577496E6974(OpenRA.Actor self, OpenRA.Primitives.TypeDictionary inits)
    {
        // structural signature __cil_ref_2101340a7cf04e0a72d3ac50eec9e2a858dbdf30 bytes=151280DD011180CD: class [System.Runtime]System.Func`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(__cil_callvirt_2B000478(inits));
        if (v1 != 0) {
            goto IL_0027;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v3 = __cil_bool_load(__cil_callvirt_2B000479(inits));
        if (v3 != 0) {
            goto IL_0027;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        nint v6 = __cil_ldftn_06000F96;
        __cil_ref_2101340a7cf04e0a72d3ac50eec9e2a858dbdf30 v7 = __cil_newobj_0A0002AE(this, v6);
        global::OpenRA.Mods.Common.DynamicFacingInit v8 = __cil_newobj_0600008E(v7);
        inits.Add(((object)(v8)));
        IL_0027: ;
        return;
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E5472616974732E494372656174696F6E41637469766974792E4765744372656174696F6E4163746976697479()
    {
        // structural signature __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba bytes=1D1180A9: valuetype [OpenRA.Game]OpenRA.CPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v1 = this.creationRallyPoint;
        if (v1 is not null) {
            goto IL_0019;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v3 = this.creationActivityDelay;
        if (v3 > 0) {
            goto IL_0019;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        int v6 = __cil_bool_load(this.creationByMap);
        if (v6 == 0) {
            return null;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        int v9 = this.creationActivityDelay;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v11 = this.creationRallyPoint;
        int v13 = __cil_bool_load(this.creationByMap);
        global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v14 = __cil_newobj_0600397C(this, v9, v11, v13);
        return v14;
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F766557697468696E52616E6765(ref OpenRA.Traits.Target target, OpenRA.WDist range, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 28, 70, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: call 0x06000F70 OpenRA.Mods.Common.Traits.Aircraft::MoveWithinRange
        // IL_000B: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F766557697468696E52616E6765(ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 28, 71, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: ldarg.s 5
        // IL_0008: call 0x06000F71 OpenRA.Mods.Common.Traits.Aircraft::MoveWithinRange
        // IL_000D: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F7665466F6C6C6F77(OpenRA.Actor self, ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 0E, 06, 28, 72, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: ldarg.s 5
        // IL_0008: ldarg.s 6
        // IL_000A: call 0x06000F72 OpenRA.Mods.Common.Traits.Aircraft::MoveFollow
        // IL_000F: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F7665546F546172676574(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 28, 74, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: call 0x06000F74 OpenRA.Mods.Common.Traits.Aircraft::MoveToTarget
        // IL_000B: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F7665496E746F546172676574(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 28, 75, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: call 0x06000F75 OpenRA.Mods.Common.Traits.Aircraft::MoveIntoTarget
        // IL_0008: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F76654F6E746F546172676574(OpenRA.Actor self, ref OpenRA.Traits.Target target, ref OpenRA.WVec offset, System.Nullable<OpenRA.WAngle> facing, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 28, 76, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: ldarg.s 5
        // IL_0008: call 0x06000F76 OpenRA.Mods.Common.Traits.Aircraft::MoveOntoTarget
        // IL_000D: ret 
    }

    private virtual bool __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E43616E456E7465725461726765744E6F77(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 28, 7C, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: call 0x06000F7C OpenRA.Mods.Common.Traits.Aircraft::CanEnterTargetNow
        // IL_0008: ret 
    }

    private virtual OpenRA.Order __name_4F70656E52412E5472616974732E4949737375654F726465722E49737375654F72646572(OpenRA.Actor self, OpenRA.Traits.IOrderTargeter order, ref OpenRA.Traits.Target target, bool queued)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 28, 7E, 0F, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: call 0x06000F7E OpenRA.Mods.Common.Traits.Aircraft::IssueOrder
        // IL_000B: ret 
    }

    private System.Collections.Generic.IEnumerable<OpenRA.Traits.VariableObserver> __name_3C3E6E5F5F30()
    {
        // structural signature __cil_ref_01e870d823b7fa5ebe8ad38c5e4fee9884ac243a bytes=151280A1011187C5: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_01e870d823b7fa5ebe8ad38c5e4fee9884ac243a v1 = __cil_direct_0A00113B(this);
        return v1;
    }

    // Metadata name: <get_Orders>b__131_0
    private bool get_OrdersLambda131_0(OpenRA.Actor target, OpenRA.Traits.TargetModifiers modifiers)
    {
        // enum storage token=0x0200012E alias=__cil_enum_0200012E underlying=int: global::@OpenRA.@Traits.@TargetModifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.Mods.Common.Traits.AircraftInfo v1 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v2 = __cil_bool_load(v1.CanForceLand);
        if (v2 == 0) {
            return false;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v3 = unchecked((int)(modifiers));
        int v5 = __cil_bool_load(OpenRA.Traits.TargetModifiersExts.HasModifier(unchecked((OpenRA.Traits.TargetModifiers)(v3)), unchecked((OpenRA.Traits.TargetModifiers)(4))));
        if (v5 == 0) {
            return false;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        return __cil_direct_06000F50(this, target);
    }

    // Metadata name: <get_Orders>b__131_1
    private bool get_OrdersLambda131_1(OpenRA.Actor target)
    {
        __cil_type_01000025 v2 = this.self;
        int v3 = __cil_bool_load(OpenRA.Mods.Common.Traits.Reservable.IsAvailableFor(target, v2));
        if (v3 == 0) {
            return false;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        return __cil_direct_06000F51(this, target, __cil_bool_store(1));
    }

    // Metadata name: <get_Orders>b__131_2
    private bool get_OrdersLambda131_2(OpenRA.Actor target)
    {
        __cil_type_01000025 v2 = this.self;
        int v3 = __cil_bool_load(OpenRA.Mods.Common.Traits.Reservable.IsAvailableFor(target, v2));
        if (v3 == 0) {
            return false;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        global::OpenRA.Mods.Common.Traits.AircraftInfo v7 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)this).Info;
        int v8 = __cil_bool_load(v7.TakeOffOnResupply);
        int v10 = (v8 == 0 ? 1 : 0);
        return __cil_direct_06000F51(this, target, __cil_bool_store(v10));
    }

    private OpenRA.WAngle __name_3C4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494163746F7250726576696577496E69744D6F6469666965722E4D6F646966794163746F7250726576696577496E69743E625F5F3134325F30()
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06000F26 kept: direct virtual this accessor needs exact call notation.
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v1 = __cil_direct_06000F26(this);
        return v1;
    }
    // property OpenRA.WAngle Facing { get: get_Facing; set: set_Facing; }
    // property OpenRA.WAngle Pitch { get: get_Pitch; set: set_Pitch; }
    // property OpenRA.WAngle Roll { get: get_Roll; set: set_Roll; }
    // property OpenRA.WRot Orientation { get: get_Orientation; set: set_Orientation; }
    // property OpenRA.WPos CenterPosition { get: get_CenterPosition; set: set_CenterPosition; }
    // property OpenRA.CPos TopLeft { get: get_TopLeft; }
    // property OpenRA.WAngle TurnSpeed { get: get_TurnSpeed; }
    // property System.Nullable<OpenRA.WAngle> IdleTurnSpeed { get: get_IdleTurnSpeed; }
    // property OpenRA.Actor ReservedActor { get: get_ReservedActor; set: set_ReservedActor; }
    // property bool MayYieldReservation { get: get_MayYieldReservation; set: set_MayYieldReservation; }
    // property bool ForceLanding { get: get_ForceLanding; set: set_ForceLanding; }
    // property bool AtLandAltitude { get: get_AtLandAltitude; }
    // property OpenRA.WDist LandAltitude { get: get_LandAltitude; }
    // property int MovementSpeed { get: get_MovementSpeed; }
    // property int IdleMovementSpeed { get: get_IdleMovementSpeed; }
    // property OpenRA.Mods.Common.Traits.MovementType CurrentMovementTypes { get: get_CurrentMovementTypes; set: set_CurrentMovementTypes; }
    // property System.Collections.Generic.IEnumerable<OpenRA.Traits.IOrderTargeter> Orders { get: get_Orders; }

    private sealed class AssociateWithAirfieldActivity : OpenRA.Activities.Activity
    {
        private readonly OpenRA.Mods.Common.Traits.Aircraft aircraft;
        private readonly int delay;
        private readonly OpenRA.CPos[] rallyPoint;
        private readonly bool creationByMap;

        public AssociateWithAirfieldActivity(OpenRA.Mods.Common.Traits.Aircraft self, int delay, OpenRA.CPos[] rallyPoint, bool creationByMap) : base()
        {
            // structural signature __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba bytes=1D1180A9: valuetype [OpenRA.Game]OpenRA.CPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            this.aircraft = self;
            this.delay = delay;
            this.rallyPoint = rallyPoint;
            int v8 = __cil_bool_load(creationByMap);
            this.creationByMap = __cil_bool_store(v8);
            return;
        }

        protected override void OnFirstRun(OpenRA.Actor self)
        {
            // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 bytes=11C00040BC: valuetype OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<>c__DisplayClass5_0; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 l0 = default;
            IL_0000: ;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v0 = ref l0;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v1 = this;
            v0.__il_field_04003DCF = v1;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v2 = ref l0;
            __cil_type_01000025 v3 = self;
            v2.self = v3;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v4 = ref l0;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v5 = l0;
            __cil_type_01000025 v6 = v5.self;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v7 = ((OpenRA.Actor)v6).Location;
            v4.cpos = v7;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v8 = ref l0;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v9 = l0;
            __cil_type_01000025 v10 = v9.self;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v11 = ((OpenRA.Actor)v10).CenterPosition;
            v8.pos = v11;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v12 = this;
            int v13 = __cil_bool_load(v12.creationByMap);
            if (v13 == 0) {
                goto IL_0136;
            } else {
                goto IL_003F;
            }
            IL_003F: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v14 = this;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v15 = ref l0;
            int v16 = __cil_bool_load(__cil_direct_06003981(v14, ref v15));
            if (v16 == 0) {
                goto IL_004A;
            } else {
                goto IL_0049;
            }
            IL_0049: ;
            return;
            IL_004A: ;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v17 = ref l0;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v18 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v19 = v18.pos;
            int v20 = v19.X;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v21 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v22 = v21.pos;
            int v23 = v22.Y;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v24 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v25 = v24.pos;
            int v26 = v25.Z;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v27 = l0;
            __cil_type_01000025 v28 = v27.self;
            __cil_type_0100002D v29 = v28.World;
            __cil_type_01000026 v30 = v29.Map;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v31 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v32 = v31.pos;
            __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v33 = v30.DistanceAboveTerrain(v32);
            int v34 = v33.Length;
            int v35 = unchecked(v26 - v34);
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v36 = __cil_newobj_0A000676(v20, v23, v35);
            v17.pos = v36;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v37 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v38 = v37.aircraft;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v39 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v38).Info;
            int v40 = __cil_bool_load(v39.TakeOffOnCreation);
            if (v40 != 0) {
                goto IL_00E8;
            } else {
                goto IL_00AA;
            }
            IL_00AA: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v41 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v42 = v41.aircraft;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v43 = l0;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v44 = v43.cpos;
            int v45 = 1;
            int v46 = __cil_bool_load(__cil_callvirt_06000F59(v42, v44, ((__cil_type_01000025)(null)), __cil_bool_store(v45)));
            if (v46 == 0) {
                goto IL_00E8;
            } else {
                goto IL_00BF;
            }
            IL_00BF: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v47 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v48 = v47.aircraft;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v49 = l0;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v50 = v49.cpos;
            __cil_callvirt_06000F6C(v48, v50);
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v51 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v52 = v51.aircraft;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v53 = l0;
            __cil_type_01000025 v54 = v53.self;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v55 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v56 = v55.pos;
            __cil_callvirt_06000F67(v52, v54, v56);
            return;
            IL_00E8: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v57 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v58 = v57.aircraft;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v59 = l0;
            __cil_type_01000025 v60 = v59.self;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v61 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v62 = v61.pos;
            int v63 = v62.X;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v64 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v65 = v64.pos;
            int v66 = v65.Y;
            __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v67 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v68 = v67.pos;
            int v69 = v68.Z;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v70 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v71 = v70.aircraft;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v72 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v71).Info;
            ref __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v73 = ref __cil_ldflda_04000CAB(v72);
            int v74 = v73.Length;
            int v75 = unchecked(v69 + v74);
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v76 = __cil_newobj_0A000676(v63, v66, v75);
            __cil_callvirt_06000F67(v58, v60, v76);
            return;
            IL_0136: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v77 = this;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v78 = ref l0;
            int v79 = __cil_bool_load(__cil_direct_06003981(v77, ref v78));
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v80 = this;
            int v81 = v80.delay;
            int v82 = 0;
            if (v81 <= v82) {
                goto IL_0159;
            } else {
                goto IL_0148;
            }
            IL_0148: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v83 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v84 = this;
            int v85 = v84.delay;
            global::OpenRA.Mods.Common.Activities.Wait v86 = __cil_newobj_06002418(v85);
            v83.QueueChild(((__cil_type_0100010F)(v86)));
            goto IL_0159;
            IL_0159: ;
            return;
        }

        public override bool Tick(OpenRA.Actor self)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba bytes=1D1180A9: valuetype [OpenRA.Game]OpenRA.CPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_40e290c8149402cb137a30da4a330e9a4e3017bb bytes=151280DD0112843D: class [System.Runtime]System.Func`1<class [OpenRA.Game]OpenRA.Activities.Activity>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba l0 = default;
            int l1 = default;
            global::OpenRA.Mods.Common.Traits.Aircraft v1 = this.aircraft;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v2 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v1).Info;
            int v3 = __cil_bool_load(v2.TakeOffOnCreation);
            if (v3 == 0) {
                return true;
            } else {
                goto IL_0012;
            }
            IL_0012: ;
            int v5 = __cil_bool_load(base.IsCanceling);
            if (!(v5 == 0)) {
                return true;
            }
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v8 = this.rallyPoint;
            if (v8 is null) {
                goto IL_0075;
            } else {
                goto IL_0024;
            }
            IL_0024: ;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v10 = this.rallyPoint;
            nint v11 = unchecked((nint)(v10.LongLength));
            if (v11 == 0) {
                goto IL_0075;
            } else {
                goto IL_002D;
            }
            IL_002D: ;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v13 = this.rallyPoint;
            l0 = v13;
            l1 = 0;
            goto IL_006F;
            IL_0038: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C3E635F5F446973706C6179436C617373365F30 v15 = __cil_newobj_060048A9();
            v15.__il_field_04003DD4 = this;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v19 = l0;
            int v20 = l1;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v21 = __cil_ldelem_0100002A(v19, v20);
            v15.cell = v21;
            nint v25 = __cil_ldftn_060048AA;
            __cil_ref_40e290c8149402cb137a30da4a330e9a4e3017bb v26 = __cil_newobj_0A0006DF(v15, v25);
            global::OpenRA.Mods.Common.Activities.AttackMoveActivity v28 = __cil_newobj_060023A5(self, v26, 0);
            this.QueueChild(((__cil_type_0100010F)(v28)));
            int v29 = l1;
            l1 = unchecked(v29 + 1);
            IL_006F: ;
            int v32 = l1;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v33 = l0;
            nint v34 = unchecked((nint)(v33.LongLength));
            int v35 = unchecked((int)(v34));
            if (v32 < v35) {
                goto IL_0038;
            } else {
                goto IL_0075;
            }
            IL_0075: ;
            int v37 = __cil_bool_load(this.creationByMap);
            if (v37 != 0) {
                return true;
            } else {
                goto IL_007D;
            }
            IL_007D: ;
            global::OpenRA.Mods.Common.Traits.Aircraft v39 = this.aircraft;
            __cil_callvirt_06000F4E(v39);
            return true;
        }

        public override System.Collections.Generic.IEnumerable<OpenRA.Traits.Target> GetTargets(OpenRA.Actor self)
        {
            // IL fallback: incompatible value/receiver types
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 28, 95, 19, 00, 0A, 2C, 0D, 02, 28, 95, 19, 00, 0A, 03, 6F, B1, 19, 00, 0A, 2A, 7E, B2, 19]
            // .code-bytes IL_0018: [00, 0A, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: call 0x0A001995 [OpenRA.Game]OpenRA.Activities.Activity::get_ChildActivity
            // IL_0006: brfalse.s IL_0015
            // IL_0008: ldarg.0 0
            // IL_0009: call 0x0A001995 [OpenRA.Game]OpenRA.Activities.Activity::get_ChildActivity
            // IL_000E: ldarg.1 1
            // IL_000F: callvirt 0x0A0019B1 [OpenRA.Game]OpenRA.Activities.Activity::GetTargets
            // IL_0014: ret 
            // IL_0015: ldsfld 0x0A0019B2 [OpenRA.Game]OpenRA.Traits.Target::None
            // IL_001A: ret 
        }

        public override System.Collections.Generic.IEnumerable<OpenRA.Activities.TargetLineNode> TargetLineNodes(OpenRA.Actor self)
        {
            // structural signature __cil_ref_4e389d8c3c1b8026c50ecd35a07e0b9ef1427db9 bytes=151280A10112879D: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v1 = __cil_newobj_060048AB(-2);
            v1.__il_field_04003DD8 = this;
            v1.__il_field_04003DDA = self;
            return v1;
        }

        private bool __name_3C4F6E466972737452756E3E675F5F547279446F636B7C355F30(ref OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C3E635F5F446973706C6179436C617373355F30 arg0)
        {
            // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 bytes=11C00040BC: valuetype OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<>c__DisplayClass5_0; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_a1d2d3c9edf358a8967c5d9e19410f83329ede5d bytes=1512812102128C4C02: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.Exit, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000025 l0 = default;
            OpenRA.Mods.Common.Traits.Exit l1 = default;
            IL_0000: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v0 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v1 = v0.aircraft;
            __cil_type_01000025 v2 = __cil_callvirt_06000F4B(v1);
            l0 = v2;
            __cil_type_01000025 v3 = l0;
            if (v3 is null) {
                goto IL_0107;
            } else {
                goto IL_0012;
            }
            IL_0012: ;
            __cil_type_01000025 v4 = l0;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v5 = ref arg0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v6 = v5.pos;
            global::OpenRA.Mods.Common.Traits.Exit v7 = OpenRA.Mods.Common.Traits.ExitExts.NearestExitOrDefault(v4, v6, ((string)(null)), ((__cil_ref_a1d2d3c9edf358a8967c5d9e19410f83329ede5d)(null)));
            l1 = v7;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v8 = ref arg0;
            __cil_type_01000025 v9 = l0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v10 = ((OpenRA.Actor)v9).CenterPosition;
            v8.pos = v10;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v11 = ref arg0;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v12 = ref arg0;
            ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v13 = ref v12.pos;
            int v14 = v13.X;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v15 = ref arg0;
            ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v16 = ref v15.pos;
            int v17 = v16.Y;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v18 = ref arg0;
            ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v19 = ref v18.pos;
            int v20 = v19.Z;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v21 = ref arg0;
            __cil_type_01000025 v22 = v21.self;
            __cil_type_0100002D v23 = v22.World;
            __cil_type_01000026 v24 = v23.Map;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v25 = ref arg0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v26 = v25.pos;
            __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v27 = v24.DistanceAboveTerrain(v26);
            int v28 = v27.Length;
            int v29 = unchecked(v20 - v28);
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v30 = __cil_newobj_0A000676(v14, v17, v29);
            v11.pos = v30;
            global::OpenRA.Mods.Common.Traits.Exit v31 = l1;
            if (v31 is null) {
                goto IL_00C6;
            } else {
                goto IL_007D;
            }
            IL_007D: ;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v32 = ref arg0;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v33 = ref arg0;
            ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v34 = ref v33.pos;
            global::OpenRA.Mods.Common.Traits.Exit v35 = l1;
            global::OpenRA.Mods.Common.Traits.ExitInfo v36 = ((__cil_ref_29396d75fd85592a95bcd5d00bdcd73afc4ddfa5)v35).Info;
            ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v37 = ref __cil_ldflda_04000F12(v36);
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v38 = OpenRA.WPos.op_Addition(ref v34, ref v37);
            v32.pos = v38;
            global::OpenRA.Mods.Common.Traits.Exit v39 = l1;
            global::OpenRA.Mods.Common.Traits.ExitInfo v40 = ((__cil_ref_29396d75fd85592a95bcd5d00bdcd73afc4ddfa5)v39).Info;
            ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v41 = ref __cil_ldflda_04000F14(v40);
            int v42 = __cil_bool_load(__cil_value_call_0A001111(ref v41));
            if (v42 == 0) {
                goto IL_00C6;
            } else {
                goto IL_00AB;
            }
            IL_00AB: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v43 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v44 = v43.aircraft;
            global::OpenRA.Mods.Common.Traits.Exit v45 = l1;
            global::OpenRA.Mods.Common.Traits.ExitInfo v46 = ((__cil_ref_29396d75fd85592a95bcd5d00bdcd73afc4ddfa5)v45).Info;
            ref __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v47 = ref __cil_ldflda_04000F14(v46);
            __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v48 = __cil_value_call_0A0013CF(ref v47);
            __cil_callvirt_06000F27(v44, v48);
            goto IL_00C6;
            IL_00C6: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v49 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v50 = v49.aircraft;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v51 = ref arg0;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v52 = v51.cpos;
            __cil_callvirt_06000F6C(v50, v52);
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v53 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v54 = v53.aircraft;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v55 = ref arg0;
            __cil_type_01000025 v56 = v55.self;
            ref __cil_value_cc22386d15f956e524ffb144199ca5d19507e0e5 v57 = ref arg0;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v58 = v57.pos;
            __cil_callvirt_06000F67(v54, v56, v58);
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v59 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v60 = v59.aircraft;
            __cil_type_01000025 v61 = l0;
            __cil_callvirt_06000F4C(v60, v61);
            global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v62 = this;
            global::OpenRA.Mods.Common.Traits.Aircraft v63 = v62.aircraft;
            __cil_callvirt_06000F4D(v63);
            int v64 = 1;
            return __cil_bool_store(v64);
            IL_0107: ;
            int v65 = 0;
            return __cil_bool_store(v65);
        }

        private struct __name_3C3E635F5F446973706C6179436C617373355F30
        {
            public OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity __il_field_04003DCF;
            public OpenRA.WPos pos;
            public OpenRA.Actor self;
            public OpenRA.CPos cpos;
        }

        private sealed class __name_3C3E635F5F446973706C6179436C617373365F30
        {
            public OpenRA.CPos cell;
            public OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity __il_field_04003DD4;

            public __name_3C3E635F5F446973706C6179436C617373365F30() : base()
            {
                return;
            }

            // Metadata name: <Tick>b__0
            internal OpenRA.Activities.Activity TickLambda0()
            {
                // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v1 = this.__il_field_04003DD4;
                global::OpenRA.Mods.Common.Traits.Aircraft v2 = v1.aircraft;
                __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v4 = this.cell;
                __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v7 = OpenRA.Primitives.Color.get_OrangeRed();
                __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v8 = __cil_value_newobj_0A0006A4(v7);
                __cil_type_0100010F v9 = __cil_callvirt_06000F6F(v2, v4, 1, ((__cil_type_01000025)(null)), __cil_bool_store(1), v8);
                return v9;
            }
        }

        private sealed class __name_3C5461726765744C696E654E6F6465733E645F5F38 : System.Collections.Generic.IEnumerable<OpenRA.Activities.TargetLineNode>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Activities.TargetLineNode>, System.Collections.IEnumerator, System.IDisposable
        {
            private int __il_field_04003DD5;
            private OpenRA.Activities.TargetLineNode __il_field_04003DD6;
            private int __il_field_04003DD7;
            public OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity __il_field_04003DD8;
            private OpenRA.Actor self;
            public OpenRA.Actor __il_field_04003DDA;
            private OpenRA.Activities.Activity __il_field_04003DDB;
            private System.Collections.Generic.IEnumerator<OpenRA.Activities.TargetLineNode> __il_field_04003DDC;

            public __name_3C5461726765744C696E654E6F6465733E645F5F38(int __name_3C3E315F5F7374617465) : base()
            {
                this.__il_field_04003DD5 = __name_3C3E315F5F7374617465;
                int v4 = System.Environment.get_CurrentManagedThreadId();
                this.__il_field_04003DD7 = v4;
                return;
            }

            private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                int l0 = default;
                IL_0000: ;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v0 = this;
                int v1 = v0.__il_field_04003DD5;
                l0 = v1;
                int v2 = l0;
                int v3 = -3;
                if (v2 == v3) {
                    goto IL_0010;
                } else {
                    goto IL_000C;
                }
                IL_000C: ;
                int v4 = l0;
                int v5 = 1;
                if (unchecked((uint)v4) != unchecked((uint)v5)) {
                    goto IL_001A;
                } else {
                    goto IL_0010;
                }
                IL_0010: ;
                try {
                    IL_0011: ;
                    goto IL_001A;
                }
                finally {
                    IL_0013: ;
                    global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v6 = this;
                    __cil_direct_060048AE(v6);
                    goto __cil_finally_end_0;
                    __cil_finally_end_0: ;
                }
                IL_001A: ;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v7 = this;
                v7.__il_field_04003DDB = null;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v8 = this;
                v8.__il_field_04003DDC = null;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v9 = this;
                int v10 = -2;
                v9.__il_field_04003DD5 = v10;
                return;
            }

            private virtual bool MoveNext()
            {
                // IL fallback: EH fault handlers need exceptional-only cleanup
                // .maxstack 3
                // .initlocals true
                // .code-bytes IL_0000: [02, 7B, D5, 3D, 00, 04, 0B, 02, 7B, D8, 3D, 00, 04, 0C, 07, 2C, 0B, 07, 17, 2E, 70, 16, 0A, DD]
                // .code-bytes IL_0018: [B2, 00, 00, 00, 02, 15, 7D, D5, 3D, 00, 04, 02, 08, 28, 95, 19, 00, 0A, 7D, DB, 3D, 00, 04, 38]
                // .code-bytes IL_0030: [84, 00, 00, 00, 02, 7B, DB, 3D, 00, 04, 6F, 29, 16, 00, 0A, 2D, 66, 02, 02, 7B, DB, 3D, 00, 04]
                // .code-bytes IL_0048: [02, 7B, D9, 3D, 00, 04, 6F, 2A, 16, 00, 0A, 6F, 89, 00, 00, 0A, 7D, DC, 3D, 00, 04, 02, 1F, FD]
                // .code-bytes IL_0060: [7D, D5, 3D, 00, 04, 2B, 26, 02, 7B, DC, 3D, 00, 04, 6F, 88, 00, 00, 0A, 0D, 02, 09, 7D, D6, 3D]
                // .code-bytes IL_0078: [00, 04, 02, 17, 7D, D5, 3D, 00, 04, 17, 0A, DE, 49, 02, 1F, FD, 7D, D5, 3D, 00, 04, 02, 7B, DC]
                // .code-bytes IL_0090: [3D, 00, 04, 6F, 1B, 00, 00, 0A, 2D, CD, 02, 28, AE, 48, 00, 06, 02, 14, 7D, DC, 3D, 00, 04, 02]
                // .code-bytes IL_00A8: [02, 7B, DB, 3D, 00, 04, 6F, 86, 11, 00, 0A, 7D, DB, 3D, 00, 04, 02, 7B, DB, 3D, 00, 04, 3A, 71]
                // .code-bytes IL_00C0: [FF, FF, FF, 16, 0A, DE, 07, 02, 28, AC, 48, 00, 06, DC, 06, 2A]
                // .local [0] bool
                // .local [1] int32
                // .local [2] class OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity
                // .local [3] class [OpenRA.Game]OpenRA.Activities.TargetLineNode
                // IL_0000: ldarg.0 0
                // IL_0001: ldfld 0x04003DD5 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>1__state
                // IL_0006: stloc.1 1
                // IL_0007: ldarg.0 0
                // IL_0008: ldfld 0x04003DD8 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>4__this
                // IL_000D: stloc.2 2
                // IL_000E: ldloc.1 1
                // IL_000F: brfalse.s IL_001C
                // IL_0011: ldloc.1 1
                // IL_0012: ldc.i4.1 1
                // IL_0013: beq.s IL_0085
                // IL_0015: ldc.i4.0 0
                // IL_0016: stloc.0 0
                // IL_0017: leave IL_00CE
                // IL_001C: ldarg.0 0
                // IL_001D: ldc.i4.m1 -1
                // IL_001E: stfld 0x04003DD5 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>1__state
                // IL_0023: ldarg.0 0
                // IL_0024: ldloc.2 2
                // IL_0025: call 0x0A001995 [OpenRA.Game]OpenRA.Activities.Activity::get_ChildActivity
                // IL_002A: stfld 0x04003DDB OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<a>5__2
                // IL_002F: br IL_00B8
                // IL_0034: ldarg.0 0
                // IL_0035: ldfld 0x04003DDB OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<a>5__2
                // IL_003A: callvirt 0x0A001629 [OpenRA.Game]OpenRA.Activities.Activity::get_IsCanceling
                // IL_003F: brtrue.s IL_00A7
                // IL_0041: ldarg.0 0
                // IL_0042: ldarg.0 0
                // IL_0043: ldfld 0x04003DDB OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<a>5__2
                // IL_0048: ldarg.0 0
                // IL_0049: ldfld 0x04003DD9 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::self
                // IL_004E: callvirt 0x0A00162A [OpenRA.Game]OpenRA.Activities.Activity::TargetLineNodes
                // IL_0053: callvirt 0x0A000089 class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>::GetEnumerator
                // IL_0058: stfld 0x04003DDC OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>7__wrap2
                // IL_005D: ldarg.0 0
                // IL_005E: ldc.i4.s -3
                // IL_0060: stfld 0x04003DD5 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>1__state
                // IL_0065: br.s IL_008D
                // IL_0067: ldarg.0 0
                // IL_0068: ldfld 0x04003DDC OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>7__wrap2
                // IL_006D: callvirt 0x0A000088 class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>::get_Current
                // IL_0072: stloc.3 3
                // IL_0073: ldarg.0 0
                // IL_0074: ldloc.3 3
                // IL_0075: stfld 0x04003DD6 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>2__current
                // IL_007A: ldarg.0 0
                // IL_007B: ldc.i4.1 1
                // IL_007C: stfld 0x04003DD5 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>1__state
                // IL_0081: ldc.i4.1 1
                // IL_0082: stloc.0 0
                // IL_0083: leave.s IL_00CE
                // IL_0085: ldarg.0 0
                // IL_0086: ldc.i4.s -3
                // IL_0088: stfld 0x04003DD5 OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>1__state
                // IL_008D: ldarg.0 0
                // IL_008E: ldfld 0x04003DDC OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>7__wrap2
                // IL_0093: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
                // IL_0098: brtrue.s IL_0067
                // IL_009A: ldarg.0 0
                // IL_009B: call 0x060048AE OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>m__Finally1
                // IL_00A0: ldarg.0 0
                // IL_00A1: ldnull 
                // IL_00A2: stfld 0x04003DDC OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<>7__wrap2
                // IL_00A7: ldarg.0 0
                // IL_00A8: ldarg.0 0
                // IL_00A9: ldfld 0x04003DDB OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<a>5__2
                // IL_00AE: callvirt 0x0A001186 [OpenRA.Game]OpenRA.Activities.Activity::get_NextActivity
                // IL_00B3: stfld 0x04003DDB OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<a>5__2
                // IL_00B8: ldarg.0 0
                // IL_00B9: ldfld 0x04003DDB OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::<a>5__2
                // IL_00BE: brtrue IL_0034
                // IL_00C3: ldc.i4.0 0
                // IL_00C4: stloc.0 0
                // IL_00C5: leave.s IL_00CE
                // IL_00C7: ldarg.0 0
                // IL_00C8: call 0x060048AC OpenRA.Mods.Common.Traits.Aircraft/AssociateWithAirfieldActivity/<TargetLineNodes>d__8::System.IDisposable.Dispose
                // IL_00CD: endfinally 
                // IL_00CE: ldloc.0 0
                // IL_00CF: ret 
                // .eh-raw ExceptionHandler { kind: Fault, try_offset: 0, try_length: 199, handler_offset: 199, handler_length: 7, raw_flags: 4 }
                // .try IL_0000..IL_00C7 fault IL_00C7..IL_00CE
            }

            private void __name_3C3E6D5F5F46696E616C6C7931()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                this.__il_field_04003DD5 = -1;
                __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d v3 = this.__il_field_04003DDC;
                if (v3 is null) {
                    goto IL_001A;
                } else {
                    goto IL_000F;
                }
                IL_000F: ;
                __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d v5 = this.__il_field_04003DDC;
                __cil_callvirt_0A00001A(v5);
                IL_001A: ;
                return;
            }

            private virtual OpenRA.Activities.TargetLineNode __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E6765745F43757272656E74()
            {
                __cil_type_010001E7 v1 = this.__il_field_04003DD6;
                return v1;
            }

            private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
            {
                global::System.NotSupportedException v0 = __cil_newobj_0A001A01();
                throw v0;
            }

            private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
            {
                __cil_type_010001E7 v1 = this.__il_field_04003DD6;
                return v1;
            }

            private virtual System.Collections.Generic.IEnumerator<OpenRA.Activities.TargetLineNode> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E476574456E756D657261746F72()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 l0 = default;
                int v1 = this.__il_field_04003DD5;
                if (unchecked((uint)v1) != unchecked((uint)-2)) {
                    goto IL_0022;
                } else {
                    goto IL_000A;
                }
                IL_000A: ;
                int v4 = this.__il_field_04003DD7;
                int v5 = System.Environment.get_CurrentManagedThreadId();
                if (unchecked((uint)v4) != unchecked((uint)v5)) {
                    goto IL_0022;
                } else {
                    goto IL_0017;
                }
                IL_0017: ;
                this.__il_field_04003DD5 = 0;
                l0 = this;
                goto IL_0035;
                IL_0022: ;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v10 = __cil_newobj_060048AB(0);
                l0 = v10;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v11 = l0;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity v13 = this.__il_field_04003DD8;
                v11.__il_field_04003DD8 = v13;
                IL_0035: ;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v14 = l0;
                __cil_type_01000025 v16 = this.__il_field_04003DDA;
                v14.self = v16;
                global::OpenRA.Mods.Common.Traits.Aircraft.AssociateWithAirfieldActivity.__name_3C5461726765744C696E654E6F6465733E645F5F38 v17 = l0;
                return v17;
            }

            private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d v1 = __cil_direct_060048B2(this);
                return v1;
            }
            // property OpenRA.Activities.TargetLineNode __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E6765745F43757272656E74; }
            // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
        }
    }

    public class AircraftMoveOrderTargeter : OpenRA.Traits.IOrderTargeter
    {
        private readonly OpenRA.Mods.Common.Traits.Aircraft aircraft;
        private string __il_field_04002FCD;
        private bool __il_field_04002FCE;

        public virtual string get_OrderID()
        {
            string v1 = this.__il_field_04002FCD;
            return v1;
        }

        protected void set_OrderID(string value)
        {
            this.__il_field_04002FCD = value;
            return;
        }

        public virtual int get_OrderPriority()
        {
            return 4;
        }

        public virtual bool get_IsQueued()
        {
            return this.__il_field_04002FCE;
        }

        protected void set_IsQueued(bool value)
        {
            int v1 = __cil_bool_load(value);
            this.__il_field_04002FCE = __cil_bool_store(v1);
            return;
        }

        public AircraftMoveOrderTargeter(OpenRA.Mods.Common.Traits.Aircraft aircraft) : base()
        {
            this.aircraft = aircraft;
            string v4 = __cil_ldstr_7001FE7B("Move");
            // Exact call 0x06003983 kept: constructor property syntax needs prior initialization.
            __cil_direct_06003983(this, v4);
            return;
        }

        public bool TargetOverridesSelection(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Collections.Generic.List<OpenRA.Actor> actorsAt, OpenRA.CPos xy, OpenRA.Traits.TargetModifiers modifiers)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_8457042ecebfe053d825612987d6bf1c10fbfaba bytes=1512811D01128095: class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // enum storage token=0x0200011C alias=__cil_enum_0200011C underlying=byte: global::@OpenRA.@Traits.@TargetType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            // enum storage token=0x0200012E alias=__cil_enum_0200012E underlying=int: global::@OpenRA.@Traits.@TargetModifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            IL_0000: ;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v0 = ref target;
            int v1 = unchecked((int)(unchecked((byte)(__cil_memberref_call_0A000208(ref v0)))));
            int v2 = 1;
            if (unchecked((uint)v1) != unchecked((uint)v2)) {
                goto IL_0036;
            } else {
                goto IL_0009;
            }
            IL_0009: ;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v3 = ref target;
            __cil_type_01000025 v4 = __cil_memberref_call_0A000209(ref v3);
            __cil_type_01000030 v5 = ((OpenRA.Actor)v4).Owner;
            __cil_type_01000025 v6 = self;
            __cil_type_01000030 v7 = ((OpenRA.Actor)v6).Owner;
            if (!System.Object.ReferenceEquals(v5, v7)) {
                goto IL_0034;
            } else {
                goto IL_001C;
            }
            IL_001C: ;
            __cil_type_01000025 v8 = self;
            __cil_type_0100002D v9 = v8.World;
            __cil_type_010001A7 v10 = v9.Selection;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v11 = ref target;
            __cil_type_01000025 v12 = __cil_memberref_call_0A000209(ref v11);
            int v13 = __cil_bool_load(__cil_callvirt_0A000AB4(v10, v12));
            if (v13 == 0) {
                goto IL_0036;
            } else {
                goto IL_0034;
            }
            IL_0034: ;
            int v14 = 1;
            return __cil_bool_store(v14);
            IL_0036: ;
            int v15 = unchecked((int)(modifiers));
            int v16 = 4;
            int v17 = __cil_bool_load(OpenRA.Traits.TargetModifiersExts.HasModifier(unchecked((OpenRA.Traits.TargetModifiers)(v15)), unchecked((OpenRA.Traits.TargetModifiers)(v16))));
            return __cil_bool_store(v17);
        }

        public virtual bool CanTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target, ref OpenRA.Traits.TargetModifiers modifiers, ref string cursor)
        {
            // IL fallback: byref/modified parameter needs IL fallback
            // .maxstack 4
            // .initlocals true
            // .code-bytes IL_0000: [04, 28, 08, 02, 00, 0A, 18, 33, 17, 02, 7B, CC, 2F, 00, 04, 7B, E8, 0C, 00, 04, 2C, 0C, 05, 4A]
            // .code-bytes IL_0018: [1A, 28, 09, 08, 00, 0A, 2D, 02, 16, 2A, 03, 7B, 59, 01, 00, 0A, 7B, 5A, 01, 00, 0A, 04, 28, 7F]
            // .code-bytes IL_0030: [02, 00, 0A, 6F, 90, 02, 00, 0A, 0A, 05, 4A, 1A, 28, 09, 08, 00, 0A, 2C, 66, 02, 7B, CC, 2F, 00]
            // .code-bytes IL_0048: [04, 7B, DB, 06, 00, 0A, 7B, C9, 0C, 00, 04, 2C, 54, 03, 7B, 59, 01, 00, 0A, 7B, 68, 01, 00, 0A]
            // .code-bytes IL_0060: [06, 6F, 69, 01, 00, 0A, 7E, DE, 3D, 00, 04, 25, 2D, 17, 26, 7E, DD, 3D, 00, 04, FE, 06, B6, 48]
            // .code-bytes IL_0078: [00, 06, 73, 9A, 01, 00, 0A, 25, 80, DE, 3D, 00, 04, 28, 16, 00, 00, 2B, 0C, 08, 2C, 10, 02, 7B]
            // .code-bytes IL_0090: [CC, 2F, 00, 04, 06, 14, 16, 6F, 59, 0F, 00, 06, 2C, 0B, 02, 72, 85, FE, 01, 70, 28, 83, 39, 00]
            // .code-bytes IL_00A8: [06, 02, 05, 4A, 18, 28, 09, 08, 00, 0A, 28, 86, 39, 00, 06, 03, 6F, 60, 01, 00, 0A, 7B, 3F, 08]
            // .code-bytes IL_00C0: [00, 0A, 06, 6F, 04, 02, 00, 0A, 0B, 0E, 04, 02, 7B, CC, 2F, 00, 04, 6F, FE, 10, 00, 0A, 2D, 28]
            // .code-bytes IL_00D8: [07, 2D, 12, 02, 7B, CC, 2F, 00, 04, 7B, DB, 06, 00, 0A, 7B, BC, 0C, 00, 04, 2C, 13, 03, 7B, 59]
            // .code-bytes IL_00F0: [01, 00, 0A, 7B, 5A, 01, 00, 0A, 06, 6F, 5C, 01, 00, 0A, 2D, 12, 02, 7B, CC, 2F, 00, 04, 7B, DB]
            // .code-bytes IL_0108: [06, 00, 0A, 7B, D6, 0C, 00, 04, 2B, 10, 02, 7B, CC, 2F, 00, 04, 7B, DB, 06, 00, 0A, 7B, D5, 0C]
            // .code-bytes IL_0120: [00, 04, 51, 17, 2A]
            // .local [0] valuetype [OpenRA.Game]OpenRA.CPos
            // .local [1] bool
            // .local [2] bool
            // IL_0000: ldarg.2 2
            // IL_0001: call 0x0A000208 [OpenRA.Game]OpenRA.Traits.Target::get_Type
            // IL_0006: ldc.i4.2 2
            // IL_0007: bne.un.s IL_0020
            // IL_0009: ldarg.0 0
            // IL_000A: ldfld 0x04002FCC OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::aircraft
            // IL_000F: ldfld 0x04000CE8 OpenRA.Mods.Common.Traits.Aircraft::RequireForceMove
            // IL_0014: brfalse.s IL_0022
            // IL_0016: ldarg.3 3
            // IL_0017: ldind.i4 
            // IL_0018: ldc.i4.4 4
            // IL_0019: call 0x0A000809 [OpenRA.Game]OpenRA.Traits.TargetModifiersExts::HasModifier
            // IL_001E: brtrue.s IL_0022
            // IL_0020: ldc.i4.0 0
            // IL_0021: ret 
            // IL_0022: ldarg.1 1
            // IL_0023: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
            // IL_0028: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
            // IL_002D: ldarg.2 2
            // IL_002E: call 0x0A00027F [OpenRA.Game]OpenRA.Traits.Target::get_CenterPosition
            // IL_0033: callvirt 0x0A000290 [OpenRA.Game]OpenRA.Map::CellContaining
            // IL_0038: stloc.0 0
            // IL_0039: ldarg.3 3
            // IL_003A: ldind.i4 
            // IL_003B: ldc.i4.4 4
            // IL_003C: call 0x0A000809 [OpenRA.Game]OpenRA.Traits.TargetModifiersExts::HasModifier
            // IL_0041: brfalse.s IL_00A9
            // IL_0043: ldarg.0 0
            // IL_0044: ldfld 0x04002FCC OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::aircraft
            // IL_0049: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
            // IL_004E: ldfld 0x04000CC9 OpenRA.Mods.Common.Traits.AircraftInfo::CanForceLand
            // IL_0053: brfalse.s IL_00A9
            // IL_0055: ldarg.1 1
            // IL_0056: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
            // IL_005B: ldfld 0x0A000168 [OpenRA.Game]OpenRA.World::ActorMap
            // IL_0060: ldloc.0 0
            // IL_0061: callvirt 0x0A000169 [OpenRA.Game]OpenRA.Traits.IActorMap::GetActorsAt
            // IL_0066: ldsfld 0x04003DDE OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter/<>c::<>9__13_0
            // IL_006B: dup 
            // IL_006C: brtrue.s IL_0085
            // IL_006E: pop 
            // IL_006F: ldsfld 0x04003DDD OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter/<>c::<>9
            // IL_0074: ldftn 0x060048B6 OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter/<>c::<CanTarget>b__13_0
            // IL_007A: newobj 0x0A00019A class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>::.ctor
            // IL_007F: dup 
            // IL_0080: stsfld 0x04003DDE OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter/<>c::<>9__13_0
            // IL_0085: call 0x2B000016 [System.Linq]System.Linq.Enumerable::Any<class [OpenRA.Game]OpenRA.Actor>
            // IL_008A: stloc.2 2
            // IL_008B: ldloc.2 2
            // IL_008C: brfalse.s IL_009E
            // IL_008E: ldarg.0 0
            // IL_008F: ldfld 0x04002FCC OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::aircraft
            // IL_0094: ldloc.0 0
            // IL_0095: ldnull 
            // IL_0096: ldc.i4.0 0
            // IL_0097: callvirt 0x06000F59 OpenRA.Mods.Common.Traits.Aircraft::CanLand
            // IL_009C: brfalse.s IL_00A9
            // IL_009E: ldarg.0 0
            // IL_009F: ldstr 0x7001FE85 [76, 97, 110, 100] utf16-bytes=[4C, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
            // IL_00A4: call 0x06003983 OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::set_OrderID
            // IL_00A9: ldarg.0 0
            // IL_00AA: ldarg.3 3
            // IL_00AB: ldind.i4 
            // IL_00AC: ldc.i4.2 2
            // IL_00AD: call 0x0A000809 [OpenRA.Game]OpenRA.Traits.TargetModifiersExts::HasModifier
            // IL_00B2: call 0x06003986 OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::set_IsQueued
            // IL_00B7: ldarg.1 1
            // IL_00B8: callvirt 0x0A000160 [OpenRA.Game]OpenRA.Actor::get_Owner
            // IL_00BD: ldfld 0x0A00083F [OpenRA.Game]OpenRA.Player::Shroud
            // IL_00C2: ldloc.0 0
            // IL_00C3: callvirt 0x0A000204 [OpenRA.Game]OpenRA.Traits.Shroud::IsExplored
            // IL_00C8: stloc.1 1
            // IL_00C9: ldarg.s 4
            // IL_00CB: ldarg.0 0
            // IL_00CC: ldfld 0x04002FCC OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::aircraft
            // IL_00D1: callvirt 0x0A0010FE class OpenRA.Mods.Common.Traits.PausableConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::get_IsTraitPaused
            // IL_00D6: brtrue.s IL_0100
            // IL_00D8: ldloc.1 1
            // IL_00D9: brtrue.s IL_00ED
            // IL_00DB: ldarg.0 0
            // IL_00DC: ldfld 0x04002FCC OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::aircraft
            // IL_00E1: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
            // IL_00E6: ldfld 0x04000CBC OpenRA.Mods.Common.Traits.AircraftInfo::MoveIntoShroud
            // IL_00EB: brfalse.s IL_0100
            // IL_00ED: ldarg.1 1
            // IL_00EE: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
            // IL_00F3: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
            // IL_00F8: ldloc.0 0
            // IL_00F9: callvirt 0x0A00015C [OpenRA.Game]OpenRA.Map::Contains
            // IL_00FE: brtrue.s IL_0112
            // IL_0100: ldarg.0 0
            // IL_0101: ldfld 0x04002FCC OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::aircraft
            // IL_0106: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
            // IL_010B: ldfld 0x04000CD6 OpenRA.Mods.Common.Traits.AircraftInfo::BlockedCursor
            // IL_0110: br.s IL_0122
            // IL_0112: ldarg.0 0
            // IL_0113: ldfld 0x04002FCC OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::aircraft
            // IL_0118: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
            // IL_011D: ldfld 0x04000CD5 OpenRA.Mods.Common.Traits.AircraftInfo::Cursor
            // IL_0122: stind.ref 
            // IL_0123: ldc.i4.1 1
            // IL_0124: ret 
        }

        private virtual bool __name_4F70656E52412E5472616974732E494F7264657254617267657465722E5461726765744F766572726964657353656C656374696F6E(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Collections.Generic.List<OpenRA.Actor> actorsAt, OpenRA.CPos xy, OpenRA.Traits.TargetModifiers modifiers)
        {
            // IL fallback: byref/modified parameter needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 28, 88, 39, 00, 06, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldarg.1 1
            // IL_0002: ldarg.2 2
            // IL_0003: ldarg.3 3
            // IL_0004: ldarg.s 4
            // IL_0006: ldarg.s 5
            // IL_0008: call 0x06003988 OpenRA.Mods.Common.Traits.Aircraft/AircraftMoveOrderTargeter::TargetOverridesSelection
            // IL_000D: ret 
        }
        // property string OrderID { get: get_OrderID; set: set_OrderID; }
        // property int OrderPriority { get: get_OrderPriority; }
        // property bool IsQueued { get: get_IsQueued; set: set_IsQueued; }

        private sealed class __name_3C3E63
        {
            public static readonly OpenRA.Mods.Common.Traits.Aircraft.AircraftMoveOrderTargeter.__name_3C3E63 __il_field_04003DDD;
            public static System.Func<OpenRA.Actor, bool> __il_field_04003DDE;

            static __name_3C3E63()
            {
                global::OpenRA.Mods.Common.Traits.Aircraft.AircraftMoveOrderTargeter.__name_3C3E63 v0 = __cil_newobj_060048B5();
                OpenRA.Mods.Common.Traits.Aircraft.AircraftMoveOrderTargeter.__name_3C3E63.__il_field_04003DDD = v0;
                return;
            }

            public __name_3C3E63() : base()
            {
                return;
            }

            // Metadata name: <CanTarget>b__13_0
            internal bool CanTargetLambda13_0(OpenRA.Actor a)
            {
                global::OpenRA.Mods.Common.Traits.Building v1 = __cil_callvirt_2B00092F(a);
                if (v1 is null) {
                    return false;
                } else {
                    goto IL_0008;
                }
                IL_0008: ;
                global::OpenRA.Mods.Common.Traits.Selectable v3 = __cil_callvirt_2B000930(a);
                return (!System.Object.ReferenceEquals(v3, null));
            }
        }
    }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 __il_field_04002FCF;
        public static System.Func<OpenRA.Mods.Common.Traits.ISpeedModifier, int> __il_field_04002FD0;
        public static System.Func<OpenRA.Actor, bool> __il_field_04002FD1;
        public static System.Func<OpenRA.Mods.Common.Traits.AmmoPool, bool> __il_field_04002FD2;
        public static System.Func<OpenRA.Mods.Common.Traits.AmmoPool, bool> __il_field_04002FD3;
        public static System.Func<OpenRA.Mods.Common.Traits.INotifyCrushed, System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>>> __il_field_04002FD4;
        public static System.Func<OpenRA.Mods.Common.Traits.INotifyCrushed, System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>>> __il_field_04002FD5;
        public static System.Func<OpenRA.Actor, System.Collections.Generic.IEnumerable<OpenRA.TraitPair<OpenRA.Traits.ICrushable>>> __il_field_04002FD6;

        static __name_3C3E63()
        {
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63 v0 = __cil_newobj_0600398C();
            OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E63.__il_field_04002FCF = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <Created>b__67_0
        internal int CreatedLambda67_0(OpenRA.Mods.Common.Traits.ISpeedModifier sm)
        {
            int v1 = __cil_callvirt_06001F9D(sm);
            return v1;
        }

        // Metadata name: <GetActorBelow>b__77_0
        internal bool GetActorBelowLambda77_0(OpenRA.Actor a)
        {
            __cil_type_01000108 v1 = a.Info;
            return __cil_callvirt_2B0008A8(v1);
        }

        // Metadata name: <AircraftCanResupplyAt>b__83_0
        internal bool AircraftCanResupplyAtLambda83_0(OpenRA.Mods.Common.Traits.AmmoPool p)
        {
            int v1 = __cil_bool_load(__cil_callvirt_06000FB7(p));
            return (v1 == 0);
        }

        // Metadata name: <CanRearmAt>b__95_0
        internal bool CanRearmAtLambda95_0(OpenRA.Mods.Common.Traits.AmmoPool p)
        {
            int v1 = __cil_bool_load(__cil_callvirt_06000FB7(p));
            return (v1 == 0);
        }

        // Metadata name: <FinishedMoving>b__108_0
        internal System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>> FinishedMovingLambda108_0(OpenRA.Mods.Common.Traits.INotifyCrushed notifyCrushed)
        {
            // IL fallback: unsupported opcode ldvirtftn at IL_0002
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 25, FE, 07, 20, 1F, 00, 06, 73, 8F, 1C, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: dup 
            // IL_0002: ldvirtftn 0x06001F20 OpenRA.Mods.Common.Traits.INotifyCrushed::OnCrush
            // IL_0008: newobj 0x0A001C8F class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>::.ctor
            // IL_000D: ret 
        }

        // Metadata name: <EnteringCell>b__109_0
        internal System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>> EnteringCellLambda109_0(OpenRA.Mods.Common.Traits.INotifyCrushed notifyCrushed)
        {
            // IL fallback: unsupported opcode ldvirtftn at IL_0002
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 25, FE, 07, 21, 1F, 00, 06, 73, 8F, 1C, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: dup 
            // IL_0002: ldvirtftn 0x06001F21 OpenRA.Mods.Common.Traits.INotifyCrushed::WarnCrush
            // IL_0008: newobj 0x0A001C8F class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>::.ctor
            // IL_000D: ret 
        }

        // Metadata name: <CrushAction>b__110_1
        internal System.Collections.Generic.IEnumerable<OpenRA.TraitPair<OpenRA.Traits.ICrushable>> CrushActionLambda110_1(OpenRA.Actor a)
        {
            // structural signature __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc bytes=1D1284C9: class [OpenRA.Game]OpenRA.Traits.ICrushable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 bytes=151280A10115118125011284C9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_f48622b11bf13e8aea55dc410129d650d43157c5 bytes=15128121021284C915118125011284C9: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.ICrushable, valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_5456acb599b8af561901b1de68086d6d17196efd bytes=151280A1011284C9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733131305F31 v0 = __cil_newobj_06003996();
            v0.a = a;
            __cil_type_01000025 v4 = v0.a;
            __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc v5 = ((OpenRA.Actor)v4).Crushables;
            nint v7 = __cil_ldftn_06003997;
            __cil_ref_f48622b11bf13e8aea55dc410129d650d43157c5 v8 = __cil_newobj_0A001C90(v0, v7);
            __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 v9 = __cil_methodspec_call_2B0008A9(((__cil_ref_5456acb599b8af561901b1de68086d6d17196efd)(v5)), v8);
            return v9;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733131305F30
    {
        public OpenRA.Actor self;

        public __name_3C3E635F5F446973706C6179436C6173733131305F30() : base()
        {
            return;
        }

        // Metadata name: <CrushAction>b__0
        internal bool CrushActionLambda0(OpenRA.Actor a)
        {
            __cil_type_01000025 v2 = this.self;
            int v3 = (System.Object.ReferenceEquals(a, v2) ? 1 : 0);
            return (v3 == 0);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733131305F31
    {
        public OpenRA.Actor a;

        public __name_3C3E635F5F446973706C6179436C6173733131305F31() : base()
        {
            return;
        }

        // Metadata name: <CrushAction>b__2
        internal OpenRA.TraitPair<OpenRA.Traits.ICrushable> CrushActionLambda2(OpenRA.Traits.ICrushable t)
        {
            // structural signature __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 bytes=15118125011284C9: valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000025 v1 = this.a;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v3 = __cil_value_newobj_0A001C91(v1, t);
            return v3;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733132335F30
    {
        public OpenRA.Mods.Common.Traits.Aircraft __il_field_04002FD9;
        public OpenRA.Actor self;
        public OpenRA.WPos fromPos;

        public __name_3C3E635F5F446973706C6179436C6173733132335F30() : base()
        {
            return;
        }

        // Metadata name: <LocalMove>b__0
        internal void LocalMoveLambda0()
        {
            // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            global::OpenRA.Mods.Common.Traits.Aircraft v1 = this.__il_field_04002FD9;
            __cil_type_01000025 v3 = this.self;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v5 = this.fromPos;
            __cil_direct_06000F65(v1, v3, v5);
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733132395F30
    {
        public OpenRA.Actor self;
        public OpenRA.Traits.Target targetActor;
        public System.Func<OpenRA.Actor, bool> __il_field_04002FDE;

        public __name_3C3E635F5F446973706C6179436C6173733132395F30() : base()
        {
            return;
        }

        // Metadata name: <CanEnterTargetNow>b__0
        internal bool CanEnterTargetNowLambda0(OpenRA.WPos p)
        {
            // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s1_0 = default;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 s1_1 = default;
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s2_0 = default;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 s2_1 = default;
            __cil_type_01000025 v1 = this.self;
            __cil_type_0100002D v2 = v1.World;
            __cil_type_01000130 v3 = v2.ActorMap;
            __cil_type_01000025 v5 = this.self;
            __cil_type_0100002D v6 = v5.World;
            __cil_type_01000026 v7 = v6.Map;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v9 = v7.CellContaining(p);
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v10 = __cil_callvirt_0A000169(v3, v9);
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v12 = this.__il_field_04002FDE;
            if (v12 is not null) {
                __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e0_2_0 = v10;
                __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 e0_2_1 = v12;
                s2_0 = e0_2_0;
                s2_1 = e0_2_1;
                goto IL_004A;
            } else {
                __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e0_1_0 = v10;
                __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 e0_1_1 = v12;
                s1_0 = e0_1_0;
                s1_1 = e0_1_1;
                goto IL_0034;
            }
            IL_0034: ;
            nint v15 = __cil_ldftn_0600399C;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v16 = __cil_newobj_0A00019A(this, v15);
            this.__il_field_04002FDE = v16;
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e1_2_0 = s1_0;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 e1_2_1 = v16;
            s2_0 = e1_2_0;
            s2_1 = e1_2_1;
            IL_004A: ;
            return __cil_methodspec_call_2B000016(s2_0, s2_1);
        }

        // Metadata name: <CanEnterTargetNow>b__1
        internal bool CanEnterTargetNowLambda1(OpenRA.Actor a)
        {
            // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            IL_0000: ;
            __cil_type_01000025 v0 = a;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132395F30 v1 = this;
            __cil_type_01000025 v2 = v1.self;
            if (System.Object.ReferenceEquals(v0, v2)) {
                goto IL_001B;
            } else {
                goto IL_0009;
            }
            IL_0009: ;
            __cil_type_01000025 v3 = a;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C3E635F5F446973706C6179436C6173733132395F30 v4 = this;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v5 = ref v4.targetActor;
            __cil_type_01000025 v6 = __cil_memberref_call_0A000209(ref v5);
            int v7 = (System.Object.ReferenceEquals(v3, v6) ? 1 : 0);
            int v8 = 0;
            int v9 = (v7 == v8 ? 1 : 0);
            return __cil_bool_store(v9);
            IL_001B: ;
            int v10 = 0;
            return __cil_bool_store(v10);
        }
    }

    private sealed class __name_3C4765745661726961626C654F62736572766572733E645F5F3635 : System.Collections.Generic.IEnumerable<OpenRA.Traits.VariableObserver>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Traits.VariableObserver>, System.Collections.IEnumerator, System.IDisposable
    {
        private int __il_field_04002FDF;
        private OpenRA.Traits.VariableObserver __il_field_04002FE0;
        private int __il_field_04002FE1;
        public OpenRA.Mods.Common.Traits.Aircraft __il_field_04002FE2;
        private System.Collections.Generic.IEnumerator<OpenRA.Traits.VariableObserver> __il_field_04002FE3;

        public __name_3C4765745661726961626C654F62736572766572733E645F5F3635(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_04002FDF = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04002FE1 = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            int l0 = default;
            IL_0000: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v0 = this;
            int v1 = v0.__il_field_04002FDF;
            l0 = v1;
            int v2 = l0;
            int v3 = -3;
            if (v2 == v3) {
                goto IL_0010;
            } else {
                goto IL_000C;
            }
            IL_000C: ;
            int v4 = l0;
            int v5 = 1;
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_001A;
            } else {
                goto IL_0010;
            }
            IL_0010: ;
            try {
                IL_0011: ;
                goto IL_001A;
            }
            finally {
                IL_0013: ;
                global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v6 = this;
                __cil_direct_060039A0(v6);
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_001A: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v7 = this;
            v7.__il_field_04002FE3 = null;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v8 = this;
            int v9 = -2;
            v8.__il_field_04002FDF = v9;
            return;
        }

        private virtual bool MoveNext()
        {
            // IL fallback: EH fault handlers need exceptional-only cleanup
            // .maxstack 3
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, DF, 2F, 00, 04, 0B, 02, 7B, E2, 2F, 00, 04, 0C, 07, 45, 03, 00, 00, 00, 07, 00, 00, 00]
            // .code-bytes IL_0018: [47, 00, 00, 00, A8, 00, 00, 00, 16, 0A, DD, B3, 00, 00, 00, 02, 15, 7D, DF, 2F, 00, 04, 02, 08]
            // .code-bytes IL_0030: [28, 92, 0F, 00, 06, 6F, 96, 00, 00, 0A, 7D, E3, 2F, 00, 04, 02, 1F, FD, 7D, DF, 2F, 00, 04, 2B]
            // .code-bytes IL_0048: [26, 02, 7B, E3, 2F, 00, 04, 6F, 95, 00, 00, 0A, 0D, 02, 09, 7D, E0, 2F, 00, 04, 02, 17, 7D, DF]
            // .code-bytes IL_0060: [2F, 00, 04, 17, 0A, DE, 73, 02, 1F, FD, 7D, DF, 2F, 00, 04, 02, 7B, E3, 2F, 00, 04, 6F, 1B, 00]
            // .code-bytes IL_0078: [00, 0A, 2D, CD, 02, 28, A0, 39, 00, 06, 02, 14, 7D, E3, 2F, 00, 04, 08, 7B, DB, 06, 00, 0A, 7B]
            // .code-bytes IL_0090: [D4, 0C, 00, 04, 2C, 39, 02, 08, FE, 06, 40, 0F, 00, 06, 73, 92, 1C, 00, 0A, 08, 7B, DB, 06, 00]
            // .code-bytes IL_00A8: [0A, 7B, D4, 0C, 00, 04, 6F, 89, 09, 00, 0A, 73, 93, 1C, 00, 0A, 7D, E0, 2F, 00, 04, 02, 18, 7D]
            // .code-bytes IL_00C0: [DF, 2F, 00, 04, 17, 0A, DE, 12, 02, 15, 7D, DF, 2F, 00, 04, 16, 0A, DE, 07, 02, 28, 9E, 39, 00]
            // .code-bytes IL_00D8: [06, DC, 06, 2A]
            // .local [0] bool
            // .local [1] int32
            // .local [2] class OpenRA.Mods.Common.Traits.Aircraft
            // .local [3] valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04002FDF OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>1__state
            // IL_0006: stloc.1 1
            // IL_0007: ldarg.0 0
            // IL_0008: ldfld 0x04002FE2 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>4__this
            // IL_000D: stloc.2 2
            // IL_000E: ldloc.1 1
            // IL_000F: switch IL_0027, IL_0067, IL_00C8
            // IL_0020: ldc.i4.0 0
            // IL_0021: stloc.0 0
            // IL_0022: leave IL_00DA
            // IL_0027: ldarg.0 0
            // IL_0028: ldc.i4.m1 -1
            // IL_0029: stfld 0x04002FDF OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>1__state
            // IL_002E: ldarg.0 0
            // IL_002F: ldloc.2 2
            // IL_0030: call 0x06000F92 OpenRA.Mods.Common.Traits.Aircraft::<>n__0
            // IL_0035: callvirt 0x0A000096 class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>::GetEnumerator
            // IL_003A: stfld 0x04002FE3 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>7__wrap1
            // IL_003F: ldarg.0 0
            // IL_0040: ldc.i4.s -3
            // IL_0042: stfld 0x04002FDF OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>1__state
            // IL_0047: br.s IL_006F
            // IL_0049: ldarg.0 0
            // IL_004A: ldfld 0x04002FE3 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>7__wrap1
            // IL_004F: callvirt 0x0A000095 class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>::get_Current
            // IL_0054: stloc.3 3
            // IL_0055: ldarg.0 0
            // IL_0056: ldloc.3 3
            // IL_0057: stfld 0x04002FE0 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>2__current
            // IL_005C: ldarg.0 0
            // IL_005D: ldc.i4.1 1
            // IL_005E: stfld 0x04002FDF OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>1__state
            // IL_0063: ldc.i4.1 1
            // IL_0064: stloc.0 0
            // IL_0065: leave.s IL_00DA
            // IL_0067: ldarg.0 0
            // IL_0068: ldc.i4.s -3
            // IL_006A: stfld 0x04002FDF OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>1__state
            // IL_006F: ldarg.0 0
            // IL_0070: ldfld 0x04002FE3 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>7__wrap1
            // IL_0075: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
            // IL_007A: brtrue.s IL_0049
            // IL_007C: ldarg.0 0
            // IL_007D: call 0x060039A0 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>m__Finally1
            // IL_0082: ldarg.0 0
            // IL_0083: ldnull 
            // IL_0084: stfld 0x04002FE3 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>7__wrap1
            // IL_0089: ldloc.2 2
            // IL_008A: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
            // IL_008F: ldfld 0x04000CD4 OpenRA.Mods.Common.Traits.AircraftInfo::RequireForceMoveCondition
            // IL_0094: brfalse.s IL_00CF
            // IL_0096: ldarg.0 0
            // IL_0097: ldloc.2 2
            // IL_0098: ldftn 0x06000F40 OpenRA.Mods.Common.Traits.Aircraft::RequireForceMoveConditionChanged
            // IL_009E: newobj 0x0A001C92 [OpenRA.Game]OpenRA.Traits.VariableObserverNotifier::.ctor
            // IL_00A3: ldloc.2 2
            // IL_00A4: ldfld 0x0A0006DB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.AircraftInfo>::Info
            // IL_00A9: ldfld 0x04000CD4 OpenRA.Mods.Common.Traits.AircraftInfo::RequireForceMoveCondition
            // IL_00AE: callvirt 0x0A000989 [OpenRA.Game]OpenRA.Support.VariableExpression::get_Variables
            // IL_00B3: newobj 0x0A001C93 [OpenRA.Game]OpenRA.Traits.VariableObserver::.ctor
            // IL_00B8: stfld 0x04002FE0 OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>2__current
            // IL_00BD: ldarg.0 0
            // IL_00BE: ldc.i4.2 2
            // IL_00BF: stfld 0x04002FDF OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>1__state
            // IL_00C4: ldc.i4.1 1
            // IL_00C5: stloc.0 0
            // IL_00C6: leave.s IL_00DA
            // IL_00C8: ldarg.0 0
            // IL_00C9: ldc.i4.m1 -1
            // IL_00CA: stfld 0x04002FDF OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::<>1__state
            // IL_00CF: ldc.i4.0 0
            // IL_00D0: stloc.0 0
            // IL_00D1: leave.s IL_00DA
            // IL_00D3: ldarg.0 0
            // IL_00D4: call 0x0600399E OpenRA.Mods.Common.Traits.Aircraft/<GetVariableObservers>d__65::System.IDisposable.Dispose
            // IL_00D9: endfinally 
            // IL_00DA: ldloc.0 0
            // IL_00DB: ret 
            // .eh-raw ExceptionHandler { kind: Fault, try_offset: 0, try_length: 211, handler_offset: 211, handler_length: 7, raw_flags: 4 }
            // .try IL_0000..IL_00D3 fault IL_00D3..IL_00DA
        }

        private void __name_3C3E6D5F5F46696E616C6C7931()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            this.__il_field_04002FDF = -1;
            __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e v3 = this.__il_field_04002FE3;
            if (v3 is null) {
                goto IL_001A;
            } else {
                goto IL_000F;
            }
            IL_000F: ;
            __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e v5 = this.__il_field_04002FE3;
            __cil_callvirt_0A00001A(v5);
            IL_001A: ;
            return;
        }

        private virtual OpenRA.Traits.VariableObserver __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E6765745F43757272656E74()
        {
            // structural signature __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 bytes=1187C5: valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 v1 = this.__il_field_04002FE0;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A001A01();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            // structural signature __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 bytes=1187C5: valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 v1 = this.__il_field_04002FE0;
            object v2 = ((object)((__cil_value_252d11ffe3490e47244441c12494c6519dc6e777)(v1)));
            return v2;
        }

        private virtual System.Collections.Generic.IEnumerator<OpenRA.Traits.VariableObserver> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 l0 = default;
            int v1 = this.__il_field_04002FDF;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04002FE1;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_04002FDF = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v10 = __cil_newobj_0600399D(0);
            l0 = v10;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v11 = l0;
            global::OpenRA.Mods.Common.Traits.Aircraft v13 = this.__il_field_04002FE2;
            v11.__il_field_04002FE2 = v13;
            IL_0035: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C4765745661726961626C654F62736572766572733E645F5F3635 v14 = l0;
            return v14;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e v1 = __cil_direct_060039A4(this);
            return v1;
        }
        // property OpenRA.Traits.VariableObserver __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }

    private sealed class __name_3C6765745F4F72646572733E645F5F313331 : System.Collections.Generic.IEnumerable<OpenRA.Traits.IOrderTargeter>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Traits.IOrderTargeter>, System.Collections.IEnumerator, System.IDisposable
    {
        private int __il_field_04002FE4;
        private OpenRA.Traits.IOrderTargeter __il_field_04002FE5;
        private int __il_field_04002FE6;
        public OpenRA.Mods.Common.Traits.Aircraft __il_field_04002FE7;

        public __name_3C6765745F4F72646572733E645F5F313331(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_04002FE4 = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04002FE6 = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            this.__il_field_04002FE4 = -2;
            return;
        }

        private virtual bool MoveNext()
        {
            // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_ed3679edf1442204b3ca46f10640a8070dc452ee bytes=151284C5031280951184F102: class [System.Runtime]System.Func`3<class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Traits.TargetModifiers, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_66df9c4fca431b5d5142ed7a45d2acca49979703 bytes=1512846C01128C34: class OpenRA.Mods.Common.Orders.EnterAlliedActorTargeter`1<class OpenRA.Mods.Common.Traits.BuildingInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            OpenRA.Mods.Common.Traits.Aircraft l1 = default;
            int v1 = this.__il_field_04002FE4;
            global::OpenRA.Mods.Common.Traits.Aircraft v3 = this.__il_field_04002FE7;
            l1 = v3;
            int v4 = v1;
            switch (v4) {
                case 0: {
                    goto IL_0026;
                }
                case 1: {
                    goto IL_0075;
                }
                case 2: {
                    goto IL_00C4;
                }
                case 3: {
                    goto IL_00E0;
                }
                default: {
                    return false;
                } }
            IL_0026: ;
            this.__il_field_04002FE4 = -1;
            string v9 = __cil_ldstr_7001FE8F("ForceEnter");
            global::OpenRA.Mods.Common.Traits.Aircraft v11 = l1;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v12 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v11).Info;
            string v13 = v12.EnterCursor;
            global::OpenRA.Mods.Common.Traits.Aircraft v14 = l1;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v15 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v14).Info;
            string v16 = v15.EnterBlockedCursor;
            global::OpenRA.Mods.Common.Traits.Aircraft v17 = l1;
            nint v18 = __cil_ldftn_06000F93;
            __cil_ref_ed3679edf1442204b3ca46f10640a8070dc452ee v19 = __cil_newobj_0A001C94(v17, v18);
            global::OpenRA.Mods.Common.Traits.Aircraft v20 = l1;
            nint v21 = __cil_ldftn_06000F94;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v22 = __cil_newobj_0A00019A(v20, v21);
            __cil_ref_66df9c4fca431b5d5142ed7a45d2acca49979703 v23 = __cil_newobj_0A001C95(v9, 6, v13, v16, v19, v22);
            this.__il_field_04002FE5 = v23;
            this.__il_field_04002FE4 = 1;
            return true;
            IL_0075: ;
            this.__il_field_04002FE4 = -1;
            string v30 = __cil_ldstr_7001FE6F("Enter");
            global::OpenRA.Mods.Common.Traits.Aircraft v32 = l1;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v33 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v32).Info;
            string v34 = v33.EnterCursor;
            global::OpenRA.Mods.Common.Traits.Aircraft v35 = l1;
            global::OpenRA.Mods.Common.Traits.AircraftInfo v36 = ((__cil_ref_656e6dffaba1c09d791add19616ed55de0dae54d)v35).Info;
            string v37 = v36.EnterBlockedCursor;
            global::OpenRA.Mods.Common.Traits.Aircraft v38 = l1;
            nint v39 = __cil_ldftn_06000F4F;
            __cil_ref_ed3679edf1442204b3ca46f10640a8070dc452ee v40 = __cil_newobj_0A001C94(v38, v39);
            global::OpenRA.Mods.Common.Traits.Aircraft v41 = l1;
            nint v42 = __cil_ldftn_06000F95;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v43 = __cil_newobj_0A00019A(v41, v42);
            __cil_ref_66df9c4fca431b5d5142ed7a45d2acca49979703 v44 = __cil_newobj_0A001C95(v30, 5, v34, v37, v40, v43);
            this.__il_field_04002FE5 = v44;
            this.__il_field_04002FE4 = 2;
            return true;
            IL_00C4: ;
            this.__il_field_04002FE4 = -1;
            global::OpenRA.Mods.Common.Traits.Aircraft v51 = l1;
            global::OpenRA.Mods.Common.Traits.Aircraft.AircraftMoveOrderTargeter v52 = __cil_newobj_06003987(v51);
            this.__il_field_04002FE5 = v52;
            this.__il_field_04002FE4 = 3;
            return true;
            IL_00E0: ;
            this.__il_field_04002FE4 = -1;
            return false;
        }

        private virtual OpenRA.Traits.IOrderTargeter __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E494F7264657254617267657465723E2E6765745F43757272656E74()
        {
            __cil_type_0100013B v1 = this.__il_field_04002FE5;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A001A01();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            __cil_type_0100013B v1 = this.__il_field_04002FE5;
            return v1;
        }

        private virtual System.Collections.Generic.IEnumerator<OpenRA.Traits.IOrderTargeter> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E5472616974732E494F7264657254617267657465723E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_d5cb43c47e96920ee7908b5463a82b2770b4c986 bytes=151280A5011284ED: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.IOrderTargeter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            OpenRA.Mods.Common.Traits.Aircraft.__name_3C6765745F4F72646572733E645F5F313331 l0 = default;
            int v1 = this.__il_field_04002FE4;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04002FE6;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_04002FE4 = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C6765745F4F72646572733E645F5F313331 v10 = __cil_newobj_060039A6(0);
            l0 = v10;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C6765745F4F72646572733E645F5F313331 v11 = l0;
            global::OpenRA.Mods.Common.Traits.Aircraft v13 = this.__il_field_04002FE7;
            v11.__il_field_04002FE7 = v13;
            IL_0035: ;
            global::OpenRA.Mods.Common.Traits.Aircraft.__name_3C6765745F4F72646572733E645F5F313331 v14 = l0;
            return v14;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_d5cb43c47e96920ee7908b5463a82b2770b4c986 bytes=151280A5011284ED: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.IOrderTargeter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_d5cb43c47e96920ee7908b5463a82b2770b4c986 v1 = __cil_direct_060039AC(this);
            return v1;
        }
        // property OpenRA.Traits.IOrderTargeter __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E494F7264657254617267657465723E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E494F7264657254617267657465723E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.DriveInfo, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.DriveInfo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Tasks.Parallel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Tasks.Parallel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.Win32.Registry, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.Win32.Registry, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 11; exact references retained; see --details for identities and provenance.
