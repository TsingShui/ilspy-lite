using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA.Mods.Common.Traits;

public class ProductionQueue : IResolveOrder, ITick, ITechTreeElement, INotifyOwnerChanged, INotifyKilled, INotifySold, ISync, INotifyTransform, INotifyCreated
{
	public readonly ProductionQueueInfo Info;

	protected readonly Dictionary<ActorInfo, ProductionState> Producible = new Dictionary<ActorInfo, ProductionState>();

	protected readonly List<ProductionItem> Queue = new List<ProductionItem>();

	private readonly IEnumerable<ActorInfo> allProducibles;

	private readonly IEnumerable<ActorInfo> buildableProducibles;

	protected Production[] productionTraits;

	private PowerManager playerPower;

	protected PlayerResources playerResources;

	protected DeveloperMode developerMode;

	protected TechTree techTree;

	public Actor Actor { get; }

	[Sync]
	public bool Enabled { get; protected set; }

	public string Faction { get; private set; }

	[Sync]
	public bool IsValidFaction { get; private set; }

	public ProductionQueue(ActorInitializer init, ProductionQueueInfo info)
	{
		Actor = init.Self;
		Info = info;
		Faction = init.GetValue<FactionInit, string>(Actor.Owner.Faction.InternalName);
		IsValidFaction = info.Factions.Count == 0 || info.Factions.Contains(Faction);
		Enabled = IsValidFaction;
		allProducibles = from a in Producible
			where a.Value.Buildable || a.Value.Visible
			select a.Key;
		buildableProducibles = from a in Producible
			where a.Value.Buildable
			select a.Key;
	}

	void INotifyCreated.Created(Actor self)
	{
		playerPower = self.Owner.PlayerActor.TraitOrDefault<PowerManager>();
		playerResources = self.Owner.PlayerActor.Trait<PlayerResources>();
		developerMode = self.Owner.PlayerActor.Trait<DeveloperMode>();
		techTree = self.Owner.PlayerActor.Trait<TechTree>();
		productionTraits = (from p in self.TraitsImplementing<Production>()
			where Enumerable.Contains(p.Info.Produces, Info.Type)
			select p).ToArray();
		CacheProducibles();
	}

	protected void ClearQueue()
	{
		foreach (ProductionItem item in Queue)
		{
			if (item.ResourcesPaid > 0)
			{
				playerResources.GiveResources(item.ResourcesPaid);
				item.RemainingCost += item.ResourcesPaid;
			}
			playerResources.GiveCash(item.TotalCost - item.RemainingCost);
		}
		Queue.Clear();
	}

	void INotifyOwnerChanged.OnOwnerChanged(Actor self, Player oldOwner, Player newOwner)
	{
		ClearQueue();
		playerPower = newOwner.PlayerActor.TraitOrDefault<PowerManager>();
		playerResources = newOwner.PlayerActor.Trait<PlayerResources>();
		developerMode = newOwner.PlayerActor.Trait<DeveloperMode>();
		techTree = newOwner.PlayerActor.Trait<TechTree>();
		if (!Info.Sticky)
		{
			Faction = self.Owner.Faction.InternalName;
			IsValidFaction = Info.Factions.Count == 0 || Info.Factions.Contains(Faction);
		}
		oldOwner.PlayerActor.Trait<TechTree>().Remove(this);
		CacheProducibles();
		techTree.Update();
	}

	void INotifyKilled.Killed(Actor killed, AttackInfo e)
	{
		if (killed == Actor)
		{
			ClearQueue();
			Enabled = false;
		}
	}

	void INotifySold.Selling(Actor self)
	{
		ClearQueue();
		Enabled = false;
	}

	void INotifySold.Sold(Actor self)
	{
	}

	void INotifyTransform.BeforeTransform(Actor self)
	{
		ClearQueue();
		Enabled = false;
	}

	void INotifyTransform.OnTransform(Actor self)
	{
	}

	void INotifyTransform.AfterTransform(Actor self)
	{
	}

	private void CacheProducibles()
	{
		Producible.Clear();
		if (!Enabled)
		{
			return;
		}
		foreach (ActorInfo item in AllBuildables(Info.Type))
		{
			BuildableInfo buildableInfo = item.TraitInfo<BuildableInfo>();
			Producible.Add(item, new ProductionState());
			techTree.Add(item.Name, buildableInfo.Prerequisites, buildableInfo.BuildLimit, this);
		}
	}

	private IEnumerable<ActorInfo> AllBuildables(string category)
	{
		return Actor.World.Map.Rules.Actors.Values.Where((ActorInfo x) => x.Name[0] != '^' && x.HasTraitInfo<BuildableInfo>() && x.TraitInfo<BuildableInfo>().Queue.Contains(category));
	}

	public void PrerequisitesAvailable(string key)
	{
		Producible[Actor.World.Map.Rules.Actors[key]].Buildable = true;
	}

	public void PrerequisitesUnavailable(string key)
	{
		Producible[Actor.World.Map.Rules.Actors[key]].Buildable = false;
	}

	public void PrerequisitesItemHidden(string key)
	{
		Producible[Actor.World.Map.Rules.Actors[key]].Visible = false;
	}

	public void PrerequisitesItemVisible(string key)
	{
		Producible[Actor.World.Map.Rules.Actors[key]].Visible = true;
	}

	public virtual bool IsProducing(ProductionItem item)
	{
		if (Queue.Count > 0)
		{
			return Queue[0] == item;
		}
		return false;
	}

	public virtual bool IsInQueue(ActorInfo actor)
	{
		return Queue.Any((ProductionItem i) => i.Item == actor.Name);
	}

	public ProductionItem CurrentItem()
	{
		return Queue.ElementAtOrDefault(0);
	}

	public virtual IEnumerable<ProductionItem> AllQueued()
	{
		return Queue;
	}

	public virtual IEnumerable<ActorInfo> AllItems()
	{
		if (productionTraits.Length != 0 && productionTraits.All((Production p) => p.IsTraitDisabled))
		{
			return Enumerable.Empty<ActorInfo>();
		}
		if (developerMode.AllTech)
		{
			return Producible.Keys;
		}
		return allProducibles;
	}

	public virtual IEnumerable<ActorInfo> BuildableItems()
	{
		if (productionTraits.Length != 0 && productionTraits.All((Production p) => p.IsTraitDisabled))
		{
			return Enumerable.Empty<ActorInfo>();
		}
		if (!Enabled)
		{
			return Enumerable.Empty<ActorInfo>();
		}
		if (!Info.PayUpFront && developerMode.AllTech)
		{
			return Producible.Keys;
		}
		if (Info.PayUpFront && developerMode.AllTech)
		{
			return Producible.Keys.Where((ActorInfo a) => GetProductionCost(a) <= playerResources.GetCashAndResources() || IsInQueue(a));
		}
		if (Info.PayUpFront)
		{
			return buildableProducibles.Where((ActorInfo a) => GetProductionCost(a) <= playerResources.GetCashAndResources() || IsInQueue(a));
		}
		return buildableProducibles;
	}

	public virtual bool AnyItemsToBuild()
	{
		if (Enabled && (productionTraits.Length == 0 || productionTraits.Any((Production p) => !p.IsTraitDisabled)))
		{
			if (!developerMode.AllTech || Producible.Keys.Count == 0)
			{
				return buildableProducibles.Any();
			}
			return true;
		}
		return false;
	}

	public bool CanBuild(ActorInfo actor)
	{
		if (!Producible.TryGetValue(actor, out var value))
		{
			return false;
		}
		if (!value.Buildable)
		{
			return developerMode.AllTech;
		}
		return true;
	}

	void ITick.Tick(Actor self)
	{
		Tick(self);
	}

	protected virtual void Tick(Actor self)
	{
		bool flag = false;
		bool flag2 = false;
		Production[] array = productionTraits;
		foreach (Production production in array)
		{
			flag |= !production.IsTraitDisabled;
			flag2 |= !production.IsTraitPaused;
		}
		if (!flag)
		{
			ClearQueue();
		}
		Enabled = IsValidFaction & flag;
		TickInner(self, !flag2);
	}

	protected virtual void TickInner(Actor self, bool allProductionPaused)
	{
		CancelUnbuildableItems();
		if (Queue.Count > 0 && !allProductionPaused)
		{
			Queue[0].Tick(playerResources);
		}
	}

	protected void CancelUnbuildableItems()
	{
		if (Queue.Count == 0)
		{
			return;
		}
		HashSet<string> hashSet = (from b in BuildableItems()
			select b.Name).ToHashSet();
		for (int num = Queue.Count - 1; num >= 0; num--)
		{
			if (!hashSet.Contains(Queue[num].Item))
			{
				if (Queue[num].ResourcesPaid > 0)
				{
					playerResources.GiveResources(Queue[num].ResourcesPaid);
					Queue[num].RemainingCost += Queue[num].ResourcesPaid;
				}
				playerResources.GiveCash(Queue[num].TotalCost - Queue[num].RemainingCost);
				EndProduction(Queue[num]);
			}
		}
	}

	public bool CanQueue(ActorInfo actor, out string notificationAudio, out string notificationText)
	{
		notificationAudio = Info.BlockedAudio;
		notificationText = Info.BlockedTextNotification;
		BuildableInfo buildableInfo = actor.TraitInfoOrDefault<BuildableInfo>();
		if (buildableInfo == null)
		{
			return false;
		}
		if (!developerMode.AllTech)
		{
			if (Info.PayUpFront && actor.TraitInfo<ValuedInfo>().Cost > playerResources.GetCashAndResources())
			{
				return false;
			}
			if (Info.QueueLimit > 0 && Queue.Count >= Info.QueueLimit)
			{
				notificationAudio = Info.LimitedAudio;
				notificationText = Info.LimitedTextNotification;
				return false;
			}
			int num = Enumerable.Count(Queue, (ProductionItem i) => i.Item == actor.Name);
			if (Info.ItemLimit > 0 && num >= Info.ItemLimit)
			{
				notificationAudio = Info.LimitedAudio;
				notificationText = Info.LimitedTextNotification;
				return false;
			}
			if (buildableInfo.BuildLimit > 0)
			{
				int num2 = Actor.Owner.World.ActorsHavingTrait<Buildable>().Count((Actor a) => a.Info.Name == actor.Name && a.Owner == Actor.Owner);
				if (num + num2 >= buildableInfo.BuildLimit)
				{
					return false;
				}
			}
		}
		notificationAudio = Info.QueuedAudio;
		notificationText = Info.QueuedTextNotification;
		return true;
	}

	public void ResolveOrder(Actor self, Order order)
	{
		if (!Enabled)
		{
			return;
		}
		Ruleset rules = self.World.Map.Rules;
		switch (order.OrderString)
		{
		case "StartProduction":
		{
			ActorInfo unit = rules.Actors[order.TargetString];
			BuildableInfo buildableInfo = unit.TraitInfo<BuildableInfo>();
			if (!buildableInfo.Queue.Contains(Info.Type) || BuildableItems().All((ActorInfo b) => b.Name != order.TargetString))
			{
				break;
			}
			int num = int.MaxValue;
			if (!developerMode.AllTech)
			{
				if (Info.QueueLimit > 0)
				{
					num = Info.QueueLimit - Queue.Count;
				}
				if (Info.ItemLimit > 0)
				{
					num = Math.Min(num, Info.ItemLimit - Enumerable.Count(Queue, (ProductionItem i) => i.Item == order.TargetString));
				}
				if (buildableInfo.BuildLimit > 0)
				{
					int num2 = Enumerable.Count(Queue, (ProductionItem pi) => pi.Item == order.TargetString);
					int num3 = self.Owner.World.ActorsHavingTrait<Buildable>().Count((Actor a) => a.Info.Name == order.TargetString && a.Owner == self.Owner);
					num = Math.Min(num, buildableInfo.BuildLimit - (num2 + num3));
				}
				if (num <= 0)
				{
					break;
				}
			}
			int productionCost = GetProductionCost(unit);
			int time = GetBuildTime(unit, buildableInfo);
			long num4 = Math.Min(num, order.ExtraData);
			for (int num5 = 0; num5 < num4; num5++)
			{
				if (Info.PayUpFront && productionCost > playerResources.GetCashAndResources())
				{
					break;
				}
				bool hasPlayedSound = false;
				BeginProduction(new ProductionItem(this, order.TargetString, productionCost, playerPower, () =>
				{
					self.World.AddFrameEndTask((World _) =>
					{
						if (Queue.Any((ProductionItem i) => i.Done && i.Item == unit.Name))
						{
							bool flag = unit.HasTraitInfo<BuildingInfo>();
							if (flag && !hasPlayedSound)
							{
								hasPlayedSound = Game.Sound.PlayNotification(rules, self.Owner, "Speech", Info.ReadyAudio, self.Owner.Faction.InternalName);
								TextNotificationsManager.AddTransientLine(self.Owner, Info.ReadyTextNotification);
							}
							else if (!flag)
							{
								if (BuildUnit(unit))
								{
									Game.Sound.PlayNotification(rules, self.Owner, "Speech", Info.ReadyAudio, self.Owner.Faction.InternalName);
									TextNotificationsManager.AddTransientLine(self.Owner, Info.ReadyTextNotification);
								}
								else if (!hasPlayedSound && time > 0)
								{
									hasPlayedSound = Game.Sound.PlayNotification(rules, self.Owner, "Speech", Info.BlockedAudio, self.Owner.Faction.InternalName);
									TextNotificationsManager.AddTransientLine(self.Owner, Info.BlockedTextNotification);
								}
							}
						}
					});
				}), !order.Queued);
			}
			break;
		}
		case "PauseProduction":
			PauseProduction(order.TargetString, order.ExtraData != 0);
			break;
		case "CancelProduction":
			CancelProduction(order.TargetString, order.ExtraData);
			break;
		}
	}

	public virtual int GetBuildTime(ActorInfo unit, BuildableInfo bi)
	{
		if (developerMode.FastBuild)
		{
			return 0;
		}
		int num = bi.BuildDuration;
		if (num == -1)
		{
			num = GetProductionCost(unit);
		}
		IEnumerable<int> percentages = (from t in unit.TraitInfos<IProductionTimeModifierInfo>()
			select t.GetProductionTimeModifier(techTree, Info.Type)).Append(bi.BuildDurationModifier).Append(Info.BuildDurationModifier);
		return Util.ApplyPercentageModifiers(num, percentages);
	}

	public virtual int GetProductionCost(ActorInfo unit)
	{
		ValuedInfo valuedInfo = unit.TraitInfoOrDefault<ValuedInfo>();
		if (valuedInfo == null)
		{
			return 0;
		}
		IEnumerable<int> percentages = from t in unit.TraitInfos<IProductionCostModifierInfo>()
			select t.GetProductionCostModifier(techTree, Info.Type);
		return Util.ApplyPercentageModifiers(valuedInfo.Cost, percentages);
	}

	protected virtual void PauseProduction(string itemName, bool paused)
	{
		Queue.FirstOrDefault((ProductionItem a) => a.Item == itemName)?.Pause(paused);
	}

	protected virtual void CancelProduction(string itemName, uint numberToCancel)
	{
		for (int i = 0; i < numberToCancel; i++)
		{
			if (!CancelProductionInner(itemName))
			{
				break;
			}
		}
	}

	protected bool CancelProductionInner(string itemName)
	{
		ProductionItem productionItem = Queue.LastOrDefault((ProductionItem a) => a.Item == itemName);
		if (productionItem != null)
		{
			if (productionItem.Infinite)
			{
				productionItem.Infinite = false;
				for (int num = 1; num < Info.InfiniteBuildLimit; num++)
				{
					Queue.Add(new ProductionItem(this, productionItem.Item, productionItem.TotalCost, playerPower, productionItem.OnComplete));
				}
			}
			else
			{
				if (productionItem.ResourcesPaid > 0)
				{
					playerResources.GiveResources(productionItem.ResourcesPaid);
					productionItem.RemainingCost += productionItem.ResourcesPaid;
				}
				playerResources.GiveCash(productionItem.TotalCost - productionItem.RemainingCost);
				EndProduction(productionItem);
			}
			return true;
		}
		return false;
	}

	public void EndProduction(ProductionItem item)
	{
		Queue.Remove(item);
		if (item.Infinite)
		{
			Queue.Add(new ProductionItem(this, item.Item, item.TotalCost, playerPower, item.OnComplete)
			{
				Infinite = true
			});
		}
	}

	protected virtual void BeginProduction(ProductionItem item, bool hasPriority)
	{
		if (Info.PayUpFront)
		{
			if (playerResources.Resources > 0 && playerResources.Resources <= item.TotalCost)
			{
				item.ResourcesPaid = playerResources.Resources;
			}
			else if (playerResources.Resources > item.TotalCost)
			{
				item.ResourcesPaid = item.TotalCost;
			}
			playerResources.TakeCash(item.TotalCost);
			item.RemainingCost = 0;
		}
		if (Queue.Any((ProductionItem i) => i.Item == item.Item && i.Infinite))
		{
			return;
		}
		if (hasPriority && Queue.Count > 1)
		{
			Queue.Insert(1, item);
		}
		else
		{
			Queue.Add(item);
		}
		if (Info.InfiniteBuildLimit < 0)
		{
			return;
		}
		List<ProductionItem> list = Queue.FindAll((ProductionItem i) => i.Item == item.Item);
		if (list.Count <= Info.InfiniteBuildLimit)
		{
			return;
		}
		list[0].Infinite = true;
		for (int num = 1; num < list.Count; num++)
		{
			if (list[num].ResourcesPaid > 0)
			{
				playerResources.GiveResources(list[num].ResourcesPaid);
				list[num].RemainingCost += list[num].ResourcesPaid;
			}
			playerResources.GiveCash(list[num].TotalCost - list[num].RemainingCost);
			EndProduction(list[num]);
		}
	}

	public virtual int RemainingTimeActual(ProductionItem item)
	{
		return item.RemainingTimeActual;
	}

	public virtual TraitPair<Production> MostLikelyProducer()
	{
		Production trait = (from p in productionTraits
			where !p.IsTraitDisabled && Enumerable.Contains(p.Info.Produces, Info.Type)
			orderby p.IsTraitPaused
			select p).FirstOrDefault();
		return new TraitPair<Production>(Actor, trait);
	}

	protected virtual bool BuildUnit(ActorInfo unit)
	{
		Production trait = MostLikelyProducer().Trait;
		if (!Actor.IsInWorld || Actor.IsDead || trait == null)
		{
			CancelProduction(unit.Name, 1u);
			return false;
		}
		TypeDictionary inits = new TypeDictionary
		{
			new OwnerInit(Actor.Owner),
			new FactionInit(BuildableInfo.GetInitialFaction(unit, Faction))
		};
		BuildableInfo buildableInfo = unit.TraitInfo<BuildableInfo>();
		string productionType = (developerMode.AllTech ? Info.Type : (buildableInfo.BuildAtProductionType ?? Info.Type));
		ProductionItem productionItem = Queue.First((ProductionItem i) => i.Done && i.Item == unit.Name);
		if (!trait.IsTraitPaused && trait.Produce(Actor, unit, productionType, inits, productionItem.TotalCost))
		{
			EndProduction(productionItem);
			return true;
		}
		return false;
	}
}
