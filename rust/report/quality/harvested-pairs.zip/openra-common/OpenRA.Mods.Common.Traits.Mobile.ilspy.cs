using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Activities;
using OpenRA.Mods.Common.Activities;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA.Mods.Common.Traits;

public class Mobile : PausableConditionalTrait<MobileInfo>, IIssueOrder, IResolveOrder, IOrderVoice, IPositionable, IOccupySpace, IMove, ITick, ICreationActivity, IFacing, IDeathActorInitModifier, INotifyAddedToWorld, INotifyRemovedFromWorld, INotifyBlockingMove, IActorPreviewInitModifier, INotifyBecomingIdle
{
	public class ReturnToCellActivity : Activity
	{
		private readonly Mobile mobile;

		private readonly bool recalculateSubCell;

		private CPos cell;

		private SubCell subCell;

		private WPos pos;

		private readonly int delay;

		public ReturnToCellActivity(Actor self, int delay = 0, bool recalculateSubCell = false)
		{
			mobile = self.Trait<Mobile>();
			IsInterruptible = false;
			this.delay = delay;
			this.recalculateSubCell = recalculateSubCell;
		}

		protected override void OnFirstRun(Actor self)
		{
			pos = self.CenterPosition;
			if (self.World.Map.DistanceAboveTerrain(pos) > WDist.Zero && self.TraitOrDefault<Parachutable>() != null)
			{
				QueueChild(new Parachute(self));
			}
		}

		public override bool Tick(Actor self)
		{
			pos = self.CenterPosition;
			cell = mobile.ToCell;
			subCell = mobile.ToSubCell;
			if (recalculateSubCell)
			{
				subCell = (mobile.Info.LocomotorInfo.SharesCell ? self.World.ActorMap.FreeSubCell(cell, subCell, (Actor a) => a != self) : SubCell.FullCell);
			}
			if (subCell == SubCell.Invalid)
			{
				subCell = self.World.Map.Grid.DefaultSubCell;
			}
			mobile.SetPosition(self, cell, subCell);
			mobile.SetCenterPosition(self, pos);
			if (delay > 0)
			{
				QueueChild(new Wait(delay));
			}
			QueueChild(mobile.LocalMove(self, pos, self.World.Map.CenterOfSubCell(cell, subCell)));
			return true;
		}
	}

	public class LeaveProductionActivity : Activity
	{
		private readonly Mobile mobile;

		private readonly int delay;

		private readonly CPos[] rallyPoint;

		private readonly ReturnToCellActivity returnToCell;

		public LeaveProductionActivity(Actor self, int delay, CPos[] rallyPoint, ReturnToCellActivity returnToCell)
		{
			mobile = self.Trait<Mobile>();
			this.delay = delay;
			this.rallyPoint = rallyPoint;
			this.returnToCell = returnToCell;
		}

		protected override void OnFirstRun(Actor self)
		{
			if (returnToCell != null)
			{
				QueueChild(returnToCell);
			}
			else if (delay > 0)
			{
				QueueChild(new Wait(delay));
			}
			if (rallyPoint == null)
			{
				return;
			}
			CPos[] array = rallyPoint;
			foreach (CPos cell in array)
			{
				QueueChild(new AttackMoveActivity(self, () => mobile.MoveTo(cell, 1, null, evaluateNearestMovableCell: true, Color.OrangeRed)));
			}
		}

		public override IEnumerable<Target> GetTargets(Actor self)
		{
			if (ChildActivity != null)
			{
				return ChildActivity.GetTargets(self);
			}
			return Target.None;
		}

		public override IEnumerable<TargetLineNode> TargetLineNodes(Actor self)
		{
			for (Activity a = ChildActivity; a != null; a = a.NextActivity)
			{
				if (!a.IsCanceling)
				{
					foreach (TargetLineNode item in a.TargetLineNodes(self))
					{
						yield return item;
					}
				}
			}
		}
	}

	private sealed class MoveOrderTargeter : IOrderTargeter
	{
		private readonly Mobile mobile;

		private readonly LocomotorInfo locomotorInfo;

		private readonly bool rejectMove;

		public string OrderID => "Move";

		public int OrderPriority => 4;

		public bool IsQueued { get; private set; }

		public bool TargetOverridesSelection(Actor self, in Target target, List<Actor> actorsAt, CPos xy, TargetModifiers modifiers)
		{
			if (target.Type == TargetType.Actor && (target.Actor.Owner != self.Owner || self.World.Selection.Contains(target.Actor)))
			{
				return true;
			}
			return modifiers.HasModifier(TargetModifiers.ForceMove);
		}

		public MoveOrderTargeter(Actor self, Mobile unit)
		{
			mobile = unit;
			locomotorInfo = mobile.Info.LocomotorInfo;
			rejectMove = !self.AcceptsOrder("Move");
		}

		public bool CanTarget(Actor self, in Target target, ref TargetModifiers modifiers, ref string cursor)
		{
			if (rejectMove || target.Type != TargetType.Terrain || (mobile.requireForceMove && !modifiers.HasModifier(TargetModifiers.ForceMove)))
			{
				return false;
			}
			CPos cell = self.World.Map.CellContaining(target.CenterPosition);
			IsQueued = modifiers.HasModifier(TargetModifiers.ForceQueue);
			bool flag = self.Owner.Shroud.IsExplored(cell);
			if (mobile.IsTraitPaused || !self.World.Map.Contains(cell) || (!flag && !locomotorInfo.MoveIntoShroud) || (flag && mobile.Locomotor.MovementCostForCell(cell) == short.MaxValue))
			{
				cursor = mobile.Info.BlockedCursor;
			}
			else if (!flag || !mobile.Info.TerrainCursors.TryGetValue(self.World.Map.GetTerrainInfo(cell).Type, out cursor))
			{
				cursor = mobile.Info.Cursor;
			}
			return true;
		}

		bool IOrderTargeter.CanTarget(Actor self, in Target target, ref TargetModifiers modifiers, ref string cursor)
		{
			return CanTarget(self, in target, ref modifiers, ref cursor);
		}

		bool IOrderTargeter.TargetOverridesSelection(Actor self, in Target target, List<Actor> actorsAt, CPos xy, TargetModifiers modifiers)
		{
			return TargetOverridesSelection(self, in target, actorsAt, xy, modifiers);
		}
	}

	private readonly Actor self;

	private readonly Lazy<IEnumerable<int>> speedModifiers;

	private readonly bool returnToCellOnCreation;

	private readonly bool returnToCellOnCreationRecalculateSubCell = true;

	private readonly int creationActivityDelay;

	private readonly CPos[] creationRallypoint;

	private MovementType movementTypes;

	private WRot terrainRampOrientation = WRot.None;

	private WAngle oldFacing;

	private WRot orientation;

	private WPos oldPos;

	public SubCell FromSubCell;

	public SubCell ToSubCell;

	private INotifyCustomLayerChanged[] notifyCustomLayerChanged;

	private INotifyCenterPositionChanged[] notifyCenterPositionChanged;

	private INotifyMoving[] notifyMoving;

	private INotifyFinishedMoving[] notifyFinishedMoving;

	private IWrapMove[] moveWrappers;

	private bool requireForceMove;

	public bool TurnToMove;

	public MovementType CurrentMovementTypes
	{
		get
		{
			return movementTypes;
		}
		set
		{
			MovementType movementType = movementTypes;
			movementTypes = value;
			if (value != movementType)
			{
				self.World.ActorMap.UpdateOccupiedCells(self.OccupiesSpace);
				INotifyMoving[] array = this.notifyMoving;
				foreach (INotifyMoving notifyMoving in array)
				{
					notifyMoving.MovementTypeChanged(self, value);
				}
			}
		}
	}

	public bool IsImmovable { get; private set; }

	public bool IsBlocking { get; private set; }

	public bool IsMovingBetweenCells => FromCell != ToCell;

	public MoveResult MoveResult { get; set; }

	[Sync]
	public WAngle Facing
	{
		get
		{
			return orientation.Yaw;
		}
		set
		{
			orientation = orientation.WithYaw(value);
		}
	}

	public WRot Orientation => orientation.Rotate(in terrainRampOrientation);

	public WAngle TurnSpeed => Info.TurnSpeed;

	[Sync]
	public CPos FromCell { get; private set; }

	[Sync]
	public CPos ToCell { get; private set; }

	public Locomotor Locomotor { get; private set; }

	public IPathFinder PathFinder { get; private set; }

	[Sync]
	public WPos CenterPosition { get; private set; }

	public CPos TopLeft => ToCell;

	IEnumerable<IOrderTargeter> IIssueOrder.Orders
	{
		get
		{
			if (!IsTraitDisabled)
			{
				yield return new MoveOrderTargeter(self, this);
			}
		}
	}

	public (CPos, SubCell)[] OccupiedCells()
	{
		if (!(FromCell == ToCell))
		{
			if (!Info.LocomotorInfo.SharesCell)
			{
				return new (CPos, SubCell)[2]
				{
					(FromCell, FromSubCell),
					(ToCell, ToSubCell)
				};
			}
			return new (CPos, SubCell)[1] { (ToCell, ToSubCell) };
		}
		return new (CPos, SubCell)[1] { (FromCell, FromSubCell) };
	}

	public Mobile(ActorInitializer init, MobileInfo info)
		: base(info)
	{
		self = init.Self;
		speedModifiers = Exts.Lazy(() => from x in self.TraitsImplementing<ISpeedModifier>().ToArray()
			select x.GetSpeedModifier());
		ToSubCell = (FromSubCell = (info.LocomotorInfo.SharesCell ? init.World.Map.Grid.DefaultSubCell : SubCell.FullCell));
		SubCellInit orDefault = init.GetOrDefault<SubCellInit>();
		if (orDefault != null)
		{
			FromSubCell = (ToSubCell = orDefault.Value);
			returnToCellOnCreationRecalculateSubCell = false;
		}
		LocationInit orDefault2 = init.GetOrDefault<LocationInit>();
		if (orDefault2 != null)
		{
			FromCell = (ToCell = orDefault2.Value);
			SetCenterPosition(self, init.World.Map.CenterOfSubCell(FromCell, FromSubCell));
		}
		Facing = (oldFacing = init.GetValue<FacingInit, WAngle>(info.InitialFacing));
		CenterPositionInit orDefault3 = init.GetOrDefault<CenterPositionInit>();
		if (orDefault3 != null)
		{
			oldPos = orDefault3.Value;
			SetCenterPosition(self, oldPos);
			returnToCellOnCreation = true;
		}
		creationActivityDelay = init.GetValue<CreationActivityDelayInit, int>(0);
		creationRallypoint = init.GetOrDefault<RallyPointInit>()?.Value;
	}

	protected override void Created(Actor self)
	{
		notifyCustomLayerChanged = self.TraitsImplementing<INotifyCustomLayerChanged>().ToArray();
		notifyCenterPositionChanged = self.TraitsImplementing<INotifyCenterPositionChanged>().ToArray();
		notifyMoving = self.TraitsImplementing<INotifyMoving>().ToArray();
		notifyFinishedMoving = self.TraitsImplementing<INotifyFinishedMoving>().ToArray();
		moveWrappers = self.TraitsImplementing<IWrapMove>().ToArray();
		PathFinder = self.World.WorldActor.Trait<IPathFinder>();
		Locomotor = self.World.WorldActor.TraitsImplementing<Locomotor>().Single((Locomotor l) => l.Info.Name == Info.Locomotor);
		base.Created(self);
	}

	void ITick.Tick(Actor self)
	{
		UpdateMovement();
	}

	public void UpdateMovement()
	{
		MovementType movementType = MovementType.None;
		if ((oldPos - CenterPosition).HorizontalLengthSquared != 0L)
		{
			movementType |= MovementType.Horizontal;
		}
		if (oldPos.Z != CenterPosition.Z)
		{
			movementType |= MovementType.Vertical;
		}
		if (oldFacing != Facing)
		{
			movementType |= MovementType.Turn;
		}
		CurrentMovementTypes = movementType;
		oldPos = CenterPosition;
		oldFacing = Facing;
	}

	void INotifyAddedToWorld.AddedToWorld(Actor self)
	{
		self.World.AddToMaps(self, this);
	}

	void INotifyRemovedFromWorld.RemovedFromWorld(Actor self)
	{
		self.World.RemoveFromMaps(self, this);
	}

	protected override void TraitEnabled(Actor self)
	{
		self.World.ActorMap.UpdateOccupiedCells(self.OccupiesSpace);
	}

	protected override void TraitDisabled(Actor self)
	{
		self.World.ActorMap.UpdateOccupiedCells(self.OccupiesSpace);
	}

	protected override void TraitResumed(Actor self)
	{
		self.World.ActorMap.UpdateOccupiedCells(self.OccupiesSpace);
	}

	protected override void TraitPaused(Actor self)
	{
		self.World.ActorMap.UpdateOccupiedCells(self.OccupiesSpace);
	}

	public CPos? GetAdjacentCell(CPos nextCell, Func<CPos, bool> preferToAvoid = null)
	{
		List<CPos> list = new List<CPos>();
		List<CPos> list2 = new List<CPos>();
		CVec[] directions = CVec.Directions;
		foreach (CVec cVec in directions)
		{
			CPos cPos = ToCell + cVec;
			if (CanEnterCell(cPos) && CanStayInCell(cPos) && (preferToAvoid == null || !preferToAvoid(cPos)))
			{
				list.Add(cPos);
			}
			else if (cPos != nextCell && cPos != ToCell)
			{
				list2.Add(cPos);
			}
		}
		CPos? result = null;
		if (list.Count > 0)
		{
			result = list.Random(self.World.SharedRandom);
		}
		else
		{
			var anon = (from c in list2
				from a in self.World.ActorMap.GetActorsAt(c).Where(IsMovable)
				select new
				{
					Cell = c,
					Actor = a
				}).RandomOrDefault(self.World.SharedRandom);
			if (anon != null)
			{
				result = anon.Cell;
			}
		}
		return result;
	}

	private static bool IsMovable(Actor otherActor)
	{
		if (!otherActor.IsIdle)
		{
			return false;
		}
		Mobile mobile = otherActor.TraitOrDefault<Mobile>();
		if (mobile == null || mobile.IsTraitDisabled || mobile.IsTraitPaused || mobile.IsImmovable)
		{
			return false;
		}
		return true;
	}

	public bool IsLeaving()
	{
		if (CurrentMovementTypes.HasMovementType(MovementType.Horizontal))
		{
			return true;
		}
		if (CurrentMovementTypes.HasMovementType(MovementType.Turn))
		{
			return TurnToMove;
		}
		return false;
	}

	public bool CanInteractWithGroundLayer(Actor self)
	{
		if (ToCell.Layer == 0)
		{
			return true;
		}
		return self.World.GetCustomMovementLayers()[ToCell.Layer]?.InteractsWithDefaultLayer ?? true;
	}

	public SubCell GetValidSubCell(SubCell preferred = SubCell.Any)
	{
		if (preferred == SubCell.Any)
		{
			preferred = FromSubCell;
		}
		if (Info.LocomotorInfo.SharesCell)
		{
			if ((int)preferred <= 0)
			{
				return self.World.Map.Grid.DefaultSubCell;
			}
		}
		else if (preferred != SubCell.FullCell)
		{
			return SubCell.FullCell;
		}
		return preferred;
	}

	public void SetPosition(Actor self, CPos cell, SubCell subCell = SubCell.Any)
	{
		subCell = GetValidSubCell(subCell);
		SetLocation(cell, subCell, cell, subCell);
		WPos a = ((cell.Layer == 0) ? self.World.Map.CenterOfCell(cell) : self.World.GetCustomMovementLayers()[cell.Layer].CenterOfCell(cell)) + self.World.Map.Grid.OffsetOfSubCell(subCell);
		a -= ILSpyHelper_AsRefReadOnly(new WVec(0, 0, self.World.Map.DistanceAboveTerrain(a).Length));
		SetCenterPosition(self, a);
		FinishedMoving(self);
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	public void SetPosition(Actor self, WPos pos)
	{
		CPos cPos = self.World.Map.CellContaining(pos);
		SetLocation(cPos, FromSubCell, cPos, FromSubCell);
		SetCenterPosition(self, self.World.Map.CenterOfSubCell(cPos, FromSubCell) + new WVec(0, 0, self.World.Map.DistanceAboveTerrain(pos).Length));
		FinishedMoving(self);
	}

	public void SetCenterPosition(Actor self, WPos pos)
	{
		CenterPosition = pos;
		self.World.UpdateMaps(self, this);
		Map map = self.World.Map;
		SetTerrainRampOrientation(map.TerrainOrientation(map.CellContaining(pos)));
		if (this.notifyCenterPositionChanged != null)
		{
			INotifyCenterPositionChanged[] array = this.notifyCenterPositionChanged;
			foreach (INotifyCenterPositionChanged notifyCenterPositionChanged in array)
			{
				notifyCenterPositionChanged.CenterPositionChanged(self, FromCell.Layer, ToCell.Layer);
			}
		}
	}

	public void SetTerrainRampOrientation(WRot orientation)
	{
		if (Info.TerrainOrientationAdjustmentMargin.Length >= 0)
		{
			terrainRampOrientation = orientation;
		}
	}

	public bool IsLeavingCell(CPos location, SubCell subCell = SubCell.Any)
	{
		if (ToCell != location && FromCell == location)
		{
			if (subCell != SubCell.Any && FromSubCell != subCell && subCell != SubCell.FullCell)
			{
				return FromSubCell == SubCell.FullCell;
			}
			return true;
		}
		return false;
	}

	public SubCell GetAvailableSubCell(CPos a, SubCell preferredSubCell = SubCell.Any, Actor ignoreActor = null, BlockedByActor check = BlockedByActor.All)
	{
		return Locomotor.GetAvailableSubCell(self, a, check, preferredSubCell, ignoreActor);
	}

	public bool CanExistInCell(CPos cell)
	{
		return Locomotor.MovementCostForCell(cell) != short.MaxValue;
	}

	public bool CanEnterCell(CPos cell, Actor ignoreActor = null, BlockedByActor check = BlockedByActor.All)
	{
		return Info.CanEnterCell(self.World, self, cell, ToSubCell, ignoreActor, check);
	}

	public bool CanStayInCell(CPos cell)
	{
		return Info.CanStayInCell(self.World, cell);
	}

	public void SetLocation(CPos from, SubCell fromSub, CPos to, SubCell toSub)
	{
		if (FromCell == from && ToCell == to && FromSubCell == fromSub && ToSubCell == toSub)
		{
			return;
		}
		RemoveInfluence();
		FromCell = from;
		ToCell = to;
		FromSubCell = fromSub;
		ToSubCell = toSub;
		AddInfluence();
		IsBlocking = false;
		if (ToCell.Layer != FromCell.Layer)
		{
			INotifyCustomLayerChanged[] array = this.notifyCustomLayerChanged;
			foreach (INotifyCustomLayerChanged notifyCustomLayerChanged in array)
			{
				notifyCustomLayerChanged.CustomLayerChanged(self, FromCell.Layer, ToCell.Layer);
			}
		}
	}

	public void FinishedMoving(Actor self)
	{
		if (FromCell.Layer == ToCell.Layer)
		{
			INotifyFinishedMoving[] array = this.notifyFinishedMoving;
			foreach (INotifyFinishedMoving notifyFinishedMoving in array)
			{
				notifyFinishedMoving.FinishedMoving(self, FromCell.Layer, ToCell.Layer);
			}
		}
		if (self.IsAtGroundLevel())
		{
			CrushAction(self, (INotifyCrushed notifyCrushed) => notifyCrushed.OnCrush);
		}
	}

	private void CrushAction(Actor self, Func<INotifyCrushed, Action<Actor, Actor, BitSet<CrushClass>>> action)
	{
		IEnumerable<TraitPair<ICrushable>> enumerable = (from a in self.World.ActorMap.GetActorsAt(ToCell, ToSubCell)
			where a != self
			select a).SelectMany((Actor a) => a.Crushables.Select((ICrushable t) => new TraitPair<ICrushable>(a, t)));
		foreach (TraitPair<ICrushable> item in enumerable)
		{
			if (!item.Trait.CrushableBy(item.Actor, self, Info.LocomotorInfo.Crushes) || !item.Actor.IsAtGroundLevel())
			{
				continue;
			}
			foreach (INotifyCrushed item2 in item.Actor.TraitsImplementing<INotifyCrushed>())
			{
				action(item2)(item.Actor, self, Info.LocomotorInfo.Crushes);
			}
		}
	}

	public void AddInfluence()
	{
		if (self.IsInWorld)
		{
			self.World.ActorMap.AddInfluence(self, this);
		}
	}

	public void RemoveInfluence()
	{
		if (self.IsInWorld)
		{
			self.World.ActorMap.RemoveInfluence(self, this);
		}
	}

	private Activity WrapMove(Activity inner)
	{
		IWrapMove wrapMove = moveWrappers.FirstEnabledTraitOrDefault();
		if (wrapMove != null)
		{
			return wrapMove.WrapMove(inner);
		}
		return inner;
	}

	public Activity MoveTo(CPos cell, int nearEnough = 0, Actor ignoreActor = null, bool evaluateNearestMovableCell = false, Color? targetLineColor = null)
	{
		return WrapMove(new Move(self, cell, WDist.FromCells(nearEnough), ignoreActor, evaluateNearestMovableCell, targetLineColor));
	}

	public Activity MoveWithinRange(in Target target, WDist range, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return WrapMove(new MoveWithinRange(self, in target, WDist.Zero, range, initialTargetPosition, targetLineColor));
	}

	public Activity MoveWithinRange(in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return WrapMove(new MoveWithinRange(self, in target, minRange, maxRange, initialTargetPosition, targetLineColor));
	}

	public Activity MoveFollow(Actor self, in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return WrapMove(new Follow(self, in target, minRange, maxRange, initialTargetPosition, targetLineColor));
	}

	public Activity ReturnToCell(Actor self)
	{
		return new ReturnToCellActivity(self);
	}

	public Activity MoveToTarget(Actor self, in Target target, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		if (target.Type == TargetType.Invalid)
		{
			return null;
		}
		return WrapMove(new MoveAdjacentTo(self, in target, initialTargetPosition, targetLineColor));
	}

	public Activity MoveIntoTarget(Actor self, in Target target)
	{
		if (target.Type == TargetType.Invalid)
		{
			return null;
		}
		return WrapMove(new LocalMoveIntoTarget(self, in target, new WDist(512)));
	}

	public Activity MoveOntoTarget(Actor self, in Target target, in WVec offset, WAngle? facing, Color? targetLineColor = null)
	{
		return WrapMove(new MoveOntoAndTurn(self, in target, in offset, facing, targetLineColor));
	}

	public Activity LocalMove(Actor self, WPos fromPos, WPos toPos)
	{
		return WrapMove(LocalMove(self, fromPos, toPos, self.Location));
	}

	public int EstimatedMoveDuration(Actor self, WPos fromPos, WPos toPos)
	{
		int num = MovementSpeedForCell(self.Location);
		if (num <= 0)
		{
			return 0;
		}
		return (toPos - fromPos).Length / num;
	}

	public CPos NearestMoveableCell(CPos target)
	{
		return NearestMoveableCell(target, 1, 10);
	}

	public bool CanEnterTargetNow(Actor self, in Target target)
	{
		if (target.Type == TargetType.FrozenActor && !target.FrozenActor.IsValid)
		{
			return false;
		}
		if (!(self.Location == self.World.Map.CellContaining(target.CenterPosition)))
		{
			return Util.AdjacentCells(self.World, in target).Any((CPos c) => c == self.Location);
		}
		return true;
	}

	public int MovementSpeedForCell(CPos cell)
	{
		int num = Locomotor.MovementSpeedForCell(cell);
		IEnumerable<int> percentages = speedModifiers.Value.Append(num);
		return Util.ApplyPercentageModifiers(Info.Speed, percentages);
	}

	public CPos NearestMoveableCell(CPos target, int minRange, int maxRange)
	{
		if (target.Layer != 0)
		{
			target = new CPos(target.X, target.Y);
		}
		if (target == self.Location && CanStayInCell(target))
		{
			return target;
		}
		if (CanEnterCell(target, null, BlockedByActor.Immovable) && CanStayInCell(target))
		{
			return target;
		}
		foreach (CPos item in self.World.Map.FindTilesInAnnulus(target, minRange, maxRange))
		{
			if (CanEnterCell(item, null, BlockedByActor.Immovable) && CanStayInCell(item))
			{
				return item;
			}
		}
		return target;
	}

	public CPos NearestCell(CPos target, Func<CPos, bool> check, int minRange, int maxRange)
	{
		if (check(target))
		{
			return target;
		}
		foreach (CPos item in self.World.Map.FindTilesInAnnulus(target, minRange, maxRange))
		{
			if (check(item))
			{
				return item;
			}
		}
		return target;
	}

	public void EnteringCell(Actor self)
	{
		if (self.IsAtGroundLevel())
		{
			CrushAction(self, (INotifyCrushed notifyCrushed) => notifyCrushed.WarnCrush);
		}
	}

	public Activity MoveTo(Func<BlockedByActor, (bool AlreadyAtDestination, List<CPos> Path)> pathFunc)
	{
		return new Move(self, pathFunc);
	}

	private Activity LocalMove(Actor self, WPos fromPos, WPos toPos, CPos cell)
	{
		int num = MovementSpeedForCell(cell);
		int length = ((num > 0) ? ((toPos - fromPos).Length / num) : 0);
		WVec wVec = toPos - fromPos;
		WAngle value = ((wVec.HorizontalLengthSquared != 0L) ? wVec.Yaw : Facing);
		return new Drag(self, fromPos, toPos, length, value);
	}

	private CPos? ClosestGroundCell()
	{
		CPos cPos = new CPos(TopLeft.X, TopLeft.Y);
		if (CanEnterCell(cPos))
		{
			return cPos;
		}
		List<CPos> list = PathFinder.FindPathToTargetCellByPredicate(self, new CPos[1] { self.Location }, (CPos loc) => loc.Layer == 0 && CanEnterCell(loc), BlockedByActor.All);
		if (list.Count > 0)
		{
			return list[0];
		}
		return null;
	}

	void IActorPreviewInitModifier.ModifyActorPreviewInit(Actor self, TypeDictionary inits)
	{
		if (!inits.Contains<DynamicFacingInit>() && !inits.Contains<FacingInit>())
		{
			inits.Add(new DynamicFacingInit(() => Facing));
		}
	}

	void IDeathActorInitModifier.ModifyDeathActorInit(Actor self, TypeDictionary init)
	{
		init.Add(new FacingInit(Facing));
		if (CanEnterCell(self.Location, self, BlockedByActor.Stationary))
		{
			init.Add(new HuskSpeedInit(MovementSpeedForCell(self.Location)));
		}
	}

	void INotifyBecomingIdle.OnBecomingIdle(Actor self)
	{
		if (self.Location.Layer == 0)
		{
			if (!Locomotor.CanStayInCell(self.Location))
			{
				self.QueueActivity(MoveTo(self.Location, 0, null, evaluateNearestMovableCell: true));
			}
			return;
		}
		ICustomMovementLayer customMovementLayer = self.World.GetCustomMovementLayers()[self.Location.Layer];
		if (customMovementLayer.ReturnToGroundLayerOnIdle)
		{
			CPos? cPos = ClosestGroundCell();
			if (cPos.HasValue)
			{
				self.QueueActivity(MoveTo(cPos.Value));
			}
		}
	}

	void INotifyBlockingMove.OnNotifyBlockingMove(Actor self, Actor blocking)
	{
		if (self.AppearsFriendlyTo(blocking))
		{
			if (self.IsIdle)
			{
				self.QueueActivity(queued: false, new Nudge(blocking));
			}
			else
			{
				IsBlocking = true;
			}
		}
	}

	public override IEnumerable<VariableObserver> GetVariableObservers()
	{
		foreach (VariableObserver variableObserver in base.GetVariableObservers())
		{
			yield return variableObserver;
		}
		if (Info.RequireForceMoveCondition != null)
		{
			yield return new VariableObserver(RequireForceMoveConditionChanged, Info.RequireForceMoveCondition.Variables);
		}
		if (Info.ImmovableCondition != null)
		{
			yield return new VariableObserver(ImmovableConditionChanged, Info.ImmovableCondition.Variables);
		}
	}

	private void RequireForceMoveConditionChanged(Actor self, IReadOnlyDictionary<string, int> conditions)
	{
		requireForceMove = Info.RequireForceMoveCondition.Evaluate(conditions);
	}

	private void ImmovableConditionChanged(Actor self, IReadOnlyDictionary<string, int> conditions)
	{
		bool isImmovable = IsImmovable;
		IsImmovable = Info.ImmovableCondition.Evaluate(conditions);
		if (isImmovable != IsImmovable)
		{
			self.World.ActorMap.UpdateOccupiedCells(self.OccupiesSpace);
		}
	}

	Order IIssueOrder.IssueOrder(Actor self, IOrderTargeter order, in Target target, bool queued)
	{
		if (order is MoveOrderTargeter)
		{
			return new Order("Move", self, in target, queued);
		}
		return null;
	}

	void IResolveOrder.ResolveOrder(Actor self, Order order)
	{
		if (IsTraitDisabled)
		{
			return;
		}
		if (order.OrderString == "Move")
		{
			if (order.Target.IsValidFor(self))
			{
				CPos cPos = self.World.Map.Clamp(this.self.World.Map.CellContaining(order.Target.CenterPosition));
				if (Info.LocomotorInfo.MoveIntoShroud || self.Owner.Shroud.IsExplored(cPos))
				{
					self.QueueActivity(order.Queued, WrapMove(new Move(self, cPos, WDist.FromCells(8), null, evaluateNearestMovableCell: true, Info.TargetLineColor)));
					self.ShowTargetLines();
				}
			}
		}
		else if (order.OrderString == "Stop")
		{
			self.CancelActivity();
		}
		else if (order.OrderString == "Scatter")
		{
			self.QueueActivity(order.Queued, new Nudge(self));
			self.ShowTargetLines();
		}
	}

	string IOrderVoice.VoicePhraseForOrder(Actor self, Order order)
	{
		if (IsTraitDisabled)
		{
			return null;
		}
		switch (order.OrderString)
		{
		case "Move":
			if (!Info.LocomotorInfo.MoveIntoShroud && order.Target.Type != TargetType.Invalid)
			{
				CPos cell = self.World.Map.CellContaining(order.Target.CenterPosition);
				if (!self.Owner.Shroud.IsExplored(cell))
				{
					return null;
				}
			}
			return Info.Voice;
		case "Scatter":
		case "Stop":
			return Info.Voice;
		default:
			return null;
		}
	}

	Activity ICreationActivity.GetCreationActivity()
	{
		if (returnToCellOnCreation || creationRallypoint != null || creationActivityDelay > 0)
		{
			return new LeaveProductionActivity(self, creationActivityDelay, creationRallypoint, returnToCellOnCreation ? new ReturnToCellActivity(self, creationActivityDelay, returnToCellOnCreationRecalculateSubCell) : null);
		}
		return null;
	}

	Activity IMove.MoveWithinRange(in Target target, WDist range, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveWithinRange(in target, range, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveWithinRange(in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveWithinRange(in target, minRange, maxRange, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveFollow(Actor self, in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveFollow(self, in target, minRange, maxRange, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveToTarget(Actor self, in Target target, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveToTarget(self, in target, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveIntoTarget(Actor self, in Target target)
	{
		return MoveIntoTarget(self, in target);
	}

	Activity IMove.MoveOntoTarget(Actor self, in Target target, in WVec offset, WAngle? facing, Color? targetLineColor = null)
	{
		return MoveOntoTarget(self, in target, in offset, facing, targetLineColor);
	}

	bool IMove.CanEnterTargetNow(Actor self, in Target target)
	{
		return CanEnterTargetNow(self, in target);
	}
}
