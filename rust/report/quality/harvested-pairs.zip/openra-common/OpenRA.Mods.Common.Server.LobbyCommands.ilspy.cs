using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using OpenRA.Mods.Common.Traits;
using OpenRA.Mods.Common.Widgets.Logic;
using OpenRA.Network;
using OpenRA.Primitives;
using OpenRA.Server;
using OpenRA.Support;
using OpenRA.Traits;

namespace OpenRA.Mods.Common.Server;

public class LobbyCommands : ServerTrait, IInterpretCommand, INotifyServerStart, INotifyServerEmpty, IClientJoined, OpenRA.Server.ITick
{
	[FluentReference]
	private const string CustomRules = "notification-custom-rules";

	[FluentReference]
	private const string OnlyHostStartGame = "notification-admin-start-game";

	[FluentReference]
	private const string NoStartUntilRequiredSlotsFull = "notification-no-start-until-required-slots-full";

	[FluentReference]
	private const string NoStartWithoutPlayers = "notification-no-start-without-players";

	[FluentReference]
	private const string TwoHumansRequired = "notification-two-humans-required";

	[FluentReference]
	private const string InsufficientEnabledSpawnPoints = "notification-insufficient-enabled-spawn-points";

	[FluentReference(new string[] { "command" })]
	private const string MalformedCommand = "notification-malformed-command";

	[FluentReference]
	private const string KickNone = "notification-kick-none";

	[FluentReference]
	private const string NoKickSelf = "notification-kick-self";

	[FluentReference]
	private const string NoKickGameStarted = "notification-no-kick-game-started";

	[FluentReference(new string[] { "admin", "player" })]
	private const string AdminKicked = "notification-admin-kicked";

	[FluentReference(new string[] { "player" })]
	private const string Kicked = "notification-kicked";

	[FluentReference(new string[] { "admin", "player" })]
	private const string TempBan = "notification-temp-ban";

	[FluentReference]
	private const string NoTransferAdmin = "notification-admin-transfer-admin";

	[FluentReference]
	private const string EmptySlot = "notification-empty-slot";

	[FluentReference(new string[] { "admin", "player" })]
	private const string MoveSpectators = "notification-move-spectators";

	[FluentReference(new string[] { "player", "name" })]
	private const string Nick = "notification-nick-changed";

	[FluentReference]
	private const string StateUnchangedReady = "notification-state-unchanged-ready";

	[FluentReference(new string[] { "command" })]
	private const string StateUnchangedGameStarted = "notification-state-unchanged-game-started";

	[FluentReference(new string[] { "faction" })]
	private const string InvalidFactionSelected = "notification-invalid-faction-selected";

	[FluentReference]
	private const string RequiresHost = "notification-requires-host";

	[FluentReference]
	private const string InvalidBotSlot = "notification-invalid-bot-slot";

	[FluentReference]
	private const string InvalidBotType = "notification-invalid-bot-type";

	[FluentReference]
	private const string HostChangeMap = "notification-admin-change-map";

	[FluentReference]
	private const string UnknownMap = "notification-unknown-map";

	[FluentReference]
	private const string SearchingMap = "notification-searching-map";

	[FluentReference]
	private const string NotAdmin = "notification-admin-change-configuration";

	[FluentReference]
	private const string InvalidConfigurationCommand = "notification-invalid-configuration-command";

	[FluentReference(new string[] { "option" })]
	private const string OptionLocked = "notification-option-locked";

	[FluentReference(new string[] { "player", "map" })]
	private const string ChangedMap = "notification-changed-map";

	[FluentReference]
	private const string MapBotsDisabled = "notification-map-bots-disabled";

	[FluentReference(new string[] { "player", "name", "value" })]
	private const string ValueChanged = "notification-option-changed";

	[FluentReference]
	private const string NoMoveSpectators = "notification-admin-move-spectators";

	[FluentReference]
	private const string AdminOption = "notification-admin-option";

	[FluentReference(new string[] { "raw" })]
	private const string NumberTeams = "notification-error-number-teams";

	[FluentReference]
	private const string AdminClearSpawn = "notification-admin-clear-spawn";

	[FluentReference]
	private const string SpawnOccupied = "notification-spawn-occupied";

	[FluentReference]
	private const string SpawnLocked = "notification-spawn-locked";

	[FluentReference]
	private const string AdminLobbyInfo = "notification-admin-lobby-info";

	[FluentReference]
	private const string InvalidLobbyInfo = "notification-invalid-lobby-info";

	[FluentReference]
	private const string AdminKick = "notification-admin-kick";

	[FluentReference]
	private const string SlotClosed = "notification-slot-closed";

	[FluentReference(new string[] { "player" })]
	private const string NewAdmin = "notification-new-admin";

	[FluentReference]
	private const string YouWereKicked = "notification-you-were-kicked";

	[FluentReference]
	private const string VoteKickDisabled = "notification-vote-kick-disabled";

	private readonly IDictionary<string, Func<OpenRA.Server.Server, Connection, Session.Client, string, bool>> commandHandlers = new Dictionary<string, Func<OpenRA.Server.Server, Connection, Session.Client, string, bool>>
	{
		{ "state", State },
		{ "startgame", StartGame },
		{ "slot", Slot },
		{ "allow_spectators", AllowSpectators },
		{ "spectate", Specate },
		{ "slot_close", SlotClose },
		{ "slot_open", SlotOpen },
		{ "slot_bot", SlotBot },
		{ "map", Map },
		{ "option", Option },
		{ "reset_options", ResetOptions },
		{ "assignteams", AssignTeams },
		{ "kick", Kick },
		{ "vote_kick", VoteKick },
		{ "make_admin", MakeAdmin },
		{ "make_spectator", MakeSpectator },
		{ "name", Name },
		{ "faction", Faction },
		{ "team", Team },
		{ "handicap", Handicap },
		{ "spawn", Spawn },
		{ "clear_spawn", ClearPlayerSpawn },
		{ "color", PlayerColor },
		{ "sync_lobby", SyncLobby }
	};

	private static bool ValidateSlotCommand(OpenRA.Server.Server server, Connection conn, Session.Client client, string arg, bool requiresHost)
	{
		lock (server.LobbyInfo)
		{
			if (!server.LobbyInfo.Slots.ContainsKey(arg))
			{
				Log.Write("server", "Invalid slot: " + arg);
				return false;
			}
			if (requiresHost && !client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-requires-host");
				return false;
			}
			return true;
		}
	}

	public static bool ValidateCommand(OpenRA.Server.Server server, Connection conn, Session.Client client, string command)
	{
		lock (server.LobbyInfo)
		{
			if (command.StartsWith("kick ", StringComparison.Ordinal) || command.StartsWith("vote_kick ", StringComparison.Ordinal))
			{
				return true;
			}
			if (server.State == ServerState.GameStarted)
			{
				server.SendFluentMessageTo(conn, "notification-state-unchanged-game-started", new object[2] { "command", command });
				return false;
			}
			if (client.State == Session.ClientState.Ready && !command.StartsWith("state", StringComparison.Ordinal) && !(command == "startgame"))
			{
				server.SendFluentMessageTo(conn, "notification-state-unchanged-ready");
				return false;
			}
			return true;
		}
	}

	public bool InterpretCommand(OpenRA.Server.Server server, Connection conn, Session.Client client, string cmd)
	{
		if (server == null || conn == null || client == null || !ValidateCommand(server, conn, client, cmd))
		{
			return false;
		}
		string key = cmd.Split(' ').First();
		string arg = cmd.Split(' ').Skip(1).JoinWith(" ");
		if (!commandHandlers.TryGetValue(key, out var value))
		{
			return false;
		}
		return value(server, conn, client, arg);
	}

	private static void CheckAutoStart(OpenRA.Server.Server server)
	{
		lock (server.LobbyInfo)
		{
			IEnumerable<Session.Client> nonBotPlayers = server.LobbyInfo.NonBotPlayers;
			if (nonBotPlayers.Any((Session.Client c) => c.State != Session.ClientState.Ready) || server.LobbyInfo.Clients.First((Session.Client c) => c.IsAdmin).State != Session.ClientState.Ready || (!server.LobbyInfo.GlobalSettings.EnableSingleplayer && nonBotPlayers.Count() < 2) || server.LobbyInfo.Slots.Any((KeyValuePair<string, Session.Slot> sl) => sl.Value.Required && server.LobbyInfo.ClientInSlot(sl.Key) == null) || server.LobbyInfo.Slots.All((KeyValuePair<string, Session.Slot> sl) => server.LobbyInfo.ClientInSlot(sl.Key) == null))
			{
				return;
			}
			if (server.Type != ServerType.Dedicated && server.ModData.MapCache[server.Map.Uid].Status != MapStatus.Available)
			{
				Session.Client client = server.LobbyInfo.Clients.FirstOrDefault((Session.Client c) => c.Index == 0);
				if (client != null)
				{
					client.State = Session.ClientState.NotReady;
				}
				else
				{
					foreach (Session.Client client2 in server.LobbyInfo.Clients)
					{
						client2.State = Session.ClientState.NotReady;
					}
				}
				server.SyncLobbyClients();
			}
			else if (!LobbyUtils.InsufficientEnabledSpawnPoints(server.Map, server.LobbyInfo))
			{
				server.StartGame();
			}
		}
	}

	private static bool State(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!Enum<Session.ClientState>.TryParse(s, ignoreCase: false, out var value))
			{
				server.SendFluentMessageTo(conn, "notification-malformed-command", new object[2] { "command", "state" });
				return true;
			}
			client.State = value;
			Log.Write("server", $"Player @{conn.EndPoint} is {client.State}");
			server.SyncLobbyClients();
			CheckAutoStart(server);
			return true;
		}
	}

	private static bool StartGame(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-start-game");
				return true;
			}
			if (server.LobbyInfo.Slots.Any((KeyValuePair<string, Session.Slot> sl) => sl.Value.Required && server.LobbyInfo.ClientInSlot(sl.Key) == null))
			{
				server.SendFluentMessageTo(conn, "notification-no-start-until-required-slots-full");
				return true;
			}
			if (server.LobbyInfo.Slots.All((KeyValuePair<string, Session.Slot> sl) => server.LobbyInfo.ClientInSlot(sl.Key) == null))
			{
				server.SendOrderTo(conn, "Message", "notification-no-start-without-players");
				return true;
			}
			if (!server.LobbyInfo.GlobalSettings.EnableSingleplayer && server.LobbyInfo.NonBotPlayers.Count() < 2)
			{
				server.SendFluentMessageTo(conn, "notification-two-humans-required");
				return true;
			}
			if (LobbyUtils.InsufficientEnabledSpawnPoints(server.Map, server.LobbyInfo))
			{
				server.SendFluentMessageTo(conn, "notification-insufficient-enabled-spawn-points");
				return true;
			}
			server.StartGame();
			return true;
		}
	}

	private static bool Slot(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!server.LobbyInfo.Slots.TryGetValue(s, out var value))
			{
				Log.Write("server", "Invalid slot: " + s);
				return false;
			}
			if (value.Closed || server.LobbyInfo.ClientInSlot(s) != null)
			{
				return false;
			}
			Session.Slot slot = ((client.Slot != null) ? server.LobbyInfo.Slots[client.Slot] : null);
			if (slot != null && slot.LockSpawn)
			{
				client.SpawnPoint = 0;
			}
			client.Slot = s;
			OpenRA.Server.Server.SyncClientToPlayerReference(client, server.Map.Players.Players[s]);
			if (!value.LockColor)
			{
				client.PreferredColor = (client.Color = SanitizePlayerColor(server, client.Color, client.Index, conn));
			}
			server.SyncLobbyClients();
			CheckAutoStart(server);
			return true;
		}
	}

	private static bool AllowSpectators(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (bool.TryParse(s, out server.LobbyInfo.GlobalSettings.AllowSpectators))
			{
				server.SyncLobbyGlobalSettings();
				return true;
			}
			server.SendFluentMessageTo(conn, "notification-malformed-command", new object[2] { "command", "allow_spectate" });
			return true;
		}
	}

	private static bool Specate(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (server.LobbyInfo.GlobalSettings.AllowSpectators || client.IsAdmin)
			{
				client.Slot = null;
				client.SpawnPoint = 0;
				client.Team = 0;
				client.Handicap = 0;
				client.Color = Color.White;
				server.SyncLobbyClients();
				CheckAutoStart(server);
				return true;
			}
			return false;
		}
	}

	private static bool SlotClose(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!ValidateSlotCommand(server, conn, client, s, requiresHost: true))
			{
				return false;
			}
			Session.Client occupant = server.LobbyInfo.ClientInSlot(s);
			if (occupant != null)
			{
				if (occupant.Bot != null)
				{
					server.LobbyInfo.Clients.Remove(occupant);
					server.SyncLobbyClients();
				}
				else
				{
					Connection connection = server.Conns.FirstOrDefault((Connection c) => c.PlayerIndex == occupant.Index);
					if (connection != null)
					{
						server.SendOrderTo(conn, "ServerError", "notification-slot-closed");
						server.DropClient(connection);
					}
				}
			}
			server.LobbyInfo.Slots[s].Closed = true;
			server.SyncLobbySlots();
			return true;
		}
	}

	private static bool SlotOpen(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!ValidateSlotCommand(server, conn, client, s, requiresHost: true))
			{
				return false;
			}
			Session.Slot slot = server.LobbyInfo.Slots[s];
			slot.Closed = false;
			server.SyncLobbySlots();
			Session.Client client2 = server.LobbyInfo.ClientInSlot(s);
			if (client2 != null && client2.Bot != null)
			{
				server.LobbyInfo.Clients.Remove(client2);
			}
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool SlotBot(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string[] array = s.Split(' ');
			if (array.Length < 3)
			{
				server.SendFluentMessageTo(conn, "notification-malformed-command", new object[2] { "command", "slot_bot" });
				return true;
			}
			if (!ValidateSlotCommand(server, conn, client, array[0], requiresHost: true))
			{
				return false;
			}
			Session.Slot slot = server.LobbyInfo.Slots[array[0]];
			Session.Client client2 = server.LobbyInfo.ClientInSlot(array[0]);
			if (!Exts.TryParseInt32Invariant(array[1], out var i))
			{
				Log.Write("server", "Invalid bot controller client index: " + array[1]);
				return false;
			}
			if (client2 != null && client2.Bot == null)
			{
				server.SendFluentMessageTo(conn, "notification-invalid-bot-slot");
				return true;
			}
			string botType = array[2];
			IBotInfo botInfo = server.Map.PlayerActorInfo.TraitInfos<IBotInfo>().FirstOrDefault((IBotInfo b) => b.Type == botType);
			if (botInfo == null)
			{
				server.SendFluentMessageTo(conn, "notification-invalid-bot-type");
				return true;
			}
			slot.Closed = false;
			if (client2 == null)
			{
				client2 = new Session.Client
				{
					Index = server.ChooseFreePlayerIndex(),
					Name = botInfo.Name,
					Bot = botType,
					Slot = array[0],
					Faction = "Random",
					SpawnPoint = 0,
					Team = 0,
					Handicap = 0,
					State = Session.ClientState.NotReady,
					BotControllerClientIndex = i
				};
				IColorPickerManagerInfo colorPickerManagerInfo = server.ModData.DefaultRules.Actors[SystemActors.World].TraitInfo<IColorPickerManagerInfo>();
				List<Color> terrainColors = server.ModData.DefaultTerrainInfo[server.Map.TileSet].RestrictedPlayerColors.ToList();
				List<Color> playerColors = server.LobbyInfo.Clients.Select((Session.Client c) => c.Color).Concat(server.Map.Players.Players.Values.Select((PlayerReference p) => p.Color)).ToList();
				client2.Color = (client2.PreferredColor = colorPickerManagerInfo.RandomPresetColor(server.Random, terrainColors, playerColors));
				server.LobbyInfo.Clients.Add(client2);
			}
			else
			{
				client2.Name = botInfo.Name;
				client2.Bot = botType;
			}
			OpenRA.Server.Server.SyncClientToPlayerReference(client2, server.Map.Players.Players[array[0]]);
			server.SyncLobbyClients();
			server.SyncLobbySlots();
			return true;
		}
	}

	private static bool Map(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-change-map");
				return true;
			}
			if (server.MapPool != null && !server.MapPool.Contains(s))
			{
				QueryFailed();
				return true;
			}
			string lastMap = server.LobbyInfo.GlobalSettings.Map;
			MapPreview mapPreview = server.ModData.MapCache[s];
			if (mapPreview.Status == MapStatus.Available || mapPreview.Status == MapStatus.DownloadAvailable)
			{
				SelectMap(mapPreview);
			}
			else if (server.Settings.QueryMapRepository)
			{
				server.SendFluentMessageTo(conn, "notification-searching-map");
				string mapRepository = server.ModData.Manifest.Get<WebServices>().MapRepository;
				bool reported = false;
				server.ModData.MapCache.QueryRemoteMapDetails(mapRepository, new string[1] { s }, SelectMap, (MapPreview _) =>
				{
					if (!reported)
					{
						QueryFailed();
					}
					reported = true;
				});
			}
			else
			{
				QueryFailed();
			}
			return true;
			void SelectMap(MapPreview map)
			{
				lock (server.LobbyInfo)
				{
					if (!(server.LobbyInfo.GlobalSettings.Map != lastMap))
					{
						server.LobbyInfo.GlobalSettings.Map = map.Uid;
						string[] array = server.LobbyInfo.Slots.Keys.ToArray();
						server.Map = server.ModData.MapCache[server.LobbyInfo.GlobalSettings.Map];
						server.LobbyInfo.GlobalSettings.MapStatus = server.MapStatusCache[server.Map];
						server.LobbyInfo.Slots = (from p in server.Map.Players.Players
							select MakeSlotFromPlayerReference(p.Value) into ss
							where ss != null
							select ss).ToDictionary((Session.Slot ss) => ss.PlayerReference, (Session.Slot ss) => ss);
						LoadMapSettings(server, server.LobbyInfo.GlobalSettings, server.Map);
						List<string> validFactions = (from f in server.Map.WorldActorInfo.TraitInfos<FactionInfo>()
							where f.Selectable
							select f.InternalName).ToList();
						foreach (Session.Client client3 in server.LobbyInfo.Clients)
						{
							client3.Faction = SanitizePlayerFaction(server, client3.Faction, validFactions);
							client3.State = Session.ClientState.Invalid;
						}
						IEnumerable<string> source = from t in server.Map.PlayerActorInfo.TraitInfos<IBotInfo>()
							select t.Type;
						string[] array2 = server.LobbyInfo.Slots.Keys.ToArray();
						int num = 0;
						string[] array3 = array;
						foreach (string slot in array3)
						{
							Session.Client client2 = server.LobbyInfo.ClientInSlot(slot);
							if (client2 != null)
							{
								client2.SpawnPoint = 0;
								client2.Slot = ((num < array2.Length) ? array2[num++] : null);
								if (client2.Slot != null)
								{
									if (client2.Bot != null && (!server.Map.Players.Players[client2.Slot].AllowBots || !source.Contains(client2.Bot)))
									{
										server.LobbyInfo.Clients.Remove(client2);
									}
									OpenRA.Server.Server.SyncClientToPlayerReference(client2, server.Map.Players.Players[client2.Slot]);
								}
								else if (client2.Bot != null)
								{
									server.LobbyInfo.Clients.Remove(client2);
								}
								else
								{
									client2.Color = Color.White;
								}
							}
						}
						foreach (Session.Client client4 in server.LobbyInfo.Clients)
						{
							if (client4.Slot != null && !server.LobbyInfo.Slots[client4.Slot].LockColor)
							{
								client4.Color = (client4.PreferredColor = SanitizePlayerColor(server, client4.Color, client4.Index, conn));
							}
						}
						server.LobbyInfo.DisabledSpawnPoints.Clear();
						server.SyncLobbyInfo();
						server.SendFluentMessage("notification-changed-map", "player", client.Name, "map", server.Map.Title);
						if ((server.LobbyInfo.GlobalSettings.MapStatus & Session.MapStatus.UnsafeCustomRules) != 0)
						{
							server.SendFluentMessage("notification-custom-rules");
						}
						if (!server.LobbyInfo.GlobalSettings.EnableSingleplayer)
						{
							server.SendFluentMessage("notification-two-humans-required");
						}
						else if (server.Map.Players.Players.Where((KeyValuePair<string, PlayerReference> p) => p.Value.Playable).All((KeyValuePair<string, PlayerReference> p) => !p.Value.AllowBots))
						{
							server.SendFluentMessage("notification-map-bots-disabled");
						}
						string text = MissionBriefingOrDefault(server);
						if (text != null)
						{
							server.SendMessage(text);
						}
					}
				}
			}
		}
		void QueryFailed()
		{
			server.SendFluentMessageTo(conn, "notification-unknown-map");
		}
	}

	private static bool Option(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-change-configuration");
				return true;
			}
			IEnumerable<LobbyOption> enumerable = server.Map.PlayerActorInfo.TraitInfos<ILobbyOptions>().Concat(server.Map.WorldActorInfo.TraitInfos<ILobbyOptions>()).SelectMany((ILobbyOptions t) => t.LobbyOptions(server.Map));
			Dictionary<string, LobbyOption> dictionary = new Dictionary<string, LobbyOption>();
			foreach (LobbyOption item in enumerable)
			{
				dictionary[item.Id] = item;
			}
			string[] array = s.Split(' ');
			if (array.Length < 2 || !dictionary.TryGetValue(array[0], out var value) || !value.Values.ContainsKey(array[1]))
			{
				server.SendFluentMessageTo(conn, "notification-invalid-configuration-command");
				return true;
			}
			if (value.IsLocked)
			{
				server.SendFluentMessageTo(conn, "notification-option-locked", new object[2] { "option", value.Name });
				return true;
			}
			Session.LobbyOptionState lobbyOptionState = server.LobbyInfo.GlobalSettings.LobbyOptions[value.Id];
			if (lobbyOptionState.Value == array[1])
			{
				return true;
			}
			if (!value.Values.ContainsKey(array[1]))
			{
				server.SendFluentMessageTo(conn, "notification-invalid-configuration-command");
				return true;
			}
			lobbyOptionState.Value = (lobbyOptionState.PreferredValue = array[1]);
			server.SyncLobbyGlobalSettings();
			server.SendFluentMessage("notification-option-changed", "player", client.Name, "name", value.Name, "value", value.Label(array[1]));
			foreach (Session.Client client2 in server.LobbyInfo.Clients)
			{
				client2.State = Session.ClientState.NotReady;
			}
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool ResetOptions(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-change-configuration");
				return true;
			}
			IEnumerable<LobbyOption> enumerable = server.Map.PlayerActorInfo.TraitInfos<ILobbyOptions>().Concat(server.Map.WorldActorInfo.TraitInfos<ILobbyOptions>()).SelectMany((ILobbyOptions t) => t.LobbyOptions(server.Map));
			Dictionary<string, Session.LobbyOptionState> dictionary = new Dictionary<string, Session.LobbyOptionState>();
			foreach (LobbyOption item in enumerable)
			{
				if (item.DefaultValue != server.LobbyInfo.GlobalSettings.LobbyOptions[item.Id].Value)
				{
					server.SendFluentMessage("notification-option-changed", "player", client.Name, "name", item.Name, "value", item.Label(item.DefaultValue));
				}
				dictionary[item.Id] = new Session.LobbyOptionState
				{
					IsLocked = item.IsLocked,
					Value = item.DefaultValue,
					PreferredValue = item.DefaultValue
				};
			}
			server.LobbyInfo.GlobalSettings.LobbyOptions = dictionary;
			server.SyncLobbyGlobalSettings();
			foreach (Session.Client client2 in server.LobbyInfo.Clients)
			{
				client2.State = Session.ClientState.NotReady;
			}
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool AssignTeams(OpenRA.Server.Server server, Connection conn, Session.Client client, string raw)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-option");
				return true;
			}
			if (!Exts.TryParseInt32Invariant(raw, out var i))
			{
				server.SendFluentMessageTo(conn, "notification-error-number-teams", new object[2] { "raw", raw });
				return true;
			}
			int max = (Enumerable.Count(server.LobbyInfo.Clients, (Session.Client c) => c.Slot != null) + 1) / 2;
			i = i.Clamp(0, max);
			List<Session.Client> list = (from slot in server.LobbyInfo.Slots
				select server.LobbyInfo.ClientInSlot(slot.Key) into c
				where c != null && !server.LobbyInfo.Slots[c.Slot].LockTeam
				select c).ToList();
			int num = 0;
			int count = list.Count;
			foreach (Session.Client item in list)
			{
				switch (i)
				{
				case 0:
					item.Team = 0;
					break;
				case 1:
					item.Team = ((item.Bot == null) ? 1 : 2);
					break;
				default:
					item.Team = num++ * i / count + 1;
					break;
				}
			}
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool Kick(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-kick");
				return true;
			}
			string[] array = s.Split(' ');
			if (array.Length < 2)
			{
				server.SendFluentMessageTo(conn, "notification-malformed-command", new object[2] { "command", "kick" });
				return true;
			}
			Connection connection = (Exts.TryParseInt32Invariant(array[0], out var kickClientID) ? server.Conns.SingleOrDefault((Connection c) =>
			{
				Session.Client client3 = server.GetClient(c);
				return client3 != null && client3.Index == kickClientID;
			}) : null);
			if (connection == null)
			{
				server.SendFluentMessageTo(conn, "notification-kick-none");
				return true;
			}
			Session.Client client2 = server.GetClient(connection);
			if (client == client2)
			{
				server.SendFluentMessageTo(conn, "notification-kick-self");
				return true;
			}
			if (server.State == ServerState.GameStarted && !client2.IsObserver && !server.HasClientWonOrLost(client2))
			{
				server.SendFluentMessageTo(conn, "notification-no-kick-game-started");
				return true;
			}
			Log.Write("server", $"Kicking client {kickClientID}.");
			server.SendFluentMessage("notification-admin-kicked", "admin", client.Name, "player", client2.Name);
			server.SendOrderTo(connection, "ServerError", "notification-you-were-kicked");
			server.DropClient(connection);
			if (bool.TryParse(array[1], out var result) & result)
			{
				Log.Write("server", $"Temporarily banning client {kickClientID} ({client2.IPAddress}).");
				server.SendFluentMessage("notification-temp-ban", "admin", client.Name, "player", client2.Name);
				server.TempBans.Add(client2.IPAddress);
			}
			server.SyncLobbyClients();
			server.SyncLobbySlots();
			return true;
		}
	}

	private static bool VoteKick(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string[] array = s.Split(' ');
			if (array.Length != 2)
			{
				server.SendFluentMessageTo(conn, "notification-malformed-command", new object[2] { "command", "vote_kick" });
				return true;
			}
			if (!server.Settings.EnableVoteKick)
			{
				server.SendFluentMessageTo(conn, "notification-vote-kick-disabled");
				return true;
			}
			Connection connection = (Exts.TryParseInt32Invariant(array[0], out var kickClientID) ? server.Conns.SingleOrDefault((Connection c) =>
			{
				Session.Client client3 = server.GetClient(c);
				return client3 != null && client3.Index == kickClientID;
			}) : null);
			if (connection == null)
			{
				server.SendFluentMessageTo(conn, "notification-kick-none");
				return true;
			}
			Session.Client client2 = server.GetClient(connection);
			if (client == client2)
			{
				server.SendFluentMessageTo(conn, "notification-kick-self");
				return true;
			}
			if (!bool.TryParse(array[1], out var result))
			{
				server.SendFluentMessageTo(conn, "notification-malformed-command", new object[2] { "command", "vote_kick" });
				return true;
			}
			if (server.VoteKickTracker.VoteKick(conn, client, connection, client2, kickClientID, result))
			{
				Log.Write("server", $"Kicking client {kickClientID}.");
				server.SendFluentMessage("notification-kicked", "player", client2.Name);
				server.SendOrderTo(connection, "ServerError", "notification-you-were-kicked");
				server.DropClient(connection);
				server.SyncLobbyClients();
				server.SyncLobbySlots();
			}
			return true;
		}
	}

	void OpenRA.Server.ITick.Tick(OpenRA.Server.Server server)
	{
		server.VoteKickTracker.Tick();
	}

	private static bool MakeAdmin(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-transfer-admin");
				return true;
			}
			Connection connection = (Exts.TryParseInt32Invariant(s, out var newAdminId) ? server.Conns.SingleOrDefault((Connection c) =>
			{
				Session.Client client3 = server.GetClient(c);
				return client3 != null && client3.Index == newAdminId;
			}) : null);
			if (connection == null)
			{
				server.SendFluentMessageTo(conn, "notification-empty-slot");
				return true;
			}
			Session.Client client2 = server.GetClient(connection);
			client.IsAdmin = false;
			client2.IsAdmin = true;
			IEnumerable<Session.Client> enumerable = from slot in server.LobbyInfo.Slots
				select server.LobbyInfo.ClientInSlot(slot.Key) into c
				where c != null && c.Bot != null
				select c;
			foreach (Session.Client item in enumerable)
			{
				item.BotControllerClientIndex = newAdminId;
			}
			server.SendFluentMessage("notification-new-admin", "player", client2.Name);
			Log.Write("server", client2.Name + " is now the admin.");
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool MakeSpectator(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-move-spectators");
				return true;
			}
			Connection connection = (Exts.TryParseInt32Invariant(s, out var targetId) ? server.Conns.SingleOrDefault((Connection c) =>
			{
				Session.Client client3 = server.GetClient(c);
				return client3 != null && client3.Index == targetId;
			}) : null);
			if (connection == null)
			{
				server.SendFluentMessageTo(conn, "notification-empty-slot");
				return true;
			}
			Session.Client client2 = server.GetClient(connection);
			client2.Slot = null;
			client2.SpawnPoint = 0;
			client2.Team = 0;
			client2.Handicap = 0;
			client2.Color = Color.White;
			client2.State = Session.ClientState.NotReady;
			server.SendFluentMessage("notification-move-spectators", "admin", client.Name, "player", client2.Name);
			Log.Write("server", client.Name + " moved " + client2.Name + " to spectators.");
			server.SyncLobbyClients();
			CheckAutoStart(server);
			return true;
		}
	}

	private static bool Name(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string text = Settings.SanitizedPlayerName(s);
			if (text == client.Name)
			{
				return true;
			}
			Log.Write("server", $"Player@{conn.EndPoint} is now known as {text}.");
			server.SendFluentMessage("notification-nick-changed", "player", client.Name, "name", text);
			client.Name = text;
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool Faction(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string[] array = s.Split(' ');
			Session.Client client2 = server.LobbyInfo.ClientWithIndex(Exts.ParseInt32Invariant(array[0]));
			if (client2.Index != client.Index && !client.IsAdmin)
			{
				return true;
			}
			if (server.LobbyInfo.Slots[client2.Slot].LockFaction)
			{
				return true;
			}
			string text = array[1];
			if (!server.Map.WorldActorInfo.TraitInfos<FactionInfo>().Any((FactionInfo f) => f.Selectable && f.InternalName == client.Faction))
			{
				server.SendFluentMessageTo(conn, "notification-invalid-faction-selected", new object[2] { "faction", text });
				return true;
			}
			client2.Faction = text;
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool Team(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string[] array = s.Split(' ');
			Session.Client client2 = server.LobbyInfo.ClientWithIndex(Exts.ParseInt32Invariant(array[0]));
			if (client2.Index != client.Index && !client.IsAdmin)
			{
				return true;
			}
			if (server.LobbyInfo.Slots[client2.Slot].LockTeam)
			{
				return true;
			}
			if (!Exts.TryParseInt32Invariant(array[1], out var i))
			{
				Log.Write("server", "Invalid team: " + s);
				return false;
			}
			client2.Team = i;
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool Handicap(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string[] array = s.Split(' ');
			Session.Client client2 = server.LobbyInfo.ClientWithIndex(Exts.ParseInt32Invariant(array[0]));
			if (client2.Index != client.Index && !client.IsAdmin)
			{
				return true;
			}
			if (server.LobbyInfo.Slots[client2.Slot].LockHandicap)
			{
				return true;
			}
			if (!Exts.TryParseInt32Invariant(array[1], out var i))
			{
				Log.Write("server", "Invalid handicap: " + s);
				return false;
			}
			IEnumerable<int> source = from num in Enumerable.Range(0, 20)
				select 5 * num;
			if (!source.Contains(i))
			{
				Log.Write("server", "Invalid handicap: " + s);
				return false;
			}
			client2.Handicap = i;
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool ClearPlayerSpawn(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		int spawnPoint = Exts.ParseInt32Invariant(s);
		if (spawnPoint == 0)
		{
			return true;
		}
		Session.Client client2 = server.LobbyInfo.Clients.FirstOrDefault((Session.Client cc) => cc.SpawnPoint == spawnPoint);
		if (client != client2 && !client.IsAdmin)
		{
			server.SendFluentMessageTo(conn, "notification-admin-clear-spawn");
			return true;
		}
		if (client2 != null)
		{
			if (client2.Slot != null && server.LobbyInfo.Slots[client2.Slot].LockSpawn)
			{
				return true;
			}
			client2.SpawnPoint = 0;
			if (client2.State == Session.ClientState.Ready)
			{
				client2.State = Session.ClientState.NotReady;
			}
			server.SyncLobbyClients();
			return true;
		}
		if (!server.LobbyInfo.DisabledSpawnPoints.Add(spawnPoint))
		{
			server.LobbyInfo.DisabledSpawnPoints.Remove(spawnPoint);
		}
		server.SyncLobbyInfo();
		return true;
	}

	private static bool Spawn(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string[] array = s.Split(' ');
			Session.Client client2 = server.LobbyInfo.ClientWithIndex(Exts.ParseInt32Invariant(array[0]));
			if (client2.Index != client.Index && !client.IsAdmin)
			{
				return true;
			}
			if (client2.Slot == null)
			{
				return true;
			}
			if (server.LobbyInfo.Slots[client2.Slot].LockSpawn)
			{
				return true;
			}
			if (!Exts.TryParseInt32Invariant(array[1], out var spawnPoint) || spawnPoint < 0 || spawnPoint > server.Map.SpawnPoints.Length)
			{
				Log.Write("server", "Invalid spawn point: " + array[1]);
				return true;
			}
			if (server.LobbyInfo.Clients.Any((Session.Client cc) => cc != client && cc.SpawnPoint == spawnPoint && cc.SpawnPoint != 0))
			{
				server.SendFluentMessageTo(conn, "notification-spawn-occupied");
				return true;
			}
			if (spawnPoint > 0 && server.LobbyInfo.Slots.Where((KeyValuePair<string, Session.Slot> ss) => ss.Value.LockSpawn).Any((KeyValuePair<string, Session.Slot> ss) =>
			{
				PlayerReference playerReference = PlayerReferenceForSlot(server, ss.Value);
				return playerReference != null && playerReference.Spawn == spawnPoint;
			}))
			{
				server.SendFluentMessageTo(conn, "notification-spawn-locked");
				return true;
			}
			client2.SpawnPoint = spawnPoint;
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool PlayerColor(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			string[] array = s.Split(' ');
			Session.Client client2 = server.LobbyInfo.ClientWithIndex(Exts.ParseInt32Invariant(array[0]));
			if (client2.Index != client.Index && !client.IsAdmin)
			{
				return true;
			}
			if (client2.Slot == null || server.LobbyInfo.Slots[client2.Slot].LockColor)
			{
				return true;
			}
			Color value = FieldLoader.GetValue<Color>("(value)", array[1]);
			client2.Color = SanitizePlayerColor(server, value, client2.Index, conn);
			if (value == client2.Color)
			{
				client2.PreferredColor = client2.Color;
			}
			server.SyncLobbyClients();
			return true;
		}
	}

	private static bool SyncLobby(OpenRA.Server.Server server, Connection conn, Session.Client client, string s)
	{
		lock (server.LobbyInfo)
		{
			if (!client.IsAdmin)
			{
				server.SendFluentMessageTo(conn, "notification-admin-lobby-info");
				return true;
			}
			try
			{
				server.LobbyInfo = Session.Deserialize(s, "SyncLobby");
				server.SyncLobbyInfo();
			}
			catch (Exception)
			{
				server.SendFluentMessageTo(conn, "notification-invalid-lobby-info");
			}
			return true;
		}
	}

	private static void InitializeMapPool(OpenRA.Server.Server server)
	{
		if (server.Type != ServerType.Dedicated)
		{
			return;
		}
		MapCache mapCache = server.ModData.MapCache;
		if (server.Settings.MapPool.Length != 0)
		{
			server.MapPool = server.Settings.MapPool.ToHashSet();
		}
		else
		{
			if (server.Settings.QueryMapRepository)
			{
				return;
			}
			server.MapPool = (from p in mapCache
				where p.Status == MapStatus.Available && p.Visibility.HasFlag(MapVisibility.Lobby)
				select p.Uid).ToHashSet();
		}
		List<string> list = server.MapPool.Where(server.MapIsUnknown).ToList();
		if (list.Count == 0)
		{
			return;
		}
		if (server.Settings.QueryMapRepository)
		{
			Log.Write("server", $"Querying Resource Center for information on {list.Count} maps...");
			string mapRepository = server.ModData.Manifest.Get<WebServices>().MapRepository;
			mapCache.QueryRemoteMapDetails(mapRepository, list);
			IEnumerable<string> source = server.MapPool.Where((string uid) => mapCache[uid].Status == MapStatus.Searching);
			Stopwatch stopwatch = Stopwatch.StartNew();
			while (source.Any() && stopwatch.ElapsedMilliseconds < 10000)
			{
				Thread.Sleep(100);
			}
		}
		List<string> list2 = server.MapPool.Where(server.MapIsUnknown).ToList();
		if (list2.Count != 0)
		{
			Log.Write("server", "Failed to resolve maps: " + list2.JoinWith(", "));
		}
	}

	private static string ChooseInitialMap(OpenRA.Server.Server server)
	{
		if (server.MapIsKnown(server.Settings.Map))
		{
			return server.Settings.Map;
		}
		if (server.MapPool == null)
		{
			return server.ModData.MapCache.ChooseInitialMap(server.Settings.Map, new MersenneTwister());
		}
		return server.MapPool.Where(server.MapIsKnown).RandomOrDefault(new MersenneTwister());
	}

	public void ServerStarted(OpenRA.Server.Server server)
	{
		lock (server.LobbyInfo)
		{
			InitializeMapPool(server);
			string text = ChooseInitialMap(server);
			if (string.IsNullOrEmpty(text))
			{
				throw new InvalidOperationException("Unable to resolve a valid initial map");
			}
			server.LobbyInfo.GlobalSettings.Map = (server.Settings.Map = text);
			server.Map = server.ModData.MapCache[text];
			server.LobbyInfo.GlobalSettings.MapStatus = server.MapStatusCache[server.Map];
			server.LobbyInfo.Slots = (from p in server.Map.Players.Players
				select MakeSlotFromPlayerReference(p.Value) into s
				where s != null
				select s).ToDictionary((Session.Slot s) => s.PlayerReference, (Session.Slot s) => s);
			LoadMapSettings(server, server.LobbyInfo.GlobalSettings, server.Map);
		}
	}

	private static Session.Slot MakeSlotFromPlayerReference(PlayerReference pr)
	{
		if (!pr.Playable)
		{
			return null;
		}
		return new Session.Slot
		{
			PlayerReference = pr.Name,
			Closed = false,
			AllowBots = pr.AllowBots,
			LockFaction = pr.LockFaction,
			LockColor = pr.LockColor,
			LockTeam = pr.LockTeam,
			LockHandicap = pr.LockHandicap,
			LockSpawn = pr.LockSpawn,
			Required = pr.Required
		};
	}

	public static void LoadMapSettings(OpenRA.Server.Server server, Session.Global gs, MapPreview map)
	{
		lock (server.LobbyInfo)
		{
			IEnumerable<LobbyOption> enumerable = map.PlayerActorInfo.TraitInfos<ILobbyOptions>().Concat(map.WorldActorInfo.TraitInfos<ILobbyOptions>()).SelectMany((ILobbyOptions t) => t.LobbyOptions(map));
			foreach (LobbyOption item in enumerable)
			{
				string value = item.DefaultValue;
				string preferredValue = item.DefaultValue;
				if (gs.LobbyOptions.TryGetValue(item.Id, out var value2))
				{
					if (!item.IsLocked)
					{
						if (item.Values.Keys.Contains(value2.PreferredValue))
						{
							value = value2.PreferredValue;
						}
						else if (item.Values.Keys.Contains(value2.Value))
						{
							value = value2.Value;
						}
					}
					preferredValue = value2.PreferredValue;
				}
				else
				{
					value2 = new Session.LobbyOptionState();
				}
				value2.IsLocked = item.IsLocked;
				value2.Value = value;
				value2.PreferredValue = preferredValue;
				gs.LobbyOptions[item.Id] = value2;
			}
		}
	}

	public static Color SanitizePlayerColor(OpenRA.Server.Server server, Color askedColor, int playerIndex, Connection connectionToEcho = null)
	{
		lock (server.LobbyInfo)
		{
			IColorPickerManagerInfo colorPickerManagerInfo = server.ModData.DefaultRules.Actors[SystemActors.World].TraitInfo<IColorPickerManagerInfo>();
			List<Color> terrainColors = server.ModData.DefaultTerrainInfo[server.Map.TileSet].RestrictedPlayerColors.ToList();
			List<Color> playerColors = (from c in server.LobbyInfo.Clients
				where c.Index != playerIndex
				select c.Color).Concat(server.Map.Players.Players.Values.Select((PlayerReference p) => p.Color)).ToList();
			return colorPickerManagerInfo.MakeValid(askedColor, server.Random, terrainColors, playerColors, OnError);
		}
		void OnError(string message)
		{
			if (connectionToEcho != null && message != null)
			{
				server.SendFluentMessageTo(connectionToEcho, message);
			}
		}
	}

	public static string SanitizePlayerFaction(OpenRA.Server.Server server, string askedFaction, IEnumerable<string> validFactions)
	{
		if (validFactions.Contains(askedFaction))
		{
			return askedFaction;
		}
		return "Random";
	}

	private static string MissionBriefingOrDefault(OpenRA.Server.Server server)
	{
		MissionDataInfo missionDataInfo = server.Map.WorldActorInfo.TraitInfoOrDefault<MissionDataInfo>();
		if (missionDataInfo != null && !string.IsNullOrEmpty(missionDataInfo.Briefing))
		{
			return missionDataInfo.Briefing.Replace("\\n", "\n");
		}
		return null;
	}

	public void ClientJoined(OpenRA.Server.Server server, Connection conn)
	{
		lock (server.LobbyInfo)
		{
			if (server.MapPool != null)
			{
				server.SendOrderTo(conn, "SyncMapPool", FieldSaver.FormatValue(server.MapPool));
			}
			Session.Client client = server.GetClient(conn);
			if (client.Slot != null && !server.LobbyInfo.Slots[client.Slot].LockColor)
			{
				client.Color = SanitizePlayerColor(server, client.Color, client.Index);
			}
			string text = MissionBriefingOrDefault(server);
			if (text != null)
			{
				server.SendOrderTo(conn, "Message", text);
			}
		}
	}

	void INotifyServerEmpty.ServerEmpty(OpenRA.Server.Server server)
	{
		lock (server.LobbyInfo)
		{
			server.TempBans.Clear();
			server.LobbyInfo.GlobalSettings.AllowSpectators = true;
			server.LobbyInfo.Slots = (from p in server.Map.Players.Players
				select MakeSlotFromPlayerReference(p.Value) into ss
				where ss != null
				select ss).ToDictionary((Session.Slot ss) => ss.PlayerReference, (Session.Slot ss) => ss);
		}
	}

	public static PlayerReference PlayerReferenceForSlot(OpenRA.Server.Server server, Session.Slot slot)
	{
		if (slot == null)
		{
			return null;
		}
		return server.Map.Players.Players[slot.PlayerReference];
	}
}
