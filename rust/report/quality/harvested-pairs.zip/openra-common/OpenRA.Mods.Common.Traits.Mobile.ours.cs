namespace OpenRA.Mods.Common.Traits;

public class Mobile : OpenRA.Mods.Common.Traits.PausableConditionalTrait<OpenRA.Mods.Common.Traits.MobileInfo>, OpenRA.Traits.IIssueOrder, OpenRA.Traits.IResolveOrder, OpenRA.Traits.IOrderVoice, OpenRA.Mods.Common.Traits.IPositionable, OpenRA.Traits.IOccupySpace, OpenRA.Mods.Common.Traits.IMove, OpenRA.Traits.ITick, OpenRA.Traits.ICreationActivity, OpenRA.Traits.IFacing, OpenRA.Mods.Common.Traits.IDeathActorInitModifier, OpenRA.Traits.INotifyAddedToWorld, OpenRA.Traits.INotifyRemovedFromWorld, OpenRA.Mods.Common.Traits.INotifyBlockingMove, OpenRA.Mods.Common.Traits.IActorPreviewInitModifier, OpenRA.Traits.INotifyBecomingIdle
{
    private readonly OpenRA.Actor self;
    private readonly System.Lazy<System.Collections.Generic.IEnumerable<int>> speedModifiers;
    private readonly bool returnToCellOnCreation;
    private readonly bool returnToCellOnCreationRecalculateSubCell;
    private readonly int creationActivityDelay;
    private readonly OpenRA.CPos[] creationRallypoint;
    private OpenRA.Mods.Common.Traits.MovementType movementTypes;
    private OpenRA.WRot terrainRampOrientation;
    private OpenRA.WAngle oldFacing;
    private OpenRA.WRot orientation;
    private OpenRA.WPos oldPos;
    public OpenRA.Traits.SubCell FromSubCell;
    public OpenRA.Traits.SubCell ToSubCell;
    private OpenRA.Mods.Common.Traits.INotifyCustomLayerChanged[] notifyCustomLayerChanged;
    private OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged[] notifyCenterPositionChanged;
    private OpenRA.Mods.Common.Traits.INotifyMoving[] notifyMoving;
    private OpenRA.Mods.Common.Traits.INotifyFinishedMoving[] notifyFinishedMoving;
    private OpenRA.Mods.Common.Traits.IWrapMove[] moveWrappers;
    private bool requireForceMove;
    private bool __il_field_04001344;
    public bool TurnToMove;
    private bool __il_field_04001346;
    private OpenRA.Mods.Common.Traits.MoveResult __il_field_04001347;
    private OpenRA.CPos __il_field_04001348;
    private OpenRA.CPos __il_field_04001349;
    private OpenRA.Mods.Common.Traits.Locomotor __il_field_0400134A;
    private OpenRA.Mods.Common.Traits.IPathFinder __il_field_0400134B;
    private OpenRA.WPos __il_field_0400134C;

    public virtual OpenRA.Mods.Common.Traits.MovementType get_CurrentMovementTypes()
    {
        // enum storage token=0x02000695 alias=__cil_enum_02000695 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MovementType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.movementTypes));
        return unchecked((__cil_enum_02000695)(v1));
    }

    public virtual void set_CurrentMovementTypes(OpenRA.Mods.Common.Traits.MovementType value)
    {
        // structural signature __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec bytes=1D129A5C: class OpenRA.Mods.Common.Traits.INotifyMoving[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000695 alias=__cil_enum_02000695 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MovementType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000695 l0 = default;
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec l1 = default;
        int l2 = default;
        int v1 = unchecked((int)(this.movementTypes));
        l0 = unchecked((__cil_enum_02000695)(v1));
        int v3 = unchecked((int)(value));
        this.movementTypes = unchecked((__cil_enum_02000695)(v3));
        int v4 = unchecked((int)(value));
        int v5 = unchecked((int)(l0));
        if (v4 == v5) {
            goto IL_0058;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        __cil_type_01000025 v7 = this.self;
        __cil_type_0100002D v8 = v7.World;
        __cil_type_01000130 v9 = v8.ActorMap;
        __cil_type_01000025 v11 = this.self;
        __cil_type_010001EE v12 = ((OpenRA.Actor)v11).OccupiesSpace;
        __cil_callvirt_0A001428(v9, v12);
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v14 = this.notifyMoving;
        l1 = v14;
        l2 = 0;
        goto IL_0052;
        IL_003D: ;
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v16 = l1;
        int v17 = l2;
        global::OpenRA.Mods.Common.Traits.INotifyMoving v18 = v16[v17];
        __cil_type_01000025 v21 = this.self;
        int v22 = unchecked((int)(value));
        __cil_callvirt_06001FE5(v18, v21, unchecked((__cil_enum_02000695)(v22)));
        int v23 = l2;
        l2 = unchecked(v23 + 1);
        IL_0052: ;
        int v26 = l2;
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v27 = l1;
        nint v28 = unchecked((nint)(v27.LongLength));
        int v29 = unchecked((int)(v28));
        if (v26 < v29) {
            goto IL_003D;
        } else {
            goto IL_0058;
        }
        IL_0058: ;
        return;
    }

    public bool get_IsImmovable()
    {
        return this.__il_field_04001344;
    }

    private void set_IsImmovable(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04001344 = __cil_bool_store(v1);
        return;
    }

    public bool get_IsBlocking()
    {
        return this.__il_field_04001346;
    }

    private void set_IsBlocking(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04001346 = __cil_bool_store(v1);
        return;
    }

    public bool get_IsMovingBetweenCells()
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = this.FromCell;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v3 = this.ToCell;
        return OpenRA.CPos.op_Inequality(v1, v3);
    }

    public OpenRA.Mods.Common.Traits.MoveResult get_MoveResult()
    {
        // enum storage token=0x02000696 alias=__cil_enum_02000696 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MoveResult; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(this.__il_field_04001347));
        return unchecked((__cil_enum_02000696)(v1));
    }

    public void set_MoveResult(OpenRA.Mods.Common.Traits.MoveResult value)
    {
        // enum storage token=0x02000696 alias=__cil_enum_02000696 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MoveResult; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v1 = unchecked((int)(value));
        this.__il_field_04001347 = unchecked((__cil_enum_02000696)(v1));
        return;
    }

    public virtual OpenRA.WAngle get_Facing()
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v1 = ref v0.orientation;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v2 = v1.Yaw;
        return v2;
    }

    public virtual void set_Facing(OpenRA.WAngle value)
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        global::OpenRA.Mods.Common.Traits.Mobile v1 = this;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v2 = ref v1.orientation;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v3 = value;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v4 = __cil_memberref_call_0A00110C(ref v2, v3);
        v0.orientation = v4;
        return;
    }

    public virtual OpenRA.WRot get_Orientation()
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v1 = ref v0.orientation;
        global::OpenRA.Mods.Common.Traits.Mobile v2 = this;
        ref __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v3 = ref v2.terrainRampOrientation;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v4 = __cil_memberref_call_0A001179(ref v1, ref v3);
        return v4;
    }

    public virtual OpenRA.WAngle get_TurnSpeed()
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Mods.Common.Traits.MobileInfo v1 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v2 = v1.TurnSpeed;
        return v2;
    }

    public OpenRA.CPos get_FromCell()
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = this.__il_field_04001348;
        return v1;
    }

    private void set_FromCell(OpenRA.CPos value)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_04001348 = value;
        return;
    }

    public OpenRA.CPos get_ToCell()
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = this.__il_field_04001349;
        return v1;
    }

    private void set_ToCell(OpenRA.CPos value)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_04001349 = value;
        return;
    }

    public OpenRA.Mods.Common.Traits.Locomotor get_Locomotor()
    {
        global::OpenRA.Mods.Common.Traits.Locomotor v1 = this.__il_field_0400134A;
        return v1;
    }

    private void set_Locomotor(OpenRA.Mods.Common.Traits.Locomotor value)
    {
        this.__il_field_0400134A = value;
        return;
    }

    public OpenRA.Mods.Common.Traits.IPathFinder get_PathFinder()
    {
        global::OpenRA.Mods.Common.Traits.IPathFinder v1 = this.__il_field_0400134B;
        return v1;
    }

    private void set_PathFinder(OpenRA.Mods.Common.Traits.IPathFinder value)
    {
        this.__il_field_0400134B = value;
        return;
    }

    public virtual OpenRA.WPos get_CenterPosition()
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v1 = this.__il_field_0400134C;
        return v1;
    }

    private void set_CenterPosition(OpenRA.WPos value)
    {
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        this.__il_field_0400134C = value;
        return;
    }

    public virtual OpenRA.CPos get_TopLeft()
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = this.ToCell;
        return v1;
    }

    public virtual System.ValueTuple<OpenRA.CPos, OpenRA.Traits.SubCell>[] OccupiedCells()
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 bytes=1D151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_763732cf543d047a5287a4266098cf29f7836f4a bytes=151181A9021180A91180E5: valuetype [System.Runtime]System.ValueTuple`2<valuetype [OpenRA.Game]OpenRA.CPos, valuetype [OpenRA.Game]OpenRA.Traits.SubCell>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = this.FromCell;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v3 = this.ToCell;
        int v4 = __cil_bool_load(OpenRA.CPos.op_Equality(v1, v3));
        if (v4 == 0) {
            goto IL_0032;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v6 = __cil_newarr_1B0001CB(1);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v9 = this.FromCell;
        int v11 = unchecked((int)(unchecked((byte)(this.FromSubCell))));
        __cil_value_763732cf543d047a5287a4266098cf29f7836f4a v12 = __cil_value_newobj_0A001127(v9, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v11)))));
        __cil_stelem_1B0001CB(v6, 0, v12);
        return v6;
        IL_0032: ;
        global::OpenRA.Mods.Common.Traits.MobileInfo v14 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        global::OpenRA.Mods.Common.Traits.LocomotorInfo v15 = __cil_callvirt_060016EE(v14);
        int v16 = __cil_bool_load(v15.SharesCell);
        if (v16 == 0) {
            goto IL_0063;
        } else {
            goto IL_0044;
        }
        IL_0044: ;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v18 = __cil_newarr_1B0001CB(1);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v21 = this.ToCell;
        int v23 = unchecked((int)(unchecked((byte)(this.ToSubCell))));
        __cil_value_763732cf543d047a5287a4266098cf29f7836f4a v24 = __cil_value_newobj_0A001127(v21, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v23)))));
        __cil_stelem_1B0001CB(v18, 0, v24);
        return v18;
        IL_0063: ;
        __cil_ref_c4dd5478a222a9440791121ce2d6d2950a490cb3 v26 = __cil_newarr_1B0001CB(2);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v29 = this.FromCell;
        int v31 = unchecked((int)(unchecked((byte)(this.FromSubCell))));
        __cil_value_763732cf543d047a5287a4266098cf29f7836f4a v32 = __cil_value_newobj_0A001127(v29, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v31)))));
        __cil_stelem_1B0001CB(v26, 0, v32);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v35 = this.ToCell;
        int v37 = unchecked((int)(unchecked((byte)(this.ToSubCell))));
        __cil_value_763732cf543d047a5287a4266098cf29f7836f4a v38 = __cil_value_newobj_0A001127(v35, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v37)))));
        __cil_stelem_1B0001CB(v26, 1, v38);
        return v26;
    }

    public Mobile(OpenRA.ActorInitializer init, OpenRA.Mods.Common.Traits.MobileInfo info)
    {
        // IL fallback: generic virtual dispatch needs runtime lookup-order modeling
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 17, 7D, 34, 13, 00, 04, 02, 7E, DC, 14, 00, 0A, 7D, 38, 13, 00, 04, 02, 04, 28, DD, 14, 00]
        // .code-bytes IL_0018: [0A, 02, 03, 7B, 1E, 07, 00, 0A, 7D, 31, 13, 00, 04, 02, 02, FE, 06, 59, 17, 00, 06, 73, F4, 0B]
        // .code-bytes IL_0030: [00, 0A, 28, 1E, 06, 00, 2B, 7D, 32, 13, 00, 04, 02, 02, 04, 6F, EE, 16, 00, 06, 7B, 89, 18, 00]
        // .code-bytes IL_0048: [04, 2D, 03, 16, 2B, 15, 03, 6F, 1D, 07, 00, 0A, 7B, 5A, 01, 00, 0A, 7B, 92, 07, 00, 0A, 7B, DE]
        // .code-bytes IL_0060: [14, 00, 0A, 25, 0D, 7D, 3C, 13, 00, 04, 09, 7D, 3D, 13, 00, 04, 03, 6F, 1F, 06, 00, 2B, 0A, 06]
        // .code-bytes IL_0078: [2C, 1C, 02, 02, 06, 6F, 90, 00, 00, 06, 25, 0D, 7D, 3D, 13, 00, 04, 09, 7D, 3C, 13, 00, 04, 02]
        // .code-bytes IL_0090: [16, 7D, 34, 13, 00, 04, 03, 6F, 60, 04, 00, 2B, 0B, 07, 2C, 3F, 02, 02, 07, 6F, B0, 04, 00, 0A]
        // .code-bytes IL_00A8: [25, 13, 04, 28, 0C, 17, 00, 06, 11, 04, 28, 0A, 17, 00, 06, 02, 02, 7B, 31, 13, 00, 04, 03, 6F]
        // .code-bytes IL_00C0: [1D, 07, 00, 0A, 7B, 5A, 01, 00, 0A, 02, 28, 09, 17, 00, 06, 02, 7B, 3C, 13, 00, 04, 6F, DF, 14]
        // .code-bytes IL_00D8: [00, 0A, 28, 26, 17, 00, 06, 02, 02, 03, 04, 7B, 1D, 13, 00, 04, 6F, 63, 04, 00, 2B, 25, 13, 05]
        // .code-bytes IL_00F0: [7D, 39, 13, 00, 04, 11, 05, 28, 06, 17, 00, 06, 03, 6F, 61, 04, 00, 2B, 0C, 08, 2C, 25, 02, 08]
        // .code-bytes IL_0108: [6F, 15, 11, 00, 0A, 7D, 3B, 13, 00, 04, 02, 02, 7B, 31, 13, 00, 04, 02, 7B, 3B, 13, 00, 04, 28]
        // .code-bytes IL_0120: [26, 17, 00, 06, 02, 17, 7D, 33, 13, 00, 04, 02, 03, 16, 6F, 64, 04, 00, 2B, 7D, 35, 13, 00, 04]
        // .code-bytes IL_0138: [02, 03, 6F, 65, 04, 00, 2B, 25, 2D, 04, 26, 14, 2B, 05, 6F, 18, 11, 00, 0A, 7D, 36, 13, 00, 04]
        // .code-bytes IL_0150: [2A]
        // .local [0] class OpenRA.Mods.Common.SubCellInit
        // .local [1] class [OpenRA.Game]OpenRA.LocationInit
        // .local [2] class OpenRA.Mods.Common.CenterPositionInit
        // .local [3] valuetype [OpenRA.Game]OpenRA.Traits.SubCell
        // .local [4] valuetype [OpenRA.Game]OpenRA.CPos
        // .local [5] valuetype [OpenRA.Game]OpenRA.WAngle
        // IL_0000: ldarg.0 0
        // IL_0001: ldc.i4.1 1
        // IL_0002: stfld 0x04001334 OpenRA.Mods.Common.Traits.Mobile::returnToCellOnCreationRecalculateSubCell
        // IL_0007: ldarg.0 0
        // IL_0008: ldsfld 0x0A0014DC [OpenRA.Game]OpenRA.WRot::None
        // IL_000D: stfld 0x04001338 OpenRA.Mods.Common.Traits.Mobile::terrainRampOrientation
        // IL_0012: ldarg.0 0
        // IL_0013: ldarg.2 2
        // IL_0014: call 0x0A0014DD class OpenRA.Mods.Common.Traits.PausableConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::.ctor
        // IL_0019: ldarg.0 0
        // IL_001A: ldarg.1 1
        // IL_001B: ldfld 0x0A00071E [OpenRA.Game]OpenRA.ActorInitializer::Self
        // IL_0020: stfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_0025: ldarg.0 0
        // IL_0026: ldarg.0 0
        // IL_0027: ldftn 0x06001759 OpenRA.Mods.Common.Traits.Mobile::<.ctor>b__67_0
        // IL_002D: newobj 0x0A000BF4 class [System.Runtime]System.Func`1<class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>>::.ctor
        // IL_0032: call 0x2B00061E [OpenRA.Game]OpenRA.Exts::Lazy<class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>>
        // IL_0037: stfld 0x04001332 OpenRA.Mods.Common.Traits.Mobile::speedModifiers
        // IL_003C: ldarg.0 0
        // IL_003D: ldarg.0 0
        // IL_003E: ldarg.2 2
        // IL_003F: callvirt 0x060016EE OpenRA.Mods.Common.Traits.MobileInfo::get_LocomotorInfo
        // IL_0044: ldfld 0x04001889 OpenRA.Mods.Common.Traits.LocomotorInfo::SharesCell
        // IL_0049: brtrue.s IL_004E
        // IL_004B: ldc.i4.0 0
        // IL_004C: br.s IL_0063
        // IL_004E: ldarg.1 1
        // IL_004F: callvirt 0x0A00071D [OpenRA.Game]OpenRA.ActorInitializer::get_World
        // IL_0054: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0059: ldfld 0x0A000792 [OpenRA.Game]OpenRA.Map::Grid
        // IL_005E: ldfld 0x0A0014DE [OpenRA.Game]OpenRA.MapGrid::DefaultSubCell
        // IL_0063: dup 
        // IL_0064: stloc.3 3
        // IL_0065: stfld 0x0400133C OpenRA.Mods.Common.Traits.Mobile::FromSubCell
        // IL_006A: ldloc.3 3
        // IL_006B: stfld 0x0400133D OpenRA.Mods.Common.Traits.Mobile::ToSubCell
        // IL_0070: ldarg.1 1
        // IL_0071: callvirt 0x2B00061F [OpenRA.Game]OpenRA.ActorInitializer::GetOrDefault<class OpenRA.Mods.Common.SubCellInit>
        // IL_0076: stloc.0 0
        // IL_0077: ldloc.0 0
        // IL_0078: brfalse.s IL_0096
        // IL_007A: ldarg.0 0
        // IL_007B: ldarg.0 0
        // IL_007C: ldloc.0 0
        // IL_007D: callvirt 0x06000090 OpenRA.Mods.Common.SubCellInit::get_Value
        // IL_0082: dup 
        // IL_0083: stloc.3 3
        // IL_0084: stfld 0x0400133D OpenRA.Mods.Common.Traits.Mobile::ToSubCell
        // IL_0089: ldloc.3 3
        // IL_008A: stfld 0x0400133C OpenRA.Mods.Common.Traits.Mobile::FromSubCell
        // IL_008F: ldarg.0 0
        // IL_0090: ldc.i4.0 0
        // IL_0091: stfld 0x04001334 OpenRA.Mods.Common.Traits.Mobile::returnToCellOnCreationRecalculateSubCell
        // IL_0096: ldarg.1 1
        // IL_0097: callvirt 0x2B000460 [OpenRA.Game]OpenRA.ActorInitializer::GetOrDefault<class [OpenRA.Game]OpenRA.LocationInit>
        // IL_009C: stloc.1 1
        // IL_009D: ldloc.1 1
        // IL_009E: brfalse.s IL_00DF
        // IL_00A0: ldarg.0 0
        // IL_00A1: ldarg.0 0
        // IL_00A2: ldloc.1 1
        // IL_00A3: callvirt 0x0A0004B0 class [OpenRA.Game]OpenRA.ValueActorInit`1<valuetype [OpenRA.Game]OpenRA.CPos>::get_Value
        // IL_00A8: dup 
        // IL_00A9: stloc.s 4
        // IL_00AB: call 0x0600170C OpenRA.Mods.Common.Traits.Mobile::set_ToCell
        // IL_00B0: ldloc.s 4
        // IL_00B2: call 0x0600170A OpenRA.Mods.Common.Traits.Mobile::set_FromCell
        // IL_00B7: ldarg.0 0
        // IL_00B8: ldarg.0 0
        // IL_00B9: ldfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_00BE: ldarg.1 1
        // IL_00BF: callvirt 0x0A00071D [OpenRA.Game]OpenRA.ActorInitializer::get_World
        // IL_00C4: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_00C9: ldarg.0 0
        // IL_00CA: call 0x06001709 OpenRA.Mods.Common.Traits.Mobile::get_FromCell
        // IL_00CF: ldarg.0 0
        // IL_00D0: ldfld 0x0400133C OpenRA.Mods.Common.Traits.Mobile::FromSubCell
        // IL_00D5: callvirt 0x0A0014DF [OpenRA.Game]OpenRA.Map::CenterOfSubCell
        // IL_00DA: call 0x06001726 OpenRA.Mods.Common.Traits.Mobile::SetCenterPosition
        // IL_00DF: ldarg.0 0
        // IL_00E0: ldarg.0 0
        // IL_00E1: ldarg.1 1
        // IL_00E2: ldarg.2 2
        // IL_00E3: ldfld 0x0400131D OpenRA.Mods.Common.Traits.MobileInfo::InitialFacing
        // IL_00E8: callvirt 0x2B000463 [OpenRA.Game]OpenRA.ActorInitializer::GetValue<class OpenRA.Mods.Common.FacingInit, valuetype [OpenRA.Game]OpenRA.WAngle>
        // IL_00ED: dup 
        // IL_00EE: stloc.s 5
        // IL_00F0: stfld 0x04001339 OpenRA.Mods.Common.Traits.Mobile::oldFacing
        // IL_00F5: ldloc.s 5
        // IL_00F7: call 0x06001706 OpenRA.Mods.Common.Traits.Mobile::set_Facing
        // IL_00FC: ldarg.1 1
        // IL_00FD: callvirt 0x2B000461 [OpenRA.Game]OpenRA.ActorInitializer::GetOrDefault<class OpenRA.Mods.Common.CenterPositionInit>
        // IL_0102: stloc.2 2
        // IL_0103: ldloc.2 2
        // IL_0104: brfalse.s IL_012B
        // IL_0106: ldarg.0 0
        // IL_0107: ldloc.2 2
        // IL_0108: callvirt 0x0A001115 class [OpenRA.Game]OpenRA.ValueActorInit`1<valuetype [OpenRA.Game]OpenRA.WPos>::get_Value
        // IL_010D: stfld 0x0400133B OpenRA.Mods.Common.Traits.Mobile::oldPos
        // IL_0112: ldarg.0 0
        // IL_0113: ldarg.0 0
        // IL_0114: ldfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_0119: ldarg.0 0
        // IL_011A: ldfld 0x0400133B OpenRA.Mods.Common.Traits.Mobile::oldPos
        // IL_011F: call 0x06001726 OpenRA.Mods.Common.Traits.Mobile::SetCenterPosition
        // IL_0124: ldarg.0 0
        // IL_0125: ldc.i4.1 1
        // IL_0126: stfld 0x04001333 OpenRA.Mods.Common.Traits.Mobile::returnToCellOnCreation
        // IL_012B: ldarg.0 0
        // IL_012C: ldarg.1 1
        // IL_012D: ldc.i4.0 0
        // IL_012E: callvirt 0x2B000464 [OpenRA.Game]OpenRA.ActorInitializer::GetValue<class OpenRA.Mods.Common.CreationActivityDelayInit, int32>
        // IL_0133: stfld 0x04001335 OpenRA.Mods.Common.Traits.Mobile::creationActivityDelay
        // IL_0138: ldarg.0 0
        // IL_0139: ldarg.1 1
        // IL_013A: callvirt 0x2B000465 [OpenRA.Game]OpenRA.ActorInitializer::GetOrDefault<class OpenRA.Mods.Common.Traits.RallyPointInit>
        // IL_013F: dup 
        // IL_0140: brtrue.s IL_0146
        // IL_0142: pop 
        // IL_0143: ldnull 
        // IL_0144: br.s IL_014B
        // IL_0146: callvirt 0x0A001118 class [OpenRA.Game]OpenRA.ValueActorInit`1<valuetype [OpenRA.Game]OpenRA.CPos[]>::get_Value
        // IL_014B: stfld 0x04001336 OpenRA.Mods.Common.Traits.Mobile::creationRallypoint
        // IL_0150: ret 
    }

    protected override void Created(OpenRA.Actor self)
    {
        // structural signature __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec bytes=1D129A5C: class OpenRA.Mods.Common.Traits.INotifyMoving[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_948ceed1b834e05819b4d0faa7a73165cceb356a bytes=151280A101129870: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyCustomLayerChanged>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_6b600c07da3c5fa7da130886771a02a07d60fe89 bytes=1D129870: class OpenRA.Mods.Common.Traits.INotifyCustomLayerChanged[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_9986e596bb81344ef676a122c3804e4a93fd3b50 bytes=151280A101129874: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d bytes=1D129874: class OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5f8b144b2c75c3ef443c9c3fbffdbce636e41778 bytes=151280A101129A5C: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyMoving>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c77a7e22b45bffe72b73c430453b05d06a2b0263 bytes=151280A101129878: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyFinishedMoving>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_167de011a51f4877b001d5ad64d0de5662e89063 bytes=1D129878: class OpenRA.Mods.Common.Traits.INotifyFinishedMoving[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f022f4bf59697370774cc0983d2d0eb9547517ce bytes=151280A1011299F0: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.IWrapMove>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_48a5e6689ec8bb1d944f17e98344d3f8ef945f29 bytes=1D1299F0: class OpenRA.Mods.Common.Traits.IWrapMove[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_478b023a18ee57a8af206e05cfffe152622337bd bytes=151280A101129724: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.Locomotor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_eb1d8c4a9eacd54f4b178d1e6343321659653d9c bytes=151281210212972402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.Locomotor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_948ceed1b834e05819b4d0faa7a73165cceb356a v2 = __cil_callvirt_2B000620(self);
        __cil_ref_6b600c07da3c5fa7da130886771a02a07d60fe89 v3 = __cil_methodspec_call_2B000621(v2);
        this.notifyCustomLayerChanged = v3;
        __cil_ref_9986e596bb81344ef676a122c3804e4a93fd3b50 v6 = __cil_callvirt_2B000470(self);
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v7 = __cil_methodspec_call_2B000471(v6);
        this.notifyCenterPositionChanged = v7;
        __cil_ref_5f8b144b2c75c3ef443c9c3fbffdbce636e41778 v10 = __cil_callvirt_2B00046B(self);
        __cil_ref_f61687ff1f2a60dadf9f80e4e9fbc58fbbc1bcec v11 = __cil_methodspec_call_2B00046C(v10);
        this.notifyMoving = v11;
        __cil_ref_c77a7e22b45bffe72b73c430453b05d06a2b0263 v14 = __cil_callvirt_2B000622(self);
        __cil_ref_167de011a51f4877b001d5ad64d0de5662e89063 v15 = __cil_methodspec_call_2B000623(v14);
        this.notifyFinishedMoving = v15;
        __cil_ref_f022f4bf59697370774cc0983d2d0eb9547517ce v18 = __cil_callvirt_2B000624(self);
        __cil_ref_48a5e6689ec8bb1d944f17e98344d3f8ef945f29 v19 = __cil_methodspec_call_2B000625(v18);
        this.moveWrappers = v19;
        __cil_type_0100002D v22 = self.World;
        __cil_type_01000025 v23 = v22.WorldActor;
        global::OpenRA.Mods.Common.Traits.IPathFinder v24 = __cil_callvirt_2B000626(v23);
        this.PathFinder = v24;
        __cil_type_0100002D v27 = self.World;
        __cil_type_01000025 v28 = v27.WorldActor;
        __cil_ref_478b023a18ee57a8af206e05cfffe152622337bd v29 = __cil_callvirt_2B0003B4(v28);
        nint v31 = __cil_ldftn_0600175A;
        __cil_ref_eb1d8c4a9eacd54f4b178d1e6343321659653d9c v32 = __cil_newobj_0A0011F4(this, v31);
        global::OpenRA.Mods.Common.Traits.Locomotor v33 = __cil_methodspec_call_2B000588(v29, v32);
        this.Locomotor = v33;
        __cil_direct_0A0014E0(this, self);
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E495469636B2E5469636B(OpenRA.Actor self)
    {
        __cil_direct_06001718(this);
        return;
    }

    public void UpdateMovement()
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000695 alias=__cil_enum_02000695 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MovementType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_enum_02000695 l0 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l1 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l2 = default;
        IL_0000: ;
        int v0 = 0;
        l0 = unchecked((__cil_enum_02000695)(v0));
        global::OpenRA.Mods.Common.Traits.Mobile v1 = this;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v2 = ref v1.oldPos;
        global::OpenRA.Mods.Common.Traits.Mobile v3 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v4 = __cil_direct_06001711(v3);
        l1 = v4;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v5 = ref l1;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v6 = OpenRA.WPos.op_Subtraction(ref v2, ref v5);
        l2 = v6;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v7 = ref l2;
        long v8 = __cil_memberref_call_0A00027C(ref v7);
        if (v8 == 0) {
            goto IL_0024;
        } else {
            goto IL_0020;
        }
        IL_0020: ;
        int v9 = unchecked((int)(l0));
        int v10 = 1;
        int v11 = unchecked(v9 | v10);
        l0 = unchecked((__cil_enum_02000695)(v11));
        goto IL_0024;
        IL_0024: ;
        global::OpenRA.Mods.Common.Traits.Mobile v12 = this;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v13 = ref v12.oldPos;
        int v14 = v13.Z;
        global::OpenRA.Mods.Common.Traits.Mobile v15 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v16 = __cil_direct_06001711(v15);
        int v17 = v16.Z;
        if (v14 == v17) {
            goto IL_0040;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        int v18 = unchecked((int)(l0));
        int v19 = 2;
        int v20 = unchecked(v18 | v19);
        l0 = unchecked((__cil_enum_02000695)(v20));
        goto IL_0040;
        IL_0040: ;
        global::OpenRA.Mods.Common.Traits.Mobile v21 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v22 = v21.oldFacing;
        global::OpenRA.Mods.Common.Traits.Mobile v23 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v24 = __cil_direct_06001705(v23);
        int v25 = __cil_bool_load(OpenRA.WAngle.op_Inequality(v22, v24));
        if (v25 == 0) {
            goto IL_0057;
        } else {
            goto IL_0053;
        }
        IL_0053: ;
        int v26 = unchecked((int)(l0));
        int v27 = 4;
        int v28 = unchecked(v26 | v27);
        l0 = unchecked((__cil_enum_02000695)(v28));
        goto IL_0057;
        IL_0057: ;
        global::OpenRA.Mods.Common.Traits.Mobile v29 = this;
        int v30 = unchecked((int)(l0));
        __cil_direct_060016FD(v29, unchecked((__cil_enum_02000695)(v30)));
        global::OpenRA.Mods.Common.Traits.Mobile v31 = this;
        global::OpenRA.Mods.Common.Traits.Mobile v32 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v33 = __cil_direct_06001711(v32);
        v31.oldPos = v33;
        global::OpenRA.Mods.Common.Traits.Mobile v34 = this;
        global::OpenRA.Mods.Common.Traits.Mobile v35 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v36 = __cil_direct_06001705(v35);
        v34.oldFacing = v36;
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F746966794164646564546F576F726C642E4164646564546F576F726C64(OpenRA.Actor self)
    {
        __cil_type_0100002D v1 = self.World;
        v1.AddToMaps(self, ((__cil_type_010001EE)(this)));
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F7469667952656D6F76656446726F6D576F726C642E52656D6F76656446726F6D576F726C64(OpenRA.Actor self)
    {
        __cil_type_0100002D v1 = self.World;
        v1.RemoveFromMaps(self, ((__cil_type_010001EE)(this)));
        return;
    }

    protected override void TraitEnabled(OpenRA.Actor self)
    {
        __cil_type_0100002D v1 = self.World;
        __cil_type_01000130 v2 = v1.ActorMap;
        __cil_type_010001EE v4 = ((OpenRA.Actor)self).OccupiesSpace;
        __cil_callvirt_0A001428(v2, v4);
        return;
    }

    protected override void TraitDisabled(OpenRA.Actor self)
    {
        __cil_type_0100002D v1 = self.World;
        __cil_type_01000130 v2 = v1.ActorMap;
        __cil_type_010001EE v4 = ((OpenRA.Actor)self).OccupiesSpace;
        __cil_callvirt_0A001428(v2, v4);
        return;
    }

    protected override void TraitResumed(OpenRA.Actor self)
    {
        __cil_type_0100002D v1 = self.World;
        __cil_type_01000130 v2 = v1.ActorMap;
        __cil_type_010001EE v4 = ((OpenRA.Actor)self).OccupiesSpace;
        __cil_callvirt_0A001428(v2, v4);
        return;
    }

    protected override void TraitPaused(OpenRA.Actor self)
    {
        __cil_type_0100002D v1 = self.World;
        __cil_type_01000130 v2 = v1.ActorMap;
        __cil_type_010001EE v4 = ((OpenRA.Actor)self).OccupiesSpace;
        __cil_callvirt_0A001428(v2, v4);
        return;
    }

    public System.Nullable<OpenRA.CPos> GetAdjacentCell(OpenRA.CPos nextCell, System.Func<OpenRA.CPos, bool> preferToAvoid = null)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_91e8632182aa8c030df79d240c0a649ddeb3e53e bytes=1180AD: valuetype [OpenRA.Game]OpenRA.CVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 bytes=15128121021180A902: class [System.Runtime]System.Func`2<valuetype [OpenRA.Game]OpenRA.CPos, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2a38231b7620144b7e2926345dd445b782449779 bytes=15118141011180A9: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 bytes=1512811D011180A9: class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d20d79d97d633f365c6bfc6180ce6c25449caa83 bytes=1D1180AD: valuetype [OpenRA.Game]OpenRA.CVec[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_181c5b4e12546c80f0be4e3e4af3817375f41e60 bytes=15120C021180A9128095: class <>f__AnonymousType1`2<valuetype [OpenRA.Game]OpenRA.CPos, class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_cca650ad0507d3f6fbf99a34fd677623696261db bytes=15128121021180A9151280A101128095: class [System.Runtime]System.Func`2<valuetype [OpenRA.Game]OpenRA.CPos, class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 bytes=151284C5031180A912809515120C021180A9128095: class [System.Runtime]System.Func`3<valuetype [OpenRA.Game]OpenRA.CPos, class [OpenRA.Game]OpenRA.Actor, class <>f__AnonymousType1`2<valuetype [OpenRA.Game]OpenRA.CPos, class [OpenRA.Game]OpenRA.Actor>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e bytes=151280A1011180A9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_a973e33d8f9b46d89f497bd4534297b7cbe82a61 bytes=151280A10115120C021180A9128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class <>f__AnonymousType1`2<valuetype [OpenRA.Game]OpenRA.CPos, class [OpenRA.Game]OpenRA.Actor>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020006A1 alias=__cil_enum_020006A1 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@BlockedByActor; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 l0 = default;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 l1 = default;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 l2 = default;
        __cil_ref_d20d79d97d633f365c6bfc6180ce6c25449caa83 l3 = default;
        int l4 = default;
        __cil_value_91e8632182aa8c030df79d240c0a649ddeb3e53e l5 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l6 = default;
        __cil_ref_181c5b4e12546c80f0be4e3e4af3817375f41e60 l7 = default;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 s14_0 = default;
        __cil_ref_cca650ad0507d3f6fbf99a34fd677623696261db s14_1 = default;
        __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 s14_2 = default;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 s15_0 = default;
        __cil_ref_cca650ad0507d3f6fbf99a34fd677623696261db s15_1 = default;
        __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 s15_2 = default;
        IL_0000: ;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 v0 = __cil_newobj_0A00070B();
        l0 = v0;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 v1 = __cil_newobj_0A00070B();
        l1 = v1;
        __cil_ref_d20d79d97d633f365c6bfc6180ce6c25449caa83 v2 = __cil_ldsfld_0A00079B();
        l3 = v2;
        int v3 = 0;
        l4 = v3;
        goto IL_0084;
        IL_0017: ;
        __cil_ref_d20d79d97d633f365c6bfc6180ce6c25449caa83 v4 = l3;
        int v5 = l4;
        __cil_value_91e8632182aa8c030df79d240c0a649ddeb3e53e v6 = __cil_ldelem_0100002B(v4, v5);
        l5 = v6;
        global::OpenRA.Mods.Common.Traits.Mobile v7 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v8 = __cil_direct_0600170B(v7);
        __cil_value_91e8632182aa8c030df79d240c0a649ddeb3e53e v9 = l5;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v10 = OpenRA.CPos.op_Addition(v8, v9);
        l6 = v10;
        global::OpenRA.Mods.Common.Traits.Mobile v11 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v12 = l6;
        int v13 = 3;
        int v14 = __cil_bool_load(__cil_direct_0600172B(v11, v12, ((__cil_type_01000025)(null)), unchecked((__cil_enum_020006A1)(v13))));
        if (v14 == 0) {
            goto IL_005D;
        } else {
            goto IL_003C;
        }
        IL_003C: ;
        global::OpenRA.Mods.Common.Traits.Mobile v15 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v16 = l6;
        int v17 = __cil_bool_load(__cil_direct_0600172C(v15, v16));
        if (v17 == 0) {
            goto IL_005D;
        } else {
            goto IL_0046;
        }
        IL_0046: ;
        __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 v18 = preferToAvoid;
        if (v18 is null) {
            goto IL_0053;
        } else {
            goto IL_0049;
        }
        IL_0049: ;
        __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 v19 = preferToAvoid;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v20 = l6;
        int v21 = __cil_bool_load(__cil_callvirt_0A000798(v19, v20));
        if (v21 != 0) {
            goto IL_005D;
        } else {
            goto IL_0053;
        }
        IL_0053: ;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 v22 = l0;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v23 = l6;
        __cil_callvirt_0A00070C(v22, v23);
        goto IL_007E;
        IL_005D: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v24 = l6;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v25 = nextCell;
        int v26 = __cil_bool_load(OpenRA.CPos.op_Inequality(v24, v25));
        if (v26 == 0) {
            goto IL_007E;
        } else {
            goto IL_0067;
        }
        IL_0067: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v27 = l6;
        global::OpenRA.Mods.Common.Traits.Mobile v28 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v29 = __cil_direct_0600170B(v28);
        int v30 = __cil_bool_load(OpenRA.CPos.op_Inequality(v27, v29));
        if (v30 == 0) {
            goto IL_007E;
        } else {
            goto IL_0076;
        }
        IL_0076: ;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 v31 = l1;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v32 = l6;
        __cil_callvirt_0A00070C(v31, v32);
        goto IL_007E;
        IL_007E: ;
        int v33 = l4;
        int v34 = 1;
        int v35 = unchecked(v33 + v34);
        l4 = v35;
        goto IL_0084;
        IL_0084: ;
        int v36 = l4;
        __cil_ref_d20d79d97d633f365c6bfc6180ce6c25449caa83 v37 = l3;
        nint v38 = unchecked((nint)(v37.LongLength));
        int v39 = unchecked((int)(v38));
        if (v36 < v39) {
            goto IL_0017;
        } else {
            goto IL_008B;
        }
        IL_008B: ;
        ref __cil_value_2a38231b7620144b7e2926345dd445b782449779 v40 = ref l2;
        v40 = default;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 v41 = l0;
        int v42 = __cil_callvirt_0A0002A8(v41);
        int v43 = 0;
        if (v42 <= v43) {
            goto IL_00BB;
        } else {
            goto IL_009C;
        }
        IL_009C: ;
        ref __cil_value_2a38231b7620144b7e2926345dd445b782449779 v44 = ref l2;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 v45 = l0;
        global::OpenRA.Mods.Common.Traits.Mobile v46 = this;
        __cil_type_01000025 v47 = v46.self;
        __cil_type_0100002D v48 = v47.World;
        __cil_type_0100006E v49 = v48.SharedRandom;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v50 = __cil_methodspec_call_2B000039(((__cil_ref_165705a4046922f9e279f5113c881f18067dbd8e)(v45)), v49);
        __cil_ctor_call_0A0006B4(ref v44, v50);
        goto IL_0115;
        IL_00BB: ;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 v51 = l1;
        global::OpenRA.Mods.Common.Traits.Mobile v52 = this;
        nint v53 = __cil_ldftn_0600175B;
        __cil_ref_cca650ad0507d3f6fbf99a34fd677623696261db v54 = __cil_newobj_0A00016A(v52, v53);
        __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 v55 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003475;
        if (v55 is not null) {
            __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 e13_15_0 = v51;
            __cil_ref_cca650ad0507d3f6fbf99a34fd677623696261db e13_15_1 = v54;
            __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 e13_15_2 = v55;
            s15_0 = e13_15_0;
            s15_1 = e13_15_1;
            s15_2 = e13_15_2;
            goto IL_00E7;
        } else {
            __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 e13_14_0 = v51;
            __cil_ref_cca650ad0507d3f6fbf99a34fd677623696261db e13_14_1 = v54;
            __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 e13_14_2 = v55;
            s14_0 = e13_14_0;
            s14_1 = e13_14_1;
            s14_2 = e13_14_2;
            goto IL_00D0;
        }
        IL_00D0: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63 v56 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003473;
        nint v57 = __cil_ldftn_06003F01;
        __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 v58 = __cil_newobj_0A0014E1(v56, v57);
        OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003475 = v58;
        __cil_ref_154ba2ee719c4453ce8738baae7f2ef55eb99db0 e14_15_0 = s14_0;
        __cil_ref_cca650ad0507d3f6fbf99a34fd677623696261db e14_15_1 = s14_1;
        __cil_ref_b3444b369d8a7c315297042831fa4a46e8c756c5 e14_15_2 = v58;
        s15_0 = e14_15_0;
        s15_1 = e14_15_1;
        s15_2 = e14_15_2;
        goto IL_00E7;
        IL_00E7: ;
        __cil_ref_a973e33d8f9b46d89f497bd4534297b7cbe82a61 v59 = __cil_methodspec_call_2B000627(((__cil_ref_165705a4046922f9e279f5113c881f18067dbd8e)(s15_0)), s15_1, s15_2);
        global::OpenRA.Mods.Common.Traits.Mobile v60 = this;
        __cil_type_01000025 v61 = v60.self;
        __cil_type_0100002D v62 = v61.World;
        __cil_type_0100006E v63 = v62.SharedRandom;
        __cil_ref_181c5b4e12546c80f0be4e3e4af3817375f41e60 v64 = __cil_methodspec_call_2B000628(v59, v63);
        l7 = v64;
        __cil_ref_181c5b4e12546c80f0be4e3e4af3817375f41e60 v65 = l7;
        if (v65 is null) {
            goto IL_0115;
        } else {
            goto IL_0107;
        }
        IL_0107: ;
        ref __cil_value_2a38231b7620144b7e2926345dd445b782449779 v66 = ref l2;
        __cil_ref_181c5b4e12546c80f0be4e3e4af3817375f41e60 v67 = l7;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v68 = v67.get_Cell();
        __cil_ctor_call_0A0006B4(ref v66, v68);
        goto IL_0115;
        IL_0115: ;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 v69 = l2;
        return v69;
    }

    private static bool IsMovable(OpenRA.Actor otherActor)
    {
        OpenRA.Mods.Common.Traits.Mobile l0 = default;
        int v1 = __cil_bool_load(((OpenRA.Actor)otherActor).IsIdle);
        if (!(v1 != 0)) {
            return false;
        }
        global::OpenRA.Mods.Common.Traits.Mobile v4 = __cil_callvirt_2B000023(otherActor);
        l0 = v4;
        global::OpenRA.Mods.Common.Traits.Mobile v5 = l0;
        if (v5 is null) {
            return false;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        global::OpenRA.Mods.Common.Traits.Mobile v6 = l0;
        int v7 = __cil_bool_load(v6.get_IsTraitDisabled());
        if (v7 != 0) {
            return false;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        global::OpenRA.Mods.Common.Traits.Mobile v8 = l0;
        int v9 = __cil_bool_load(v8.get_IsTraitPaused());
        if (v9 != 0) {
            return false;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        global::OpenRA.Mods.Common.Traits.Mobile v10 = l0;
        int v11 = __cil_bool_load(__cil_callvirt_060016FE(v10));
        if (v11 == 0) {
            return true;
        } else {
            return false;
        }
    }

    public bool IsLeaving()
    {
        // enum storage token=0x02000695 alias=__cil_enum_02000695 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@MovementType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // Exact call 0x060016FC kept: direct virtual this accessor needs exact call notation.
        int v1 = unchecked((int)(__cil_direct_060016FC(this)));
        int v3 = __cil_bool_load(OpenRA.Mods.Common.Traits.LocomoterExts.HasMovementType(unchecked((__cil_enum_02000695)(v1)), unchecked((__cil_enum_02000695)(1))));
        if (!(v3 == 0)) {
            return true;
        }
        int v6 = unchecked((int)(__cil_direct_060016FC(this)));
        int v8 = __cil_bool_load(OpenRA.Mods.Common.Traits.LocomoterExts.HasMovementType(unchecked((__cil_enum_02000695)(v6)), unchecked((__cil_enum_02000695)(4))));
        if (v8 == 0) {
            return false;
        } else {
            goto IL_001E;
        }
        IL_001E: ;
        return this.TurnToMove;
    }

    public bool CanInteractWithGroundLayer(OpenRA.Actor self)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_23a63c8143d1ed2a653dd00c1e5916b2d69027f2 bytes=1D1299D8: class OpenRA.Mods.Common.Traits.ICustomMovementLayer[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ICustomMovementLayer l0 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l1 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = __cil_direct_0600170B(v0);
        l1 = v1;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v2 = ref l1;
        int v3 = unchecked((int)(__cil_memberref_call_0A00021B(ref v2)));
        if (v3 != 0) {
            goto IL_0012;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        int v4 = 1;
        return __cil_bool_store(v4);
        IL_0012: ;
        __cil_type_01000025 v5 = self;
        __cil_type_0100002D v6 = v5.World;
        __cil_ref_23a63c8143d1ed2a653dd00c1e5916b2d69027f2 v7 = OpenRA.Mods.Common.Traits.ActorMapWorldExts.GetCustomMovementLayers(v6);
        global::OpenRA.Mods.Common.Traits.Mobile v8 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v9 = __cil_direct_0600170B(v8);
        l1 = v9;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v10 = ref l1;
        int v11 = unchecked((int)(__cil_memberref_call_0A00021B(ref v10)));
        global::OpenRA.Mods.Common.Traits.ICustomMovementLayer v12 = v7[v11];
        l0 = v12;
        global::OpenRA.Mods.Common.Traits.ICustomMovementLayer v13 = l0;
        if (v13 is null) {
            goto IL_0037;
        } else {
            goto IL_0030;
        }
        IL_0030: ;
        global::OpenRA.Mods.Common.Traits.ICustomMovementLayer v14 = l0;
        int v15 = __cil_bool_load(__cil_callvirt_06001FAC(v14));
        return __cil_bool_store(v15);
        IL_0037: ;
        int v16 = 1;
        return __cil_bool_store(v16);
    }

    public virtual OpenRA.Traits.SubCell GetValidSubCell(OpenRA.Traits.SubCell preferred = 254)
    {
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        int v0 = unchecked((int)(unchecked((byte)(preferred))));
        if (unchecked((uint)v0) != unchecked((uint)254)) {
            goto IL_0010;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v3 = unchecked((int)(unchecked((byte)(this.FromSubCell))));
        preferred = unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v3))));
        IL_0010: ;
        global::OpenRA.Mods.Common.Traits.MobileInfo v5 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        global::OpenRA.Mods.Common.Traits.LocomotorInfo v6 = __cil_callvirt_060016EE(v5);
        int v7 = __cil_bool_load(v6.SharesCell);
        if (v7 == 0) {
            goto IL_0041;
        } else {
            goto IL_0022;
        }
        IL_0022: ;
        int v8 = unchecked((int)(unchecked((byte)(preferred))));
        if (v8 > 0) {
            goto IL_0046;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        __cil_type_01000025 v11 = this.self;
        __cil_type_0100002D v12 = v11.World;
        __cil_type_01000026 v13 = v12.Map;
        __cil_type_010000C7 v14 = v13.Grid;
        int v15 = unchecked((int)(unchecked((byte)(v14.DefaultSubCell))));
        return unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v15))));
        IL_0041: ;
        int v16 = unchecked((int)(unchecked((byte)(preferred))));
        if (v16 == 0) {
            goto IL_0046;
        } else {
            goto IL_0044;
        }
        IL_0044: ;
        return unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(0))));
        IL_0046: ;
        int v18 = unchecked((int)(unchecked((byte)(preferred))));
        return unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v18))));
    }

    public virtual void SetPosition(OpenRA.Actor self, OpenRA.CPos cell, OpenRA.Traits.SubCell subCell = 254)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_23a63c8143d1ed2a653dd00c1e5916b2d69027f2 bytes=1D1299D8: class OpenRA.Mods.Common.Traits.ICustomMovementLayer[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l0 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l1 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae s3_0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        int v1 = unchecked((int)(unchecked((byte)(subCell))));
        int v2 = unchecked((int)(unchecked((byte)(__cil_direct_06001723(v0, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v1)))))))));
        subCell = unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v2))));
        global::OpenRA.Mods.Common.Traits.Mobile v3 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v4 = cell;
        int v5 = unchecked((int)(unchecked((byte)(subCell))));
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v6 = cell;
        int v7 = unchecked((int)(unchecked((byte)(subCell))));
        __cil_direct_0600172D(v3, v4, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v5)))), v6, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v7)))));
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v8 = ref cell;
        int v9 = unchecked((int)(__cil_memberref_call_0A00021B(ref v8)));
        if (v9 == 0) {
            goto IL_0037;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        __cil_type_01000025 v10 = self;
        __cil_type_0100002D v11 = v10.World;
        __cil_ref_23a63c8143d1ed2a653dd00c1e5916b2d69027f2 v12 = OpenRA.Mods.Common.Traits.ActorMapWorldExts.GetCustomMovementLayers(v11);
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v13 = ref cell;
        int v14 = unchecked((int)(__cil_memberref_call_0A00021B(ref v13)));
        global::OpenRA.Mods.Common.Traits.ICustomMovementLayer v15 = v12[v14];
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v16 = cell;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v17 = __cil_callvirt_06001FB2(v15, v16);
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae e1_3_0 = v17;
        s3_0 = e1_3_0;
        goto IL_0048;
        IL_0037: ;
        __cil_type_01000025 v18 = self;
        __cil_type_0100002D v19 = v18.World;
        __cil_type_01000026 v20 = v19.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v21 = cell;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v22 = v20.CenterOfCell(v21);
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae e2_3_0 = v22;
        s3_0 = e2_3_0;
        goto IL_0048;
        IL_0048: ;
        l0 = s3_0;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v23 = ref l0;
        __cil_type_01000025 v24 = self;
        __cil_type_0100002D v25 = v24.World;
        __cil_type_01000026 v26 = v25.Map;
        __cil_type_010000C7 v27 = v26.Grid;
        int v28 = unchecked((int)(unchecked((byte)(subCell))));
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v29 = v27.OffsetOfSubCell(unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v28)))));
        l1 = v29;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v30 = ref l1;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v31 = OpenRA.WPos.op_Addition(ref v23, ref v30);
        l0 = v31;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v32 = ref l0;
        int v33 = 0;
        int v34 = 0;
        __cil_type_01000025 v35 = self;
        __cil_type_0100002D v36 = v35.World;
        __cil_type_01000026 v37 = v36.Map;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v38 = l0;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v39 = v37.DistanceAboveTerrain(v38);
        int v40 = v39.Length;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v41 = __cil_newobj_0A000221(v33, v34, v40);
        l1 = v41;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v42 = ref l1;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v43 = OpenRA.WPos.op_Subtraction(ref v32, ref v42);
        l0 = v43;
        global::OpenRA.Mods.Common.Traits.Mobile v44 = this;
        __cil_type_01000025 v45 = self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v46 = l0;
        __cil_direct_06001726(v44, v45, v46);
        global::OpenRA.Mods.Common.Traits.Mobile v47 = this;
        __cil_type_01000025 v48 = self;
        __cil_direct_0600172E(v47, v48);
        return;
    }

    public virtual void SetPosition(OpenRA.Actor self, OpenRA.WPos pos)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l0 = default;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae l1 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l2 = default;
        IL_0000: ;
        __cil_type_01000025 v0 = self;
        __cil_type_0100002D v1 = v0.World;
        __cil_type_01000026 v2 = v1.Map;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v3 = pos;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v4 = v2.CellContaining(v3);
        l0 = v4;
        global::OpenRA.Mods.Common.Traits.Mobile v5 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v6 = l0;
        global::OpenRA.Mods.Common.Traits.Mobile v7 = this;
        int v8 = unchecked((int)(unchecked((byte)(v7.FromSubCell))));
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v9 = l0;
        global::OpenRA.Mods.Common.Traits.Mobile v10 = this;
        int v11 = unchecked((int)(unchecked((byte)(v10.FromSubCell))));
        __cil_direct_0600172D(v5, v6, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v8)))), v9, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v11)))));
        global::OpenRA.Mods.Common.Traits.Mobile v12 = this;
        __cil_type_01000025 v13 = self;
        __cil_type_01000025 v14 = self;
        __cil_type_0100002D v15 = v14.World;
        __cil_type_01000026 v16 = v15.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v17 = l0;
        global::OpenRA.Mods.Common.Traits.Mobile v18 = this;
        int v19 = unchecked((int)(unchecked((byte)(v18.FromSubCell))));
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v20 = v16.CenterOfSubCell(v17, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v19)))));
        l1 = v20;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v21 = ref l1;
        int v22 = 0;
        int v23 = 0;
        __cil_type_01000025 v24 = self;
        __cil_type_0100002D v25 = v24.World;
        __cil_type_01000026 v26 = v25.Map;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v27 = pos;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v28 = v26.DistanceAboveTerrain(v27);
        int v29 = v28.Length;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v30 = __cil_newobj_0A000221(v22, v23, v29);
        l2 = v30;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v31 = ref l2;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v32 = OpenRA.WPos.op_Addition(ref v21, ref v31);
        __cil_direct_06001726(v12, v13, v32);
        global::OpenRA.Mods.Common.Traits.Mobile v33 = this;
        __cil_type_01000025 v34 = self;
        __cil_direct_0600172E(v33, v34);
        return;
    }

    public virtual void SetCenterPosition(OpenRA.Actor self, OpenRA.WPos pos)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d bytes=1D129874: class OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000026 l0 = default;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d l1 = default;
        int l2 = default;
        OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged l3 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l4 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v1 = pos;
        __cil_direct_06001712(v0, v1);
        __cil_type_01000025 v2 = self;
        __cil_type_0100002D v3 = v2.World;
        __cil_type_01000025 v4 = self;
        global::OpenRA.Mods.Common.Traits.Mobile v5 = this;
        v3.UpdateMaps(v4, ((__cil_type_010001EE)(v5)));
        __cil_type_01000025 v6 = self;
        __cil_type_0100002D v7 = v6.World;
        __cil_type_01000026 v8 = v7.Map;
        l0 = v8;
        global::OpenRA.Mods.Common.Traits.Mobile v9 = this;
        __cil_type_01000026 v10 = l0;
        __cil_type_01000026 v11 = l0;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v12 = pos;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v13 = v11.CellContaining(v12);
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v14 = v10.TerrainOrientation(v13);
        __cil_direct_06001727(v9, v14);
        global::OpenRA.Mods.Common.Traits.Mobile v15 = this;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v16 = v15.notifyCenterPositionChanged;
        if (v16 is not null) {
            goto IL_003C;
        } else {
            goto IL_003B;
        }
        IL_003B: ;
        return;
        IL_003C: ;
        global::OpenRA.Mods.Common.Traits.Mobile v17 = this;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v18 = v17.notifyCenterPositionChanged;
        l1 = v18;
        int v19 = 0;
        l2 = v19;
        goto IL_0074;
        IL_0047: ;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v20 = l1;
        int v21 = l2;
        global::OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged v22 = v20[v21];
        l3 = v22;
        global::OpenRA.Mods.Common.Traits.INotifyCenterPositionChanged v23 = l3;
        __cil_type_01000025 v24 = self;
        global::OpenRA.Mods.Common.Traits.Mobile v25 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v26 = __cil_direct_06001709(v25);
        l4 = v26;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v27 = ref l4;
        int v28 = unchecked((int)(__cil_memberref_call_0A00021B(ref v27)));
        global::OpenRA.Mods.Common.Traits.Mobile v29 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v30 = __cil_direct_0600170B(v29);
        l4 = v30;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v31 = ref l4;
        int v32 = unchecked((int)(__cil_memberref_call_0A00021B(ref v31)));
        __cil_callvirt_06001F1B(v23, v24, unchecked((byte)(v28)), unchecked((byte)(v32)));
        int v33 = l2;
        int v34 = 1;
        int v35 = unchecked(v33 + v34);
        l2 = v35;
        goto IL_0074;
        IL_0074: ;
        int v36 = l2;
        __cil_ref_2819d85ae49ca0446ada6bfc5cb909639768237d v37 = l1;
        nint v38 = unchecked((nint)(v37.LongLength));
        int v39 = unchecked((int)(v38));
        if (v36 < v39) {
            goto IL_0047;
        } else {
            goto IL_007A;
        }
        IL_007A: ;
        return;
    }

    public void SetTerrainRampOrientation(OpenRA.WRot orientation)
    {
        // structural signature __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 bytes=1180D5: valuetype [OpenRA.Game]OpenRA.WRot; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        global::OpenRA.Mods.Common.Traits.MobileInfo v1 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v0).Info;
        ref __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v2 = ref __cil_ldflda_0400132E(v1);
        int v3 = v2.Length;
        int v4 = 0;
        if (v3 < v4) {
            goto IL_001A;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        global::OpenRA.Mods.Common.Traits.Mobile v5 = this;
        __cil_value_3c99b82114c12cddedc02f82771ca1668af83f11 v6 = orientation;
        v5.terrainRampOrientation = v6;
        goto IL_001A;
        IL_001A: ;
        return;
    }

    public virtual bool IsLeavingCell(OpenRA.CPos location, OpenRA.Traits.SubCell subCell = 254)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = this.ToCell;
        int v3 = __cil_bool_load(OpenRA.CPos.op_Inequality(v1, location));
        if (v3 == 0) {
            return false;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v5 = this.FromCell;
        int v7 = __cil_bool_load(OpenRA.CPos.op_Equality(v5, location));
        if (v7 == 0) {
            return false;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        int v8 = unchecked((int)(unchecked((byte)(subCell))));
        if (v8 == 254) {
            return true;
        } else {
            goto IL_0024;
        }
        IL_0024: ;
        int v11 = unchecked((int)(unchecked((byte)(this.FromSubCell))));
        int v12 = unchecked((int)(unchecked((byte)(subCell))));
        if (v11 == v12) {
            return true;
        } else {
            goto IL_002D;
        }
        IL_002D: ;
        int v13 = unchecked((int)(unchecked((byte)(subCell))));
        if (v13 == 0) {
            return true;
        } else {
            goto IL_0030;
        }
        IL_0030: ;
        int v15 = unchecked((int)(unchecked((byte)(this.FromSubCell))));
        return (v15 == 0);
    }

    public virtual OpenRA.Traits.SubCell GetAvailableSubCell(OpenRA.CPos a, OpenRA.Traits.SubCell preferredSubCell = 254, OpenRA.Actor ignoreActor = null, OpenRA.Mods.Common.Traits.BlockedByActor check = 3)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020006A1 alias=__cil_enum_020006A1 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@BlockedByActor; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.Mods.Common.Traits.Locomotor v1 = this.Locomotor;
        __cil_type_01000025 v3 = this.self;
        int v5 = unchecked((int)(check));
        int v6 = unchecked((int)(unchecked((byte)(preferredSubCell))));
        int v8 = unchecked((int)(unchecked((byte)(__cil_callvirt_06001DA2(v1, v3, a, unchecked((__cil_enum_020006A1)(v5)), unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v6)))), ignoreActor)))));
        return unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v8))));
    }

    public virtual bool CanExistInCell(OpenRA.CPos cell)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Mods.Common.Traits.Locomotor v1 = this.Locomotor;
        int v3 = unchecked((int)(__cil_callvirt_06001D9B(v1, cell)));
        int v5 = (v3 == 32767 ? 1 : 0);
        return (v5 == 0);
    }

    public virtual bool CanEnterCell(OpenRA.CPos cell, OpenRA.Actor ignoreActor = null, OpenRA.Mods.Common.Traits.BlockedByActor check = 3)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x020006A1 alias=__cil_enum_020006A1 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@BlockedByActor; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::OpenRA.Mods.Common.Traits.MobileInfo v1 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        __cil_type_01000025 v3 = this.self;
        __cil_type_0100002D v4 = v3.World;
        __cil_type_01000025 v6 = this.self;
        int v9 = unchecked((int)(unchecked((byte)(this.ToSubCell))));
        return __cil_callvirt_060016F2(v1, v4, v6, cell, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v9)))), ignoreActor, unchecked((__cil_enum_020006A1)(unchecked((int)(check)))));
    }

    public bool CanStayInCell(OpenRA.CPos cell)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        global::OpenRA.Mods.Common.Traits.MobileInfo v1 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        __cil_type_01000025 v3 = this.self;
        __cil_type_0100002D v4 = v3.World;
        return __cil_callvirt_060016F3(v1, v4, cell);
    }

    public void SetLocation(OpenRA.CPos from, OpenRA.Traits.SubCell fromSub, OpenRA.CPos to, OpenRA.Traits.SubCell toSub)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_6b600c07da3c5fa7da130886771a02a07d60fe89 bytes=1D129870: class OpenRA.Mods.Common.Traits.INotifyCustomLayerChanged[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l0 = default;
        __cil_ref_6b600c07da3c5fa7da130886771a02a07d60fe89 l1 = default;
        int l2 = default;
        OpenRA.Mods.Common.Traits.INotifyCustomLayerChanged l3 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = __cil_direct_06001709(v0);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v2 = from;
        int v3 = __cil_bool_load(OpenRA.CPos.op_Equality(v1, v2));
        if (v3 == 0) {
            goto IL_0030;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        global::OpenRA.Mods.Common.Traits.Mobile v4 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v5 = __cil_direct_0600170B(v4);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v6 = to;
        int v7 = __cil_bool_load(OpenRA.CPos.op_Equality(v5, v6));
        if (v7 == 0) {
            goto IL_0030;
        } else {
            goto IL_001C;
        }
        IL_001C: ;
        global::OpenRA.Mods.Common.Traits.Mobile v8 = this;
        int v9 = unchecked((int)(unchecked((byte)(v8.FromSubCell))));
        int v10 = unchecked((int)(unchecked((byte)(fromSub))));
        if (unchecked((uint)v9) != unchecked((uint)v10)) {
            goto IL_0030;
        } else {
            goto IL_0025;
        }
        IL_0025: ;
        global::OpenRA.Mods.Common.Traits.Mobile v11 = this;
        int v12 = unchecked((int)(unchecked((byte)(v11.ToSubCell))));
        int v13 = unchecked((int)(unchecked((byte)(toSub))));
        if (unchecked((uint)v12) != unchecked((uint)v13)) {
            goto IL_0030;
        } else {
            goto IL_002F;
        }
        IL_002F: ;
        return;
        IL_0030: ;
        global::OpenRA.Mods.Common.Traits.Mobile v14 = this;
        __cil_direct_06001731(v14);
        global::OpenRA.Mods.Common.Traits.Mobile v15 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v16 = from;
        __cil_direct_0600170A(v15, v16);
        global::OpenRA.Mods.Common.Traits.Mobile v17 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v18 = to;
        __cil_direct_0600170C(v17, v18);
        global::OpenRA.Mods.Common.Traits.Mobile v19 = this;
        int v20 = unchecked((int)(unchecked((byte)(fromSub))));
        v19.FromSubCell = unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v20))));
        global::OpenRA.Mods.Common.Traits.Mobile v21 = this;
        int v22 = unchecked((int)(unchecked((byte)(toSub))));
        v21.ToSubCell = unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v22))));
        global::OpenRA.Mods.Common.Traits.Mobile v23 = this;
        __cil_direct_06001730(v23);
        global::OpenRA.Mods.Common.Traits.Mobile v24 = this;
        int v25 = 0;
        __cil_direct_06001701(v24, __cil_bool_store(v25));
        global::OpenRA.Mods.Common.Traits.Mobile v26 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v27 = __cil_direct_0600170B(v26);
        l0 = v27;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v28 = ref l0;
        int v29 = unchecked((int)(__cil_memberref_call_0A00021B(ref v28)));
        global::OpenRA.Mods.Common.Traits.Mobile v30 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v31 = __cil_direct_06001709(v30);
        l0 = v31;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v32 = ref l0;
        int v33 = unchecked((int)(__cil_memberref_call_0A00021B(ref v32)));
        if (v29 == v33) {
            goto IL_00BF;
        } else {
            goto IL_007E;
        }
        IL_007E: ;
        global::OpenRA.Mods.Common.Traits.Mobile v34 = this;
        __cil_ref_6b600c07da3c5fa7da130886771a02a07d60fe89 v35 = v34.notifyCustomLayerChanged;
        l1 = v35;
        int v36 = 0;
        l2 = v36;
        goto IL_00B9;
        IL_0089: ;
        __cil_ref_6b600c07da3c5fa7da130886771a02a07d60fe89 v37 = l1;
        int v38 = l2;
        global::OpenRA.Mods.Common.Traits.INotifyCustomLayerChanged v39 = v37[v38];
        l3 = v39;
        global::OpenRA.Mods.Common.Traits.INotifyCustomLayerChanged v40 = l3;
        global::OpenRA.Mods.Common.Traits.Mobile v41 = this;
        __cil_type_01000025 v42 = v41.self;
        global::OpenRA.Mods.Common.Traits.Mobile v43 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v44 = __cil_direct_06001709(v43);
        l0 = v44;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v45 = ref l0;
        int v46 = unchecked((int)(__cil_memberref_call_0A00021B(ref v45)));
        global::OpenRA.Mods.Common.Traits.Mobile v47 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v48 = __cil_direct_0600170B(v47);
        l0 = v48;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v49 = ref l0;
        int v50 = unchecked((int)(__cil_memberref_call_0A00021B(ref v49)));
        __cil_callvirt_06001F1A(v40, v42, unchecked((byte)(v46)), unchecked((byte)(v50)));
        int v51 = l2;
        int v52 = 1;
        int v53 = unchecked(v51 + v52);
        l2 = v53;
        goto IL_00B9;
        IL_00B9: ;
        int v54 = l2;
        __cil_ref_6b600c07da3c5fa7da130886771a02a07d60fe89 v55 = l1;
        nint v56 = unchecked((nint)(v55.LongLength));
        int v57 = unchecked((int)(v56));
        if (v54 < v57) {
            goto IL_0089;
        } else {
            goto IL_00BF;
        }
        IL_00BF: ;
        return;
    }

    public void FinishedMoving(OpenRA.Actor self)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_167de011a51f4877b001d5ad64d0de5662e89063 bytes=1D129878: class OpenRA.Mods.Common.Traits.INotifyFinishedMoving[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d bytes=15128121021298841512872D03128095128095151181E5011287A1: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.INotifyCrushed, class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l0 = default;
        __cil_ref_167de011a51f4877b001d5ad64d0de5662e89063 l1 = default;
        int l2 = default;
        OpenRA.Mods.Common.Traits.INotifyFinishedMoving l3 = default;
        OpenRA.Mods.Common.Traits.Mobile s7_0 = default;
        __cil_type_01000025 s7_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s7_2 = default;
        OpenRA.Mods.Common.Traits.Mobile s8_0 = default;
        __cil_type_01000025 s8_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s8_2 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = __cil_direct_06001709(v0);
        l0 = v1;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v2 = ref l0;
        int v3 = unchecked((int)(__cil_memberref_call_0A00021B(ref v2)));
        global::OpenRA.Mods.Common.Traits.Mobile v4 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v5 = __cil_direct_0600170B(v4);
        l0 = v5;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v6 = ref l0;
        int v7 = unchecked((int)(__cil_memberref_call_0A00021B(ref v6)));
        if (unchecked((uint)v3) != unchecked((uint)v7)) {
            goto IL_005A;
        } else {
            goto IL_001E;
        }
        IL_001E: ;
        global::OpenRA.Mods.Common.Traits.Mobile v8 = this;
        __cil_ref_167de011a51f4877b001d5ad64d0de5662e89063 v9 = v8.notifyFinishedMoving;
        l1 = v9;
        int v10 = 0;
        l2 = v10;
        goto IL_0054;
        IL_0029: ;
        __cil_ref_167de011a51f4877b001d5ad64d0de5662e89063 v11 = l1;
        int v12 = l2;
        global::OpenRA.Mods.Common.Traits.INotifyFinishedMoving v13 = v11[v12];
        l3 = v13;
        global::OpenRA.Mods.Common.Traits.INotifyFinishedMoving v14 = l3;
        __cil_type_01000025 v15 = self;
        global::OpenRA.Mods.Common.Traits.Mobile v16 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v17 = __cil_direct_06001709(v16);
        l0 = v17;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v18 = ref l0;
        int v19 = unchecked((int)(__cil_memberref_call_0A00021B(ref v18)));
        global::OpenRA.Mods.Common.Traits.Mobile v20 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v21 = __cil_direct_0600170B(v20);
        l0 = v21;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v22 = ref l0;
        int v23 = unchecked((int)(__cil_memberref_call_0A00021B(ref v22)));
        __cil_callvirt_06001F1C(v14, v15, unchecked((byte)(v19)), unchecked((byte)(v23)));
        int v24 = l2;
        int v25 = 1;
        int v26 = unchecked(v24 + v25);
        l2 = v26;
        goto IL_0054;
        IL_0054: ;
        int v27 = l2;
        __cil_ref_167de011a51f4877b001d5ad64d0de5662e89063 v28 = l1;
        nint v29 = unchecked((nint)(v28.LongLength));
        int v30 = unchecked((int)(v29));
        if (v27 < v30) {
            goto IL_0029;
        } else {
            goto IL_005A;
        }
        IL_005A: ;
        __cil_type_01000025 v31 = self;
        int v32 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.IsAtGroundLevel(v31));
        if (v32 != 0) {
            goto IL_0063;
        } else {
            goto IL_0062;
        }
        IL_0062: ;
        return;
        IL_0063: ;
        global::OpenRA.Mods.Common.Traits.Mobile v33 = this;
        __cil_type_01000025 v34 = self;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v35 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003476;
        if (v35 is not null) {
            OpenRA.Mods.Common.Traits.Mobile e6_8_0 = v33;
            __cil_type_01000025 e6_8_1 = v34;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e6_8_2 = v35;
            s8_0 = e6_8_0;
            s8_1 = e6_8_1;
            s8_2 = e6_8_2;
            goto IL_0084;
        } else {
            OpenRA.Mods.Common.Traits.Mobile e6_7_0 = v33;
            __cil_type_01000025 e6_7_1 = v34;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e6_7_2 = v35;
            s7_0 = e6_7_0;
            s7_1 = e6_7_1;
            s7_2 = e6_7_2;
            goto IL_006D;
        }
        IL_006D: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63 v36 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003473;
        nint v37 = __cil_ldftn_06003F02;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v38 = __cil_newobj_0A00112B(v36, v37);
        OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003476 = v38;
        OpenRA.Mods.Common.Traits.Mobile e7_8_0 = s7_0;
        __cil_type_01000025 e7_8_1 = s7_1;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e7_8_2 = v38;
        s8_0 = e7_8_0;
        s8_1 = e7_8_1;
        s8_2 = e7_8_2;
        goto IL_0084;
        IL_0084: ;
        __cil_direct_0600172F(s8_0, s8_1, s8_2);
        return;
    }

    private void CrushAction(OpenRA.Actor self, System.Func<OpenRA.Mods.Common.Traits.INotifyCrushed, System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>>> action)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d bytes=15128121021298841512872D03128095128095151181E5011287A1: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.INotifyCrushed, class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 bytes=151280A10115118125011284C9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af bytes=151280A50115118125011284C9: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 bytes=15118125011284C9: valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 bytes=151280A501129884: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class OpenRA.Mods.Common.Traits.INotifyCrushed>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 bytes=1512812102128095151280A10115118125011284C9: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 bytes=151181E5011287A1: valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_d995c0c526708ec78848b40add5041ee43b0e621 bytes=151280A101129884: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.INotifyCrushed>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_395110448511d63be4531c40c9e73da5028734d3 bytes=1512872D03128095128095151181E5011287A1: class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F30 l0 = default;
        __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 l1 = default;
        __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af l2 = default;
        __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 l3 = default;
        __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 l4 = default;
        OpenRA.Mods.Common.Traits.INotifyCrushed l5 = default;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s1_0 = default;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 s1_1 = default;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 s2_0 = default;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 s2_1 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F30 v0 = __cil_newobj_06003F07();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F30 v1 = l0;
        __cil_type_01000025 v2 = self;
        v1.self = v2;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F30 v3 = l0;
        __cil_type_01000025 v4 = v3.self;
        __cil_type_0100002D v5 = v4.World;
        __cil_type_01000130 v6 = v5.ActorMap;
        global::OpenRA.Mods.Common.Traits.Mobile v7 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v8 = __cil_direct_0600170B(v7);
        global::OpenRA.Mods.Common.Traits.Mobile v9 = this;
        int v10 = unchecked((int)(unchecked((byte)(v9.ToSubCell))));
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v11 = __cil_callvirt_0A0014E5(v6, v8, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v10)))));
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F30 v12 = l0;
        nint v13 = __cil_ldftn_06003F08;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v14 = __cil_newobj_0A00019A(v12, v13);
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v15 = __cil_methodspec_call_2B000009(v11, v14);
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 v16 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003477;
        if (v16 is not null) {
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e0_2_0 = v15;
            __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 e0_2_1 = v16;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_005E;
        } else {
            __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e0_1_0 = v15;
            __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 e0_1_1 = v16;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_0047;
        }
        IL_0047: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63 v17 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003473;
        nint v18 = __cil_ldftn_06003F03;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 v19 = __cil_newobj_0A00112C(v17, v18);
        OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003477 = v19;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 e1_2_0 = s1_0;
        __cil_ref_0f14e3be0791e1be558ad136a20aa966dfb89765 e1_2_1 = v19;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        goto IL_005E;
        IL_005E: ;
        __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 v20 = __cil_methodspec_call_2B000475(s2_0, s2_1);
        l1 = v20;
        __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 v21 = l1;
        __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v22 = __cil_callvirt_0A00112D(v21);
        l2 = v22;
        try {
            IL_006B: ;
            goto IL_010A;
            IL_0070: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v23 = l2;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v24 = __cil_callvirt_0A00112E(v23);
            l3 = v24;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v25 = l3;
            __cil_type_01000132 v26 = v25.Trait;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v27 = l3;
            __cil_type_01000025 v28 = v27.Actor;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F30 v29 = l0;
            __cil_type_01000025 v30 = v29.self;
            global::OpenRA.Mods.Common.Traits.Mobile v31 = this;
            global::OpenRA.Mods.Common.Traits.MobileInfo v32 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v31).Info;
            global::OpenRA.Mods.Common.Traits.LocomotorInfo v33 = __cil_callvirt_060016EE(v32);
            __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 v34 = v33.Crushes;
            int v35 = __cil_bool_load(__cil_callvirt_0A0000BB(v26, v28, v30, v34));
            if (v35 == 0) {
                goto IL_010A;
            } else {
                goto IL_00A0;
            }
            IL_00A0: ;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v36 = l3;
            __cil_type_01000025 v37 = v36.Actor;
            int v38 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.IsAtGroundLevel(v37));
            if (v38 == 0) {
                goto IL_010A;
            } else {
                goto IL_00AD;
            }
            IL_00AD: ;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v39 = l3;
            __cil_type_01000025 v40 = v39.Actor;
            __cil_ref_d995c0c526708ec78848b40add5041ee43b0e621 v41 = __cil_callvirt_2B000476(v40);
            __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v42 = __cil_callvirt_0A001131(v41);
            l4 = v42;
            try {
                IL_00BF: ;
                goto IL_00F3;
                IL_00C1: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v43 = l4;
                global::OpenRA.Mods.Common.Traits.INotifyCrushed v44 = __cil_callvirt_0A001132(v43);
                l5 = v44;
                __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v45 = action;
                global::OpenRA.Mods.Common.Traits.INotifyCrushed v46 = l5;
                __cil_ref_395110448511d63be4531c40c9e73da5028734d3 v47 = __cil_callvirt_0A001133(v45, v46);
                __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v48 = l3;
                __cil_type_01000025 v49 = v48.Actor;
                global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F30 v50 = l0;
                __cil_type_01000025 v51 = v50.self;
                global::OpenRA.Mods.Common.Traits.Mobile v52 = this;
                global::OpenRA.Mods.Common.Traits.MobileInfo v53 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v52).Info;
                global::OpenRA.Mods.Common.Traits.LocomotorInfo v54 = __cil_callvirt_060016EE(v53);
                __cil_value_3ce420d19db35f344a56a9474ef4cdcf690c8348 v55 = v54.Crushes;
                __cil_callvirt_0A001134(v47, v49, v51, v55);
                goto IL_00F3;
                IL_00F3: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v56 = l4;
                int v57 = __cil_bool_load(__cil_callvirt_0A00001B(v56));
                if (v57 != 0) {
                    goto IL_00C1;
                } else {
                    goto IL_00FC;
                }
                IL_00FC: ;
                goto IL_010A;
            }
            finally {
                IL_00FE: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v58 = l4;
                if (v58 is null) {
                    goto IL_0109;
                } else {
                    goto IL_0102;
                }
                IL_0102: ;
                __cil_ref_d0e479bedbb04d9406f107ed44286c04ca728804 v59 = l4;
                __cil_callvirt_0A00001A(v59);
                goto IL_0109;
                IL_0109: ;
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_010A: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v60 = l2;
            int v61 = __cil_bool_load(__cil_callvirt_0A00001B(v60));
            if (v61 != 0) {
                goto IL_0070;
            } else {
                goto IL_0115;
            }
            IL_0115: ;
            goto IL_0121;
        }
        finally {
            IL_0117: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v62 = l2;
            if (v62 is null) {
                goto IL_0120;
            } else {
                goto IL_011A;
            }
            IL_011A: ;
            __cil_ref_7f1dc413b063126f805567f1ee8f91f0667af3af v63 = l2;
            __cil_callvirt_0A00001A(v63);
            goto IL_0120;
            IL_0120: ;
            goto __cil_finally_end_1;
            __cil_finally_end_1: ;
        }
        IL_0121: ;
        return;
    }

    public void AddInfluence()
    {
        __cil_type_01000025 v1 = this.self;
        int v2 = __cil_bool_load(((OpenRA.Actor)v1).IsInWorld);
        if (v2 == 0) {
            goto IL_0029;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_type_01000025 v4 = this.self;
        __cil_type_0100002D v5 = v4.World;
        __cil_type_01000130 v6 = v5.ActorMap;
        __cil_type_01000025 v8 = this.self;
        __cil_callvirt_0A001129(v6, v8, ((__cil_type_010001EE)(this)));
        IL_0029: ;
        return;
    }

    public void RemoveInfluence()
    {
        __cil_type_01000025 v1 = this.self;
        int v2 = __cil_bool_load(((OpenRA.Actor)v1).IsInWorld);
        if (v2 == 0) {
            goto IL_0029;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        __cil_type_01000025 v4 = this.self;
        __cil_type_0100002D v5 = v4.World;
        __cil_type_01000130 v6 = v5.ActorMap;
        __cil_type_01000025 v8 = this.self;
        __cil_callvirt_0A001128(v6, v8, ((__cil_type_010001EE)(this)));
        IL_0029: ;
        return;
    }

    private OpenRA.Activities.Activity WrapMove(OpenRA.Activities.Activity inner)
    {
        // structural signature __cil_ref_48a5e6689ec8bb1d944f17e98344d3f8ef945f29 bytes=1D1299F0: class OpenRA.Mods.Common.Traits.IWrapMove[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.IWrapMove l0 = default;
        __cil_ref_48a5e6689ec8bb1d944f17e98344d3f8ef945f29 v1 = this.moveWrappers;
        global::OpenRA.Mods.Common.Traits.IWrapMove v2 = __cil_methodspec_call_2B000629(v1);
        l0 = v2;
        global::OpenRA.Mods.Common.Traits.IWrapMove v3 = l0;
        if (v3 is null) {
            return inner;
        } else {
            goto IL_000F;
        }
        IL_000F: ;
        global::OpenRA.Mods.Common.Traits.IWrapMove v4 = l0;
        __cil_type_0100010F v6 = __cil_callvirt_06001FC4(v4, inner);
        return v6;
    }

    public virtual OpenRA.Activities.Activity MoveTo(OpenRA.CPos cell, int nearEnough = 0, OpenRA.Actor ignoreActor = null, bool evaluateNearestMovableCell = false, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_type_01000025 v2 = this.self;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v5 = OpenRA.WDist.FromCells(nearEnough);
        int v7 = __cil_bool_load(evaluateNearestMovableCell);
        global::OpenRA.Mods.Common.Activities.Move v9 = __cil_newobj_060023BB(v2, cell, v5, ignoreActor, v7, targetLineColor);
        __cil_type_0100010F v10 = __cil_direct_06001732(this, ((__cil_type_0100010F)(v9)));
        return v10;
    }

    public OpenRA.Activities.Activity MoveWithinRange(ref OpenRA.Traits.Target target, OpenRA.WDist range, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        global::OpenRA.Mods.Common.Traits.Mobile v1 = this;
        __cil_type_01000025 v2 = v1.self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v3 = ref target;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v4 = __cil_ldsfld_0A00023E();
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v5 = range;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v6 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v7 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.MoveWithinRange v8 = __cil_newobj_060023E0(v2, ref v3, v4, v5, v6, v7);
        __cil_type_0100010F v9 = __cil_direct_06001732(v0, ((__cil_type_0100010F)(v8)));
        return v9;
    }

    public OpenRA.Activities.Activity MoveWithinRange(ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        global::OpenRA.Mods.Common.Traits.Mobile v1 = this;
        __cil_type_01000025 v2 = v1.self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v3 = ref target;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v4 = minRange;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v5 = maxRange;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v6 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v7 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.MoveWithinRange v8 = __cil_newobj_060023E0(v2, ref v3, v4, v5, v6, v7);
        __cil_type_0100010F v9 = __cil_direct_06001732(v0, ((__cil_type_0100010F)(v8)));
        return v9;
    }

    public OpenRA.Activities.Activity MoveFollow(OpenRA.Actor self, ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_type_01000025 v1 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v2 = ref target;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v3 = minRange;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v4 = maxRange;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v5 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v6 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.Follow v7 = __cil_newobj_060023B0(v1, ref v2, v3, v4, v5, v6);
        __cil_type_0100010F v8 = __cil_direct_06001732(v0, ((__cil_type_0100010F)(v7)));
        return v8;
    }

    public virtual OpenRA.Activities.Activity ReturnToCell(OpenRA.Actor self)
    {
        global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity v3 = __cil_newobj_06003EEE(self, 0, 0);
        return v3;
    }

    public OpenRA.Activities.Activity MoveToTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 bytes=15118141011180ED: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200011C alias=__cil_enum_0200011C underlying=byte: global::@OpenRA.@Traits.@TargetType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v0 = ref target;
        int v1 = unchecked((int)(unchecked((byte)(__cil_memberref_call_0A000208(ref v0)))));
        if (v1 != 0) {
            goto IL_000A;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return null;
        IL_000A: ;
        global::OpenRA.Mods.Common.Traits.Mobile v2 = this;
        __cil_type_01000025 v3 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v4 = ref target;
        __cil_value_4a28f9e66178ae24f495e26b641eb38909b6ee96 v5 = initialTargetPosition;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v6 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.MoveAdjacentTo v7 = __cil_newobj_060023CA(v3, ref v4, v5, v6);
        __cil_type_0100010F v8 = __cil_direct_06001732(v2, ((__cil_type_0100010F)(v7)));
        return v8;
    }

    public OpenRA.Activities.Activity MoveIntoTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200011C alias=__cil_enum_0200011C underlying=byte: global::@OpenRA.@Traits.@TargetType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l0 = default;
        IL_0000: ;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v0 = ref target;
        int v1 = unchecked((int)(unchecked((byte)(__cil_memberref_call_0A000208(ref v0)))));
        if (v1 != 0) {
            goto IL_000A;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return null;
        IL_000A: ;
        global::OpenRA.Mods.Common.Traits.Mobile v2 = this;
        __cil_type_01000025 v3 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v4 = ref target;
        int v5 = 512;
        __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v6 = __cil_newobj_0A00023F(v5);
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v7 = ref l0;
        v7 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v8 = l0;
        global::OpenRA.Mods.Common.Activities.LocalMoveIntoTarget v9 = __cil_newobj_060023B3(v3, ref v4, v6, v8);
        __cil_type_0100010F v10 = __cil_direct_06001732(v2, ((__cil_type_0100010F)(v9)));
        return v10;
    }

    public OpenRA.Activities.Activity MoveOntoTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target, ref OpenRA.WVec offset, System.Nullable<OpenRA.WAngle> facing, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_type_01000025 v1 = self;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v2 = ref target;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v3 = ref offset;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v4 = facing;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v5 = targetLineColor;
        global::OpenRA.Mods.Common.Activities.MoveOntoAndTurn v6 = __cil_newobj_060023DE(v1, ref v2, ref v3, v4, v5);
        __cil_type_0100010F v7 = __cil_direct_06001732(v0, ((__cil_type_0100010F)(v6)));
        return v7;
    }

    public virtual OpenRA.Activities.Activity LocalMove(OpenRA.Actor self, OpenRA.WPos fromPos, OpenRA.WPos toPos)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v6 = ((OpenRA.Actor)self).Location;
        __cil_type_0100010F v7 = __cil_direct_06001744(this, self, fromPos, toPos, v6);
        __cil_type_0100010F v8 = __cil_direct_06001732(this, v7);
        return v8;
    }

    public virtual int EstimatedMoveDuration(OpenRA.Actor self, OpenRA.WPos fromPos, OpenRA.WPos toPos)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int l0 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l1 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_type_01000025 v1 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v2 = ((OpenRA.Actor)v1).Location;
        int v3 = __cil_direct_0600173F(v0, v2);
        l0 = v3;
        int v4 = l0;
        int v5 = 0;
        if (v4 > v5) {
            goto IL_0013;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        int v6 = 0;
        return v6;
        IL_0013: ;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v7 = ref toPos;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v8 = ref fromPos;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v9 = OpenRA.WPos.op_Subtraction(ref v7, ref v8);
        l1 = v9;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v10 = ref l1;
        int v11 = __cil_memberref_call_0A000257(ref v10);
        int v12 = l0;
        int v13 = unchecked(v11 / v12);
        return v13;
    }

    public virtual OpenRA.CPos NearestMoveableCell(OpenRA.CPos target)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v4 = __cil_direct_06001740(this, target, 1, 10);
        return v4;
    }

    public bool CanEnterTargetNow(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 bytes=15128121021180A902: class [System.Runtime]System.Func`2<valuetype [OpenRA.Game]OpenRA.CPos, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e bytes=151280A1011180A9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200011C alias=__cil_enum_0200011C underlying=byte: global::@OpenRA.@Traits.@TargetType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C6173733130395F30 l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C6173733130395F30 v0 = __cil_newobj_06003F05();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C6173733130395F30 v1 = l0;
        __cil_type_01000025 v2 = self;
        v1.self = v2;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v3 = ref target;
        int v4 = unchecked((int)(unchecked((byte)(__cil_memberref_call_0A000208(ref v3)))));
        int v5 = 3;
        if (unchecked((uint)v4) != unchecked((uint)v5)) {
            goto IL_0025;
        } else {
            goto IL_0016;
        }
        IL_0016: ;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v6 = ref target;
        __cil_type_0100006C v7 = __cil_memberref_call_0A00020D(ref v6);
        int v8 = __cil_bool_load(((OpenRA.Traits.FrozenActor)v7).IsValid);
        if (v8 != 0) {
            goto IL_0025;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        int v9 = 0;
        return __cil_bool_store(v9);
        IL_0025: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C6173733130395F30 v10 = l0;
        __cil_type_01000025 v11 = v10.self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v12 = ((OpenRA.Actor)v11).Location;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C6173733130395F30 v13 = l0;
        __cil_type_01000025 v14 = v13.self;
        __cil_type_0100002D v15 = v14.World;
        __cil_type_01000026 v16 = v15.Map;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v17 = ref target;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v18 = __cil_memberref_call_0A00027F(ref v17);
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v19 = v16.CellContaining(v18);
        int v20 = __cil_bool_load(OpenRA.CPos.op_Equality(v12, v19));
        if (v20 != 0) {
            goto IL_0075;
        } else {
            goto IL_0052;
        }
        IL_0052: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C6173733130395F30 v21 = l0;
        __cil_type_01000025 v22 = v21.self;
        __cil_type_0100002D v23 = v22.World;
        ref __cil_value_afed037d079105c214a094897df496882260d1c3 v24 = ref target;
        __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e v25 = OpenRA.Mods.Common.Util.AdjacentCells(v23, ref v24);
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C6173733130395F30 v26 = l0;
        nint v27 = __cil_ldftn_06003F06;
        __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 v28 = __cil_newobj_0A0007E7(v26, v27);
        int v29 = __cil_bool_load(__cil_methodspec_call_2B000548(v25, v28));
        return __cil_bool_store(v29);
        IL_0075: ;
        int v30 = 1;
        return __cil_bool_store(v30);
    }

    public int MovementSpeedForCell(OpenRA.CPos cell)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4aa8ae9ba810a6865a3e9d91de7ae35bcf0aa3ea bytes=1512810501151280A10108: class [System.Runtime]System.Lazy`1<class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.Locomotor v1 = this.Locomotor;
        int v3 = __cil_callvirt_06001D9D(v1, cell);
        __cil_ref_4aa8ae9ba810a6865a3e9d91de7ae35bcf0aa3ea v5 = this.speedModifiers;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v6 = __cil_callvirt_0A0014E6(v5);
        int[] v8 = new int[1];
        v8[0] = v3;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v11 = __cil_methodspec_call_2B000037(v6, v8);
        global::OpenRA.Mods.Common.Traits.MobileInfo v13 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        int v14 = v13.Speed;
        int v16 = OpenRA.Mods.Common.Util.ApplyPercentageModifiers(v14, v11);
        return v16;
    }

    public OpenRA.CPos NearestMoveableCell(OpenRA.CPos target, int minRange, int maxRange)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [0F, 01, 28, 1B, 02, 00, 0A, 2C, 15, 0F, 01, 0F, 01, 28, 94, 07, 00, 0A, 0F, 01, 28, 95, 07, 00]
        // .code-bytes IL_0018: [0A, 28, 6D, 06, 00, 0A, 03, 02, 7B, 31, 13, 00, 04, 6F, 5B, 01, 00, 0A, 28, E0, 07, 00, 0A, 2C]
        // .code-bytes IL_0030: [0B, 02, 03, 28, 2C, 17, 00, 06, 2C, 02, 03, 2A, 02, 03, 14, 17, 28, 2B, 17, 00, 06, 2C, 0B, 02]
        // .code-bytes IL_0048: [03, 28, 2C, 17, 00, 06, 2C, 02, 03, 2A, 02, 7B, 31, 13, 00, 04, 7B, 59, 01, 00, 0A, 7B, 5A, 01]
        // .code-bytes IL_0060: [00, 0A, 03, 04, 05, 16, 6F, 95, 02, 00, 0A, 6F, 2B, 00, 00, 0A, 0A, 2B, 1F, 06, 6F, 2A, 00, 00]
        // .code-bytes IL_0078: [0A, 0B, 02, 07, 14, 17, 28, 2B, 17, 00, 06, 2C, 0D, 02, 07, 28, 2C, 17, 00, 06, 2C, 04, 07, 0C]
        // .code-bytes IL_0090: [DE, 16, 06, 6F, 1B, 00, 00, 0A, 2D, D9, DE, 0A, 06, 2C, 06, 06, 6F, 1A, 00, 00, 0A, DC, 03, 2A]
        // .code-bytes IL_00A8: [08, 2A]
        // .local [0] class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.CPos>
        // .local [1] valuetype [OpenRA.Game]OpenRA.CPos
        // .local [2] valuetype [OpenRA.Game]OpenRA.CPos
        // IL_0000: ldarga.s 1
        // IL_0002: call 0x0A00021B [OpenRA.Game]OpenRA.CPos::get_Layer
        // IL_0007: brfalse.s IL_001E
        // IL_0009: ldarga.s 1
        // IL_000B: ldarga.s 1
        // IL_000D: call 0x0A000794 [OpenRA.Game]OpenRA.CPos::get_X
        // IL_0012: ldarga.s 1
        // IL_0014: call 0x0A000795 [OpenRA.Game]OpenRA.CPos::get_Y
        // IL_0019: call 0x0A00066D [OpenRA.Game]OpenRA.CPos::.ctor
        // IL_001E: ldarg.1 1
        // IL_001F: ldarg.0 0
        // IL_0020: ldfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_0025: callvirt 0x0A00015B [OpenRA.Game]OpenRA.Actor::get_Location
        // IL_002A: call 0x0A0007E0 [OpenRA.Game]OpenRA.CPos::op_Equality
        // IL_002F: brfalse.s IL_003C
        // IL_0031: ldarg.0 0
        // IL_0032: ldarg.1 1
        // IL_0033: call 0x0600172C OpenRA.Mods.Common.Traits.Mobile::CanStayInCell
        // IL_0038: brfalse.s IL_003C
        // IL_003A: ldarg.1 1
        // IL_003B: ret 
        // IL_003C: ldarg.0 0
        // IL_003D: ldarg.1 1
        // IL_003E: ldnull 
        // IL_003F: ldc.i4.1 1
        // IL_0040: call 0x0600172B OpenRA.Mods.Common.Traits.Mobile::CanEnterCell
        // IL_0045: brfalse.s IL_0052
        // IL_0047: ldarg.0 0
        // IL_0048: ldarg.1 1
        // IL_0049: call 0x0600172C OpenRA.Mods.Common.Traits.Mobile::CanStayInCell
        // IL_004E: brfalse.s IL_0052
        // IL_0050: ldarg.1 1
        // IL_0051: ret 
        // IL_0052: ldarg.0 0
        // IL_0053: ldfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_0058: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_005D: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0062: ldarg.1 1
        // IL_0063: ldarg.2 2
        // IL_0064: ldarg.3 3
        // IL_0065: ldc.i4.0 0
        // IL_0066: callvirt 0x0A000295 [OpenRA.Game]OpenRA.Map::FindTilesInAnnulus
        // IL_006B: callvirt 0x0A00002B class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.CPos>::GetEnumerator
        // IL_0070: stloc.0 0
        // IL_0071: br.s IL_0092
        // IL_0073: ldloc.0 0
        // IL_0074: callvirt 0x0A00002A class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.CPos>::get_Current
        // IL_0079: stloc.1 1
        // IL_007A: ldarg.0 0
        // IL_007B: ldloc.1 1
        // IL_007C: ldnull 
        // IL_007D: ldc.i4.1 1
        // IL_007E: call 0x0600172B OpenRA.Mods.Common.Traits.Mobile::CanEnterCell
        // IL_0083: brfalse.s IL_0092
        // IL_0085: ldarg.0 0
        // IL_0086: ldloc.1 1
        // IL_0087: call 0x0600172C OpenRA.Mods.Common.Traits.Mobile::CanStayInCell
        // IL_008C: brfalse.s IL_0092
        // IL_008E: ldloc.1 1
        // IL_008F: stloc.2 2
        // IL_0090: leave.s IL_00A8
        // IL_0092: ldloc.0 0
        // IL_0093: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_0098: brtrue.s IL_0073
        // IL_009A: leave.s IL_00A6
        // IL_009C: ldloc.0 0
        // IL_009D: brfalse.s IL_00A5
        // IL_009F: ldloc.0 0
        // IL_00A0: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_00A5: endfinally 
        // IL_00A6: ldarg.1 1
        // IL_00A7: ret 
        // IL_00A8: ldloc.2 2
        // IL_00A9: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 113, try_length: 43, handler_offset: 156, handler_length: 10, raw_flags: 2 }
        // .try IL_0071..IL_009C finally IL_009C..IL_00A6
    }

    public OpenRA.CPos NearestCell(OpenRA.CPos target, System.Func<OpenRA.CPos, bool> check, int minRange, int maxRange)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 bytes=15128121021180A902: class [System.Runtime]System.Func`2<valuetype [OpenRA.Game]OpenRA.CPos, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e bytes=151280A1011180A9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d bytes=151280A5011180A9: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d l0 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l1 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l2 = default;
        IL_0000: ;
        __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 v0 = check;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = target;
        int v2 = __cil_bool_load(__cil_callvirt_0A000798(v0, v1));
        if (v2 == 0) {
            goto IL_000B;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v3 = target;
        return v3;
        IL_000B: ;
        global::OpenRA.Mods.Common.Traits.Mobile v4 = this;
        __cil_type_01000025 v5 = v4.self;
        __cil_type_0100002D v6 = v5.World;
        __cil_type_01000026 v7 = v6.Map;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v8 = target;
        int v9 = minRange;
        int v10 = maxRange;
        int v11 = 0;
        __cil_ref_165705a4046922f9e279f5113c881f18067dbd8e v12 = v7.FindTilesInAnnulus(v8, v9, v10, __cil_bool_store(v11));
        __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v13 = __cil_callvirt_0A00002B(v12);
        l0 = v13;
        try {
            IL_002B: ;
            goto IL_0041;
            IL_002D: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v14 = l0;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v15 = __cil_callvirt_0A00002A(v14);
            l1 = v15;
            __cil_ref_df3204ad56250276e00bab9c5179b4baf46913f7 v16 = check;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v17 = l1;
            int v18 = __cil_bool_load(__cil_callvirt_0A000798(v16, v17));
            if (v18 == 0) {
                goto IL_0041;
            } else {
                goto IL_003D;
            }
            IL_003D: ;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v19 = l1;
            l2 = v19;
            goto IL_0057;
            IL_0041: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v20 = l0;
            int v21 = __cil_bool_load(__cil_callvirt_0A00001B(v20));
            if (v21 != 0) {
                goto IL_002D;
            } else {
                goto IL_0049;
            }
            IL_0049: ;
            goto IL_0055;
        }
        finally {
            IL_004B: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v22 = l0;
            if (v22 is null) {
                goto IL_0054;
            } else {
                goto IL_004E;
            }
            IL_004E: ;
            __cil_ref_196aef51a2452efcd80efb2a0ee63a834d59cc4d v23 = l0;
            __cil_callvirt_0A00001A(v23);
            goto IL_0054;
            IL_0054: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0055: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v24 = target;
        return v24;
        IL_0057: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v25 = l2;
        return v25;
    }

    public void EnteringCell(OpenRA.Actor self)
    {
        // structural signature __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d bytes=15128121021298841512872D03128095128095151181E5011287A1: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.INotifyCrushed, class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.Mobile s3_0 = default;
        __cil_type_01000025 s3_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s3_2 = default;
        OpenRA.Mods.Common.Traits.Mobile s4_0 = default;
        __cil_type_01000025 s4_1 = default;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d s4_2 = default;
        int v1 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.IsAtGroundLevel(self));
        if (v1 != 0) {
            goto IL_0009;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        return;
        IL_0009: ;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v4 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003478;
        if (v4 is not null) {
            OpenRA.Mods.Common.Traits.Mobile e2_4_0 = this;
            __cil_type_01000025 e2_4_1 = self;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e2_4_2 = v4;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            s4_2 = e2_4_2;
            goto IL_002A;
        } else {
            OpenRA.Mods.Common.Traits.Mobile e2_3_0 = this;
            __cil_type_01000025 e2_3_1 = self;
            __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e2_3_2 = v4;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            s3_2 = e2_3_2;
            goto IL_0013;
        }
        IL_0013: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63 v5 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003473;
        nint v6 = __cil_ldftn_06003F04;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d v7 = __cil_newobj_0A00112B(v5, v6);
        OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003478 = v7;
        OpenRA.Mods.Common.Traits.Mobile e3_4_0 = s3_0;
        __cil_type_01000025 e3_4_1 = s3_1;
        __cil_ref_53b559b474ac0799d1663c34fc7877470f45973d e3_4_2 = v7;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        s4_2 = e3_4_2;
        IL_002A: ;
        __cil_direct_0600172F(s4_0, s4_1, s4_2);
        return;
    }

    public OpenRA.Activities.Activity MoveTo(System.Func<OpenRA.Mods.Common.Traits.BlockedByActor, System.ValueTuple<bool, System.Collections.Generic.List<OpenRA.CPos>>> pathFunc)
    {
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_9d42f019f8c077dcb7c76bf78ad9b9a88910cf3c bytes=1512812102119A84151181A902021512811D011180A9: class [System.Runtime]System.Func`2<valuetype OpenRA.Mods.Common.Traits.BlockedByActor, valuetype [System.Runtime]System.ValueTuple`2<bool, class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.CPos>>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_type_01000025 v1 = v0.self;
        __cil_ref_9d42f019f8c077dcb7c76bf78ad9b9a88910cf3c v2 = pathFunc;
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v3 = ref l0;
        v3 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v4 = l0;
        global::OpenRA.Mods.Common.Activities.Move v5 = __cil_newobj_060023BC(v1, v2, v4);
        return v5;
    }

    private OpenRA.Activities.Activity LocalMove(OpenRA.Actor self, OpenRA.WPos fromPos, OpenRA.WPos toPos, OpenRA.CPos cell)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 bytes=1181B5: valuetype [OpenRA.Game]OpenRA.WVec; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 bytes=15118141011180CD: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        int l0 = default;
        int l1 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l2 = default;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae l3 = default;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 l4 = default;
        int s3_0 = default;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae s6_0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.Mobile v0 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = cell;
        int v2 = __cil_direct_0600173F(v0, v1);
        l0 = v2;
        int v3 = l0;
        int v4 = 0;
        if (v3 > v4) {
            goto IL_0010;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v5 = 0;
        int e1_3_0 = v5;
        s3_0 = e1_3_0;
        goto IL_0024;
        IL_0010: ;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v6 = ref toPos;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v7 = ref fromPos;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v8 = OpenRA.WPos.op_Subtraction(ref v6, ref v7);
        l4 = v8;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v9 = ref l4;
        int v10 = __cil_memberref_call_0A000257(ref v9);
        int v11 = l0;
        int v12 = unchecked(v10 / v11);
        int e2_3_0 = v12;
        s3_0 = e2_3_0;
        goto IL_0024;
        IL_0024: ;
        l1 = s3_0;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v13 = ref toPos;
        ref __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v14 = ref fromPos;
        __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v15 = OpenRA.WPos.op_Subtraction(ref v13, ref v14);
        l2 = v15;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v16 = ref l2;
        long v17 = __cil_memberref_call_0A00027C(ref v16);
        if (v17 != 0) {
            goto IL_0040;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        global::OpenRA.Mods.Common.Traits.Mobile v18 = this;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v19 = __cil_direct_06001705(v18);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae e4_6_0 = v19;
        s6_0 = e4_6_0;
        goto IL_0047;
        IL_0040: ;
        ref __cil_value_2b607768eb75a07650dd68fe00aee50feef8ce11 v20 = ref l2;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v21 = __cil_memberref_call_0A000222(ref v20);
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae e5_6_0 = v21;
        s6_0 = e5_6_0;
        goto IL_0047;
        IL_0047: ;
        l3 = s6_0;
        __cil_type_01000025 v22 = self;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v23 = fromPos;
        __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v24 = toPos;
        int v25 = l1;
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v26 = l3;
        __cil_value_877f2d9f1d5ae9ff8420452e071399208150ae77 v27 = __cil_value_newobj_0A001462(v26);
        global::OpenRA.Mods.Common.Activities.Drag v28 = __cil_newobj_060023AB(v22, v23, v24, v25, v27);
        return v28;
    }

    private System.Nullable<OpenRA.CPos> ClosestGroundCell()
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 8
        // .initlocals true
        // .code-bytes IL_0000: [12, 00, 02, 28, 13, 17, 00, 06, 0C, 12, 02, 28, 94, 07, 00, 0A, 02, 28, 13, 17, 00, 06, 0C, 12]
        // .code-bytes IL_0018: [02, 28, 95, 07, 00, 0A, 28, 6D, 06, 00, 0A, 02, 06, 14, 19, 28, 2B, 17, 00, 06, 2C, 07, 06, 73]
        // .code-bytes IL_0030: [B4, 06, 00, 0A, 2A, 02, 28, 0F, 17, 00, 06, 02, 7B, 31, 13, 00, 04, 17, 8D, 2A, 00, 00, 01, 25]
        // .code-bytes IL_0048: [16, 02, 7B, 31, 13, 00, 04, 6F, 5B, 01, 00, 0A, A4, 2A, 00, 00, 01, 02, FE, 06, 5C, 17, 00, 06]
        // .code-bytes IL_0060: [73, E7, 07, 00, 0A, 19, 14, 14, 17, 6F, 10, 20, 00, 06, 0B, 07, 6F, A8, 02, 00, 0A, 16, 31, 0D]
        // .code-bytes IL_0078: [07, 16, 6F, EC, 11, 00, 0A, 73, B4, 06, 00, 0A, 2A, 12, 03, FE, 15, 03, 03, 00, 1B, 09, 2A]
        // .local [0] valuetype [OpenRA.Game]OpenRA.CPos
        // .local [1] class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.CPos>
        // .local [2] valuetype [OpenRA.Game]OpenRA.CPos
        // .local [3] valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.CPos>
        // IL_0000: ldloca.s 0
        // IL_0002: ldarg.0 0
        // IL_0003: call 0x06001713 OpenRA.Mods.Common.Traits.Mobile::get_TopLeft
        // IL_0008: stloc.2 2
        // IL_0009: ldloca.s 2
        // IL_000B: call 0x0A000794 [OpenRA.Game]OpenRA.CPos::get_X
        // IL_0010: ldarg.0 0
        // IL_0011: call 0x06001713 OpenRA.Mods.Common.Traits.Mobile::get_TopLeft
        // IL_0016: stloc.2 2
        // IL_0017: ldloca.s 2
        // IL_0019: call 0x0A000795 [OpenRA.Game]OpenRA.CPos::get_Y
        // IL_001E: call 0x0A00066D [OpenRA.Game]OpenRA.CPos::.ctor
        // IL_0023: ldarg.0 0
        // IL_0024: ldloc.0 0
        // IL_0025: ldnull 
        // IL_0026: ldc.i4.3 3
        // IL_0027: call 0x0600172B OpenRA.Mods.Common.Traits.Mobile::CanEnterCell
        // IL_002C: brfalse.s IL_0035
        // IL_002E: ldloc.0 0
        // IL_002F: newobj 0x0A0006B4 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.CPos>::.ctor
        // IL_0034: ret 
        // IL_0035: ldarg.0 0
        // IL_0036: call 0x0600170F OpenRA.Mods.Common.Traits.Mobile::get_PathFinder
        // IL_003B: ldarg.0 0
        // IL_003C: ldfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_0041: ldc.i4.1 1
        // IL_0042: newarr 0x0100002A [OpenRA.Game]OpenRA.CPos
        // IL_0047: dup 
        // IL_0048: ldc.i4.0 0
        // IL_0049: ldarg.0 0
        // IL_004A: ldfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_004F: callvirt 0x0A00015B [OpenRA.Game]OpenRA.Actor::get_Location
        // IL_0054: stelem 0x0100002A [OpenRA.Game]OpenRA.CPos
        // IL_0059: ldarg.0 0
        // IL_005A: ldftn 0x0600175C OpenRA.Mods.Common.Traits.Mobile::<ClosestGroundCell>b__116_0
        // IL_0060: newobj 0x0A0007E7 class [System.Runtime]System.Func`2<valuetype [OpenRA.Game]OpenRA.CPos, bool>::.ctor
        // IL_0065: ldc.i4.3 3
        // IL_0066: ldnull 
        // IL_0067: ldnull 
        // IL_0068: ldc.i4.1 1
        // IL_0069: callvirt 0x06002010 OpenRA.Mods.Common.Traits.IPathFinder::FindPathToTargetCellByPredicate
        // IL_006E: stloc.1 1
        // IL_006F: ldloc.1 1
        // IL_0070: callvirt 0x0A0002A8 class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.CPos>::get_Count
        // IL_0075: ldc.i4.0 0
        // IL_0076: ble.s IL_0085
        // IL_0078: ldloc.1 1
        // IL_0079: ldc.i4.0 0
        // IL_007A: callvirt 0x0A0011EC class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.CPos>::get_Item
        // IL_007F: newobj 0x0A0006B4 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.CPos>::.ctor
        // IL_0084: ret 
        // IL_0085: ldloca.s 3
        // IL_0087: initobj 0x1B000303 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.CPos>
        // IL_008D: ldloc.3 3
        // IL_008E: ret 
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494163746F7250726576696577496E69744D6F6469666965722E4D6F646966794163746F7250726576696577496E6974(OpenRA.Actor self, OpenRA.Primitives.TypeDictionary inits)
    {
        // structural signature __cil_ref_2101340a7cf04e0a72d3ac50eec9e2a858dbdf30 bytes=151280DD011180CD: class [System.Runtime]System.Func`1<valuetype [OpenRA.Game]OpenRA.WAngle>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(__cil_callvirt_2B000478(inits));
        if (v1 != 0) {
            goto IL_0027;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        int v3 = __cil_bool_load(__cil_callvirt_2B000479(inits));
        if (v3 != 0) {
            goto IL_0027;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        nint v6 = __cil_ldftn_0600175D;
        __cil_ref_2101340a7cf04e0a72d3ac50eec9e2a858dbdf30 v7 = __cil_newobj_0A0002AE(this, v6);
        global::OpenRA.Mods.Common.DynamicFacingInit v8 = __cil_newobj_0600008E(v7);
        inits.Add(((object)(v8)));
        IL_0027: ;
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E4944656174684163746F72496E69744D6F6469666965722E4D6F6469667944656174684163746F72496E6974(OpenRA.Actor self, OpenRA.Primitives.TypeDictionary init)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x020006A1 alias=__cil_enum_020006A1 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@BlockedByActor; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // Exact call 0x06001705 kept: direct virtual this accessor needs exact call notation.
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v2 = __cil_direct_06001705(this);
        global::OpenRA.Mods.Common.FacingInit v3 = __cil_newobj_0600008B(v2);
        init.Add(((object)(v3)));
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v6 = ((OpenRA.Actor)self).Location;
        int v9 = __cil_bool_load(__cil_direct_0600172B(this, v6, self, unchecked((__cil_enum_020006A1)(2))));
        if (v9 == 0) {
            goto IL_0038;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v13 = ((OpenRA.Actor)self).Location;
        int v14 = __cil_direct_0600173F(this, v13);
        global::OpenRA.Mods.Common.Traits.HuskSpeedInit v15 = __cil_newobj_0600166B(v14);
        init.Add(((object)(v15)));
        IL_0038: ;
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F746966794265636F6D696E6749646C652E4F6E4265636F6D696E6749646C65(OpenRA.Actor self)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_2a38231b7620144b7e2926345dd445b782449779 bytes=15118141011180A9: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.CPos>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_23a63c8143d1ed2a653dd00c1e5916b2d69027f2 bytes=1D1299D8: class OpenRA.Mods.Common.Traits.ICustomMovementLayer[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        OpenRA.Mods.Common.Traits.ICustomMovementLayer l0 = default;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 l1 = default;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l2 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 l3 = default;
        IL_0000: ;
        __cil_type_01000025 v0 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v1 = ((OpenRA.Actor)v0).Location;
        l2 = v1;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v2 = ref l2;
        int v3 = unchecked((int)(__cil_memberref_call_0A00021B(ref v2)));
        if (v3 != 0) {
            goto IL_0042;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        global::OpenRA.Mods.Common.Traits.Mobile v4 = this;
        global::OpenRA.Mods.Common.Traits.Locomotor v5 = __cil_direct_0600170D(v4);
        __cil_type_01000025 v6 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v7 = ((OpenRA.Actor)v6).Location;
        int v8 = __cil_bool_load(__cil_callvirt_06001DA1(v5, v7));
        if (v8 != 0) {
            goto IL_0041;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        __cil_type_01000025 v9 = self;
        global::OpenRA.Mods.Common.Traits.Mobile v10 = this;
        __cil_type_01000025 v11 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v12 = ((OpenRA.Actor)v11).Location;
        int v13 = 0;
        int v14 = 1;
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v15 = ref l3;
        v15 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v16 = l3;
        __cil_type_0100010F v17 = __cil_direct_06001733(v10, v12, v13, ((__cil_type_01000025)(null)), __cil_bool_store(v14), v16);
        v9.QueueActivity(v17);
        goto IL_0041;
        IL_0041: ;
        return;
        IL_0042: ;
        __cil_type_01000025 v18 = self;
        __cil_type_0100002D v19 = v18.World;
        __cil_ref_23a63c8143d1ed2a653dd00c1e5916b2d69027f2 v20 = OpenRA.Mods.Common.Traits.ActorMapWorldExts.GetCustomMovementLayers(v19);
        __cil_type_01000025 v21 = self;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v22 = ((OpenRA.Actor)v21).Location;
        l2 = v22;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v23 = ref l2;
        int v24 = unchecked((int)(__cil_memberref_call_0A00021B(ref v23)));
        global::OpenRA.Mods.Common.Traits.ICustomMovementLayer v25 = v20[v24];
        l0 = v25;
        global::OpenRA.Mods.Common.Traits.ICustomMovementLayer v26 = l0;
        int v27 = __cil_bool_load(__cil_callvirt_06001FAD(v26));
        if (v27 != 0) {
            goto IL_0066;
        } else {
            goto IL_0065;
        }
        IL_0065: ;
        return;
        IL_0066: ;
        global::OpenRA.Mods.Common.Traits.Mobile v28 = this;
        __cil_value_2a38231b7620144b7e2926345dd445b782449779 v29 = __cil_direct_06001745(v28);
        l1 = v29;
        ref __cil_value_2a38231b7620144b7e2926345dd445b782449779 v30 = ref l1;
        int v31 = __cil_bool_load(__cil_value_call_0A0006AE(ref v30));
        if (v31 == 0) {
            goto IL_0095;
        } else {
            goto IL_0076;
        }
        IL_0076: ;
        __cil_type_01000025 v32 = self;
        global::OpenRA.Mods.Common.Traits.Mobile v33 = this;
        ref __cil_value_2a38231b7620144b7e2926345dd445b782449779 v34 = ref l1;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v35 = __cil_value_call_0A0006AF(ref v34);
        int v36 = 0;
        int v37 = 0;
        ref __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v38 = ref l3;
        v38 = default;
        __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v39 = l3;
        __cil_type_0100010F v40 = __cil_direct_06001733(v33, v35, v36, ((__cil_type_01000025)(null)), __cil_bool_store(v37), v39);
        v32.QueueActivity(v40);
        goto IL_0095;
        IL_0095: ;
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494E6F74696679426C6F636B696E674D6F76652E4F6E4E6F74696679426C6F636B696E674D6F7665(OpenRA.Actor self, OpenRA.Actor blocking)
    {
        int v2 = __cil_bool_load(OpenRA.Mods.Common.ActorExts.AppearsFriendlyTo(self, blocking));
        if (v2 != 0) {
            goto IL_000A;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        return;
        IL_000A: ;
        int v4 = __cil_bool_load(((OpenRA.Actor)self).IsIdle);
        if (v4 == 0) {
            goto IL_0020;
        } else {
            goto IL_0012;
        }
        IL_0012: ;
        global::OpenRA.Mods.Common.Traits.Nudge v8 = __cil_newobj_06000EFD(blocking);
        self.QueueActivity(__cil_bool_store(0), ((__cil_type_0100010F)(v8)));
        return;
        IL_0020: ;
        this.IsBlocking = __cil_bool_store(1);
        return;
    }

    public override System.Collections.Generic.IEnumerable<OpenRA.Traits.VariableObserver> GetVariableObservers()
    {
        // structural signature __cil_ref_01e870d823b7fa5ebe8ad38c5e4fee9884ac243a bytes=151280A1011187C5: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v1 = __cil_newobj_06003F0B(-2);
        v1.__il_field_0400347F = this;
        return v1;
    }

    private void RequireForceMoveConditionChanged(OpenRA.Actor self, System.Collections.Generic.IReadOnlyDictionary<string, int> conditions)
    {
        // structural signature __cil_ref_beeddf9dea012b3eb1ea23704adc8273e644e143 bytes=1512833D020E08: class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.MobileInfo v2 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        __cil_type_010001EB v3 = v2.RequireForceMoveCondition;
        int v5 = __cil_bool_load(v3.Evaluate(conditions));
        this.requireForceMove = __cil_bool_store(v5);
        return;
    }

    private void ImmovableConditionChanged(OpenRA.Actor self, System.Collections.Generic.IReadOnlyDictionary<string, int> conditions)
    {
        // structural signature __cil_ref_beeddf9dea012b3eb1ea23704adc8273e644e143 bytes=1512833D020E08: class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        int v1 = __cil_bool_load(this.IsImmovable);
        l0 = __cil_bool_store(v1);
        global::OpenRA.Mods.Common.Traits.MobileInfo v4 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        __cil_type_010001EB v5 = v4.ImmovableCondition;
        int v7 = __cil_bool_load(v5.Evaluate(conditions));
        this.IsImmovable = __cil_bool_store(v7);
        int v8 = __cil_bool_load(l0);
        int v10 = __cil_bool_load(this.IsImmovable);
        if (v8 == v10) {
            goto IL_003D;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        __cil_type_0100002D v12 = self.World;
        __cil_type_01000130 v13 = v12.ActorMap;
        __cil_type_010001EE v15 = ((OpenRA.Actor)self).OccupiesSpace;
        __cil_callvirt_0A001428(v13, v15);
        IL_003D: ;
        return;
    }

    private virtual System.Collections.Generic.IEnumerable<OpenRA.Traits.IOrderTargeter> __name_4F70656E52412E5472616974732E4949737375654F726465722E6765745F4F7264657273()
    {
        // structural signature __cil_ref_d8a04e490f85e1e44ceb20f3de6c2ef1e488e08d bytes=151280A1011284ED: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.IOrderTargeter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4F70656E52412D5472616974732D4949737375654F726465722D6765745F4F72646572733E645F5F313235 v1 = __cil_newobj_06003F14(-2);
        v1.__il_field_04003484 = this;
        return v1;
    }

    private virtual OpenRA.Order __name_4F70656E52412E5472616974732E4949737375654F726465722E49737375654F72646572(OpenRA.Actor self, OpenRA.Traits.IOrderTargeter order, ref OpenRA.Traits.Target target, bool queued)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [04, 75, DC, 0D, 00, 02, 2C, 11, 72, 7B, FE, 01, 70, 03, 05, 0E, 04, 14, 14, 73, E2, 10, 00, 0A]
        // .code-bytes IL_0018: [2A, 14, 2A]
        // IL_0000: ldarg.2 2
        // IL_0001: isinst 0x02000DDC OpenRA.Mods.Common.Traits.Mobile/MoveOrderTargeter
        // IL_0006: brfalse.s IL_0019
        // IL_0008: ldstr 0x7001FE7B [77, 111, 118, 101] utf16-bytes=[4D, 00, 6F, 00, 76, 00, 65, 00] terminal-flag=Some(0)
        // IL_000D: ldarg.1 1
        // IL_000E: ldarg.3 3
        // IL_000F: ldarg.s 4
        // IL_0011: ldnull 
        // IL_0012: ldnull 
        // IL_0013: newobj 0x0A0010E2 [OpenRA.Game]OpenRA.Order::.ctor
        // IL_0018: ret 
        // IL_0019: ldnull 
        // IL_001A: ret 
    }

    private virtual void __name_4F70656E52412E5472616974732E495265736F6C76654F726465722E5265736F6C76654F72646572(OpenRA.Actor self, OpenRA.Order order)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 9
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, FB, 06, 00, 0A, 2C, 01, 2A, 04, 7B, 5D, 08, 00, 0A, 72, 7B, FE, 01, 70, 28, BD, 02, 00]
        // .code-bytes IL_0018: [0A, 39, 9E, 00, 00, 00, 04, 6F, 7F, 0D, 00, 0A, 03, 28, E1, 06, 00, 0A, 2D, 01, 2A, 03, 7B, 59]
        // .code-bytes IL_0030: [01, 00, 0A, 7B, 5A, 01, 00, 0A, 02, 7B, 31, 13, 00, 04, 7B, 59, 01, 00, 0A, 7B, 5A, 01, 00, 0A]
        // .code-bytes IL_0048: [04, 6F, 7F, 0D, 00, 0A, 28, 7F, 02, 00, 0A, 6F, 90, 02, 00, 0A, 6F, 36, 11, 00, 0A, 0A, 02, 7B]
        // .code-bytes IL_0060: [FB, 10, 00, 0A, 6F, EE, 16, 00, 06, 7B, 8A, 18, 00, 04, 2D, 14, 03, 6F, 60, 01, 00, 0A, 7B, 3F]
        // .code-bytes IL_0078: [08, 00, 0A, 06, 6F, 04, 02, 00, 0A, 2D, 01, 2A, 03, 04, 7B, 37, 11, 00, 0A, 02, 03, 06, 1E, 28]
        // .code-bytes IL_0090: [82, 02, 00, 0A, 14, 17, 02, 7B, FB, 10, 00, 0A, 7B, 26, 13, 00, 04, 73, A4, 06, 00, 0A, 73, BB]
        // .code-bytes IL_00A8: [23, 00, 06, 28, 32, 17, 00, 06, 6F, FA, 06, 00, 0A, 03, 28, A2, 1A, 00, 06, 2A, 04, 7B, 5D, 08]
        // .code-bytes IL_00C0: [00, 0A, 72, BF, FE, 01, 70, 28, BD, 02, 00, 0A, 2C, 07, 03, 6F, 81, 02, 00, 0A, 2A, 04, 7B, 5D]
        // .code-bytes IL_00D8: [08, 00, 0A, 72, C9, FE, 01, 70, 28, BD, 02, 00, 0A, 2C, 18, 03, 04, 7B, 37, 11, 00, 0A, 03, 73]
        // .code-bytes IL_00F0: [FD, 0E, 00, 06, 6F, FA, 06, 00, 0A, 03, 28, A2, 1A, 00, 06, 2A]
        // .local [0] valuetype [OpenRA.Game]OpenRA.CPos
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x0A0006FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::get_IsTraitDisabled
        // IL_0006: brfalse.s IL_0009
        // IL_0008: ret 
        // IL_0009: ldarg.2 2
        // IL_000A: ldfld 0x0A00085D [OpenRA.Game]OpenRA.Order::OrderString
        // IL_000F: ldstr 0x7001FE7B [77, 111, 118, 101] utf16-bytes=[4D, 00, 6F, 00, 76, 00, 65, 00] terminal-flag=Some(0)
        // IL_0014: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0019: brfalse IL_00BC
        // IL_001E: ldarg.2 2
        // IL_001F: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_0024: ldarg.1 1
        // IL_0025: call 0x0A0006E1 [OpenRA.Game]OpenRA.Traits.Target::IsValidFor
        // IL_002A: brtrue.s IL_002D
        // IL_002C: ret 
        // IL_002D: ldarg.1 1
        // IL_002E: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0033: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0038: ldarg.0 0
        // IL_0039: ldfld 0x04001331 OpenRA.Mods.Common.Traits.Mobile::self
        // IL_003E: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_0043: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0048: ldarg.2 2
        // IL_0049: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_004E: call 0x0A00027F [OpenRA.Game]OpenRA.Traits.Target::get_CenterPosition
        // IL_0053: callvirt 0x0A000290 [OpenRA.Game]OpenRA.Map::CellContaining
        // IL_0058: callvirt 0x0A001136 [OpenRA.Game]OpenRA.Map::Clamp
        // IL_005D: stloc.0 0
        // IL_005E: ldarg.0 0
        // IL_005F: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
        // IL_0064: callvirt 0x060016EE OpenRA.Mods.Common.Traits.MobileInfo::get_LocomotorInfo
        // IL_0069: ldfld 0x0400188A OpenRA.Mods.Common.Traits.LocomotorInfo::MoveIntoShroud
        // IL_006E: brtrue.s IL_0084
        // IL_0070: ldarg.1 1
        // IL_0071: callvirt 0x0A000160 [OpenRA.Game]OpenRA.Actor::get_Owner
        // IL_0076: ldfld 0x0A00083F [OpenRA.Game]OpenRA.Player::Shroud
        // IL_007B: ldloc.0 0
        // IL_007C: callvirt 0x0A000204 [OpenRA.Game]OpenRA.Traits.Shroud::IsExplored
        // IL_0081: brtrue.s IL_0084
        // IL_0083: ret 
        // IL_0084: ldarg.1 1
        // IL_0085: ldarg.2 2
        // IL_0086: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_008B: ldarg.0 0
        // IL_008C: ldarg.1 1
        // IL_008D: ldloc.0 0
        // IL_008E: ldc.i4.8 8
        // IL_008F: call 0x0A000282 [OpenRA.Game]OpenRA.WDist::FromCells
        // IL_0094: ldnull 
        // IL_0095: ldc.i4.1 1
        // IL_0096: ldarg.0 0
        // IL_0097: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
        // IL_009C: ldfld 0x04001326 OpenRA.Mods.Common.Traits.MobileInfo::TargetLineColor
        // IL_00A1: newobj 0x0A0006A4 valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>::.ctor
        // IL_00A6: newobj 0x060023BB OpenRA.Mods.Common.Activities.Move::.ctor
        // IL_00AB: call 0x06001732 OpenRA.Mods.Common.Traits.Mobile::WrapMove
        // IL_00B0: callvirt 0x0A0006FA [OpenRA.Game]OpenRA.Actor::QueueActivity
        // IL_00B5: ldarg.1 1
        // IL_00B6: call 0x06001AA2 OpenRA.Mods.Common.Traits.LineTargetExts::ShowTargetLines
        // IL_00BB: ret 
        // IL_00BC: ldarg.2 2
        // IL_00BD: ldfld 0x0A00085D [OpenRA.Game]OpenRA.Order::OrderString
        // IL_00C2: ldstr 0x7001FEBF [83, 116, 111, 112] utf16-bytes=[53, 00, 74, 00, 6F, 00, 70, 00] terminal-flag=Some(0)
        // IL_00C7: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_00CC: brfalse.s IL_00D5
        // IL_00CE: ldarg.1 1
        // IL_00CF: callvirt 0x0A000281 [OpenRA.Game]OpenRA.Actor::CancelActivity
        // IL_00D4: ret 
        // IL_00D5: ldarg.2 2
        // IL_00D6: ldfld 0x0A00085D [OpenRA.Game]OpenRA.Order::OrderString
        // IL_00DB: ldstr 0x7001FEC9 [83, 99, 97, 116, 116, 101, 114] utf16-bytes=[53, 00, 63, 00, 61, 00, 74, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00E0: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_00E5: brfalse.s IL_00FF
        // IL_00E7: ldarg.1 1
        // IL_00E8: ldarg.2 2
        // IL_00E9: ldfld 0x0A001137 [OpenRA.Game]OpenRA.Order::Queued
        // IL_00EE: ldarg.1 1
        // IL_00EF: newobj 0x06000EFD OpenRA.Mods.Common.Traits.Nudge::.ctor
        // IL_00F4: callvirt 0x0A0006FA [OpenRA.Game]OpenRA.Actor::QueueActivity
        // IL_00F9: ldarg.1 1
        // IL_00FA: call 0x06001AA2 OpenRA.Mods.Common.Traits.LineTargetExts::ShowTargetLines
        // IL_00FF: ret 
    }

    private virtual string __name_4F70656E52412E5472616974732E494F72646572566F6963652E566F696365506872617365466F724F72646572(OpenRA.Actor self, OpenRA.Order order)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [02, 28, FB, 06, 00, 0A, 2C, 02, 14, 2A, 04, 7B, 5D, 08, 00, 0A, 0A, 06, 72, 7B, FE, 01, 70, 28]
        // .code-bytes IL_0018: [BD, 02, 00, 0A, 2D, 1C, 06, 72, C9, FE, 01, 70, 28, BD, 02, 00, 0A, 2D, 6B, 06, 72, BF, FE, 01]
        // .code-bytes IL_0030: [70, 28, BD, 02, 00, 0A, 2D, 5E, 2B, 68, 02, 7B, FB, 10, 00, 0A, 6F, EE, 16, 00, 06, 7B, 8A, 18]
        // .code-bytes IL_0048: [00, 04, 2D, 3E, 04, 6F, 7F, 0D, 00, 0A, 28, 08, 02, 00, 0A, 2C, 31, 03, 7B, 59, 01, 00, 0A, 7B]
        // .code-bytes IL_0060: [5A, 01, 00, 0A, 04, 6F, 7F, 0D, 00, 0A, 28, 7F, 02, 00, 0A, 6F, 90, 02, 00, 0A, 0B, 03, 6F, 60]
        // .code-bytes IL_0078: [01, 00, 0A, 7B, 3F, 08, 00, 0A, 07, 6F, 04, 02, 00, 0A, 2D, 02, 14, 2A, 02, 7B, FB, 10, 00, 0A]
        // .code-bytes IL_0090: [7B, 25, 13, 00, 04, 2A, 02, 7B, FB, 10, 00, 0A, 7B, 25, 13, 00, 04, 2A, 14, 2A]
        // .local [0] string
        // .local [1] valuetype [OpenRA.Game]OpenRA.CPos
        // IL_0000: ldarg.0 0
        // IL_0001: call 0x0A0006FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::get_IsTraitDisabled
        // IL_0006: brfalse.s IL_000A
        // IL_0008: ldnull 
        // IL_0009: ret 
        // IL_000A: ldarg.2 2
        // IL_000B: ldfld 0x0A00085D [OpenRA.Game]OpenRA.Order::OrderString
        // IL_0010: stloc.0 0
        // IL_0011: ldloc.0 0
        // IL_0012: ldstr 0x7001FE7B [77, 111, 118, 101] utf16-bytes=[4D, 00, 6F, 00, 76, 00, 65, 00] terminal-flag=Some(0)
        // IL_0017: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_001C: brtrue.s IL_003A
        // IL_001E: ldloc.0 0
        // IL_001F: ldstr 0x7001FEC9 [83, 99, 97, 116, 116, 101, 114] utf16-bytes=[53, 00, 63, 00, 61, 00, 74, 00, 74, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0024: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0029: brtrue.s IL_0096
        // IL_002B: ldloc.0 0
        // IL_002C: ldstr 0x7001FEBF [83, 116, 111, 112] utf16-bytes=[53, 00, 74, 00, 6F, 00, 70, 00] terminal-flag=Some(0)
        // IL_0031: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0036: brtrue.s IL_0096
        // IL_0038: br.s IL_00A2
        // IL_003A: ldarg.0 0
        // IL_003B: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
        // IL_0040: callvirt 0x060016EE OpenRA.Mods.Common.Traits.MobileInfo::get_LocomotorInfo
        // IL_0045: ldfld 0x0400188A OpenRA.Mods.Common.Traits.LocomotorInfo::MoveIntoShroud
        // IL_004A: brtrue.s IL_008A
        // IL_004C: ldarg.2 2
        // IL_004D: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_0052: call 0x0A000208 [OpenRA.Game]OpenRA.Traits.Target::get_Type
        // IL_0057: brfalse.s IL_008A
        // IL_0059: ldarg.1 1
        // IL_005A: ldfld 0x0A000159 [OpenRA.Game]OpenRA.Actor::World
        // IL_005F: ldfld 0x0A00015A [OpenRA.Game]OpenRA.World::Map
        // IL_0064: ldarg.2 2
        // IL_0065: callvirt 0x0A000D7F [OpenRA.Game]OpenRA.Order::get_Target
        // IL_006A: call 0x0A00027F [OpenRA.Game]OpenRA.Traits.Target::get_CenterPosition
        // IL_006F: callvirt 0x0A000290 [OpenRA.Game]OpenRA.Map::CellContaining
        // IL_0074: stloc.1 1
        // IL_0075: ldarg.1 1
        // IL_0076: callvirt 0x0A000160 [OpenRA.Game]OpenRA.Actor::get_Owner
        // IL_007B: ldfld 0x0A00083F [OpenRA.Game]OpenRA.Player::Shroud
        // IL_0080: ldloc.1 1
        // IL_0081: callvirt 0x0A000204 [OpenRA.Game]OpenRA.Traits.Shroud::IsExplored
        // IL_0086: brtrue.s IL_008A
        // IL_0088: ldnull 
        // IL_0089: ret 
        // IL_008A: ldarg.0 0
        // IL_008B: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
        // IL_0090: ldfld 0x04001325 OpenRA.Mods.Common.Traits.MobileInfo::Voice
        // IL_0095: ret 
        // IL_0096: ldarg.0 0
        // IL_0097: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
        // IL_009C: ldfld 0x04001325 OpenRA.Mods.Common.Traits.MobileInfo::Voice
        // IL_00A1: ret 
        // IL_00A2: ldnull 
        // IL_00A3: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E5472616974732E494372656174696F6E41637469766974792E4765744372656174696F6E4163746976697479()
    {
        // structural signature __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba bytes=1D1180A9: valuetype [OpenRA.Game]OpenRA.CPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000025 s4_0 = default;
        int s4_1 = default;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba s4_2 = default;
        __cil_type_01000025 s5_0 = default;
        int s5_1 = default;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba s5_2 = default;
        __cil_type_01000025 s6_0 = default;
        int s6_1 = default;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba s6_2 = default;
        OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity s6_3 = default;
        int v1 = __cil_bool_load(this.returnToCellOnCreation);
        if (v1 != 0) {
            goto IL_0019;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v3 = this.creationRallypoint;
        if (v3 is not null) {
            goto IL_0019;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        int v5 = this.creationActivityDelay;
        if (v5 <= 0) {
            return null;
        } else {
            goto IL_0019;
        }
        IL_0019: ;
        __cil_type_01000025 v8 = this.self;
        int v10 = this.creationActivityDelay;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v12 = this.creationRallypoint;
        int v14 = __cil_bool_load(this.returnToCellOnCreation);
        if (v14 != 0) {
            __cil_type_01000025 e3_5_0 = v8;
            int e3_5_1 = v10;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba e3_5_2 = v12;
            s5_0 = e3_5_0;
            s5_1 = e3_5_1;
            s5_2 = e3_5_2;
            goto IL_0036;
        } else {
            __cil_type_01000025 e3_4_0 = v8;
            int e3_4_1 = v10;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba e3_4_2 = v12;
            s4_0 = e3_4_0;
            s4_1 = e3_4_1;
            s4_2 = e3_4_2;
            goto IL_0033;
        }
        IL_0033: ;
        __cil_type_01000025 e4_6_0 = s4_0;
        int e4_6_1 = s4_1;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba e4_6_2 = s4_2;
        OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity e4_6_3 = null;
        s6_0 = e4_6_0;
        s6_1 = e4_6_1;
        s6_2 = e4_6_2;
        s6_3 = e4_6_3;
        goto IL_004D;
        IL_0036: ;
        __cil_type_01000025 v16 = this.self;
        int v18 = this.creationActivityDelay;
        int v20 = __cil_bool_load(this.returnToCellOnCreationRecalculateSubCell);
        global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity v21 = __cil_newobj_06003EEE(v16, v18, v20);
        __cil_type_01000025 e5_6_0 = s5_0;
        int e5_6_1 = s5_1;
        __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba e5_6_2 = s5_2;
        OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity e5_6_3 = v21;
        s6_0 = e5_6_0;
        s6_1 = e5_6_1;
        s6_2 = e5_6_2;
        s6_3 = e5_6_3;
        IL_004D: ;
        global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity v22 = __cil_newobj_06003EF1(s6_0, s6_1, s6_2, s6_3);
        return v22;
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F766557697468696E52616E6765(ref OpenRA.Traits.Target target, OpenRA.WDist range, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 28, 34, 17, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: call 0x06001734 OpenRA.Mods.Common.Traits.Mobile::MoveWithinRange
        // IL_000B: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F766557697468696E52616E6765(ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 28, 35, 17, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: ldarg.s 5
        // IL_0008: call 0x06001735 OpenRA.Mods.Common.Traits.Mobile::MoveWithinRange
        // IL_000D: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F7665466F6C6C6F77(OpenRA.Actor self, ref OpenRA.Traits.Target target, OpenRA.WDist minRange, OpenRA.WDist maxRange, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 0E, 06, 28, 36, 17, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: ldarg.s 5
        // IL_0008: ldarg.s 6
        // IL_000A: call 0x06001736 OpenRA.Mods.Common.Traits.Mobile::MoveFollow
        // IL_000F: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F7665546F546172676574(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Nullable<OpenRA.WPos> initialTargetPosition = null, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 28, 38, 17, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: call 0x06001738 OpenRA.Mods.Common.Traits.Mobile::MoveToTarget
        // IL_000B: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F7665496E746F546172676574(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 28, 39, 17, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: call 0x06001739 OpenRA.Mods.Common.Traits.Mobile::MoveIntoTarget
        // IL_0008: ret 
    }

    private virtual OpenRA.Activities.Activity __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E4D6F76654F6E746F546172676574(OpenRA.Actor self, ref OpenRA.Traits.Target target, ref OpenRA.WVec offset, System.Nullable<OpenRA.WAngle> facing, System.Nullable<OpenRA.Primitives.Color> targetLineColor = null)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 28, 3A, 17, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: ldarg.3 3
        // IL_0004: ldarg.s 4
        // IL_0006: ldarg.s 5
        // IL_0008: call 0x0600173A OpenRA.Mods.Common.Traits.Mobile::MoveOntoTarget
        // IL_000D: ret 
    }

    private virtual bool __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494D6F76652E43616E456E7465725461726765744E6F77(OpenRA.Actor self, ref OpenRA.Traits.Target target)
    {
        // IL fallback: byref/modified parameter needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [02, 03, 04, 28, 3E, 17, 00, 06, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldarg.1 1
        // IL_0002: ldarg.2 2
        // IL_0003: call 0x0600173E OpenRA.Mods.Common.Traits.Mobile::CanEnterTargetNow
        // IL_0008: ret 
    }

    // Metadata name: <.ctor>b__67_0
    private System.Collections.Generic.IEnumerable<int> CtorLambda67_0()
    {
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_723ccaa1cf5b61a0b7e2292717be84d90587b5a0 bytes=151280A1011299A0: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ISpeedModifier>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 bytes=1D1299A0: class OpenRA.Mods.Common.Traits.ISpeedModifier[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 bytes=15128121021299A008: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ISpeedModifier, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 s1_0 = default;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 s1_1 = default;
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 s2_0 = default;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 s2_1 = default;
        __cil_type_01000025 v1 = this.self;
        __cil_ref_723ccaa1cf5b61a0b7e2292717be84d90587b5a0 v2 = __cil_callvirt_2B000468(v1);
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 v3 = __cil_methodspec_call_2B000469(v2);
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 v4 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003474;
        if (v4 is not null) {
            __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 e0_2_0 = v3;
            __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 e0_2_1 = v4;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_002F;
        } else {
            __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 e0_1_0 = v3;
            __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 e0_1_1 = v4;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_0018;
        }
        IL_0018: ;
        global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63 v5 = OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003473;
        nint v6 = __cil_ldftn_06003F00;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 v7 = __cil_newobj_0A00111B(v5, v6);
        OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003474 = v7;
        __cil_ref_bb1ce1f3ad50592f20e24d52363e8957c3314f27 e1_2_0 = s1_0;
        __cil_ref_f123132d2a980fc162e1fc1c9f8fd16f86cb0884 e1_2_1 = v7;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        IL_002F: ;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v8 = __cil_methodspec_call_2B00046A(((__cil_ref_723ccaa1cf5b61a0b7e2292717be84d90587b5a0)(s2_0)), s2_1);
        return v8;
    }

    // Metadata name: <Created>b__68_0
    private bool CreatedLambda68_0(OpenRA.Mods.Common.Traits.Locomotor l)
    {
        global::OpenRA.Mods.Common.Traits.LocomotorInfo v1 = l.Info;
        string v2 = v1.Name;
        global::OpenRA.Mods.Common.Traits.MobileInfo v4 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)this).Info;
        string v5 = v4.Locomotor;
        return System.String.op_Equality(v2, v5);
    }

    // Metadata name: <GetAdjacentCell>b__77_0
    private System.Collections.Generic.IEnumerable<OpenRA.Actor> GetAdjacentCellLambda77_0(OpenRA.CPos c)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000025 v1 = this.self;
        __cil_type_0100002D v2 = v1.World;
        __cil_type_01000130 v3 = v2.ActorMap;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v5 = __cil_callvirt_0A000169(v3, c);
        nint v6 = __cil_ldftn_06001720;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v7 = __cil_newobj_0A00019A(null, v6);
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v8 = __cil_methodspec_call_2B000009(v5, v7);
        return v8;
    }

    // Metadata name: <ClosestGroundCell>b__116_0
    private bool ClosestGroundCellLambda116_0(OpenRA.CPos loc)
    {
        // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // enum storage token=0x020006A1 alias=__cil_enum_020006A1 underlying=int: global::@OpenRA.@Mods.@Common.@Traits.@BlockedByActor; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        IL_0000: ;
        ref __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v0 = ref loc;
        int v1 = unchecked((int)(__cil_memberref_call_0A00021B(ref v0)));
        if (v1 != 0) {
            goto IL_0013;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        global::OpenRA.Mods.Common.Traits.Mobile v2 = this;
        __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v3 = loc;
        int v4 = 3;
        int v5 = __cil_bool_load(__cil_direct_0600172B(v2, v3, ((__cil_type_01000025)(null)), unchecked((__cil_enum_020006A1)(v4))));
        return __cil_bool_store(v5);
        IL_0013: ;
        int v6 = 0;
        return __cil_bool_store(v6);
    }

    private OpenRA.WAngle __name_3C4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494163746F7250726576696577496E69744D6F6469666965722E4D6F646966794163746F7250726576696577496E69743E625F5F3131375F30()
    {
        // structural signature __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae bytes=1180CD: valuetype [OpenRA.Game]OpenRA.WAngle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // Exact call 0x06001705 kept: direct virtual this accessor needs exact call notation.
        __cil_value_4dc9b0074cc3358fbbb6a841eafae67a8806e8ae v1 = __cil_direct_06001705(this);
        return v1;
    }

    private System.Collections.Generic.IEnumerable<OpenRA.Traits.VariableObserver> __name_3C3E6E5F5F30()
    {
        // structural signature __cil_ref_01e870d823b7fa5ebe8ad38c5e4fee9884ac243a bytes=151280A1011187C5: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_01e870d823b7fa5ebe8ad38c5e4fee9884ac243a v1 = __cil_direct_0A0014E7(this);
        return v1;
    }
    // property OpenRA.Mods.Common.Traits.MovementType CurrentMovementTypes { get: get_CurrentMovementTypes; set: set_CurrentMovementTypes; }
    // property bool IsImmovable { get: get_IsImmovable; set: set_IsImmovable; }
    // property bool IsBlocking { get: get_IsBlocking; set: set_IsBlocking; }
    // property bool IsMovingBetweenCells { get: get_IsMovingBetweenCells; }
    // property OpenRA.Mods.Common.Traits.MoveResult MoveResult { get: get_MoveResult; set: set_MoveResult; }
    // property OpenRA.WAngle Facing { get: get_Facing; set: set_Facing; }
    // property OpenRA.WRot Orientation { get: get_Orientation; }
    // property OpenRA.WAngle TurnSpeed { get: get_TurnSpeed; }
    // property OpenRA.CPos FromCell { get: get_FromCell; set: set_FromCell; }
    // property OpenRA.CPos ToCell { get: get_ToCell; set: set_ToCell; }
    // property OpenRA.Mods.Common.Traits.Locomotor Locomotor { get: get_Locomotor; set: set_Locomotor; }
    // property OpenRA.Mods.Common.Traits.IPathFinder PathFinder { get: get_PathFinder; set: set_PathFinder; }
    // property OpenRA.WPos CenterPosition { get: get_CenterPosition; set: set_CenterPosition; }
    // property OpenRA.CPos TopLeft { get: get_TopLeft; }
    // property System.Collections.Generic.IEnumerable<OpenRA.Traits.IOrderTargeter> __name_4F70656E52412E5472616974732E4949737375654F726465722E4F7264657273 { get: __name_4F70656E52412E5472616974732E4949737375654F726465722E6765745F4F7264657273; }

    public class ReturnToCellActivity : OpenRA.Activities.Activity
    {
        private readonly OpenRA.Mods.Common.Traits.Mobile mobile;
        private readonly bool recalculateSubCell;
        private OpenRA.CPos cell;
        private OpenRA.Traits.SubCell subCell;
        private OpenRA.WPos pos;
        private readonly int delay;

        public ReturnToCellActivity(OpenRA.Actor self, int delay = 0, bool recalculateSubCell = false) : base()
        {
            global::OpenRA.Mods.Common.Traits.Mobile v3 = __cil_callvirt_2B000178(self);
            this.mobile = v3;
            base.IsInterruptible = __cil_bool_store(0);
            this.delay = delay;
            int v9 = __cil_bool_load(recalculateSubCell);
            this.recalculateSubCell = __cil_bool_store(v9);
            return;
        }

        protected override void OnFirstRun(OpenRA.Actor self)
        {
            // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d bytes=1181C5: valuetype [OpenRA.Game]OpenRA.WDist; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v2 = ((OpenRA.Actor)self).CenterPosition;
            this.pos = v2;
            __cil_type_0100002D v4 = self.World;
            __cil_type_01000026 v5 = v4.Map;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v7 = this.pos;
            __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v8 = v5.DistanceAboveTerrain(v7);
            __cil_value_b5c122ef7de4090fd5d30ee9b32ccd852415036d v9 = __cil_ldsfld_0A00023E();
            int v10 = __cil_bool_load(OpenRA.WDist.op_GreaterThan(v8, v9));
            if (v10 == 0) {
                goto IL_0042;
            } else {
                goto IL_002E;
            }
            IL_002E: ;
            global::OpenRA.Mods.Common.Traits.Parachutable v12 = __cil_callvirt_2B0005C6(self);
            if (v12 is null) {
                goto IL_0042;
            } else {
                goto IL_0036;
            }
            IL_0036: ;
            global::OpenRA.Mods.Common.Activities.Parachute v15 = __cil_newobj_060023EA(self);
            this.QueueChild(((__cil_type_0100010F)(v15)));
            IL_0042: ;
            return;
        }

        public override bool Tick(OpenRA.Actor self)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // enum storage token=0x02000154 alias=__cil_enum_02000154 underlying=byte: global::@OpenRA.@Traits.@SubCell; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 l0 = default;
            OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity s2_0 = default;
            OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity s3_0 = default;
            OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity s4_0 = default;
            int s4_1 = default;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v0 = __cil_newobj_06004916();
            l0 = v0;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v1 = l0;
            v1.self = self;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v4 = l0;
            __cil_type_01000025 v5 = v4.self;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v6 = ((OpenRA.Actor)v5).CenterPosition;
            this.pos = v6;
            global::OpenRA.Mods.Common.Traits.Mobile v9 = this.mobile;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v10 = __cil_callvirt_0600170B(v9);
            this.cell = v10;
            global::OpenRA.Mods.Common.Traits.Mobile v13 = this.mobile;
            int v14 = unchecked((int)(unchecked((byte)(v13.ToSubCell))));
            this.subCell = unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v14))));
            int v16 = __cil_bool_load(this.recalculateSubCell);
            if (v16 == 0) {
                goto IL_0095;
            } else {
                goto IL_0048;
            }
            IL_0048: ;
            global::OpenRA.Mods.Common.Traits.Mobile v19 = this.mobile;
            global::OpenRA.Mods.Common.Traits.MobileInfo v20 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v19).Info;
            global::OpenRA.Mods.Common.Traits.LocomotorInfo v21 = __cil_callvirt_060016EE(v20);
            int v22 = __cil_bool_load(v21.SharesCell);
            if (v22 != 0) {
                OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity e1_3_0 = this;
                s3_0 = e1_3_0;
                goto IL_0063;
            } else {
                OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity e1_2_0 = this;
                s2_0 = e1_2_0;
                goto IL_0060;
            }
            IL_0060: ;
            OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity e2_4_0 = s2_0;
            int e2_4_1 = 0;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0090;
            IL_0063: ;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v24 = l0;
            __cil_type_01000025 v25 = v24.self;
            __cil_type_0100002D v26 = v25.World;
            __cil_type_01000130 v27 = v26.ActorMap;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v29 = this.cell;
            int v31 = unchecked((int)(unchecked((byte)(this.subCell))));
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v32 = l0;
            nint v33 = __cil_ldftn_06004917;
            __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v34 = __cil_newobj_0A00019A(v32, v33);
            int v35 = unchecked((int)(unchecked((byte)(__cil_callvirt_0A00178E(v27, v29, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v31)))), v34)))));
            OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity e3_4_0 = s3_0;
            int e3_4_1 = v35;
            s4_0 = e3_4_0;
            s4_1 = e3_4_1;
            IL_0090: ;
            s4_0.subCell = unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(s4_1))));
            IL_0095: ;
            int v37 = unchecked((int)(unchecked((byte)(this.subCell))));
            if (unchecked((uint)v37) != unchecked((uint)255)) {
                goto IL_00C2;
            } else {
                goto IL_00A2;
            }
            IL_00A2: ;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v40 = l0;
            __cil_type_01000025 v41 = v40.self;
            __cil_type_0100002D v42 = v41.World;
            __cil_type_01000026 v43 = v42.Map;
            __cil_type_010000C7 v44 = v43.Grid;
            int v45 = unchecked((int)(unchecked((byte)(v44.DefaultSubCell))));
            this.subCell = unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v45))));
            IL_00C2: ;
            global::OpenRA.Mods.Common.Traits.Mobile v47 = this.mobile;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v48 = l0;
            __cil_type_01000025 v49 = v48.self;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v51 = this.cell;
            int v53 = unchecked((int)(unchecked((byte)(this.subCell))));
            __cil_callvirt_06001724(v47, v49, v51, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v53)))));
            global::OpenRA.Mods.Common.Traits.Mobile v55 = this.mobile;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v56 = l0;
            __cil_type_01000025 v57 = v56.self;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v59 = this.pos;
            __cil_callvirt_06001726(v55, v57, v59);
            int v61 = this.delay;
            if (v61 <= 0) {
                goto IL_0110;
            } else {
                goto IL_00FF;
            }
            IL_00FF: ;
            int v65 = this.delay;
            global::OpenRA.Mods.Common.Activities.Wait v66 = __cil_newobj_06002418(v65);
            this.QueueChild(((__cil_type_0100010F)(v66)));
            IL_0110: ;
            global::OpenRA.Mods.Common.Traits.Mobile v69 = this.mobile;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v70 = l0;
            __cil_type_01000025 v71 = v70.self;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v73 = this.pos;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity.__name_3C3E635F5F446973706C6179436C617373385F30 v74 = l0;
            __cil_type_01000025 v75 = v74.self;
            __cil_type_0100002D v76 = v75.World;
            __cil_type_01000026 v77 = v76.Map;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v79 = this.cell;
            int v81 = unchecked((int)(unchecked((byte)(this.subCell))));
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v82 = v77.CenterOfSubCell(v79, unchecked((OpenRA.Traits.SubCell)(unchecked((byte)(v81)))));
            __cil_type_0100010F v83 = __cil_callvirt_0600173B(v69, v71, v73, v82);
            this.QueueChild(v83);
            return true;
        }

        private sealed class __name_3C3E635F5F446973706C6179436C617373385F30
        {
            public OpenRA.Actor self;

            public __name_3C3E635F5F446973706C6179436C617373385F30() : base()
            {
                return;
            }

            // Metadata name: <Tick>b__0
            internal bool TickLambda0(OpenRA.Actor a)
            {
                __cil_type_01000025 v2 = this.self;
                int v3 = (System.Object.ReferenceEquals(a, v2) ? 1 : 0);
                return (v3 == 0);
            }
        }
    }

    public class LeaveProductionActivity : OpenRA.Activities.Activity
    {
        private readonly OpenRA.Mods.Common.Traits.Mobile mobile;
        private readonly int delay;
        private readonly OpenRA.CPos[] rallyPoint;
        private readonly OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity returnToCell;

        public LeaveProductionActivity(OpenRA.Actor self, int delay, OpenRA.CPos[] rallyPoint, OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity returnToCell) : base()
        {
            // structural signature __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba bytes=1D1180A9: valuetype [OpenRA.Game]OpenRA.CPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Mods.Common.Traits.Mobile v3 = __cil_callvirt_2B000178(self);
            this.mobile = v3;
            this.delay = delay;
            this.rallyPoint = rallyPoint;
            this.returnToCell = returnToCell;
            return;
        }

        protected override void OnFirstRun(OpenRA.Actor self)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba bytes=1D1180A9: valuetype [OpenRA.Game]OpenRA.CPos[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_40e290c8149402cb137a30da4a330e9a4e3017bb bytes=151280DD0112843D: class [System.Runtime]System.Func`1<class [OpenRA.Game]OpenRA.Activities.Activity>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba l0 = default;
            int l1 = default;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity v1 = this.returnToCell;
            if (v1 is null) {
                goto IL_0016;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            global::OpenRA.Mods.Common.Traits.Mobile.ReturnToCellActivity v4 = this.returnToCell;
            this.QueueChild(((__cil_type_0100010F)(v4)));
            goto IL_0030;
            IL_0016: ;
            int v6 = this.delay;
            if (v6 <= 0) {
                goto IL_0030;
            } else {
                goto IL_001F;
            }
            IL_001F: ;
            int v10 = this.delay;
            global::OpenRA.Mods.Common.Activities.Wait v11 = __cil_newobj_06002418(v10);
            this.QueueChild(((__cil_type_0100010F)(v11)));
            IL_0030: ;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v13 = this.rallyPoint;
            if (v13 is null) {
                goto IL_0080;
            } else {
                goto IL_0038;
            }
            IL_0038: ;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v15 = this.rallyPoint;
            l0 = v15;
            l1 = 0;
            goto IL_007A;
            IL_0043: ;
            global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C3E635F5F446973706C6179436C617373355F30 v17 = __cil_newobj_06004918();
            v17.__il_field_04003E2E = this;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v21 = l0;
            int v22 = l1;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v23 = __cil_ldelem_0100002A(v21, v22);
            v17.cell = v23;
            nint v27 = __cil_ldftn_06004919;
            __cil_ref_40e290c8149402cb137a30da4a330e9a4e3017bb v28 = __cil_newobj_0A0006DF(v17, v27);
            global::OpenRA.Mods.Common.Activities.AttackMoveActivity v30 = __cil_newobj_060023A5(self, v28, 0);
            this.QueueChild(((__cil_type_0100010F)(v30)));
            int v31 = l1;
            l1 = unchecked(v31 + 1);
            IL_007A: ;
            int v34 = l1;
            __cil_ref_4e8b8ccf3fe6ece249f79bd7bd392d1c2a3a72ba v35 = l0;
            nint v36 = unchecked((nint)(v35.LongLength));
            int v37 = unchecked((int)(v36));
            if (v34 < v37) {
                goto IL_0043;
            } else {
                goto IL_0080;
            }
            IL_0080: ;
            return;
        }

        public override System.Collections.Generic.IEnumerable<OpenRA.Traits.Target> GetTargets(OpenRA.Actor self)
        {
            // IL fallback: incompatible value/receiver types
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 28, 95, 19, 00, 0A, 2C, 0D, 02, 28, 95, 19, 00, 0A, 03, 6F, B1, 19, 00, 0A, 2A, 7E, B2, 19]
            // .code-bytes IL_0018: [00, 0A, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: call 0x0A001995 [OpenRA.Game]OpenRA.Activities.Activity::get_ChildActivity
            // IL_0006: brfalse.s IL_0015
            // IL_0008: ldarg.0 0
            // IL_0009: call 0x0A001995 [OpenRA.Game]OpenRA.Activities.Activity::get_ChildActivity
            // IL_000E: ldarg.1 1
            // IL_000F: callvirt 0x0A0019B1 [OpenRA.Game]OpenRA.Activities.Activity::GetTargets
            // IL_0014: ret 
            // IL_0015: ldsfld 0x0A0019B2 [OpenRA.Game]OpenRA.Traits.Target::None
            // IL_001A: ret 
        }

        public override System.Collections.Generic.IEnumerable<OpenRA.Activities.TargetLineNode> TargetLineNodes(OpenRA.Actor self)
        {
            // structural signature __cil_ref_4e389d8c3c1b8026c50ecd35a07e0b9ef1427db9 bytes=151280A10112879D: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v1 = __cil_newobj_0600491A(-2);
            v1.__il_field_04003E32 = this;
            v1.__il_field_04003E34 = self;
            return v1;
        }

        private sealed class __name_3C3E635F5F446973706C6179436C617373355F30
        {
            public OpenRA.CPos cell;
            public OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity __il_field_04003E2E;

            public __name_3C3E635F5F446973706C6179436C617373355F30() : base()
            {
                return;
            }

            // Metadata name: <OnFirstRun>b__0
            internal OpenRA.Activities.Activity OnFirstRunLambda0()
            {
                // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
                // structural signature __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 bytes=1511814101118085: valuetype [System.Runtime]System.Nullable`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity v1 = this.__il_field_04003E2E;
                global::OpenRA.Mods.Common.Traits.Mobile v2 = v1.mobile;
                __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v4 = this.cell;
                __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v7 = OpenRA.Primitives.Color.get_OrangeRed();
                __cil_value_aa1deb8a2e32b587bcb185568f953568cb8858e3 v8 = __cil_value_newobj_0A0006A4(v7);
                __cil_type_0100010F v9 = __cil_callvirt_06001733(v2, v4, 1, ((__cil_type_01000025)(null)), __cil_bool_store(1), v8);
                return v9;
            }
        }

        private sealed class __name_3C5461726765744C696E654E6F6465733E645F5F37 : System.Collections.Generic.IEnumerable<OpenRA.Activities.TargetLineNode>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Activities.TargetLineNode>, System.Collections.IEnumerator, System.IDisposable
        {
            private int __il_field_04003E2F;
            private OpenRA.Activities.TargetLineNode __il_field_04003E30;
            private int __il_field_04003E31;
            public OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity __il_field_04003E32;
            private OpenRA.Actor self;
            public OpenRA.Actor __il_field_04003E34;
            private OpenRA.Activities.Activity __il_field_04003E35;
            private System.Collections.Generic.IEnumerator<OpenRA.Activities.TargetLineNode> __il_field_04003E36;

            public __name_3C5461726765744C696E654E6F6465733E645F5F37(int __name_3C3E315F5F7374617465) : base()
            {
                this.__il_field_04003E2F = __name_3C3E315F5F7374617465;
                int v4 = System.Environment.get_CurrentManagedThreadId();
                this.__il_field_04003E31 = v4;
                return;
            }

            private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                int l0 = default;
                IL_0000: ;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v0 = this;
                int v1 = v0.__il_field_04003E2F;
                l0 = v1;
                int v2 = l0;
                int v3 = -3;
                if (v2 == v3) {
                    goto IL_0010;
                } else {
                    goto IL_000C;
                }
                IL_000C: ;
                int v4 = l0;
                int v5 = 1;
                if (unchecked((uint)v4) != unchecked((uint)v5)) {
                    goto IL_001A;
                } else {
                    goto IL_0010;
                }
                IL_0010: ;
                try {
                    IL_0011: ;
                    goto IL_001A;
                }
                finally {
                    IL_0013: ;
                    global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v6 = this;
                    __cil_direct_0600491D(v6);
                    goto __cil_finally_end_0;
                    __cil_finally_end_0: ;
                }
                IL_001A: ;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v7 = this;
                v7.__il_field_04003E35 = null;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v8 = this;
                v8.__il_field_04003E36 = null;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v9 = this;
                int v10 = -2;
                v9.__il_field_04003E2F = v10;
                return;
            }

            private virtual bool MoveNext()
            {
                // IL fallback: EH fault handlers need exceptional-only cleanup
                // .maxstack 3
                // .initlocals true
                // .code-bytes IL_0000: [02, 7B, 2F, 3E, 00, 04, 0B, 02, 7B, 32, 3E, 00, 04, 0C, 07, 2C, 0B, 07, 17, 2E, 70, 16, 0A, DD]
                // .code-bytes IL_0018: [B2, 00, 00, 00, 02, 15, 7D, 2F, 3E, 00, 04, 02, 08, 28, 95, 19, 00, 0A, 7D, 35, 3E, 00, 04, 38]
                // .code-bytes IL_0030: [84, 00, 00, 00, 02, 7B, 35, 3E, 00, 04, 6F, 29, 16, 00, 0A, 2D, 66, 02, 02, 7B, 35, 3E, 00, 04]
                // .code-bytes IL_0048: [02, 7B, 33, 3E, 00, 04, 6F, 2A, 16, 00, 0A, 6F, 89, 00, 00, 0A, 7D, 36, 3E, 00, 04, 02, 1F, FD]
                // .code-bytes IL_0060: [7D, 2F, 3E, 00, 04, 2B, 26, 02, 7B, 36, 3E, 00, 04, 6F, 88, 00, 00, 0A, 0D, 02, 09, 7D, 30, 3E]
                // .code-bytes IL_0078: [00, 04, 02, 17, 7D, 2F, 3E, 00, 04, 17, 0A, DE, 49, 02, 1F, FD, 7D, 2F, 3E, 00, 04, 02, 7B, 36]
                // .code-bytes IL_0090: [3E, 00, 04, 6F, 1B, 00, 00, 0A, 2D, CD, 02, 28, 1D, 49, 00, 06, 02, 14, 7D, 36, 3E, 00, 04, 02]
                // .code-bytes IL_00A8: [02, 7B, 35, 3E, 00, 04, 6F, 86, 11, 00, 0A, 7D, 35, 3E, 00, 04, 02, 7B, 35, 3E, 00, 04, 3A, 71]
                // .code-bytes IL_00C0: [FF, FF, FF, 16, 0A, DE, 07, 02, 28, 1B, 49, 00, 06, DC, 06, 2A]
                // .local [0] bool
                // .local [1] int32
                // .local [2] class OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity
                // .local [3] class [OpenRA.Game]OpenRA.Activities.TargetLineNode
                // IL_0000: ldarg.0 0
                // IL_0001: ldfld 0x04003E2F OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>1__state
                // IL_0006: stloc.1 1
                // IL_0007: ldarg.0 0
                // IL_0008: ldfld 0x04003E32 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>4__this
                // IL_000D: stloc.2 2
                // IL_000E: ldloc.1 1
                // IL_000F: brfalse.s IL_001C
                // IL_0011: ldloc.1 1
                // IL_0012: ldc.i4.1 1
                // IL_0013: beq.s IL_0085
                // IL_0015: ldc.i4.0 0
                // IL_0016: stloc.0 0
                // IL_0017: leave IL_00CE
                // IL_001C: ldarg.0 0
                // IL_001D: ldc.i4.m1 -1
                // IL_001E: stfld 0x04003E2F OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>1__state
                // IL_0023: ldarg.0 0
                // IL_0024: ldloc.2 2
                // IL_0025: call 0x0A001995 [OpenRA.Game]OpenRA.Activities.Activity::get_ChildActivity
                // IL_002A: stfld 0x04003E35 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<a>5__2
                // IL_002F: br IL_00B8
                // IL_0034: ldarg.0 0
                // IL_0035: ldfld 0x04003E35 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<a>5__2
                // IL_003A: callvirt 0x0A001629 [OpenRA.Game]OpenRA.Activities.Activity::get_IsCanceling
                // IL_003F: brtrue.s IL_00A7
                // IL_0041: ldarg.0 0
                // IL_0042: ldarg.0 0
                // IL_0043: ldfld 0x04003E35 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<a>5__2
                // IL_0048: ldarg.0 0
                // IL_0049: ldfld 0x04003E33 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::self
                // IL_004E: callvirt 0x0A00162A [OpenRA.Game]OpenRA.Activities.Activity::TargetLineNodes
                // IL_0053: callvirt 0x0A000089 class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>::GetEnumerator
                // IL_0058: stfld 0x04003E36 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>7__wrap2
                // IL_005D: ldarg.0 0
                // IL_005E: ldc.i4.s -3
                // IL_0060: stfld 0x04003E2F OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>1__state
                // IL_0065: br.s IL_008D
                // IL_0067: ldarg.0 0
                // IL_0068: ldfld 0x04003E36 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>7__wrap2
                // IL_006D: callvirt 0x0A000088 class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>::get_Current
                // IL_0072: stloc.3 3
                // IL_0073: ldarg.0 0
                // IL_0074: ldloc.3 3
                // IL_0075: stfld 0x04003E30 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>2__current
                // IL_007A: ldarg.0 0
                // IL_007B: ldc.i4.1 1
                // IL_007C: stfld 0x04003E2F OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>1__state
                // IL_0081: ldc.i4.1 1
                // IL_0082: stloc.0 0
                // IL_0083: leave.s IL_00CE
                // IL_0085: ldarg.0 0
                // IL_0086: ldc.i4.s -3
                // IL_0088: stfld 0x04003E2F OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>1__state
                // IL_008D: ldarg.0 0
                // IL_008E: ldfld 0x04003E36 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>7__wrap2
                // IL_0093: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
                // IL_0098: brtrue.s IL_0067
                // IL_009A: ldarg.0 0
                // IL_009B: call 0x0600491D OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>m__Finally1
                // IL_00A0: ldarg.0 0
                // IL_00A1: ldnull 
                // IL_00A2: stfld 0x04003E36 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<>7__wrap2
                // IL_00A7: ldarg.0 0
                // IL_00A8: ldarg.0 0
                // IL_00A9: ldfld 0x04003E35 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<a>5__2
                // IL_00AE: callvirt 0x0A001186 [OpenRA.Game]OpenRA.Activities.Activity::get_NextActivity
                // IL_00B3: stfld 0x04003E35 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<a>5__2
                // IL_00B8: ldarg.0 0
                // IL_00B9: ldfld 0x04003E35 OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::<a>5__2
                // IL_00BE: brtrue IL_0034
                // IL_00C3: ldc.i4.0 0
                // IL_00C4: stloc.0 0
                // IL_00C5: leave.s IL_00CE
                // IL_00C7: ldarg.0 0
                // IL_00C8: call 0x0600491B OpenRA.Mods.Common.Traits.Mobile/LeaveProductionActivity/<TargetLineNodes>d__7::System.IDisposable.Dispose
                // IL_00CD: endfinally 
                // IL_00CE: ldloc.0 0
                // IL_00CF: ret 
                // .eh-raw ExceptionHandler { kind: Fault, try_offset: 0, try_length: 199, handler_offset: 199, handler_length: 7, raw_flags: 4 }
                // .try IL_0000..IL_00C7 fault IL_00C7..IL_00CE
            }

            private void __name_3C3E6D5F5F46696E616C6C7931()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                this.__il_field_04003E2F = -1;
                __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d v3 = this.__il_field_04003E36;
                if (v3 is null) {
                    goto IL_001A;
                } else {
                    goto IL_000F;
                }
                IL_000F: ;
                __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d v5 = this.__il_field_04003E36;
                __cil_callvirt_0A00001A(v5);
                IL_001A: ;
                return;
            }

            private virtual OpenRA.Activities.TargetLineNode __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E6765745F43757272656E74()
            {
                __cil_type_010001E7 v1 = this.__il_field_04003E30;
                return v1;
            }

            private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
            {
                global::System.NotSupportedException v0 = __cil_newobj_0A001A01();
                throw v0;
            }

            private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
            {
                __cil_type_010001E7 v1 = this.__il_field_04003E30;
                return v1;
            }

            private virtual System.Collections.Generic.IEnumerator<OpenRA.Activities.TargetLineNode> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E476574456E756D657261746F72()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 l0 = default;
                int v1 = this.__il_field_04003E2F;
                if (unchecked((uint)v1) != unchecked((uint)-2)) {
                    goto IL_0022;
                } else {
                    goto IL_000A;
                }
                IL_000A: ;
                int v4 = this.__il_field_04003E31;
                int v5 = System.Environment.get_CurrentManagedThreadId();
                if (unchecked((uint)v4) != unchecked((uint)v5)) {
                    goto IL_0022;
                } else {
                    goto IL_0017;
                }
                IL_0017: ;
                this.__il_field_04003E2F = 0;
                l0 = this;
                goto IL_0035;
                IL_0022: ;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v10 = __cil_newobj_0600491A(0);
                l0 = v10;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v11 = l0;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity v13 = this.__il_field_04003E32;
                v11.__il_field_04003E32 = v13;
                IL_0035: ;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v14 = l0;
                __cil_type_01000025 v16 = this.__il_field_04003E34;
                v14.self = v16;
                global::OpenRA.Mods.Common.Traits.Mobile.LeaveProductionActivity.__name_3C5461726765744C696E654E6F6465733E645F5F37 v17 = l0;
                return v17;
            }

            private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
            {
                // structural signature __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d bytes=151280A50112879D: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Activities.TargetLineNode>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
                __cil_ref_7d489abb93734a46fcfce87fe58e999746e61b5d v1 = __cil_direct_06004921(this);
                return v1;
            }
            // property OpenRA.Activities.TargetLineNode __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E416374697669746965732E5461726765744C696E654E6F64653E2E6765745F43757272656E74; }
            // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
        }
    }

    private sealed class MoveOrderTargeter : OpenRA.Traits.IOrderTargeter
    {
        private readonly OpenRA.Mods.Common.Traits.Mobile mobile;
        private readonly OpenRA.Mods.Common.Traits.LocomotorInfo locomotorInfo;
        private readonly bool rejectMove;
        private bool __il_field_04003472;

        public bool TargetOverridesSelection(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Collections.Generic.List<OpenRA.Actor> actorsAt, OpenRA.CPos xy, OpenRA.Traits.TargetModifiers modifiers)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_8457042ecebfe053d825612987d6bf1c10fbfaba bytes=1512811D01128095: class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // enum storage token=0x0200011C alias=__cil_enum_0200011C underlying=byte: global::@OpenRA.@Traits.@TargetType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            // enum storage token=0x0200012E alias=__cil_enum_0200012E underlying=int: global::@OpenRA.@Traits.@TargetModifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            IL_0000: ;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v0 = ref target;
            int v1 = unchecked((int)(unchecked((byte)(__cil_memberref_call_0A000208(ref v0)))));
            int v2 = 1;
            if (unchecked((uint)v1) != unchecked((uint)v2)) {
                goto IL_0036;
            } else {
                goto IL_0009;
            }
            IL_0009: ;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v3 = ref target;
            __cil_type_01000025 v4 = __cil_memberref_call_0A000209(ref v3);
            __cil_type_01000030 v5 = ((OpenRA.Actor)v4).Owner;
            __cil_type_01000025 v6 = self;
            __cil_type_01000030 v7 = ((OpenRA.Actor)v6).Owner;
            if (!System.Object.ReferenceEquals(v5, v7)) {
                goto IL_0034;
            } else {
                goto IL_001C;
            }
            IL_001C: ;
            __cil_type_01000025 v8 = self;
            __cil_type_0100002D v9 = v8.World;
            __cil_type_010001A7 v10 = v9.Selection;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v11 = ref target;
            __cil_type_01000025 v12 = __cil_memberref_call_0A000209(ref v11);
            int v13 = __cil_bool_load(__cil_callvirt_0A000AB4(v10, v12));
            if (v13 == 0) {
                goto IL_0036;
            } else {
                goto IL_0034;
            }
            IL_0034: ;
            int v14 = 1;
            return __cil_bool_store(v14);
            IL_0036: ;
            int v15 = unchecked((int)(modifiers));
            int v16 = 4;
            int v17 = __cil_bool_load(OpenRA.Traits.TargetModifiersExts.HasModifier(unchecked((OpenRA.Traits.TargetModifiers)(v15)), unchecked((OpenRA.Traits.TargetModifiers)(v16))));
            return __cil_bool_store(v17);
        }

        public MoveOrderTargeter(OpenRA.Actor self, OpenRA.Mods.Common.Traits.Mobile unit) : base()
        {
            this.mobile = unit;
            global::OpenRA.Mods.Common.Traits.Mobile v5 = this.mobile;
            global::OpenRA.Mods.Common.Traits.MobileInfo v6 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v5).Info;
            global::OpenRA.Mods.Common.Traits.LocomotorInfo v7 = __cil_callvirt_060016EE(v6);
            this.locomotorInfo = v7;
            string v10 = __cil_ldstr_7001FE7B("Move");
            int v11 = __cil_bool_load(OpenRA.Mods.Common.Traits.RejectsOrdersExts.AcceptsOrder(self, v10));
            int v13 = (v11 == 0 ? 1 : 0);
            this.rejectMove = __cil_bool_store(v13);
            return;
        }

        public virtual string get_OrderID()
        {
            string v0 = __cil_ldstr_7001FE7B("Move");
            return v0;
        }

        public virtual int get_OrderPriority()
        {
            return 4;
        }

        public virtual bool get_IsQueued()
        {
            return this.__il_field_04003472;
        }

        private void set_IsQueued(bool value)
        {
            int v1 = __cil_bool_load(value);
            this.__il_field_04003472 = __cil_bool_store(v1);
            return;
        }

        public bool CanTarget(OpenRA.Actor self, ref OpenRA.Traits.Target target, ref OpenRA.Traits.TargetModifiers modifiers, ref string cursor)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae bytes=1180ED: valuetype [OpenRA.Game]OpenRA.WPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_afed037d079105c214a094897df496882260d1c3 bytes=118129: valuetype [OpenRA.Game]OpenRA.Traits.Target; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_ef4ee1cce8a13f751ccb6c82e9bfe251b81efc2d bytes=15128189020E0E: class [System.Collections]System.Collections.Generic.Dictionary`2<string, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // enum storage token=0x0200011C alias=__cil_enum_0200011C underlying=byte: global::@OpenRA.@Traits.@TargetType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            // enum storage token=0x0200012E alias=__cil_enum_0200012E underlying=int: global::@OpenRA.@Traits.@TargetModifiers; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 l0 = default;
            bool l1 = default;
            IL_0000: ;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v0 = this;
            int v1 = __cil_bool_load(v0.rejectMove);
            if (v1 != 0) {
                goto IL_0028;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v2 = ref target;
            int v3 = unchecked((int)(unchecked((byte)(__cil_memberref_call_0A000208(ref v2)))));
            int v4 = 2;
            if (unchecked((uint)v3) != unchecked((uint)v4)) {
                goto IL_0028;
            } else {
                goto IL_0011;
            }
            IL_0011: ;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v5 = this;
            global::OpenRA.Mods.Common.Traits.Mobile v6 = v5.mobile;
            int v7 = __cil_bool_load(v6.requireForceMove);
            if (v7 == 0) {
                goto IL_002A;
            } else {
                goto IL_001E;
            }
            IL_001E: ;
            ref global::OpenRA.Traits.TargetModifiers v8 = ref modifiers;
            int v9 = unchecked((int)(v8));
            int v10 = 4;
            int v11 = __cil_bool_load(OpenRA.Traits.TargetModifiersExts.HasModifier(unchecked((OpenRA.Traits.TargetModifiers)(v9)), unchecked((OpenRA.Traits.TargetModifiers)(v10))));
            if (v11 != 0) {
                goto IL_002A;
            } else {
                goto IL_0028;
            }
            IL_0028: ;
            int v12 = 0;
            return __cil_bool_store(v12);
            IL_002A: ;
            __cil_type_01000025 v13 = self;
            __cil_type_0100002D v14 = v13.World;
            __cil_type_01000026 v15 = v14.Map;
            ref __cil_value_afed037d079105c214a094897df496882260d1c3 v16 = ref target;
            __cil_value_bf39fb754021d22c3f376a39c5b30d9a05a893ae v17 = __cil_memberref_call_0A00027F(ref v16);
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v18 = v15.CellContaining(v17);
            l0 = v18;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v19 = this;
            ref global::OpenRA.Traits.TargetModifiers v20 = ref modifiers;
            int v21 = unchecked((int)(v20));
            int v22 = 2;
            int v23 = __cil_bool_load(OpenRA.Traits.TargetModifiersExts.HasModifier(unchecked((OpenRA.Traits.TargetModifiers)(v21)), unchecked((OpenRA.Traits.TargetModifiers)(v22))));
            __cil_direct_06003EFA(v19, __cil_bool_store(v23));
            __cil_type_01000025 v24 = self;
            __cil_type_01000030 v25 = ((OpenRA.Actor)v24).Owner;
            __cil_type_01000068 v26 = v25.Shroud;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v27 = l0;
            int v28 = __cil_bool_load(v26.IsExplored(v27));
            l1 = __cil_bool_store(v28);
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v29 = this;
            global::OpenRA.Mods.Common.Traits.Mobile v30 = v29.mobile;
            int v31 = __cil_bool_load(v30.get_IsTraitPaused());
            if (v31 != 0) {
                goto IL_00AC;
            } else {
                goto IL_006E;
            }
            IL_006E: ;
            __cil_type_01000025 v32 = self;
            __cil_type_0100002D v33 = v32.World;
            __cil_type_01000026 v34 = v33.Map;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v35 = l0;
            int v36 = __cil_bool_load(v34.Contains(v35));
            if (v36 == 0) {
                goto IL_00AC;
            } else {
                goto IL_0081;
            }
            IL_0081: ;
            int v37 = __cil_bool_load(l1);
            if (v37 != 0) {
                goto IL_0091;
            } else {
                goto IL_0084;
            }
            IL_0084: ;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v38 = this;
            global::OpenRA.Mods.Common.Traits.LocomotorInfo v39 = v38.locomotorInfo;
            int v40 = __cil_bool_load(v39.MoveIntoShroud);
            if (v40 == 0) {
                goto IL_00AC;
            } else {
                goto IL_0091;
            }
            IL_0091: ;
            int v41 = __cil_bool_load(l1);
            if (v41 == 0) {
                goto IL_00C1;
            } else {
                goto IL_0094;
            }
            IL_0094: ;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v42 = this;
            global::OpenRA.Mods.Common.Traits.Mobile v43 = v42.mobile;
            global::OpenRA.Mods.Common.Traits.Locomotor v44 = __cil_callvirt_0600170D(v43);
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v45 = l0;
            int v46 = unchecked((int)(__cil_callvirt_06001D9B(v44, v45)));
            int v47 = 32767;
            if (unchecked((uint)v46) != unchecked((uint)v47)) {
                goto IL_00C1;
            } else {
                goto IL_00AC;
            }
            IL_00AC: ;
            ref string v48 = ref cursor;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v49 = this;
            global::OpenRA.Mods.Common.Traits.Mobile v50 = v49.mobile;
            global::OpenRA.Mods.Common.Traits.MobileInfo v51 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v50).Info;
            string v52 = v51.BlockedCursor;
            v48 = v52;
            goto IL_0106;
            IL_00C1: ;
            int v53 = __cil_bool_load(l1);
            if (v53 == 0) {
                goto IL_00F3;
            } else {
                goto IL_00C4;
            }
            IL_00C4: ;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v54 = this;
            global::OpenRA.Mods.Common.Traits.Mobile v55 = v54.mobile;
            global::OpenRA.Mods.Common.Traits.MobileInfo v56 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v55).Info;
            __cil_ref_ef4ee1cce8a13f751ccb6c82e9bfe251b81efc2d v57 = v56.TerrainCursors;
            __cil_type_01000025 v58 = self;
            __cil_type_0100002D v59 = v58.World;
            __cil_type_01000026 v60 = v59.Map;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v61 = l0;
            __cil_type_010000CD v62 = v60.GetTerrainInfo(v61);
            string v63 = v62.Type;
            ref string v64 = ref cursor;
            int v65 = __cil_bool_load(__cil_callvirt_0A00041F(v57, v63, ref v64));
            if (v65 != 0) {
                goto IL_0106;
            } else {
                goto IL_00F3;
            }
            IL_00F3: ;
            ref string v66 = ref cursor;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v67 = this;
            global::OpenRA.Mods.Common.Traits.Mobile v68 = v67.mobile;
            global::OpenRA.Mods.Common.Traits.MobileInfo v69 = ((__cil_ref_dbcbfe5783708e7edce61f3a1a883a7e310c648d)v68).Info;
            string v70 = v69.Cursor;
            v66 = v70;
            goto IL_0106;
            IL_0106: ;
            int v71 = 1;
            return __cil_bool_store(v71);
        }

        private virtual bool __name_4F70656E52412E5472616974732E494F7264657254617267657465722E43616E546172676574(OpenRA.Actor self, ref OpenRA.Traits.Target target, ref OpenRA.Traits.TargetModifiers modifiers, ref string cursor)
        {
            // IL fallback: byref/modified parameter needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 28, FB, 3E, 00, 06, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldarg.1 1
            // IL_0002: ldarg.2 2
            // IL_0003: ldarg.3 3
            // IL_0004: ldarg.s 4
            // IL_0006: call 0x06003EFB OpenRA.Mods.Common.Traits.Mobile/MoveOrderTargeter::CanTarget
            // IL_000B: ret 
        }

        private virtual bool __name_4F70656E52412E5472616974732E494F7264657254617267657465722E5461726765744F766572726964657353656C656374696F6E(OpenRA.Actor self, ref OpenRA.Traits.Target target, System.Collections.Generic.List<OpenRA.Actor> actorsAt, OpenRA.CPos xy, OpenRA.Traits.TargetModifiers modifiers)
        {
            // IL fallback: byref/modified parameter needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 03, 04, 05, 0E, 04, 0E, 05, 28, F5, 3E, 00, 06, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldarg.1 1
            // IL_0002: ldarg.2 2
            // IL_0003: ldarg.3 3
            // IL_0004: ldarg.s 4
            // IL_0006: ldarg.s 5
            // IL_0008: call 0x06003EF5 OpenRA.Mods.Common.Traits.Mobile/MoveOrderTargeter::TargetOverridesSelection
            // IL_000D: ret 
        }
        // property string OrderID { get: get_OrderID; }
        // property int OrderPriority { get: get_OrderPriority; }
        // property bool IsQueued { get: get_IsQueued; set: set_IsQueued; }
    }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63 __il_field_04003473;
        public static System.Func<OpenRA.Mods.Common.Traits.ISpeedModifier, int> __il_field_04003474;
        public static System.Func<OpenRA.CPos, OpenRA.Actor, __name_3C3E665F5F416E6F6E796D6F75735479706531<OpenRA.CPos, OpenRA.Actor>> __il_field_04003475;
        public static System.Func<OpenRA.Mods.Common.Traits.INotifyCrushed, System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>>> __il_field_04003476;
        public static System.Func<OpenRA.Actor, System.Collections.Generic.IEnumerable<OpenRA.TraitPair<OpenRA.Traits.ICrushable>>> __il_field_04003477;
        public static System.Func<OpenRA.Mods.Common.Traits.INotifyCrushed, System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>>> __il_field_04003478;

        static __name_3C3E63()
        {
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63 v0 = __cil_newobj_06003EFF();
            OpenRA.Mods.Common.Traits.Mobile.__name_3C3E63.__il_field_04003473 = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <.ctor>b__67_1
        internal int CtorLambda67_1(OpenRA.Mods.Common.Traits.ISpeedModifier x)
        {
            int v1 = __cil_callvirt_06001F9D(x);
            return v1;
        }

        // Metadata name: <GetAdjacentCell>b__77_1
        internal __name_3C3E665F5F416E6F6E796D6F75735479706531<OpenRA.CPos, OpenRA.Actor> GetAdjacentCellLambda77_1(OpenRA.CPos c, OpenRA.Actor a)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            // structural signature __cil_ref_181c5b4e12546c80f0be4e3e4af3817375f41e60 bytes=15120C021180A9128095: class <>f__AnonymousType1`2<valuetype [OpenRA.Game]OpenRA.CPos, class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_181c5b4e12546c80f0be4e3e4af3817375f41e60 v2 = __cil_newobj_0A001D05(c, a);
            return v2;
        }

        // Metadata name: <FinishedMoving>b__92_0
        internal System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>> FinishedMovingLambda92_0(OpenRA.Mods.Common.Traits.INotifyCrushed notifyCrushed)
        {
            // IL fallback: unsupported opcode ldvirtftn at IL_0002
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 25, FE, 07, 20, 1F, 00, 06, 73, 8F, 1C, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: dup 
            // IL_0002: ldvirtftn 0x06001F20 OpenRA.Mods.Common.Traits.INotifyCrushed::OnCrush
            // IL_0008: newobj 0x0A001C8F class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>::.ctor
            // IL_000D: ret 
        }

        // Metadata name: <CrushAction>b__93_1
        internal System.Collections.Generic.IEnumerable<OpenRA.TraitPair<OpenRA.Traits.ICrushable>> CrushActionLambda93_1(OpenRA.Actor a)
        {
            // structural signature __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 bytes=151280A10115118125011284C9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc bytes=1D1284C9: class [OpenRA.Game]OpenRA.Traits.ICrushable[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_f48622b11bf13e8aea55dc410129d650d43157c5 bytes=15128121021284C915118125011284C9: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.ICrushable, valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_5456acb599b8af561901b1de68086d6d17196efd bytes=151280A1011284C9: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C3E635F5F446973706C6179436C61737339335F31 v0 = __cil_newobj_06003F09();
            v0.a = a;
            __cil_type_01000025 v4 = v0.a;
            __cil_ref_92d8549dbf5581c8f4852fbf64ca8e2437a98acc v5 = ((OpenRA.Actor)v4).Crushables;
            nint v7 = __cil_ldftn_06003F0A;
            __cil_ref_f48622b11bf13e8aea55dc410129d650d43157c5 v8 = __cil_newobj_0A001C90(v0, v7);
            __cil_ref_5df9075ea840446a5ca28772ec6f494bc0da6d90 v9 = __cil_methodspec_call_2B0008A9(((__cil_ref_5456acb599b8af561901b1de68086d6d17196efd)(v5)), v8);
            return v9;
        }

        // Metadata name: <EnteringCell>b__113_0
        internal System.Action<OpenRA.Actor, OpenRA.Actor, OpenRA.Primitives.BitSet<OpenRA.Traits.CrushClass>> EnteringCellLambda113_0(OpenRA.Mods.Common.Traits.INotifyCrushed notifyCrushed)
        {
            // IL fallback: unsupported opcode ldvirtftn at IL_0002
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 25, FE, 07, 21, 1F, 00, 06, 73, 8F, 1C, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: dup 
            // IL_0002: ldvirtftn 0x06001F21 OpenRA.Mods.Common.Traits.INotifyCrushed::WarnCrush
            // IL_0008: newobj 0x0A001C8F class [System.Runtime]System.Action`3<class [OpenRA.Game]OpenRA.Actor, class [OpenRA.Game]OpenRA.Actor, valuetype [OpenRA.Game]OpenRA.Primitives.BitSet`1<class [OpenRA.Game]OpenRA.Traits.CrushClass>>::.ctor
            // IL_000D: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C6173733130395F30
    {
        public OpenRA.Actor self;

        public __name_3C3E635F5F446973706C6179436C6173733130395F30() : base()
        {
            return;
        }

        // Metadata name: <CanEnterTargetNow>b__0
        internal bool CanEnterTargetNowLambda0(OpenRA.CPos c)
        {
            // structural signature __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 bytes=1180A9: valuetype [OpenRA.Game]OpenRA.CPos; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_type_01000025 v2 = this.self;
            __cil_value_13b48834ea748f1ea38d02def38ca26e6d26c625 v3 = ((OpenRA.Actor)v2).Location;
            return OpenRA.CPos.op_Equality(c, v3);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737339335F30
    {
        public OpenRA.Actor self;

        public __name_3C3E635F5F446973706C6179436C61737339335F30() : base()
        {
            return;
        }

        // Metadata name: <CrushAction>b__0
        internal bool CrushActionLambda0(OpenRA.Actor a)
        {
            __cil_type_01000025 v2 = this.self;
            int v3 = (System.Object.ReferenceEquals(a, v2) ? 1 : 0);
            return (v3 == 0);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737339335F31
    {
        public OpenRA.Actor a;

        public __name_3C3E635F5F446973706C6179436C61737339335F31() : base()
        {
            return;
        }

        // Metadata name: <CrushAction>b__2
        internal OpenRA.TraitPair<OpenRA.Traits.ICrushable> CrushActionLambda2(OpenRA.Traits.ICrushable t)
        {
            // structural signature __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 bytes=15118125011284C9: valuetype [OpenRA.Game]OpenRA.TraitPair`1<class [OpenRA.Game]OpenRA.Traits.ICrushable>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000025 v1 = this.a;
            __cil_value_90edea45962623e8bdb7e3b1342cb5df469ae830 v3 = __cil_value_newobj_0A001C91(v1, t);
            return v3;
        }
    }

    private sealed class __name_3C4765745661726961626C654F62736572766572733E645F5F313231 : System.Collections.Generic.IEnumerable<OpenRA.Traits.VariableObserver>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Traits.VariableObserver>, System.Collections.IEnumerator, System.IDisposable
    {
        private int __il_field_0400347C;
        private OpenRA.Traits.VariableObserver __il_field_0400347D;
        private int __il_field_0400347E;
        public OpenRA.Mods.Common.Traits.Mobile __il_field_0400347F;
        private System.Collections.Generic.IEnumerator<OpenRA.Traits.VariableObserver> __il_field_04003480;

        public __name_3C4765745661726961626C654F62736572766572733E645F5F313231(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_0400347C = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_0400347E = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            int l0 = default;
            IL_0000: ;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v0 = this;
            int v1 = v0.__il_field_0400347C;
            l0 = v1;
            int v2 = l0;
            int v3 = -3;
            if (v2 == v3) {
                goto IL_0010;
            } else {
                goto IL_000C;
            }
            IL_000C: ;
            int v4 = l0;
            int v5 = 1;
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_001A;
            } else {
                goto IL_0010;
            }
            IL_0010: ;
            try {
                IL_0011: ;
                goto IL_001A;
            }
            finally {
                IL_0013: ;
                global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v6 = this;
                __cil_direct_06003F0E(v6);
                goto __cil_finally_end_0;
                __cil_finally_end_0: ;
            }
            IL_001A: ;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v7 = this;
            v7.__il_field_04003480 = null;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v8 = this;
            int v9 = -2;
            v8.__il_field_0400347C = v9;
            return;
        }

        private virtual bool MoveNext()
        {
            // IL fallback: EH fault handlers need exceptional-only cleanup
            // .maxstack 3
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, 7C, 34, 00, 04, 0B, 02, 7B, 7F, 34, 00, 04, 0C, 07, 45, 04, 00, 00, 00, 07, 00, 00, 00]
            // .code-bytes IL_0018: [4A, 00, 00, 00, AB, 00, 00, 00, F1, 00, 00, 00, 16, 0A, DD, FC, 00, 00, 00, 02, 15, 7D, 7C, 34]
            // .code-bytes IL_0030: [00, 04, 02, 08, 28, 5E, 17, 00, 06, 6F, 96, 00, 00, 0A, 7D, 80, 34, 00, 04, 02, 1F, FD, 7D, 7C]
            // .code-bytes IL_0048: [34, 00, 04, 2B, 29, 02, 7B, 80, 34, 00, 04, 6F, 95, 00, 00, 0A, 0D, 02, 09, 7D, 7D, 34, 00, 04]
            // .code-bytes IL_0060: [02, 17, 7D, 7C, 34, 00, 04, 17, 0A, DD, B9, 00, 00, 00, 02, 1F, FD, 7D, 7C, 34, 00, 04, 02, 7B]
            // .code-bytes IL_0078: [80, 34, 00, 04, 6F, 1B, 00, 00, 0A, 2D, CA, 02, 28, 0E, 3F, 00, 06, 02, 14, 7D, 80, 34, 00, 04]
            // .code-bytes IL_0090: [08, 7B, FB, 10, 00, 0A, 7B, 2C, 13, 00, 04, 2C, 39, 02, 08, FE, 06, 4B, 17, 00, 06, 73, 92, 1C]
            // .code-bytes IL_00A8: [00, 0A, 08, 7B, FB, 10, 00, 0A, 7B, 2C, 13, 00, 04, 6F, 89, 09, 00, 0A, 73, 93, 1C, 00, 0A, 7D]
            // .code-bytes IL_00C0: [7D, 34, 00, 04, 02, 18, 7D, 7C, 34, 00, 04, 17, 0A, DE, 58, 02, 15, 7D, 7C, 34, 00, 04, 08, 7B]
            // .code-bytes IL_00D8: [FB, 10, 00, 0A, 7B, 2D, 13, 00, 04, 2C, 39, 02, 08, FE, 06, 4C, 17, 00, 06, 73, 92, 1C, 00, 0A]
            // .code-bytes IL_00F0: [08, 7B, FB, 10, 00, 0A, 7B, 2D, 13, 00, 04, 6F, 89, 09, 00, 0A, 73, 93, 1C, 00, 0A, 7D, 7D, 34]
            // .code-bytes IL_0108: [00, 04, 02, 19, 7D, 7C, 34, 00, 04, 17, 0A, DE, 12, 02, 15, 7D, 7C, 34, 00, 04, 16, 0A, DE, 07]
            // .code-bytes IL_0120: [02, 28, 0C, 3F, 00, 06, DC, 06, 2A]
            // .local [0] bool
            // .local [1] int32
            // .local [2] class OpenRA.Mods.Common.Traits.Mobile
            // .local [3] valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_0006: stloc.1 1
            // IL_0007: ldarg.0 0
            // IL_0008: ldfld 0x0400347F OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>4__this
            // IL_000D: stloc.2 2
            // IL_000E: ldloc.1 1
            // IL_000F: switch IL_002B, IL_006E, IL_00CF, IL_0115
            // IL_0024: ldc.i4.0 0
            // IL_0025: stloc.0 0
            // IL_0026: leave IL_0127
            // IL_002B: ldarg.0 0
            // IL_002C: ldc.i4.m1 -1
            // IL_002D: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_0032: ldarg.0 0
            // IL_0033: ldloc.2 2
            // IL_0034: call 0x0600175E OpenRA.Mods.Common.Traits.Mobile::<>n__0
            // IL_0039: callvirt 0x0A000096 class [System.Runtime]System.Collections.Generic.IEnumerable`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>::GetEnumerator
            // IL_003E: stfld 0x04003480 OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>7__wrap1
            // IL_0043: ldarg.0 0
            // IL_0044: ldc.i4.s -3
            // IL_0046: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_004B: br.s IL_0076
            // IL_004D: ldarg.0 0
            // IL_004E: ldfld 0x04003480 OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>7__wrap1
            // IL_0053: callvirt 0x0A000095 class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>::get_Current
            // IL_0058: stloc.3 3
            // IL_0059: ldarg.0 0
            // IL_005A: ldloc.3 3
            // IL_005B: stfld 0x0400347D OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>2__current
            // IL_0060: ldarg.0 0
            // IL_0061: ldc.i4.1 1
            // IL_0062: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_0067: ldc.i4.1 1
            // IL_0068: stloc.0 0
            // IL_0069: leave IL_0127
            // IL_006E: ldarg.0 0
            // IL_006F: ldc.i4.s -3
            // IL_0071: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_0076: ldarg.0 0
            // IL_0077: ldfld 0x04003480 OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>7__wrap1
            // IL_007C: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
            // IL_0081: brtrue.s IL_004D
            // IL_0083: ldarg.0 0
            // IL_0084: call 0x06003F0E OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>m__Finally1
            // IL_0089: ldarg.0 0
            // IL_008A: ldnull 
            // IL_008B: stfld 0x04003480 OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>7__wrap1
            // IL_0090: ldloc.2 2
            // IL_0091: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
            // IL_0096: ldfld 0x0400132C OpenRA.Mods.Common.Traits.MobileInfo::RequireForceMoveCondition
            // IL_009B: brfalse.s IL_00D6
            // IL_009D: ldarg.0 0
            // IL_009E: ldloc.2 2
            // IL_009F: ldftn 0x0600174B OpenRA.Mods.Common.Traits.Mobile::RequireForceMoveConditionChanged
            // IL_00A5: newobj 0x0A001C92 [OpenRA.Game]OpenRA.Traits.VariableObserverNotifier::.ctor
            // IL_00AA: ldloc.2 2
            // IL_00AB: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
            // IL_00B0: ldfld 0x0400132C OpenRA.Mods.Common.Traits.MobileInfo::RequireForceMoveCondition
            // IL_00B5: callvirt 0x0A000989 [OpenRA.Game]OpenRA.Support.VariableExpression::get_Variables
            // IL_00BA: newobj 0x0A001C93 [OpenRA.Game]OpenRA.Traits.VariableObserver::.ctor
            // IL_00BF: stfld 0x0400347D OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>2__current
            // IL_00C4: ldarg.0 0
            // IL_00C5: ldc.i4.2 2
            // IL_00C6: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_00CB: ldc.i4.1 1
            // IL_00CC: stloc.0 0
            // IL_00CD: leave.s IL_0127
            // IL_00CF: ldarg.0 0
            // IL_00D0: ldc.i4.m1 -1
            // IL_00D1: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_00D6: ldloc.2 2
            // IL_00D7: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
            // IL_00DC: ldfld 0x0400132D OpenRA.Mods.Common.Traits.MobileInfo::ImmovableCondition
            // IL_00E1: brfalse.s IL_011C
            // IL_00E3: ldarg.0 0
            // IL_00E4: ldloc.2 2
            // IL_00E5: ldftn 0x0600174C OpenRA.Mods.Common.Traits.Mobile::ImmovableConditionChanged
            // IL_00EB: newobj 0x0A001C92 [OpenRA.Game]OpenRA.Traits.VariableObserverNotifier::.ctor
            // IL_00F0: ldloc.2 2
            // IL_00F1: ldfld 0x0A0010FB class OpenRA.Mods.Common.Traits.ConditionalTrait`1<class OpenRA.Mods.Common.Traits.MobileInfo>::Info
            // IL_00F6: ldfld 0x0400132D OpenRA.Mods.Common.Traits.MobileInfo::ImmovableCondition
            // IL_00FB: callvirt 0x0A000989 [OpenRA.Game]OpenRA.Support.VariableExpression::get_Variables
            // IL_0100: newobj 0x0A001C93 [OpenRA.Game]OpenRA.Traits.VariableObserver::.ctor
            // IL_0105: stfld 0x0400347D OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>2__current
            // IL_010A: ldarg.0 0
            // IL_010B: ldc.i4.3 3
            // IL_010C: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_0111: ldc.i4.1 1
            // IL_0112: stloc.0 0
            // IL_0113: leave.s IL_0127
            // IL_0115: ldarg.0 0
            // IL_0116: ldc.i4.m1 -1
            // IL_0117: stfld 0x0400347C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::<>1__state
            // IL_011C: ldc.i4.0 0
            // IL_011D: stloc.0 0
            // IL_011E: leave.s IL_0127
            // IL_0120: ldarg.0 0
            // IL_0121: call 0x06003F0C OpenRA.Mods.Common.Traits.Mobile/<GetVariableObservers>d__121::System.IDisposable.Dispose
            // IL_0126: endfinally 
            // IL_0127: ldloc.0 0
            // IL_0128: ret 
            // .eh-raw ExceptionHandler { kind: Fault, try_offset: 0, try_length: 288, handler_offset: 288, handler_length: 7, raw_flags: 4 }
            // .try IL_0000..IL_0120 fault IL_0120..IL_0127
        }

        private void __name_3C3E6D5F5F46696E616C6C7931()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            this.__il_field_0400347C = -1;
            __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e v3 = this.__il_field_04003480;
            if (v3 is null) {
                goto IL_001A;
            } else {
                goto IL_000F;
            }
            IL_000F: ;
            __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e v5 = this.__il_field_04003480;
            __cil_callvirt_0A00001A(v5);
            IL_001A: ;
            return;
        }

        private virtual OpenRA.Traits.VariableObserver __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E6765745F43757272656E74()
        {
            // structural signature __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 bytes=1187C5: valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 v1 = this.__il_field_0400347D;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A001A01();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            // structural signature __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 bytes=1187C5: valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_252d11ffe3490e47244441c12494c6519dc6e777 v1 = this.__il_field_0400347D;
            object v2 = ((object)((__cil_value_252d11ffe3490e47244441c12494c6519dc6e777)(v1)));
            return v2;
        }

        private virtual System.Collections.Generic.IEnumerator<OpenRA.Traits.VariableObserver> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 l0 = default;
            int v1 = this.__il_field_0400347C;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_0400347E;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_0400347C = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v10 = __cil_newobj_06003F0B(0);
            l0 = v10;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v11 = l0;
            global::OpenRA.Mods.Common.Traits.Mobile v13 = this.__il_field_0400347F;
            v11.__il_field_0400347F = v13;
            IL_0035: ;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4765745661726961626C654F62736572766572733E645F5F313231 v14 = l0;
            return v14;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e bytes=151280A5011187C5: class [System.Runtime]System.Collections.Generic.IEnumerator`1<valuetype [OpenRA.Game]OpenRA.Traits.VariableObserver>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_ba0f3a6d9a170b4315a27682c594844550e5d06e v1 = __cil_direct_06003F12(this);
            return v1;
        }
        // property OpenRA.Traits.VariableObserver __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E5661726961626C654F627365727665723E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }

    private sealed class __name_3C4F70656E52412D5472616974732D4949737375654F726465722D6765745F4F72646572733E645F5F313235 : System.Collections.Generic.IEnumerable<OpenRA.Traits.IOrderTargeter>, System.Collections.IEnumerable, System.Collections.Generic.IEnumerator<OpenRA.Traits.IOrderTargeter>, System.Collections.IEnumerator, System.IDisposable
    {
        private int __il_field_04003481;
        private OpenRA.Traits.IOrderTargeter __il_field_04003482;
        private int __il_field_04003483;
        public OpenRA.Mods.Common.Traits.Mobile __il_field_04003484;

        public __name_3C4F70656E52412D5472616974732D4949737375654F726465722D6765745F4F72646572733E645F5F313235(int __name_3C3E315F5F7374617465) : base()
        {
            this.__il_field_04003481 = __name_3C3E315F5F7374617465;
            int v4 = System.Environment.get_CurrentManagedThreadId();
            this.__il_field_04003483 = v4;
            return;
        }

        private virtual void __name_53797374656D2E49446973706F7361626C652E446973706F7365()
        {
            this.__il_field_04003481 = -2;
            return;
        }

        private virtual bool MoveNext()
        {
            int l0 = default;
            OpenRA.Mods.Common.Traits.Mobile l1 = default;
            int v1 = this.__il_field_04003481;
            l0 = v1;
            global::OpenRA.Mods.Common.Traits.Mobile v3 = this.__il_field_04003484;
            l1 = v3;
            int v4 = l0;
            if (v4 == 0) {
                goto IL_0017;
            } else {
                goto IL_0011;
            }
            IL_0011: ;
            int v5 = l0;
            if (v5 == 1) {
                goto IL_0041;
            } else {
                return false;
            }
            IL_0017: ;
            this.__il_field_04003481 = -1;
            global::OpenRA.Mods.Common.Traits.Mobile v10 = l1;
            int v11 = __cil_bool_load(__cil_direct_0A0006FB(v10));
            if (v11 != 0) {
                return false;
            } else {
                goto IL_0026;
            }
            IL_0026: ;
            global::OpenRA.Mods.Common.Traits.Mobile v13 = l1;
            __cil_type_01000025 v14 = v13.self;
            global::OpenRA.Mods.Common.Traits.Mobile v15 = l1;
            global::OpenRA.Mods.Common.Traits.Mobile.MoveOrderTargeter v16 = __cil_newobj_06003EF6(v14, v15);
            this.__il_field_04003482 = v16;
            this.__il_field_04003481 = 1;
            return true;
            IL_0041: ;
            this.__il_field_04003481 = -1;
            return false;
        }

        private virtual OpenRA.Traits.IOrderTargeter __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E494F7264657254617267657465723E2E6765745F43757272656E74()
        {
            __cil_type_0100013B v1 = this.__il_field_04003482;
            return v1;
        }

        private virtual void __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E5265736574()
        {
            global::System.NotSupportedException v0 = __cil_newobj_0A001A01();
            throw v0;
        }

        private virtual object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74()
        {
            __cil_type_0100013B v1 = this.__il_field_04003482;
            return v1;
        }

        private virtual System.Collections.Generic.IEnumerator<OpenRA.Traits.IOrderTargeter> __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261626C653C4F70656E52412E5472616974732E494F7264657254617267657465723E2E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_d5cb43c47e96920ee7908b5463a82b2770b4c986 bytes=151280A5011284ED: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.IOrderTargeter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            OpenRA.Mods.Common.Traits.Mobile.__name_3C4F70656E52412D5472616974732D4949737375654F726465722D6765745F4F72646572733E645F5F313235 l0 = default;
            int v1 = this.__il_field_04003481;
            if (unchecked((uint)v1) != unchecked((uint)-2)) {
                goto IL_0022;
            } else {
                goto IL_000A;
            }
            IL_000A: ;
            int v4 = this.__il_field_04003483;
            int v5 = System.Environment.get_CurrentManagedThreadId();
            if (unchecked((uint)v4) != unchecked((uint)v5)) {
                goto IL_0022;
            } else {
                goto IL_0017;
            }
            IL_0017: ;
            this.__il_field_04003481 = 0;
            l0 = this;
            goto IL_0035;
            IL_0022: ;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4F70656E52412D5472616974732D4949737375654F726465722D6765745F4F72646572733E645F5F313235 v10 = __cil_newobj_06003F14(0);
            l0 = v10;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4F70656E52412D5472616974732D4949737375654F726465722D6765745F4F72646572733E645F5F313235 v11 = l0;
            global::OpenRA.Mods.Common.Traits.Mobile v13 = this.__il_field_04003484;
            v11.__il_field_04003484 = v13;
            IL_0035: ;
            global::OpenRA.Mods.Common.Traits.Mobile.__name_3C4F70656E52412D5472616974732D4949737375654F726465722D6765745F4F72646572733E645F5F313235 v14 = l0;
            return v14;
        }

        private virtual System.Collections.IEnumerator __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261626C652E476574456E756D657261746F72()
        {
            // structural signature __cil_ref_d5cb43c47e96920ee7908b5463a82b2770b4c986 bytes=151280A5011284ED: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.IOrderTargeter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_ref_d5cb43c47e96920ee7908b5463a82b2770b4c986 v1 = __cil_direct_06003F1A(this);
            return v1;
        }
        // property OpenRA.Traits.IOrderTargeter __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E494F7264657254617267657465723E2E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E47656E657269632E49456E756D657261746F723C4F70656E52412E5472616974732E494F7264657254617267657465723E2E6765745F43757272656E74; }
        // property object __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E43757272656E74 { get: __name_53797374656D2E436F6C6C656374696F6E732E49456E756D657261746F722E6765745F43757272656E74; }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.DriveInfo, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.DriveInfo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Tasks.Parallel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Tasks.Parallel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.Win32.Registry, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.Win32.Registry, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 11; exact references retained; see --details for identities and provenance.
