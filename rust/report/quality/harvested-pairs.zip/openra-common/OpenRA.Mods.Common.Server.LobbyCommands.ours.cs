namespace OpenRA.Mods.Common.Server;

public class LobbyCommands : OpenRA.Server.ServerTrait, OpenRA.Server.IInterpretCommand, OpenRA.Server.INotifyServerStart, OpenRA.Server.INotifyServerEmpty, OpenRA.Server.IClientJoined, OpenRA.Server.ITick
{
    private const string CustomRules = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0063\u0075\u0073\u0074\u006F\u006D\u002D\u0072\u0075\u006C\u0065\u0073";
    private const string OnlyHostStartGame = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u0073\u0074\u0061\u0072\u0074\u002D\u0067\u0061\u006D\u0065";
    private const string NoStartUntilRequiredSlotsFull = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006E\u006F\u002D\u0073\u0074\u0061\u0072\u0074\u002D\u0075\u006E\u0074\u0069\u006C\u002D\u0072\u0065\u0071\u0075\u0069\u0072\u0065\u0064\u002D\u0073\u006C\u006F\u0074\u0073\u002D\u0066\u0075\u006C\u006C";
    private const string NoStartWithoutPlayers = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006E\u006F\u002D\u0073\u0074\u0061\u0072\u0074\u002D\u0077\u0069\u0074\u0068\u006F\u0075\u0074\u002D\u0070\u006C\u0061\u0079\u0065\u0072\u0073";
    private const string TwoHumansRequired = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0074\u0077\u006F\u002D\u0068\u0075\u006D\u0061\u006E\u0073\u002D\u0072\u0065\u0071\u0075\u0069\u0072\u0065\u0064";
    private const string InsufficientEnabledSpawnPoints = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0069\u006E\u0073\u0075\u0066\u0066\u0069\u0063\u0069\u0065\u006E\u0074\u002D\u0065\u006E\u0061\u0062\u006C\u0065\u0064\u002D\u0073\u0070\u0061\u0077\u006E\u002D\u0070\u006F\u0069\u006E\u0074\u0073";
    private const string MalformedCommand = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006D\u0061\u006C\u0066\u006F\u0072\u006D\u0065\u0064\u002D\u0063\u006F\u006D\u006D\u0061\u006E\u0064";
    private const string KickNone = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006B\u0069\u0063\u006B\u002D\u006E\u006F\u006E\u0065";
    private const string NoKickSelf = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006B\u0069\u0063\u006B\u002D\u0073\u0065\u006C\u0066";
    private const string NoKickGameStarted = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006E\u006F\u002D\u006B\u0069\u0063\u006B\u002D\u0067\u0061\u006D\u0065\u002D\u0073\u0074\u0061\u0072\u0074\u0065\u0064";
    private const string AdminKicked = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u006B\u0069\u0063\u006B\u0065\u0064";
    private const string Kicked = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006B\u0069\u0063\u006B\u0065\u0064";
    private const string TempBan = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0074\u0065\u006D\u0070\u002D\u0062\u0061\u006E";
    private const string NoTransferAdmin = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u0074\u0072\u0061\u006E\u0073\u0066\u0065\u0072\u002D\u0061\u0064\u006D\u0069\u006E";
    private const string EmptySlot = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0065\u006D\u0070\u0074\u0079\u002D\u0073\u006C\u006F\u0074";
    private const string MoveSpectators = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006D\u006F\u0076\u0065\u002D\u0073\u0070\u0065\u0063\u0074\u0061\u0074\u006F\u0072\u0073";
    private const string Nick = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006E\u0069\u0063\u006B\u002D\u0063\u0068\u0061\u006E\u0067\u0065\u0064";
    private const string StateUnchangedReady = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0073\u0074\u0061\u0074\u0065\u002D\u0075\u006E\u0063\u0068\u0061\u006E\u0067\u0065\u0064\u002D\u0072\u0065\u0061\u0064\u0079";
    private const string StateUnchangedGameStarted = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0073\u0074\u0061\u0074\u0065\u002D\u0075\u006E\u0063\u0068\u0061\u006E\u0067\u0065\u0064\u002D\u0067\u0061\u006D\u0065\u002D\u0073\u0074\u0061\u0072\u0074\u0065\u0064";
    private const string InvalidFactionSelected = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0069\u006E\u0076\u0061\u006C\u0069\u0064\u002D\u0066\u0061\u0063\u0074\u0069\u006F\u006E\u002D\u0073\u0065\u006C\u0065\u0063\u0074\u0065\u0064";
    private const string RequiresHost = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0072\u0065\u0071\u0075\u0069\u0072\u0065\u0073\u002D\u0068\u006F\u0073\u0074";
    private const string InvalidBotSlot = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0069\u006E\u0076\u0061\u006C\u0069\u0064\u002D\u0062\u006F\u0074\u002D\u0073\u006C\u006F\u0074";
    private const string InvalidBotType = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0069\u006E\u0076\u0061\u006C\u0069\u0064\u002D\u0062\u006F\u0074\u002D\u0074\u0079\u0070\u0065";
    private const string HostChangeMap = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u0063\u0068\u0061\u006E\u0067\u0065\u002D\u006D\u0061\u0070";
    private const string UnknownMap = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0075\u006E\u006B\u006E\u006F\u0077\u006E\u002D\u006D\u0061\u0070";
    private const string SearchingMap = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0073\u0065\u0061\u0072\u0063\u0068\u0069\u006E\u0067\u002D\u006D\u0061\u0070";
    private const string NotAdmin = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u0063\u0068\u0061\u006E\u0067\u0065\u002D\u0063\u006F\u006E\u0066\u0069\u0067\u0075\u0072\u0061\u0074\u0069\u006F\u006E";
    private const string InvalidConfigurationCommand = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0069\u006E\u0076\u0061\u006C\u0069\u0064\u002D\u0063\u006F\u006E\u0066\u0069\u0067\u0075\u0072\u0061\u0074\u0069\u006F\u006E\u002D\u0063\u006F\u006D\u006D\u0061\u006E\u0064";
    private const string OptionLocked = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006F\u0070\u0074\u0069\u006F\u006E\u002D\u006C\u006F\u0063\u006B\u0065\u0064";
    private const string ChangedMap = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0063\u0068\u0061\u006E\u0067\u0065\u0064\u002D\u006D\u0061\u0070";
    private const string MapBotsDisabled = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006D\u0061\u0070\u002D\u0062\u006F\u0074\u0073\u002D\u0064\u0069\u0073\u0061\u0062\u006C\u0065\u0064";
    private const string ValueChanged = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006F\u0070\u0074\u0069\u006F\u006E\u002D\u0063\u0068\u0061\u006E\u0067\u0065\u0064";
    private const string NoMoveSpectators = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u006D\u006F\u0076\u0065\u002D\u0073\u0070\u0065\u0063\u0074\u0061\u0074\u006F\u0072\u0073";
    private const string AdminOption = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u006F\u0070\u0074\u0069\u006F\u006E";
    private const string NumberTeams = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0065\u0072\u0072\u006F\u0072\u002D\u006E\u0075\u006D\u0062\u0065\u0072\u002D\u0074\u0065\u0061\u006D\u0073";
    private const string AdminClearSpawn = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u0063\u006C\u0065\u0061\u0072\u002D\u0073\u0070\u0061\u0077\u006E";
    private const string SpawnOccupied = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0073\u0070\u0061\u0077\u006E\u002D\u006F\u0063\u0063\u0075\u0070\u0069\u0065\u0064";
    private const string SpawnLocked = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0073\u0070\u0061\u0077\u006E\u002D\u006C\u006F\u0063\u006B\u0065\u0064";
    private const string AdminLobbyInfo = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u006C\u006F\u0062\u0062\u0079\u002D\u0069\u006E\u0066\u006F";
    private const string InvalidLobbyInfo = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0069\u006E\u0076\u0061\u006C\u0069\u0064\u002D\u006C\u006F\u0062\u0062\u0079\u002D\u0069\u006E\u0066\u006F";
    private const string AdminKick = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0061\u0064\u006D\u0069\u006E\u002D\u006B\u0069\u0063\u006B";
    private const string SlotClosed = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0073\u006C\u006F\u0074\u002D\u0063\u006C\u006F\u0073\u0065\u0064";
    private const string NewAdmin = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u006E\u0065\u0077\u002D\u0061\u0064\u006D\u0069\u006E";
    private const string YouWereKicked = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0079\u006F\u0075\u002D\u0077\u0065\u0072\u0065\u002D\u006B\u0069\u0063\u006B\u0065\u0064";
    private const string VoteKickDisabled = "\u006E\u006F\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006F\u006E\u002D\u0076\u006F\u0074\u0065\u002D\u006B\u0069\u0063\u006B\u002D\u0064\u0069\u0073\u0061\u0062\u006C\u0065\u0064";
    private readonly System.Collections.Generic.IDictionary<string, System.Func<OpenRA.Server.Server, OpenRA.Server.Connection, OpenRA.Network.Session.Client, string, bool>> commandHandlers;

    private static bool ValidateSlotCommand(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string arg, bool requiresHost)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 02, 7B, 72, 05, 00, 0A, 7B]
        // .code-bytes IL_0018: [74, 05, 00, 0A, 05, 6F, 75, 05, 00, 0A, 2D, 19, 72, C5, D1, 00, 70, 72, D3, D1, 00, 70, 05, 28]
        // .code-bytes IL_0030: [44, 02, 00, 0A, 28, 76, 05, 00, 0A, 16, 0C, DE, 2B, 0E, 04, 2C, 19, 04, 7B, 77, 05, 00, 0A, 2D]
        // .code-bytes IL_0048: [11, 02, 03, 72, F1, D1, 00, 70, 14, 6F, 78, 05, 00, 0A, 16, 0C, DE, 0E, 17, 0C, DE, 0A, 07, 2C]
        // .code-bytes IL_0060: [06, 06, 28, 79, 05, 00, 0A, DC, 08, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.0 0
        // IL_0012: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0017: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_001C: ldarg.3 3
        // IL_001D: callvirt 0x0A000575 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::ContainsKey
        // IL_0022: brtrue.s IL_003D
        // IL_0024: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0029: ldstr 0x7000D1D3 [73, 110, 118, 97, 108, 105, 100, 32, 115, 108, 111, 116, 58, 32] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 73, 00, 6C, 00, 6F, 00, 74, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_002E: ldarg.3 3
        // IL_002F: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_0034: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_0039: ldc.i4.0 0
        // IL_003A: stloc.2 2
        // IL_003B: leave.s IL_0068
        // IL_003D: ldarg.s 4
        // IL_003F: brfalse.s IL_005A
        // IL_0041: ldarg.2 2
        // IL_0042: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0047: brtrue.s IL_005A
        // IL_0049: ldarg.0 0
        // IL_004A: ldarg.1 1
        // IL_004B: ldstr 0x7000D1F1 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 114, 101, 113, 117, 105, 114, 101, 115, 45, 104, 111, 115, 116] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 72, 00, 65, 00, 71, 00, 75, 00, 69, 00, 72, 00, 65, 00, 73, 00, 2D, 00, 68, 00, 6F, 00, 73, 00, 74, 00] terminal-flag=Some(1)
        // IL_0050: ldnull 
        // IL_0051: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0056: ldc.i4.0 0
        // IL_0057: stloc.2 2
        // IL_0058: leave.s IL_0068
        // IL_005A: ldc.i4.1 1
        // IL_005B: stloc.2 2
        // IL_005C: leave.s IL_0068
        // IL_005E: ldloc.1 1
        // IL_005F: brfalse.s IL_0067
        // IL_0061: ldloc.0 0
        // IL_0062: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0067: endfinally 
        // IL_0068: ldloc.2 2
        // IL_0069: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 85, handler_offset: 94, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_005E finally IL_005E..IL_0068
    }

    public static bool ValidateCommand(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string command)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 05, 72, 27, D2, 00, 70, 1A]
        // .code-bytes IL_0018: [6F, EE, 02, 00, 0A, 2D, 0E, 05, 72, 33, D2, 00, 70, 1A, 6F, EE, 02, 00, 0A, 2C, 04, 17, 0C, DE]
        // .code-bytes IL_0030: [6E, 02, 6F, 7A, 05, 00, 0A, 18, 33, 22, 02, 03, 72, 49, D2, 00, 70, 18, 8D, 12, 00, 00, 01, 25]
        // .code-bytes IL_0048: [16, 72, 9D, D2, 00, 70, A2, 25, 17, 05, A2, 6F, 78, 05, 00, 0A, 16, 0C, DE, 43, 04, 7B, 7B, 05]
        // .code-bytes IL_0060: [00, 0A, 18, 33, 2C, 05, 72, 31, 09, 00, 70, 1A, 6F, EE, 02, 00, 0A, 2D, 1E, 05, 72, AD, D2, 00]
        // .code-bytes IL_0078: [70, 28, BD, 02, 00, 0A, 2D, 11, 02, 03, 72, C1, D2, 00, 70, 14, 6F, 78, 05, 00, 0A, 16, 0C, DE]
        // .code-bytes IL_0090: [0E, 17, 0C, DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00, 0A, DC, 08, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.3 3
        // IL_0012: ldstr 0x7000D227 [107, 105, 99, 107, 32] utf16-bytes=[6B, 00, 69, 00, 63, 00, 6B, 00, 20, 00] terminal-flag=Some(0)
        // IL_0017: ldc.i4.4 4
        // IL_0018: callvirt 0x0A0002EE [System.Runtime]System.String::StartsWith
        // IL_001D: brtrue.s IL_002D
        // IL_001F: ldarg.3 3
        // IL_0020: ldstr 0x7000D233 [118, 111, 116, 101, 95, 107, 105, 99, 107, 32] utf16-bytes=[76, 00, 6F, 00, 74, 00, 65, 00, 5F, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 20, 00] terminal-flag=Some(0)
        // IL_0025: ldc.i4.4 4
        // IL_0026: callvirt 0x0A0002EE [System.Runtime]System.String::StartsWith
        // IL_002B: brfalse.s IL_0031
        // IL_002D: ldc.i4.1 1
        // IL_002E: stloc.2 2
        // IL_002F: leave.s IL_009F
        // IL_0031: ldarg.0 0
        // IL_0032: callvirt 0x0A00057A [OpenRA.Game]OpenRA.Server.Server::get_State
        // IL_0037: ldc.i4.2 2
        // IL_0038: bne.un.s IL_005C
        // IL_003A: ldarg.0 0
        // IL_003B: ldarg.1 1
        // IL_003C: ldstr 0x7000D249 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 115, 116, 97, 116, 101, 45, 117, 110, 99, 104, 97, 110, 103, 101, 100, 45, 103, 97, 109, 101, 45, 115, 116, 97, 114, 116, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 73, 00, 74, 00, 61, 00, 74, 00, 65, 00, 2D, 00, 75, 00, 6E, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 64, 00, 2D, 00, 67, 00, 61, 00, 6D, 00, 65, 00, 2D, 00, 73, 00, 74, 00, 61, 00, 72, 00, 74, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_0041: ldc.i4.2 2
        // IL_0042: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0047: dup 
        // IL_0048: ldc.i4.0 0
        // IL_0049: ldstr 0x7000D29D [99, 111, 109, 109, 97, 110, 100] utf16-bytes=[63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_004E: stelem.ref 
        // IL_004F: dup 
        // IL_0050: ldc.i4.1 1
        // IL_0051: ldarg.3 3
        // IL_0052: stelem.ref 
        // IL_0053: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0058: ldc.i4.0 0
        // IL_0059: stloc.2 2
        // IL_005A: leave.s IL_009F
        // IL_005C: ldarg.2 2
        // IL_005D: ldfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0062: ldc.i4.2 2
        // IL_0063: bne.un.s IL_0091
        // IL_0065: ldarg.3 3
        // IL_0066: ldstr 0x70000931 [115, 116, 97, 116, 101] utf16-bytes=[73, 00, 74, 00, 61, 00, 74, 00, 65, 00] terminal-flag=Some(0)
        // IL_006B: ldc.i4.4 4
        // IL_006C: callvirt 0x0A0002EE [System.Runtime]System.String::StartsWith
        // IL_0071: brtrue.s IL_0091
        // IL_0073: ldarg.3 3
        // IL_0074: ldstr 0x7000D2AD [115, 116, 97, 114, 116, 103, 97, 109, 101] utf16-bytes=[73, 00, 74, 00, 61, 00, 72, 00, 74, 00, 67, 00, 61, 00, 6D, 00, 65, 00] terminal-flag=Some(0)
        // IL_0079: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_007E: brtrue.s IL_0091
        // IL_0080: ldarg.0 0
        // IL_0081: ldarg.1 1
        // IL_0082: ldstr 0x7000D2C1 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 115, 116, 97, 116, 101, 45, 117, 110, 99, 104, 97, 110, 103, 101, 100, 45, 114, 101, 97, 100, 121] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 73, 00, 74, 00, 61, 00, 74, 00, 65, 00, 2D, 00, 75, 00, 6E, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 64, 00, 2D, 00, 72, 00, 65, 00, 61, 00, 64, 00, 79, 00] terminal-flag=Some(1)
        // IL_0087: ldnull 
        // IL_0088: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_008D: ldc.i4.0 0
        // IL_008E: stloc.2 2
        // IL_008F: leave.s IL_009F
        // IL_0091: ldc.i4.1 1
        // IL_0092: stloc.2 2
        // IL_0093: leave.s IL_009F
        // IL_0095: ldloc.1 1
        // IL_0096: brfalse.s IL_009E
        // IL_0098: ldloc.0 0
        // IL_0099: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_009E: endfinally 
        // IL_009F: ldloc.2 2
        // IL_00A0: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 140, handler_offset: 149, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_0095 finally IL_0095..IL_009F
    }

    public virtual bool InterpretCommand(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string cmd)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [03, 2C, 12, 04, 2C, 0F, 05, 2C, 0C, 03, 04, 05, 0E, 04, 28, 22, 03, 00, 06, 2D, 02, 16, 2A, 0E]
        // .code-bytes IL_0018: [04, 1F, 20, 16, 6F, CC, 01, 00, 0A, 28, 1C, 00, 00, 2B, 0A, 0E, 04, 1F, 20, 16, 6F, CC, 01, 00]
        // .code-bytes IL_0030: [0A, 17, 28, 8B, 00, 00, 2B, 72, 27, 36, 00, 70, 28, 5D, 00, 00, 2B, 0B, 02, 7B, 42, 01, 00, 04]
        // .code-bytes IL_0048: [06, 12, 02, 6F, 7C, 05, 00, 0A, 2D, 02, 16, 2A, 08, 03, 04, 05, 07, 6F, 7D, 05, 00, 0A, 2A]
        // .local [0] string
        // .local [1] string
        // .local [2] class [System.Runtime]System.Func`5<class [OpenRA.Game]OpenRA.Server.Server, class [OpenRA.Game]OpenRA.Server.Connection, class [OpenRA.Game]OpenRA.Network.Session/Client, string, bool>
        // IL_0000: ldarg.1 1
        // IL_0001: brfalse.s IL_0015
        // IL_0003: ldarg.2 2
        // IL_0004: brfalse.s IL_0015
        // IL_0006: ldarg.3 3
        // IL_0007: brfalse.s IL_0015
        // IL_0009: ldarg.1 1
        // IL_000A: ldarg.2 2
        // IL_000B: ldarg.3 3
        // IL_000C: ldarg.s 4
        // IL_000E: call 0x06000322 OpenRA.Mods.Common.Server.LobbyCommands::ValidateCommand
        // IL_0013: brtrue.s IL_0017
        // IL_0015: ldc.i4.0 0
        // IL_0016: ret 
        // IL_0017: ldarg.s 4
        // IL_0019: ldc.i4.s 32
        // IL_001B: ldc.i4.0 0
        // IL_001C: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_0021: call 0x2B00001C [System.Linq]System.Linq.Enumerable::First<string>
        // IL_0026: stloc.0 0
        // IL_0027: ldarg.s 4
        // IL_0029: ldc.i4.s 32
        // IL_002B: ldc.i4.0 0
        // IL_002C: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_0031: ldc.i4.1 1
        // IL_0032: call 0x2B00008B [System.Linq]System.Linq.Enumerable::Skip<string>
        // IL_0037: ldstr 0x70003627 [32] utf16-bytes=[20, 00] terminal-flag=Some(0)
        // IL_003C: call 0x2B00005D [OpenRA.Game]OpenRA.Exts::JoinWith<string>
        // IL_0041: stloc.1 1
        // IL_0042: ldarg.0 0
        // IL_0043: ldfld 0x04000142 OpenRA.Mods.Common.Server.LobbyCommands::commandHandlers
        // IL_0048: ldloc.0 0
        // IL_0049: ldloca.s 2
        // IL_004B: callvirt 0x0A00057C class [System.Runtime]System.Collections.Generic.IDictionary`2<string, class [System.Runtime]System.Func`5<class [OpenRA.Game]OpenRA.Server.Server, class [OpenRA.Game]OpenRA.Server.Connection, class [OpenRA.Game]OpenRA.Network.Session/Client, string, bool>>::TryGetValue
        // IL_0050: brtrue.s IL_0054
        // IL_0052: ldc.i4.0 0
        // IL_0053: ret 
        // IL_0054: ldloc.2 2
        // IL_0055: ldarg.1 1
        // IL_0056: ldarg.2 2
        // IL_0057: ldarg.3 3
        // IL_0058: ldloc.1 1
        // IL_0059: callvirt 0x0A00057D class [System.Runtime]System.Func`5<class [OpenRA.Game]OpenRA.Server.Server, class [OpenRA.Game]OpenRA.Server.Connection, class [OpenRA.Game]OpenRA.Network.Session/Client, string, bool>::Invoke
        // IL_005E: ret 
    }

    private static void CheckAutoStart(OpenRA.Server.Server server)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [73, 56, 29, 00, 06, 0A, 06, 02, 7D, F8, 21, 00, 04, 06, 7B, F8, 21, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 06, 7B, F8, 21, 00, 04, 7B, 72, 05, 00, 0A, 6F, 7E]
        // .code-bytes IL_0030: [05, 00, 0A, 0D, 09, 7E, DA, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 38, 29, 00]
        // .code-bytes IL_0048: [06, 73, 7F, 05, 00, 0A, 25, 80, DA, 21, 00, 04, 28, E7, 00, 00, 2B, 2D, 3C, 06, 7B, F8, 21, 00]
        // .code-bytes IL_0060: [04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 7E, DB, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00]
        // .code-bytes IL_0078: [04, FE, 06, 39, 29, 00, 06, 73, 7F, 05, 00, 0A, 25, 80, DB, 21, 00, 04, 28, E8, 00, 00, 2B, 7B]
        // .code-bytes IL_0090: [7B, 05, 00, 0A, 18, 2E, 05, DD, 7F, 01, 00, 00, 06, 7B, F8, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B]
        // .code-bytes IL_00A8: [81, 05, 00, 0A, 7B, 82, 05, 00, 0A, 2D, 0E, 09, 28, E9, 00, 00, 2B, 18, 2F, 05, DD, 5A, 01, 00]
        // .code-bytes IL_00C0: [00, 06, 7B, F8, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 06, FE, 06, 57, 29, 00, 06]
        // .code-bytes IL_00D8: [73, 83, 05, 00, 0A, 28, EA, 00, 00, 2B, 2C, 05, DD, 32, 01, 00, 00, 06, 7B, F8, 21, 00, 04, 7B]
        // .code-bytes IL_00F0: [72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 06, FE, 06, 58, 29, 00, 06, 73, 83, 05, 00, 0A, 28, EB, 00]
        // .code-bytes IL_0108: [00, 2B, 2C, 05, DD, 0A, 01, 00, 00, 06, 7B, F8, 21, 00, 04, 7B, 84, 05, 00, 0A, 19, 3B, C3, 00]
        // .code-bytes IL_0120: [00, 00, 06, 7B, F8, 21, 00, 04, 7B, 85, 05, 00, 0A, 7B, 21, 03, 00, 0A, 06, 7B, F8, 21, 00, 04]
        // .code-bytes IL_0138: [7B, 86, 05, 00, 0A, 7B, 87, 05, 00, 0A, 6F, 88, 05, 00, 0A, 6F, 89, 05, 00, 0A, 39, 94, 00, 00]
        // .code-bytes IL_0150: [00, 06, 7B, F8, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 7E, DC, 21, 00, 04, 25, 2D]
        // .code-bytes IL_0168: [17, 26, 7E, D9, 21, 00, 04, FE, 06, 3A, 29, 00, 06, 73, 8A, 05, 00, 0A, 25, 80, DC, 21, 00, 04]
        // .code-bytes IL_0180: [28, EC, 00, 00, 2B, 13, 04, 11, 04, 2C, 0A, 11, 04, 16, 7D, 7B, 05, 00, 0A, 2B, 43, 06, 7B, F8]
        // .code-bytes IL_0198: [21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 6F, 8B, 05, 00, 0A, 13, 05, 2B, 11, 12, 05]
        // .code-bytes IL_01B0: [28, 8C, 05, 00, 0A, 13, 06, 11, 06, 16, 7D, 7B, 05, 00, 0A, 12, 05, 28, 8D, 05, 00, 0A, 2D, E6]
        // .code-bytes IL_01C8: [DE, 0E, 12, 05, FE, 16, C5, 02, 00, 1B, 6F, 1A, 00, 00, 0A, DC, 06, 7B, F8, 21, 00, 04, 6F, 8E]
        // .code-bytes IL_01E0: [05, 00, 0A, DE, 36, 06, 7B, F8, 21, 00, 04, 7B, 86, 05, 00, 0A, 06, 7B, F8, 21, 00, 04, 7B, 72]
        // .code-bytes IL_01F8: [05, 00, 0A, 28, A2, 0D, 00, 06, 2C, 02, DE, 17, 06, 7B, F8, 21, 00, 04, 6F, 8F, 05, 00, 0A, DE]
        // .code-bytes IL_0210: [0A, 08, 2C, 06, 07, 28, 79, 05, 00, 0A, DC, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [4] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [5] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [6] class [OpenRA.Game]OpenRA.Network.Session/Client
        // IL_0000: newobj 0x06002956 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldloc.0 0
        // IL_0024: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_0029: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_002E: callvirt 0x0A00057E [OpenRA.Game]OpenRA.Network.Session::get_NonBotPlayers
        // IL_0033: stloc.3 3
        // IL_0034: ldloc.3 3
        // IL_0035: ldsfld 0x040021DA OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__49_0
        // IL_003A: dup 
        // IL_003B: brtrue.s IL_0054
        // IL_003D: pop 
        // IL_003E: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0043: ldftn 0x06002938 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<CheckAutoStart>b__49_0
        // IL_0049: newobj 0x0A00057F class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, bool>::.ctor
        // IL_004E: dup 
        // IL_004F: stsfld 0x040021DA OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__49_0
        // IL_0054: call 0x2B0000E7 [System.Linq]System.Linq.Enumerable::Any<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_0059: brtrue.s IL_0097
        // IL_005B: ldloc.0 0
        // IL_005C: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_0061: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0066: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_006B: ldsfld 0x040021DB OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__49_1
        // IL_0070: dup 
        // IL_0071: brtrue.s IL_008A
        // IL_0073: pop 
        // IL_0074: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0079: ldftn 0x06002939 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<CheckAutoStart>b__49_1
        // IL_007F: newobj 0x0A00057F class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, bool>::.ctor
        // IL_0084: dup 
        // IL_0085: stsfld 0x040021DB OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__49_1
        // IL_008A: call 0x2B0000E8 [System.Linq]System.Linq.Enumerable::First<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_008F: ldfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0094: ldc.i4.2 2
        // IL_0095: beq.s IL_009C
        // IL_0097: leave IL_021B
        // IL_009C: ldloc.0 0
        // IL_009D: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_00A2: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00A7: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_00AC: ldfld 0x0A000582 [OpenRA.Game]OpenRA.Network.Session/Global::EnableSingleplayer
        // IL_00B1: brtrue.s IL_00C1
        // IL_00B3: ldloc.3 3
        // IL_00B4: call 0x2B0000E9 [System.Linq]System.Linq.Enumerable::Count<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00B9: ldc.i4.2 2
        // IL_00BA: bge.s IL_00C1
        // IL_00BC: leave IL_021B
        // IL_00C1: ldloc.0 0
        // IL_00C2: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_00C7: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00CC: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_00D1: ldloc.0 0
        // IL_00D2: ldftn 0x06002957 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::<CheckAutoStart>b__2
        // IL_00D8: newobj 0x0A000583 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, bool>::.ctor
        // IL_00DD: call 0x2B0000EA [System.Linq]System.Linq.Enumerable::Any<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>>
        // IL_00E2: brfalse.s IL_00E9
        // IL_00E4: leave IL_021B
        // IL_00E9: ldloc.0 0
        // IL_00EA: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_00EF: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00F4: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_00F9: ldloc.0 0
        // IL_00FA: ldftn 0x06002958 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::<CheckAutoStart>b__3
        // IL_0100: newobj 0x0A000583 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, bool>::.ctor
        // IL_0105: call 0x2B0000EB [System.Linq]System.Linq.Enumerable::All<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>>
        // IL_010A: brfalse.s IL_0111
        // IL_010C: leave IL_021B
        // IL_0111: ldloc.0 0
        // IL_0112: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_0117: ldfld 0x0A000584 [OpenRA.Game]OpenRA.Server.Server::Type
        // IL_011C: ldc.i4.3 3
        // IL_011D: beq IL_01E5
        // IL_0122: ldloc.0 0
        // IL_0123: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_0128: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_012D: ldfld 0x0A000321 [OpenRA.Game]OpenRA.ModData::MapCache
        // IL_0132: ldloc.0 0
        // IL_0133: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_0138: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_013D: ldfld 0x0A000587 [OpenRA.Game]OpenRA.MapPreview::Uid
        // IL_0142: callvirt 0x0A000588 [OpenRA.Game]OpenRA.MapCache::get_Item
        // IL_0147: callvirt 0x0A000589 [OpenRA.Game]OpenRA.MapPreview::get_Status
        // IL_014C: brfalse IL_01E5
        // IL_0151: ldloc.0 0
        // IL_0152: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_0157: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_015C: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_0161: ldsfld 0x040021DC OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__49_4
        // IL_0166: dup 
        // IL_0167: brtrue.s IL_0180
        // IL_0169: pop 
        // IL_016A: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_016F: ldftn 0x0600293A OpenRA.Mods.Common.Server.LobbyCommands/<>c::<CheckAutoStart>b__49_4
        // IL_0175: newobj 0x0A00058A class [System.Runtime]System.Predicate`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::.ctor
        // IL_017A: dup 
        // IL_017B: stsfld 0x040021DC OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__49_4
        // IL_0180: call 0x2B0000EC [OpenRA.Game]OpenRA.Exts::FirstOrDefault<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_0185: stloc.s 4
        // IL_0187: ldloc.s 4
        // IL_0189: brfalse.s IL_0195
        // IL_018B: ldloc.s 4
        // IL_018D: ldc.i4.0 0
        // IL_018E: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0193: br.s IL_01D8
        // IL_0195: ldloc.0 0
        // IL_0196: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_019B: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_01A0: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_01A5: callvirt 0x0A00058B class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::GetEnumerator
        // IL_01AA: stloc.s 5
        // IL_01AC: br.s IL_01BF
        // IL_01AE: ldloca.s 5
        // IL_01B0: call 0x0A00058C valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Current
        // IL_01B5: stloc.s 6
        // IL_01B7: ldloc.s 6
        // IL_01B9: ldc.i4.0 0
        // IL_01BA: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_01BF: ldloca.s 5
        // IL_01C1: call 0x0A00058D valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::MoveNext
        // IL_01C6: brtrue.s IL_01AE
        // IL_01C8: leave.s IL_01D8
        // IL_01CA: ldloca.s 5
        // IL_01CC: constrained. 0x1B0002C5 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_01D2: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_01D7: endfinally 
        // IL_01D8: ldloc.0 0
        // IL_01D9: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_01DE: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_01E3: leave.s IL_021B
        // IL_01E5: ldloc.0 0
        // IL_01E6: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_01EB: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_01F0: ldloc.0 0
        // IL_01F1: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_01F6: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_01FB: call 0x06000DA2 OpenRA.Mods.Common.Widgets.Logic.LobbyUtils::InsufficientEnabledSpawnPoints
        // IL_0200: brfalse.s IL_0204
        // IL_0202: leave.s IL_021B
        // IL_0204: ldloc.0 0
        // IL_0205: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
        // IL_020A: callvirt 0x0A00058F [OpenRA.Game]OpenRA.Server.Server::StartGame
        // IL_020F: leave.s IL_021B
        // IL_0211: ldloc.2 2
        // IL_0212: brfalse.s IL_021A
        // IL_0214: ldloc.1 1
        // IL_0215: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_021A: endfinally 
        // IL_021B: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 428, try_length: 30, handler_offset: 458, handler_length: 14, raw_flags: 2 }
        // .try IL_01AC..IL_01CA finally IL_01CA..IL_01D8
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 502, handler_offset: 529, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_0211 finally IL_0211..IL_021B
    }

    private static bool State(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 05, 16, 12, 02, 28, 90, 05]
        // .code-bytes IL_0018: [00, 0A, 2D, 26, 02, 03, 72, 07, D3, 00, 70, 18, 8D, 12, 00, 00, 01, 25, 16, 72, 9D, D2, 00, 70]
        // .code-bytes IL_0030: [A2, 25, 17, 72, 31, 09, 00, 70, A2, 6F, 78, 05, 00, 0A, 17, 0D, DE, 6E, 04, 08, 7D, 7B, 05, 00]
        // .code-bytes IL_0048: [0A, 72, C5, D1, 00, 70, 1F, 0C, 18, 73, FA, 02, 00, 0A, 13, 04, 12, 04, 72, 45, D3, 00, 70, 28]
        // .code-bytes IL_0060: [FB, 02, 00, 0A, 12, 04, 03, 7B, 91, 05, 00, 0A, 28, ED, 00, 00, 2B, 12, 04, 72, 57, D3, 00, 70]
        // .code-bytes IL_0078: [28, FB, 02, 00, 0A, 12, 04, 04, 7B, 7B, 05, 00, 0A, 28, EE, 00, 00, 2B, 12, 04, 28, FD, 02, 00]
        // .code-bytes IL_0090: [0A, 28, 76, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 02, 28, 24, 03, 00, 06, 17, 0D, DE, 0A, 07, 2C]
        // .code-bytes IL_00A8: [06, 06, 28, 79, 05, 00, 0A, DC, 09, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] valuetype [OpenRA.Game]OpenRA.Network.Session/ClientState
        // .local [3] bool
        // .local [4] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.3 3
        // IL_0012: ldc.i4.0 0
        // IL_0013: ldloca.s 2
        // IL_0015: call 0x0A000590 class [OpenRA.Game]OpenRA.Enum`1<valuetype [OpenRA.Game]OpenRA.Network.Session/ClientState>::TryParse
        // IL_001A: brtrue.s IL_0042
        // IL_001C: ldarg.0 0
        // IL_001D: ldarg.1 1
        // IL_001E: ldstr 0x7000D307 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 97, 108, 102, 111, 114, 109, 101, 100, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 61, 00, 6C, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 65, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_0023: ldc.i4.2 2
        // IL_0024: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0029: dup 
        // IL_002A: ldc.i4.0 0
        // IL_002B: ldstr 0x7000D29D [99, 111, 109, 109, 97, 110, 100] utf16-bytes=[63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_0030: stelem.ref 
        // IL_0031: dup 
        // IL_0032: ldc.i4.1 1
        // IL_0033: ldstr 0x70000931 [115, 116, 97, 116, 101] utf16-bytes=[73, 00, 74, 00, 61, 00, 74, 00, 65, 00] terminal-flag=Some(0)
        // IL_0038: stelem.ref 
        // IL_0039: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_003E: ldc.i4.1 1
        // IL_003F: stloc.3 3
        // IL_0040: leave.s IL_00B0
        // IL_0042: ldarg.2 2
        // IL_0043: ldloc.2 2
        // IL_0044: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0049: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_004E: ldc.i4.s 12
        // IL_0050: ldc.i4.2 2
        // IL_0051: newobj 0x0A0002FA [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0056: stloc.s 4
        // IL_0058: ldloca.s 4
        // IL_005A: ldstr 0x7000D345 [80, 108, 97, 121, 101, 114, 32, 64] utf16-bytes=[50, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00, 20, 00, 40, 00] terminal-flag=Some(0)
        // IL_005F: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0064: ldloca.s 4
        // IL_0066: ldarg.1 1
        // IL_0067: ldfld 0x0A000591 [OpenRA.Game]OpenRA.Server.Connection::EndPoint
        // IL_006C: call 0x2B0000ED [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<class [System.Net.Primitives]System.Net.EndPoint>
        // IL_0071: ldloca.s 4
        // IL_0073: ldstr 0x7000D357 [32, 105, 115, 32] utf16-bytes=[20, 00, 69, 00, 73, 00, 20, 00] terminal-flag=Some(0)
        // IL_0078: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_007D: ldloca.s 4
        // IL_007F: ldarg.2 2
        // IL_0080: ldfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0085: call 0x2B0000EE [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<valuetype [OpenRA.Game]OpenRA.Network.Session/ClientState>
        // IL_008A: ldloca.s 4
        // IL_008C: call 0x0A0002FD [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0091: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_0096: ldarg.0 0
        // IL_0097: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_009C: ldarg.0 0
        // IL_009D: call 0x06000324 OpenRA.Mods.Common.Server.LobbyCommands::CheckAutoStart
        // IL_00A2: ldc.i4.1 1
        // IL_00A3: stloc.3 3
        // IL_00A4: leave.s IL_00B0
        // IL_00A6: ldloc.1 1
        // IL_00A7: brfalse.s IL_00AF
        // IL_00A9: ldloc.0 0
        // IL_00AA: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00AF: endfinally 
        // IL_00B0: ldloc.3 3
        // IL_00B1: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 157, handler_offset: 166, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00A6 finally IL_00A6..IL_00B0
    }

    private static bool StartGame(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [73, 59, 29, 00, 06, 0A, 06, 02, 7D, F9, 21, 00, 04, 06, 7B, F9, 21, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 04, 7B, 77, 05, 00, 0A, 2D, 19, 06, 7B, F9, 21, 00]
        // .code-bytes IL_0030: [04, 03, 72, 61, D3, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 0D, DD, 0D, 01, 00, 00, 06, 7B, F9, 21]
        // .code-bytes IL_0048: [00, 04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 06, FE, 06, 5A, 29, 00, 06, 73, 83, 05, 00, 0A]
        // .code-bytes IL_0060: [28, EA, 00, 00, 2B, 2C, 19, 06, 7B, F9, 21, 00, 04, 03, 72, 9D, D3, 00, 70, 14, 6F, 78, 05, 00]
        // .code-bytes IL_0078: [0A, 17, 0D, DD, D1, 00, 00, 00, 06, 7B, F9, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A]
        // .code-bytes IL_0090: [06, FE, 06, 5B, 29, 00, 06, 73, 83, 05, 00, 0A, 28, EB, 00, 00, 2B, 2C, 1D, 06, 7B, F9, 21, 00]
        // .code-bytes IL_00A8: [04, 03, 72, FD, D3, 00, 70, 72, 0D, D4, 00, 70, 6F, 92, 05, 00, 0A, 17, 0D, DD, 91, 00, 00, 00]
        // .code-bytes IL_00C0: [06, 7B, F9, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 7B, 82, 05, 00, 0A, 2D, 2E, 06]
        // .code-bytes IL_00D8: [7B, F9, 21, 00, 04, 7B, 72, 05, 00, 0A, 6F, 7E, 05, 00, 0A, 28, E9, 00, 00, 2B, 18, 2F, 16, 06]
        // .code-bytes IL_00F0: [7B, F9, 21, 00, 04, 03, 72, 59, D4, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 0D, DE, 4C, 06, 7B, F9]
        // .code-bytes IL_0108: [21, 00, 04, 7B, 86, 05, 00, 0A, 06, 7B, F9, 21, 00, 04, 7B, 72, 05, 00, 0A, 28, A2, 0D, 00, 06]
        // .code-bytes IL_0120: [2C, 16, 06, 7B, F9, 21, 00, 04, 03, 72, 9B, D4, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 0D, DE, 19]
        // .code-bytes IL_0138: [06, 7B, F9, 21, 00, 04, 6F, 8F, 05, 00, 0A, 17, 0D, DE, 0A, 08, 2C, 06, 07, 28, 79, 05, 00, 0A]
        // .code-bytes IL_0150: [DC, 09, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] bool
        // IL_0000: newobj 0x06002959 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldarg.2 2
        // IL_0024: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0029: brtrue.s IL_0044
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_0031: ldarg.1 1
        // IL_0032: ldstr 0x7000D361 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 115, 116, 97, 114, 116, 45, 103, 97, 109, 101] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 73, 00, 74, 00, 61, 00, 72, 00, 74, 00, 2D, 00, 67, 00, 61, 00, 6D, 00, 65, 00] terminal-flag=Some(1)
        // IL_0037: ldnull 
        // IL_0038: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_003D: ldc.i4.1 1
        // IL_003E: stloc.3 3
        // IL_003F: leave IL_0151
        // IL_0044: ldloc.0 0
        // IL_0045: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_004A: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_004F: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0054: ldloc.0 0
        // IL_0055: ldftn 0x0600295A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::<StartGame>b__0
        // IL_005B: newobj 0x0A000583 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, bool>::.ctor
        // IL_0060: call 0x2B0000EA [System.Linq]System.Linq.Enumerable::Any<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>>
        // IL_0065: brfalse.s IL_0080
        // IL_0067: ldloc.0 0
        // IL_0068: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_006D: ldarg.1 1
        // IL_006E: ldstr 0x7000D39D [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 110, 111, 45, 115, 116, 97, 114, 116, 45, 117, 110, 116, 105, 108, 45, 114, 101, 113, 117, 105, 114, 101, 100, 45, 115, 108, 111, 116, 115, 45, 102, 117, 108, 108] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6E, 00, 6F, 00, 2D, 00, 73, 00, 74, 00, 61, 00, 72, 00, 74, 00, 2D, 00, 75, 00, 6E, 00, 74, 00, 69, 00, 6C, 00, 2D, 00, 72, 00, 65, 00, 71, 00, 75, 00, 69, 00, 72, 00, 65, 00, 64, 00, 2D, 00, 73, 00, 6C, 00, 6F, 00, 74, 00, 73, 00, 2D, 00, 66, 00, 75, 00, 6C, 00, 6C, 00] terminal-flag=Some(1)
        // IL_0073: ldnull 
        // IL_0074: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0079: ldc.i4.1 1
        // IL_007A: stloc.3 3
        // IL_007B: leave IL_0151
        // IL_0080: ldloc.0 0
        // IL_0081: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_0086: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_008B: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0090: ldloc.0 0
        // IL_0091: ldftn 0x0600295B OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::<StartGame>b__1
        // IL_0097: newobj 0x0A000583 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, bool>::.ctor
        // IL_009C: call 0x2B0000EB [System.Linq]System.Linq.Enumerable::All<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>>
        // IL_00A1: brfalse.s IL_00C0
        // IL_00A3: ldloc.0 0
        // IL_00A4: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_00A9: ldarg.1 1
        // IL_00AA: ldstr 0x7000D3FD [77, 101, 115, 115, 97, 103, 101] utf16-bytes=[4D, 00, 65, 00, 73, 00, 73, 00, 61, 00, 67, 00, 65, 00] terminal-flag=Some(0)
        // IL_00AF: ldstr 0x7000D40D [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 110, 111, 45, 115, 116, 97, 114, 116, 45, 119, 105, 116, 104, 111, 117, 116, 45, 112, 108, 97, 121, 101, 114, 115] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6E, 00, 6F, 00, 2D, 00, 73, 00, 74, 00, 61, 00, 72, 00, 74, 00, 2D, 00, 77, 00, 69, 00, 74, 00, 68, 00, 6F, 00, 75, 00, 74, 00, 2D, 00, 70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00, 73, 00] terminal-flag=Some(1)
        // IL_00B4: callvirt 0x0A000592 [OpenRA.Game]OpenRA.Server.Server::SendOrderTo
        // IL_00B9: ldc.i4.1 1
        // IL_00BA: stloc.3 3
        // IL_00BB: leave IL_0151
        // IL_00C0: ldloc.0 0
        // IL_00C1: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_00C6: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00CB: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_00D0: ldfld 0x0A000582 [OpenRA.Game]OpenRA.Network.Session/Global::EnableSingleplayer
        // IL_00D5: brtrue.s IL_0105
        // IL_00D7: ldloc.0 0
        // IL_00D8: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_00DD: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00E2: callvirt 0x0A00057E [OpenRA.Game]OpenRA.Network.Session::get_NonBotPlayers
        // IL_00E7: call 0x2B0000E9 [System.Linq]System.Linq.Enumerable::Count<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00EC: ldc.i4.2 2
        // IL_00ED: bge.s IL_0105
        // IL_00EF: ldloc.0 0
        // IL_00F0: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_00F5: ldarg.1 1
        // IL_00F6: ldstr 0x7000D459 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 116, 119, 111, 45, 104, 117, 109, 97, 110, 115, 45, 114, 101, 113, 117, 105, 114, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 74, 00, 77, 00, 6F, 00, 2D, 00, 68, 00, 75, 00, 6D, 00, 61, 00, 6E, 00, 73, 00, 2D, 00, 72, 00, 65, 00, 71, 00, 75, 00, 69, 00, 72, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_00FB: ldnull 
        // IL_00FC: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0101: ldc.i4.1 1
        // IL_0102: stloc.3 3
        // IL_0103: leave.s IL_0151
        // IL_0105: ldloc.0 0
        // IL_0106: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_010B: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0110: ldloc.0 0
        // IL_0111: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_0116: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_011B: call 0x06000DA2 OpenRA.Mods.Common.Widgets.Logic.LobbyUtils::InsufficientEnabledSpawnPoints
        // IL_0120: brfalse.s IL_0138
        // IL_0122: ldloc.0 0
        // IL_0123: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_0128: ldarg.1 1
        // IL_0129: ldstr 0x7000D49B [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 105, 110, 115, 117, 102, 102, 105, 99, 105, 101, 110, 116, 45, 101, 110, 97, 98, 108, 101, 100, 45, 115, 112, 97, 119, 110, 45, 112, 111, 105, 110, 116, 115] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 69, 00, 6E, 00, 73, 00, 75, 00, 66, 00, 66, 00, 69, 00, 63, 00, 69, 00, 65, 00, 6E, 00, 74, 00, 2D, 00, 65, 00, 6E, 00, 61, 00, 62, 00, 6C, 00, 65, 00, 64, 00, 2D, 00, 73, 00, 70, 00, 61, 00, 77, 00, 6E, 00, 2D, 00, 70, 00, 6F, 00, 69, 00, 6E, 00, 74, 00, 73, 00] terminal-flag=Some(1)
        // IL_012E: ldnull 
        // IL_012F: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0134: ldc.i4.1 1
        // IL_0135: stloc.3 3
        // IL_0136: leave.s IL_0151
        // IL_0138: ldloc.0 0
        // IL_0139: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
        // IL_013E: callvirt 0x0A00058F [OpenRA.Game]OpenRA.Server.Server::StartGame
        // IL_0143: ldc.i4.1 1
        // IL_0144: stloc.3 3
        // IL_0145: leave.s IL_0151
        // IL_0147: ldloc.2 2
        // IL_0148: brfalse.s IL_0150
        // IL_014A: ldloc.1 1
        // IL_014B: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0150: endfinally 
        // IL_0151: ldloc.3 3
        // IL_0152: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 300, handler_offset: 327, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_0147 finally IL_0147..IL_0151
    }

    private static bool Slot(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 02, 7B, 72, 05, 00, 0A, 7B]
        // .code-bytes IL_0018: [74, 05, 00, 0A, 05, 12, 02, 6F, 93, 05, 00, 0A, 2D, 1D, 72, C5, D1, 00, 70, 72, D3, D1, 00, 70]
        // .code-bytes IL_0030: [05, 28, 44, 02, 00, 0A, 28, 76, 05, 00, 0A, 16, 13, 04, DD, BC, 00, 00, 00, 08, 7B, 94, 05, 00]
        // .code-bytes IL_0048: [0A, 2D, 0E, 02, 7B, 72, 05, 00, 0A, 05, 6F, 95, 05, 00, 0A, 2C, 08, 16, 13, 04, DD, 9E, 00, 00]
        // .code-bytes IL_0060: [00, 04, 7B, 96, 05, 00, 0A, 2D, 03, 14, 2B, 16, 02, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 04]
        // .code-bytes IL_0078: [7B, 96, 05, 00, 0A, 6F, 97, 05, 00, 0A, 0D, 09, 2C, 0F, 09, 7B, 98, 05, 00, 0A, 2C, 07, 04, 16]
        // .code-bytes IL_0090: [7D, 99, 05, 00, 0A, 04, 05, 7D, 96, 05, 00, 0A, 04, 02, 7B, 86, 05, 00, 0A, 6F, 9A, 05, 00, 0A]
        // .code-bytes IL_00A8: [7B, 9B, 05, 00, 0A, 05, 6F, 9C, 05, 00, 0A, 28, 9D, 05, 00, 0A, 08, 7B, 9E, 05, 00, 0A, 2D, 24]
        // .code-bytes IL_00C0: [04, 04, 02, 04, 7B, 9F, 05, 00, 0A, 04, 7B, A0, 05, 00, 0A, 03, 28, 43, 03, 00, 06, 25, 13, 05]
        // .code-bytes IL_00D8: [7D, 9F, 05, 00, 0A, 11, 05, 7D, A1, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 02, 28, 24, 03, 00, 06]
        // .code-bytes IL_00F0: [17, 13, 04, DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00, 0A, DC, 11, 04, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] class [OpenRA.Game]OpenRA.Network.Session/Slot
        // .local [3] class [OpenRA.Game]OpenRA.Network.Session/Slot
        // .local [4] bool
        // .local [5] valuetype [OpenRA.Game]OpenRA.Primitives.Color
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.0 0
        // IL_0012: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0017: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_001C: ldarg.3 3
        // IL_001D: ldloca.s 2
        // IL_001F: callvirt 0x0A000593 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::TryGetValue
        // IL_0024: brtrue.s IL_0043
        // IL_0026: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_002B: ldstr 0x7000D1D3 [73, 110, 118, 97, 108, 105, 100, 32, 115, 108, 111, 116, 58, 32] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 73, 00, 6C, 00, 6F, 00, 74, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_0030: ldarg.3 3
        // IL_0031: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_0036: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_003B: ldc.i4.0 0
        // IL_003C: stloc.s 4
        // IL_003E: leave IL_00FF
        // IL_0043: ldloc.2 2
        // IL_0044: ldfld 0x0A000594 [OpenRA.Game]OpenRA.Network.Session/Slot::Closed
        // IL_0049: brtrue.s IL_0059
        // IL_004B: ldarg.0 0
        // IL_004C: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0051: ldarg.3 3
        // IL_0052: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
        // IL_0057: brfalse.s IL_0061
        // IL_0059: ldc.i4.0 0
        // IL_005A: stloc.s 4
        // IL_005C: leave IL_00FF
        // IL_0061: ldarg.2 2
        // IL_0062: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0067: brtrue.s IL_006C
        // IL_0069: ldnull 
        // IL_006A: br.s IL_0082
        // IL_006C: ldarg.0 0
        // IL_006D: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0072: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0077: ldarg.2 2
        // IL_0078: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_007D: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_0082: stloc.3 3
        // IL_0083: ldloc.3 3
        // IL_0084: brfalse.s IL_0095
        // IL_0086: ldloc.3 3
        // IL_0087: ldfld 0x0A000598 [OpenRA.Game]OpenRA.Network.Session/Slot::LockSpawn
        // IL_008C: brfalse.s IL_0095
        // IL_008E: ldarg.2 2
        // IL_008F: ldc.i4.0 0
        // IL_0090: stfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
        // IL_0095: ldarg.2 2
        // IL_0096: ldarg.3 3
        // IL_0097: stfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_009C: ldarg.2 2
        // IL_009D: ldarg.0 0
        // IL_009E: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_00A3: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
        // IL_00A8: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
        // IL_00AD: ldarg.3 3
        // IL_00AE: callvirt 0x0A00059C class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Item
        // IL_00B3: call 0x0A00059D [OpenRA.Game]OpenRA.Server.Server::SyncClientToPlayerReference
        // IL_00B8: ldloc.2 2
        // IL_00B9: ldfld 0x0A00059E [OpenRA.Game]OpenRA.Network.Session/Slot::LockColor
        // IL_00BE: brtrue.s IL_00E4
        // IL_00C0: ldarg.2 2
        // IL_00C1: ldarg.2 2
        // IL_00C2: ldarg.0 0
        // IL_00C3: ldarg.2 2
        // IL_00C4: ldfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_00C9: ldarg.2 2
        // IL_00CA: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_00CF: ldarg.1 1
        // IL_00D0: call 0x06000343 OpenRA.Mods.Common.Server.LobbyCommands::SanitizePlayerColor
        // IL_00D5: dup 
        // IL_00D6: stloc.s 5
        // IL_00D8: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_00DD: ldloc.s 5
        // IL_00DF: stfld 0x0A0005A1 [OpenRA.Game]OpenRA.Network.Session/Client::PreferredColor
        // IL_00E4: ldarg.0 0
        // IL_00E5: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_00EA: ldarg.0 0
        // IL_00EB: call 0x06000324 OpenRA.Mods.Common.Server.LobbyCommands::CheckAutoStart
        // IL_00F0: ldc.i4.1 1
        // IL_00F1: stloc.s 4
        // IL_00F3: leave.s IL_00FF
        // IL_00F5: ldloc.1 1
        // IL_00F6: brfalse.s IL_00FE
        // IL_00F8: ldloc.0 0
        // IL_00F9: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00FE: endfinally 
        // IL_00FF: ldloc.s 4
        // IL_0101: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 236, handler_offset: 245, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00F5 finally IL_00F5..IL_00FF
    }

    private static bool AllowSpectators(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 05, 02, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [7B, 81, 05, 00, 0A, 7C, A2, 05, 00, 0A, 28, A3, 05, 00, 0A, 2C, 0A, 02, 6F, A4, 05, 00, 0A, 17]
        // .code-bytes IL_0030: [0C, DE, 30, 02, 03, 72, 07, D3, 00, 70, 18, 8D, 12, 00, 00, 01, 25, 16, 72, 9D, D2, 00, 70, A2]
        // .code-bytes IL_0048: [25, 17, 72, F9, D4, 00, 70, A2, 6F, 78, 05, 00, 0A, 17, 0C, DE, 0A, 07, 2C, 06, 06, 28, 79, 05]
        // .code-bytes IL_0060: [00, 0A, DC, 08, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.3 3
        // IL_0012: ldarg.0 0
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_001D: ldflda 0x0A0005A2 [OpenRA.Game]OpenRA.Network.Session/Global::AllowSpectators
        // IL_0022: call 0x0A0005A3 [System.Runtime]System.Boolean::TryParse
        // IL_0027: brfalse.s IL_0033
        // IL_0029: ldarg.0 0
        // IL_002A: callvirt 0x0A0005A4 [OpenRA.Game]OpenRA.Server.Server::SyncLobbyGlobalSettings
        // IL_002F: ldc.i4.1 1
        // IL_0030: stloc.2 2
        // IL_0031: leave.s IL_0063
        // IL_0033: ldarg.0 0
        // IL_0034: ldarg.1 1
        // IL_0035: ldstr 0x7000D307 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 97, 108, 102, 111, 114, 109, 101, 100, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 61, 00, 6C, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 65, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_003A: ldc.i4.2 2
        // IL_003B: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0040: dup 
        // IL_0041: ldc.i4.0 0
        // IL_0042: ldstr 0x7000D29D [99, 111, 109, 109, 97, 110, 100] utf16-bytes=[63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_0047: stelem.ref 
        // IL_0048: dup 
        // IL_0049: ldc.i4.1 1
        // IL_004A: ldstr 0x7000D4F9 [97, 108, 108, 111, 119, 95, 115, 112, 101, 99, 116, 97, 116, 101] utf16-bytes=[61, 00, 6C, 00, 6C, 00, 6F, 00, 77, 00, 5F, 00, 73, 00, 70, 00, 65, 00, 63, 00, 74, 00, 61, 00, 74, 00, 65, 00] terminal-flag=Some(0)
        // IL_004F: stelem.ref 
        // IL_0050: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0055: ldc.i4.1 1
        // IL_0056: stloc.2 2
        // IL_0057: leave.s IL_0063
        // IL_0059: ldloc.1 1
        // IL_005A: brfalse.s IL_0062
        // IL_005C: ldloc.0 0
        // IL_005D: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0062: endfinally 
        // IL_0063: ldloc.2 2
        // IL_0064: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 80, handler_offset: 89, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_0059 finally IL_0059..IL_0063
    }

    private static bool Specate(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 02, 7B, 72, 05, 00, 0A, 7B]
        // .code-bytes IL_0018: [81, 05, 00, 0A, 7B, A2, 05, 00, 0A, 2D, 08, 04, 7B, 77, 05, 00, 0A, 2C, 37, 04, 14, 7D, 96, 05]
        // .code-bytes IL_0030: [00, 0A, 04, 16, 7D, 99, 05, 00, 0A, 04, 16, 7D, A5, 05, 00, 0A, 04, 16, 7D, A6, 05, 00, 0A, 04]
        // .code-bytes IL_0048: [28, BF, 02, 00, 0A, 7D, 9F, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 02, 28, 24, 03, 00, 06, 17, 0C]
        // .code-bytes IL_0060: [DE, 0E, 16, 0C, DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00, 0A, DC, 08, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.0 0
        // IL_0012: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0017: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_001C: ldfld 0x0A0005A2 [OpenRA.Game]OpenRA.Network.Session/Global::AllowSpectators
        // IL_0021: brtrue.s IL_002B
        // IL_0023: ldarg.2 2
        // IL_0024: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0029: brfalse.s IL_0062
        // IL_002B: ldarg.2 2
        // IL_002C: ldnull 
        // IL_002D: stfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0032: ldarg.2 2
        // IL_0033: ldc.i4.0 0
        // IL_0034: stfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
        // IL_0039: ldarg.2 2
        // IL_003A: ldc.i4.0 0
        // IL_003B: stfld 0x0A0005A5 [OpenRA.Game]OpenRA.Network.Session/Client::Team
        // IL_0040: ldarg.2 2
        // IL_0041: ldc.i4.0 0
        // IL_0042: stfld 0x0A0005A6 [OpenRA.Game]OpenRA.Network.Session/Client::Handicap
        // IL_0047: ldarg.2 2
        // IL_0048: call 0x0A0002BF [OpenRA.Game]OpenRA.Primitives.Color::get_White
        // IL_004D: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_0052: ldarg.0 0
        // IL_0053: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_0058: ldarg.0 0
        // IL_0059: call 0x06000324 OpenRA.Mods.Common.Server.LobbyCommands::CheckAutoStart
        // IL_005E: ldc.i4.1 1
        // IL_005F: stloc.2 2
        // IL_0060: leave.s IL_0070
        // IL_0062: ldc.i4.0 0
        // IL_0063: stloc.2 2
        // IL_0064: leave.s IL_0070
        // IL_0066: ldloc.1 1
        // IL_0067: brfalse.s IL_006F
        // IL_0069: ldloc.0 0
        // IL_006A: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_006F: endfinally 
        // IL_0070: ldloc.2 2
        // IL_0071: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 93, handler_offset: 102, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_0066 finally IL_0066..IL_0070
    }

    private static bool SlotClose(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 73, 5C, 29, 00, 06, 0C, 02]
        // .code-bytes IL_0018: [03, 04, 05, 17, 28, 21, 03, 00, 06, 2D, 07, 16, 0D, DD, A7, 00, 00, 00, 08, 02, 7B, 72, 05, 00]
        // .code-bytes IL_0030: [0A, 05, 6F, 95, 05, 00, 0A, 7D, FA, 21, 00, 04, 08, 7B, FA, 21, 00, 04, 2C, 62, 08, 7B, FA, 21]
        // .code-bytes IL_0048: [00, 04, 7B, A7, 05, 00, 0A, 2C, 1F, 02, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 08, 7B, FA, 21]
        // .code-bytes IL_0060: [00, 04, 6F, A8, 05, 00, 0A, 26, 02, 6F, 8E, 05, 00, 0A, 2B, 36, 02, 7B, A9, 05, 00, 0A, 08, FE]
        // .code-bytes IL_0078: [06, 5D, 29, 00, 06, 73, AA, 05, 00, 0A, 28, EF, 00, 00, 2B, 13, 04, 11, 04, 2C, 19, 02, 03, 72]
        // .code-bytes IL_0090: [17, D5, 00, 70, 72, 2F, D5, 00, 70, 6F, 92, 05, 00, 0A, 02, 11, 04, 6F, AB, 05, 00, 0A, 02, 7B]
        // .code-bytes IL_00A8: [72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 05, 6F, 97, 05, 00, 0A, 17, 7D, 94, 05, 00, 0A, 02, 6F, AC]
        // .code-bytes IL_00C0: [05, 00, 0A, 17, 0D, DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00, 0A, DC, 09, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0
        // .local [3] bool
        // .local [4] class [OpenRA.Game]OpenRA.Server.Connection
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: newobj 0x0600295C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0::.ctor
        // IL_0016: stloc.2 2
        // IL_0017: ldarg.0 0
        // IL_0018: ldarg.1 1
        // IL_0019: ldarg.2 2
        // IL_001A: ldarg.3 3
        // IL_001B: ldc.i4.1 1
        // IL_001C: call 0x06000321 OpenRA.Mods.Common.Server.LobbyCommands::ValidateSlotCommand
        // IL_0021: brtrue.s IL_002A
        // IL_0023: ldc.i4.0 0
        // IL_0024: stloc.3 3
        // IL_0025: leave IL_00D1
        // IL_002A: ldloc.2 2
        // IL_002B: ldarg.0 0
        // IL_002C: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0031: ldarg.3 3
        // IL_0032: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
        // IL_0037: stfld 0x040021FA OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0::occupant
        // IL_003C: ldloc.2 2
        // IL_003D: ldfld 0x040021FA OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0::occupant
        // IL_0042: brfalse.s IL_00A6
        // IL_0044: ldloc.2 2
        // IL_0045: ldfld 0x040021FA OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0::occupant
        // IL_004A: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
        // IL_004F: brfalse.s IL_0070
        // IL_0051: ldarg.0 0
        // IL_0052: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0057: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_005C: ldloc.2 2
        // IL_005D: ldfld 0x040021FA OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0::occupant
        // IL_0062: callvirt 0x0A0005A8 class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::Remove
        // IL_0067: pop 
        // IL_0068: ldarg.0 0
        // IL_0069: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_006E: br.s IL_00A6
        // IL_0070: ldarg.0 0
        // IL_0071: ldfld 0x0A0005A9 [OpenRA.Game]OpenRA.Server.Server::Conns
        // IL_0076: ldloc.2 2
        // IL_0077: ldftn 0x0600295D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0::<SlotClose>b__0
        // IL_007D: newobj 0x0A0005AA class [System.Runtime]System.Predicate`1<class [OpenRA.Game]OpenRA.Server.Connection>::.ctor
        // IL_0082: call 0x2B0000EF [OpenRA.Game]OpenRA.Exts::FirstOrDefault<class [OpenRA.Game]OpenRA.Server.Connection>
        // IL_0087: stloc.s 4
        // IL_0089: ldloc.s 4
        // IL_008B: brfalse.s IL_00A6
        // IL_008D: ldarg.0 0
        // IL_008E: ldarg.1 1
        // IL_008F: ldstr 0x7000D517 [83, 101, 114, 118, 101, 114, 69, 114, 114, 111, 114] utf16-bytes=[53, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00, 45, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_0094: ldstr 0x7000D52F [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 115, 108, 111, 116, 45, 99, 108, 111, 115, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 73, 00, 6C, 00, 6F, 00, 74, 00, 2D, 00, 63, 00, 6C, 00, 6F, 00, 73, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_0099: callvirt 0x0A000592 [OpenRA.Game]OpenRA.Server.Server::SendOrderTo
        // IL_009E: ldarg.0 0
        // IL_009F: ldloc.s 4
        // IL_00A1: callvirt 0x0A0005AB [OpenRA.Game]OpenRA.Server.Server::DropClient
        // IL_00A6: ldarg.0 0
        // IL_00A7: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00AC: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_00B1: ldarg.3 3
        // IL_00B2: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_00B7: ldc.i4.1 1
        // IL_00B8: stfld 0x0A000594 [OpenRA.Game]OpenRA.Network.Session/Slot::Closed
        // IL_00BD: ldarg.0 0
        // IL_00BE: callvirt 0x0A0005AC [OpenRA.Game]OpenRA.Server.Server::SyncLobbySlots
        // IL_00C3: ldc.i4.1 1
        // IL_00C4: stloc.3 3
        // IL_00C5: leave.s IL_00D1
        // IL_00C7: ldloc.1 1
        // IL_00C8: brfalse.s IL_00D0
        // IL_00CA: ldloc.0 0
        // IL_00CB: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00D0: endfinally 
        // IL_00D1: ldloc.3 3
        // IL_00D2: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 190, handler_offset: 199, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00C7 finally IL_00C7..IL_00D1
    }

    private static bool SlotOpen(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 02, 03, 04, 05, 17, 28, 21]
        // .code-bytes IL_0018: [03, 00, 06, 2D, 05, 16, 13, 04, DE, 5E, 02, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 05, 6F, 97]
        // .code-bytes IL_0030: [05, 00, 0A, 0C, 08, 16, 7D, 94, 05, 00, 0A, 02, 6F, AC, 05, 00, 0A, 02, 7B, 72, 05, 00, 0A, 05]
        // .code-bytes IL_0048: [6F, 95, 05, 00, 0A, 0D, 09, 2C, 1A, 09, 7B, A7, 05, 00, 0A, 2C, 12, 02, 7B, 72, 05, 00, 0A, 7B]
        // .code-bytes IL_0060: [80, 05, 00, 0A, 09, 6F, A8, 05, 00, 0A, 26, 02, 6F, 8E, 05, 00, 0A, 17, 13, 04, DE, 0A, 07, 2C]
        // .code-bytes IL_0078: [06, 06, 28, 79, 05, 00, 0A, DC, 11, 04, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] class [OpenRA.Game]OpenRA.Network.Session/Slot
        // .local [3] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [4] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.0 0
        // IL_0012: ldarg.1 1
        // IL_0013: ldarg.2 2
        // IL_0014: ldarg.3 3
        // IL_0015: ldc.i4.1 1
        // IL_0016: call 0x06000321 OpenRA.Mods.Common.Server.LobbyCommands::ValidateSlotCommand
        // IL_001B: brtrue.s IL_0022
        // IL_001D: ldc.i4.0 0
        // IL_001E: stloc.s 4
        // IL_0020: leave.s IL_0080
        // IL_0022: ldarg.0 0
        // IL_0023: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0028: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_002D: ldarg.3 3
        // IL_002E: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_0033: stloc.2 2
        // IL_0034: ldloc.2 2
        // IL_0035: ldc.i4.0 0
        // IL_0036: stfld 0x0A000594 [OpenRA.Game]OpenRA.Network.Session/Slot::Closed
        // IL_003B: ldarg.0 0
        // IL_003C: callvirt 0x0A0005AC [OpenRA.Game]OpenRA.Server.Server::SyncLobbySlots
        // IL_0041: ldarg.0 0
        // IL_0042: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0047: ldarg.3 3
        // IL_0048: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
        // IL_004D: stloc.3 3
        // IL_004E: ldloc.3 3
        // IL_004F: brfalse.s IL_006B
        // IL_0051: ldloc.3 3
        // IL_0052: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
        // IL_0057: brfalse.s IL_006B
        // IL_0059: ldarg.0 0
        // IL_005A: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_005F: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_0064: ldloc.3 3
        // IL_0065: callvirt 0x0A0005A8 class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::Remove
        // IL_006A: pop 
        // IL_006B: ldarg.0 0
        // IL_006C: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_0071: ldc.i4.1 1
        // IL_0072: stloc.s 4
        // IL_0074: leave.s IL_0080
        // IL_0076: ldloc.1 1
        // IL_0077: brfalse.s IL_007F
        // IL_0079: ldloc.0 0
        // IL_007A: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_007F: endfinally 
        // IL_0080: ldloc.s 4
        // IL_0082: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 109, handler_offset: 118, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_0076 finally IL_0076..IL_0080
    }

    private static bool SlotBot(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 73, 5E, 29, 00, 06, 0C, 05]
        // .code-bytes IL_0018: [1F, 20, 16, 6F, CC, 01, 00, 0A, 0D, 09, 8E, 69, 19, 2F, 2A, 02, 03, 72, 07, D3, 00, 70, 18, 8D]
        // .code-bytes IL_0030: [12, 00, 00, 01, 25, 16, 72, 9D, D2, 00, 70, A2, 25, 17, 72, 61, D5, 00, 70, A2, 6F, 78, 05, 00]
        // .code-bytes IL_0048: [0A, 17, 13, 08, DD, 85, 02, 00, 00, 02, 03, 04, 09, 16, 9A, 17, 28, 21, 03, 00, 06, 2D, 08, 16]
        // .code-bytes IL_0060: [13, 08, DD, 6F, 02, 00, 00, 02, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 09, 16, 9A, 6F, 97, 05]
        // .code-bytes IL_0078: [00, 0A, 13, 04, 02, 7B, 72, 05, 00, 0A, 09, 16, 9A, 6F, 95, 05, 00, 0A, 13, 05, 09, 17, 9A, 12]
        // .code-bytes IL_0090: [06, 28, AD, 05, 00, 0A, 2D, 1F, 72, C5, D1, 00, 70, 72, 73, D5, 00, 70, 09, 17, 9A, 28, 44, 02]
        // .code-bytes IL_00A8: [00, 0A, 28, 76, 05, 00, 0A, 16, 13, 08, DD, 1F, 02, 00, 00, 11, 05, 2C, 1E, 11, 05, 7B, A7, 05]
        // .code-bytes IL_00C0: [00, 0A, 2D, 15, 02, 03, 72, BF, D5, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 08, DD, FD, 01, 00]
        // .code-bytes IL_00D8: [00, 08, 09, 18, 9A, 7D, FB, 21, 00, 04, 02, 7B, 86, 05, 00, 0A, 6F, AE, 05, 00, 0A, 6F, F0, 00]
        // .code-bytes IL_00F0: [00, 2B, 08, FE, 06, 5F, 29, 00, 06, 73, AF, 05, 00, 0A, 28, F1, 00, 00, 2B, 13, 07, 11, 07, 2D]
        // .code-bytes IL_0108: [15, 02, 03, 72, FB, D5, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 08, DD, B8, 01, 00, 00, 11, 04]
        // .code-bytes IL_0120: [16, 7D, 94, 05, 00, 0A, 11, 05, 3A, 54, 01, 00, 00, 73, B0, 05, 00, 0A, 25, 02, 6F, B1, 05, 00]
        // .code-bytes IL_0138: [0A, 7D, A0, 05, 00, 0A, 25, 11, 07, 6F, D5, 00, 00, 0A, 7D, B2, 05, 00, 0A, 25, 08, 7B, FB, 21]
        // .code-bytes IL_0150: [00, 04, 7D, A7, 05, 00, 0A, 25, 09, 16, 9A, 7D, 96, 05, 00, 0A, 25, 72, 37, D6, 00, 70, 7D, B3]
        // .code-bytes IL_0168: [05, 00, 0A, 25, 16, 7D, 99, 05, 00, 0A, 25, 16, 7D, A5, 05, 00, 0A, 25, 16, 7D, A6, 05, 00, 0A]
        // .code-bytes IL_0180: [25, 16, 7D, 7B, 05, 00, 0A, 25, 11, 06, 7D, B4, 05, 00, 0A, 13, 05, 02, 7B, 85, 05, 00, 0A, 6F]
        // .code-bytes IL_0198: [05, 03, 00, 0A, 7B, 06, 03, 00, 0A, 18, 6F, 07, 03, 00, 0A, 6F, F2, 00, 00, 2B, 13, 09, 02, 7B]
        // .code-bytes IL_01B0: [85, 05, 00, 0A, 6F, 01, 03, 00, 0A, 02, 7B, 86, 05, 00, 0A, 6F, B5, 05, 00, 0A, 6F, B6, 05, 00]
        // .code-bytes IL_01C8: [0A, 6F, 3E, 00, 00, 0A, 28, F3, 00, 00, 2B, 13, 0A, 02, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A]
        // .code-bytes IL_01E0: [7E, DD, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 3B, 29, 00, 06, 73, B7, 05, 00]
        // .code-bytes IL_01F8: [0A, 25, 80, DD, 21, 00, 04, 28, F4, 00, 00, 2B, 02, 7B, 86, 05, 00, 0A, 6F, 9A, 05, 00, 0A, 7B]
        // .code-bytes IL_0210: [9B, 05, 00, 0A, 6F, B8, 05, 00, 0A, 7E, DE, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE]
        // .code-bytes IL_0228: [06, 3C, 29, 00, 06, 73, B9, 05, 00, 0A, 25, 80, DE, 21, 00, 04, 28, F5, 00, 00, 2B, 28, F6, 00]
        // .code-bytes IL_0240: [00, 2B, 28, F3, 00, 00, 2B, 13, 0B, 11, 05, 11, 05, 11, 09, 02, 7B, BA, 05, 00, 0A, 11, 0A, 11]
        // .code-bytes IL_0258: [0B, 6F, 88, 1F, 00, 06, 25, 13, 0C, 7D, A1, 05, 00, 0A, 11, 0C, 7D, 9F, 05, 00, 0A, 02, 7B, 72]
        // .code-bytes IL_0270: [05, 00, 0A, 7B, 80, 05, 00, 0A, 11, 05, 6F, BB, 05, 00, 0A, 2B, 1B, 11, 05, 11, 07, 6F, D5, 00]
        // .code-bytes IL_0288: [00, 0A, 7D, B2, 05, 00, 0A, 11, 05, 08, 7B, FB, 21, 00, 04, 7D, A7, 05, 00, 0A, 11, 05, 02, 7B]
        // .code-bytes IL_02A0: [86, 05, 00, 0A, 6F, 9A, 05, 00, 0A, 7B, 9B, 05, 00, 0A, 09, 16, 9A, 6F, 9C, 05, 00, 0A, 28, 9D]
        // .code-bytes IL_02B8: [05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 02, 6F, AC, 05, 00, 0A, 17, 13, 08, DE, 0A, 07, 2C, 06, 06]
        // .code-bytes IL_02D0: [28, 79, 05, 00, 0A, DC, 11, 08, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass57_0
        // .local [3] string[]
        // .local [4] class [OpenRA.Game]OpenRA.Network.Session/Slot
        // .local [5] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [6] int32
        // .local [7] class [OpenRA.Game]OpenRA.Traits.IBotInfo
        // .local [8] bool
        // .local [9] class OpenRA.Mods.Common.Traits.IColorPickerManagerInfo
        // .local [10] class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // .local [11] class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // .local [12] valuetype [OpenRA.Game]OpenRA.Primitives.Color
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: newobj 0x0600295E OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass57_0::.ctor
        // IL_0016: stloc.2 2
        // IL_0017: ldarg.3 3
        // IL_0018: ldc.i4.s 32
        // IL_001A: ldc.i4.0 0
        // IL_001B: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_0020: stloc.3 3
        // IL_0021: ldloc.3 3
        // IL_0022: ldlen 
        // IL_0023: conv.i4 
        // IL_0024: ldc.i4.3 3
        // IL_0025: bge.s IL_0051
        // IL_0027: ldarg.0 0
        // IL_0028: ldarg.1 1
        // IL_0029: ldstr 0x7000D307 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 97, 108, 102, 111, 114, 109, 101, 100, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 61, 00, 6C, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 65, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_002E: ldc.i4.2 2
        // IL_002F: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0034: dup 
        // IL_0035: ldc.i4.0 0
        // IL_0036: ldstr 0x7000D29D [99, 111, 109, 109, 97, 110, 100] utf16-bytes=[63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_003B: stelem.ref 
        // IL_003C: dup 
        // IL_003D: ldc.i4.1 1
        // IL_003E: ldstr 0x7000D561 [115, 108, 111, 116, 95, 98, 111, 116] utf16-bytes=[73, 00, 6C, 00, 6F, 00, 74, 00, 5F, 00, 62, 00, 6F, 00, 74, 00] terminal-flag=Some(0)
        // IL_0043: stelem.ref 
        // IL_0044: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0049: ldc.i4.1 1
        // IL_004A: stloc.s 8
        // IL_004C: leave IL_02D6
        // IL_0051: ldarg.0 0
        // IL_0052: ldarg.1 1
        // IL_0053: ldarg.2 2
        // IL_0054: ldloc.3 3
        // IL_0055: ldc.i4.0 0
        // IL_0056: ldelem.ref 
        // IL_0057: ldc.i4.1 1
        // IL_0058: call 0x06000321 OpenRA.Mods.Common.Server.LobbyCommands::ValidateSlotCommand
        // IL_005D: brtrue.s IL_0067
        // IL_005F: ldc.i4.0 0
        // IL_0060: stloc.s 8
        // IL_0062: leave IL_02D6
        // IL_0067: ldarg.0 0
        // IL_0068: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_006D: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0072: ldloc.3 3
        // IL_0073: ldc.i4.0 0
        // IL_0074: ldelem.ref 
        // IL_0075: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_007A: stloc.s 4
        // IL_007C: ldarg.0 0
        // IL_007D: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0082: ldloc.3 3
        // IL_0083: ldc.i4.0 0
        // IL_0084: ldelem.ref 
        // IL_0085: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
        // IL_008A: stloc.s 5
        // IL_008C: ldloc.3 3
        // IL_008D: ldc.i4.1 1
        // IL_008E: ldelem.ref 
        // IL_008F: ldloca.s 6
        // IL_0091: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_0096: brtrue.s IL_00B7
        // IL_0098: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_009D: ldstr 0x7000D573 [73, 110, 118, 97, 108, 105, 100, 32, 98, 111, 116, 32, 99, 111, 110, 116, 114, 111, 108, 108, 101, 114, 32, 99, 108, 105, 101, 110, 116, 32, 105, 110, 100, 101, 120, 58, 32] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 62, 00, 6F, 00, 74, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 74, 00, 72, 00, 6F, 00, 6C, 00, 6C, 00, 65, 00, 72, 00, 20, 00, 63, 00, 6C, 00, 69, 00, 65, 00, 6E, 00, 74, 00, 20, 00, 69, 00, 6E, 00, 64, 00, 65, 00, 78, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_00A2: ldloc.3 3
        // IL_00A3: ldc.i4.1 1
        // IL_00A4: ldelem.ref 
        // IL_00A5: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_00AA: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_00AF: ldc.i4.0 0
        // IL_00B0: stloc.s 8
        // IL_00B2: leave IL_02D6
        // IL_00B7: ldloc.s 5
        // IL_00B9: brfalse.s IL_00D9
        // IL_00BB: ldloc.s 5
        // IL_00BD: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
        // IL_00C2: brtrue.s IL_00D9
        // IL_00C4: ldarg.0 0
        // IL_00C5: ldarg.1 1
        // IL_00C6: ldstr 0x7000D5BF [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 105, 110, 118, 97, 108, 105, 100, 45, 98, 111, 116, 45, 115, 108, 111, 116] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 69, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 2D, 00, 62, 00, 6F, 00, 74, 00, 2D, 00, 73, 00, 6C, 00, 6F, 00, 74, 00] terminal-flag=Some(1)
        // IL_00CB: ldnull 
        // IL_00CC: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_00D1: ldc.i4.1 1
        // IL_00D2: stloc.s 8
        // IL_00D4: leave IL_02D6
        // IL_00D9: ldloc.2 2
        // IL_00DA: ldloc.3 3
        // IL_00DB: ldc.i4.2 2
        // IL_00DC: ldelem.ref 
        // IL_00DD: stfld 0x040021FB OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass57_0::botType
        // IL_00E2: ldarg.0 0
        // IL_00E3: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_00E8: callvirt 0x0A0005AE [OpenRA.Game]OpenRA.MapPreview::get_PlayerActorInfo
        // IL_00ED: callvirt 0x2B0000F0 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.IBotInfo>
        // IL_00F2: ldloc.2 2
        // IL_00F3: ldftn 0x0600295F OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass57_0::<SlotBot>b__0
        // IL_00F9: newobj 0x0A0005AF class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.IBotInfo, bool>::.ctor
        // IL_00FE: call 0x2B0000F1 [System.Linq]System.Linq.Enumerable::FirstOrDefault<class [OpenRA.Game]OpenRA.Traits.IBotInfo>
        // IL_0103: stloc.s 7
        // IL_0105: ldloc.s 7
        // IL_0107: brtrue.s IL_011E
        // IL_0109: ldarg.0 0
        // IL_010A: ldarg.1 1
        // IL_010B: ldstr 0x7000D5FB [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 105, 110, 118, 97, 108, 105, 100, 45, 98, 111, 116, 45, 116, 121, 112, 101] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 69, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 2D, 00, 62, 00, 6F, 00, 74, 00, 2D, 00, 74, 00, 79, 00, 70, 00, 65, 00] terminal-flag=Some(1)
        // IL_0110: ldnull 
        // IL_0111: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0116: ldc.i4.1 1
        // IL_0117: stloc.s 8
        // IL_0119: leave IL_02D6
        // IL_011E: ldloc.s 4
        // IL_0120: ldc.i4.0 0
        // IL_0121: stfld 0x0A000594 [OpenRA.Game]OpenRA.Network.Session/Slot::Closed
        // IL_0126: ldloc.s 5
        // IL_0128: brtrue IL_0281
        // IL_012D: newobj 0x0A0005B0 [OpenRA.Game]OpenRA.Network.Session/Client::.ctor
        // IL_0132: dup 
        // IL_0133: ldarg.0 0
        // IL_0134: callvirt 0x0A0005B1 [OpenRA.Game]OpenRA.Server.Server::ChooseFreePlayerIndex
        // IL_0139: stfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_013E: dup 
        // IL_013F: ldloc.s 7
        // IL_0141: callvirt 0x0A0000D5 [OpenRA.Game]OpenRA.Traits.IBotInfo::get_Name
        // IL_0146: stfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_014B: dup 
        // IL_014C: ldloc.2 2
        // IL_014D: ldfld 0x040021FB OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass57_0::botType
        // IL_0152: stfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
        // IL_0157: dup 
        // IL_0158: ldloc.3 3
        // IL_0159: ldc.i4.0 0
        // IL_015A: ldelem.ref 
        // IL_015B: stfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0160: dup 
        // IL_0161: ldstr 0x7000D637 [82, 97, 110, 100, 111, 109] utf16-bytes=[52, 00, 61, 00, 6E, 00, 64, 00, 6F, 00, 6D, 00] terminal-flag=Some(0)
        // IL_0166: stfld 0x0A0005B3 [OpenRA.Game]OpenRA.Network.Session/Client::Faction
        // IL_016B: dup 
        // IL_016C: ldc.i4.0 0
        // IL_016D: stfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
        // IL_0172: dup 
        // IL_0173: ldc.i4.0 0
        // IL_0174: stfld 0x0A0005A5 [OpenRA.Game]OpenRA.Network.Session/Client::Team
        // IL_0179: dup 
        // IL_017A: ldc.i4.0 0
        // IL_017B: stfld 0x0A0005A6 [OpenRA.Game]OpenRA.Network.Session/Client::Handicap
        // IL_0180: dup 
        // IL_0181: ldc.i4.0 0
        // IL_0182: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0187: dup 
        // IL_0188: ldloc.s 6
        // IL_018A: stfld 0x0A0005B4 [OpenRA.Game]OpenRA.Network.Session/Client::BotControllerClientIndex
        // IL_018F: stloc.s 5
        // IL_0191: ldarg.0 0
        // IL_0192: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_0197: callvirt 0x0A000305 [OpenRA.Game]OpenRA.ModData::get_DefaultRules
        // IL_019C: ldfld 0x0A000306 [OpenRA.Game]OpenRA.Ruleset::Actors
        // IL_01A1: ldc.i4.2 2
        // IL_01A2: callvirt 0x0A000307 [OpenRA.Game]OpenRA.ActorInfoDictionary::get_Item
        // IL_01A7: callvirt 0x2B0000F2 [OpenRA.Game]OpenRA.ActorInfo::TraitInfo<class OpenRA.Mods.Common.Traits.IColorPickerManagerInfo>
        // IL_01AC: stloc.s 9
        // IL_01AE: ldarg.0 0
        // IL_01AF: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_01B4: callvirt 0x0A000301 [OpenRA.Game]OpenRA.ModData::get_DefaultTerrainInfo
        // IL_01B9: ldarg.0 0
        // IL_01BA: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_01BF: callvirt 0x0A0005B5 [OpenRA.Game]OpenRA.MapPreview::get_TileSet
        // IL_01C4: callvirt 0x0A0005B6 class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, class [OpenRA.Game]OpenRA.ITerrainInfo>::get_Item
        // IL_01C9: callvirt 0x0A00003E [OpenRA.Game]OpenRA.ITerrainInfo::get_RestrictedPlayerColors
        // IL_01CE: call 0x2B0000F3 [System.Linq]System.Linq.Enumerable::ToList<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_01D3: stloc.s 10
        // IL_01D5: ldarg.0 0
        // IL_01D6: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_01DB: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_01E0: ldsfld 0x040021DD OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__57_1
        // IL_01E5: dup 
        // IL_01E6: brtrue.s IL_01FF
        // IL_01E8: pop 
        // IL_01E9: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_01EE: ldftn 0x0600293B OpenRA.Mods.Common.Server.LobbyCommands/<>c::<SlotBot>b__57_1
        // IL_01F4: newobj 0x0A0005B7 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, valuetype [OpenRA.Game]OpenRA.Primitives.Color>::.ctor
        // IL_01F9: dup 
        // IL_01FA: stsfld 0x040021DD OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__57_1
        // IL_01FF: call 0x2B0000F4 [System.Linq]System.Linq.Enumerable::Select<class [OpenRA.Game]OpenRA.Network.Session/Client, valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_0204: ldarg.0 0
        // IL_0205: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_020A: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
        // IL_020F: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
        // IL_0214: callvirt 0x0A0005B8 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Values
        // IL_0219: ldsfld 0x040021DE OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__57_2
        // IL_021E: dup 
        // IL_021F: brtrue.s IL_0238
        // IL_0221: pop 
        // IL_0222: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0227: ldftn 0x0600293C OpenRA.Mods.Common.Server.LobbyCommands/<>c::<SlotBot>b__57_2
        // IL_022D: newobj 0x0A0005B9 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.PlayerReference, valuetype [OpenRA.Game]OpenRA.Primitives.Color>::.ctor
        // IL_0232: dup 
        // IL_0233: stsfld 0x040021DE OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__57_2
        // IL_0238: call 0x2B0000F5 [System.Linq]System.Linq.Enumerable::Select<class [OpenRA.Game]OpenRA.PlayerReference, valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_023D: call 0x2B0000F6 [System.Linq]System.Linq.Enumerable::Concat<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_0242: call 0x2B0000F3 [System.Linq]System.Linq.Enumerable::ToList<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_0247: stloc.s 11
        // IL_0249: ldloc.s 5
        // IL_024B: ldloc.s 5
        // IL_024D: ldloc.s 9
        // IL_024F: ldarg.0 0
        // IL_0250: ldfld 0x0A0005BA [OpenRA.Game]OpenRA.Server.Server::Random
        // IL_0255: ldloc.s 10
        // IL_0257: ldloc.s 11
        // IL_0259: callvirt 0x06001F88 OpenRA.Mods.Common.Traits.IColorPickerManagerInfo::RandomPresetColor
        // IL_025E: dup 
        // IL_025F: stloc.s 12
        // IL_0261: stfld 0x0A0005A1 [OpenRA.Game]OpenRA.Network.Session/Client::PreferredColor
        // IL_0266: ldloc.s 12
        // IL_0268: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_026D: ldarg.0 0
        // IL_026E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0273: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_0278: ldloc.s 5
        // IL_027A: callvirt 0x0A0005BB class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::Add
        // IL_027F: br.s IL_029C
        // IL_0281: ldloc.s 5
        // IL_0283: ldloc.s 7
        // IL_0285: callvirt 0x0A0000D5 [OpenRA.Game]OpenRA.Traits.IBotInfo::get_Name
        // IL_028A: stfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_028F: ldloc.s 5
        // IL_0291: ldloc.2 2
        // IL_0292: ldfld 0x040021FB OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass57_0::botType
        // IL_0297: stfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
        // IL_029C: ldloc.s 5
        // IL_029E: ldarg.0 0
        // IL_029F: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_02A4: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
        // IL_02A9: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
        // IL_02AE: ldloc.3 3
        // IL_02AF: ldc.i4.0 0
        // IL_02B0: ldelem.ref 
        // IL_02B1: callvirt 0x0A00059C class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Item
        // IL_02B6: call 0x0A00059D [OpenRA.Game]OpenRA.Server.Server::SyncClientToPlayerReference
        // IL_02BB: ldarg.0 0
        // IL_02BC: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_02C1: ldarg.0 0
        // IL_02C2: callvirt 0x0A0005AC [OpenRA.Game]OpenRA.Server.Server::SyncLobbySlots
        // IL_02C7: ldc.i4.1 1
        // IL_02C8: stloc.s 8
        // IL_02CA: leave.s IL_02D6
        // IL_02CC: ldloc.1 1
        // IL_02CD: brfalse.s IL_02D5
        // IL_02CF: ldloc.0 0
        // IL_02D0: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_02D5: endfinally 
        // IL_02D6: ldloc.s 8
        // IL_02D8: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 707, handler_offset: 716, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_02CC finally IL_02CC..IL_02D6
    }

    private static bool Map(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [73, 60, 29, 00, 06, 0A, 06, 02, 7D, FC, 21, 00, 04, 06, 03, 7D, FD, 21, 00, 04, 06, 04, 7D, FE]
        // .code-bytes IL_0018: [21, 00, 04, 06, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00]
        // .code-bytes IL_0030: [0A, 73, 62, 29, 00, 06, 0D, 09, 06, 7D, 00, 22, 00, 04, 09, 7B, 00, 22, 00, 04, 7B, FE, 21, 00]
        // .code-bytes IL_0048: [04, 7B, 77, 05, 00, 0A, 2D, 29, 09, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 09, 7B, 00, 22, 00]
        // .code-bytes IL_0060: [04, 7B, FD, 21, 00, 04, 72, 45, D6, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 05, DD, 86, 01, 00]
        // .code-bytes IL_0078: [00, 09, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, BC, 05, 00, 0A, 2C, 2B, 09, 7B, 00, 22, 00]
        // .code-bytes IL_0090: [04, 7B, FC, 21, 00, 04, 7B, BC, 05, 00, 0A, 05, 6F, A0, 02, 00, 0A, 2D, 13, 09, 7B, 00, 22, 00]
        // .code-bytes IL_00A8: [04, 6F, 61, 29, 00, 06, 17, 13, 05, DD, 49, 01, 00, 00, 09, 09, 7B, 00, 22, 00, 04, 7B, FC, 21]
        // .code-bytes IL_00C0: [00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 7B, BD, 05, 00, 0A, 7D, FF, 21, 00, 04, 09, 7B]
        // .code-bytes IL_00D8: [00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 85, 05, 00, 0A, 7B, 21, 03, 00, 0A, 05, 6F, 88, 05, 00]
        // .code-bytes IL_00F0: [0A, 13, 04, 11, 04, 6F, 89, 05, 00, 0A, 2C, 0A, 11, 04, 6F, 89, 05, 00, 0A, 19, 33, 0D, 09, 11]
        // .code-bytes IL_0108: [04, 6F, 63, 29, 00, 06, 38, DD, 00, 00, 00, 09, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, BE]
        // .code-bytes IL_0120: [05, 00, 0A, 7B, BF, 05, 00, 0A, 39, B8, 00, 00, 00, 73, 64, 29, 00, 06, 13, 06, 11, 06, 09, 7D]
        // .code-bytes IL_0138: [02, 22, 00, 04, 11, 06, 7B, 02, 22, 00, 04, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 11, 06, 7B]
        // .code-bytes IL_0150: [02, 22, 00, 04, 7B, 00, 22, 00, 04, 7B, FD, 21, 00, 04, 72, 81, D6, 00, 70, 14, 6F, 78, 05, 00]
        // .code-bytes IL_0168: [0A, 11, 06, 7B, 02, 22, 00, 04, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 85, 05, 00, 0A, 7B]
        // .code-bytes IL_0180: [B9, 01, 00, 0A, 6F, F7, 00, 00, 2B, 7B, 72, 00, 00, 04, 13, 07, 11, 06, 16, 7D, 01, 22, 00, 04]
        // .code-bytes IL_0198: [11, 06, 7B, 02, 22, 00, 04, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 85, 05, 00, 0A, 7B, 21]
        // .code-bytes IL_01B0: [03, 00, 0A, 11, 07, 17, 8D, 4E, 02, 00, 01, 25, 16, 05, A2, 11, 06, 7B, 02, 22, 00, 04, FE, 06]
        // .code-bytes IL_01C8: [63, 29, 00, 06, 73, C0, 05, 00, 0A, 11, 06, FE, 06, 65, 29, 00, 06, 73, C0, 05, 00, 0A, 6F, C1]
        // .code-bytes IL_01E0: [05, 00, 0A, 2B, 0B, 09, 7B, 00, 22, 00, 04, 6F, 61, 29, 00, 06, 17, 13, 05, DE, 0A, 08, 2C, 06]
        // .code-bytes IL_01F8: [07, 28, 79, 05, 00, 0A, DC, 11, 05, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1
        // .local [4] class [OpenRA.Game]OpenRA.MapPreview
        // .local [5] bool
        // .local [6] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2
        // .local [7] string
        // IL_0000: newobj 0x06002960 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldarg.1 1
        // IL_000F: stfld 0x040021FD OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::conn
        // IL_0014: ldloc.0 0
        // IL_0015: ldarg.2 2
        // IL_0016: stfld 0x040021FE OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::client
        // IL_001B: ldloc.0 0
        // IL_001C: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_0021: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0026: stloc.1 1
        // IL_0027: ldc.i4.0 0
        // IL_0028: stloc.2 2
        // IL_0029: ldloc.1 1
        // IL_002A: ldloca.s 2
        // IL_002C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0031: newobj 0x06002962 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::.ctor
        // IL_0036: stloc.3 3
        // IL_0037: ldloc.3 3
        // IL_0038: ldloc.0 0
        // IL_0039: stfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_003E: ldloc.3 3
        // IL_003F: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0044: ldfld 0x040021FE OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::client
        // IL_0049: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_004E: brtrue.s IL_0079
        // IL_0050: ldloc.3 3
        // IL_0051: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0056: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_005B: ldloc.3 3
        // IL_005C: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0061: ldfld 0x040021FD OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::conn
        // IL_0066: ldstr 0x7000D645 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 99, 104, 97, 110, 103, 101, 45, 109, 97, 112] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 2D, 00, 6D, 00, 61, 00, 70, 00] terminal-flag=Some(1)
        // IL_006B: ldnull 
        // IL_006C: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0071: ldc.i4.1 1
        // IL_0072: stloc.s 5
        // IL_0074: leave IL_01FF
        // IL_0079: ldloc.3 3
        // IL_007A: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_007F: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_0084: ldfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_0089: brfalse.s IL_00B6
        // IL_008B: ldloc.3 3
        // IL_008C: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0091: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_0096: ldfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_009B: ldarg.3 3
        // IL_009C: callvirt 0x0A0002A0 class [System.Collections]System.Collections.Generic.HashSet`1<string>::Contains
        // IL_00A1: brtrue.s IL_00B6
        // IL_00A3: ldloc.3 3
        // IL_00A4: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_00A9: callvirt 0x06002961 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::<Map>g__QueryFailed|0
        // IL_00AE: ldc.i4.1 1
        // IL_00AF: stloc.s 5
        // IL_00B1: leave IL_01FF
        // IL_00B6: ldloc.3 3
        // IL_00B7: ldloc.3 3
        // IL_00B8: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_00BD: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_00C2: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00C7: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_00CC: ldfld 0x0A0005BD [OpenRA.Game]OpenRA.Network.Session/Global::Map
        // IL_00D1: stfld 0x040021FF OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::lastMap
        // IL_00D6: ldloc.3 3
        // IL_00D7: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_00DC: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_00E1: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_00E6: ldfld 0x0A000321 [OpenRA.Game]OpenRA.ModData::MapCache
        // IL_00EB: ldarg.3 3
        // IL_00EC: callvirt 0x0A000588 [OpenRA.Game]OpenRA.MapCache::get_Item
        // IL_00F1: stloc.s 4
        // IL_00F3: ldloc.s 4
        // IL_00F5: callvirt 0x0A000589 [OpenRA.Game]OpenRA.MapPreview::get_Status
        // IL_00FA: brfalse.s IL_0106
        // IL_00FC: ldloc.s 4
        // IL_00FE: callvirt 0x0A000589 [OpenRA.Game]OpenRA.MapPreview::get_Status
        // IL_0103: ldc.i4.3 3
        // IL_0104: bne.un.s IL_0113
        // IL_0106: ldloc.3 3
        // IL_0107: ldloc.s 4
        // IL_0109: callvirt 0x06002963 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::<Map>g__SelectMap|1
        // IL_010E: br IL_01F0
        // IL_0113: ldloc.3 3
        // IL_0114: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0119: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_011E: ldfld 0x0A0005BE [OpenRA.Game]OpenRA.Server.Server::Settings
        // IL_0123: ldfld 0x0A0005BF [OpenRA.Game]OpenRA.ServerSettings::QueryMapRepository
        // IL_0128: brfalse IL_01E5
        // IL_012D: newobj 0x06002964 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::.ctor
        // IL_0132: stloc.s 6
        // IL_0134: ldloc.s 6
        // IL_0136: ldloc.3 3
        // IL_0137: stfld 0x04002202 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::CS$<>8__locals2
        // IL_013C: ldloc.s 6
        // IL_013E: ldfld 0x04002202 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::CS$<>8__locals2
        // IL_0143: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0148: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_014D: ldloc.s 6
        // IL_014F: ldfld 0x04002202 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::CS$<>8__locals2
        // IL_0154: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0159: ldfld 0x040021FD OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::conn
        // IL_015E: ldstr 0x7000D681 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 115, 101, 97, 114, 99, 104, 105, 110, 103, 45, 109, 97, 112] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 73, 00, 65, 00, 61, 00, 72, 00, 63, 00, 68, 00, 69, 00, 6E, 00, 67, 00, 2D, 00, 6D, 00, 61, 00, 70, 00] terminal-flag=Some(1)
        // IL_0163: ldnull 
        // IL_0164: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0169: ldloc.s 6
        // IL_016B: ldfld 0x04002202 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::CS$<>8__locals2
        // IL_0170: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_0175: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_017A: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_017F: ldfld 0x0A0001B9 [OpenRA.Game]OpenRA.ModData::Manifest
        // IL_0184: callvirt 0x2B0000F7 [OpenRA.Game]OpenRA.Manifest::Get<class OpenRA.Mods.Common.WebServices>
        // IL_0189: ldfld 0x04000072 OpenRA.Mods.Common.WebServices::MapRepository
        // IL_018E: stloc.s 7
        // IL_0190: ldloc.s 6
        // IL_0192: ldc.i4.0 0
        // IL_0193: stfld 0x04002201 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::reported
        // IL_0198: ldloc.s 6
        // IL_019A: ldfld 0x04002202 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::CS$<>8__locals2
        // IL_019F: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_01A4: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
        // IL_01A9: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_01AE: ldfld 0x0A000321 [OpenRA.Game]OpenRA.ModData::MapCache
        // IL_01B3: ldloc.s 7
        // IL_01B5: ldc.i4.1 1
        // IL_01B6: newarr 0x0100024E [System.Runtime]System.String
        // IL_01BB: dup 
        // IL_01BC: ldc.i4.0 0
        // IL_01BD: ldarg.3 3
        // IL_01BE: stelem.ref 
        // IL_01BF: ldloc.s 6
        // IL_01C1: ldfld 0x04002202 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::CS$<>8__locals2
        // IL_01C6: ldftn 0x06002963 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::<Map>g__SelectMap|1
        // IL_01CC: newobj 0x0A0005C0 class [System.Runtime]System.Action`1<class [OpenRA.Game]OpenRA.MapPreview>::.ctor
        // IL_01D1: ldloc.s 6
        // IL_01D3: ldftn 0x06002965 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_2::<Map>b__11
        // IL_01D9: newobj 0x0A0005C0 class [System.Runtime]System.Action`1<class [OpenRA.Game]OpenRA.MapPreview>::.ctor
        // IL_01DE: callvirt 0x0A0005C1 [OpenRA.Game]OpenRA.MapCache::QueryRemoteMapDetails
        // IL_01E3: br.s IL_01F0
        // IL_01E5: ldloc.3 3
        // IL_01E6: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
        // IL_01EB: callvirt 0x06002961 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::<Map>g__QueryFailed|0
        // IL_01F0: ldc.i4.1 1
        // IL_01F1: stloc.s 5
        // IL_01F3: leave.s IL_01FF
        // IL_01F5: ldloc.2 2
        // IL_01F6: brfalse.s IL_01FE
        // IL_01F8: ldloc.1 1
        // IL_01F9: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_01FE: endfinally 
        // IL_01FF: ldloc.s 5
        // IL_0201: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 41, try_length: 460, handler_offset: 501, handler_length: 10, raw_flags: 2 }
        // .try IL_0029..IL_01F5 finally IL_01F5..IL_01FF
    }

    private static bool Option(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 8
        // .initlocals true
        // .code-bytes IL_0000: [73, 66, 29, 00, 06, 0A, 06, 02, 7D, 03, 22, 00, 04, 06, 7B, 03, 22, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 04, 7B, 77, 05, 00, 0A, 2D, 1A, 06, 7B, 03, 22, 00]
        // .code-bytes IL_0030: [04, 03, 72, B7, D6, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 08, DD, 40, 02, 00, 00, 06, 7B, 03]
        // .code-bytes IL_0048: [22, 00, 04, 7B, 86, 05, 00, 0A, 6F, AE, 05, 00, 0A, 6F, F8, 00, 00, 2B, 06, 7B, 03, 22, 00, 04]
        // .code-bytes IL_0060: [7B, 86, 05, 00, 0A, 6F, C2, 05, 00, 0A, 6F, F8, 00, 00, 2B, 28, F9, 00, 00, 2B, 06, FE, 06, 67]
        // .code-bytes IL_0078: [29, 00, 06, 73, C3, 05, 00, 0A, 28, FA, 00, 00, 2B, 0D, 73, C4, 05, 00, 0A, 13, 04, 09, 6F, D2]
        // .code-bytes IL_0090: [00, 00, 0A, 13, 09, 2B, 19, 11, 09, 6F, D1, 00, 00, 0A, 13, 0A, 11, 04, 11, 0A, 7B, C5, 05, 00]
        // .code-bytes IL_00A8: [0A, 11, 0A, 6F, C6, 05, 00, 0A, 11, 09, 6F, 1B, 00, 00, 0A, 2D, DE, DE, 0C, 11, 09, 2C, 07, 11]
        // .code-bytes IL_00C0: [09, 6F, 1A, 00, 00, 0A, DC, 05, 1F, 20, 16, 6F, CC, 01, 00, 0A, 13, 05, 11, 05, 8E, 69, 18, 32]
        // .code-bytes IL_00D8: [21, 11, 04, 11, 05, 16, 9A, 12, 06, 6F, C7, 05, 00, 0A, 2C, 12, 11, 06, 7B, C8, 05, 00, 0A, 11]
        // .code-bytes IL_00F0: [05, 17, 9A, 6F, C9, 05, 00, 0A, 2D, 1A, 06, 7B, 03, 22, 00, 04, 03, 72, 07, D7, 00, 70, 14, 6F]
        // .code-bytes IL_0108: [78, 05, 00, 0A, 17, 13, 08, DD, 71, 01, 00, 00, 11, 06, 7B, CA, 05, 00, 0A, 2C, 31, 06, 7B, 03]
        // .code-bytes IL_0120: [22, 00, 04, 03, 72, 5D, D7, 00, 70, 18, 8D, 12, 00, 00, 01, 25, 16, 72, 93, D7, 00, 70, A2, 25]
        // .code-bytes IL_0138: [17, 11, 06, 7B, CB, 05, 00, 0A, A2, 6F, 78, 05, 00, 0A, 17, 13, 08, DD, 37, 01, 00, 00, 06, 7B]
        // .code-bytes IL_0150: [03, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 7B, CC, 05, 00, 0A, 11, 06, 7B, C5, 05]
        // .code-bytes IL_0168: [00, 0A, 6F, CD, 05, 00, 0A, 13, 07, 11, 07, 7B, CE, 05, 00, 0A, 11, 05, 17, 9A, 28, BD, 02, 00]
        // .code-bytes IL_0180: [0A, 2C, 08, 17, 13, 08, DD, FA, 00, 00, 00, 11, 06, 7B, C8, 05, 00, 0A, 11, 05, 17, 9A, 6F, C9]
        // .code-bytes IL_0198: [05, 00, 0A, 2D, 1A, 06, 7B, 03, 22, 00, 04, 03, 72, 07, D7, 00, 70, 14, 6F, 78, 05, 00, 0A, 17]
        // .code-bytes IL_01B0: [13, 08, DD, CE, 00, 00, 00, 11, 07, 11, 07, 11, 05, 17, 9A, 25, 13, 0B, 7D, CF, 05, 00, 0A, 11]
        // .code-bytes IL_01C8: [0B, 7D, CE, 05, 00, 0A, 06, 7B, 03, 22, 00, 04, 6F, A4, 05, 00, 0A, 06, 7B, 03, 22, 00, 04, 72]
        // .code-bytes IL_01E0: [A1, D7, 00, 70, 1C, 8D, 12, 00, 00, 01, 25, 16, 72, CF, 3A, 00, 70, A2, 25, 17, 04, 7B, B2, 05]
        // .code-bytes IL_01F8: [00, 0A, A2, 25, 18, 72, D9, D7, 00, 70, A2, 25, 19, 11, 06, 7B, CB, 05, 00, 0A, A2, 25, 1A, 72]
        // .code-bytes IL_0210: [64, 07, 00, 70, A2, 25, 1B, 11, 06, 11, 05, 17, 9A, 6F, D0, 05, 00, 0A, A2, 6F, D1, 05, 00, 0A]
        // .code-bytes IL_0228: [06, 7B, 03, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 6F, 8B, 05, 00, 0A, 13, 0C, 2B]
        // .code-bytes IL_0240: [11, 12, 0C, 28, 8C, 05, 00, 0A, 13, 0D, 11, 0D, 16, 7D, 7B, 05, 00, 0A, 12, 0C, 28, 8D, 05, 00]
        // .code-bytes IL_0258: [0A, 2D, E6, DE, 0E, 12, 0C, FE, 16, C5, 02, 00, 1B, 6F, 1A, 00, 00, 0A, DC, 06, 7B, 03, 22, 00]
        // .code-bytes IL_0270: [04, 6F, 8E, 05, 00, 0A, 17, 13, 08, DE, 0A, 08, 2C, 06, 07, 28, 79, 05, 00, 0A, DC, 11, 08, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // .local [4] class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // .local [5] string[]
        // .local [6] class [OpenRA.Game]OpenRA.Traits.LobbyOption
        // .local [7] class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState
        // .local [8] bool
        // .local [9] class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // .local [10] class [OpenRA.Game]OpenRA.Traits.LobbyOption
        // .local [11] string
        // .local [12] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [13] class [OpenRA.Game]OpenRA.Network.Session/Client
        // IL_0000: newobj 0x06002966 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldarg.2 2
        // IL_0024: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0029: brtrue.s IL_0045
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_0031: ldarg.1 1
        // IL_0032: ldstr 0x7000D6B7 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 99, 104, 97, 110, 103, 101, 45, 99, 111, 110, 102, 105, 103, 117, 114, 97, 116, 105, 111, 110] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 2D, 00, 63, 00, 6F, 00, 6E, 00, 66, 00, 69, 00, 67, 00, 75, 00, 72, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00] terminal-flag=Some(1)
        // IL_0037: ldnull 
        // IL_0038: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_003D: ldc.i4.1 1
        // IL_003E: stloc.s 8
        // IL_0040: leave IL_0285
        // IL_0045: ldloc.0 0
        // IL_0046: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_004B: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0050: callvirt 0x0A0005AE [OpenRA.Game]OpenRA.MapPreview::get_PlayerActorInfo
        // IL_0055: callvirt 0x2B0000F8 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_005A: ldloc.0 0
        // IL_005B: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_0060: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0065: callvirt 0x0A0005C2 [OpenRA.Game]OpenRA.MapPreview::get_WorldActorInfo
        // IL_006A: callvirt 0x2B0000F8 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_006F: call 0x2B0000F9 [System.Linq]System.Linq.Enumerable::Concat<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_0074: ldloc.0 0
        // IL_0075: ldftn 0x06002967 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::<Option>b__0
        // IL_007B: newobj 0x0A0005C3 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions, class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>>::.ctor
        // IL_0080: call 0x2B0000FA [System.Linq]System.Linq.Enumerable::SelectMany<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions, class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // IL_0085: stloc.3 3
        // IL_0086: newobj 0x0A0005C4 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Traits.LobbyOption>::.ctor
        // IL_008B: stloc.s 4
        // IL_008D: ldloc.3 3
        // IL_008E: callvirt 0x0A0000D2 class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>::GetEnumerator
        // IL_0093: stloc.s 9
        // IL_0095: br.s IL_00B0
        // IL_0097: ldloc.s 9
        // IL_0099: callvirt 0x0A0000D1 class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>::get_Current
        // IL_009E: stloc.s 10
        // IL_00A0: ldloc.s 4
        // IL_00A2: ldloc.s 10
        // IL_00A4: ldfld 0x0A0005C5 [OpenRA.Game]OpenRA.Traits.LobbyOption::Id
        // IL_00A9: ldloc.s 10
        // IL_00AB: callvirt 0x0A0005C6 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Traits.LobbyOption>::set_Item
        // IL_00B0: ldloc.s 9
        // IL_00B2: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_00B7: brtrue.s IL_0097
        // IL_00B9: leave.s IL_00C7
        // IL_00BB: ldloc.s 9
        // IL_00BD: brfalse.s IL_00C6
        // IL_00BF: ldloc.s 9
        // IL_00C1: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_00C6: endfinally 
        // IL_00C7: ldarg.3 3
        // IL_00C8: ldc.i4.s 32
        // IL_00CA: ldc.i4.0 0
        // IL_00CB: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_00D0: stloc.s 5
        // IL_00D2: ldloc.s 5
        // IL_00D4: ldlen 
        // IL_00D5: conv.i4 
        // IL_00D6: ldc.i4.2 2
        // IL_00D7: blt.s IL_00FA
        // IL_00D9: ldloc.s 4
        // IL_00DB: ldloc.s 5
        // IL_00DD: ldc.i4.0 0
        // IL_00DE: ldelem.ref 
        // IL_00DF: ldloca.s 6
        // IL_00E1: callvirt 0x0A0005C7 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Traits.LobbyOption>::TryGetValue
        // IL_00E6: brfalse.s IL_00FA
        // IL_00E8: ldloc.s 6
        // IL_00EA: ldfld 0x0A0005C8 [OpenRA.Game]OpenRA.Traits.LobbyOption::Values
        // IL_00EF: ldloc.s 5
        // IL_00F1: ldc.i4.1 1
        // IL_00F2: ldelem.ref 
        // IL_00F3: callvirt 0x0A0005C9 class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, string>::ContainsKey
        // IL_00F8: brtrue.s IL_0114
        // IL_00FA: ldloc.0 0
        // IL_00FB: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_0100: ldarg.1 1
        // IL_0101: ldstr 0x7000D707 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 105, 110, 118, 97, 108, 105, 100, 45, 99, 111, 110, 102, 105, 103, 117, 114, 97, 116, 105, 111, 110, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 69, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6E, 00, 66, 00, 69, 00, 67, 00, 75, 00, 72, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_0106: ldnull 
        // IL_0107: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_010C: ldc.i4.1 1
        // IL_010D: stloc.s 8
        // IL_010F: leave IL_0285
        // IL_0114: ldloc.s 6
        // IL_0116: ldfld 0x0A0005CA [OpenRA.Game]OpenRA.Traits.LobbyOption::IsLocked
        // IL_011B: brfalse.s IL_014E
        // IL_011D: ldloc.0 0
        // IL_011E: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_0123: ldarg.1 1
        // IL_0124: ldstr 0x7000D75D [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 111, 112, 116, 105, 111, 110, 45, 108, 111, 99, 107, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6F, 00, 70, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6C, 00, 6F, 00, 63, 00, 6B, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_0129: ldc.i4.2 2
        // IL_012A: newarr 0x01000012 [System.Runtime]System.Object
        // IL_012F: dup 
        // IL_0130: ldc.i4.0 0
        // IL_0131: ldstr 0x7000D793 [111, 112, 116, 105, 111, 110] utf16-bytes=[6F, 00, 70, 00, 74, 00, 69, 00, 6F, 00, 6E, 00] terminal-flag=Some(0)
        // IL_0136: stelem.ref 
        // IL_0137: dup 
        // IL_0138: ldc.i4.1 1
        // IL_0139: ldloc.s 6
        // IL_013B: ldfld 0x0A0005CB [OpenRA.Game]OpenRA.Traits.LobbyOption::Name
        // IL_0140: stelem.ref 
        // IL_0141: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0146: ldc.i4.1 1
        // IL_0147: stloc.s 8
        // IL_0149: leave IL_0285
        // IL_014E: ldloc.0 0
        // IL_014F: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_0154: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0159: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_015E: ldfld 0x0A0005CC [OpenRA.Game]OpenRA.Network.Session/Global::LobbyOptions
        // IL_0163: ldloc.s 6
        // IL_0165: ldfld 0x0A0005C5 [OpenRA.Game]OpenRA.Traits.LobbyOption::Id
        // IL_016A: callvirt 0x0A0005CD class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState>::get_Item
        // IL_016F: stloc.s 7
        // IL_0171: ldloc.s 7
        // IL_0173: ldfld 0x0A0005CE [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::Value
        // IL_0178: ldloc.s 5
        // IL_017A: ldc.i4.1 1
        // IL_017B: ldelem.ref 
        // IL_017C: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0181: brfalse.s IL_018B
        // IL_0183: ldc.i4.1 1
        // IL_0184: stloc.s 8
        // IL_0186: leave IL_0285
        // IL_018B: ldloc.s 6
        // IL_018D: ldfld 0x0A0005C8 [OpenRA.Game]OpenRA.Traits.LobbyOption::Values
        // IL_0192: ldloc.s 5
        // IL_0194: ldc.i4.1 1
        // IL_0195: ldelem.ref 
        // IL_0196: callvirt 0x0A0005C9 class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, string>::ContainsKey
        // IL_019B: brtrue.s IL_01B7
        // IL_019D: ldloc.0 0
        // IL_019E: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_01A3: ldarg.1 1
        // IL_01A4: ldstr 0x7000D707 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 105, 110, 118, 97, 108, 105, 100, 45, 99, 111, 110, 102, 105, 103, 117, 114, 97, 116, 105, 111, 110, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 69, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6E, 00, 66, 00, 69, 00, 67, 00, 75, 00, 72, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_01A9: ldnull 
        // IL_01AA: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_01AF: ldc.i4.1 1
        // IL_01B0: stloc.s 8
        // IL_01B2: leave IL_0285
        // IL_01B7: ldloc.s 7
        // IL_01B9: ldloc.s 7
        // IL_01BB: ldloc.s 5
        // IL_01BD: ldc.i4.1 1
        // IL_01BE: ldelem.ref 
        // IL_01BF: dup 
        // IL_01C0: stloc.s 11
        // IL_01C2: stfld 0x0A0005CF [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::PreferredValue
        // IL_01C7: ldloc.s 11
        // IL_01C9: stfld 0x0A0005CE [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::Value
        // IL_01CE: ldloc.0 0
        // IL_01CF: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_01D4: callvirt 0x0A0005A4 [OpenRA.Game]OpenRA.Server.Server::SyncLobbyGlobalSettings
        // IL_01D9: ldloc.0 0
        // IL_01DA: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_01DF: ldstr 0x7000D7A1 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 111, 112, 116, 105, 111, 110, 45, 99, 104, 97, 110, 103, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6F, 00, 70, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_01E4: ldc.i4.6 6
        // IL_01E5: newarr 0x01000012 [System.Runtime]System.Object
        // IL_01EA: dup 
        // IL_01EB: ldc.i4.0 0
        // IL_01EC: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01F1: stelem.ref 
        // IL_01F2: dup 
        // IL_01F3: ldc.i4.1 1
        // IL_01F4: ldarg.2 2
        // IL_01F5: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_01FA: stelem.ref 
        // IL_01FB: dup 
        // IL_01FC: ldc.i4.2 2
        // IL_01FD: ldstr 0x7000D7D9 [110, 97, 109, 101] utf16-bytes=[6E, 00, 61, 00, 6D, 00, 65, 00] terminal-flag=Some(0)
        // IL_0202: stelem.ref 
        // IL_0203: dup 
        // IL_0204: ldc.i4.3 3
        // IL_0205: ldloc.s 6
        // IL_0207: ldfld 0x0A0005CB [OpenRA.Game]OpenRA.Traits.LobbyOption::Name
        // IL_020C: stelem.ref 
        // IL_020D: dup 
        // IL_020E: ldc.i4.4 4
        // IL_020F: ldstr 0x70000764 [118, 97, 108, 117, 101] utf16-bytes=[76, 00, 61, 00, 6C, 00, 75, 00, 65, 00] terminal-flag=Some(0)
        // IL_0214: stelem.ref 
        // IL_0215: dup 
        // IL_0216: ldc.i4.5 5
        // IL_0217: ldloc.s 6
        // IL_0219: ldloc.s 5
        // IL_021B: ldc.i4.1 1
        // IL_021C: ldelem.ref 
        // IL_021D: callvirt 0x0A0005D0 [OpenRA.Game]OpenRA.Traits.LobbyOption::Label
        // IL_0222: stelem.ref 
        // IL_0223: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_0228: ldloc.0 0
        // IL_0229: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_022E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0233: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_0238: callvirt 0x0A00058B class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::GetEnumerator
        // IL_023D: stloc.s 12
        // IL_023F: br.s IL_0252
        // IL_0241: ldloca.s 12
        // IL_0243: call 0x0A00058C valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Current
        // IL_0248: stloc.s 13
        // IL_024A: ldloc.s 13
        // IL_024C: ldc.i4.0 0
        // IL_024D: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0252: ldloca.s 12
        // IL_0254: call 0x0A00058D valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::MoveNext
        // IL_0259: brtrue.s IL_0241
        // IL_025B: leave.s IL_026B
        // IL_025D: ldloca.s 12
        // IL_025F: constrained. 0x1B0002C5 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_0265: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_026A: endfinally 
        // IL_026B: ldloc.0 0
        // IL_026C: ldfld 0x04002203 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass59_0::server
        // IL_0271: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_0276: ldc.i4.1 1
        // IL_0277: stloc.s 8
        // IL_0279: leave.s IL_0285
        // IL_027B: ldloc.2 2
        // IL_027C: brfalse.s IL_0284
        // IL_027E: ldloc.1 1
        // IL_027F: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0284: endfinally 
        // IL_0285: ldloc.s 8
        // IL_0287: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 149, try_length: 38, handler_offset: 187, handler_length: 12, raw_flags: 2 }
        // .try IL_0095..IL_00BB finally IL_00BB..IL_00C7
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 575, try_length: 30, handler_offset: 605, handler_length: 14, raw_flags: 2 }
        // .try IL_023F..IL_025D finally IL_025D..IL_026B
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 608, handler_offset: 635, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_027B finally IL_027B..IL_0285
    }

    private static bool ResetOptions(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 68, 29, 00, 06, 0A, 06, 02, 7D, 04, 22, 00, 04, 06, 7B, 04, 22, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 04, 7B, 77, 05, 00, 0A, 2D, 1A, 06, 7B, 04, 22, 00]
        // .code-bytes IL_0030: [04, 03, 72, B7, D6, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 05, DD, B7, 01, 00, 00, 06, 7B, 04]
        // .code-bytes IL_0048: [22, 00, 04, 7B, 86, 05, 00, 0A, 6F, AE, 05, 00, 0A, 6F, F8, 00, 00, 2B, 06, 7B, 04, 22, 00, 04]
        // .code-bytes IL_0060: [7B, 86, 05, 00, 0A, 6F, C2, 05, 00, 0A, 6F, F8, 00, 00, 2B, 28, F9, 00, 00, 2B, 06, FE, 06, 69]
        // .code-bytes IL_0078: [29, 00, 06, 73, C3, 05, 00, 0A, 28, FA, 00, 00, 2B, 0D, 73, D2, 05, 00, 0A, 13, 04, 09, 6F, D2]
        // .code-bytes IL_0090: [00, 00, 0A, 13, 06, 38, C9, 00, 00, 00, 11, 06, 6F, D1, 00, 00, 0A, 13, 07, 11, 07, 7B, D3, 05]
        // .code-bytes IL_00A8: [00, 0A, 06, 7B, 04, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 7B, CC, 05, 00, 0A, 11]
        // .code-bytes IL_00C0: [07, 7B, C5, 05, 00, 0A, 6F, CD, 05, 00, 0A, 7B, CE, 05, 00, 0A, 28, F1, 02, 00, 0A, 2C, 52, 06]
        // .code-bytes IL_00D8: [7B, 04, 22, 00, 04, 72, A1, D7, 00, 70, 1C, 8D, 12, 00, 00, 01, 25, 16, 72, CF, 3A, 00, 70, A2]
        // .code-bytes IL_00F0: [25, 17, 04, 7B, B2, 05, 00, 0A, A2, 25, 18, 72, D9, D7, 00, 70, A2, 25, 19, 11, 07, 7B, CB, 05]
        // .code-bytes IL_0108: [00, 0A, A2, 25, 1A, 72, 64, 07, 00, 70, A2, 25, 1B, 11, 07, 11, 07, 7B, D3, 05, 00, 0A, 6F, D0]
        // .code-bytes IL_0120: [05, 00, 0A, A2, 6F, D1, 05, 00, 0A, 11, 04, 11, 07, 7B, C5, 05, 00, 0A, 73, D4, 05, 00, 0A, 25]
        // .code-bytes IL_0138: [11, 07, 7B, CA, 05, 00, 0A, 7D, D5, 05, 00, 0A, 25, 11, 07, 7B, D3, 05, 00, 0A, 7D, CE, 05, 00]
        // .code-bytes IL_0150: [0A, 25, 11, 07, 7B, D3, 05, 00, 0A, 7D, CF, 05, 00, 0A, 6F, D6, 05, 00, 0A, 11, 06, 6F, 1B, 00]
        // .code-bytes IL_0168: [00, 0A, 3A, 2B, FF, FF, FF, DE, 0C, 11, 06, 2C, 07, 11, 06, 6F, 1A, 00, 00, 0A, DC, 06, 7B, 04]
        // .code-bytes IL_0180: [22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 11, 04, 7D, CC, 05, 00, 0A, 06, 7B, 04, 22]
        // .code-bytes IL_0198: [00, 04, 6F, A4, 05, 00, 0A, 06, 7B, 04, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 6F]
        // .code-bytes IL_01B0: [8B, 05, 00, 0A, 13, 08, 2B, 11, 12, 08, 28, 8C, 05, 00, 0A, 13, 09, 11, 09, 16, 7D, 7B, 05, 00]
        // .code-bytes IL_01C8: [0A, 12, 08, 28, 8D, 05, 00, 0A, 2D, E6, DE, 0E, 12, 08, FE, 16, C5, 02, 00, 1B, 6F, 1A, 00, 00]
        // .code-bytes IL_01E0: [0A, DC, 06, 7B, 04, 22, 00, 04, 6F, 8E, 05, 00, 0A, 17, 13, 05, DE, 0A, 08, 2C, 06, 07, 28, 79]
        // .code-bytes IL_01F8: [05, 00, 0A, DC, 11, 05, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // .local [4] class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState>
        // .local [5] bool
        // .local [6] class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // .local [7] class [OpenRA.Game]OpenRA.Traits.LobbyOption
        // .local [8] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [9] class [OpenRA.Game]OpenRA.Network.Session/Client
        // IL_0000: newobj 0x06002968 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldarg.2 2
        // IL_0024: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0029: brtrue.s IL_0045
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_0031: ldarg.1 1
        // IL_0032: ldstr 0x7000D6B7 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 99, 104, 97, 110, 103, 101, 45, 99, 111, 110, 102, 105, 103, 117, 114, 97, 116, 105, 111, 110] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 2D, 00, 63, 00, 6F, 00, 6E, 00, 66, 00, 69, 00, 67, 00, 75, 00, 72, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00] terminal-flag=Some(1)
        // IL_0037: ldnull 
        // IL_0038: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_003D: ldc.i4.1 1
        // IL_003E: stloc.s 5
        // IL_0040: leave IL_01FC
        // IL_0045: ldloc.0 0
        // IL_0046: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_004B: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0050: callvirt 0x0A0005AE [OpenRA.Game]OpenRA.MapPreview::get_PlayerActorInfo
        // IL_0055: callvirt 0x2B0000F8 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_005A: ldloc.0 0
        // IL_005B: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_0060: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0065: callvirt 0x0A0005C2 [OpenRA.Game]OpenRA.MapPreview::get_WorldActorInfo
        // IL_006A: callvirt 0x2B0000F8 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_006F: call 0x2B0000F9 [System.Linq]System.Linq.Enumerable::Concat<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_0074: ldloc.0 0
        // IL_0075: ldftn 0x06002969 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::<ResetOptions>b__0
        // IL_007B: newobj 0x0A0005C3 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions, class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>>::.ctor
        // IL_0080: call 0x2B0000FA [System.Linq]System.Linq.Enumerable::SelectMany<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions, class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // IL_0085: stloc.3 3
        // IL_0086: newobj 0x0A0005D2 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState>::.ctor
        // IL_008B: stloc.s 4
        // IL_008D: ldloc.3 3
        // IL_008E: callvirt 0x0A0000D2 class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>::GetEnumerator
        // IL_0093: stloc.s 6
        // IL_0095: br IL_0163
        // IL_009A: ldloc.s 6
        // IL_009C: callvirt 0x0A0000D1 class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>::get_Current
        // IL_00A1: stloc.s 7
        // IL_00A3: ldloc.s 7
        // IL_00A5: ldfld 0x0A0005D3 [OpenRA.Game]OpenRA.Traits.LobbyOption::DefaultValue
        // IL_00AA: ldloc.0 0
        // IL_00AB: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_00B0: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00B5: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_00BA: ldfld 0x0A0005CC [OpenRA.Game]OpenRA.Network.Session/Global::LobbyOptions
        // IL_00BF: ldloc.s 7
        // IL_00C1: ldfld 0x0A0005C5 [OpenRA.Game]OpenRA.Traits.LobbyOption::Id
        // IL_00C6: callvirt 0x0A0005CD class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState>::get_Item
        // IL_00CB: ldfld 0x0A0005CE [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::Value
        // IL_00D0: call 0x0A0002F1 [System.Runtime]System.String::op_Inequality
        // IL_00D5: brfalse.s IL_0129
        // IL_00D7: ldloc.0 0
        // IL_00D8: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_00DD: ldstr 0x7000D7A1 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 111, 112, 116, 105, 111, 110, 45, 99, 104, 97, 110, 103, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6F, 00, 70, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_00E2: ldc.i4.6 6
        // IL_00E3: newarr 0x01000012 [System.Runtime]System.Object
        // IL_00E8: dup 
        // IL_00E9: ldc.i4.0 0
        // IL_00EA: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00EF: stelem.ref 
        // IL_00F0: dup 
        // IL_00F1: ldc.i4.1 1
        // IL_00F2: ldarg.2 2
        // IL_00F3: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_00F8: stelem.ref 
        // IL_00F9: dup 
        // IL_00FA: ldc.i4.2 2
        // IL_00FB: ldstr 0x7000D7D9 [110, 97, 109, 101] utf16-bytes=[6E, 00, 61, 00, 6D, 00, 65, 00] terminal-flag=Some(0)
        // IL_0100: stelem.ref 
        // IL_0101: dup 
        // IL_0102: ldc.i4.3 3
        // IL_0103: ldloc.s 7
        // IL_0105: ldfld 0x0A0005CB [OpenRA.Game]OpenRA.Traits.LobbyOption::Name
        // IL_010A: stelem.ref 
        // IL_010B: dup 
        // IL_010C: ldc.i4.4 4
        // IL_010D: ldstr 0x70000764 [118, 97, 108, 117, 101] utf16-bytes=[76, 00, 61, 00, 6C, 00, 75, 00, 65, 00] terminal-flag=Some(0)
        // IL_0112: stelem.ref 
        // IL_0113: dup 
        // IL_0114: ldc.i4.5 5
        // IL_0115: ldloc.s 7
        // IL_0117: ldloc.s 7
        // IL_0119: ldfld 0x0A0005D3 [OpenRA.Game]OpenRA.Traits.LobbyOption::DefaultValue
        // IL_011E: callvirt 0x0A0005D0 [OpenRA.Game]OpenRA.Traits.LobbyOption::Label
        // IL_0123: stelem.ref 
        // IL_0124: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_0129: ldloc.s 4
        // IL_012B: ldloc.s 7
        // IL_012D: ldfld 0x0A0005C5 [OpenRA.Game]OpenRA.Traits.LobbyOption::Id
        // IL_0132: newobj 0x0A0005D4 [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::.ctor
        // IL_0137: dup 
        // IL_0138: ldloc.s 7
        // IL_013A: ldfld 0x0A0005CA [OpenRA.Game]OpenRA.Traits.LobbyOption::IsLocked
        // IL_013F: stfld 0x0A0005D5 [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::IsLocked
        // IL_0144: dup 
        // IL_0145: ldloc.s 7
        // IL_0147: ldfld 0x0A0005D3 [OpenRA.Game]OpenRA.Traits.LobbyOption::DefaultValue
        // IL_014C: stfld 0x0A0005CE [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::Value
        // IL_0151: dup 
        // IL_0152: ldloc.s 7
        // IL_0154: ldfld 0x0A0005D3 [OpenRA.Game]OpenRA.Traits.LobbyOption::DefaultValue
        // IL_0159: stfld 0x0A0005CF [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::PreferredValue
        // IL_015E: callvirt 0x0A0005D6 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState>::set_Item
        // IL_0163: ldloc.s 6
        // IL_0165: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_016A: brtrue IL_009A
        // IL_016F: leave.s IL_017D
        // IL_0171: ldloc.s 6
        // IL_0173: brfalse.s IL_017C
        // IL_0175: ldloc.s 6
        // IL_0177: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_017C: endfinally 
        // IL_017D: ldloc.0 0
        // IL_017E: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_0183: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0188: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_018D: ldloc.s 4
        // IL_018F: stfld 0x0A0005CC [OpenRA.Game]OpenRA.Network.Session/Global::LobbyOptions
        // IL_0194: ldloc.0 0
        // IL_0195: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_019A: callvirt 0x0A0005A4 [OpenRA.Game]OpenRA.Server.Server::SyncLobbyGlobalSettings
        // IL_019F: ldloc.0 0
        // IL_01A0: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_01A5: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_01AA: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_01AF: callvirt 0x0A00058B class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::GetEnumerator
        // IL_01B4: stloc.s 8
        // IL_01B6: br.s IL_01C9
        // IL_01B8: ldloca.s 8
        // IL_01BA: call 0x0A00058C valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Current
        // IL_01BF: stloc.s 9
        // IL_01C1: ldloc.s 9
        // IL_01C3: ldc.i4.0 0
        // IL_01C4: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_01C9: ldloca.s 8
        // IL_01CB: call 0x0A00058D valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::MoveNext
        // IL_01D0: brtrue.s IL_01B8
        // IL_01D2: leave.s IL_01E2
        // IL_01D4: ldloca.s 8
        // IL_01D6: constrained. 0x1B0002C5 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_01DC: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_01E1: endfinally 
        // IL_01E2: ldloc.0 0
        // IL_01E3: ldfld 0x04002204 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass60_0::server
        // IL_01E8: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_01ED: ldc.i4.1 1
        // IL_01EE: stloc.s 5
        // IL_01F0: leave.s IL_01FC
        // IL_01F2: ldloc.2 2
        // IL_01F3: brfalse.s IL_01FB
        // IL_01F5: ldloc.1 1
        // IL_01F6: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_01FB: endfinally 
        // IL_01FC: ldloc.s 5
        // IL_01FE: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 149, try_length: 220, handler_offset: 369, handler_length: 12, raw_flags: 2 }
        // .try IL_0095..IL_0171 finally IL_0171..IL_017D
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 438, try_length: 30, handler_offset: 468, handler_length: 14, raw_flags: 2 }
        // .try IL_01B6..IL_01D4 finally IL_01D4..IL_01E2
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 471, handler_offset: 498, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_01F2 finally IL_01F2..IL_01FC
    }

    private static bool AssignTeams(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string raw)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 6A, 29, 00, 06, 0A, 06, 02, 7D, 05, 22, 00, 04, 06, 7B, 05, 22, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 04, 7B, 77, 05, 00, 0A, 2D, 1A, 06, 7B, 05, 22, 00]
        // .code-bytes IL_0030: [04, 03, 72, E3, D7, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 08, DD, 41, 01, 00, 00, 05, 12, 03]
        // .code-bytes IL_0048: [28, AD, 05, 00, 0A, 2D, 2B, 06, 7B, 05, 22, 00, 04, 03, 72, 17, D8, 00, 70, 18, 8D, 12, 00, 00]
        // .code-bytes IL_0060: [01, 25, 16, 72, 57, D8, 00, 70, A2, 25, 17, 05, A2, 6F, 78, 05, 00, 0A, 17, 13, 08, DD, 0C, 01]
        // .code-bytes IL_0078: [00, 00, 06, 7B, 05, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 7E, E8, 21, 00, 04, 25]
        // .code-bytes IL_0090: [2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 46, 29, 00, 06, 73, 7F, 05, 00, 0A, 25, 80, E8, 21, 00]
        // .code-bytes IL_00A8: [04, 28, FB, 00, 00, 2B, 17, 58, 18, 5B, 13, 04, 09, 16, 11, 04, 28, FC, 00, 00, 2B, 0D, 06, 7B]
        // .code-bytes IL_00C0: [05, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 06, FE, 06, 6B, 29, 00, 06, 73, D8, 05]
        // .code-bytes IL_00D8: [00, 0A, 28, FD, 00, 00, 2B, 06, FE, 06, 6C, 29, 00, 06, 73, 7F, 05, 00, 0A, 28, FE, 00, 00, 2B]
        // .code-bytes IL_00F0: [28, FF, 00, 00, 2B, 13, 05, 16, 13, 06, 11, 05, 6F, D9, 05, 00, 0A, 13, 07, 11, 05, 6F, 8B, 05]
        // .code-bytes IL_0108: [00, 0A, 13, 09, 2B, 45, 12, 09, 28, 8C, 05, 00, 0A, 13, 0A, 09, 2D, 0A, 11, 0A, 16, 7D, A5, 05]
        // .code-bytes IL_0120: [00, 0A, 2B, 2F, 09, 17, 33, 16, 11, 0A, 11, 0A, 7B, A7, 05, 00, 0A, 2C, 03, 18, 2B, 01, 17, 7D]
        // .code-bytes IL_0138: [A5, 05, 00, 0A, 2B, 15, 11, 0A, 11, 06, 25, 17, 58, 13, 06, 09, 5A, 11, 07, 5B, 17, 58, 7D, A5]
        // .code-bytes IL_0150: [05, 00, 0A, 12, 09, 28, 8D, 05, 00, 0A, 2D, B2, DE, 0E, 12, 09, FE, 16, C5, 02, 00, 1B, 6F, 1A]
        // .code-bytes IL_0168: [00, 00, 0A, DC, 06, 7B, 05, 22, 00, 04, 6F, 8E, 05, 00, 0A, 17, 13, 08, DE, 0A, 08, 2C, 06, 07]
        // .code-bytes IL_0180: [28, 79, 05, 00, 0A, DC, 11, 08, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] int32
        // .local [4] int32
        // .local [5] class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [6] int32
        // .local [7] int32
        // .local [8] bool
        // .local [9] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [10] class [OpenRA.Game]OpenRA.Network.Session/Client
        // IL_0000: newobj 0x0600296A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldarg.2 2
        // IL_0024: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0029: brtrue.s IL_0045
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
        // IL_0031: ldarg.1 1
        // IL_0032: ldstr 0x7000D7E3 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 111, 112, 116, 105, 111, 110] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 6F, 00, 70, 00, 74, 00, 69, 00, 6F, 00, 6E, 00] terminal-flag=Some(1)
        // IL_0037: ldnull 
        // IL_0038: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_003D: ldc.i4.1 1
        // IL_003E: stloc.s 8
        // IL_0040: leave IL_0186
        // IL_0045: ldarg.3 3
        // IL_0046: ldloca.s 3
        // IL_0048: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_004D: brtrue.s IL_007A
        // IL_004F: ldloc.0 0
        // IL_0050: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
        // IL_0055: ldarg.1 1
        // IL_0056: ldstr 0x7000D817 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 101, 114, 114, 111, 114, 45, 110, 117, 109, 98, 101, 114, 45, 116, 101, 97, 109, 115] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 2D, 00, 6E, 00, 75, 00, 6D, 00, 62, 00, 65, 00, 72, 00, 2D, 00, 74, 00, 65, 00, 61, 00, 6D, 00, 73, 00] terminal-flag=Some(1)
        // IL_005B: ldc.i4.2 2
        // IL_005C: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0061: dup 
        // IL_0062: ldc.i4.0 0
        // IL_0063: ldstr 0x7000D857 [114, 97, 119] utf16-bytes=[72, 00, 61, 00, 77, 00] terminal-flag=Some(0)
        // IL_0068: stelem.ref 
        // IL_0069: dup 
        // IL_006A: ldc.i4.1 1
        // IL_006B: ldarg.3 3
        // IL_006C: stelem.ref 
        // IL_006D: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0072: ldc.i4.1 1
        // IL_0073: stloc.s 8
        // IL_0075: leave IL_0186
        // IL_007A: ldloc.0 0
        // IL_007B: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
        // IL_0080: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0085: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_008A: ldsfld 0x040021E8 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__61_0
        // IL_008F: dup 
        // IL_0090: brtrue.s IL_00A9
        // IL_0092: pop 
        // IL_0093: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0098: ldftn 0x06002946 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<AssignTeams>b__61_0
        // IL_009E: newobj 0x0A00057F class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, bool>::.ctor
        // IL_00A3: dup 
        // IL_00A4: stsfld 0x040021E8 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__61_0
        // IL_00A9: call 0x2B0000FB [System.Linq]System.Linq.Enumerable::Count<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00AE: ldc.i4.1 1
        // IL_00AF: add 
        // IL_00B0: ldc.i4.2 2
        // IL_00B1: div 
        // IL_00B2: stloc.s 4
        // IL_00B4: ldloc.3 3
        // IL_00B5: ldc.i4.0 0
        // IL_00B6: ldloc.s 4
        // IL_00B8: call 0x2B0000FC [OpenRA.Game]OpenRA.Exts::Clamp<int32>
        // IL_00BD: stloc.3 3
        // IL_00BE: ldloc.0 0
        // IL_00BF: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
        // IL_00C4: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00C9: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_00CE: ldloc.0 0
        // IL_00CF: ldftn 0x0600296B OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::<AssignTeams>b__1
        // IL_00D5: newobj 0x0A0005D8 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, class [OpenRA.Game]OpenRA.Network.Session/Client>::.ctor
        // IL_00DA: call 0x2B0000FD [System.Linq]System.Linq.Enumerable::Select<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00DF: ldloc.0 0
        // IL_00E0: ldftn 0x0600296C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::<AssignTeams>b__2
        // IL_00E6: newobj 0x0A00057F class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, bool>::.ctor
        // IL_00EB: call 0x2B0000FE [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00F0: call 0x2B0000FF [System.Linq]System.Linq.Enumerable::ToList<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00F5: stloc.s 5
        // IL_00F7: ldc.i4.0 0
        // IL_00F8: stloc.s 6
        // IL_00FA: ldloc.s 5
        // IL_00FC: callvirt 0x0A0005D9 class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Count
        // IL_0101: stloc.s 7
        // IL_0103: ldloc.s 5
        // IL_0105: callvirt 0x0A00058B class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::GetEnumerator
        // IL_010A: stloc.s 9
        // IL_010C: br.s IL_0153
        // IL_010E: ldloca.s 9
        // IL_0110: call 0x0A00058C valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Current
        // IL_0115: stloc.s 10
        // IL_0117: ldloc.3 3
        // IL_0118: brtrue.s IL_0124
        // IL_011A: ldloc.s 10
        // IL_011C: ldc.i4.0 0
        // IL_011D: stfld 0x0A0005A5 [OpenRA.Game]OpenRA.Network.Session/Client::Team
        // IL_0122: br.s IL_0153
        // IL_0124: ldloc.3 3
        // IL_0125: ldc.i4.1 1
        // IL_0126: bne.un.s IL_013E
        // IL_0128: ldloc.s 10
        // IL_012A: ldloc.s 10
        // IL_012C: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
        // IL_0131: brfalse.s IL_0136
        // IL_0133: ldc.i4.2 2
        // IL_0134: br.s IL_0137
        // IL_0136: ldc.i4.1 1
        // IL_0137: stfld 0x0A0005A5 [OpenRA.Game]OpenRA.Network.Session/Client::Team
        // IL_013C: br.s IL_0153
        // IL_013E: ldloc.s 10
        // IL_0140: ldloc.s 6
        // IL_0142: dup 
        // IL_0143: ldc.i4.1 1
        // IL_0144: add 
        // IL_0145: stloc.s 6
        // IL_0147: ldloc.3 3
        // IL_0148: mul 
        // IL_0149: ldloc.s 7
        // IL_014B: div 
        // IL_014C: ldc.i4.1 1
        // IL_014D: add 
        // IL_014E: stfld 0x0A0005A5 [OpenRA.Game]OpenRA.Network.Session/Client::Team
        // IL_0153: ldloca.s 9
        // IL_0155: call 0x0A00058D valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::MoveNext
        // IL_015A: brtrue.s IL_010E
        // IL_015C: leave.s IL_016C
        // IL_015E: ldloca.s 9
        // IL_0160: constrained. 0x1B0002C5 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_0166: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_016B: endfinally 
        // IL_016C: ldloc.0 0
        // IL_016D: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
        // IL_0172: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_0177: ldc.i4.1 1
        // IL_0178: stloc.s 8
        // IL_017A: leave.s IL_0186
        // IL_017C: ldloc.2 2
        // IL_017D: brfalse.s IL_0185
        // IL_017F: ldloc.1 1
        // IL_0180: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0185: endfinally 
        // IL_0186: ldloc.s 8
        // IL_0188: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 268, try_length: 82, handler_offset: 350, handler_length: 14, raw_flags: 2 }
        // .try IL_010C..IL_015E finally IL_015E..IL_016C
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 353, handler_offset: 380, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_017C finally IL_017C..IL_0186
    }

    private static bool Kick(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 6D, 29, 00, 06, 0A, 06, 02, 7D, 06, 22, 00, 04, 06, 7B, 06, 22, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 04, 7B, 77, 05, 00, 0A, 2D, 1A, 06, 7B, 06, 22, 00]
        // .code-bytes IL_0030: [04, 03, 72, 5F, D8, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, 7A, 02, 00, 00, 05, 1F, 20]
        // .code-bytes IL_0048: [16, 6F, CC, 01, 00, 0A, 0D, 09, 8E, 69, 18, 2F, 2F, 06, 7B, 06, 22, 00, 04, 03, 72, 07, D3, 00]
        // .code-bytes IL_0060: [70, 18, 8D, 12, 00, 00, 01, 25, 16, 72, 9D, D2, 00, 70, A2, 25, 17, 72, 8F, D8, 00, 70, A2, 6F]
        // .code-bytes IL_0078: [78, 05, 00, 0A, 17, 13, 07, DD, 3B, 02, 00, 00, 09, 16, 9A, 06, 7C, 07, 22, 00, 04, 28, AD, 05]
        // .code-bytes IL_0090: [00, 0A, 2D, 03, 14, 2B, 1C, 06, 7B, 06, 22, 00, 04, 7B, A9, 05, 00, 0A, 06, FE, 06, 6E, 29, 00]
        // .code-bytes IL_00A8: [06, 73, DA, 05, 00, 0A, 28, 00, 01, 00, 2B, 13, 04, 11, 04, 2D, 1A, 06, 7B, 06, 22, 00, 04, 03]
        // .code-bytes IL_00C0: [72, 99, D8, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, EC, 01, 00, 00, 06, 7B, 06, 22, 00]
        // .code-bytes IL_00D8: [04, 11, 04, 6F, DC, 05, 00, 0A, 13, 05, 04, 11, 05, 33, 1A, 06, 7B, 06, 22, 00, 04, 03, 72, C7]
        // .code-bytes IL_00F0: [D8, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, BE, 01, 00, 00, 06, 7B, 06, 22, 00, 04, 6F]
        // .code-bytes IL_0108: [7A, 05, 00, 0A, 18, 33, 32, 11, 05, 6F, DD, 05, 00, 0A, 2D, 29, 06, 7B, 06, 22, 00, 04, 11, 05]
        // .code-bytes IL_0120: [6F, DE, 05, 00, 0A, 2D, 1A, 06, 7B, 06, 22, 00, 04, 03, 72, F5, D8, 00, 70, 14, 6F, 78, 05, 00]
        // .code-bytes IL_0138: [0A, 17, 13, 07, DD, 7E, 01, 00, 00, 72, C5, D1, 00, 70, 1F, 10, 17, 73, FA, 02, 00, 0A, 13, 08]
        // .code-bytes IL_0150: [12, 08, 72, 39, D9, 00, 70, 28, FB, 02, 00, 0A, 12, 08, 06, 7B, 07, 22, 00, 04, 28, 4A, 00, 00]
        // .code-bytes IL_0168: [2B, 12, 08, 72, 9A, 0F, 00, 70, 28, FB, 02, 00, 0A, 12, 08, 28, FD, 02, 00, 0A, 28, 76, 05, 00]
        // .code-bytes IL_0180: [0A, 06, 7B, 06, 22, 00, 04, 72, 59, D9, 00, 70, 1A, 8D, 12, 00, 00, 01, 25, 16, 72, 8D, D9, 00]
        // .code-bytes IL_0198: [70, A2, 25, 17, 04, 7B, B2, 05, 00, 0A, A2, 25, 18, 72, CF, 3A, 00, 70, A2, 25, 19, 11, 05, 7B]
        // .code-bytes IL_01B0: [B2, 05, 00, 0A, A2, 6F, D1, 05, 00, 0A, 06, 7B, 06, 22, 00, 04, 11, 04, 72, 17, D5, 00, 70, 72]
        // .code-bytes IL_01C8: [99, D9, 00, 70, 6F, 92, 05, 00, 0A, 06, 7B, 06, 22, 00, 04, 11, 04, 6F, AB, 05, 00, 0A, 09, 17]
        // .code-bytes IL_01E0: [9A, 12, 06, 28, A3, 05, 00, 0A, 11, 06, 5F, 39, AA, 00, 00, 00, 72, C5, D1, 00, 70, 1F, 1F, 18]
        // .code-bytes IL_01F8: [73, FA, 02, 00, 0A, 13, 08, 12, 08, 72, D3, D9, 00, 70, 28, FB, 02, 00, 0A, 12, 08, 06, 7B, 07]
        // .code-bytes IL_0210: [22, 00, 04, 28, 4A, 00, 00, 2B, 12, 08, 72, 0B, DA, 00, 70, 28, FB, 02, 00, 0A, 12, 08, 11, 05]
        // .code-bytes IL_0228: [7B, DF, 05, 00, 0A, 28, 00, 03, 00, 0A, 12, 08, 72, 11, DA, 00, 70, 28, FB, 02, 00, 0A, 12, 08]
        // .code-bytes IL_0240: [28, FD, 02, 00, 0A, 28, 76, 05, 00, 0A, 06, 7B, 06, 22, 00, 04, 72, 17, DA, 00, 70, 1A, 8D, 12]
        // .code-bytes IL_0258: [00, 00, 01, 25, 16, 72, 8D, D9, 00, 70, A2, 25, 17, 04, 7B, B2, 05, 00, 0A, A2, 25, 18, 72, CF]
        // .code-bytes IL_0270: [3A, 00, 70, A2, 25, 19, 11, 05, 7B, B2, 05, 00, 0A, A2, 6F, D1, 05, 00, 0A, 06, 7B, 06, 22, 00]
        // .code-bytes IL_0288: [04, 7B, E0, 05, 00, 0A, 11, 05, 7B, DF, 05, 00, 0A, 6F, 79, 03, 00, 0A, 06, 7B, 06, 22, 00, 04]
        // .code-bytes IL_02A0: [6F, 8E, 05, 00, 0A, 06, 7B, 06, 22, 00, 04, 6F, AC, 05, 00, 0A, 17, 13, 07, DE, 0A, 08, 2C, 06]
        // .code-bytes IL_02B8: [07, 28, 79, 05, 00, 0A, DC, 11, 07, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] string[]
        // .local [4] class [OpenRA.Game]OpenRA.Server.Connection
        // .local [5] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [6] bool
        // .local [7] bool
        // .local [8] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: newobj 0x0600296D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldarg.2 2
        // IL_0024: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0029: brtrue.s IL_0045
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_0031: ldarg.1 1
        // IL_0032: ldstr 0x7000D85F [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 107, 105, 99, 107] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00] terminal-flag=Some(1)
        // IL_0037: ldnull 
        // IL_0038: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_003D: ldc.i4.1 1
        // IL_003E: stloc.s 7
        // IL_0040: leave IL_02BF
        // IL_0045: ldarg.3 3
        // IL_0046: ldc.i4.s 32
        // IL_0048: ldc.i4.0 0
        // IL_0049: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_004E: stloc.3 3
        // IL_004F: ldloc.3 3
        // IL_0050: ldlen 
        // IL_0051: conv.i4 
        // IL_0052: ldc.i4.2 2
        // IL_0053: bge.s IL_0084
        // IL_0055: ldloc.0 0
        // IL_0056: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_005B: ldarg.1 1
        // IL_005C: ldstr 0x7000D307 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 97, 108, 102, 111, 114, 109, 101, 100, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 61, 00, 6C, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 65, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_0061: ldc.i4.2 2
        // IL_0062: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0067: dup 
        // IL_0068: ldc.i4.0 0
        // IL_0069: ldstr 0x7000D29D [99, 111, 109, 109, 97, 110, 100] utf16-bytes=[63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_006E: stelem.ref 
        // IL_006F: dup 
        // IL_0070: ldc.i4.1 1
        // IL_0071: ldstr 0x7000D88F [107, 105, 99, 107] utf16-bytes=[6B, 00, 69, 00, 63, 00, 6B, 00] terminal-flag=Some(0)
        // IL_0076: stelem.ref 
        // IL_0077: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_007C: ldc.i4.1 1
        // IL_007D: stloc.s 7
        // IL_007F: leave IL_02BF
        // IL_0084: ldloc.3 3
        // IL_0085: ldc.i4.0 0
        // IL_0086: ldelem.ref 
        // IL_0087: ldloc.0 0
        // IL_0088: ldflda 0x04002207 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::kickClientID
        // IL_008D: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_0092: brtrue.s IL_0097
        // IL_0094: ldnull 
        // IL_0095: br.s IL_00B3
        // IL_0097: ldloc.0 0
        // IL_0098: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_009D: ldfld 0x0A0005A9 [OpenRA.Game]OpenRA.Server.Server::Conns
        // IL_00A2: ldloc.0 0
        // IL_00A3: ldftn 0x0600296E OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::<Kick>b__0
        // IL_00A9: newobj 0x0A0005DA class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Server.Connection, bool>::.ctor
        // IL_00AE: call 0x2B000100 [System.Linq]System.Linq.Enumerable::SingleOrDefault<class [OpenRA.Game]OpenRA.Server.Connection>
        // IL_00B3: stloc.s 4
        // IL_00B5: ldloc.s 4
        // IL_00B7: brtrue.s IL_00D3
        // IL_00B9: ldloc.0 0
        // IL_00BA: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_00BF: ldarg.1 1
        // IL_00C0: ldstr 0x7000D899 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 107, 105, 99, 107, 45, 110, 111, 110, 101] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 2D, 00, 6E, 00, 6F, 00, 6E, 00, 65, 00] terminal-flag=Some(1)
        // IL_00C5: ldnull 
        // IL_00C6: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_00CB: ldc.i4.1 1
        // IL_00CC: stloc.s 7
        // IL_00CE: leave IL_02BF
        // IL_00D3: ldloc.0 0
        // IL_00D4: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_00D9: ldloc.s 4
        // IL_00DB: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
        // IL_00E0: stloc.s 5
        // IL_00E2: ldarg.2 2
        // IL_00E3: ldloc.s 5
        // IL_00E5: bne.un.s IL_0101
        // IL_00E7: ldloc.0 0
        // IL_00E8: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_00ED: ldarg.1 1
        // IL_00EE: ldstr 0x7000D8C7 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 107, 105, 99, 107, 45, 115, 101, 108, 102] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 2D, 00, 73, 00, 65, 00, 6C, 00, 66, 00] terminal-flag=Some(1)
        // IL_00F3: ldnull 
        // IL_00F4: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_00F9: ldc.i4.1 1
        // IL_00FA: stloc.s 7
        // IL_00FC: leave IL_02BF
        // IL_0101: ldloc.0 0
        // IL_0102: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_0107: callvirt 0x0A00057A [OpenRA.Game]OpenRA.Server.Server::get_State
        // IL_010C: ldc.i4.2 2
        // IL_010D: bne.un.s IL_0141
        // IL_010F: ldloc.s 5
        // IL_0111: callvirt 0x0A0005DD [OpenRA.Game]OpenRA.Network.Session/Client::get_IsObserver
        // IL_0116: brtrue.s IL_0141
        // IL_0118: ldloc.0 0
        // IL_0119: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_011E: ldloc.s 5
        // IL_0120: callvirt 0x0A0005DE [OpenRA.Game]OpenRA.Server.Server::HasClientWonOrLost
        // IL_0125: brtrue.s IL_0141
        // IL_0127: ldloc.0 0
        // IL_0128: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_012D: ldarg.1 1
        // IL_012E: ldstr 0x7000D8F5 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 110, 111, 45, 107, 105, 99, 107, 45, 103, 97, 109, 101, 45, 115, 116, 97, 114, 116, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6E, 00, 6F, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 2D, 00, 67, 00, 61, 00, 6D, 00, 65, 00, 2D, 00, 73, 00, 74, 00, 61, 00, 72, 00, 74, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_0133: ldnull 
        // IL_0134: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0139: ldc.i4.1 1
        // IL_013A: stloc.s 7
        // IL_013C: leave IL_02BF
        // IL_0141: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0146: ldc.i4.s 16
        // IL_0148: ldc.i4.1 1
        // IL_0149: newobj 0x0A0002FA [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_014E: stloc.s 8
        // IL_0150: ldloca.s 8
        // IL_0152: ldstr 0x7000D939 [75, 105, 99, 107, 105, 110, 103, 32, 99, 108, 105, 101, 110, 116, 32] utf16-bytes=[4B, 00, 69, 00, 63, 00, 6B, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6C, 00, 69, 00, 65, 00, 6E, 00, 74, 00, 20, 00] terminal-flag=Some(0)
        // IL_0157: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_015C: ldloca.s 8
        // IL_015E: ldloc.0 0
        // IL_015F: ldfld 0x04002207 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::kickClientID
        // IL_0164: call 0x2B00004A [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_0169: ldloca.s 8
        // IL_016B: ldstr 0x70000F9A [46] utf16-bytes=[2E, 00] terminal-flag=Some(0)
        // IL_0170: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0175: ldloca.s 8
        // IL_0177: call 0x0A0002FD [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_017C: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_0181: ldloc.0 0
        // IL_0182: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_0187: ldstr 0x7000D959 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 107, 105, 99, 107, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_018C: ldc.i4.4 4
        // IL_018D: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0192: dup 
        // IL_0193: ldc.i4.0 0
        // IL_0194: ldstr 0x7000D98D [97, 100, 109, 105, 110] utf16-bytes=[61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_0199: stelem.ref 
        // IL_019A: dup 
        // IL_019B: ldc.i4.1 1
        // IL_019C: ldarg.2 2
        // IL_019D: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_01A2: stelem.ref 
        // IL_01A3: dup 
        // IL_01A4: ldc.i4.2 2
        // IL_01A5: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01AA: stelem.ref 
        // IL_01AB: dup 
        // IL_01AC: ldc.i4.3 3
        // IL_01AD: ldloc.s 5
        // IL_01AF: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_01B4: stelem.ref 
        // IL_01B5: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_01BA: ldloc.0 0
        // IL_01BB: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_01C0: ldloc.s 4
        // IL_01C2: ldstr 0x7000D517 [83, 101, 114, 118, 101, 114, 69, 114, 114, 111, 114] utf16-bytes=[53, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00, 45, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_01C7: ldstr 0x7000D999 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 121, 111, 117, 45, 119, 101, 114, 101, 45, 107, 105, 99, 107, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 79, 00, 6F, 00, 75, 00, 2D, 00, 77, 00, 65, 00, 72, 00, 65, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_01CC: callvirt 0x0A000592 [OpenRA.Game]OpenRA.Server.Server::SendOrderTo
        // IL_01D1: ldloc.0 0
        // IL_01D2: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_01D7: ldloc.s 4
        // IL_01D9: callvirt 0x0A0005AB [OpenRA.Game]OpenRA.Server.Server::DropClient
        // IL_01DE: ldloc.3 3
        // IL_01DF: ldc.i4.1 1
        // IL_01E0: ldelem.ref 
        // IL_01E1: ldloca.s 6
        // IL_01E3: call 0x0A0005A3 [System.Runtime]System.Boolean::TryParse
        // IL_01E8: ldloc.s 6
        // IL_01EA: and 
        // IL_01EB: brfalse IL_029A
        // IL_01F0: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01F5: ldc.i4.s 31
        // IL_01F7: ldc.i4.2 2
        // IL_01F8: newobj 0x0A0002FA [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_01FD: stloc.s 8
        // IL_01FF: ldloca.s 8
        // IL_0201: ldstr 0x7000D9D3 [84, 101, 109, 112, 111, 114, 97, 114, 105, 108, 121, 32, 98, 97, 110, 110, 105, 110, 103, 32, 99, 108, 105, 101, 110, 116, 32] utf16-bytes=[54, 00, 65, 00, 6D, 00, 70, 00, 6F, 00, 72, 00, 61, 00, 72, 00, 69, 00, 6C, 00, 79, 00, 20, 00, 62, 00, 61, 00, 6E, 00, 6E, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6C, 00, 69, 00, 65, 00, 6E, 00, 74, 00, 20, 00] terminal-flag=Some(0)
        // IL_0206: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_020B: ldloca.s 8
        // IL_020D: ldloc.0 0
        // IL_020E: ldfld 0x04002207 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::kickClientID
        // IL_0213: call 0x2B00004A [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_0218: ldloca.s 8
        // IL_021A: ldstr 0x7000DA0B [32, 40] utf16-bytes=[20, 00, 28, 00] terminal-flag=Some(0)
        // IL_021F: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0224: ldloca.s 8
        // IL_0226: ldloc.s 5
        // IL_0228: ldfld 0x0A0005DF [OpenRA.Game]OpenRA.Network.Session/Client::IPAddress
        // IL_022D: call 0x0A000300 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted
        // IL_0232: ldloca.s 8
        // IL_0234: ldstr 0x7000DA11 [41, 46] utf16-bytes=[29, 00, 2E, 00] terminal-flag=Some(0)
        // IL_0239: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_023E: ldloca.s 8
        // IL_0240: call 0x0A0002FD [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0245: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_024A: ldloc.0 0
        // IL_024B: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_0250: ldstr 0x7000DA17 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 116, 101, 109, 112, 45, 98, 97, 110] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 74, 00, 65, 00, 6D, 00, 70, 00, 2D, 00, 62, 00, 61, 00, 6E, 00] terminal-flag=Some(1)
        // IL_0255: ldc.i4.4 4
        // IL_0256: newarr 0x01000012 [System.Runtime]System.Object
        // IL_025B: dup 
        // IL_025C: ldc.i4.0 0
        // IL_025D: ldstr 0x7000D98D [97, 100, 109, 105, 110] utf16-bytes=[61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_0262: stelem.ref 
        // IL_0263: dup 
        // IL_0264: ldc.i4.1 1
        // IL_0265: ldarg.2 2
        // IL_0266: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_026B: stelem.ref 
        // IL_026C: dup 
        // IL_026D: ldc.i4.2 2
        // IL_026E: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0273: stelem.ref 
        // IL_0274: dup 
        // IL_0275: ldc.i4.3 3
        // IL_0276: ldloc.s 5
        // IL_0278: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_027D: stelem.ref 
        // IL_027E: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_0283: ldloc.0 0
        // IL_0284: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_0289: ldfld 0x0A0005E0 [OpenRA.Game]OpenRA.Server.Server::TempBans
        // IL_028E: ldloc.s 5
        // IL_0290: ldfld 0x0A0005DF [OpenRA.Game]OpenRA.Network.Session/Client::IPAddress
        // IL_0295: callvirt 0x0A000379 class [System.Collections]System.Collections.Generic.List`1<string>::Add
        // IL_029A: ldloc.0 0
        // IL_029B: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_02A0: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_02A5: ldloc.0 0
        // IL_02A6: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
        // IL_02AB: callvirt 0x0A0005AC [OpenRA.Game]OpenRA.Server.Server::SyncLobbySlots
        // IL_02B0: ldc.i4.1 1
        // IL_02B1: stloc.s 7
        // IL_02B3: leave.s IL_02BF
        // IL_02B5: ldloc.2 2
        // IL_02B6: brfalse.s IL_02BE
        // IL_02B8: ldloc.1 1
        // IL_02B9: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_02BE: endfinally 
        // IL_02BF: ldloc.s 7
        // IL_02C1: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 666, handler_offset: 693, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_02B5 finally IL_02B5..IL_02BF
    }

    private static bool VoteKick(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 6F, 29, 00, 06, 0A, 06, 02, 7D, 08, 22, 00, 04, 06, 7B, 08, 22, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 05, 1F, 20, 16, 6F, CC, 01, 00, 0A, 0D, 09, 8E, 69]
        // .code-bytes IL_0030: [18, 2E, 2F, 06, 7B, 08, 22, 00, 04, 03, 72, 07, D3, 00, 70, 18, 8D, 12, 00, 00, 01, 25, 16, 72]
        // .code-bytes IL_0048: [9D, D2, 00, 70, A2, 25, 17, 72, 43, DA, 00, 70, A2, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, B8, 01]
        // .code-bytes IL_0060: [00, 00, 06, 7B, 08, 22, 00, 04, 7B, BE, 05, 00, 0A, 7B, E1, 05, 00, 0A, 2D, 1A, 06, 7B, 08, 22]
        // .code-bytes IL_0078: [00, 04, 03, 72, 57, DA, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, 8C, 01, 00, 00, 09, 16]
        // .code-bytes IL_0090: [9A, 06, 7C, 09, 22, 00, 04, 28, AD, 05, 00, 0A, 2D, 03, 14, 2B, 1C, 06, 7B, 08, 22, 00, 04, 7B]
        // .code-bytes IL_00A8: [A9, 05, 00, 0A, 06, FE, 06, 70, 29, 00, 06, 73, DA, 05, 00, 0A, 28, 00, 01, 00, 2B, 13, 04, 11]
        // .code-bytes IL_00C0: [04, 2D, 1A, 06, 7B, 08, 22, 00, 04, 03, 72, 99, D8, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 07]
        // .code-bytes IL_00D8: [DD, 3D, 01, 00, 00, 06, 7B, 08, 22, 00, 04, 11, 04, 6F, DC, 05, 00, 0A, 13, 05, 04, 11, 05, 33]
        // .code-bytes IL_00F0: [1A, 06, 7B, 08, 22, 00, 04, 03, 72, C7, D8, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, 0F]
        // .code-bytes IL_0108: [01, 00, 00, 09, 17, 9A, 12, 06, 28, A3, 05, 00, 0A, 2D, 2F, 06, 7B, 08, 22, 00, 04, 03, 72, 07]
        // .code-bytes IL_0120: [D3, 00, 70, 18, 8D, 12, 00, 00, 01, 25, 16, 72, 9D, D2, 00, 70, A2, 25, 17, 72, 43, DA, 00, 70]
        // .code-bytes IL_0138: [A2, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, D4, 00, 00, 00, 06, 7B, 08, 22, 00, 04, 7B, E2, 05, 00]
        // .code-bytes IL_0150: [0A, 03, 04, 11, 04, 11, 05, 06, 7B, 09, 22, 00, 04, 11, 06, 6F, E3, 05, 00, 0A, 39, A2, 00, 00]
        // .code-bytes IL_0168: [00, 72, C5, D1, 00, 70, 1F, 10, 17, 73, FA, 02, 00, 0A, 13, 08, 12, 08, 72, 39, D9, 00, 70, 28]
        // .code-bytes IL_0180: [FB, 02, 00, 0A, 12, 08, 06, 7B, 09, 22, 00, 04, 28, 4A, 00, 00, 2B, 12, 08, 72, 9A, 0F, 00, 70]
        // .code-bytes IL_0198: [28, FB, 02, 00, 0A, 12, 08, 28, FD, 02, 00, 0A, 28, 76, 05, 00, 0A, 06, 7B, 08, 22, 00, 04, 72]
        // .code-bytes IL_01B0: [97, DA, 00, 70, 18, 8D, 12, 00, 00, 01, 25, 16, 72, CF, 3A, 00, 70, A2, 25, 17, 11, 05, 7B, B2]
        // .code-bytes IL_01C8: [05, 00, 0A, A2, 6F, D1, 05, 00, 0A, 06, 7B, 08, 22, 00, 04, 11, 04, 72, 17, D5, 00, 70, 72, 99]
        // .code-bytes IL_01E0: [D9, 00, 70, 6F, 92, 05, 00, 0A, 06, 7B, 08, 22, 00, 04, 11, 04, 6F, AB, 05, 00, 0A, 06, 7B, 08]
        // .code-bytes IL_01F8: [22, 00, 04, 6F, 8E, 05, 00, 0A, 06, 7B, 08, 22, 00, 04, 6F, AC, 05, 00, 0A, 17, 13, 07, DE, 0A]
        // .code-bytes IL_0210: [08, 2C, 06, 07, 28, 79, 05, 00, 0A, DC, 11, 07, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] string[]
        // .local [4] class [OpenRA.Game]OpenRA.Server.Connection
        // .local [5] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [6] bool
        // .local [7] bool
        // .local [8] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: newobj 0x0600296F OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldarg.3 3
        // IL_0024: ldc.i4.s 32
        // IL_0026: ldc.i4.0 0
        // IL_0027: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_002C: stloc.3 3
        // IL_002D: ldloc.3 3
        // IL_002E: ldlen 
        // IL_002F: conv.i4 
        // IL_0030: ldc.i4.2 2
        // IL_0031: beq.s IL_0062
        // IL_0033: ldloc.0 0
        // IL_0034: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_0039: ldarg.1 1
        // IL_003A: ldstr 0x7000D307 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 97, 108, 102, 111, 114, 109, 101, 100, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 61, 00, 6C, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 65, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_003F: ldc.i4.2 2
        // IL_0040: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0045: dup 
        // IL_0046: ldc.i4.0 0
        // IL_0047: ldstr 0x7000D29D [99, 111, 109, 109, 97, 110, 100] utf16-bytes=[63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_004C: stelem.ref 
        // IL_004D: dup 
        // IL_004E: ldc.i4.1 1
        // IL_004F: ldstr 0x7000DA43 [118, 111, 116, 101, 95, 107, 105, 99, 107] utf16-bytes=[76, 00, 6F, 00, 74, 00, 65, 00, 5F, 00, 6B, 00, 69, 00, 63, 00, 6B, 00] terminal-flag=Some(0)
        // IL_0054: stelem.ref 
        // IL_0055: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_005A: ldc.i4.1 1
        // IL_005B: stloc.s 7
        // IL_005D: leave IL_021A
        // IL_0062: ldloc.0 0
        // IL_0063: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_0068: ldfld 0x0A0005BE [OpenRA.Game]OpenRA.Server.Server::Settings
        // IL_006D: ldfld 0x0A0005E1 [OpenRA.Game]OpenRA.ServerSettings::EnableVoteKick
        // IL_0072: brtrue.s IL_008E
        // IL_0074: ldloc.0 0
        // IL_0075: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_007A: ldarg.1 1
        // IL_007B: ldstr 0x7000DA57 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 118, 111, 116, 101, 45, 107, 105, 99, 107, 45, 100, 105, 115, 97, 98, 108, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 76, 00, 6F, 00, 74, 00, 65, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 2D, 00, 64, 00, 69, 00, 73, 00, 61, 00, 62, 00, 6C, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_0080: ldnull 
        // IL_0081: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0086: ldc.i4.1 1
        // IL_0087: stloc.s 7
        // IL_0089: leave IL_021A
        // IL_008E: ldloc.3 3
        // IL_008F: ldc.i4.0 0
        // IL_0090: ldelem.ref 
        // IL_0091: ldloc.0 0
        // IL_0092: ldflda 0x04002209 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::kickClientID
        // IL_0097: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_009C: brtrue.s IL_00A1
        // IL_009E: ldnull 
        // IL_009F: br.s IL_00BD
        // IL_00A1: ldloc.0 0
        // IL_00A2: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_00A7: ldfld 0x0A0005A9 [OpenRA.Game]OpenRA.Server.Server::Conns
        // IL_00AC: ldloc.0 0
        // IL_00AD: ldftn 0x06002970 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::<VoteKick>b__0
        // IL_00B3: newobj 0x0A0005DA class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Server.Connection, bool>::.ctor
        // IL_00B8: call 0x2B000100 [System.Linq]System.Linq.Enumerable::SingleOrDefault<class [OpenRA.Game]OpenRA.Server.Connection>
        // IL_00BD: stloc.s 4
        // IL_00BF: ldloc.s 4
        // IL_00C1: brtrue.s IL_00DD
        // IL_00C3: ldloc.0 0
        // IL_00C4: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_00C9: ldarg.1 1
        // IL_00CA: ldstr 0x7000D899 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 107, 105, 99, 107, 45, 110, 111, 110, 101] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 2D, 00, 6E, 00, 6F, 00, 6E, 00, 65, 00] terminal-flag=Some(1)
        // IL_00CF: ldnull 
        // IL_00D0: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_00D5: ldc.i4.1 1
        // IL_00D6: stloc.s 7
        // IL_00D8: leave IL_021A
        // IL_00DD: ldloc.0 0
        // IL_00DE: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_00E3: ldloc.s 4
        // IL_00E5: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
        // IL_00EA: stloc.s 5
        // IL_00EC: ldarg.2 2
        // IL_00ED: ldloc.s 5
        // IL_00EF: bne.un.s IL_010B
        // IL_00F1: ldloc.0 0
        // IL_00F2: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_00F7: ldarg.1 1
        // IL_00F8: ldstr 0x7000D8C7 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 107, 105, 99, 107, 45, 115, 101, 108, 102] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 2D, 00, 73, 00, 65, 00, 6C, 00, 66, 00] terminal-flag=Some(1)
        // IL_00FD: ldnull 
        // IL_00FE: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0103: ldc.i4.1 1
        // IL_0104: stloc.s 7
        // IL_0106: leave IL_021A
        // IL_010B: ldloc.3 3
        // IL_010C: ldc.i4.1 1
        // IL_010D: ldelem.ref 
        // IL_010E: ldloca.s 6
        // IL_0110: call 0x0A0005A3 [System.Runtime]System.Boolean::TryParse
        // IL_0115: brtrue.s IL_0146
        // IL_0117: ldloc.0 0
        // IL_0118: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_011D: ldarg.1 1
        // IL_011E: ldstr 0x7000D307 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 97, 108, 102, 111, 114, 109, 101, 100, 45, 99, 111, 109, 109, 97, 110, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 61, 00, 6C, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 65, 00, 64, 00, 2D, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(1)
        // IL_0123: ldc.i4.2 2
        // IL_0124: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0129: dup 
        // IL_012A: ldc.i4.0 0
        // IL_012B: ldstr 0x7000D29D [99, 111, 109, 109, 97, 110, 100] utf16-bytes=[63, 00, 6F, 00, 6D, 00, 6D, 00, 61, 00, 6E, 00, 64, 00] terminal-flag=Some(0)
        // IL_0130: stelem.ref 
        // IL_0131: dup 
        // IL_0132: ldc.i4.1 1
        // IL_0133: ldstr 0x7000DA43 [118, 111, 116, 101, 95, 107, 105, 99, 107] utf16-bytes=[76, 00, 6F, 00, 74, 00, 65, 00, 5F, 00, 6B, 00, 69, 00, 63, 00, 6B, 00] terminal-flag=Some(0)
        // IL_0138: stelem.ref 
        // IL_0139: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_013E: ldc.i4.1 1
        // IL_013F: stloc.s 7
        // IL_0141: leave IL_021A
        // IL_0146: ldloc.0 0
        // IL_0147: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_014C: ldfld 0x0A0005E2 [OpenRA.Game]OpenRA.Server.Server::VoteKickTracker
        // IL_0151: ldarg.1 1
        // IL_0152: ldarg.2 2
        // IL_0153: ldloc.s 4
        // IL_0155: ldloc.s 5
        // IL_0157: ldloc.0 0
        // IL_0158: ldfld 0x04002209 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::kickClientID
        // IL_015D: ldloc.s 6
        // IL_015F: callvirt 0x0A0005E3 [OpenRA.Game]OpenRA.Server.VoteKickTracker::VoteKick
        // IL_0164: brfalse IL_020B
        // IL_0169: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_016E: ldc.i4.s 16
        // IL_0170: ldc.i4.1 1
        // IL_0171: newobj 0x0A0002FA [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_0176: stloc.s 8
        // IL_0178: ldloca.s 8
        // IL_017A: ldstr 0x7000D939 [75, 105, 99, 107, 105, 110, 103, 32, 99, 108, 105, 101, 110, 116, 32] utf16-bytes=[4B, 00, 69, 00, 63, 00, 6B, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6C, 00, 69, 00, 65, 00, 6E, 00, 74, 00, 20, 00] terminal-flag=Some(0)
        // IL_017F: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0184: ldloca.s 8
        // IL_0186: ldloc.0 0
        // IL_0187: ldfld 0x04002209 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::kickClientID
        // IL_018C: call 0x2B00004A [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_0191: ldloca.s 8
        // IL_0193: ldstr 0x70000F9A [46] utf16-bytes=[2E, 00] terminal-flag=Some(0)
        // IL_0198: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_019D: ldloca.s 8
        // IL_019F: call 0x0A0002FD [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_01A4: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_01A9: ldloc.0 0
        // IL_01AA: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_01AF: ldstr 0x7000DA97 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 107, 105, 99, 107, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_01B4: ldc.i4.2 2
        // IL_01B5: newarr 0x01000012 [System.Runtime]System.Object
        // IL_01BA: dup 
        // IL_01BB: ldc.i4.0 0
        // IL_01BC: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01C1: stelem.ref 
        // IL_01C2: dup 
        // IL_01C3: ldc.i4.1 1
        // IL_01C4: ldloc.s 5
        // IL_01C6: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_01CB: stelem.ref 
        // IL_01CC: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_01D1: ldloc.0 0
        // IL_01D2: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_01D7: ldloc.s 4
        // IL_01D9: ldstr 0x7000D517 [83, 101, 114, 118, 101, 114, 69, 114, 114, 111, 114] utf16-bytes=[53, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00, 45, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_01DE: ldstr 0x7000D999 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 121, 111, 117, 45, 119, 101, 114, 101, 45, 107, 105, 99, 107, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 79, 00, 6F, 00, 75, 00, 2D, 00, 77, 00, 65, 00, 72, 00, 65, 00, 2D, 00, 6B, 00, 69, 00, 63, 00, 6B, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_01E3: callvirt 0x0A000592 [OpenRA.Game]OpenRA.Server.Server::SendOrderTo
        // IL_01E8: ldloc.0 0
        // IL_01E9: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_01EE: ldloc.s 4
        // IL_01F0: callvirt 0x0A0005AB [OpenRA.Game]OpenRA.Server.Server::DropClient
        // IL_01F5: ldloc.0 0
        // IL_01F6: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_01FB: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_0200: ldloc.0 0
        // IL_0201: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
        // IL_0206: callvirt 0x0A0005AC [OpenRA.Game]OpenRA.Server.Server::SyncLobbySlots
        // IL_020B: ldc.i4.1 1
        // IL_020C: stloc.s 7
        // IL_020E: leave.s IL_021A
        // IL_0210: ldloc.2 2
        // IL_0211: brfalse.s IL_0219
        // IL_0213: ldloc.1 1
        // IL_0214: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0219: endfinally 
        // IL_021A: ldloc.s 7
        // IL_021C: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 501, handler_offset: 528, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_0210 finally IL_0210..IL_021A
    }

    private virtual void __name_4F70656E52412E5365727665722E495469636B2E5469636B(OpenRA.Server.Server server)
    {
        __cil_type_01000299 v1 = server.VoteKickTracker;
        v1.Tick();
        return;
    }

    private static bool MakeAdmin(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [73, 71, 29, 00, 06, 0A, 06, 02, 7D, 0A, 22, 00, 04, 06, 7B, 0A, 22, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 73, 73, 29, 00, 06, 0D, 09, 06, 7D, 0C, 22, 00, 04]
        // .code-bytes IL_0030: [04, 7B, 77, 05, 00, 0A, 2D, 1F, 09, 7B, 0C, 22, 00, 04, 7B, 0A, 22, 00, 04, 03, 72, BF, DA, 00]
        // .code-bytes IL_0048: [70, 14, 6F, 78, 05, 00, 0A, 17, 13, 07, DD, 6A, 01, 00, 00, 05, 09, 7C, 0B, 22, 00, 04, 28, AD]
        // .code-bytes IL_0060: [05, 00, 0A, 2D, 03, 14, 2B, 21, 09, 7B, 0C, 22, 00, 04, 7B, 0A, 22, 00, 04, 7B, A9, 05, 00, 0A]
        // .code-bytes IL_0078: [09, FE, 06, 74, 29, 00, 06, 73, DA, 05, 00, 0A, 28, 00, 01, 00, 2B, 13, 04, 11, 04, 2D, 1F, 09]
        // .code-bytes IL_0090: [7B, 0C, 22, 00, 04, 7B, 0A, 22, 00, 04, 03, 72, 03, DB, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13]
        // .code-bytes IL_00A8: [07, DD, 13, 01, 00, 00, 09, 7B, 0C, 22, 00, 04, 7B, 0A, 22, 00, 04, 11, 04, 6F, DC, 05, 00, 0A]
        // .code-bytes IL_00C0: [13, 05, 04, 16, 7D, 77, 05, 00, 0A, 11, 05, 17, 7D, 77, 05, 00, 0A, 09, 7B, 0C, 22, 00, 04, 7B]
        // .code-bytes IL_00D8: [0A, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 09, 7B, 0C, 22, 00, 04, FE, 06, 72, 29]
        // .code-bytes IL_00F0: [00, 06, 73, D8, 05, 00, 0A, 28, FD, 00, 00, 2B, 7E, E9, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21]
        // .code-bytes IL_0108: [00, 04, FE, 06, 47, 29, 00, 06, 73, 7F, 05, 00, 0A, 25, 80, E9, 21, 00, 04, 28, FE, 00, 00, 2B]
        // .code-bytes IL_0120: [13, 06, 11, 06, 6F, E5, 05, 00, 0A, 13, 08, 2B, 16, 11, 08, 6F, E6, 05, 00, 0A, 13, 09, 11, 09]
        // .code-bytes IL_0138: [09, 7B, 0B, 22, 00, 04, 7D, B4, 05, 00, 0A, 11, 08, 6F, 1B, 00, 00, 0A, 2D, E1, DE, 0C, 11, 08]
        // .code-bytes IL_0150: [2C, 07, 11, 08, 6F, 1A, 00, 00, 0A, DC, 09, 7B, 0C, 22, 00, 04, 7B, 0A, 22, 00, 04, 72, 33, DB]
        // .code-bytes IL_0168: [00, 70, 18, 8D, 12, 00, 00, 01, 25, 16, 72, CF, 3A, 00, 70, A2, 25, 17, 11, 05, 7B, B2, 05, 00]
        // .code-bytes IL_0180: [0A, A2, 6F, D1, 05, 00, 0A, 72, C5, D1, 00, 70, 11, 05, 7B, B2, 05, 00, 0A, 72, 61, DB, 00, 70]
        // .code-bytes IL_0198: [28, 44, 02, 00, 0A, 28, 76, 05, 00, 0A, 09, 7B, 0C, 22, 00, 04, 7B, 0A, 22, 00, 04, 6F, 8E, 05]
        // .code-bytes IL_01B0: [00, 0A, 17, 13, 07, DE, 0A, 08, 2C, 06, 07, 28, 79, 05, 00, 0A, DC, 11, 07, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1
        // .local [4] class [OpenRA.Game]OpenRA.Server.Connection
        // .local [5] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [6] class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [7] bool
        // .local [8] class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // .local [9] class [OpenRA.Game]OpenRA.Network.Session/Client
        // IL_0000: newobj 0x06002971 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: newobj 0x06002973 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::.ctor
        // IL_0028: stloc.3 3
        // IL_0029: ldloc.3 3
        // IL_002A: ldloc.0 0
        // IL_002B: stfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_0030: ldarg.2 2
        // IL_0031: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0036: brtrue.s IL_0057
        // IL_0038: ldloc.3 3
        // IL_0039: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_003E: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_0043: ldarg.1 1
        // IL_0044: ldstr 0x7000DABF [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 116, 114, 97, 110, 115, 102, 101, 114, 45, 97, 100, 109, 105, 110] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 74, 00, 72, 00, 61, 00, 6E, 00, 73, 00, 66, 00, 65, 00, 72, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00] terminal-flag=Some(1)
        // IL_0049: ldnull 
        // IL_004A: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_004F: ldc.i4.1 1
        // IL_0050: stloc.s 7
        // IL_0052: leave IL_01C1
        // IL_0057: ldarg.3 3
        // IL_0058: ldloc.3 3
        // IL_0059: ldflda 0x0400220B OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::newAdminId
        // IL_005E: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_0063: brtrue.s IL_0068
        // IL_0065: ldnull 
        // IL_0066: br.s IL_0089
        // IL_0068: ldloc.3 3
        // IL_0069: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_006E: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_0073: ldfld 0x0A0005A9 [OpenRA.Game]OpenRA.Server.Server::Conns
        // IL_0078: ldloc.3 3
        // IL_0079: ldftn 0x06002974 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::<MakeAdmin>b__0
        // IL_007F: newobj 0x0A0005DA class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Server.Connection, bool>::.ctor
        // IL_0084: call 0x2B000100 [System.Linq]System.Linq.Enumerable::SingleOrDefault<class [OpenRA.Game]OpenRA.Server.Connection>
        // IL_0089: stloc.s 4
        // IL_008B: ldloc.s 4
        // IL_008D: brtrue.s IL_00AE
        // IL_008F: ldloc.3 3
        // IL_0090: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_0095: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_009A: ldarg.1 1
        // IL_009B: ldstr 0x7000DB03 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 101, 109, 112, 116, 121, 45, 115, 108, 111, 116] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 65, 00, 6D, 00, 70, 00, 74, 00, 79, 00, 2D, 00, 73, 00, 6C, 00, 6F, 00, 74, 00] terminal-flag=Some(1)
        // IL_00A0: ldnull 
        // IL_00A1: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_00A6: ldc.i4.1 1
        // IL_00A7: stloc.s 7
        // IL_00A9: leave IL_01C1
        // IL_00AE: ldloc.3 3
        // IL_00AF: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_00B4: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_00B9: ldloc.s 4
        // IL_00BB: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
        // IL_00C0: stloc.s 5
        // IL_00C2: ldarg.2 2
        // IL_00C3: ldc.i4.0 0
        // IL_00C4: stfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_00C9: ldloc.s 5
        // IL_00CB: ldc.i4.1 1
        // IL_00CC: stfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_00D1: ldloc.3 3
        // IL_00D2: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_00D7: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_00DC: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00E1: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_00E6: ldloc.3 3
        // IL_00E7: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_00EC: ldftn 0x06002972 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::<MakeAdmin>b__1
        // IL_00F2: newobj 0x0A0005D8 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, class [OpenRA.Game]OpenRA.Network.Session/Client>::.ctor
        // IL_00F7: call 0x2B0000FD [System.Linq]System.Linq.Enumerable::Select<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00FC: ldsfld 0x040021E9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__65_2
        // IL_0101: dup 
        // IL_0102: brtrue.s IL_011B
        // IL_0104: pop 
        // IL_0105: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_010A: ldftn 0x06002947 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<MakeAdmin>b__65_2
        // IL_0110: newobj 0x0A00057F class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, bool>::.ctor
        // IL_0115: dup 
        // IL_0116: stsfld 0x040021E9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__65_2
        // IL_011B: call 0x2B0000FE [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_0120: stloc.s 6
        // IL_0122: ldloc.s 6
        // IL_0124: callvirt 0x0A0005E5 class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::GetEnumerator
        // IL_0129: stloc.s 8
        // IL_012B: br.s IL_0143
        // IL_012D: ldloc.s 8
        // IL_012F: callvirt 0x0A0005E6 class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Current
        // IL_0134: stloc.s 9
        // IL_0136: ldloc.s 9
        // IL_0138: ldloc.3 3
        // IL_0139: ldfld 0x0400220B OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::newAdminId
        // IL_013E: stfld 0x0A0005B4 [OpenRA.Game]OpenRA.Network.Session/Client::BotControllerClientIndex
        // IL_0143: ldloc.s 8
        // IL_0145: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_014A: brtrue.s IL_012D
        // IL_014C: leave.s IL_015A
        // IL_014E: ldloc.s 8
        // IL_0150: brfalse.s IL_0159
        // IL_0152: ldloc.s 8
        // IL_0154: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_0159: endfinally 
        // IL_015A: ldloc.3 3
        // IL_015B: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_0160: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_0165: ldstr 0x7000DB33 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 110, 101, 119, 45, 97, 100, 109, 105, 110] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6E, 00, 65, 00, 77, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00] terminal-flag=Some(1)
        // IL_016A: ldc.i4.2 2
        // IL_016B: newarr 0x01000012 [System.Runtime]System.Object
        // IL_0170: dup 
        // IL_0171: ldc.i4.0 0
        // IL_0172: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0177: stelem.ref 
        // IL_0178: dup 
        // IL_0179: ldc.i4.1 1
        // IL_017A: ldloc.s 5
        // IL_017C: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_0181: stelem.ref 
        // IL_0182: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_0187: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_018C: ldloc.s 5
        // IL_018E: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_0193: ldstr 0x7000DB61 [32, 105, 115, 32, 110, 111, 119, 32, 116, 104, 101, 32, 97, 100, 109, 105, 110, 46] utf16-bytes=[20, 00, 69, 00, 73, 00, 20, 00, 6E, 00, 6F, 00, 77, 00, 20, 00, 74, 00, 68, 00, 65, 00, 20, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2E, 00] terminal-flag=Some(0)
        // IL_0198: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_019D: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_01A2: ldloc.3 3
        // IL_01A3: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
        // IL_01A8: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
        // IL_01AD: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_01B2: ldc.i4.1 1
        // IL_01B3: stloc.s 7
        // IL_01B5: leave.s IL_01C1
        // IL_01B7: ldloc.2 2
        // IL_01B8: brfalse.s IL_01C0
        // IL_01BA: ldloc.1 1
        // IL_01BB: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_01C0: endfinally 
        // IL_01C1: ldloc.s 7
        // IL_01C3: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 299, try_length: 35, handler_offset: 334, handler_length: 12, raw_flags: 2 }
        // .try IL_012B..IL_014E finally IL_014E..IL_015A
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 412, handler_offset: 439, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_01B7 finally IL_01B7..IL_01C1
    }

    private static bool MakeSpectator(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [73, 75, 29, 00, 06, 0A, 06, 02, 7D, 0D, 22, 00, 04, 06, 7B, 0D, 22, 00, 04, 7B, 72, 05, 00, 0A]
        // .code-bytes IL_0018: [0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 04, 7B, 77, 05, 00, 0A, 2D, 1A, 06, 7B, 0D, 22, 00]
        // .code-bytes IL_0030: [04, 03, 72, 87, DB, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 05, DD, 11, 01, 00, 00, 05, 06, 7C]
        // .code-bytes IL_0048: [0E, 22, 00, 04, 28, AD, 05, 00, 0A, 2D, 03, 14, 2B, 1C, 06, 7B, 0D, 22, 00, 04, 7B, A9, 05, 00]
        // .code-bytes IL_0060: [0A, 06, FE, 06, 76, 29, 00, 06, 73, DA, 05, 00, 0A, 28, 00, 01, 00, 2B, 0D, 09, 2D, 1A, 06, 7B]
        // .code-bytes IL_0078: [0D, 22, 00, 04, 03, 72, 03, DB, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 05, DD, C6, 00, 00, 00]
        // .code-bytes IL_0090: [06, 7B, 0D, 22, 00, 04, 09, 6F, DC, 05, 00, 0A, 13, 04, 11, 04, 14, 7D, 96, 05, 00, 0A, 11, 04]
        // .code-bytes IL_00A8: [16, 7D, 99, 05, 00, 0A, 11, 04, 16, 7D, A5, 05, 00, 0A, 11, 04, 16, 7D, A6, 05, 00, 0A, 11, 04]
        // .code-bytes IL_00C0: [28, BF, 02, 00, 0A, 7D, 9F, 05, 00, 0A, 11, 04, 16, 7D, 7B, 05, 00, 0A, 06, 7B, 0D, 22, 00, 04]
        // .code-bytes IL_00D8: [72, CD, DB, 00, 70, 1A, 8D, 12, 00, 00, 01, 25, 16, 72, 8D, D9, 00, 70, A2, 25, 17, 04, 7B, B2]
        // .code-bytes IL_00F0: [05, 00, 0A, A2, 25, 18, 72, CF, 3A, 00, 70, A2, 25, 19, 11, 04, 7B, B2, 05, 00, 0A, A2, 6F, D1]
        // .code-bytes IL_0108: [05, 00, 0A, 72, C5, D1, 00, 70, 04, 7B, B2, 05, 00, 0A, 72, 07, DC, 00, 70, 11, 04, 7B, B2, 05]
        // .code-bytes IL_0120: [00, 0A, 72, 17, DC, 00, 70, 28, 3D, 02, 00, 0A, 28, 76, 05, 00, 0A, 06, 7B, 0D, 22, 00, 04, 6F]
        // .code-bytes IL_0138: [8E, 05, 00, 0A, 06, 7B, 0D, 22, 00, 04, 28, 24, 03, 00, 06, 17, 13, 05, DE, 0A, 08, 2C, 06, 07]
        // .code-bytes IL_0150: [28, 79, 05, 00, 0A, DC, 11, 05, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class [OpenRA.Game]OpenRA.Server.Connection
        // .local [4] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [5] bool
        // IL_0000: newobj 0x06002975 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.0 0
        // IL_0008: stfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_000D: ldloc.0 0
        // IL_000E: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_0013: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0018: stloc.1 1
        // IL_0019: ldc.i4.0 0
        // IL_001A: stloc.2 2
        // IL_001B: ldloc.1 1
        // IL_001C: ldloca.s 2
        // IL_001E: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0023: ldarg.2 2
        // IL_0024: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0029: brtrue.s IL_0045
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_0031: ldarg.1 1
        // IL_0032: ldstr 0x7000DB87 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 109, 111, 118, 101, 45, 115, 112, 101, 99, 116, 97, 116, 111, 114, 115] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 6D, 00, 6F, 00, 76, 00, 65, 00, 2D, 00, 73, 00, 70, 00, 65, 00, 63, 00, 74, 00, 61, 00, 74, 00, 6F, 00, 72, 00, 73, 00] terminal-flag=Some(1)
        // IL_0037: ldnull 
        // IL_0038: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_003D: ldc.i4.1 1
        // IL_003E: stloc.s 5
        // IL_0040: leave IL_0156
        // IL_0045: ldarg.3 3
        // IL_0046: ldloc.0 0
        // IL_0047: ldflda 0x0400220E OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::targetId
        // IL_004C: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_0051: brtrue.s IL_0056
        // IL_0053: ldnull 
        // IL_0054: br.s IL_0072
        // IL_0056: ldloc.0 0
        // IL_0057: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_005C: ldfld 0x0A0005A9 [OpenRA.Game]OpenRA.Server.Server::Conns
        // IL_0061: ldloc.0 0
        // IL_0062: ldftn 0x06002976 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::<MakeSpectator>b__0
        // IL_0068: newobj 0x0A0005DA class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Server.Connection, bool>::.ctor
        // IL_006D: call 0x2B000100 [System.Linq]System.Linq.Enumerable::SingleOrDefault<class [OpenRA.Game]OpenRA.Server.Connection>
        // IL_0072: stloc.3 3
        // IL_0073: ldloc.3 3
        // IL_0074: brtrue.s IL_0090
        // IL_0076: ldloc.0 0
        // IL_0077: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_007C: ldarg.1 1
        // IL_007D: ldstr 0x7000DB03 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 101, 109, 112, 116, 121, 45, 115, 108, 111, 116] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 65, 00, 6D, 00, 70, 00, 74, 00, 79, 00, 2D, 00, 73, 00, 6C, 00, 6F, 00, 74, 00] terminal-flag=Some(1)
        // IL_0082: ldnull 
        // IL_0083: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0088: ldc.i4.1 1
        // IL_0089: stloc.s 5
        // IL_008B: leave IL_0156
        // IL_0090: ldloc.0 0
        // IL_0091: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_0096: ldloc.3 3
        // IL_0097: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
        // IL_009C: stloc.s 4
        // IL_009E: ldloc.s 4
        // IL_00A0: ldnull 
        // IL_00A1: stfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_00A6: ldloc.s 4
        // IL_00A8: ldc.i4.0 0
        // IL_00A9: stfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
        // IL_00AE: ldloc.s 4
        // IL_00B0: ldc.i4.0 0
        // IL_00B1: stfld 0x0A0005A5 [OpenRA.Game]OpenRA.Network.Session/Client::Team
        // IL_00B6: ldloc.s 4
        // IL_00B8: ldc.i4.0 0
        // IL_00B9: stfld 0x0A0005A6 [OpenRA.Game]OpenRA.Network.Session/Client::Handicap
        // IL_00BE: ldloc.s 4
        // IL_00C0: call 0x0A0002BF [OpenRA.Game]OpenRA.Primitives.Color::get_White
        // IL_00C5: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_00CA: ldloc.s 4
        // IL_00CC: ldc.i4.0 0
        // IL_00CD: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_00D2: ldloc.0 0
        // IL_00D3: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_00D8: ldstr 0x7000DBCD [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 111, 118, 101, 45, 115, 112, 101, 99, 116, 97, 116, 111, 114, 115] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 6F, 00, 76, 00, 65, 00, 2D, 00, 73, 00, 70, 00, 65, 00, 63, 00, 74, 00, 61, 00, 74, 00, 6F, 00, 72, 00, 73, 00] terminal-flag=Some(1)
        // IL_00DD: ldc.i4.4 4
        // IL_00DE: newarr 0x01000012 [System.Runtime]System.Object
        // IL_00E3: dup 
        // IL_00E4: ldc.i4.0 0
        // IL_00E5: ldstr 0x7000D98D [97, 100, 109, 105, 110] utf16-bytes=[61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_00EA: stelem.ref 
        // IL_00EB: dup 
        // IL_00EC: ldc.i4.1 1
        // IL_00ED: ldarg.2 2
        // IL_00EE: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_00F3: stelem.ref 
        // IL_00F4: dup 
        // IL_00F5: ldc.i4.2 2
        // IL_00F6: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00FB: stelem.ref 
        // IL_00FC: dup 
        // IL_00FD: ldc.i4.3 3
        // IL_00FE: ldloc.s 4
        // IL_0100: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_0105: stelem.ref 
        // IL_0106: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_010B: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0110: ldarg.2 2
        // IL_0111: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_0116: ldstr 0x7000DC07 [32, 109, 111, 118, 101, 100, 32] utf16-bytes=[20, 00, 6D, 00, 6F, 00, 76, 00, 65, 00, 64, 00, 20, 00] terminal-flag=Some(0)
        // IL_011B: ldloc.s 4
        // IL_011D: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_0122: ldstr 0x7000DC17 [32, 116, 111, 32, 115, 112, 101, 99, 116, 97, 116, 111, 114, 115, 46] utf16-bytes=[20, 00, 74, 00, 6F, 00, 20, 00, 73, 00, 70, 00, 65, 00, 63, 00, 74, 00, 61, 00, 74, 00, 6F, 00, 72, 00, 73, 00, 2E, 00] terminal-flag=Some(0)
        // IL_0127: call 0x0A00023D [System.Runtime]System.String::Concat
        // IL_012C: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_0131: ldloc.0 0
        // IL_0132: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_0137: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_013C: ldloc.0 0
        // IL_013D: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
        // IL_0142: call 0x06000324 OpenRA.Mods.Common.Server.LobbyCommands::CheckAutoStart
        // IL_0147: ldc.i4.1 1
        // IL_0148: stloc.s 5
        // IL_014A: leave.s IL_0156
        // IL_014C: ldloc.2 2
        // IL_014D: brfalse.s IL_0155
        // IL_014F: ldloc.1 1
        // IL_0150: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0155: endfinally 
        // IL_0156: ldloc.s 5
        // IL_0158: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 27, try_length: 305, handler_offset: 332, handler_length: 10, raw_flags: 2 }
        // .try IL_001B..IL_014C finally IL_014C..IL_0156
    }

    private static bool Name(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 6
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 05, 28, E7, 05, 00, 0A, 0C]
        // .code-bytes IL_0018: [08, 04, 7B, B2, 05, 00, 0A, 28, BD, 02, 00, 0A, 2C, 07, 17, 0D, DD, 9D, 00, 00, 00, 72, C5, D1]
        // .code-bytes IL_0030: [00, 70, 1F, 19, 18, 73, FA, 02, 00, 0A, 13, 04, 12, 04, 72, 37, DC, 00, 70, 28, FB, 02, 00, 0A]
        // .code-bytes IL_0048: [12, 04, 03, 7B, 91, 05, 00, 0A, 28, ED, 00, 00, 2B, 12, 04, 72, 47, DC, 00, 70, 28, FB, 02, 00]
        // .code-bytes IL_0060: [0A, 12, 04, 08, 28, 00, 03, 00, 0A, 12, 04, 72, 9A, 0F, 00, 70, 28, FB, 02, 00, 0A, 12, 04, 28]
        // .code-bytes IL_0078: [FD, 02, 00, 0A, 28, 76, 05, 00, 0A, 02, 72, 6B, DC, 00, 70, 1A, 8D, 12, 00, 00, 01, 25, 16, 72]
        // .code-bytes IL_0090: [CF, 3A, 00, 70, A2, 25, 17, 04, 7B, B2, 05, 00, 0A, A2, 25, 18, 72, D9, D7, 00, 70, A2, 25, 19]
        // .code-bytes IL_00A8: [08, A2, 6F, D1, 05, 00, 0A, 04, 08, 7D, B2, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 17, 0D, DE, 0A]
        // .code-bytes IL_00C0: [07, 2C, 06, 06, 28, 79, 05, 00, 0A, DC, 09, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] string
        // .local [3] bool
        // .local [4] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.3 3
        // IL_0012: call 0x0A0005E7 [OpenRA.Game]OpenRA.Settings::SanitizedPlayerName
        // IL_0017: stloc.2 2
        // IL_0018: ldloc.2 2
        // IL_0019: ldarg.2 2
        // IL_001A: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_001F: call 0x0A0002BD [System.Runtime]System.String::op_Equality
        // IL_0024: brfalse.s IL_002D
        // IL_0026: ldc.i4.1 1
        // IL_0027: stloc.3 3
        // IL_0028: leave IL_00CA
        // IL_002D: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0032: ldc.i4.s 25
        // IL_0034: ldc.i4.2 2
        // IL_0035: newobj 0x0A0002FA [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_003A: stloc.s 4
        // IL_003C: ldloca.s 4
        // IL_003E: ldstr 0x7000DC37 [80, 108, 97, 121, 101, 114, 64] utf16-bytes=[50, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00, 40, 00] terminal-flag=Some(0)
        // IL_0043: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0048: ldloca.s 4
        // IL_004A: ldarg.1 1
        // IL_004B: ldfld 0x0A000591 [OpenRA.Game]OpenRA.Server.Connection::EndPoint
        // IL_0050: call 0x2B0000ED [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<class [System.Net.Primitives]System.Net.EndPoint>
        // IL_0055: ldloca.s 4
        // IL_0057: ldstr 0x7000DC47 [32, 105, 115, 32, 110, 111, 119, 32, 107, 110, 111, 119, 110, 32, 97, 115, 32] utf16-bytes=[20, 00, 69, 00, 73, 00, 20, 00, 6E, 00, 6F, 00, 77, 00, 20, 00, 6B, 00, 6E, 00, 6F, 00, 77, 00, 6E, 00, 20, 00, 61, 00, 73, 00, 20, 00] terminal-flag=Some(0)
        // IL_005C: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0061: ldloca.s 4
        // IL_0063: ldloc.2 2
        // IL_0064: call 0x0A000300 [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted
        // IL_0069: ldloca.s 4
        // IL_006B: ldstr 0x70000F9A [46] utf16-bytes=[2E, 00] terminal-flag=Some(0)
        // IL_0070: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0075: ldloca.s 4
        // IL_0077: call 0x0A0002FD [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_007C: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_0081: ldarg.0 0
        // IL_0082: ldstr 0x7000DC6B [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 110, 105, 99, 107, 45, 99, 104, 97, 110, 103, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6E, 00, 69, 00, 63, 00, 6B, 00, 2D, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_0087: ldc.i4.4 4
        // IL_0088: newarr 0x01000012 [System.Runtime]System.Object
        // IL_008D: dup 
        // IL_008E: ldc.i4.0 0
        // IL_008F: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0094: stelem.ref 
        // IL_0095: dup 
        // IL_0096: ldc.i4.1 1
        // IL_0097: ldarg.2 2
        // IL_0098: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_009D: stelem.ref 
        // IL_009E: dup 
        // IL_009F: ldc.i4.2 2
        // IL_00A0: ldstr 0x7000D7D9 [110, 97, 109, 101] utf16-bytes=[6E, 00, 61, 00, 6D, 00, 65, 00] terminal-flag=Some(0)
        // IL_00A5: stelem.ref 
        // IL_00A6: dup 
        // IL_00A7: ldc.i4.3 3
        // IL_00A8: ldloc.2 2
        // IL_00A9: stelem.ref 
        // IL_00AA: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
        // IL_00AF: ldarg.2 2
        // IL_00B0: ldloc.2 2
        // IL_00B1: stfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
        // IL_00B6: ldarg.0 0
        // IL_00B7: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_00BC: ldc.i4.1 1
        // IL_00BD: stloc.3 3
        // IL_00BE: leave.s IL_00CA
        // IL_00C0: ldloc.1 1
        // IL_00C1: brfalse.s IL_00C9
        // IL_00C3: ldloc.0 0
        // IL_00C4: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00C9: endfinally 
        // IL_00CA: ldloc.3 3
        // IL_00CB: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 183, handler_offset: 192, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00C0 finally IL_00C0..IL_00CA
    }

    private static bool Faction(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 77, 29, 00, 06, 0A, 06, 04, 7D, 0F, 22, 00, 04, 02, 7B, 72, 05, 00, 0A, 0B, 16, 0C, 07, 12]
        // .code-bytes IL_0018: [02, 28, 73, 05, 00, 0A, 05, 1F, 20, 16, 6F, CC, 01, 00, 0A, 0D, 02, 7B, 72, 05, 00, 0A, 09, 16]
        // .code-bytes IL_0030: [9A, 28, E8, 05, 00, 0A, 6F, E9, 05, 00, 0A, 13, 04, 11, 04, 7B, A0, 05, 00, 0A, 06, 7B, 0F, 22]
        // .code-bytes IL_0048: [00, 04, 7B, A0, 05, 00, 0A, 2E, 15, 06, 7B, 0F, 22, 00, 04, 7B, 77, 05, 00, 0A, 2D, 08, 17, 13]
        // .code-bytes IL_0060: [07, DD, 91, 00, 00, 00, 02, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 11, 04, 7B, 96, 05, 00, 0A]
        // .code-bytes IL_0078: [6F, 97, 05, 00, 0A, 7B, EA, 05, 00, 0A, 2C, 05, 17, 13, 07, DE, 6E, 09, 17, 9A, 13, 05, 02, 7B]
        // .code-bytes IL_0090: [86, 05, 00, 0A, 6F, C2, 05, 00, 0A, 6F, 01, 01, 00, 2B, 06, FE, 06, 78, 29, 00, 06, 73, EB, 05]
        // .code-bytes IL_00A8: [00, 0A, 28, 02, 01, 00, 2B, 13, 06, 11, 06, 2D, 24, 02, 03, 72, 9F, DC, 00, 70, 18, 8D, 12, 00]
        // .code-bytes IL_00C0: [00, 01, 25, 16, 72, EB, DC, 00, 70, A2, 25, 17, 11, 05, A2, 6F, 78, 05, 00, 0A, 17, 13, 07, DE]
        // .code-bytes IL_00D8: [1E, 11, 04, 11, 05, 7D, B3, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 17, 13, 07, DE, 0A, 08, 2C, 06]
        // .code-bytes IL_00F0: [07, 28, 79, 05, 00, 0A, DC, 11, 07, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass68_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] string[]
        // .local [4] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [5] string
        // .local [6] bool
        // .local [7] bool
        // IL_0000: newobj 0x06002977 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass68_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.2 2
        // IL_0008: stfld 0x0400220F OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass68_0::client
        // IL_000D: ldarg.0 0
        // IL_000E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0013: stloc.1 1
        // IL_0014: ldc.i4.0 0
        // IL_0015: stloc.2 2
        // IL_0016: ldloc.1 1
        // IL_0017: ldloca.s 2
        // IL_0019: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_001E: ldarg.3 3
        // IL_001F: ldc.i4.s 32
        // IL_0021: ldc.i4.0 0
        // IL_0022: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_0027: stloc.3 3
        // IL_0028: ldarg.0 0
        // IL_0029: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_002E: ldloc.3 3
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldelem.ref 
        // IL_0031: call 0x0A0005E8 [OpenRA.Game]OpenRA.Exts::ParseInt32Invariant
        // IL_0036: callvirt 0x0A0005E9 [OpenRA.Game]OpenRA.Network.Session::ClientWithIndex
        // IL_003B: stloc.s 4
        // IL_003D: ldloc.s 4
        // IL_003F: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_0044: ldloc.0 0
        // IL_0045: ldfld 0x0400220F OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass68_0::client
        // IL_004A: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_004F: beq.s IL_0066
        // IL_0051: ldloc.0 0
        // IL_0052: ldfld 0x0400220F OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass68_0::client
        // IL_0057: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_005C: brtrue.s IL_0066
        // IL_005E: ldc.i4.1 1
        // IL_005F: stloc.s 7
        // IL_0061: leave IL_00F7
        // IL_0066: ldarg.0 0
        // IL_0067: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_006C: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0071: ldloc.s 4
        // IL_0073: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0078: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_007D: ldfld 0x0A0005EA [OpenRA.Game]OpenRA.Network.Session/Slot::LockFaction
        // IL_0082: brfalse.s IL_0089
        // IL_0084: ldc.i4.1 1
        // IL_0085: stloc.s 7
        // IL_0087: leave.s IL_00F7
        // IL_0089: ldloc.3 3
        // IL_008A: ldc.i4.1 1
        // IL_008B: ldelem.ref 
        // IL_008C: stloc.s 5
        // IL_008E: ldarg.0 0
        // IL_008F: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0094: callvirt 0x0A0005C2 [OpenRA.Game]OpenRA.MapPreview::get_WorldActorInfo
        // IL_0099: callvirt 0x2B000101 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.FactionInfo>
        // IL_009E: ldloc.0 0
        // IL_009F: ldftn 0x06002978 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass68_0::<Faction>b__0
        // IL_00A5: newobj 0x0A0005EB class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.FactionInfo, bool>::.ctor
        // IL_00AA: call 0x2B000102 [System.Linq]System.Linq.Enumerable::Any<class [OpenRA.Game]OpenRA.Traits.FactionInfo>
        // IL_00AF: stloc.s 6
        // IL_00B1: ldloc.s 6
        // IL_00B3: brtrue.s IL_00D9
        // IL_00B5: ldarg.0 0
        // IL_00B6: ldarg.1 1
        // IL_00B7: ldstr 0x7000DC9F [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 105, 110, 118, 97, 108, 105, 100, 45, 102, 97, 99, 116, 105, 111, 110, 45, 115, 101, 108, 101, 99, 116, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 69, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 2D, 00, 66, 00, 61, 00, 63, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 73, 00, 65, 00, 6C, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_00BC: ldc.i4.2 2
        // IL_00BD: newarr 0x01000012 [System.Runtime]System.Object
        // IL_00C2: dup 
        // IL_00C3: ldc.i4.0 0
        // IL_00C4: ldstr 0x7000DCEB [102, 97, 99, 116, 105, 111, 110] utf16-bytes=[66, 00, 61, 00, 63, 00, 74, 00, 69, 00, 6F, 00, 6E, 00] terminal-flag=Some(0)
        // IL_00C9: stelem.ref 
        // IL_00CA: dup 
        // IL_00CB: ldc.i4.1 1
        // IL_00CC: ldloc.s 5
        // IL_00CE: stelem.ref 
        // IL_00CF: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_00D4: ldc.i4.1 1
        // IL_00D5: stloc.s 7
        // IL_00D7: leave.s IL_00F7
        // IL_00D9: ldloc.s 4
        // IL_00DB: ldloc.s 5
        // IL_00DD: stfld 0x0A0005B3 [OpenRA.Game]OpenRA.Network.Session/Client::Faction
        // IL_00E2: ldarg.0 0
        // IL_00E3: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_00E8: ldc.i4.1 1
        // IL_00E9: stloc.s 7
        // IL_00EB: leave.s IL_00F7
        // IL_00ED: ldloc.2 2
        // IL_00EE: brfalse.s IL_00F6
        // IL_00F0: ldloc.1 1
        // IL_00F1: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00F6: endfinally 
        // IL_00F7: ldloc.s 7
        // IL_00F9: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 22, try_length: 215, handler_offset: 237, handler_length: 10, raw_flags: 2 }
        // .try IL_0016..IL_00ED finally IL_00ED..IL_00F7
    }

    private static bool Team(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 05, 1F, 20, 16, 6F, CC, 01]
        // .code-bytes IL_0018: [00, 0A, 0C, 02, 7B, 72, 05, 00, 0A, 08, 16, 9A, 28, E8, 05, 00, 0A, 6F, E9, 05, 00, 0A, 0D, 09]
        // .code-bytes IL_0030: [7B, A0, 05, 00, 0A, 04, 7B, A0, 05, 00, 0A, 2E, 0D, 04, 7B, 77, 05, 00, 0A, 2D, 05, 17, 13, 05]
        // .code-bytes IL_0048: [DE, 65, 02, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 09, 7B, 96, 05, 00, 0A, 6F, 97, 05, 00, 0A]
        // .code-bytes IL_0060: [7B, EC, 05, 00, 0A, 2C, 05, 17, 13, 05, DE, 43, 08, 17, 9A, 12, 04, 28, AD, 05, 00, 0A, 2D, 1A]
        // .code-bytes IL_0078: [72, C5, D1, 00, 70, 72, FB, DC, 00, 70, 05, 28, 44, 02, 00, 0A, 28, 76, 05, 00, 0A, 16, 13, 05]
        // .code-bytes IL_0090: [DE, 1D, 09, 11, 04, 7D, A5, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 17, 13, 05, DE, 0A, 07, 2C, 06]
        // .code-bytes IL_00A8: [06, 28, 79, 05, 00, 0A, DC, 11, 05, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] string[]
        // .local [3] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [4] int32
        // .local [5] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.3 3
        // IL_0012: ldc.i4.s 32
        // IL_0014: ldc.i4.0 0
        // IL_0015: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_001A: stloc.2 2
        // IL_001B: ldarg.0 0
        // IL_001C: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0021: ldloc.2 2
        // IL_0022: ldc.i4.0 0
        // IL_0023: ldelem.ref 
        // IL_0024: call 0x0A0005E8 [OpenRA.Game]OpenRA.Exts::ParseInt32Invariant
        // IL_0029: callvirt 0x0A0005E9 [OpenRA.Game]OpenRA.Network.Session::ClientWithIndex
        // IL_002E: stloc.3 3
        // IL_002F: ldloc.3 3
        // IL_0030: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_0035: ldarg.2 2
        // IL_0036: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_003B: beq.s IL_004A
        // IL_003D: ldarg.2 2
        // IL_003E: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0043: brtrue.s IL_004A
        // IL_0045: ldc.i4.1 1
        // IL_0046: stloc.s 5
        // IL_0048: leave.s IL_00AF
        // IL_004A: ldarg.0 0
        // IL_004B: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0050: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0055: ldloc.3 3
        // IL_0056: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_005B: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_0060: ldfld 0x0A0005EC [OpenRA.Game]OpenRA.Network.Session/Slot::LockTeam
        // IL_0065: brfalse.s IL_006C
        // IL_0067: ldc.i4.1 1
        // IL_0068: stloc.s 5
        // IL_006A: leave.s IL_00AF
        // IL_006C: ldloc.2 2
        // IL_006D: ldc.i4.1 1
        // IL_006E: ldelem.ref 
        // IL_006F: ldloca.s 4
        // IL_0071: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_0076: brtrue.s IL_0092
        // IL_0078: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_007D: ldstr 0x7000DCFB [73, 110, 118, 97, 108, 105, 100, 32, 116, 101, 97, 109, 58, 32] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 74, 00, 65, 00, 61, 00, 6D, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_0082: ldarg.3 3
        // IL_0083: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_0088: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_008D: ldc.i4.0 0
        // IL_008E: stloc.s 5
        // IL_0090: leave.s IL_00AF
        // IL_0092: ldloc.3 3
        // IL_0093: ldloc.s 4
        // IL_0095: stfld 0x0A0005A5 [OpenRA.Game]OpenRA.Network.Session/Client::Team
        // IL_009A: ldarg.0 0
        // IL_009B: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_00A0: ldc.i4.1 1
        // IL_00A1: stloc.s 5
        // IL_00A3: leave.s IL_00AF
        // IL_00A5: ldloc.1 1
        // IL_00A6: brfalse.s IL_00AE
        // IL_00A8: ldloc.0 0
        // IL_00A9: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00AE: endfinally 
        // IL_00AF: ldloc.s 5
        // IL_00B1: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 156, handler_offset: 165, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00A5 finally IL_00A5..IL_00AF
    }

    private static bool Handicap(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 05, 1F, 20, 16, 6F, CC, 01]
        // .code-bytes IL_0018: [00, 0A, 0C, 02, 7B, 72, 05, 00, 0A, 08, 16, 9A, 28, E8, 05, 00, 0A, 6F, E9, 05, 00, 0A, 0D, 09]
        // .code-bytes IL_0030: [7B, A0, 05, 00, 0A, 04, 7B, A0, 05, 00, 0A, 2E, 10, 04, 7B, 77, 05, 00, 0A, 2D, 08, 17, 13, 06]
        // .code-bytes IL_0048: [DD, BB, 00, 00, 00, 02, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 09, 7B, 96, 05, 00, 0A, 6F, 97]
        // .code-bytes IL_0060: [05, 00, 0A, 7B, ED, 05, 00, 0A, 2C, 08, 17, 13, 06, DD, 96, 00, 00, 00, 08, 17, 9A, 12, 04, 28]
        // .code-bytes IL_0078: [AD, 05, 00, 0A, 2D, 1A, 72, C5, D1, 00, 70, 72, 19, DD, 00, 70, 05, 28, 44, 02, 00, 0A, 28, 76]
        // .code-bytes IL_0090: [05, 00, 0A, 16, 13, 06, DE, 70, 16, 1F, 14, 28, EE, 05, 00, 0A, 7E, EA, 21, 00, 04, 25, 2D, 17]
        // .code-bytes IL_00A8: [26, 7E, D9, 21, 00, 04, FE, 06, 48, 29, 00, 06, 73, 3F, 05, 00, 0A, 25, 80, EA, 21, 00, 04, 28]
        // .code-bytes IL_00C0: [03, 01, 00, 2B, 13, 05, 11, 05, 11, 04, 28, 04, 01, 00, 2B, 2D, 1A, 72, C5, D1, 00, 70, 72, 19]
        // .code-bytes IL_00D8: [DD, 00, 70, 05, 28, 44, 02, 00, 0A, 28, 76, 05, 00, 0A, 16, 13, 06, DE, 1D, 09, 11, 04, 7D, A6]
        // .code-bytes IL_00F0: [05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 17, 13, 06, DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00, 0A, DC]
        // .code-bytes IL_0108: [11, 06, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] string[]
        // .local [3] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [4] int32
        // .local [5] class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>
        // .local [6] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.3 3
        // IL_0012: ldc.i4.s 32
        // IL_0014: ldc.i4.0 0
        // IL_0015: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_001A: stloc.2 2
        // IL_001B: ldarg.0 0
        // IL_001C: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0021: ldloc.2 2
        // IL_0022: ldc.i4.0 0
        // IL_0023: ldelem.ref 
        // IL_0024: call 0x0A0005E8 [OpenRA.Game]OpenRA.Exts::ParseInt32Invariant
        // IL_0029: callvirt 0x0A0005E9 [OpenRA.Game]OpenRA.Network.Session::ClientWithIndex
        // IL_002E: stloc.3 3
        // IL_002F: ldloc.3 3
        // IL_0030: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_0035: ldarg.2 2
        // IL_0036: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_003B: beq.s IL_004D
        // IL_003D: ldarg.2 2
        // IL_003E: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0043: brtrue.s IL_004D
        // IL_0045: ldc.i4.1 1
        // IL_0046: stloc.s 6
        // IL_0048: leave IL_0108
        // IL_004D: ldarg.0 0
        // IL_004E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0053: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0058: ldloc.3 3
        // IL_0059: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_005E: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_0063: ldfld 0x0A0005ED [OpenRA.Game]OpenRA.Network.Session/Slot::LockHandicap
        // IL_0068: brfalse.s IL_0072
        // IL_006A: ldc.i4.1 1
        // IL_006B: stloc.s 6
        // IL_006D: leave IL_0108
        // IL_0072: ldloc.2 2
        // IL_0073: ldc.i4.1 1
        // IL_0074: ldelem.ref 
        // IL_0075: ldloca.s 4
        // IL_0077: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_007C: brtrue.s IL_0098
        // IL_007E: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_0083: ldstr 0x7000DD19 [73, 110, 118, 97, 108, 105, 100, 32, 104, 97, 110, 100, 105, 99, 97, 112, 58, 32] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 68, 00, 61, 00, 6E, 00, 64, 00, 69, 00, 63, 00, 61, 00, 70, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_0088: ldarg.3 3
        // IL_0089: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_008E: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_0093: ldc.i4.0 0
        // IL_0094: stloc.s 6
        // IL_0096: leave.s IL_0108
        // IL_0098: ldc.i4.0 0
        // IL_0099: ldc.i4.s 20
        // IL_009B: call 0x0A0005EE [System.Linq]System.Linq.Enumerable::Range
        // IL_00A0: ldsfld 0x040021EA OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__70_0
        // IL_00A5: dup 
        // IL_00A6: brtrue.s IL_00BF
        // IL_00A8: pop 
        // IL_00A9: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_00AE: ldftn 0x06002948 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Handicap>b__70_0
        // IL_00B4: newobj 0x0A00053F class [System.Runtime]System.Func`2<int32, int32>::.ctor
        // IL_00B9: dup 
        // IL_00BA: stsfld 0x040021EA OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__70_0
        // IL_00BF: call 0x2B000103 [System.Linq]System.Linq.Enumerable::Select<int32, int32>
        // IL_00C4: stloc.s 5
        // IL_00C6: ldloc.s 5
        // IL_00C8: ldloc.s 4
        // IL_00CA: call 0x2B000104 [System.Linq]System.Linq.Enumerable::Contains<int32>
        // IL_00CF: brtrue.s IL_00EB
        // IL_00D1: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00D6: ldstr 0x7000DD19 [73, 110, 118, 97, 108, 105, 100, 32, 104, 97, 110, 100, 105, 99, 97, 112, 58, 32] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 68, 00, 61, 00, 6E, 00, 64, 00, 69, 00, 63, 00, 61, 00, 70, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_00DB: ldarg.3 3
        // IL_00DC: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_00E1: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_00E6: ldc.i4.0 0
        // IL_00E7: stloc.s 6
        // IL_00E9: leave.s IL_0108
        // IL_00EB: ldloc.3 3
        // IL_00EC: ldloc.s 4
        // IL_00EE: stfld 0x0A0005A6 [OpenRA.Game]OpenRA.Network.Session/Client::Handicap
        // IL_00F3: ldarg.0 0
        // IL_00F4: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_00F9: ldc.i4.1 1
        // IL_00FA: stloc.s 6
        // IL_00FC: leave.s IL_0108
        // IL_00FE: ldloc.1 1
        // IL_00FF: brfalse.s IL_0107
        // IL_0101: ldloc.0 0
        // IL_0102: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0107: endfinally 
        // IL_0108: ldloc.s 6
        // IL_010A: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 245, handler_offset: 254, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00FE finally IL_00FE..IL_0108
    }

    private static bool ClearPlayerSpawn(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [73, 79, 29, 00, 06, 0A, 06, 05, 28, E8, 05, 00, 0A, 7D, 10, 22, 00, 04, 06, 7B, 10, 22, 00, 04]
        // .code-bytes IL_0018: [2D, 02, 17, 2A, 02, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 06, FE, 06, 7A, 29, 00, 06, 73, 8A]
        // .code-bytes IL_0030: [05, 00, 0A, 28, EC, 00, 00, 2B, 0B, 04, 07, 2E, 17, 04, 7B, 77, 05, 00, 0A, 2D, 0F, 02, 03, 72]
        // .code-bytes IL_0048: [3F, DD, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 2A, 07, 2C, 46, 07, 7B, 96, 05, 00, 0A, 2C, 1F, 02]
        // .code-bytes IL_0060: [7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 07, 7B, 96, 05, 00, 0A, 6F, 97, 05, 00, 0A, 7B, 98, 05]
        // .code-bytes IL_0078: [00, 0A, 2C, 02, 17, 2A, 07, 16, 7D, 99, 05, 00, 0A, 07, 7B, 7B, 05, 00, 0A, 18, 33, 07, 07, 16]
        // .code-bytes IL_0090: [7D, 7B, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 17, 2A, 02, 7B, 72, 05, 00, 0A, 7B, EF, 05, 00, 0A]
        // .code-bytes IL_00A8: [06, 7B, 10, 22, 00, 04, 6F, F0, 05, 00, 0A, 2D, 17, 02, 7B, 72, 05, 00, 0A, 7B, EF, 05, 00, 0A]
        // .code-bytes IL_00C0: [06, 7B, 10, 22, 00, 04, 6F, F1, 05, 00, 0A, 26, 02, 6F, F2, 05, 00, 0A, 17, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session/Client
        // IL_0000: newobj 0x06002979 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.3 3
        // IL_0008: call 0x0A0005E8 [OpenRA.Game]OpenRA.Exts::ParseInt32Invariant
        // IL_000D: stfld 0x04002210 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0::spawnPoint
        // IL_0012: ldloc.0 0
        // IL_0013: ldfld 0x04002210 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0::spawnPoint
        // IL_0018: brtrue.s IL_001C
        // IL_001A: ldc.i4.1 1
        // IL_001B: ret 
        // IL_001C: ldarg.0 0
        // IL_001D: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0022: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_0027: ldloc.0 0
        // IL_0028: ldftn 0x0600297A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0::<ClearPlayerSpawn>b__0
        // IL_002E: newobj 0x0A00058A class [System.Runtime]System.Predicate`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::.ctor
        // IL_0033: call 0x2B0000EC [OpenRA.Game]OpenRA.Exts::FirstOrDefault<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_0038: stloc.1 1
        // IL_0039: ldarg.2 2
        // IL_003A: ldloc.1 1
        // IL_003B: beq.s IL_0054
        // IL_003D: ldarg.2 2
        // IL_003E: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0043: brtrue.s IL_0054
        // IL_0045: ldarg.0 0
        // IL_0046: ldarg.1 1
        // IL_0047: ldstr 0x7000DD3F [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 99, 108, 101, 97, 114, 45, 115, 112, 97, 119, 110] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 63, 00, 6C, 00, 65, 00, 61, 00, 72, 00, 2D, 00, 73, 00, 70, 00, 61, 00, 77, 00, 6E, 00] terminal-flag=Some(1)
        // IL_004C: ldnull 
        // IL_004D: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0052: ldc.i4.1 1
        // IL_0053: ret 
        // IL_0054: ldloc.1 1
        // IL_0055: brfalse.s IL_009D
        // IL_0057: ldloc.1 1
        // IL_0058: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_005D: brfalse.s IL_007E
        // IL_005F: ldarg.0 0
        // IL_0060: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0065: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_006A: ldloc.1 1
        // IL_006B: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0070: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_0075: ldfld 0x0A000598 [OpenRA.Game]OpenRA.Network.Session/Slot::LockSpawn
        // IL_007A: brfalse.s IL_007E
        // IL_007C: ldc.i4.1 1
        // IL_007D: ret 
        // IL_007E: ldloc.1 1
        // IL_007F: ldc.i4.0 0
        // IL_0080: stfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
        // IL_0085: ldloc.1 1
        // IL_0086: ldfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_008B: ldc.i4.2 2
        // IL_008C: bne.un.s IL_0095
        // IL_008E: ldloc.1 1
        // IL_008F: ldc.i4.0 0
        // IL_0090: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
        // IL_0095: ldarg.0 0
        // IL_0096: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_009B: ldc.i4.1 1
        // IL_009C: ret 
        // IL_009D: ldarg.0 0
        // IL_009E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00A3: ldfld 0x0A0005EF [OpenRA.Game]OpenRA.Network.Session::DisabledSpawnPoints
        // IL_00A8: ldloc.0 0
        // IL_00A9: ldfld 0x04002210 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0::spawnPoint
        // IL_00AE: callvirt 0x0A0005F0 class [System.Collections]System.Collections.Generic.HashSet`1<int32>::Add
        // IL_00B3: brtrue.s IL_00CC
        // IL_00B5: ldarg.0 0
        // IL_00B6: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_00BB: ldfld 0x0A0005EF [OpenRA.Game]OpenRA.Network.Session::DisabledSpawnPoints
        // IL_00C0: ldloc.0 0
        // IL_00C1: ldfld 0x04002210 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0::spawnPoint
        // IL_00C6: callvirt 0x0A0005F1 class [System.Collections]System.Collections.Generic.HashSet`1<int32>::Remove
        // IL_00CB: pop 
        // IL_00CC: ldarg.0 0
        // IL_00CD: callvirt 0x0A0005F2 [OpenRA.Game]OpenRA.Server.Server::SyncLobbyInfo
        // IL_00D2: ldc.i4.1 1
        // IL_00D3: ret 
    }

    private static bool Spawn(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [73, 7B, 29, 00, 06, 0A, 06, 04, 7D, 11, 22, 00, 04, 06, 02, 7D, 12, 22, 00, 04, 06, 7B, 12, 22]
        // .code-bytes IL_0018: [00, 04, 7B, 72, 05, 00, 0A, 0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00, 0A, 05, 1F, 20, 16, 6F, CC]
        // .code-bytes IL_0030: [01, 00, 0A, 0D, 06, 7B, 12, 22, 00, 04, 7B, 72, 05, 00, 0A, 09, 16, 9A, 28, E8, 05, 00, 0A, 6F]
        // .code-bytes IL_0048: [E9, 05, 00, 0A, 13, 04, 11, 04, 7B, A0, 05, 00, 0A, 06, 7B, 11, 22, 00, 04, 7B, A0, 05, 00, 0A]
        // .code-bytes IL_0060: [2E, 15, 06, 7B, 11, 22, 00, 04, 7B, 77, 05, 00, 0A, 2D, 08, 17, 13, 05, DD, 5D, 01, 00, 00, 11]
        // .code-bytes IL_0078: [04, 7B, 96, 05, 00, 0A, 2D, 08, 17, 13, 05, DD, 4C, 01, 00, 00, 06, 7B, 12, 22, 00, 04, 7B, 72]
        // .code-bytes IL_0090: [05, 00, 0A, 7B, 74, 05, 00, 0A, 11, 04, 7B, 96, 05, 00, 0A, 6F, 97, 05, 00, 0A, 7B, 98, 05, 00]
        // .code-bytes IL_00A8: [0A, 2C, 08, 17, 13, 05, DD, 21, 01, 00, 00, 09, 17, 9A, 06, 7C, 13, 22, 00, 04, 28, AD, 05, 00]
        // .code-bytes IL_00C0: [0A, 2C, 23, 06, 7B, 13, 22, 00, 04, 16, 32, 1A, 06, 7B, 13, 22, 00, 04, 06, 7B, 12, 22, 00, 04]
        // .code-bytes IL_00D8: [7B, 86, 05, 00, 0A, 6F, F3, 05, 00, 0A, 8E, 69, 31, 1F, 72, C5, D1, 00, 70, 72, 7D, DD, 00, 70]
        // .code-bytes IL_00F0: [09, 17, 9A, 28, 44, 02, 00, 0A, 28, 76, 05, 00, 0A, 17, 13, 05, DD, CF, 00, 00, 00, 06, 7B, 12]
        // .code-bytes IL_0108: [22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 06, FE, 06, 7C, 29, 00, 06, 73, 7F, 05, 00]
        // .code-bytes IL_0120: [0A, 28, E7, 00, 00, 2B, 2C, 1A, 06, 7B, 12, 22, 00, 04, 03, 72, A9, DD, 00, 70, 14, 6F, 78, 05]
        // .code-bytes IL_0138: [00, 0A, 17, 13, 05, DD, 92, 00, 00, 00, 06, 7B, 13, 22, 00, 04, 16, 31, 62, 06, 7B, 12, 22, 00]
        // .code-bytes IL_0150: [04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 7E, EB, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00]
        // .code-bytes IL_0168: [04, FE, 06, 49, 29, 00, 06, 73, 83, 05, 00, 0A, 25, 80, EB, 21, 00, 04, 28, 05, 01, 00, 2B, 06]
        // .code-bytes IL_0180: [FE, 06, 7D, 29, 00, 06, 73, 83, 05, 00, 0A, 28, EA, 00, 00, 2B, 13, 06, 11, 06, 2C, 17, 06, 7B]
        // .code-bytes IL_0198: [12, 22, 00, 04, 03, 72, E1, DD, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 13, 05, DE, 27, 11, 04, 06]
        // .code-bytes IL_01B0: [7B, 13, 22, 00, 04, 7D, 99, 05, 00, 0A, 06, 7B, 12, 22, 00, 04, 6F, 8E, 05, 00, 0A, 17, 13, 05]
        // .code-bytes IL_01C8: [DE, 0A, 08, 2C, 06, 07, 28, 79, 05, 00, 0A, DC, 11, 05, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] string[]
        // .local [4] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [5] bool
        // .local [6] bool
        // IL_0000: newobj 0x0600297B OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.2 2
        // IL_0008: stfld 0x04002211 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::client
        // IL_000D: ldloc.0 0
        // IL_000E: ldarg.0 0
        // IL_000F: stfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_0014: ldloc.0 0
        // IL_0015: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_001A: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_001F: stloc.1 1
        // IL_0020: ldc.i4.0 0
        // IL_0021: stloc.2 2
        // IL_0022: ldloc.1 1
        // IL_0023: ldloca.s 2
        // IL_0025: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_002A: ldarg.3 3
        // IL_002B: ldc.i4.s 32
        // IL_002D: ldc.i4.0 0
        // IL_002E: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_0033: stloc.3 3
        // IL_0034: ldloc.0 0
        // IL_0035: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_003A: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_003F: ldloc.3 3
        // IL_0040: ldc.i4.0 0
        // IL_0041: ldelem.ref 
        // IL_0042: call 0x0A0005E8 [OpenRA.Game]OpenRA.Exts::ParseInt32Invariant
        // IL_0047: callvirt 0x0A0005E9 [OpenRA.Game]OpenRA.Network.Session::ClientWithIndex
        // IL_004C: stloc.s 4
        // IL_004E: ldloc.s 4
        // IL_0050: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_0055: ldloc.0 0
        // IL_0056: ldfld 0x04002211 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::client
        // IL_005B: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_0060: beq.s IL_0077
        // IL_0062: ldloc.0 0
        // IL_0063: ldfld 0x04002211 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::client
        // IL_0068: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_006D: brtrue.s IL_0077
        // IL_006F: ldc.i4.1 1
        // IL_0070: stloc.s 5
        // IL_0072: leave IL_01D4
        // IL_0077: ldloc.s 4
        // IL_0079: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_007E: brtrue.s IL_0088
        // IL_0080: ldc.i4.1 1
        // IL_0081: stloc.s 5
        // IL_0083: leave IL_01D4
        // IL_0088: ldloc.0 0
        // IL_0089: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_008E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0093: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_0098: ldloc.s 4
        // IL_009A: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_009F: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_00A4: ldfld 0x0A000598 [OpenRA.Game]OpenRA.Network.Session/Slot::LockSpawn
        // IL_00A9: brfalse.s IL_00B3
        // IL_00AB: ldc.i4.1 1
        // IL_00AC: stloc.s 5
        // IL_00AE: leave IL_01D4
        // IL_00B3: ldloc.3 3
        // IL_00B4: ldc.i4.1 1
        // IL_00B5: ldelem.ref 
        // IL_00B6: ldloc.0 0
        // IL_00B7: ldflda 0x04002213 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::spawnPoint
        // IL_00BC: call 0x0A0005AD [OpenRA.Game]OpenRA.Exts::TryParseInt32Invariant
        // IL_00C1: brfalse.s IL_00E6
        // IL_00C3: ldloc.0 0
        // IL_00C4: ldfld 0x04002213 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::spawnPoint
        // IL_00C9: ldc.i4.0 0
        // IL_00CA: blt.s IL_00E6
        // IL_00CC: ldloc.0 0
        // IL_00CD: ldfld 0x04002213 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::spawnPoint
        // IL_00D2: ldloc.0 0
        // IL_00D3: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_00D8: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_00DD: callvirt 0x0A0005F3 [OpenRA.Game]OpenRA.MapPreview::get_SpawnPoints
        // IL_00E2: ldlen 
        // IL_00E3: conv.i4 
        // IL_00E4: ble.s IL_0105
        // IL_00E6: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00EB: ldstr 0x7000DD7D [73, 110, 118, 97, 108, 105, 100, 32, 115, 112, 97, 119, 110, 32, 112, 111, 105, 110, 116, 58, 32] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 73, 00, 70, 00, 61, 00, 77, 00, 6E, 00, 20, 00, 70, 00, 6F, 00, 69, 00, 6E, 00, 74, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_00F0: ldloc.3 3
        // IL_00F1: ldc.i4.1 1
        // IL_00F2: ldelem.ref 
        // IL_00F3: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_00F8: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_00FD: ldc.i4.1 1
        // IL_00FE: stloc.s 5
        // IL_0100: leave IL_01D4
        // IL_0105: ldloc.0 0
        // IL_0106: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_010B: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0110: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_0115: ldloc.0 0
        // IL_0116: ldftn 0x0600297C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::<Spawn>b__0
        // IL_011C: newobj 0x0A00057F class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, bool>::.ctor
        // IL_0121: call 0x2B0000E7 [System.Linq]System.Linq.Enumerable::Any<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_0126: brfalse.s IL_0142
        // IL_0128: ldloc.0 0
        // IL_0129: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_012E: ldarg.1 1
        // IL_012F: ldstr 0x7000DDA9 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 115, 112, 97, 119, 110, 45, 111, 99, 99, 117, 112, 105, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 73, 00, 70, 00, 61, 00, 77, 00, 6E, 00, 2D, 00, 6F, 00, 63, 00, 63, 00, 75, 00, 70, 00, 69, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_0134: ldnull 
        // IL_0135: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_013A: ldc.i4.1 1
        // IL_013B: stloc.s 5
        // IL_013D: leave IL_01D4
        // IL_0142: ldloc.0 0
        // IL_0143: ldfld 0x04002213 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::spawnPoint
        // IL_0148: ldc.i4.0 0
        // IL_0149: ble.s IL_01AD
        // IL_014B: ldloc.0 0
        // IL_014C: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_0151: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0156: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_015B: ldsfld 0x040021EB OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__72_1
        // IL_0160: dup 
        // IL_0161: brtrue.s IL_017A
        // IL_0163: pop 
        // IL_0164: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0169: ldftn 0x06002949 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Spawn>b__72_1
        // IL_016F: newobj 0x0A000583 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, bool>::.ctor
        // IL_0174: dup 
        // IL_0175: stsfld 0x040021EB OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__72_1
        // IL_017A: call 0x2B000105 [System.Linq]System.Linq.Enumerable::Where<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>>
        // IL_017F: ldloc.0 0
        // IL_0180: ldftn 0x0600297D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::<Spawn>b__2
        // IL_0186: newobj 0x0A000583 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>, bool>::.ctor
        // IL_018B: call 0x2B0000EA [System.Linq]System.Linq.Enumerable::Any<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>>
        // IL_0190: stloc.s 6
        // IL_0192: ldloc.s 6
        // IL_0194: brfalse.s IL_01AD
        // IL_0196: ldloc.0 0
        // IL_0197: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_019C: ldarg.1 1
        // IL_019D: ldstr 0x7000DDE1 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 115, 112, 97, 119, 110, 45, 108, 111, 99, 107, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 73, 00, 70, 00, 61, 00, 77, 00, 6E, 00, 2D, 00, 6C, 00, 6F, 00, 63, 00, 6B, 00, 65, 00, 64, 00] terminal-flag=Some(1)
        // IL_01A2: ldnull 
        // IL_01A3: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_01A8: ldc.i4.1 1
        // IL_01A9: stloc.s 5
        // IL_01AB: leave.s IL_01D4
        // IL_01AD: ldloc.s 4
        // IL_01AF: ldloc.0 0
        // IL_01B0: ldfld 0x04002213 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::spawnPoint
        // IL_01B5: stfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
        // IL_01BA: ldloc.0 0
        // IL_01BB: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
        // IL_01C0: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_01C5: ldc.i4.1 1
        // IL_01C6: stloc.s 5
        // IL_01C8: leave.s IL_01D4
        // IL_01CA: ldloc.2 2
        // IL_01CB: brfalse.s IL_01D3
        // IL_01CD: ldloc.1 1
        // IL_01CE: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_01D3: endfinally 
        // IL_01D4: ldloc.s 5
        // IL_01D6: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 34, try_length: 424, handler_offset: 458, handler_length: 10, raw_flags: 2 }
        // .try IL_0022..IL_01CA finally IL_01CA..IL_01D4
    }

    private static bool PlayerColor(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 05, 1F, 20, 16, 6F, CC, 01]
        // .code-bytes IL_0018: [00, 0A, 0C, 02, 7B, 72, 05, 00, 0A, 08, 16, 9A, 28, E8, 05, 00, 0A, 6F, E9, 05, 00, 0A, 0D, 09]
        // .code-bytes IL_0030: [7B, A0, 05, 00, 0A, 04, 7B, A0, 05, 00, 0A, 2E, 0D, 04, 7B, 77, 05, 00, 0A, 2D, 05, 17, 13, 05]
        // .code-bytes IL_0048: [DE, 7E, 09, 7B, 96, 05, 00, 0A, 2C, 1D, 02, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 09, 7B, 96]
        // .code-bytes IL_0060: [05, 00, 0A, 6F, 97, 05, 00, 0A, 7B, 9E, 05, 00, 0A, 2C, 05, 17, 13, 05, DE, 54, 72, 15, DE, 00]
        // .code-bytes IL_0078: [70, 08, 17, 9A, 28, 06, 01, 00, 2B, 13, 04, 09, 02, 11, 04, 09, 7B, A0, 05, 00, 0A, 03, 28, 43]
        // .code-bytes IL_0090: [03, 00, 06, 7D, 9F, 05, 00, 0A, 11, 04, 09, 7B, 9F, 05, 00, 0A, 28, 16, 05, 00, 0A, 2C, 0C, 09]
        // .code-bytes IL_00A8: [09, 7B, 9F, 05, 00, 0A, 7D, A1, 05, 00, 0A, 02, 6F, 8E, 05, 00, 0A, 17, 13, 05, DE, 0A, 07, 2C]
        // .code-bytes IL_00C0: [06, 06, 28, 79, 05, 00, 0A, DC, 11, 05, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] string[]
        // .local [3] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [4] valuetype [OpenRA.Game]OpenRA.Primitives.Color
        // .local [5] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.3 3
        // IL_0012: ldc.i4.s 32
        // IL_0014: ldc.i4.0 0
        // IL_0015: callvirt 0x0A0001CC [System.Runtime]System.String::Split
        // IL_001A: stloc.2 2
        // IL_001B: ldarg.0 0
        // IL_001C: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0021: ldloc.2 2
        // IL_0022: ldc.i4.0 0
        // IL_0023: ldelem.ref 
        // IL_0024: call 0x0A0005E8 [OpenRA.Game]OpenRA.Exts::ParseInt32Invariant
        // IL_0029: callvirt 0x0A0005E9 [OpenRA.Game]OpenRA.Network.Session::ClientWithIndex
        // IL_002E: stloc.3 3
        // IL_002F: ldloc.3 3
        // IL_0030: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_0035: ldarg.2 2
        // IL_0036: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_003B: beq.s IL_004A
        // IL_003D: ldarg.2 2
        // IL_003E: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0043: brtrue.s IL_004A
        // IL_0045: ldc.i4.1 1
        // IL_0046: stloc.s 5
        // IL_0048: leave.s IL_00C8
        // IL_004A: ldloc.3 3
        // IL_004B: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0050: brfalse.s IL_006F
        // IL_0052: ldarg.0 0
        // IL_0053: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0058: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_005D: ldloc.3 3
        // IL_005E: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0063: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_0068: ldfld 0x0A00059E [OpenRA.Game]OpenRA.Network.Session/Slot::LockColor
        // IL_006D: brfalse.s IL_0074
        // IL_006F: ldc.i4.1 1
        // IL_0070: stloc.s 5
        // IL_0072: leave.s IL_00C8
        // IL_0074: ldstr 0x7000DE15 [40, 118, 97, 108, 117, 101, 41] utf16-bytes=[28, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 29, 00] terminal-flag=Some(0)
        // IL_0079: ldloc.2 2
        // IL_007A: ldc.i4.1 1
        // IL_007B: ldelem.ref 
        // IL_007C: call 0x2B000106 [OpenRA.Game]OpenRA.FieldLoader::GetValue<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_0081: stloc.s 4
        // IL_0083: ldloc.3 3
        // IL_0084: ldarg.0 0
        // IL_0085: ldloc.s 4
        // IL_0087: ldloc.3 3
        // IL_0088: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_008D: ldarg.1 1
        // IL_008E: call 0x06000343 OpenRA.Mods.Common.Server.LobbyCommands::SanitizePlayerColor
        // IL_0093: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_0098: ldloc.s 4
        // IL_009A: ldloc.3 3
        // IL_009B: ldfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_00A0: call 0x0A000516 [OpenRA.Game]OpenRA.Primitives.Color::op_Equality
        // IL_00A5: brfalse.s IL_00B3
        // IL_00A7: ldloc.3 3
        // IL_00A8: ldloc.3 3
        // IL_00A9: ldfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_00AE: stfld 0x0A0005A1 [OpenRA.Game]OpenRA.Network.Session/Client::PreferredColor
        // IL_00B3: ldarg.0 0
        // IL_00B4: callvirt 0x0A00058E [OpenRA.Game]OpenRA.Server.Server::SyncLobbyClients
        // IL_00B9: ldc.i4.1 1
        // IL_00BA: stloc.s 5
        // IL_00BC: leave.s IL_00C8
        // IL_00BE: ldloc.1 1
        // IL_00BF: brfalse.s IL_00C7
        // IL_00C1: ldloc.0 0
        // IL_00C2: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00C7: endfinally 
        // IL_00C8: ldloc.s 5
        // IL_00CA: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 181, handler_offset: 190, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00BE finally IL_00BE..IL_00C8
    }

    private static bool SyncLobby(OpenRA.Server.Server server, OpenRA.Server.Connection conn, OpenRA.Network.Session.Client client, string s)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 04, 7B, 77, 05, 00, 0A, 2D]
        // .code-bytes IL_0018: [11, 02, 03, 72, 25, DE, 00, 70, 14, 6F, 78, 05, 00, 0A, 17, 0C, DE, 38, 00, 02, 05, 72, 61, DE]
        // .code-bytes IL_0030: [00, 70, 28, F4, 05, 00, 0A, 7D, 72, 05, 00, 0A, 02, 6F, F2, 05, 00, 0A, DE, 10, 26, 02, 03, 72]
        // .code-bytes IL_0048: [75, DE, 00, 70, 14, 6F, 78, 05, 00, 0A, DE, 00, 17, 0C, DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00]
        // .code-bytes IL_0060: [0A, DC, 08, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] bool
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.2 2
        // IL_0012: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
        // IL_0017: brtrue.s IL_002A
        // IL_0019: ldarg.0 0
        // IL_001A: ldarg.1 1
        // IL_001B: ldstr 0x7000DE25 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 97, 100, 109, 105, 110, 45, 108, 111, 98, 98, 121, 45, 105, 110, 102, 111] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 61, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 2D, 00, 6C, 00, 6F, 00, 62, 00, 62, 00, 79, 00, 2D, 00, 69, 00, 6E, 00, 66, 00, 6F, 00] terminal-flag=Some(1)
        // IL_0020: ldnull 
        // IL_0021: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0026: ldc.i4.1 1
        // IL_0027: stloc.2 2
        // IL_0028: leave.s IL_0062
        // IL_002A: nop 
        // IL_002B: ldarg.0 0
        // IL_002C: ldarg.3 3
        // IL_002D: ldstr 0x7000DE61 [83, 121, 110, 99, 76, 111, 98, 98, 121] utf16-bytes=[53, 00, 79, 00, 6E, 00, 63, 00, 4C, 00, 6F, 00, 62, 00, 62, 00, 79, 00] terminal-flag=Some(0)
        // IL_0032: call 0x0A0005F4 [OpenRA.Game]OpenRA.Network.Session::Deserialize
        // IL_0037: stfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_003C: ldarg.0 0
        // IL_003D: callvirt 0x0A0005F2 [OpenRA.Game]OpenRA.Server.Server::SyncLobbyInfo
        // IL_0042: leave.s IL_0054
        // IL_0044: pop 
        // IL_0045: ldarg.0 0
        // IL_0046: ldarg.1 1
        // IL_0047: ldstr 0x7000DE75 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 105, 110, 118, 97, 108, 105, 100, 45, 108, 111, 98, 98, 121, 45, 105, 110, 102, 111] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 69, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 2D, 00, 6C, 00, 6F, 00, 62, 00, 62, 00, 79, 00, 2D, 00, 69, 00, 6E, 00, 66, 00, 6F, 00] terminal-flag=Some(1)
        // IL_004C: ldnull 
        // IL_004D: callvirt 0x0A000578 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessageTo
        // IL_0052: leave.s IL_0054
        // IL_0054: ldc.i4.1 1
        // IL_0055: stloc.2 2
        // IL_0056: leave.s IL_0062
        // IL_0058: ldloc.1 1
        // IL_0059: brfalse.s IL_0061
        // IL_005B: ldloc.0 0
        // IL_005C: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0061: endfinally 
        // IL_0062: ldloc.2 2
        // IL_0063: ret 
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[95])), try_offset: 43, try_length: 25, handler_offset: 68, handler_length: 16, raw_flags: 0 }
        // .try IL_002B..IL_0044 catch 0x0100005F [System.Runtime]System.Exception IL_0044..IL_0054
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 79, handler_offset: 88, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_0058 finally IL_0058..IL_0062
    }

    private static void InitializeMapPool(OpenRA.Server.Server server)
    {
        // IL fallback: incompatible value/receiver types
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 7E, 29, 00, 06, 0A, 02, 7B, 84, 05, 00, 0A, 19, 2E, 01, 2A, 06, 02, 7B, 85, 05, 00, 0A, 7B]
        // .code-bytes IL_0018: [21, 03, 00, 0A, 7D, 14, 22, 00, 04, 02, 7B, BE, 05, 00, 0A, 7B, F5, 05, 00, 0A, 8E, 2C, 18, 02]
        // .code-bytes IL_0030: [02, 7B, BE, 05, 00, 0A, 7B, F5, 05, 00, 0A, 28, 66, 00, 00, 2B, 7D, BC, 05, 00, 0A, 2B, 69, 02]
        // .code-bytes IL_0048: [7B, BE, 05, 00, 0A, 7B, BF, 05, 00, 0A, 2D, 5B, 02, 06, 7B, 14, 22, 00, 04, 7E, EC, 21, 00, 04]
        // .code-bytes IL_0060: [25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 4A, 29, 00, 06, 73, F6, 05, 00, 0A, 25, 80, EC, 21]
        // .code-bytes IL_0078: [00, 04, 28, 07, 01, 00, 2B, 7E, ED, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 4B]
        // .code-bytes IL_0090: [29, 00, 06, 73, F7, 05, 00, 0A, 25, 80, ED, 21, 00, 04, 28, 08, 01, 00, 2B, 28, 66, 00, 00, 2B]
        // .code-bytes IL_00A8: [7D, BC, 05, 00, 0A, 2B, 01, 2A, 02, 7B, BC, 05, 00, 0A, 02, FE, 06, F8, 05, 00, 0A, 73, C8, 02]
        // .code-bytes IL_00C0: [00, 0A, 28, 6E, 00, 00, 2B, 28, B4, 00, 00, 2B, 0B, 07, 6F, BD, 04, 00, 0A, 2D, 01, 2A, 02, 7B]
        // .code-bytes IL_00D8: [BE, 05, 00, 0A, 7B, BF, 05, 00, 0A, 39, A6, 00, 00, 00, 72, C5, D1, 00, 70, 12, 06, 1F, 34, 17]
        // .code-bytes IL_00F0: [28, FA, 02, 00, 0A, 12, 06, 72, B5, DE, 00, 70, 28, FB, 02, 00, 0A, 12, 06, 07, 6F, BD, 04, 00]
        // .code-bytes IL_0108: [0A, 28, 4A, 00, 00, 2B, 12, 06, 72, 0F, DF, 00, 70, 28, FB, 02, 00, 0A, 12, 06, 28, FD, 02, 00]
        // .code-bytes IL_0120: [0A, 28, 76, 05, 00, 0A, 02, 7B, 85, 05, 00, 0A, 7B, B9, 01, 00, 0A, 6F, F7, 00, 00, 2B, 7B, 72]
        // .code-bytes IL_0138: [00, 00, 04, 0D, 06, 7B, 14, 22, 00, 04, 09, 07, 14, 14, 6F, C1, 05, 00, 0A, 02, 7B, BC, 05, 00]
        // .code-bytes IL_0150: [0A, 06, FE, 06, 7F, 29, 00, 06, 73, C8, 02, 00, 0A, 28, 6E, 00, 00, 2B, 13, 04, 28, F9, 05, 00]
        // .code-bytes IL_0168: [0A, 13, 05, 2B, 07, 1F, 64, 28, FA, 05, 00, 0A, 11, 04, 28, 09, 01, 00, 2B, 2C, 0F, 11, 05, 6F]
        // .code-bytes IL_0180: [FC, 05, 00, 0A, 20, 10, 27, 00, 00, 6A, 32, E1, 02, 7B, BC, 05, 00, 0A, 02, FE, 06, F8, 05, 00]
        // .code-bytes IL_0198: [0A, 73, C8, 02, 00, 0A, 28, 6E, 00, 00, 2B, 28, B4, 00, 00, 2B, 0C, 08, 6F, BD, 04, 00, 0A, 2C]
        // .code-bytes IL_01B0: [1F, 72, C5, D1, 00, 70, 72, 21, DF, 00, 70, 08, 72, 9F, 09, 00, 70, 28, 5D, 00, 00, 2B, 28, 44]
        // .code-bytes IL_01C8: [02, 00, 0A, 28, 76, 05, 00, 0A, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass75_0
        // .local [1] class [System.Collections]System.Collections.Generic.List`1<string>
        // .local [2] class [System.Collections]System.Collections.Generic.List`1<string>
        // .local [3] string
        // .local [4] class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>
        // .local [5] class [System.Runtime]System.Diagnostics.Stopwatch
        // .local [6] valuetype [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler
        // IL_0000: newobj 0x0600297E OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass75_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldarg.0 0
        // IL_0007: ldfld 0x0A000584 [OpenRA.Game]OpenRA.Server.Server::Type
        // IL_000C: ldc.i4.3 3
        // IL_000D: beq.s IL_0010
        // IL_000F: ret 
        // IL_0010: ldloc.0 0
        // IL_0011: ldarg.0 0
        // IL_0012: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_0017: ldfld 0x0A000321 [OpenRA.Game]OpenRA.ModData::MapCache
        // IL_001C: stfld 0x04002214 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass75_0::mapCache
        // IL_0021: ldarg.0 0
        // IL_0022: ldfld 0x0A0005BE [OpenRA.Game]OpenRA.Server.Server::Settings
        // IL_0027: ldfld 0x0A0005F5 [OpenRA.Game]OpenRA.ServerSettings::MapPool
        // IL_002C: ldlen 
        // IL_002D: brfalse.s IL_0047
        // IL_002F: ldarg.0 0
        // IL_0030: ldarg.0 0
        // IL_0031: ldfld 0x0A0005BE [OpenRA.Game]OpenRA.Server.Server::Settings
        // IL_0036: ldfld 0x0A0005F5 [OpenRA.Game]OpenRA.ServerSettings::MapPool
        // IL_003B: call 0x2B000066 [OpenRA.Game]OpenRA.Exts::ToHashSet<string>
        // IL_0040: stfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_0045: br.s IL_00B0
        // IL_0047: ldarg.0 0
        // IL_0048: ldfld 0x0A0005BE [OpenRA.Game]OpenRA.Server.Server::Settings
        // IL_004D: ldfld 0x0A0005BF [OpenRA.Game]OpenRA.ServerSettings::QueryMapRepository
        // IL_0052: brtrue.s IL_00AF
        // IL_0054: ldarg.0 0
        // IL_0055: ldloc.0 0
        // IL_0056: ldfld 0x04002214 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass75_0::mapCache
        // IL_005B: ldsfld 0x040021EC OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__75_0
        // IL_0060: dup 
        // IL_0061: brtrue.s IL_007A
        // IL_0063: pop 
        // IL_0064: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0069: ldftn 0x0600294A OpenRA.Mods.Common.Server.LobbyCommands/<>c::<InitializeMapPool>b__75_0
        // IL_006F: newobj 0x0A0005F6 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.MapPreview, bool>::.ctor
        // IL_0074: dup 
        // IL_0075: stsfld 0x040021EC OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__75_0
        // IL_007A: call 0x2B000107 [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.MapPreview>
        // IL_007F: ldsfld 0x040021ED OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__75_1
        // IL_0084: dup 
        // IL_0085: brtrue.s IL_009E
        // IL_0087: pop 
        // IL_0088: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_008D: ldftn 0x0600294B OpenRA.Mods.Common.Server.LobbyCommands/<>c::<InitializeMapPool>b__75_1
        // IL_0093: newobj 0x0A0005F7 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.MapPreview, string>::.ctor
        // IL_0098: dup 
        // IL_0099: stsfld 0x040021ED OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__75_1
        // IL_009E: call 0x2B000108 [System.Linq]System.Linq.Enumerable::Select<class [OpenRA.Game]OpenRA.MapPreview, string>
        // IL_00A3: call 0x2B000066 [OpenRA.Game]OpenRA.Exts::ToHashSet<string>
        // IL_00A8: stfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_00AD: br.s IL_00B0
        // IL_00AF: ret 
        // IL_00B0: ldarg.0 0
        // IL_00B1: ldfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_00B6: ldarg.0 0
        // IL_00B7: ldftn 0x0A0005F8 [OpenRA.Game]OpenRA.Server.Server::MapIsUnknown
        // IL_00BD: newobj 0x0A0002C8 class [System.Runtime]System.Func`2<string, bool>::.ctor
        // IL_00C2: call 0x2B00006E [System.Linq]System.Linq.Enumerable::Where<string>
        // IL_00C7: call 0x2B0000B4 [System.Linq]System.Linq.Enumerable::ToList<string>
        // IL_00CC: stloc.1 1
        // IL_00CD: ldloc.1 1
        // IL_00CE: callvirt 0x0A0004BD class [System.Collections]System.Collections.Generic.List`1<string>::get_Count
        // IL_00D3: brtrue.s IL_00D6
        // IL_00D5: ret 
        // IL_00D6: ldarg.0 0
        // IL_00D7: ldfld 0x0A0005BE [OpenRA.Game]OpenRA.Server.Server::Settings
        // IL_00DC: ldfld 0x0A0005BF [OpenRA.Game]OpenRA.ServerSettings::QueryMapRepository
        // IL_00E1: brfalse IL_018C
        // IL_00E6: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_00EB: ldloca.s 6
        // IL_00ED: ldc.i4.s 52
        // IL_00EF: ldc.i4.1 1
        // IL_00F0: call 0x0A0002FA [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::.ctor
        // IL_00F5: ldloca.s 6
        // IL_00F7: ldstr 0x7000DEB5 [81, 117, 101, 114, 121, 105, 110, 103, 32, 82, 101, 115, 111, 117, 114, 99, 101, 32, 67, 101, 110, 116, 101, 114, 32, 102, 111, 114, 32, 105, 110, 102, 111, 114, 109, 97, 116, 105, 111, 110, 32, 111, 110, 32] utf16-bytes=[51, 00, 75, 00, 65, 00, 72, 00, 79, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 52, 00, 65, 00, 73, 00, 6F, 00, 75, 00, 72, 00, 63, 00, 65, 00, 20, 00, 43, 00, 65, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 69, 00, 6E, 00, 66, 00, 6F, 00, 72, 00, 6D, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 6F, 00, 6E, 00, 20, 00] terminal-flag=Some(0)
        // IL_00FC: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_0101: ldloca.s 6
        // IL_0103: ldloc.1 1
        // IL_0104: callvirt 0x0A0004BD class [System.Collections]System.Collections.Generic.List`1<string>::get_Count
        // IL_0109: call 0x2B00004A [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendFormatted<int32>
        // IL_010E: ldloca.s 6
        // IL_0110: ldstr 0x7000DF0F [32, 109, 97, 112, 115, 46, 46, 46] utf16-bytes=[20, 00, 6D, 00, 61, 00, 70, 00, 73, 00, 2E, 00, 2E, 00, 2E, 00] terminal-flag=Some(0)
        // IL_0115: call 0x0A0002FB [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::AppendLiteral
        // IL_011A: ldloca.s 6
        // IL_011C: call 0x0A0002FD [System.Runtime]System.Runtime.CompilerServices.DefaultInterpolatedStringHandler::ToStringAndClear
        // IL_0121: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_0126: ldarg.0 0
        // IL_0127: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_012C: ldfld 0x0A0001B9 [OpenRA.Game]OpenRA.ModData::Manifest
        // IL_0131: callvirt 0x2B0000F7 [OpenRA.Game]OpenRA.Manifest::Get<class OpenRA.Mods.Common.WebServices>
        // IL_0136: ldfld 0x04000072 OpenRA.Mods.Common.WebServices::MapRepository
        // IL_013B: stloc.3 3
        // IL_013C: ldloc.0 0
        // IL_013D: ldfld 0x04002214 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass75_0::mapCache
        // IL_0142: ldloc.3 3
        // IL_0143: ldloc.1 1
        // IL_0144: ldnull 
        // IL_0145: ldnull 
        // IL_0146: callvirt 0x0A0005C1 [OpenRA.Game]OpenRA.MapCache::QueryRemoteMapDetails
        // IL_014B: ldarg.0 0
        // IL_014C: ldfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_0151: ldloc.0 0
        // IL_0152: ldftn 0x0600297F OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass75_0::<InitializeMapPool>b__2
        // IL_0158: newobj 0x0A0002C8 class [System.Runtime]System.Func`2<string, bool>::.ctor
        // IL_015D: call 0x2B00006E [System.Linq]System.Linq.Enumerable::Where<string>
        // IL_0162: stloc.s 4
        // IL_0164: call 0x0A0005F9 [System.Runtime]System.Diagnostics.Stopwatch::StartNew
        // IL_0169: stloc.s 5
        // IL_016B: br.s IL_0174
        // IL_016D: ldc.i4.s 100
        // IL_016F: call 0x0A0005FA [System.Threading.Thread]System.Threading.Thread::Sleep
        // IL_0174: ldloc.s 4
        // IL_0176: call 0x2B000109 [System.Linq]System.Linq.Enumerable::Any<string>
        // IL_017B: brfalse.s IL_018C
        // IL_017D: ldloc.s 5
        // IL_017F: callvirt 0x0A0005FC [System.Runtime]System.Diagnostics.Stopwatch::get_ElapsedMilliseconds
        // IL_0184: ldc.i4 10000
        // IL_0189: conv.i8 
        // IL_018A: blt.s IL_016D
        // IL_018C: ldarg.0 0
        // IL_018D: ldfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_0192: ldarg.0 0
        // IL_0193: ldftn 0x0A0005F8 [OpenRA.Game]OpenRA.Server.Server::MapIsUnknown
        // IL_0199: newobj 0x0A0002C8 class [System.Runtime]System.Func`2<string, bool>::.ctor
        // IL_019E: call 0x2B00006E [System.Linq]System.Linq.Enumerable::Where<string>
        // IL_01A3: call 0x2B0000B4 [System.Linq]System.Linq.Enumerable::ToList<string>
        // IL_01A8: stloc.2 2
        // IL_01A9: ldloc.2 2
        // IL_01AA: callvirt 0x0A0004BD class [System.Collections]System.Collections.Generic.List`1<string>::get_Count
        // IL_01AF: brfalse.s IL_01D0
        // IL_01B1: ldstr 0x7000D1C5 [115, 101, 114, 118, 101, 114] utf16-bytes=[73, 00, 65, 00, 72, 00, 76, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_01B6: ldstr 0x7000DF21 [70, 97, 105, 108, 101, 100, 32, 116, 111, 32, 114, 101, 115, 111, 108, 118, 101, 32, 109, 97, 112, 115, 58, 32] utf16-bytes=[46, 00, 61, 00, 69, 00, 6C, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 72, 00, 65, 00, 73, 00, 6F, 00, 6C, 00, 76, 00, 65, 00, 20, 00, 6D, 00, 61, 00, 70, 00, 73, 00, 3A, 00, 20, 00] terminal-flag=Some(0)
        // IL_01BB: ldloc.2 2
        // IL_01BC: ldstr 0x7000099F [44, 32] utf16-bytes=[2C, 00, 20, 00] terminal-flag=Some(0)
        // IL_01C1: call 0x2B00005D [OpenRA.Game]OpenRA.Exts::JoinWith<string>
        // IL_01C6: call 0x0A000244 [System.Runtime]System.String::Concat
        // IL_01CB: call 0x0A000576 [OpenRA.Game]OpenRA.Log::Write
        // IL_01D0: ret 
    }

    private static string ChooseInitialMap(OpenRA.Server.Server server)
    {
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_dd6d26e90d0e3806ee110be3f03d7c917c2e9ebe bytes=15128121020E02: class [System.Runtime]System.Func`2<string, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_010001D2 v2 = server.Settings;
        string v3 = v2.Map;
        int v4 = __cil_bool_load(server.MapIsKnown(v3));
        if (v4 == 0) {
            goto IL_001F;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        __cil_type_010001D2 v6 = server.Settings;
        string v7 = v6.Map;
        return v7;
        IL_001F: ;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v9 = server.MapPool;
        if (v9 is not null) {
            goto IL_0048;
        } else {
            goto IL_0027;
        }
        IL_0027: ;
        __cil_type_0100008C v11 = server.ModData;
        __cil_type_010000F7 v12 = v11.MapCache;
        __cil_type_010001D2 v14 = server.Settings;
        string v15 = v14.Map;
        __cil_type_0100006E v16 = __cil_newobj_0A00052C();
        string v17 = v12.ChooseInitialMap(v15, v16);
        return v17;
        IL_0048: ;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v19 = server.MapPool;
        nint v21 = __cil_ldftn_0A0005FE;
        __cil_ref_dd6d26e90d0e3806ee110be3f03d7c917c2e9ebe v22 = __cil_newobj_0A0002C8(server, v21);
        __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v23 = __cil_methodspec_call_2B00006E(((__cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3)(v19)), v22);
        __cil_type_0100006E v24 = __cil_newobj_0A00052C();
        string v25 = __cil_methodspec_call_2B000030(v23, v24);
        return v25;
    }

    public virtual void ServerStarted(OpenRA.Server.Server server)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [03, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 03, 28, 3E, 03, 00, 06, 03]
        // .code-bytes IL_0018: [28, 3F, 03, 00, 06, 0C, 08, 28, E0, 03, 00, 0A, 2C, 0B, 72, 53, DF, 00, 70, 73, 8A, 03, 00, 0A]
        // .code-bytes IL_0030: [7A, 03, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 03, 7B, BE, 05, 00, 0A, 08, 25, 0D, 7D, FD, 05]
        // .code-bytes IL_0048: [00, 0A, 09, 7D, BD, 05, 00, 0A, 03, 03, 7B, 85, 05, 00, 0A, 7B, 21, 03, 00, 0A, 08, 6F, 88, 05]
        // .code-bytes IL_0060: [00, 0A, 7D, 86, 05, 00, 0A, 03, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 03, 7B, 00, 06, 00, 0A]
        // .code-bytes IL_0078: [03, 7B, 86, 05, 00, 0A, 6F, 01, 06, 00, 0A, 7D, 02, 06, 00, 0A, 03, 7B, 72, 05, 00, 0A, 03, 7B]
        // .code-bytes IL_0090: [86, 05, 00, 0A, 6F, 9A, 05, 00, 0A, 7B, 9B, 05, 00, 0A, 7E, EE, 21, 00, 04, 25, 2D, 17, 26, 7E]
        // .code-bytes IL_00A8: [D9, 21, 00, 04, FE, 06, 4C, 29, 00, 06, 73, 03, 06, 00, 0A, 25, 80, EE, 21, 00, 04, 28, 0A, 01]
        // .code-bytes IL_00C0: [00, 2B, 7E, EF, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 4D, 29, 00, 06, 73, 04]
        // .code-bytes IL_00D8: [06, 00, 0A, 25, 80, EF, 21, 00, 04, 28, 0B, 01, 00, 2B, 7E, F0, 21, 00, 04, 25, 2D, 17, 26, 7E]
        // .code-bytes IL_00F0: [D9, 21, 00, 04, FE, 06, 4E, 29, 00, 06, 73, 05, 06, 00, 0A, 25, 80, F0, 21, 00, 04, 7E, F1, 21]
        // .code-bytes IL_0108: [00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 4F, 29, 00, 06, 73, 06, 06, 00, 0A, 25, 80]
        // .code-bytes IL_0120: [F1, 21, 00, 04, 28, 0C, 01, 00, 2B, 7D, 74, 05, 00, 0A, 03, 03, 7B, 72, 05, 00, 0A, 7B, 81, 05]
        // .code-bytes IL_0138: [00, 0A, 03, 7B, 86, 05, 00, 0A, 28, 42, 03, 00, 06, DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00, 0A]
        // .code-bytes IL_0150: [DC, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] string
        // .local [3] string
        // IL_0000: ldarg.1 1
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.1 1
        // IL_0012: call 0x0600033E OpenRA.Mods.Common.Server.LobbyCommands::InitializeMapPool
        // IL_0017: ldarg.1 1
        // IL_0018: call 0x0600033F OpenRA.Mods.Common.Server.LobbyCommands::ChooseInitialMap
        // IL_001D: stloc.2 2
        // IL_001E: ldloc.2 2
        // IL_001F: call 0x0A0003E0 [System.Runtime]System.String::IsNullOrEmpty
        // IL_0024: brfalse.s IL_0031
        // IL_0026: ldstr 0x7000DF53 [85, 110, 97, 98, 108, 101, 32, 116, 111, 32, 114, 101, 115, 111, 108, 118, 101, 32, 97, 32, 118, 97, 108, 105, 100, 32, 105, 110, 105, 116, 105, 97, 108, 32, 109, 97, 112] utf16-bytes=[55, 00, 6E, 00, 61, 00, 62, 00, 6C, 00, 65, 00, 20, 00, 74, 00, 6F, 00, 20, 00, 72, 00, 65, 00, 73, 00, 6F, 00, 6C, 00, 76, 00, 65, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 69, 00, 6E, 00, 69, 00, 74, 00, 69, 00, 61, 00, 6C, 00, 20, 00, 6D, 00, 61, 00, 70, 00] terminal-flag=Some(0)
        // IL_002B: newobj 0x0A00038A [System.Runtime]System.InvalidOperationException::.ctor
        // IL_0030: throw 
        // IL_0031: ldarg.1 1
        // IL_0032: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0037: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_003C: ldarg.1 1
        // IL_003D: ldfld 0x0A0005BE [OpenRA.Game]OpenRA.Server.Server::Settings
        // IL_0042: ldloc.2 2
        // IL_0043: dup 
        // IL_0044: stloc.3 3
        // IL_0045: stfld 0x0A0005FD [OpenRA.Game]OpenRA.ServerSettings::Map
        // IL_004A: ldloc.3 3
        // IL_004B: stfld 0x0A0005BD [OpenRA.Game]OpenRA.Network.Session/Global::Map
        // IL_0050: ldarg.1 1
        // IL_0051: ldarg.1 1
        // IL_0052: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_0057: ldfld 0x0A000321 [OpenRA.Game]OpenRA.ModData::MapCache
        // IL_005C: ldloc.2 2
        // IL_005D: callvirt 0x0A000588 [OpenRA.Game]OpenRA.MapCache::get_Item
        // IL_0062: stfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0067: ldarg.1 1
        // IL_0068: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_006D: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_0072: ldarg.1 1
        // IL_0073: ldfld 0x0A000600 [OpenRA.Game]OpenRA.Server.Server::MapStatusCache
        // IL_0078: ldarg.1 1
        // IL_0079: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_007E: callvirt 0x0A000601 [OpenRA.Game]OpenRA.Server.MapStatusCache::get_Item
        // IL_0083: stfld 0x0A000602 [OpenRA.Game]OpenRA.Network.Session/Global::MapStatus
        // IL_0088: ldarg.1 1
        // IL_0089: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_008E: ldarg.1 1
        // IL_008F: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0094: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
        // IL_0099: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
        // IL_009E: ldsfld 0x040021EE OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_0
        // IL_00A3: dup 
        // IL_00A4: brtrue.s IL_00BD
        // IL_00A6: pop 
        // IL_00A7: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_00AC: ldftn 0x0600294C OpenRA.Mods.Common.Server.LobbyCommands/<>c::<ServerStarted>b__77_0
        // IL_00B2: newobj 0x0A000603 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, class [OpenRA.Game]OpenRA.Network.Session/Slot>::.ctor
        // IL_00B7: dup 
        // IL_00B8: stsfld 0x040021EE OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_0
        // IL_00BD: call 0x2B00010A [System.Linq]System.Linq.Enumerable::Select<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, class [OpenRA.Game]OpenRA.Network.Session/Slot>
        // IL_00C2: ldsfld 0x040021EF OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_1
        // IL_00C7: dup 
        // IL_00C8: brtrue.s IL_00E1
        // IL_00CA: pop 
        // IL_00CB: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_00D0: ldftn 0x0600294D OpenRA.Mods.Common.Server.LobbyCommands/<>c::<ServerStarted>b__77_1
        // IL_00D6: newobj 0x0A000604 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, bool>::.ctor
        // IL_00DB: dup 
        // IL_00DC: stsfld 0x040021EF OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_1
        // IL_00E1: call 0x2B00010B [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.Network.Session/Slot>
        // IL_00E6: ldsfld 0x040021F0 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_2
        // IL_00EB: dup 
        // IL_00EC: brtrue.s IL_0105
        // IL_00EE: pop 
        // IL_00EF: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_00F4: ldftn 0x0600294E OpenRA.Mods.Common.Server.LobbyCommands/<>c::<ServerStarted>b__77_2
        // IL_00FA: newobj 0x0A000605 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, string>::.ctor
        // IL_00FF: dup 
        // IL_0100: stsfld 0x040021F0 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_2
        // IL_0105: ldsfld 0x040021F1 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_3
        // IL_010A: dup 
        // IL_010B: brtrue.s IL_0124
        // IL_010D: pop 
        // IL_010E: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0113: ldftn 0x0600294F OpenRA.Mods.Common.Server.LobbyCommands/<>c::<ServerStarted>b__77_3
        // IL_0119: newobj 0x0A000606 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, class [OpenRA.Game]OpenRA.Network.Session/Slot>::.ctor
        // IL_011E: dup 
        // IL_011F: stsfld 0x040021F1 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__77_3
        // IL_0124: call 0x2B00010C [System.Linq]System.Linq.Enumerable::ToDictionary<class [OpenRA.Game]OpenRA.Network.Session/Slot, string, class [OpenRA.Game]OpenRA.Network.Session/Slot>
        // IL_0129: stfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_012E: ldarg.1 1
        // IL_012F: ldarg.1 1
        // IL_0130: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0135: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_013A: ldarg.1 1
        // IL_013B: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0140: call 0x06000342 OpenRA.Mods.Common.Server.LobbyCommands::LoadMapSettings
        // IL_0145: leave.s IL_0151
        // IL_0147: ldloc.1 1
        // IL_0148: brfalse.s IL_0150
        // IL_014A: ldloc.0 0
        // IL_014B: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0150: endfinally 
        // IL_0151: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 318, handler_offset: 327, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_0147 finally IL_0147..IL_0151
    }

    private static OpenRA.Network.Session.Slot MakeSlotFromPlayerReference(OpenRA.PlayerReference pr)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [02, 7B, 07, 06, 00, 0A, 2D, 02, 14, 2A, 73, 08, 06, 00, 0A, 25, 02, 7B, 09, 06, 00, 0A, 7D, 0A]
        // .code-bytes IL_0018: [06, 00, 0A, 25, 16, 7D, 94, 05, 00, 0A, 25, 02, 7B, 0B, 06, 00, 0A, 7D, 0C, 06, 00, 0A, 25, 02]
        // .code-bytes IL_0030: [7B, 0D, 06, 00, 0A, 7D, EA, 05, 00, 0A, 25, 02, 7B, 0E, 06, 00, 0A, 7D, 9E, 05, 00, 0A, 25, 02]
        // .code-bytes IL_0048: [7B, 0F, 06, 00, 0A, 7D, EC, 05, 00, 0A, 25, 02, 7B, 10, 06, 00, 0A, 7D, ED, 05, 00, 0A, 25, 02]
        // .code-bytes IL_0060: [7B, 11, 06, 00, 0A, 7D, 98, 05, 00, 0A, 25, 02, 7B, 12, 06, 00, 0A, 7D, 13, 06, 00, 0A, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: ldfld 0x0A000607 [OpenRA.Game]OpenRA.PlayerReference::Playable
        // IL_0006: brtrue.s IL_000A
        // IL_0008: ldnull 
        // IL_0009: ret 
        // IL_000A: newobj 0x0A000608 [OpenRA.Game]OpenRA.Network.Session/Slot::.ctor
        // IL_000F: dup 
        // IL_0010: ldarg.0 0
        // IL_0011: ldfld 0x0A000609 [OpenRA.Game]OpenRA.PlayerReference::Name
        // IL_0016: stfld 0x0A00060A [OpenRA.Game]OpenRA.Network.Session/Slot::PlayerReference
        // IL_001B: dup 
        // IL_001C: ldc.i4.0 0
        // IL_001D: stfld 0x0A000594 [OpenRA.Game]OpenRA.Network.Session/Slot::Closed
        // IL_0022: dup 
        // IL_0023: ldarg.0 0
        // IL_0024: ldfld 0x0A00060B [OpenRA.Game]OpenRA.PlayerReference::AllowBots
        // IL_0029: stfld 0x0A00060C [OpenRA.Game]OpenRA.Network.Session/Slot::AllowBots
        // IL_002E: dup 
        // IL_002F: ldarg.0 0
        // IL_0030: ldfld 0x0A00060D [OpenRA.Game]OpenRA.PlayerReference::LockFaction
        // IL_0035: stfld 0x0A0005EA [OpenRA.Game]OpenRA.Network.Session/Slot::LockFaction
        // IL_003A: dup 
        // IL_003B: ldarg.0 0
        // IL_003C: ldfld 0x0A00060E [OpenRA.Game]OpenRA.PlayerReference::LockColor
        // IL_0041: stfld 0x0A00059E [OpenRA.Game]OpenRA.Network.Session/Slot::LockColor
        // IL_0046: dup 
        // IL_0047: ldarg.0 0
        // IL_0048: ldfld 0x0A00060F [OpenRA.Game]OpenRA.PlayerReference::LockTeam
        // IL_004D: stfld 0x0A0005EC [OpenRA.Game]OpenRA.Network.Session/Slot::LockTeam
        // IL_0052: dup 
        // IL_0053: ldarg.0 0
        // IL_0054: ldfld 0x0A000610 [OpenRA.Game]OpenRA.PlayerReference::LockHandicap
        // IL_0059: stfld 0x0A0005ED [OpenRA.Game]OpenRA.Network.Session/Slot::LockHandicap
        // IL_005E: dup 
        // IL_005F: ldarg.0 0
        // IL_0060: ldfld 0x0A000611 [OpenRA.Game]OpenRA.PlayerReference::LockSpawn
        // IL_0065: stfld 0x0A000598 [OpenRA.Game]OpenRA.Network.Session/Slot::LockSpawn
        // IL_006A: dup 
        // IL_006B: ldarg.0 0
        // IL_006C: ldfld 0x0A000612 [OpenRA.Game]OpenRA.PlayerReference::Required
        // IL_0071: stfld 0x0A000613 [OpenRA.Game]OpenRA.Network.Session/Slot::Required
        // IL_0076: ret 
    }

    public static void LoadMapSettings(OpenRA.Server.Server server, OpenRA.Network.Session.Global gs, OpenRA.MapPreview map)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [73, 80, 29, 00, 06, 0A, 06, 04, 7D, 15, 22, 00, 04, 02, 7B, 72, 05, 00, 0A, 0B, 16, 0C, 07, 12]
        // .code-bytes IL_0018: [02, 28, 73, 05, 00, 0A, 06, 7B, 15, 22, 00, 04, 6F, AE, 05, 00, 0A, 6F, F8, 00, 00, 2B, 06, 7B]
        // .code-bytes IL_0030: [15, 22, 00, 04, 6F, C2, 05, 00, 0A, 6F, F8, 00, 00, 2B, 28, F9, 00, 00, 2B, 06, FE, 06, 81, 29]
        // .code-bytes IL_0048: [00, 06, 73, C3, 05, 00, 0A, 28, FA, 00, 00, 2B, 0D, 09, 6F, D2, 00, 00, 0A, 13, 04, 38, C8, 00]
        // .code-bytes IL_0060: [00, 00, 11, 04, 6F, D1, 00, 00, 0A, 13, 05, 11, 05, 7B, D3, 05, 00, 0A, 13, 06, 11, 05, 7B, D3]
        // .code-bytes IL_0078: [05, 00, 0A, 13, 07, 03, 7B, CC, 05, 00, 0A, 11, 05, 7B, C5, 05, 00, 0A, 12, 08, 6F, 14, 06, 00]
        // .code-bytes IL_0090: [0A, 2C, 5C, 11, 05, 7B, CA, 05, 00, 0A, 2D, 48, 11, 05, 7B, C8, 05, 00, 0A, 6F, 15, 06, 00, 0A]
        // .code-bytes IL_00A8: [11, 08, 7B, CF, 05, 00, 0A, 28, 54, 00, 00, 2B, 2C, 0B, 11, 08, 7B, CF, 05, 00, 0A, 13, 06, 2B]
        // .code-bytes IL_00C0: [23, 11, 05, 7B, C8, 05, 00, 0A, 6F, 15, 06, 00, 0A, 11, 08, 7B, CE, 05, 00, 0A, 28, 54, 00, 00]
        // .code-bytes IL_00D8: [2B, 2C, 09, 11, 08, 7B, CE, 05, 00, 0A, 13, 06, 11, 08, 7B, CF, 05, 00, 0A, 13, 07, 2B, 07, 73]
        // .code-bytes IL_00F0: [D4, 05, 00, 0A, 13, 08, 11, 08, 11, 05, 7B, CA, 05, 00, 0A, 7D, D5, 05, 00, 0A, 11, 08, 11, 06]
        // .code-bytes IL_0108: [7D, CE, 05, 00, 0A, 11, 08, 11, 07, 7D, CF, 05, 00, 0A, 03, 7B, CC, 05, 00, 0A, 11, 05, 7B, C5]
        // .code-bytes IL_0120: [05, 00, 0A, 11, 08, 6F, D6, 05, 00, 0A, 11, 04, 6F, 1B, 00, 00, 0A, 3A, 2C, FF, FF, FF, DE, 16]
        // .code-bytes IL_0138: [11, 04, 2C, 07, 11, 04, 6F, 1A, 00, 00, 0A, DC, 08, 2C, 06, 07, 28, 79, 05, 00, 0A, DC, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass79_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // .local [4] class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // .local [5] class [OpenRA.Game]OpenRA.Traits.LobbyOption
        // .local [6] string
        // .local [7] string
        // .local [8] class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState
        // IL_0000: newobj 0x06002980 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass79_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.2 2
        // IL_0008: stfld 0x04002215 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass79_0::map
        // IL_000D: ldarg.0 0
        // IL_000E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0013: stloc.1 1
        // IL_0014: ldc.i4.0 0
        // IL_0015: stloc.2 2
        // IL_0016: ldloc.1 1
        // IL_0017: ldloca.s 2
        // IL_0019: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x04002215 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass79_0::map
        // IL_0024: callvirt 0x0A0005AE [OpenRA.Game]OpenRA.MapPreview::get_PlayerActorInfo
        // IL_0029: callvirt 0x2B0000F8 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_002E: ldloc.0 0
        // IL_002F: ldfld 0x04002215 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass79_0::map
        // IL_0034: callvirt 0x0A0005C2 [OpenRA.Game]OpenRA.MapPreview::get_WorldActorInfo
        // IL_0039: callvirt 0x2B0000F8 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_003E: call 0x2B0000F9 [System.Linq]System.Linq.Enumerable::Concat<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions>
        // IL_0043: ldloc.0 0
        // IL_0044: ldftn 0x06002981 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass79_0::<LoadMapSettings>b__0
        // IL_004A: newobj 0x0A0005C3 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions, class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>>::.ctor
        // IL_004F: call 0x2B0000FA [System.Linq]System.Linq.Enumerable::SelectMany<class [OpenRA.Game]OpenRA.Traits.ILobbyOptions, class [OpenRA.Game]OpenRA.Traits.LobbyOption>
        // IL_0054: stloc.3 3
        // IL_0055: ldloc.3 3
        // IL_0056: callvirt 0x0A0000D2 class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>::GetEnumerator
        // IL_005B: stloc.s 4
        // IL_005D: br IL_012A
        // IL_0062: ldloc.s 4
        // IL_0064: callvirt 0x0A0000D1 class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>::get_Current
        // IL_0069: stloc.s 5
        // IL_006B: ldloc.s 5
        // IL_006D: ldfld 0x0A0005D3 [OpenRA.Game]OpenRA.Traits.LobbyOption::DefaultValue
        // IL_0072: stloc.s 6
        // IL_0074: ldloc.s 5
        // IL_0076: ldfld 0x0A0005D3 [OpenRA.Game]OpenRA.Traits.LobbyOption::DefaultValue
        // IL_007B: stloc.s 7
        // IL_007D: ldarg.1 1
        // IL_007E: ldfld 0x0A0005CC [OpenRA.Game]OpenRA.Network.Session/Global::LobbyOptions
        // IL_0083: ldloc.s 5
        // IL_0085: ldfld 0x0A0005C5 [OpenRA.Game]OpenRA.Traits.LobbyOption::Id
        // IL_008A: ldloca.s 8
        // IL_008C: callvirt 0x0A000614 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState>::TryGetValue
        // IL_0091: brfalse.s IL_00EF
        // IL_0093: ldloc.s 5
        // IL_0095: ldfld 0x0A0005CA [OpenRA.Game]OpenRA.Traits.LobbyOption::IsLocked
        // IL_009A: brtrue.s IL_00E4
        // IL_009C: ldloc.s 5
        // IL_009E: ldfld 0x0A0005C8 [OpenRA.Game]OpenRA.Traits.LobbyOption::Values
        // IL_00A3: callvirt 0x0A000615 class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, string>::get_Keys
        // IL_00A8: ldloc.s 8
        // IL_00AA: ldfld 0x0A0005CF [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::PreferredValue
        // IL_00AF: call 0x2B000054 [System.Linq]System.Linq.Enumerable::Contains<string>
        // IL_00B4: brfalse.s IL_00C1
        // IL_00B6: ldloc.s 8
        // IL_00B8: ldfld 0x0A0005CF [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::PreferredValue
        // IL_00BD: stloc.s 6
        // IL_00BF: br.s IL_00E4
        // IL_00C1: ldloc.s 5
        // IL_00C3: ldfld 0x0A0005C8 [OpenRA.Game]OpenRA.Traits.LobbyOption::Values
        // IL_00C8: callvirt 0x0A000615 class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, string>::get_Keys
        // IL_00CD: ldloc.s 8
        // IL_00CF: ldfld 0x0A0005CE [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::Value
        // IL_00D4: call 0x2B000054 [System.Linq]System.Linq.Enumerable::Contains<string>
        // IL_00D9: brfalse.s IL_00E4
        // IL_00DB: ldloc.s 8
        // IL_00DD: ldfld 0x0A0005CE [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::Value
        // IL_00E2: stloc.s 6
        // IL_00E4: ldloc.s 8
        // IL_00E6: ldfld 0x0A0005CF [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::PreferredValue
        // IL_00EB: stloc.s 7
        // IL_00ED: br.s IL_00F6
        // IL_00EF: newobj 0x0A0005D4 [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::.ctor
        // IL_00F4: stloc.s 8
        // IL_00F6: ldloc.s 8
        // IL_00F8: ldloc.s 5
        // IL_00FA: ldfld 0x0A0005CA [OpenRA.Game]OpenRA.Traits.LobbyOption::IsLocked
        // IL_00FF: stfld 0x0A0005D5 [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::IsLocked
        // IL_0104: ldloc.s 8
        // IL_0106: ldloc.s 6
        // IL_0108: stfld 0x0A0005CE [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::Value
        // IL_010D: ldloc.s 8
        // IL_010F: ldloc.s 7
        // IL_0111: stfld 0x0A0005CF [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState::PreferredValue
        // IL_0116: ldarg.1 1
        // IL_0117: ldfld 0x0A0005CC [OpenRA.Game]OpenRA.Network.Session/Global::LobbyOptions
        // IL_011C: ldloc.s 5
        // IL_011E: ldfld 0x0A0005C5 [OpenRA.Game]OpenRA.Traits.LobbyOption::Id
        // IL_0123: ldloc.s 8
        // IL_0125: callvirt 0x0A0005D6 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/LobbyOptionState>::set_Item
        // IL_012A: ldloc.s 4
        // IL_012C: callvirt 0x0A00001B [System.Runtime]System.Collections.IEnumerator::MoveNext
        // IL_0131: brtrue IL_0062
        // IL_0136: leave.s IL_014E
        // IL_0138: ldloc.s 4
        // IL_013A: brfalse.s IL_0143
        // IL_013C: ldloc.s 4
        // IL_013E: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
        // IL_0143: endfinally 
        // IL_0144: ldloc.2 2
        // IL_0145: brfalse.s IL_014D
        // IL_0147: ldloc.1 1
        // IL_0148: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_014D: endfinally 
        // IL_014E: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 93, try_length: 219, handler_offset: 312, handler_length: 12, raw_flags: 2 }
        // .try IL_005D..IL_0138 finally IL_0138..IL_0144
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 22, try_length: 302, handler_offset: 324, handler_length: 10, raw_flags: 2 }
        // .try IL_0016..IL_0144 finally IL_0144..IL_014E
    }

    public static OpenRA.Primitives.Color SanitizePlayerColor(OpenRA.Server.Server server, OpenRA.Primitives.Color askedColor, int playerIndex, OpenRA.Server.Connection connectionToEcho = null)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 82, 29, 00, 06, 0A, 06, 05, 7D, 16, 22, 00, 04, 06, 02, 7D, 17, 22, 00, 04, 06, 04, 7D, 18]
        // .code-bytes IL_0018: [22, 00, 04, 06, 7B, 17, 22, 00, 04, 7B, 72, 05, 00, 0A, 0B, 16, 0C, 07, 12, 02, 28, 73, 05, 00]
        // .code-bytes IL_0030: [0A, 06, 7B, 17, 22, 00, 04, 7B, 85, 05, 00, 0A, 6F, 05, 03, 00, 0A, 7B, 06, 03, 00, 0A, 18, 6F]
        // .code-bytes IL_0048: [07, 03, 00, 0A, 6F, F2, 00, 00, 2B, 0D, 03, 13, 04, 06, 7B, 17, 22, 00, 04, 7B, 85, 05, 00, 0A]
        // .code-bytes IL_0060: [6F, 01, 03, 00, 0A, 06, 7B, 17, 22, 00, 04, 7B, 86, 05, 00, 0A, 6F, B5, 05, 00, 0A, 6F, B6, 05]
        // .code-bytes IL_0078: [00, 0A, 6F, 3E, 00, 00, 0A, 28, F3, 00, 00, 2B, 13, 05, 06, 7B, 17, 22, 00, 04, 7B, 72, 05, 00]
        // .code-bytes IL_0090: [0A, 7B, 80, 05, 00, 0A, 06, FE, 06, 84, 29, 00, 06, 73, 7F, 05, 00, 0A, 28, FE, 00, 00, 2B, 7E]
        // .code-bytes IL_00A8: [F2, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 50, 29, 00, 06, 73, B7, 05, 00, 0A]
        // .code-bytes IL_00C0: [25, 80, F2, 21, 00, 04, 28, F4, 00, 00, 2B, 06, 7B, 17, 22, 00, 04, 7B, 86, 05, 00, 0A, 6F, 9A]
        // .code-bytes IL_00D8: [05, 00, 0A, 7B, 9B, 05, 00, 0A, 6F, B8, 05, 00, 0A, 7E, F3, 21, 00, 04, 25, 2D, 17, 26, 7E, D9]
        // .code-bytes IL_00F0: [21, 00, 04, FE, 06, 51, 29, 00, 06, 73, B9, 05, 00, 0A, 25, 80, F3, 21, 00, 04, 28, F5, 00, 00]
        // .code-bytes IL_0108: [2B, 28, F6, 00, 00, 2B, 28, F3, 00, 00, 2B, 13, 06, 09, 11, 04, 06, 7B, 17, 22, 00, 04, 7B, BA]
        // .code-bytes IL_0120: [05, 00, 0A, 11, 05, 11, 06, 06, FE, 06, 83, 29, 00, 06, 73, 0B, 03, 00, 0A, 6F, 8A, 1F, 00, 06]
        // .code-bytes IL_0138: [13, 07, DE, 0A, 08, 2C, 06, 07, 28, 79, 05, 00, 0A, DC, 11, 07, 2A]
        // .local [0] class OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0
        // .local [1] class [OpenRA.Game]OpenRA.Network.Session
        // .local [2] bool
        // .local [3] class OpenRA.Mods.Common.Traits.IColorPickerManagerInfo
        // .local [4] valuetype [OpenRA.Game]OpenRA.Primitives.Color
        // .local [5] class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // .local [6] class [System.Collections]System.Collections.Generic.List`1<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // .local [7] valuetype [OpenRA.Game]OpenRA.Primitives.Color
        // IL_0000: newobj 0x06002982 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: ldloc.0 0
        // IL_0007: ldarg.3 3
        // IL_0008: stfld 0x04002216 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::connectionToEcho
        // IL_000D: ldloc.0 0
        // IL_000E: ldarg.0 0
        // IL_000F: stfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_0014: ldloc.0 0
        // IL_0015: ldarg.2 2
        // IL_0016: stfld 0x04002218 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::playerIndex
        // IL_001B: ldloc.0 0
        // IL_001C: ldfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_0021: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0026: stloc.1 1
        // IL_0027: ldc.i4.0 0
        // IL_0028: stloc.2 2
        // IL_0029: ldloc.1 1
        // IL_002A: ldloca.s 2
        // IL_002C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0031: ldloc.0 0
        // IL_0032: ldfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_0037: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_003C: callvirt 0x0A000305 [OpenRA.Game]OpenRA.ModData::get_DefaultRules
        // IL_0041: ldfld 0x0A000306 [OpenRA.Game]OpenRA.Ruleset::Actors
        // IL_0046: ldc.i4.2 2
        // IL_0047: callvirt 0x0A000307 [OpenRA.Game]OpenRA.ActorInfoDictionary::get_Item
        // IL_004C: callvirt 0x2B0000F2 [OpenRA.Game]OpenRA.ActorInfo::TraitInfo<class OpenRA.Mods.Common.Traits.IColorPickerManagerInfo>
        // IL_0051: stloc.3 3
        // IL_0052: ldarg.1 1
        // IL_0053: stloc.s 4
        // IL_0055: ldloc.0 0
        // IL_0056: ldfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_005B: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
        // IL_0060: callvirt 0x0A000301 [OpenRA.Game]OpenRA.ModData::get_DefaultTerrainInfo
        // IL_0065: ldloc.0 0
        // IL_0066: ldfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_006B: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0070: callvirt 0x0A0005B5 [OpenRA.Game]OpenRA.MapPreview::get_TileSet
        // IL_0075: callvirt 0x0A0005B6 class [System.Runtime]System.Collections.Generic.IReadOnlyDictionary`2<string, class [OpenRA.Game]OpenRA.ITerrainInfo>::get_Item
        // IL_007A: callvirt 0x0A00003E [OpenRA.Game]OpenRA.ITerrainInfo::get_RestrictedPlayerColors
        // IL_007F: call 0x2B0000F3 [System.Linq]System.Linq.Enumerable::ToList<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_0084: stloc.s 5
        // IL_0086: ldloc.0 0
        // IL_0087: ldfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_008C: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0091: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
        // IL_0096: ldloc.0 0
        // IL_0097: ldftn 0x06002984 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::<SanitizePlayerColor>b__1
        // IL_009D: newobj 0x0A00057F class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, bool>::.ctor
        // IL_00A2: call 0x2B0000FE [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.Network.Session/Client>
        // IL_00A7: ldsfld 0x040021F2 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__80_2
        // IL_00AC: dup 
        // IL_00AD: brtrue.s IL_00C6
        // IL_00AF: pop 
        // IL_00B0: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_00B5: ldftn 0x06002950 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<SanitizePlayerColor>b__80_2
        // IL_00BB: newobj 0x0A0005B7 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Client, valuetype [OpenRA.Game]OpenRA.Primitives.Color>::.ctor
        // IL_00C0: dup 
        // IL_00C1: stsfld 0x040021F2 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__80_2
        // IL_00C6: call 0x2B0000F4 [System.Linq]System.Linq.Enumerable::Select<class [OpenRA.Game]OpenRA.Network.Session/Client, valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_00CB: ldloc.0 0
        // IL_00CC: ldfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_00D1: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_00D6: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
        // IL_00DB: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
        // IL_00E0: callvirt 0x0A0005B8 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Values
        // IL_00E5: ldsfld 0x040021F3 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__80_3
        // IL_00EA: dup 
        // IL_00EB: brtrue.s IL_0104
        // IL_00ED: pop 
        // IL_00EE: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_00F3: ldftn 0x06002951 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<SanitizePlayerColor>b__80_3
        // IL_00F9: newobj 0x0A0005B9 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.PlayerReference, valuetype [OpenRA.Game]OpenRA.Primitives.Color>::.ctor
        // IL_00FE: dup 
        // IL_00FF: stsfld 0x040021F3 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__80_3
        // IL_0104: call 0x2B0000F5 [System.Linq]System.Linq.Enumerable::Select<class [OpenRA.Game]OpenRA.PlayerReference, valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_0109: call 0x2B0000F6 [System.Linq]System.Linq.Enumerable::Concat<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_010E: call 0x2B0000F3 [System.Linq]System.Linq.Enumerable::ToList<valuetype [OpenRA.Game]OpenRA.Primitives.Color>
        // IL_0113: stloc.s 6
        // IL_0115: ldloc.3 3
        // IL_0116: ldloc.s 4
        // IL_0118: ldloc.0 0
        // IL_0119: ldfld 0x04002217 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::server
        // IL_011E: ldfld 0x0A0005BA [OpenRA.Game]OpenRA.Server.Server::Random
        // IL_0123: ldloc.s 5
        // IL_0125: ldloc.s 6
        // IL_0127: ldloc.0 0
        // IL_0128: ldftn 0x06002983 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::<SanitizePlayerColor>g__OnError|0
        // IL_012E: newobj 0x0A00030B class [System.Runtime]System.Action`1<string>::.ctor
        // IL_0133: callvirt 0x06001F8A OpenRA.Mods.Common.Traits.IColorPickerManagerInfo::MakeValid
        // IL_0138: stloc.s 7
        // IL_013A: leave.s IL_0146
        // IL_013C: ldloc.2 2
        // IL_013D: brfalse.s IL_0145
        // IL_013F: ldloc.1 1
        // IL_0140: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0145: endfinally 
        // IL_0146: ldloc.s 7
        // IL_0148: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 41, try_length: 275, handler_offset: 316, handler_length: 10, raw_flags: 2 }
        // .try IL_0029..IL_013C finally IL_013C..IL_0146
    }

    public static string SanitizePlayerFaction(OpenRA.Server.Server server, string askedFaction, System.Collections.Generic.IEnumerable<string> validFactions)
    {
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v2 = __cil_bool_load(__cil_methodspec_call_2B000054(validFactions, askedFaction));
        if (!(v2 == 0)) {
            return askedFaction;
        }
        string v4 = __cil_ldstr_7000D637("Random");
        return v4;
    }

    private static string MissionBriefingOrDefault(OpenRA.Server.Server server)
    {
        OpenRA.Mods.Common.Traits.MissionDataInfo l0 = default;
        __cil_type_010000EE v1 = server.Map;
        __cil_type_01000108 v2 = ((OpenRA.MapPreview)v1).WorldActorInfo;
        global::OpenRA.Mods.Common.Traits.MissionDataInfo v3 = __cil_callvirt_2B00010D(v2);
        l0 = v3;
        global::OpenRA.Mods.Common.Traits.MissionDataInfo v4 = l0;
        if (v4 is null) {
            return null;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        global::OpenRA.Mods.Common.Traits.MissionDataInfo v5 = l0;
        string v6 = v5.Briefing;
        int v7 = __cil_bool_load(System.String.IsNullOrEmpty(v6));
        if (v7 != 0) {
            return null;
        } else {
            goto IL_0021;
        }
        IL_0021: ;
        global::OpenRA.Mods.Common.Traits.MissionDataInfo v8 = l0;
        string v9 = v8.Briefing;
        string v10 = __cil_ldstr_700026F0("\\n");
        string v11 = __cil_ldstr_70001905("\u000A");
        string v12 = v9.Replace(v10, v11);
        return v12;
    }

    public virtual void ClientJoined(OpenRA.Server.Server server, OpenRA.Server.Connection conn)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [03, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 03, 7B, BC, 05, 00, 0A, 2C]
        // .code-bytes IL_0018: [17, 03, 04, 72, 9F, DF, 00, 70, 03, 7B, BC, 05, 00, 0A, 28, 82, 01, 00, 0A, 6F, 92, 05, 00, 0A]
        // .code-bytes IL_0030: [03, 04, 6F, DC, 05, 00, 0A, 0C, 08, 7B, 96, 05, 00, 0A, 2C, 36, 03, 7B, 72, 05, 00, 0A, 7B, 74]
        // .code-bytes IL_0048: [05, 00, 0A, 08, 7B, 96, 05, 00, 0A, 6F, 97, 05, 00, 0A, 7B, 9E, 05, 00, 0A, 2D, 19, 08, 03, 08]
        // .code-bytes IL_0060: [7B, 9F, 05, 00, 0A, 08, 7B, A0, 05, 00, 0A, 14, 28, 43, 03, 00, 06, 7D, 9F, 05, 00, 0A, 03, 28]
        // .code-bytes IL_0078: [45, 03, 00, 06, 0D, 09, 2C, 0D, 03, 04, 72, FD, D3, 00, 70, 09, 6F, 92, 05, 00, 0A, DE, 0A, 07]
        // .code-bytes IL_0090: [2C, 06, 06, 28, 79, 05, 00, 0A, DC, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // .local [2] class [OpenRA.Game]OpenRA.Network.Session/Client
        // .local [3] string
        // IL_0000: ldarg.1 1
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.1 1
        // IL_0012: ldfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_0017: brfalse.s IL_0030
        // IL_0019: ldarg.1 1
        // IL_001A: ldarg.2 2
        // IL_001B: ldstr 0x7000DF9F [83, 121, 110, 99, 77, 97, 112, 80, 111, 111, 108] utf16-bytes=[53, 00, 79, 00, 6E, 00, 63, 00, 4D, 00, 61, 00, 70, 00, 50, 00, 6F, 00, 6F, 00, 6C, 00] terminal-flag=Some(0)
        // IL_0020: ldarg.1 1
        // IL_0021: ldfld 0x0A0005BC [OpenRA.Game]OpenRA.Server.Server::MapPool
        // IL_0026: call 0x0A000182 [OpenRA.Game]OpenRA.FieldSaver::FormatValue
        // IL_002B: callvirt 0x0A000592 [OpenRA.Game]OpenRA.Server.Server::SendOrderTo
        // IL_0030: ldarg.1 1
        // IL_0031: ldarg.2 2
        // IL_0032: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
        // IL_0037: stloc.2 2
        // IL_0038: ldloc.2 2
        // IL_0039: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_003E: brfalse.s IL_0076
        // IL_0040: ldarg.1 1
        // IL_0041: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0046: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_004B: ldloc.2 2
        // IL_004C: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
        // IL_0051: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
        // IL_0056: ldfld 0x0A00059E [OpenRA.Game]OpenRA.Network.Session/Slot::LockColor
        // IL_005B: brtrue.s IL_0076
        // IL_005D: ldloc.2 2
        // IL_005E: ldarg.1 1
        // IL_005F: ldloc.2 2
        // IL_0060: ldfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_0065: ldloc.2 2
        // IL_0066: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
        // IL_006B: ldnull 
        // IL_006C: call 0x06000343 OpenRA.Mods.Common.Server.LobbyCommands::SanitizePlayerColor
        // IL_0071: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
        // IL_0076: ldarg.1 1
        // IL_0077: call 0x06000345 OpenRA.Mods.Common.Server.LobbyCommands::MissionBriefingOrDefault
        // IL_007C: stloc.3 3
        // IL_007D: ldloc.3 3
        // IL_007E: brfalse.s IL_008D
        // IL_0080: ldarg.1 1
        // IL_0081: ldarg.2 2
        // IL_0082: ldstr 0x7000D3FD [77, 101, 115, 115, 97, 103, 101] utf16-bytes=[4D, 00, 65, 00, 73, 00, 73, 00, 61, 00, 67, 00, 65, 00] terminal-flag=Some(0)
        // IL_0087: ldloc.3 3
        // IL_0088: callvirt 0x0A000592 [OpenRA.Game]OpenRA.Server.Server::SendOrderTo
        // IL_008D: leave.s IL_0099
        // IL_008F: ldloc.1 1
        // IL_0090: brfalse.s IL_0098
        // IL_0092: ldloc.0 0
        // IL_0093: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_0098: endfinally 
        // IL_0099: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 134, handler_offset: 143, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_008F finally IL_008F..IL_0099
    }

    private virtual void __name_4F70656E52412E5365727665722E494E6F74696679536572766572456D7074792E536572766572456D707479(OpenRA.Server.Server server)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [03, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73, 05, 00, 0A, 03, 7B, E0, 05, 00, 0A, 6F]
        // .code-bytes IL_0018: [17, 06, 00, 0A, 03, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 17, 7D, A2, 05, 00, 0A, 03, 7B, 72]
        // .code-bytes IL_0030: [05, 00, 0A, 03, 7B, 86, 05, 00, 0A, 6F, 9A, 05, 00, 0A, 7B, 9B, 05, 00, 0A, 7E, F4, 21, 00, 04]
        // .code-bytes IL_0048: [25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 52, 29, 00, 06, 73, 03, 06, 00, 0A, 25, 80, F4, 21]
        // .code-bytes IL_0060: [00, 04, 28, 0A, 01, 00, 2B, 7E, F5, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 53]
        // .code-bytes IL_0078: [29, 00, 06, 73, 04, 06, 00, 0A, 25, 80, F5, 21, 00, 04, 28, 0B, 01, 00, 2B, 7E, F6, 21, 00, 04]
        // .code-bytes IL_0090: [25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 54, 29, 00, 06, 73, 05, 06, 00, 0A, 25, 80, F6, 21]
        // .code-bytes IL_00A8: [00, 04, 7E, F7, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 55, 29, 00, 06, 73, 06]
        // .code-bytes IL_00C0: [06, 00, 0A, 25, 80, F7, 21, 00, 04, 28, 0C, 01, 00, 2B, 7D, 74, 05, 00, 0A, DE, 0A, 07, 2C, 06]
        // .code-bytes IL_00D8: [06, 28, 79, 05, 00, 0A, DC, 2A]
        // .local [0] class [OpenRA.Game]OpenRA.Network.Session
        // .local [1] bool
        // IL_0000: ldarg.1 1
        // IL_0001: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0006: stloc.0 0
        // IL_0007: ldc.i4.0 0
        // IL_0008: stloc.1 1
        // IL_0009: ldloc.0 0
        // IL_000A: ldloca.s 1
        // IL_000C: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
        // IL_0011: ldarg.1 1
        // IL_0012: ldfld 0x0A0005E0 [OpenRA.Game]OpenRA.Server.Server::TempBans
        // IL_0017: callvirt 0x0A000617 class [System.Collections]System.Collections.Generic.List`1<string>::Clear
        // IL_001C: ldarg.1 1
        // IL_001D: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0022: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
        // IL_0027: ldc.i4.1 1
        // IL_0028: stfld 0x0A0005A2 [OpenRA.Game]OpenRA.Network.Session/Global::AllowSpectators
        // IL_002D: ldarg.1 1
        // IL_002E: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
        // IL_0033: ldarg.1 1
        // IL_0034: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_0039: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
        // IL_003E: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
        // IL_0043: ldsfld 0x040021F4 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_0
        // IL_0048: dup 
        // IL_0049: brtrue.s IL_0062
        // IL_004B: pop 
        // IL_004C: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0051: ldftn 0x06002952 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<OpenRA.Server.INotifyServerEmpty.ServerEmpty>b__84_0
        // IL_0057: newobj 0x0A000603 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, class [OpenRA.Game]OpenRA.Network.Session/Slot>::.ctor
        // IL_005C: dup 
        // IL_005D: stsfld 0x040021F4 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_0
        // IL_0062: call 0x2B00010A [System.Linq]System.Linq.Enumerable::Select<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, class [OpenRA.Game]OpenRA.Network.Session/Slot>
        // IL_0067: ldsfld 0x040021F5 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_1
        // IL_006C: dup 
        // IL_006D: brtrue.s IL_0086
        // IL_006F: pop 
        // IL_0070: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0075: ldftn 0x06002953 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<OpenRA.Server.INotifyServerEmpty.ServerEmpty>b__84_1
        // IL_007B: newobj 0x0A000604 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, bool>::.ctor
        // IL_0080: dup 
        // IL_0081: stsfld 0x040021F5 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_1
        // IL_0086: call 0x2B00010B [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.Network.Session/Slot>
        // IL_008B: ldsfld 0x040021F6 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_2
        // IL_0090: dup 
        // IL_0091: brtrue.s IL_00AA
        // IL_0093: pop 
        // IL_0094: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_0099: ldftn 0x06002954 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<OpenRA.Server.INotifyServerEmpty.ServerEmpty>b__84_2
        // IL_009F: newobj 0x0A000605 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, string>::.ctor
        // IL_00A4: dup 
        // IL_00A5: stsfld 0x040021F6 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_2
        // IL_00AA: ldsfld 0x040021F7 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_3
        // IL_00AF: dup 
        // IL_00B0: brtrue.s IL_00C9
        // IL_00B2: pop 
        // IL_00B3: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
        // IL_00B8: ldftn 0x06002955 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<OpenRA.Server.INotifyServerEmpty.ServerEmpty>b__84_3
        // IL_00BE: newobj 0x0A000606 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, class [OpenRA.Game]OpenRA.Network.Session/Slot>::.ctor
        // IL_00C3: dup 
        // IL_00C4: stsfld 0x040021F7 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__84_3
        // IL_00C9: call 0x2B00010C [System.Linq]System.Linq.Enumerable::ToDictionary<class [OpenRA.Game]OpenRA.Network.Session/Slot, string, class [OpenRA.Game]OpenRA.Network.Session/Slot>
        // IL_00CE: stfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
        // IL_00D3: leave.s IL_00DF
        // IL_00D5: ldloc.1 1
        // IL_00D6: brfalse.s IL_00DE
        // IL_00D8: ldloc.0 0
        // IL_00D9: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
        // IL_00DE: endfinally 
        // IL_00DF: ret 
        // .eh-raw ExceptionHandler { kind: Finally, try_offset: 9, try_length: 204, handler_offset: 213, handler_length: 10, raw_flags: 2 }
        // .try IL_0009..IL_00D5 finally IL_00D5..IL_00DF
    }

    public static OpenRA.PlayerReference PlayerReferenceForSlot(OpenRA.Server.Server server, OpenRA.Network.Session.Slot slot)
    {
        // IL fallback: nested/generic/unresolved external class needs IL fallback
        // .maxstack 8
        // .initlocals false
        // .code-bytes IL_0000: [03, 2D, 02, 14, 2A, 02, 7B, 86, 05, 00, 0A, 6F, 9A, 05, 00, 0A, 7B, 9B, 05, 00, 0A, 03, 7B, 0A]
        // .code-bytes IL_0018: [06, 00, 0A, 6F, 9C, 05, 00, 0A, 2A]
        // IL_0000: ldarg.1 1
        // IL_0001: brtrue.s IL_0005
        // IL_0003: ldnull 
        // IL_0004: ret 
        // IL_0005: ldarg.0 0
        // IL_0006: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
        // IL_000B: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
        // IL_0010: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
        // IL_0015: ldarg.1 1
        // IL_0016: ldfld 0x0A00060A [OpenRA.Game]OpenRA.Network.Session/Slot::PlayerReference
        // IL_001B: callvirt 0x0A00059C class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Item
        // IL_0020: ret 
    }

    public LobbyCommands()
    {
        // structural signature __cil_ref_60dc616c6864b639d0a2c165b44892c02f22fe64 bytes=15128189020E151283A1051283851283A51283A90E02: class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [System.Runtime]System.Func`5<class [OpenRA.Game]OpenRA.Server.Server, class [OpenRA.Game]OpenRA.Server.Connection, class [OpenRA.Game]OpenRA.Network.Session/Client, string, bool>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f bytes=151283A1051283851283A51283A90E02: class [System.Runtime]System.Func`5<class [OpenRA.Game]OpenRA.Server.Server, class [OpenRA.Game]OpenRA.Server.Connection, class [OpenRA.Game]OpenRA.Network.Session/Client, string, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_6d020990bd5293aa283bef59acfe6c02342d75c0 bytes=1512839D020E151283A1051283851283A51283A90E02: class [System.Runtime]System.Collections.Generic.IDictionary`2<string, class [System.Runtime]System.Func`5<class [OpenRA.Game]OpenRA.Server.Server, class [OpenRA.Game]OpenRA.Server.Connection, class [OpenRA.Game]OpenRA.Network.Session/Client, string, bool>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_60dc616c6864b639d0a2c165b44892c02f22fe64 v1 = __cil_newobj_0A000618();
        string v3 = __cil_ldstr_70000931("state");
        nint v4 = __cil_ldftn_06000325;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v5 = __cil_newobj_0A000619(null, v4);
        __cil_callvirt_0A00061A(v1, v3, v5);
        string v7 = __cil_ldstr_7000D2AD("startgame");
        nint v8 = __cil_ldftn_06000326;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v9 = __cil_newobj_0A000619(null, v8);
        __cil_callvirt_0A00061A(v1, v7, v9);
        string v11 = __cil_ldstr_7000DFB7("slot");
        nint v12 = __cil_ldftn_06000327;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v13 = __cil_newobj_0A000619(null, v12);
        __cil_callvirt_0A00061A(v1, v11, v13);
        string v15 = __cil_ldstr_7000DFC1("allow_spectators");
        nint v16 = __cil_ldftn_06000328;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v17 = __cil_newobj_0A000619(null, v16);
        __cil_callvirt_0A00061A(v1, v15, v17);
        string v19 = __cil_ldstr_7000DFE3("spectate");
        nint v20 = __cil_ldftn_06000329;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v21 = __cil_newobj_0A000619(null, v20);
        __cil_callvirt_0A00061A(v1, v19, v21);
        string v23 = __cil_ldstr_7000DFF5("slot_close");
        nint v24 = __cil_ldftn_0600032A;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v25 = __cil_newobj_0A000619(null, v24);
        __cil_callvirt_0A00061A(v1, v23, v25);
        string v27 = __cil_ldstr_7000E00B("slot_open");
        nint v28 = __cil_ldftn_0600032B;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v29 = __cil_newobj_0A000619(null, v28);
        __cil_callvirt_0A00061A(v1, v27, v29);
        string v31 = __cil_ldstr_7000D561("slot_bot");
        nint v32 = __cil_ldftn_0600032C;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v33 = __cil_newobj_0A000619(null, v32);
        __cil_callvirt_0A00061A(v1, v31, v33);
        string v35 = __cil_ldstr_7000E01F("map");
        nint v36 = __cil_ldftn_0600032D;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v37 = __cil_newobj_0A000619(null, v36);
        __cil_callvirt_0A00061A(v1, v35, v37);
        string v39 = __cil_ldstr_7000D793("option");
        nint v40 = __cil_ldftn_0600032E;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v41 = __cil_newobj_0A000619(null, v40);
        __cil_callvirt_0A00061A(v1, v39, v41);
        string v43 = __cil_ldstr_7000E027("reset_options");
        nint v44 = __cil_ldftn_0600032F;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v45 = __cil_newobj_0A000619(null, v44);
        __cil_callvirt_0A00061A(v1, v43, v45);
        string v47 = __cil_ldstr_7000E043("assignteams");
        nint v48 = __cil_ldftn_06000330;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v49 = __cil_newobj_0A000619(null, v48);
        __cil_callvirt_0A00061A(v1, v47, v49);
        string v51 = __cil_ldstr_7000D88F("kick");
        nint v52 = __cil_ldftn_06000331;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v53 = __cil_newobj_0A000619(null, v52);
        __cil_callvirt_0A00061A(v1, v51, v53);
        string v55 = __cil_ldstr_7000DA43("vote_kick");
        nint v56 = __cil_ldftn_06000332;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v57 = __cil_newobj_0A000619(null, v56);
        __cil_callvirt_0A00061A(v1, v55, v57);
        string v59 = __cil_ldstr_7000E05B("make_admin");
        nint v60 = __cil_ldftn_06000334;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v61 = __cil_newobj_0A000619(null, v60);
        __cil_callvirt_0A00061A(v1, v59, v61);
        string v63 = __cil_ldstr_7000E071("make_spectator");
        nint v64 = __cil_ldftn_06000335;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v65 = __cil_newobj_0A000619(null, v64);
        __cil_callvirt_0A00061A(v1, v63, v65);
        string v67 = __cil_ldstr_7000D7D9("name");
        nint v68 = __cil_ldftn_06000336;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v69 = __cil_newobj_0A000619(null, v68);
        __cil_callvirt_0A00061A(v1, v67, v69);
        string v71 = __cil_ldstr_7000DCEB("faction");
        nint v72 = __cil_ldftn_06000337;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v73 = __cil_newobj_0A000619(null, v72);
        __cil_callvirt_0A00061A(v1, v71, v73);
        string v75 = __cil_ldstr_7000E08F("team");
        nint v76 = __cil_ldftn_06000338;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v77 = __cil_newobj_0A000619(null, v76);
        __cil_callvirt_0A00061A(v1, v75, v77);
        string v79 = __cil_ldstr_7000E099("handicap");
        nint v80 = __cil_ldftn_06000339;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v81 = __cil_newobj_0A000619(null, v80);
        __cil_callvirt_0A00061A(v1, v79, v81);
        string v83 = __cil_ldstr_7000E0AB("spawn");
        nint v84 = __cil_ldftn_0600033B;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v85 = __cil_newobj_0A000619(null, v84);
        __cil_callvirt_0A00061A(v1, v83, v85);
        string v87 = __cil_ldstr_7000E0B7("clear_spawn");
        nint v88 = __cil_ldftn_0600033A;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v89 = __cil_newobj_0A000619(null, v88);
        __cil_callvirt_0A00061A(v1, v87, v89);
        string v91 = __cil_ldstr_70003A9D("color");
        nint v92 = __cil_ldftn_0600033C;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v93 = __cil_newobj_0A000619(null, v92);
        __cil_callvirt_0A00061A(v1, v91, v93);
        string v95 = __cil_ldstr_7000E0CF("sync_lobby");
        nint v96 = __cil_ldftn_0600033D;
        __cil_ref_affef7f2d4008f057ef6d2e0bfffc711118b199f v97 = __cil_newobj_0A000619(null, v96);
        __cil_callvirt_0A00061A(v1, v95, v97);
        this.commandHandlers = v1;
        __cil_ctor_call_0A00061B(this);
        return;
    }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E63 __il_field_040021D9;
        public static System.Func<OpenRA.Network.Session.Client, bool> __il_field_040021DA;
        public static System.Func<OpenRA.Network.Session.Client, bool> __il_field_040021DB;
        public static System.Predicate<OpenRA.Network.Session.Client> __il_field_040021DC;
        public static System.Func<OpenRA.Network.Session.Client, OpenRA.Primitives.Color> __il_field_040021DD;
        public static System.Func<OpenRA.PlayerReference, OpenRA.Primitives.Color> __il_field_040021DE;
        public static System.Func<System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference>, OpenRA.Network.Session.Slot> __il_field_040021DF;
        public static System.Func<OpenRA.Network.Session.Slot, bool> __il_field_040021E0;
        public static System.Func<OpenRA.Network.Session.Slot, string> __il_field_040021E1;
        public static System.Func<OpenRA.Network.Session.Slot, OpenRA.Network.Session.Slot> __il_field_040021E2;
        public static System.Func<OpenRA.Traits.FactionInfo, bool> __il_field_040021E3;
        public static System.Func<OpenRA.Traits.FactionInfo, string> __il_field_040021E4;
        public static System.Func<OpenRA.Traits.IBotInfo, string> __il_field_040021E5;
        public static System.Func<System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference>, bool> __il_field_040021E6;
        public static System.Func<System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference>, bool> __il_field_040021E7;
        public static System.Func<OpenRA.Network.Session.Client, bool> __il_field_040021E8;
        public static System.Func<OpenRA.Network.Session.Client, bool> __il_field_040021E9;
        public static System.Func<int, int> __il_field_040021EA;
        public static System.Func<System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot>, bool> __il_field_040021EB;
        public static System.Func<OpenRA.MapPreview, bool> __il_field_040021EC;
        public static System.Func<OpenRA.MapPreview, string> __il_field_040021ED;
        public static System.Func<System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference>, OpenRA.Network.Session.Slot> __il_field_040021EE;
        public static System.Func<OpenRA.Network.Session.Slot, bool> __il_field_040021EF;
        public static System.Func<OpenRA.Network.Session.Slot, string> __il_field_040021F0;
        public static System.Func<OpenRA.Network.Session.Slot, OpenRA.Network.Session.Slot> __il_field_040021F1;
        public static System.Func<OpenRA.Network.Session.Client, OpenRA.Primitives.Color> __il_field_040021F2;
        public static System.Func<OpenRA.PlayerReference, OpenRA.Primitives.Color> __il_field_040021F3;
        public static System.Func<System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference>, OpenRA.Network.Session.Slot> __il_field_040021F4;
        public static System.Func<OpenRA.Network.Session.Slot, bool> __il_field_040021F5;
        public static System.Func<OpenRA.Network.Session.Slot, string> __il_field_040021F6;
        public static System.Func<OpenRA.Network.Session.Slot, OpenRA.Network.Session.Slot> __il_field_040021F7;

        static __name_3C3E63()
        {
            global::OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E63 v0 = __cil_newobj_06002937();
            OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E63.__il_field_040021D9 = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <CheckAutoStart>b__49_0
        internal bool CheckAutoStartLambda49_0(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 7B, 05, 00, 0A, 18, FE, 01, 16, FE, 01, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
            // IL_0006: ldc.i4.2 2
            // IL_0007: ceq 
            // IL_0009: ldc.i4.0 0
            // IL_000A: ceq 
            // IL_000C: ret 
        }

        // Metadata name: <CheckAutoStart>b__49_1
        internal bool CheckAutoStartLambda49_1(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 77, 05, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A000577 [OpenRA.Game]OpenRA.Network.Session/Client::IsAdmin
            // IL_0006: ret 
        }

        // Metadata name: <CheckAutoStart>b__49_4
        internal bool CheckAutoStartLambda49_4(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, A0, 05, 00, 0A, 16, FE, 01, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_0006: ldc.i4.0 0
            // IL_0007: ceq 
            // IL_0009: ret 
        }

        // Metadata name: <SlotBot>b__57_1
        internal OpenRA.Primitives.Color SlotBotLambda57_1(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 9F, 05, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
            // IL_0006: ret 
        }

        // Metadata name: <SlotBot>b__57_2
        internal OpenRA.Primitives.Color SlotBotLambda57_2(OpenRA.PlayerReference p)
        {
            // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v1 = p.Color;
            return v1;
        }

        // Metadata name: <Map>b__58_2
        internal OpenRA.Network.Session.Slot MapLambda58_2(System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference> p)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [0F, 01, 28, 06, 17, 00, 0A, 28, 41, 03, 00, 06, 2A]
            // IL_0000: ldarga.s 1
            // IL_0002: call 0x0A001706 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Value
            // IL_0007: call 0x06000341 OpenRA.Mods.Common.Server.LobbyCommands::MakeSlotFromPlayerReference
            // IL_000C: ret 
        }

        // Metadata name: <Map>b__58_3
        internal bool MapLambda58_3(OpenRA.Network.Session.Slot ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 14, FE, 03, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldnull 
            // IL_0002: cgt.un 
            // IL_0004: ret 
        }

        // Metadata name: <Map>b__58_4
        internal string MapLambda58_4(OpenRA.Network.Session.Slot ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 0A, 06, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A00060A [OpenRA.Game]OpenRA.Network.Session/Slot::PlayerReference
            // IL_0006: ret 
        }

        // Metadata name: <Map>b__58_5
        internal OpenRA.Network.Session.Slot MapLambda58_5(OpenRA.Network.Session.Slot ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ret 
        }

        // Metadata name: <Map>b__58_6
        internal bool MapLambda58_6(OpenRA.Traits.FactionInfo f)
        {
            return f.Selectable;
        }

        // Metadata name: <Map>b__58_7
        internal string MapLambda58_7(OpenRA.Traits.FactionInfo f)
        {
            string v1 = f.InternalName;
            return v1;
        }

        // Metadata name: <Map>b__58_8
        internal string MapLambda58_8(OpenRA.Traits.IBotInfo t)
        {
            string v1 = __cil_callvirt_0A0000D4(t);
            return v1;
        }

        // Metadata name: <Map>b__58_9
        internal bool MapLambda58_9(System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference> p)
        {
            // structural signature __cil_value_607268c45a1f51609f93a77a424d8ec904fae9ba bytes=15118235020E1283C9: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_607268c45a1f51609f93a77a424d8ec904fae9ba v0 = ref p;
            __cil_type_010000F2 v1 = __cil_value_call_0A001706(ref v0);
            int v2 = __cil_bool_load(v1.Playable);
            return __cil_bool_store(v2);
        }

        // Metadata name: <Map>b__58_10
        internal bool MapLambda58_10(System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference> p)
        {
            // structural signature __cil_value_607268c45a1f51609f93a77a424d8ec904fae9ba bytes=15118235020E1283C9: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_607268c45a1f51609f93a77a424d8ec904fae9ba v0 = ref p;
            __cil_type_010000F2 v1 = __cil_value_call_0A001706(ref v0);
            int v2 = __cil_bool_load(v1.AllowBots);
            int v3 = 0;
            int v4 = (v2 == v3 ? 1 : 0);
            return __cil_bool_store(v4);
        }

        // Metadata name: <AssignTeams>b__61_0
        internal bool AssignTeamsLambda61_0(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 96, 05, 00, 0A, 14, FE, 03, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_0006: ldnull 
            // IL_0007: cgt.un 
            // IL_0009: ret 
        }

        // Metadata name: <MakeAdmin>b__65_2
        internal bool MakeAdminLambda65_2(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 2C, 0A, 03, 7B, A7, 05, 00, 0A, 14, FE, 03, 2A, 16, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: brfalse.s IL_000D
            // IL_0003: ldarg.1 1
            // IL_0004: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
            // IL_0009: ldnull 
            // IL_000A: cgt.un 
            // IL_000C: ret 
            // IL_000D: ldc.i4.0 0
            // IL_000E: ret 
        }

        // Metadata name: <Handicap>b__70_0
        internal int HandicapLambda70_0(int i)
        {
            return unchecked(5 * i);
        }

        // Metadata name: <Spawn>b__72_1
        internal bool SpawnLambda72_1(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [0F, 01, 28, 0A, 0F, 00, 0A, 7B, 98, 05, 00, 0A, 2A]
            // IL_0000: ldarga.s 1
            // IL_0002: call 0x0A000F0A valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Value
            // IL_0007: ldfld 0x0A000598 [OpenRA.Game]OpenRA.Network.Session/Slot::LockSpawn
            // IL_000C: ret 
        }

        // Metadata name: <InitializeMapPool>b__75_0
        internal bool InitializeMapPoolLambda75_0(OpenRA.MapPreview p)
        {
            // IL fallback: incompatible value/receiver types
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 6F, 89, 05, 00, 0A, 2D, 17, 03, 6F, 58, 09, 00, 0A, 8C, 6E, 01, 00, 01, 17, 8C, 6E, 01, 00]
            // .code-bytes IL_0018: [01, 28, 79, 09, 00, 0A, 2A, 16, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: callvirt 0x0A000589 [OpenRA.Game]OpenRA.MapPreview::get_Status
            // IL_0006: brtrue.s IL_001F
            // IL_0008: ldarg.1 1
            // IL_0009: callvirt 0x0A000958 [OpenRA.Game]OpenRA.MapPreview::get_Visibility
            // IL_000E: box 0x0100016E [OpenRA.Game]OpenRA.MapVisibility
            // IL_0013: ldc.i4.1 1
            // IL_0014: box 0x0100016E [OpenRA.Game]OpenRA.MapVisibility
            // IL_0019: call 0x0A000979 [System.Runtime]System.Enum::HasFlag
            // IL_001E: ret 
            // IL_001F: ldc.i4.0 0
            // IL_0020: ret 
        }

        // Metadata name: <InitializeMapPool>b__75_1
        internal string InitializeMapPoolLambda75_1(OpenRA.MapPreview p)
        {
            string v1 = p.Uid;
            return v1;
        }

        // Metadata name: <ServerStarted>b__77_0
        internal OpenRA.Network.Session.Slot ServerStartedLambda77_0(System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference> p)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [0F, 01, 28, 06, 17, 00, 0A, 28, 41, 03, 00, 06, 2A]
            // IL_0000: ldarga.s 1
            // IL_0002: call 0x0A001706 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Value
            // IL_0007: call 0x06000341 OpenRA.Mods.Common.Server.LobbyCommands::MakeSlotFromPlayerReference
            // IL_000C: ret 
        }

        // Metadata name: <ServerStarted>b__77_1
        internal bool ServerStartedLambda77_1(OpenRA.Network.Session.Slot s)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 14, FE, 03, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldnull 
            // IL_0002: cgt.un 
            // IL_0004: ret 
        }

        // Metadata name: <ServerStarted>b__77_2
        internal string ServerStartedLambda77_2(OpenRA.Network.Session.Slot s)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 0A, 06, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A00060A [OpenRA.Game]OpenRA.Network.Session/Slot::PlayerReference
            // IL_0006: ret 
        }

        // Metadata name: <ServerStarted>b__77_3
        internal OpenRA.Network.Session.Slot ServerStartedLambda77_3(OpenRA.Network.Session.Slot s)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ret 
        }

        // Metadata name: <SanitizePlayerColor>b__80_2
        internal OpenRA.Primitives.Color SanitizePlayerColorLambda80_2(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 9F, 05, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
            // IL_0006: ret 
        }

        // Metadata name: <SanitizePlayerColor>b__80_3
        internal OpenRA.Primitives.Color SanitizePlayerColorLambda80_3(OpenRA.PlayerReference p)
        {
            // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
            __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v1 = p.Color;
            return v1;
        }

        internal OpenRA.Network.Session.Slot __name_3C4F70656E52412E5365727665722E494E6F74696679536572766572456D7074792E536572766572456D7074793E625F5F38345F30(System.Collections.Generic.KeyValuePair<string, OpenRA.PlayerReference> p)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [0F, 01, 28, 06, 17, 00, 0A, 28, 41, 03, 00, 06, 2A]
            // IL_0000: ldarga.s 1
            // IL_0002: call 0x0A001706 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Value
            // IL_0007: call 0x06000341 OpenRA.Mods.Common.Server.LobbyCommands::MakeSlotFromPlayerReference
            // IL_000C: ret 
        }

        internal bool __name_3C4F70656E52412E5365727665722E494E6F74696679536572766572456D7074792E536572766572456D7074793E625F5F38345F31(OpenRA.Network.Session.Slot ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 14, FE, 03, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldnull 
            // IL_0002: cgt.un 
            // IL_0004: ret 
        }

        internal string __name_3C4F70656E52412E5365727665722E494E6F74696679536572766572456D7074792E536572766572456D7074793E625F5F38345F32(OpenRA.Network.Session.Slot ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 0A, 06, 00, 0A, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A00060A [OpenRA.Game]OpenRA.Network.Session/Slot::PlayerReference
            // IL_0006: ret 
        }

        internal OpenRA.Network.Session.Slot __name_3C4F70656E52412E5365727665722E494E6F74696679536572766572456D7074792E536572766572456D7074793E625F5F38345F33(OpenRA.Network.Session.Slot ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334395F30
    {
        public OpenRA.Server.Server server;

        public __name_3C3E635F5F446973706C6179436C61737334395F30() : base()
        {
            return;
        }

        // Metadata name: <CheckAutoStart>b__2
        internal bool CheckAutoStartLambda2(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> sl)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [0F, 01, 28, 0A, 0F, 00, 0A, 7B, 13, 06, 00, 0A, 2C, 1B, 02, 7B, F8, 21, 00, 04, 7B, 72, 05, 00]
            // .code-bytes IL_0018: [0A, 0F, 01, 28, 09, 0F, 00, 0A, 6F, 95, 05, 00, 0A, 14, FE, 01, 2A, 16, 2A]
            // IL_0000: ldarga.s 1
            // IL_0002: call 0x0A000F0A valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Value
            // IL_0007: ldfld 0x0A000613 [OpenRA.Game]OpenRA.Network.Session/Slot::Required
            // IL_000C: brfalse.s IL_0029
            // IL_000E: ldarg.0 0
            // IL_000F: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
            // IL_0014: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0019: ldarga.s 1
            // IL_001B: call 0x0A000F09 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Key
            // IL_0020: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
            // IL_0025: ldnull 
            // IL_0026: ceq 
            // IL_0028: ret 
            // IL_0029: ldc.i4.0 0
            // IL_002A: ret 
        }

        // Metadata name: <CheckAutoStart>b__3
        internal bool CheckAutoStartLambda3(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> sl)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, F8, 21, 00, 04, 7B, 72, 05, 00, 0A, 0F, 01, 28, 09, 0F, 00, 0A, 6F, 95, 05, 00, 0A, 14]
            // .code-bytes IL_0018: [FE, 01, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x040021F8 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass49_0::server
            // IL_0006: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_000B: ldarga.s 1
            // IL_000D: call 0x0A000F09 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Key
            // IL_0012: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
            // IL_0017: ldnull 
            // IL_0018: ceq 
            // IL_001A: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335315F30
    {
        public OpenRA.Server.Server server;

        public __name_3C3E635F5F446973706C6179436C61737335315F30() : base()
        {
            return;
        }

        // Metadata name: <StartGame>b__0
        internal bool StartGameLambda0(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> sl)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [0F, 01, 28, 0A, 0F, 00, 0A, 7B, 13, 06, 00, 0A, 2C, 1B, 02, 7B, F9, 21, 00, 04, 7B, 72, 05, 00]
            // .code-bytes IL_0018: [0A, 0F, 01, 28, 09, 0F, 00, 0A, 6F, 95, 05, 00, 0A, 14, FE, 01, 2A, 16, 2A]
            // IL_0000: ldarga.s 1
            // IL_0002: call 0x0A000F0A valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Value
            // IL_0007: ldfld 0x0A000613 [OpenRA.Game]OpenRA.Network.Session/Slot::Required
            // IL_000C: brfalse.s IL_0029
            // IL_000E: ldarg.0 0
            // IL_000F: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
            // IL_0014: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0019: ldarga.s 1
            // IL_001B: call 0x0A000F09 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Key
            // IL_0020: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
            // IL_0025: ldnull 
            // IL_0026: ceq 
            // IL_0028: ret 
            // IL_0029: ldc.i4.0 0
            // IL_002A: ret 
        }

        // Metadata name: <StartGame>b__1
        internal bool StartGameLambda1(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> sl)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, F9, 21, 00, 04, 7B, 72, 05, 00, 0A, 0F, 01, 28, 09, 0F, 00, 0A, 6F, 95, 05, 00, 0A, 14]
            // .code-bytes IL_0018: [FE, 01, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x040021F9 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass51_0::server
            // IL_0006: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_000B: ldarga.s 1
            // IL_000D: call 0x0A000F09 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Key
            // IL_0012: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
            // IL_0017: ldnull 
            // IL_0018: ceq 
            // IL_001A: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335355F30
    {
        public OpenRA.Network.Session.Client occupant;

        public __name_3C3E635F5F446973706C6179436C61737335355F30() : base()
        {
            return;
        }

        // Metadata name: <SlotClose>b__0
        internal bool SlotCloseLambda0(OpenRA.Server.Connection c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 94, 1A, 00, 0A, 02, 7B, FA, 21, 00, 04, 7B, A0, 05, 00, 0A, FE, 01, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A001A94 [OpenRA.Game]OpenRA.Server.Connection::PlayerIndex
            // IL_0006: ldarg.0 0
            // IL_0007: ldfld 0x040021FA OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass55_0::occupant
            // IL_000C: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_0011: ceq 
            // IL_0013: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335375F30
    {
        public string botType;

        public __name_3C3E635F5F446973706C6179436C61737335375F30() : base()
        {
            return;
        }

        // Metadata name: <SlotBot>b__0
        internal bool SlotBotLambda0(OpenRA.Traits.IBotInfo b)
        {
            string v1 = __cil_callvirt_0A0000D4(b);
            string v3 = this.botType;
            return System.String.op_Equality(v1, v3);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335385F30
    {
        public OpenRA.Server.Server server;
        public OpenRA.Server.Connection conn;
        public OpenRA.Network.Session.Client client;

        public __name_3C3E635F5F446973706C6179436C61737335385F30() : base()
        {
            return;
        }

        internal void __name_3C4D61703E675F5F51756572794661696C65647C30()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_010000E1 v1 = this.server;
            __cil_type_010000E9 v3 = this.conn;
            string v4 = __cil_ldstr_7002986B("notification-unknown-map");
            v1.SendFluentMessageTo(v3, v4, ((__cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff)(null)));
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335385F31
    {
        public string lastMap;
        public OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E635F5F446973706C6179436C61737335385F30 __il_field_04002200;

        public __name_3C3E635F5F446973706C6179436C61737335385F31() : base()
        {
            return;
        }

        internal void __name_3C4D61703E675F5F53656C6563744D61707C31(OpenRA.MapPreview map)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 6
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 0A, 16, 0B, 06, 12, 01, 28, 73]
            // .code-bytes IL_0018: [05, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A]
            // .code-bytes IL_0030: [7B, BD, 05, 00, 0A, 02, 7B, FF, 21, 00, 04, 28, F1, 02, 00, 0A, 2C, 05, DD, 6D, 06, 00, 00, 02]
            // .code-bytes IL_0048: [7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 03, 7B, 87, 05]
            // .code-bytes IL_0060: [00, 0A, 7D, BD, 05, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B]
            // .code-bytes IL_0078: [74, 05, 00, 0A, 6F, 95, 1A, 00, 0A, 28, 14, 00, 00, 2B, 0C, 02, 7B, 00, 22, 00, 04, 7B, FC, 21]
            // .code-bytes IL_0090: [00, 04, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 85, 05, 00, 0A, 7B, 21, 03, 00, 0A, 02]
            // .code-bytes IL_00A8: [7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 7B, BD, 05, 00]
            // .code-bytes IL_00C0: [0A, 6F, 88, 05, 00, 0A, 7D, 86, 05, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72]
            // .code-bytes IL_00D8: [05, 00, 0A, 7B, 81, 05, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 00, 06, 00, 0A]
            // .code-bytes IL_00F0: [02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 6F, 01, 06, 00, 0A, 7D, 02, 06]
            // .code-bytes IL_0108: [00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 02, 7B, 00, 22, 00, 04]
            // .code-bytes IL_0120: [7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 6F, 9A, 05, 00, 0A, 7B, 9B, 05, 00, 0A, 7E, DF, 21, 00]
            // .code-bytes IL_0138: [04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 3D, 29, 00, 06, 73, 03, 06, 00, 0A, 25, 80, DF]
            // .code-bytes IL_0150: [21, 00, 04, 28, 0A, 01, 00, 2B, 7E, E0, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06]
            // .code-bytes IL_0168: [3E, 29, 00, 06, 73, 04, 06, 00, 0A, 25, 80, E0, 21, 00, 04, 28, 0B, 01, 00, 2B, 7E, E1, 21, 00]
            // .code-bytes IL_0180: [04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 3F, 29, 00, 06, 73, 05, 06, 00, 0A, 25, 80, E1]
            // .code-bytes IL_0198: [21, 00, 04, 7E, E2, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 40, 29, 00, 06, 73]
            // .code-bytes IL_01B0: [06, 06, 00, 0A, 25, 80, E2, 21, 00, 04, 28, 0C, 01, 00, 2B, 7D, 74, 05, 00, 0A, 02, 7B, 00, 22]
            // .code-bytes IL_01C8: [00, 04, 7B, FC, 21, 00, 04, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B]
            // .code-bytes IL_01E0: [81, 05, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 28, 42, 03, 00]
            // .code-bytes IL_01F8: [06, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 6F, C2, 05, 00, 0A, 6F, 01]
            // .code-bytes IL_0210: [01, 00, 2B, 7E, E3, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 41, 29, 00, 06, 73]
            // .code-bytes IL_0228: [EB, 05, 00, 0A, 25, 80, E3, 21, 00, 04, 28, 12, 01, 00, 2B, 7E, E4, 21, 00, 04, 25, 2D, 17, 26]
            // .code-bytes IL_0240: [7E, D9, 21, 00, 04, FE, 06, 42, 29, 00, 06, 73, 42, 06, 00, 0A, 25, 80, E4, 21, 00, 04, 28, 13]
            // .code-bytes IL_0258: [01, 00, 2B, 28, B4, 00, 00, 2B, 0D, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00]
            // .code-bytes IL_0270: [0A, 7B, 80, 05, 00, 0A, 6F, 8B, 05, 00, 0A, 13, 08, 2B, 30, 12, 08, 28, 8C, 05, 00, 0A, 13, 09]
            // .code-bytes IL_0288: [11, 09, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 11, 09, 7B, B3, 05, 00, 0A, 09, 28, 44, 03]
            // .code-bytes IL_02A0: [00, 06, 7D, B3, 05, 00, 0A, 11, 09, 17, 7D, 7B, 05, 00, 0A, 12, 08, 28, 8D, 05, 00, 0A, 2D, C7]
            // .code-bytes IL_02B8: [DE, 0E, 12, 08, FE, 16, C5, 02, 00, 1B, 6F, 1A, 00, 00, 0A, DC, 02, 7B, 00, 22, 00, 04, 7B, FC]
            // .code-bytes IL_02D0: [21, 00, 04, 7B, 86, 05, 00, 0A, 6F, AE, 05, 00, 0A, 6F, F0, 00, 00, 2B, 7E, E5, 21, 00, 04, 25]
            // .code-bytes IL_02E8: [2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 43, 29, 00, 06, 73, 48, 06, 00, 0A, 25, 80, E5, 21, 00]
            // .code-bytes IL_0300: [04, 28, 17, 01, 00, 2B, 13, 04, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A]
            // .code-bytes IL_0318: [7B, 74, 05, 00, 0A, 6F, 95, 1A, 00, 0A, 28, 14, 00, 00, 2B, 13, 05, 16, 13, 06, 08, 13, 0A, 16]
            // .code-bytes IL_0330: [13, 0B, 38, 23, 01, 00, 00, 11, 0A, 11, 0B, 9A, 13, 0C, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00]
            // .code-bytes IL_0348: [04, 7B, 72, 05, 00, 0A, 11, 0C, 6F, 95, 05, 00, 0A, 13, 0D, 11, 0D, 39, F6, 00, 00, 00, 11, 0D]
            // .code-bytes IL_0360: [16, 7D, 99, 05, 00, 0A, 11, 0D, 11, 06, 11, 05, 8E, 69, 32, 03, 14, 2B, 0A, 11, 05, 11, 06, 25]
            // .code-bytes IL_0378: [17, 58, 13, 06, 9A, 7D, 96, 05, 00, 0A, 11, 0D, 7B, 96, 05, 00, 0A, 39, 92, 00, 00, 00, 11, 0D]
            // .code-bytes IL_0390: [7B, A7, 05, 00, 0A, 2C, 5A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 6F]
            // .code-bytes IL_03A8: [9A, 05, 00, 0A, 7B, 9B, 05, 00, 0A, 11, 0D, 7B, 96, 05, 00, 0A, 6F, 9C, 05, 00, 0A, 7B, 0B, 06]
            // .code-bytes IL_03C0: [00, 0A, 2C, 10, 11, 04, 11, 0D, 7B, A7, 05, 00, 0A, 28, 54, 00, 00, 2B, 2D, 1D, 02, 7B, 00, 22]
            // .code-bytes IL_03D8: [00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 11, 0D, 6F, A8, 05, 00, 0A]
            // .code-bytes IL_03F0: [26, 11, 0D, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 6F, 9A, 05, 00, 0A]
            // .code-bytes IL_0408: [7B, 9B, 05, 00, 0A, 11, 0D, 7B, 96, 05, 00, 0A, 6F, 9C, 05, 00, 0A, 28, 9D, 05, 00, 0A, 2B, 34]
            // .code-bytes IL_0420: [11, 0D, 7B, A7, 05, 00, 0A, 2C, 1F, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00]
            // .code-bytes IL_0438: [0A, 7B, 80, 05, 00, 0A, 11, 0D, 6F, A8, 05, 00, 0A, 26, 2B, 0C, 11, 0D, 28, BF, 02, 00, 0A, 7D]
            // .code-bytes IL_0450: [9F, 05, 00, 0A, 11, 0B, 17, 58, 13, 0B, 11, 0B, 11, 0A, 8E, 69, 3F, D2, FE, FF, FF, 02, 7B, 00]
            // .code-bytes IL_0468: [22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 80, 05, 00, 0A, 6F, 8B, 05, 00, 0A, 13]
            // .code-bytes IL_0480: [0E, 2B, 76, 12, 0E, 28, 8C, 05, 00, 0A, 13, 0F, 11, 0F, 7B, 96, 05, 00, 0A, 2C, 64, 02, 7B, 00]
            // .code-bytes IL_0498: [22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 11, 0F, 7B, 96, 05, 00]
            // .code-bytes IL_04B0: [0A, 6F, 97, 05, 00, 0A, 7B, 9E, 05, 00, 0A, 2D, 3C, 11, 0F, 11, 0F, 02, 7B, 00, 22, 00, 04, 7B]
            // .code-bytes IL_04C8: [FC, 21, 00, 04, 11, 0F, 7B, 9F, 05, 00, 0A, 11, 0F, 7B, A0, 05, 00, 0A, 02, 7B, 00, 22, 00, 04]
            // .code-bytes IL_04E0: [7B, FD, 21, 00, 04, 28, 43, 03, 00, 06, 25, 13, 10, 7D, A1, 05, 00, 0A, 11, 10, 7D, 9F, 05, 00]
            // .code-bytes IL_04F8: [0A, 12, 0E, 28, 8D, 05, 00, 0A, 2D, 81, DE, 0E, 12, 0E, FE, 16, C5, 02, 00, 1B, 6F, 1A, 00, 00]
            // .code-bytes IL_0510: [0A, DC, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, EF, 05, 00, 0A, 6F]
            // .code-bytes IL_0528: [D5, 07, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 6F, F2, 05, 00, 0A, 02, 7B, 00, 22]
            // .code-bytes IL_0540: [00, 04, 7B, FC, 21, 00, 04, 72, 9D, 98, 02, 70, 1A, 8D, 12, 00, 00, 01, 25, 16, 72, CF, 3A, 00]
            // .code-bytes IL_0558: [70, A2, 25, 17, 02, 7B, 00, 22, 00, 04, 7B, FE, 21, 00, 04, 7B, B2, 05, 00, 0A, A2, 25, 18, 72]
            // .code-bytes IL_0570: [1F, E0, 00, 70, A2, 25, 19, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 6F]
            // .code-bytes IL_0588: [3C, 09, 00, 0A, A2, 6F, D1, 05, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 72, 05]
            // .code-bytes IL_05A0: [00, 0A, 7B, 81, 05, 00, 0A, 7B, 02, 06, 00, 0A, 1E, 5F, 2C, 1A, 02, 7B, 00, 22, 00, 04, 7B, FC]
            // .code-bytes IL_05B8: [21, 00, 04, 72, CF, 98, 02, 70, 28, B5, 00, 00, 2B, 6F, D1, 05, 00, 0A, 02, 7B, 00, 22, 00, 04]
            // .code-bytes IL_05D0: [7B, FC, 21, 00, 04, 7B, 72, 05, 00, 0A, 7B, 81, 05, 00, 0A, 7B, 82, 05, 00, 0A, 2D, 1C, 02, 7B]
            // .code-bytes IL_05E8: [00, 22, 00, 04, 7B, FC, 21, 00, 04, 72, 59, D4, 00, 70, 28, B5, 00, 00, 2B, 6F, D1, 05, 00, 0A]
            // .code-bytes IL_0600: [2B, 7E, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 7B, 86, 05, 00, 0A, 6F, 9A, 05, 00, 0A, 7B]
            // .code-bytes IL_0618: [9B, 05, 00, 0A, 7E, E6, 21, 00, 04, 25, 2D, 17, 26, 7E, D9, 21, 00, 04, FE, 06, 44, 29, 00, 06]
            // .code-bytes IL_0630: [73, 62, 09, 00, 0A, 25, 80, E6, 21, 00, 04, 28, ED, 06, 00, 2B, 7E, E7, 21, 00, 04, 25, 2D, 17]
            // .code-bytes IL_0648: [26, 7E, D9, 21, 00, 04, FE, 06, 45, 29, 00, 06, 73, 62, 09, 00, 0A, 25, 80, E7, 21, 00, 04, 28]
            // .code-bytes IL_0660: [16, 08, 00, 2B, 2C, 1A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 72, 03, 99, 02, 70, 28, B5]
            // .code-bytes IL_0678: [00, 00, 2B, 6F, D1, 05, 00, 0A, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 28, 45, 03, 00, 06]
            // .code-bytes IL_0690: [13, 07, 11, 07, 2C, 12, 02, 7B, 00, 22, 00, 04, 7B, FC, 21, 00, 04, 11, 07, 6F, 96, 1A, 00, 0A]
            // .code-bytes IL_06A8: [DE, 0A, 07, 2C, 06, 06, 28, 79, 05, 00, 0A, DC, 2A]
            // .local [0] class [OpenRA.Game]OpenRA.Network.Session
            // .local [1] bool
            // .local [2] string[]
            // .local [3] class [System.Collections]System.Collections.Generic.List`1<string>
            // .local [4] class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>
            // .local [5] string[]
            // .local [6] int32
            // .local [7] string
            // .local [8] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
            // .local [9] class [OpenRA.Game]OpenRA.Network.Session/Client
            // .local [10] string[]
            // .local [11] int32
            // .local [12] string
            // .local [13] class [OpenRA.Game]OpenRA.Network.Session/Client
            // .local [14] valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
            // .local [15] class [OpenRA.Game]OpenRA.Network.Session/Client
            // .local [16] valuetype [OpenRA.Game]OpenRA.Primitives.Color
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0006: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_000B: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0010: stloc.0 0
            // IL_0011: ldc.i4.0 0
            // IL_0012: stloc.1 1
            // IL_0013: ldloc.0 0
            // IL_0014: ldloca.s 1
            // IL_0016: call 0x0A000573 [System.Threading]System.Threading.Monitor::Enter
            // IL_001B: ldarg.0 0
            // IL_001C: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0021: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0026: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_002B: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
            // IL_0030: ldfld 0x0A0005BD [OpenRA.Game]OpenRA.Network.Session/Global::Map
            // IL_0035: ldarg.0 0
            // IL_0036: ldfld 0x040021FF OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::lastMap
            // IL_003B: call 0x0A0002F1 [System.Runtime]System.String::op_Inequality
            // IL_0040: brfalse.s IL_0047
            // IL_0042: leave IL_06B4
            // IL_0047: ldarg.0 0
            // IL_0048: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_004D: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0052: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0057: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
            // IL_005C: ldarg.1 1
            // IL_005D: ldfld 0x0A000587 [OpenRA.Game]OpenRA.MapPreview::Uid
            // IL_0062: stfld 0x0A0005BD [OpenRA.Game]OpenRA.Network.Session/Global::Map
            // IL_0067: ldarg.0 0
            // IL_0068: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_006D: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0072: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0077: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
            // IL_007C: callvirt 0x0A001A95 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Keys
            // IL_0081: call 0x2B000014 [System.Linq]System.Linq.Enumerable::ToArray<string>
            // IL_0086: stloc.2 2
            // IL_0087: ldarg.0 0
            // IL_0088: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_008D: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0092: ldarg.0 0
            // IL_0093: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0098: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_009D: ldfld 0x0A000585 [OpenRA.Game]OpenRA.Server.Server::ModData
            // IL_00A2: ldfld 0x0A000321 [OpenRA.Game]OpenRA.ModData::MapCache
            // IL_00A7: ldarg.0 0
            // IL_00A8: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_00AD: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_00B2: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_00B7: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
            // IL_00BC: ldfld 0x0A0005BD [OpenRA.Game]OpenRA.Network.Session/Global::Map
            // IL_00C1: callvirt 0x0A000588 [OpenRA.Game]OpenRA.MapCache::get_Item
            // IL_00C6: stfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_00CB: ldarg.0 0
            // IL_00CC: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_00D1: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_00D6: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_00DB: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
            // IL_00E0: ldarg.0 0
            // IL_00E1: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_00E6: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_00EB: ldfld 0x0A000600 [OpenRA.Game]OpenRA.Server.Server::MapStatusCache
            // IL_00F0: ldarg.0 0
            // IL_00F1: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_00F6: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_00FB: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_0100: callvirt 0x0A000601 [OpenRA.Game]OpenRA.Server.MapStatusCache::get_Item
            // IL_0105: stfld 0x0A000602 [OpenRA.Game]OpenRA.Network.Session/Global::MapStatus
            // IL_010A: ldarg.0 0
            // IL_010B: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0110: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0115: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_011A: ldarg.0 0
            // IL_011B: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0120: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0125: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_012A: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
            // IL_012F: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
            // IL_0134: ldsfld 0x040021DF OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_2
            // IL_0139: dup 
            // IL_013A: brtrue.s IL_0153
            // IL_013C: pop 
            // IL_013D: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_0142: ldftn 0x0600293D OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_2
            // IL_0148: newobj 0x0A000603 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, class [OpenRA.Game]OpenRA.Network.Session/Slot>::.ctor
            // IL_014D: dup 
            // IL_014E: stsfld 0x040021DF OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_2
            // IL_0153: call 0x2B00010A [System.Linq]System.Linq.Enumerable::Select<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, class [OpenRA.Game]OpenRA.Network.Session/Slot>
            // IL_0158: ldsfld 0x040021E0 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_3
            // IL_015D: dup 
            // IL_015E: brtrue.s IL_0177
            // IL_0160: pop 
            // IL_0161: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_0166: ldftn 0x0600293E OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_3
            // IL_016C: newobj 0x0A000604 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, bool>::.ctor
            // IL_0171: dup 
            // IL_0172: stsfld 0x040021E0 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_3
            // IL_0177: call 0x2B00010B [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.Network.Session/Slot>
            // IL_017C: ldsfld 0x040021E1 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_4
            // IL_0181: dup 
            // IL_0182: brtrue.s IL_019B
            // IL_0184: pop 
            // IL_0185: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_018A: ldftn 0x0600293F OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_4
            // IL_0190: newobj 0x0A000605 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, string>::.ctor
            // IL_0195: dup 
            // IL_0196: stsfld 0x040021E1 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_4
            // IL_019B: ldsfld 0x040021E2 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_5
            // IL_01A0: dup 
            // IL_01A1: brtrue.s IL_01BA
            // IL_01A3: pop 
            // IL_01A4: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_01A9: ldftn 0x06002940 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_5
            // IL_01AF: newobj 0x0A000606 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Network.Session/Slot, class [OpenRA.Game]OpenRA.Network.Session/Slot>::.ctor
            // IL_01B4: dup 
            // IL_01B5: stsfld 0x040021E2 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_5
            // IL_01BA: call 0x2B00010C [System.Linq]System.Linq.Enumerable::ToDictionary<class [OpenRA.Game]OpenRA.Network.Session/Slot, string, class [OpenRA.Game]OpenRA.Network.Session/Slot>
            // IL_01BF: stfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
            // IL_01C4: ldarg.0 0
            // IL_01C5: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_01CA: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_01CF: ldarg.0 0
            // IL_01D0: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_01D5: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_01DA: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_01DF: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
            // IL_01E4: ldarg.0 0
            // IL_01E5: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_01EA: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_01EF: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_01F4: call 0x06000342 OpenRA.Mods.Common.Server.LobbyCommands::LoadMapSettings
            // IL_01F9: ldarg.0 0
            // IL_01FA: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_01FF: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0204: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_0209: callvirt 0x0A0005C2 [OpenRA.Game]OpenRA.MapPreview::get_WorldActorInfo
            // IL_020E: callvirt 0x2B000101 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.FactionInfo>
            // IL_0213: ldsfld 0x040021E3 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_6
            // IL_0218: dup 
            // IL_0219: brtrue.s IL_0232
            // IL_021B: pop 
            // IL_021C: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_0221: ldftn 0x06002941 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_6
            // IL_0227: newobj 0x0A0005EB class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.FactionInfo, bool>::.ctor
            // IL_022C: dup 
            // IL_022D: stsfld 0x040021E3 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_6
            // IL_0232: call 0x2B000112 [System.Linq]System.Linq.Enumerable::Where<class [OpenRA.Game]OpenRA.Traits.FactionInfo>
            // IL_0237: ldsfld 0x040021E4 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_7
            // IL_023C: dup 
            // IL_023D: brtrue.s IL_0256
            // IL_023F: pop 
            // IL_0240: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_0245: ldftn 0x06002942 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_7
            // IL_024B: newobj 0x0A000642 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.FactionInfo, string>::.ctor
            // IL_0250: dup 
            // IL_0251: stsfld 0x040021E4 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_7
            // IL_0256: call 0x2B000113 [System.Linq]System.Linq.Enumerable::Select<class [OpenRA.Game]OpenRA.Traits.FactionInfo, string>
            // IL_025B: call 0x2B0000B4 [System.Linq]System.Linq.Enumerable::ToList<string>
            // IL_0260: stloc.3 3
            // IL_0261: ldarg.0 0
            // IL_0262: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0267: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_026C: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0271: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
            // IL_0276: callvirt 0x0A00058B class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::GetEnumerator
            // IL_027B: stloc.s 8
            // IL_027D: br.s IL_02AF
            // IL_027F: ldloca.s 8
            // IL_0281: call 0x0A00058C valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Current
            // IL_0286: stloc.s 9
            // IL_0288: ldloc.s 9
            // IL_028A: ldarg.0 0
            // IL_028B: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0290: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0295: ldloc.s 9
            // IL_0297: ldfld 0x0A0005B3 [OpenRA.Game]OpenRA.Network.Session/Client::Faction
            // IL_029C: ldloc.3 3
            // IL_029D: call 0x06000344 OpenRA.Mods.Common.Server.LobbyCommands::SanitizePlayerFaction
            // IL_02A2: stfld 0x0A0005B3 [OpenRA.Game]OpenRA.Network.Session/Client::Faction
            // IL_02A7: ldloc.s 9
            // IL_02A9: ldc.i4.1 1
            // IL_02AA: stfld 0x0A00057B [OpenRA.Game]OpenRA.Network.Session/Client::State
            // IL_02AF: ldloca.s 8
            // IL_02B1: call 0x0A00058D valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::MoveNext
            // IL_02B6: brtrue.s IL_027F
            // IL_02B8: leave.s IL_02C8
            // IL_02BA: ldloca.s 8
            // IL_02BC: constrained. 0x1B0002C5 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
            // IL_02C2: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
            // IL_02C7: endfinally 
            // IL_02C8: ldarg.0 0
            // IL_02C9: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_02CE: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_02D3: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_02D8: callvirt 0x0A0005AE [OpenRA.Game]OpenRA.MapPreview::get_PlayerActorInfo
            // IL_02DD: callvirt 0x2B0000F0 [OpenRA.Game]OpenRA.ActorInfo::TraitInfos<class [OpenRA.Game]OpenRA.Traits.IBotInfo>
            // IL_02E2: ldsfld 0x040021E5 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_8
            // IL_02E7: dup 
            // IL_02E8: brtrue.s IL_0301
            // IL_02EA: pop 
            // IL_02EB: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_02F0: ldftn 0x06002943 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_8
            // IL_02F6: newobj 0x0A000648 class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Traits.IBotInfo, string>::.ctor
            // IL_02FB: dup 
            // IL_02FC: stsfld 0x040021E5 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_8
            // IL_0301: call 0x2B000117 [System.Linq]System.Linq.Enumerable::Select<class [OpenRA.Game]OpenRA.Traits.IBotInfo, string>
            // IL_0306: stloc.s 4
            // IL_0308: ldarg.0 0
            // IL_0309: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_030E: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0313: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0318: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
            // IL_031D: callvirt 0x0A001A95 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Keys
            // IL_0322: call 0x2B000014 [System.Linq]System.Linq.Enumerable::ToArray<string>
            // IL_0327: stloc.s 5
            // IL_0329: ldc.i4.0 0
            // IL_032A: stloc.s 6
            // IL_032C: ldloc.2 2
            // IL_032D: stloc.s 10
            // IL_032F: ldc.i4.0 0
            // IL_0330: stloc.s 11
            // IL_0332: br IL_045A
            // IL_0337: ldloc.s 10
            // IL_0339: ldloc.s 11
            // IL_033B: ldelem.ref 
            // IL_033C: stloc.s 12
            // IL_033E: ldarg.0 0
            // IL_033F: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0344: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0349: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_034E: ldloc.s 12
            // IL_0350: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
            // IL_0355: stloc.s 13
            // IL_0357: ldloc.s 13
            // IL_0359: brfalse IL_0454
            // IL_035E: ldloc.s 13
            // IL_0360: ldc.i4.0 0
            // IL_0361: stfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
            // IL_0366: ldloc.s 13
            // IL_0368: ldloc.s 6
            // IL_036A: ldloc.s 5
            // IL_036C: ldlen 
            // IL_036D: conv.i4 
            // IL_036E: blt.s IL_0373
            // IL_0370: ldnull 
            // IL_0371: br.s IL_037D
            // IL_0373: ldloc.s 5
            // IL_0375: ldloc.s 6
            // IL_0377: dup 
            // IL_0378: ldc.i4.1 1
            // IL_0379: add 
            // IL_037A: stloc.s 6
            // IL_037C: ldelem.ref 
            // IL_037D: stfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_0382: ldloc.s 13
            // IL_0384: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_0389: brfalse IL_0420
            // IL_038E: ldloc.s 13
            // IL_0390: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
            // IL_0395: brfalse.s IL_03F1
            // IL_0397: ldarg.0 0
            // IL_0398: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_039D: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_03A2: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_03A7: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
            // IL_03AC: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
            // IL_03B1: ldloc.s 13
            // IL_03B3: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_03B8: callvirt 0x0A00059C class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Item
            // IL_03BD: ldfld 0x0A00060B [OpenRA.Game]OpenRA.PlayerReference::AllowBots
            // IL_03C2: brfalse.s IL_03D4
            // IL_03C4: ldloc.s 4
            // IL_03C6: ldloc.s 13
            // IL_03C8: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
            // IL_03CD: call 0x2B000054 [System.Linq]System.Linq.Enumerable::Contains<string>
            // IL_03D2: brtrue.s IL_03F1
            // IL_03D4: ldarg.0 0
            // IL_03D5: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_03DA: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_03DF: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_03E4: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
            // IL_03E9: ldloc.s 13
            // IL_03EB: callvirt 0x0A0005A8 class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::Remove
            // IL_03F0: pop 
            // IL_03F1: ldloc.s 13
            // IL_03F3: ldarg.0 0
            // IL_03F4: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_03F9: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_03FE: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_0403: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
            // IL_0408: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
            // IL_040D: ldloc.s 13
            // IL_040F: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_0414: callvirt 0x0A00059C class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.PlayerReference>::get_Item
            // IL_0419: call 0x0A00059D [OpenRA.Game]OpenRA.Server.Server::SyncClientToPlayerReference
            // IL_041E: br.s IL_0454
            // IL_0420: ldloc.s 13
            // IL_0422: ldfld 0x0A0005A7 [OpenRA.Game]OpenRA.Network.Session/Client::Bot
            // IL_0427: brfalse.s IL_0448
            // IL_0429: ldarg.0 0
            // IL_042A: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_042F: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0434: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0439: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
            // IL_043E: ldloc.s 13
            // IL_0440: callvirt 0x0A0005A8 class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::Remove
            // IL_0445: pop 
            // IL_0446: br.s IL_0454
            // IL_0448: ldloc.s 13
            // IL_044A: call 0x0A0002BF [OpenRA.Game]OpenRA.Primitives.Color::get_White
            // IL_044F: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
            // IL_0454: ldloc.s 11
            // IL_0456: ldc.i4.1 1
            // IL_0457: add 
            // IL_0458: stloc.s 11
            // IL_045A: ldloc.s 11
            // IL_045C: ldloc.s 10
            // IL_045E: ldlen 
            // IL_045F: conv.i4 
            // IL_0460: blt IL_0337
            // IL_0465: ldarg.0 0
            // IL_0466: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_046B: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0470: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0475: ldfld 0x0A000580 [OpenRA.Game]OpenRA.Network.Session::Clients
            // IL_047A: callvirt 0x0A00058B class [System.Collections]System.Collections.Generic.List`1<class [OpenRA.Game]OpenRA.Network.Session/Client>::GetEnumerator
            // IL_047F: stloc.s 14
            // IL_0481: br.s IL_04F9
            // IL_0483: ldloca.s 14
            // IL_0485: call 0x0A00058C valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::get_Current
            // IL_048A: stloc.s 15
            // IL_048C: ldloc.s 15
            // IL_048E: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_0493: brfalse.s IL_04F9
            // IL_0495: ldarg.0 0
            // IL_0496: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_049B: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_04A0: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_04A5: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
            // IL_04AA: ldloc.s 15
            // IL_04AC: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_04B1: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
            // IL_04B6: ldfld 0x0A00059E [OpenRA.Game]OpenRA.Network.Session/Slot::LockColor
            // IL_04BB: brtrue.s IL_04F9
            // IL_04BD: ldloc.s 15
            // IL_04BF: ldloc.s 15
            // IL_04C1: ldarg.0 0
            // IL_04C2: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_04C7: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_04CC: ldloc.s 15
            // IL_04CE: ldfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
            // IL_04D3: ldloc.s 15
            // IL_04D5: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_04DA: ldarg.0 0
            // IL_04DB: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_04E0: ldfld 0x040021FD OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::conn
            // IL_04E5: call 0x06000343 OpenRA.Mods.Common.Server.LobbyCommands::SanitizePlayerColor
            // IL_04EA: dup 
            // IL_04EB: stloc.s 16
            // IL_04ED: stfld 0x0A0005A1 [OpenRA.Game]OpenRA.Network.Session/Client::PreferredColor
            // IL_04F2: ldloc.s 16
            // IL_04F4: stfld 0x0A00059F [OpenRA.Game]OpenRA.Network.Session/Client::Color
            // IL_04F9: ldloca.s 14
            // IL_04FB: call 0x0A00058D valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>::MoveNext
            // IL_0500: brtrue.s IL_0483
            // IL_0502: leave.s IL_0512
            // IL_0504: ldloca.s 14
            // IL_0506: constrained. 0x1B0002C5 valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class [OpenRA.Game]OpenRA.Network.Session/Client>
            // IL_050C: callvirt 0x0A00001A [System.Runtime]System.IDisposable::Dispose
            // IL_0511: endfinally 
            // IL_0512: ldarg.0 0
            // IL_0513: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0518: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_051D: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_0522: ldfld 0x0A0005EF [OpenRA.Game]OpenRA.Network.Session::DisabledSpawnPoints
            // IL_0527: callvirt 0x0A0007D5 class [System.Collections]System.Collections.Generic.HashSet`1<int32>::Clear
            // IL_052C: ldarg.0 0
            // IL_052D: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0532: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0537: callvirt 0x0A0005F2 [OpenRA.Game]OpenRA.Server.Server::SyncLobbyInfo
            // IL_053C: ldarg.0 0
            // IL_053D: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0542: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0547: ldstr 0x7002989D [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 99, 104, 97, 110, 103, 101, 100, 45, 109, 97, 112] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 63, 00, 68, 00, 61, 00, 6E, 00, 67, 00, 65, 00, 64, 00, 2D, 00, 6D, 00, 61, 00, 70, 00] terminal-flag=Some(1)
            // IL_054C: ldc.i4.4 4
            // IL_054D: newarr 0x01000012 [System.Runtime]System.Object
            // IL_0552: dup 
            // IL_0553: ldc.i4.0 0
            // IL_0554: ldstr 0x70003ACF [112, 108, 97, 121, 101, 114] utf16-bytes=[70, 00, 6C, 00, 61, 00, 79, 00, 65, 00, 72, 00] terminal-flag=Some(0)
            // IL_0559: stelem.ref 
            // IL_055A: dup 
            // IL_055B: ldc.i4.1 1
            // IL_055C: ldarg.0 0
            // IL_055D: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0562: ldfld 0x040021FE OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::client
            // IL_0567: ldfld 0x0A0005B2 [OpenRA.Game]OpenRA.Network.Session/Client::Name
            // IL_056C: stelem.ref 
            // IL_056D: dup 
            // IL_056E: ldc.i4.2 2
            // IL_056F: ldstr 0x7000E01F [109, 97, 112] utf16-bytes=[6D, 00, 61, 00, 70, 00] terminal-flag=Some(0)
            // IL_0574: stelem.ref 
            // IL_0575: dup 
            // IL_0576: ldc.i4.3 3
            // IL_0577: ldarg.0 0
            // IL_0578: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_057D: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0582: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_0587: callvirt 0x0A00093C [OpenRA.Game]OpenRA.MapPreview::get_Title
            // IL_058C: stelem.ref 
            // IL_058D: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
            // IL_0592: ldarg.0 0
            // IL_0593: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0598: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_059D: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_05A2: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
            // IL_05A7: ldfld 0x0A000602 [OpenRA.Game]OpenRA.Network.Session/Global::MapStatus
            // IL_05AC: ldc.i4.8 8
            // IL_05AD: and 
            // IL_05AE: brfalse.s IL_05CA
            // IL_05B0: ldarg.0 0
            // IL_05B1: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_05B6: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_05BB: ldstr 0x700298CF [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 99, 117, 115, 116, 111, 109, 45, 114, 117, 108, 101, 115] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 63, 00, 75, 00, 73, 00, 74, 00, 6F, 00, 6D, 00, 2D, 00, 72, 00, 75, 00, 6C, 00, 65, 00, 73, 00] terminal-flag=Some(1)
            // IL_05C0: call 0x2B0000B5 [System.Runtime]System.Array::Empty<object>
            // IL_05C5: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
            // IL_05CA: ldarg.0 0
            // IL_05CB: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_05D0: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_05D5: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_05DA: ldfld 0x0A000581 [OpenRA.Game]OpenRA.Network.Session::GlobalSettings
            // IL_05DF: ldfld 0x0A000582 [OpenRA.Game]OpenRA.Network.Session/Global::EnableSingleplayer
            // IL_05E4: brtrue.s IL_0602
            // IL_05E6: ldarg.0 0
            // IL_05E7: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_05EC: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_05F1: ldstr 0x7000D459 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 116, 119, 111, 45, 104, 117, 109, 97, 110, 115, 45, 114, 101, 113, 117, 105, 114, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 74, 00, 77, 00, 6F, 00, 2D, 00, 68, 00, 75, 00, 6D, 00, 61, 00, 6E, 00, 73, 00, 2D, 00, 72, 00, 65, 00, 71, 00, 75, 00, 69, 00, 72, 00, 65, 00, 64, 00] terminal-flag=Some(1)
            // IL_05F6: call 0x2B0000B5 [System.Runtime]System.Array::Empty<object>
            // IL_05FB: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
            // IL_0600: br.s IL_0680
            // IL_0602: ldarg.0 0
            // IL_0603: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0608: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_060D: ldfld 0x0A000586 [OpenRA.Game]OpenRA.Server.Server::Map
            // IL_0612: callvirt 0x0A00059A [OpenRA.Game]OpenRA.MapPreview::get_Players
            // IL_0617: ldfld 0x0A00059B [OpenRA.Game]OpenRA.MapPlayers::Players
            // IL_061C: ldsfld 0x040021E6 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_9
            // IL_0621: dup 
            // IL_0622: brtrue.s IL_063B
            // IL_0624: pop 
            // IL_0625: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_062A: ldftn 0x06002944 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_9
            // IL_0630: newobj 0x0A000962 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, bool>::.ctor
            // IL_0635: dup 
            // IL_0636: stsfld 0x040021E6 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_9
            // IL_063B: call 0x2B0006ED [System.Linq]System.Linq.Enumerable::Where<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>>
            // IL_0640: ldsfld 0x040021E7 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_10
            // IL_0645: dup 
            // IL_0646: brtrue.s IL_065F
            // IL_0648: pop 
            // IL_0649: ldsfld 0x040021D9 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9
            // IL_064E: ldftn 0x06002945 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<Map>b__58_10
            // IL_0654: newobj 0x0A000962 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>, bool>::.ctor
            // IL_0659: dup 
            // IL_065A: stsfld 0x040021E7 OpenRA.Mods.Common.Server.LobbyCommands/<>c::<>9__58_10
            // IL_065F: call 0x2B000816 [System.Linq]System.Linq.Enumerable::All<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.PlayerReference>>
            // IL_0664: brfalse.s IL_0680
            // IL_0666: ldarg.0 0
            // IL_0667: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_066C: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_0671: ldstr 0x70029903 [110, 111, 116, 105, 102, 105, 99, 97, 116, 105, 111, 110, 45, 109, 97, 112, 45, 98, 111, 116, 115, 45, 100, 105, 115, 97, 98, 108, 101, 100] utf16-bytes=[6E, 00, 6F, 00, 74, 00, 69, 00, 66, 00, 69, 00, 63, 00, 61, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 2D, 00, 6D, 00, 61, 00, 70, 00, 2D, 00, 62, 00, 6F, 00, 74, 00, 73, 00, 2D, 00, 64, 00, 69, 00, 73, 00, 61, 00, 62, 00, 6C, 00, 65, 00, 64, 00] terminal-flag=Some(1)
            // IL_0676: call 0x2B0000B5 [System.Runtime]System.Array::Empty<object>
            // IL_067B: callvirt 0x0A0005D1 [OpenRA.Game]OpenRA.Server.Server::SendFluentMessage
            // IL_0680: ldarg.0 0
            // IL_0681: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_0686: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_068B: call 0x06000345 OpenRA.Mods.Common.Server.LobbyCommands::MissionBriefingOrDefault
            // IL_0690: stloc.s 7
            // IL_0692: ldloc.s 7
            // IL_0694: brfalse.s IL_06A8
            // IL_0696: ldarg.0 0
            // IL_0697: ldfld 0x04002200 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_1::CS$<>8__locals1
            // IL_069C: ldfld 0x040021FC OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass58_0::server
            // IL_06A1: ldloc.s 7
            // IL_06A3: callvirt 0x0A001A96 [OpenRA.Game]OpenRA.Server.Server::SendMessage
            // IL_06A8: leave.s IL_06B4
            // IL_06AA: ldloc.1 1
            // IL_06AB: brfalse.s IL_06B3
            // IL_06AD: ldloc.0 0
            // IL_06AE: call 0x0A000579 [System.Threading]System.Threading.Monitor::Exit
            // IL_06B3: endfinally 
            // IL_06B4: ret 
            // .eh-raw ExceptionHandler { kind: Finally, try_offset: 637, try_length: 61, handler_offset: 698, handler_length: 14, raw_flags: 2 }
            // .try IL_027D..IL_02BA finally IL_02BA..IL_02C8
            // .eh-raw ExceptionHandler { kind: Finally, try_offset: 1153, try_length: 131, handler_offset: 1284, handler_length: 14, raw_flags: 2 }
            // .try IL_0481..IL_0504 finally IL_0504..IL_0512
            // .eh-raw ExceptionHandler { kind: Finally, try_offset: 19, try_length: 1687, handler_offset: 1706, handler_length: 10, raw_flags: 2 }
            // .try IL_0013..IL_06AA finally IL_06AA..IL_06B4
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335385F32
    {
        public bool reported;
        public OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E635F5F446973706C6179436C61737335385F31 __il_field_04002202;

        public __name_3C3E635F5F446973706C6179436C61737335385F32() : base()
        {
            return;
        }

        // Metadata name: <Map>b__11
        internal void MapLambda11(OpenRA.MapPreview _)
        {
            int v1 = __cil_bool_load(this.reported);
            if (v1 != 0) {
                goto IL_0018;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            global::OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E635F5F446973706C6179436C61737335385F31 v3 = this.__il_field_04002202;
            global::OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E635F5F446973706C6179436C61737335385F30 v4 = v3.__il_field_04002200;
            __cil_callvirt_06002961(v4);
            IL_0018: ;
            this.reported = __cil_bool_store(1);
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335395F30
    {
        public OpenRA.Server.Server server;

        public __name_3C3E635F5F446973706C6179436C61737335395F30() : base()
        {
            return;
        }

        // Metadata name: <Option>b__0
        internal System.Collections.Generic.IEnumerable<OpenRA.Traits.LobbyOption> OptionLambda0(OpenRA.Traits.ILobbyOptions t)
        {
            // structural signature __cil_ref_762d55c1f4d4dab281411052866340b05fcbc225 bytes=151280A1011283BD: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_010000E1 v2 = this.server;
            __cil_type_010000EE v3 = v2.Map;
            __cil_ref_762d55c1f4d4dab281411052866340b05fcbc225 v4 = __cil_callvirt_0A0000D0(t, v3);
            return v4;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336305F30
    {
        public OpenRA.Server.Server server;

        public __name_3C3E635F5F446973706C6179436C61737336305F30() : base()
        {
            return;
        }

        // Metadata name: <ResetOptions>b__0
        internal System.Collections.Generic.IEnumerable<OpenRA.Traits.LobbyOption> ResetOptionsLambda0(OpenRA.Traits.ILobbyOptions t)
        {
            // structural signature __cil_ref_762d55c1f4d4dab281411052866340b05fcbc225 bytes=151280A1011283BD: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_010000E1 v2 = this.server;
            __cil_type_010000EE v3 = v2.Map;
            __cil_ref_762d55c1f4d4dab281411052866340b05fcbc225 v4 = __cil_callvirt_0A0000D0(t, v3);
            return v4;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336315F30
    {
        public OpenRA.Server.Server server;

        public __name_3C3E635F5F446973706C6179436C61737336315F30() : base()
        {
            return;
        }

        // Metadata name: <AssignTeams>b__1
        internal OpenRA.Network.Session.Client AssignTeamsLambda1(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> slot)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, 05, 22, 00, 04, 7B, 72, 05, 00, 0A, 0F, 01, 28, 09, 0F, 00, 0A, 6F, 95, 05, 00, 0A, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
            // IL_0006: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_000B: ldarga.s 1
            // IL_000D: call 0x0A000F09 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Key
            // IL_0012: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
            // IL_0017: ret 
        }

        // Metadata name: <AssignTeams>b__2
        internal bool AssignTeamsLambda2(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 2C, 24, 02, 7B, 05, 22, 00, 04, 7B, 72, 05, 00, 0A, 7B, 74, 05, 00, 0A, 03, 7B, 96, 05, 00]
            // .code-bytes IL_0018: [0A, 6F, 97, 05, 00, 0A, 7B, EC, 05, 00, 0A, 16, FE, 01, 2A, 16, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: brfalse.s IL_0027
            // IL_0003: ldarg.0 0
            // IL_0004: ldfld 0x04002205 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass61_0::server
            // IL_0009: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_000E: ldfld 0x0A000574 [OpenRA.Game]OpenRA.Network.Session::Slots
            // IL_0013: ldarg.1 1
            // IL_0014: ldfld 0x0A000596 [OpenRA.Game]OpenRA.Network.Session/Client::Slot
            // IL_0019: callvirt 0x0A000597 class [System.Collections]System.Collections.Generic.Dictionary`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Item
            // IL_001E: ldfld 0x0A0005EC [OpenRA.Game]OpenRA.Network.Session/Slot::LockTeam
            // IL_0023: ldc.i4.0 0
            // IL_0024: ceq 
            // IL_0026: ret 
            // IL_0027: ldc.i4.0 0
            // IL_0028: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336325F30
    {
        public OpenRA.Server.Server server;
        public int kickClientID;

        public __name_3C3E635F5F446973706C6179436C61737336325F30() : base()
        {
            return;
        }

        // Metadata name: <Kick>b__0
        internal bool KickLambda0(OpenRA.Server.Connection c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, 06, 22, 00, 04, 03, 6F, DC, 05, 00, 0A, 25, 2D, 03, 26, 16, 2A, 7B, A0, 05, 00, 0A, 02]
            // .code-bytes IL_0018: [7B, 07, 22, 00, 04, FE, 01, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04002206 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::server
            // IL_0006: ldarg.1 1
            // IL_0007: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
            // IL_000C: dup 
            // IL_000D: brtrue.s IL_0012
            // IL_000F: pop 
            // IL_0010: ldc.i4.0 0
            // IL_0011: ret 
            // IL_0012: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_0017: ldarg.0 0
            // IL_0018: ldfld 0x04002207 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass62_0::kickClientID
            // IL_001D: ceq 
            // IL_001F: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336335F30
    {
        public OpenRA.Server.Server server;
        public int kickClientID;

        public __name_3C3E635F5F446973706C6179436C61737336335F30() : base()
        {
            return;
        }

        // Metadata name: <VoteKick>b__0
        internal bool VoteKickLambda0(OpenRA.Server.Connection c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, 08, 22, 00, 04, 03, 6F, DC, 05, 00, 0A, 25, 2D, 03, 26, 16, 2A, 7B, A0, 05, 00, 0A, 02]
            // .code-bytes IL_0018: [7B, 09, 22, 00, 04, FE, 01, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04002208 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::server
            // IL_0006: ldarg.1 1
            // IL_0007: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
            // IL_000C: dup 
            // IL_000D: brtrue.s IL_0012
            // IL_000F: pop 
            // IL_0010: ldc.i4.0 0
            // IL_0011: ret 
            // IL_0012: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_0017: ldarg.0 0
            // IL_0018: ldfld 0x04002209 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass63_0::kickClientID
            // IL_001D: ceq 
            // IL_001F: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336355F30
    {
        public OpenRA.Server.Server server;

        public __name_3C3E635F5F446973706C6179436C61737336355F30() : base()
        {
            return;
        }

        // Metadata name: <MakeAdmin>b__1
        internal OpenRA.Network.Session.Client MakeAdminLambda1(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> slot)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, 0A, 22, 00, 04, 7B, 72, 05, 00, 0A, 0F, 01, 28, 09, 0F, 00, 0A, 6F, 95, 05, 00, 0A, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
            // IL_0006: ldfld 0x0A000572 [OpenRA.Game]OpenRA.Server.Server::LobbyInfo
            // IL_000B: ldarga.s 1
            // IL_000D: call 0x0A000F09 valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Key
            // IL_0012: callvirt 0x0A000595 [OpenRA.Game]OpenRA.Network.Session::ClientInSlot
            // IL_0017: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336355F31
    {
        public int newAdminId;
        public OpenRA.Mods.Common.Server.LobbyCommands.__name_3C3E635F5F446973706C6179436C61737336355F30 __il_field_0400220C;

        public __name_3C3E635F5F446973706C6179436C61737336355F31() : base()
        {
            return;
        }

        // Metadata name: <MakeAdmin>b__0
        internal bool MakeAdminLambda0(OpenRA.Server.Connection c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, 0C, 22, 00, 04, 7B, 0A, 22, 00, 04, 03, 6F, DC, 05, 00, 0A, 25, 2D, 03, 26, 16, 2A, 7B]
            // .code-bytes IL_0018: [A0, 05, 00, 0A, 02, 7B, 0B, 22, 00, 04, FE, 01, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x0400220C OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::CS$<>8__locals1
            // IL_0006: ldfld 0x0400220A OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_0::server
            // IL_000B: ldarg.1 1
            // IL_000C: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
            // IL_0011: dup 
            // IL_0012: brtrue.s IL_0017
            // IL_0014: pop 
            // IL_0015: ldc.i4.0 0
            // IL_0016: ret 
            // IL_0017: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_001C: ldarg.0 0
            // IL_001D: ldfld 0x0400220B OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass65_1::newAdminId
            // IL_0022: ceq 
            // IL_0024: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336365F30
    {
        public OpenRA.Server.Server server;
        public int targetId;

        public __name_3C3E635F5F446973706C6179436C61737336365F30() : base()
        {
            return;
        }

        // Metadata name: <MakeSpectator>b__0
        internal bool MakeSpectatorLambda0(OpenRA.Server.Connection c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [02, 7B, 0D, 22, 00, 04, 03, 6F, DC, 05, 00, 0A, 25, 2D, 03, 26, 16, 2A, 7B, A0, 05, 00, 0A, 02]
            // .code-bytes IL_0018: [7B, 0E, 22, 00, 04, FE, 01, 2A]
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x0400220D OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::server
            // IL_0006: ldarg.1 1
            // IL_0007: callvirt 0x0A0005DC [OpenRA.Game]OpenRA.Server.Server::GetClient
            // IL_000C: dup 
            // IL_000D: brtrue.s IL_0012
            // IL_000F: pop 
            // IL_0010: ldc.i4.0 0
            // IL_0011: ret 
            // IL_0012: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_0017: ldarg.0 0
            // IL_0018: ldfld 0x0400220E OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass66_0::targetId
            // IL_001D: ceq 
            // IL_001F: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336385F30
    {
        public OpenRA.Network.Session.Client client;

        public __name_3C3E635F5F446973706C6179436C61737336385F30() : base()
        {
            return;
        }

        // Metadata name: <Faction>b__0
        internal bool FactionLambda0(OpenRA.Traits.FactionInfo f)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, FC, 0E, 00, 0A, 2C, 17, 03, 7B, 9C, 06, 00, 0A, 02, 7B, 0F, 22, 00, 04, 7B, B3, 05, 00]
            // .code-bytes IL_0018: [0A, 28, BD, 02, 00, 0A, 2A, 16, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A000EFC [OpenRA.Game]OpenRA.Traits.FactionInfo::Selectable
            // IL_0006: brfalse.s IL_001F
            // IL_0008: ldarg.1 1
            // IL_0009: ldfld 0x0A00069C [OpenRA.Game]OpenRA.Traits.FactionInfo::InternalName
            // IL_000E: ldarg.0 0
            // IL_000F: ldfld 0x0400220F OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass68_0::client
            // IL_0014: ldfld 0x0A0005B3 [OpenRA.Game]OpenRA.Network.Session/Client::Faction
            // IL_0019: call 0x0A0002BD [System.Runtime]System.String::op_Equality
            // IL_001E: ret 
            // IL_001F: ldc.i4.0 0
            // IL_0020: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337315F30
    {
        public int spawnPoint;

        public __name_3C3E635F5F446973706C6179436C61737337315F30() : base()
        {
            return;
        }

        // Metadata name: <ClearPlayerSpawn>b__0
        internal bool ClearPlayerSpawnLambda0(OpenRA.Network.Session.Client cc)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, 99, 05, 00, 0A, 02, 7B, 10, 22, 00, 04, FE, 01, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
            // IL_0006: ldarg.0 0
            // IL_0007: ldfld 0x04002210 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass71_0::spawnPoint
            // IL_000C: ceq 
            // IL_000E: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337325F30
    {
        public OpenRA.Network.Session.Client client;
        public OpenRA.Server.Server server;
        public int spawnPoint;

        public __name_3C3E635F5F446973706C6179436C61737337325F30() : base()
        {
            return;
        }

        // Metadata name: <Spawn>b__0
        internal bool SpawnLambda0(OpenRA.Network.Session.Client cc)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 02, 7B, 11, 22, 00, 04, 2E, 18, 03, 7B, 99, 05, 00, 0A, 02, 7B, 13, 22, 00, 04, 33, 0A, 03]
            // .code-bytes IL_0018: [7B, 99, 05, 00, 0A, 16, FE, 03, 2A, 16, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldarg.0 0
            // IL_0002: ldfld 0x04002211 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::client
            // IL_0007: beq.s IL_0021
            // IL_0009: ldarg.1 1
            // IL_000A: ldfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
            // IL_000F: ldarg.0 0
            // IL_0010: ldfld 0x04002213 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::spawnPoint
            // IL_0015: bne.un.s IL_0021
            // IL_0017: ldarg.1 1
            // IL_0018: ldfld 0x0A000599 [OpenRA.Game]OpenRA.Network.Session/Client::SpawnPoint
            // IL_001D: ldc.i4.0 0
            // IL_001E: cgt.un 
            // IL_0020: ret 
            // IL_0021: ldc.i4.0 0
            // IL_0022: ret 
        }

        // Metadata name: <Spawn>b__2
        internal bool SpawnLambda2(System.Collections.Generic.KeyValuePair<string, OpenRA.Network.Session.Slot> ss)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 2
            // .initlocals true
            // .code-bytes IL_0000: [02, 7B, 12, 22, 00, 04, 0F, 01, 28, 0A, 0F, 00, 0A, 28, 48, 03, 00, 06, 0A, 06, 2C, 0F, 06, 7B]
            // .code-bytes IL_0018: [97, 1A, 00, 0A, 02, 7B, 13, 22, 00, 04, FE, 01, 2A, 16, 2A]
            // .local [0] class [OpenRA.Game]OpenRA.PlayerReference
            // IL_0000: ldarg.0 0
            // IL_0001: ldfld 0x04002212 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::server
            // IL_0006: ldarga.s 1
            // IL_0008: call 0x0A000F0A valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<string, class [OpenRA.Game]OpenRA.Network.Session/Slot>::get_Value
            // IL_000D: call 0x06000348 OpenRA.Mods.Common.Server.LobbyCommands::PlayerReferenceForSlot
            // IL_0012: stloc.0 0
            // IL_0013: ldloc.0 0
            // IL_0014: brfalse.s IL_0025
            // IL_0016: ldloc.0 0
            // IL_0017: ldfld 0x0A001A97 [OpenRA.Game]OpenRA.PlayerReference::Spawn
            // IL_001C: ldarg.0 0
            // IL_001D: ldfld 0x04002213 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass72_0::spawnPoint
            // IL_0022: ceq 
            // IL_0024: ret 
            // IL_0025: ldc.i4.0 0
            // IL_0026: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337355F30
    {
        public OpenRA.MapCache mapCache;

        public __name_3C3E635F5F446973706C6179436C61737337355F30() : base()
        {
            return;
        }

        // Metadata name: <InitializeMapPool>b__2
        internal bool InitializeMapPoolLambda2(string uid)
        {
            // enum storage token=0x02000071 alias=__cil_enum_02000071 underlying=int: global::@OpenRA.@MapStatus; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            __cil_type_010000F7 v1 = this.mapCache;
            __cil_type_010000EE v3 = __cil_callvirt_0A000588(v1, uid);
            int v4 = unchecked((int)(((OpenRA.MapPreview)v3).Status));
            return (v4 == 2);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337395F30
    {
        public OpenRA.MapPreview map;

        public __name_3C3E635F5F446973706C6179436C61737337395F30() : base()
        {
            return;
        }

        // Metadata name: <LoadMapSettings>b__0
        internal System.Collections.Generic.IEnumerable<OpenRA.Traits.LobbyOption> LoadMapSettingsLambda0(OpenRA.Traits.ILobbyOptions t)
        {
            // structural signature __cil_ref_762d55c1f4d4dab281411052866340b05fcbc225 bytes=151280A1011283BD: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Traits.LobbyOption>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_010000EE v2 = this.map;
            __cil_ref_762d55c1f4d4dab281411052866340b05fcbc225 v3 = __cil_callvirt_0A0000D0(t, v2);
            return v3;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737338305F30
    {
        public OpenRA.Server.Connection connectionToEcho;
        public OpenRA.Server.Server server;
        public int playerIndex;

        public __name_3C3E635F5F446973706C6179436C61737338305F30() : base()
        {
            return;
        }

        internal void __name_3C53616E6974697A65506C61796572436F6C6F723E675F5F4F6E4572726F727C30(string message)
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_010000E9 v1 = this.connectionToEcho;
            if (v1 is null) {
                goto IL_001E;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            if (message is null) {
                goto IL_001E;
            } else {
                goto IL_000B;
            }
            IL_000B: ;
            __cil_type_010000E1 v4 = this.server;
            __cil_type_010000E9 v6 = this.connectionToEcho;
            v4.SendFluentMessageTo(v6, message, ((__cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff)(null)));
            IL_001E: ;
            return;
        }

        // Metadata name: <SanitizePlayerColor>b__1
        internal bool SanitizePlayerColorLambda1(OpenRA.Network.Session.Client c)
        {
            // IL fallback: nested/generic/unresolved external class needs IL fallback
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [03, 7B, A0, 05, 00, 0A, 02, 7B, 18, 22, 00, 04, FE, 01, 16, FE, 01, 2A]
            // IL_0000: ldarg.1 1
            // IL_0001: ldfld 0x0A0005A0 [OpenRA.Game]OpenRA.Network.Session/Client::Index
            // IL_0006: ldarg.0 0
            // IL_0007: ldfld 0x04002218 OpenRA.Mods.Common.Server.LobbyCommands/<>c__DisplayClass80_0::playerIndex
            // IL_000C: ceq 
            // IL_000E: ldc.i4.0 0
            // IL_000F: ceq 
            // IL_0011: ret 
        }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.DriveInfo, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.DriveInfo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Tasks.Parallel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Tasks.Parallel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.Win32.Registry, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.Win32.Registry, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 11; exact references retained; see --details for identities and provenance.
