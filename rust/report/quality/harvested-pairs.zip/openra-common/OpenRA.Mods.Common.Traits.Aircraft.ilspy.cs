using System;
using System.Collections.Generic;
using System.Linq;
using OpenRA.Activities;
using OpenRA.Mods.Common.Activities;
using OpenRA.Mods.Common.Orders;
using OpenRA.Primitives;
using OpenRA.Traits;

namespace OpenRA.Mods.Common.Traits;

public class Aircraft : PausableConditionalTrait<AircraftInfo>, ITick, ISync, IFacing, IPositionable, IOccupySpace, IMove, INotifyAddedToWorld, INotifyRemovedFromWorld, INotifyActorDisposing, INotifyBecomingIdle, ICreationActivity, IActorPreviewInitModifier, IDeathActorInitModifier, IIssueDeployOrder, IIssueOrder, IResolveOrder, IOrderVoice
{
	private sealed class AssociateWithAirfieldActivity : Activity
	{
		private readonly Aircraft aircraft;

		private readonly int delay;

		private readonly CPos[] rallyPoint;

		private readonly bool creationByMap;

		public AssociateWithAirfieldActivity(Aircraft self, int delay, CPos[] rallyPoint, bool creationByMap)
		{
			aircraft = self;
			this.delay = delay;
			this.rallyPoint = rallyPoint;
			this.creationByMap = creationByMap;
		}

		protected override void OnFirstRun(Actor self)
		{
			CPos cpos = self.Location;
			WPos pos = self.CenterPosition;
			if (creationByMap)
			{
				if (!TryDock())
				{
					pos = new WPos(pos.X, pos.Y, pos.Z - self.World.Map.DistanceAboveTerrain(pos).Length);
					if (!aircraft.Info.TakeOffOnCreation && aircraft.CanLand(cpos))
					{
						aircraft.AddInfluence(cpos);
						aircraft.SetPosition(self, pos);
					}
					else
					{
						aircraft.SetPosition(self, new WPos(pos.X, pos.Y, pos.Z + aircraft.Info.CruiseAltitude.Length));
					}
				}
			}
			else
			{
				TryDock();
				if (delay > 0)
				{
					QueueChild(new Wait(delay));
				}
			}
			bool TryDock()
			{
				Actor actorBelow = aircraft.GetActorBelow();
				if (actorBelow != null)
				{
					Exit exit = actorBelow.NearestExitOrDefault(pos);
					pos = actorBelow.CenterPosition;
					pos = new WPos(pos.X, pos.Y, pos.Z - self.World.Map.DistanceAboveTerrain(pos).Length);
					if (exit != null)
					{
						pos += exit.Info.SpawnOffset;
						if (exit.Info.Facing.HasValue)
						{
							aircraft.Facing = exit.Info.Facing.Value;
						}
					}
					aircraft.AddInfluence(cpos);
					aircraft.SetPosition(self, pos);
					aircraft.MakeReservation(actorBelow);
					aircraft.AllowYieldingReservation();
					return true;
				}
				return false;
			}
		}

		public override bool Tick(Actor self)
		{
			if (!aircraft.Info.TakeOffOnCreation || IsCanceling)
			{
				return true;
			}
			if (rallyPoint != null && rallyPoint.Length != 0)
			{
				CPos[] array = rallyPoint;
				foreach (CPos cell in array)
				{
					QueueChild(new AttackMoveActivity(self, () => aircraft.MoveTo(cell, 1, null, evaluateNearestMovableCell: true, Color.OrangeRed)));
				}
			}
			if (!creationByMap)
			{
				aircraft.UnReserve();
			}
			return true;
		}

		public override IEnumerable<Target> GetTargets(Actor self)
		{
			if (ChildActivity != null)
			{
				return ChildActivity.GetTargets(self);
			}
			return Target.None;
		}

		public override IEnumerable<TargetLineNode> TargetLineNodes(Actor self)
		{
			for (Activity a = ChildActivity; a != null; a = a.NextActivity)
			{
				if (!a.IsCanceling)
				{
					foreach (TargetLineNode item in a.TargetLineNodes(self))
					{
						yield return item;
					}
				}
			}
		}
	}

	public class AircraftMoveOrderTargeter : IOrderTargeter
	{
		private readonly Aircraft aircraft;

		public string OrderID { get; protected set; }

		public int OrderPriority => 4;

		public bool IsQueued { get; protected set; }

		public AircraftMoveOrderTargeter(Aircraft aircraft)
		{
			this.aircraft = aircraft;
			OrderID = "Move";
		}

		public bool TargetOverridesSelection(Actor self, in Target target, List<Actor> actorsAt, CPos xy, TargetModifiers modifiers)
		{
			if (target.Type == TargetType.Actor && (target.Actor.Owner != self.Owner || self.World.Selection.Contains(target.Actor)))
			{
				return true;
			}
			return modifiers.HasModifier(TargetModifiers.ForceMove);
		}

		public virtual bool CanTarget(Actor self, in Target target, ref TargetModifiers modifiers, ref string cursor)
		{
			if (target.Type != TargetType.Terrain || (aircraft.RequireForceMove && !modifiers.HasModifier(TargetModifiers.ForceMove)))
			{
				return false;
			}
			CPos cPos = self.World.Map.CellContaining(target.CenterPosition);
			if (modifiers.HasModifier(TargetModifiers.ForceMove) && aircraft.Info.CanForceLand && (!self.World.ActorMap.GetActorsAt(cPos).Any((Actor a) => a.TraitOrDefault<Building>() != null && a.TraitOrDefault<Selectable>() != null) || aircraft.CanLand(cPos, null, blockedByMobile: false)))
			{
				OrderID = "Land";
			}
			IsQueued = modifiers.HasModifier(TargetModifiers.ForceQueue);
			bool flag = self.Owner.Shroud.IsExplored(cPos);
			cursor = ((!aircraft.IsTraitPaused && (flag || aircraft.Info.MoveIntoShroud) && self.World.Map.Contains(cPos)) ? aircraft.Info.Cursor : aircraft.Info.BlockedCursor);
			return true;
		}

		bool IOrderTargeter.TargetOverridesSelection(Actor self, in Target target, List<Actor> actorsAt, CPos xy, TargetModifiers modifiers)
		{
			return TargetOverridesSelection(self, in target, actorsAt, xy, modifiers);
		}
	}

	private readonly Actor self;

	private Repairable repairable;

	private Rearmable rearmable;

	private IAircraftCenterPositionOffset[] positionOffsets;

	private IDisposable reservation;

	private IEnumerable<int> speedModifiers;

	private INotifyMoving[] notifyMoving;

	private INotifyCenterPositionChanged[] notifyCenterPositionChanged;

	private IOverrideAircraftLanding overrideAircraftLanding;

	private (CPos, SubCell)[] landingCells = Array.Empty<(CPos, SubCell)>();

	public bool RequireForceMove;

	private readonly int creationActivityDelay;

	private readonly bool creationByMap;

	private readonly CPos[] creationRallyPoint;

	private bool notify = true;

	private bool airborne;

	private bool cruising;

	private int airborneToken = -1;

	private int cruisingToken = -1;

	private MovementType movementTypes;

	private WPos cachedPosition;

	private WAngle cachedFacing;

	[Sync]
	public WAngle Facing
	{
		get
		{
			return Orientation.Yaw;
		}
		set
		{
			Orientation = Orientation.WithYaw(value);
		}
	}

	public WAngle Pitch
	{
		get
		{
			return Orientation.Pitch;
		}
		set
		{
			Orientation = Orientation.WithPitch(value);
		}
	}

	public WAngle Roll
	{
		get
		{
			return Orientation.Roll;
		}
		set
		{
			Orientation = Orientation.WithRoll(value);
		}
	}

	public WRot Orientation { get; private set; }

	[Sync]
	public WPos CenterPosition { get; private set; }

	public CPos TopLeft => self.World.Map.CellContaining(CenterPosition);

	public WAngle TurnSpeed
	{
		get
		{
			if (!IsTraitDisabled && !IsTraitPaused)
			{
				return Info.TurnSpeed;
			}
			return WAngle.Zero;
		}
	}

	public WAngle? IdleTurnSpeed
	{
		get
		{
			if (!IsTraitDisabled && !IsTraitPaused)
			{
				return Info.IdleTurnSpeed;
			}
			return null;
		}
	}

	public Actor ReservedActor { get; private set; }

	public bool MayYieldReservation { get; private set; }

	public bool ForceLanding { get; private set; }

	public bool AtLandAltitude => self.World.Map.DistanceAboveTerrain(GetPosition()) == LandAltitude;

	public WDist LandAltitude
	{
		get
		{
			WDist landAltitude = Info.LandAltitude;
			IAircraftCenterPositionOffset[] array = positionOffsets;
			foreach (IAircraftCenterPositionOffset aircraftCenterPositionOffset in array)
			{
				landAltitude -= new WDist(aircraftCenterPositionOffset.PositionOffset.Z);
			}
			return landAltitude;
		}
	}

	public int MovementSpeed
	{
		get
		{
			if (IsTraitDisabled || IsTraitPaused)
			{
				return 0;
			}
			return Util.ApplyPercentageModifiers(Info.Speed, speedModifiers);
		}
	}

	public int IdleMovementSpeed
	{
		get
		{
			if (Info.IdleSpeed >= 0)
			{
				if (IsTraitDisabled || IsTraitPaused)
				{
					return 0;
				}
				return Util.ApplyPercentageModifiers(Info.IdleSpeed, speedModifiers);
			}
			return MovementSpeed;
		}
	}

	public MovementType CurrentMovementTypes
	{
		get
		{
			return movementTypes;
		}
		set
		{
			MovementType movementType = movementTypes;
			movementTypes = value;
			if (value != movementType)
			{
				INotifyMoving[] array = this.notifyMoving;
				foreach (INotifyMoving notifyMoving in array)
				{
					notifyMoving.MovementTypeChanged(self, value);
				}
			}
		}
	}

	public IEnumerable<IOrderTargeter> Orders
	{
		get
		{
			yield return new EnterAlliedActorTargeter<BuildingInfo>("ForceEnter", 6, Info.EnterCursor, Info.EnterBlockedCursor, (Actor target, TargetModifiers modifiers) => Info.CanForceLand && modifiers.HasModifier(TargetModifiers.ForceMove) && AircraftCanEnter(target), (Actor target) => Reservable.IsAvailableFor(target, self) && AircraftCanResupplyAt(target, allowedToForceEnter: true));
			yield return new EnterAlliedActorTargeter<BuildingInfo>("Enter", 5, Info.EnterCursor, Info.EnterBlockedCursor, AircraftCanEnter, (Actor target) => Reservable.IsAvailableFor(target, self) && AircraftCanResupplyAt(target, !Info.TakeOffOnResupply));
			yield return new AircraftMoveOrderTargeter(this);
		}
	}

	public WAngle GetTurnSpeed(bool isIdleTurn)
	{
		if ((isIdleTurn && IdleMovementSpeed == 0) || MovementSpeed == 0)
		{
			return WAngle.Zero;
		}
		return new WAngle(Util.ApplyPercentageModifiers(((!isIdleTurn) ? TurnSpeed : (IdleTurnSpeed ?? TurnSpeed)).Angle, speedModifiers).Clamp(1, 1024));
	}

	public static WPos GroundPosition(Actor self)
	{
		return self.CenterPosition - new WVec(WDist.Zero, WDist.Zero, self.World.Map.DistanceAboveTerrain(self.CenterPosition));
	}

	public Aircraft(ActorInitializer init, AircraftInfo info)
		: base(info)
	{
		self = init.Self;
		LocationInit orDefault = init.GetOrDefault<LocationInit>();
		CenterPositionInit orDefault2 = init.GetOrDefault<CenterPositionInit>();
		if (orDefault != null || orDefault2 != null)
		{
			WPos pos = orDefault2?.Value ?? self.World.Map.CenterOfCell(orDefault.Value);
			creationByMap = init.Contains<SpawnedByMapInit>();
			SetPosition(self, pos);
		}
		Facing = init.GetValue<FacingInit, WAngle>(Info.InitialFacing);
		creationActivityDelay = init.GetValue<CreationActivityDelayInit, int>(0);
		creationRallyPoint = init.GetOrDefault<RallyPointInit>()?.Value;
	}

	public WPos GetPosition()
	{
		WPos a = self.CenterPosition;
		IAircraftCenterPositionOffset[] array = positionOffsets;
		foreach (IAircraftCenterPositionOffset aircraftCenterPositionOffset in array)
		{
			a += ILSpyHelper_AsRefReadOnly(aircraftCenterPositionOffset.PositionOffset);
		}
		return a;
		static ref readonly T ILSpyHelper_AsRefReadOnly<T>(in T temp)
		{
			//ILSpy generated this function to help ensure overload resolution can pick the overload using 'in'
			return ref temp;
		}
	}

	public override IEnumerable<VariableObserver> GetVariableObservers()
	{
		foreach (VariableObserver variableObserver in base.GetVariableObservers())
		{
			yield return variableObserver;
		}
		if (Info.RequireForceMoveCondition != null)
		{
			yield return new VariableObserver(RequireForceMoveConditionChanged, Info.RequireForceMoveCondition.Variables);
		}
	}

	private void RequireForceMoveConditionChanged(Actor self, IReadOnlyDictionary<string, int> conditions)
	{
		RequireForceMove = Info.RequireForceMoveCondition.Evaluate(conditions);
	}

	protected override void Created(Actor self)
	{
		repairable = self.TraitOrDefault<Repairable>();
		rearmable = self.TraitOrDefault<Rearmable>();
		speedModifiers = from sm in self.TraitsImplementing<ISpeedModifier>().ToArray()
			select sm.GetSpeedModifier();
		cachedPosition = self.CenterPosition;
		notifyMoving = self.TraitsImplementing<INotifyMoving>().ToArray();
		positionOffsets = self.TraitsImplementing<IAircraftCenterPositionOffset>().ToArray();
		overrideAircraftLanding = self.TraitOrDefault<IOverrideAircraftLanding>();
		notifyCenterPositionChanged = self.TraitsImplementing<INotifyCenterPositionChanged>().ToArray();
		base.Created(self);
	}

	void INotifyAddedToWorld.AddedToWorld(Actor self)
	{
		AddedToWorld(self);
	}

	protected virtual void AddedToWorld(Actor self)
	{
		self.World.AddToMaps(self, this);
		WDist wDist = self.World.Map.DistanceAboveTerrain(CenterPosition);
		if (wDist.Length >= Info.MinAirborneAltitude)
		{
			OnAirborneAltitudeReached();
		}
		if (wDist == Info.CruiseAltitude)
		{
			OnCruisingAltitudeReached();
		}
	}

	void INotifyRemovedFromWorld.RemovedFromWorld(Actor self)
	{
		RemovedFromWorld(self);
	}

	protected virtual void RemovedFromWorld(Actor self)
	{
		UnReserve();
		self.World.RemoveFromMaps(self, this);
		OnCruisingAltitudeLeft();
		OnAirborneAltitudeLeft();
	}

	void ITick.Tick(Actor self)
	{
		Tick(self);
	}

	protected virtual void Tick(Actor self)
	{
		if (!ForceLanding && IsTraitPaused && airborne && CanLand(self.Location) && !(self.CurrentActivity is Land) && !(self.CurrentActivity is Turn))
		{
			self.QueueActivity(queued: false, new Land(self));
			ForceLanding = true;
		}
		if (ForceLanding && !IsTraitPaused && !cruising && !(self.CurrentActivity is TakeOff))
		{
			ForceLanding = false;
			if (Info.IdleBehavior != IdleBehaviorType.Land)
			{
				self.QueueActivity(queued: false, new TakeOff(self));
			}
		}
		WAngle wAngle = cachedFacing;
		cachedFacing = Facing;
		WPos a = cachedPosition;
		cachedPosition = self.CenterPosition;
		MovementType movementType = MovementType.None;
		if (wAngle != Facing)
		{
			movementType |= MovementType.Turn;
		}
		if ((a - cachedPosition).HorizontalLengthSquared != 0L)
		{
			movementType |= MovementType.Horizontal;
		}
		if ((a - cachedPosition).VerticalLengthSquared != 0L)
		{
			movementType |= MovementType.Vertical;
		}
		CurrentMovementTypes = movementType;
		if (!CurrentMovementTypes.HasMovementType(MovementType.Horizontal))
		{
			if (Info.Roll != WAngle.Zero && Roll != WAngle.Zero)
			{
				Roll = Util.TickFacing(Roll, WAngle.Zero, Info.RollSpeed);
			}
			if (Info.Pitch != WAngle.Zero && Pitch != WAngle.Zero)
			{
				Pitch = Util.TickFacing(Pitch, WAngle.Zero, Info.PitchSpeed);
			}
		}
		Repulse();
	}

	public void Repulse()
	{
		WVec me = GetRepulsionForce();
		if (!(me == WVec.Zero))
		{
			int speed = ((Info.RepulsionSpeed != -1) ? Info.RepulsionSpeed : MovementSpeed);
			notify = false;
			SetPosition(self, CenterPosition + FlyStep(speed, me.Yaw));
			notify = true;
		}
	}

	public virtual WVec GetRepulsionForce()
	{
		if (!Info.Repulsable)
		{
			return WVec.Zero;
		}
		if (reservation != null)
		{
			int horizontalLength = (ReservedActor.CenterPosition - self.CenterPosition).HorizontalLength;
			if (horizontalLength < Info.WaitDistanceFromResupplyBase.Length)
			{
				return WVec.Zero;
			}
		}
		if (!cruising)
		{
			return WVec.Zero;
		}
		WVec b = WVec.Zero;
		foreach (Actor item in self.World.FindActorsInCircle(self.CenterPosition, Info.IdealSeparation))
		{
			if (!item.IsDead)
			{
				AircraftInfo aircraftInfo = item.Info.TraitInfoOrDefault<AircraftInfo>();
				if (aircraftInfo != null && aircraftInfo.Repulsable && !(aircraftInfo.CruiseAltitude != Info.CruiseAltitude))
				{
					b += GetRepulsionForce(item);
				}
			}
		}
		if (!self.World.Map.Contains(self.Location))
		{
			WPos b2 = WPos.Lerp(self.World.Map.ProjectedTopLeft, self.World.Map.ProjectedBottomRight, 1, 2);
			b += new WVec(0, 1024, 0).Rotate(WRot.FromYaw((self.CenterPosition - b2).Yaw));
		}
		if (Info.CanSlide)
		{
			return b;
		}
		WVec a = FlyStep(Facing);
		int num = a.HorizontalLength * b.HorizontalLength;
		if (num == 0)
		{
			return WVec.Zero;
		}
		int num2 = WVec.Dot(in a, in b) / num;
		if (num2 < 0)
		{
			return WVec.Zero;
		}
		return b;
	}

	public WVec GetRepulsionForce(Actor other)
	{
		if (self == other || other.CenterPosition.Z < self.CenterPosition.Z)
		{
			return WVec.Zero;
		}
		WVec a = self.CenterPosition - other.CenterPosition;
		long horizontalLengthSquared = a.HorizontalLengthSquared;
		if (horizontalLengthSquared > Info.IdealSeparation.LengthSquared)
		{
			return WVec.Zero;
		}
		if (horizontalLengthSquared < 1)
		{
			int a2 = self.World.SharedRandom.Next(0, 1023);
			WRot rot = new WRot(WAngle.Zero, WAngle.Zero, new WAngle(a2));
			return new WVec(1024, 0, 0).Rotate(in rot);
		}
		return a * 1024 * 8 / (int)horizontalLengthSquared;
	}

	public Actor GetActorBelow()
	{
		if (self.World.Map.DistanceAboveTerrain(CenterPosition) != LandAltitude)
		{
			return null;
		}
		return self.World.ActorMap.GetActorsAt(self.Location).FirstOrDefault((Actor a) => a.Info.HasTraitInfo<ReservableInfo>());
	}

	public void MakeReservation(Actor target)
	{
		UnReserve();
		Reservable reservable = target.TraitOrDefault<Reservable>();
		if (reservable != null)
		{
			reservation = reservable.Reserve(target, self, this);
			ReservedActor = target;
		}
	}

	public void AllowYieldingReservation()
	{
		if (reservation != null)
		{
			MayYieldReservation = true;
		}
	}

	public void UnReserve()
	{
		if (reservation != null)
		{
			reservation.Dispose();
			reservation = null;
			ReservedActor = null;
			MayYieldReservation = false;
		}
	}

	private bool AircraftCanEnter(Actor a, TargetModifiers modifiers)
	{
		if (RequireForceMove && !modifiers.HasModifier(TargetModifiers.ForceMove))
		{
			return false;
		}
		return AircraftCanEnter(a);
	}

	private bool AircraftCanEnter(Actor a)
	{
		if (self.AppearsHostileTo(a))
		{
			return false;
		}
		bool flag = rearmable != null && rearmable.Info.RearmActors.Contains(a.Info.Name);
		bool flag2 = repairable != null && repairable.Info.RepairActors.Contains(a.Info.Name);
		return flag | flag2;
	}

	private bool AircraftCanResupplyAt(Actor a, bool allowedToForceEnter = false)
	{
		if (self.AppearsHostileTo(a))
		{
			return false;
		}
		bool flag = rearmable != null && rearmable.Info.RearmActors.Contains(a.Info.Name);
		bool flag2 = repairable != null && repairable.Info.RepairActors.Contains(a.Info.Name);
		bool flag3 = flag && (allowedToForceEnter || rearmable.RearmableAmmoPools.Any((AmmoPool p) => !p.HasFullAmmo));
		bool flag4 = flag2 && (allowedToForceEnter || self.GetDamageState() != DamageState.Undamaged);
		return flag3 | flag4;
	}

	public (CPos Cell, SubCell SubCell)[] OccupiedCells()
	{
		return landingCells;
	}

	public WVec FlyStep(WAngle facing)
	{
		return FlyStep(MovementSpeed, facing);
	}

	public WVec FlyStep(int speed, WAngle facing)
	{
		return speed * new WVec(0, -1024, 0).Rotate(WRot.FromYaw(facing)) / 1024;
	}

	public CPos? FindLandingLocation(CPos targetCell, WDist maxSearchDistance)
	{
		if (CanLand(targetCell, null, blockedByMobile: false))
		{
			return targetCell;
		}
		int maxRange = (maxSearchDistance.Length + 1023) / 1024;
		WPos b = self.World.Map.CenterOfCell(targetCell);
		foreach (CPos item in self.World.Map.FindTilesInCircle(targetCell, maxRange))
		{
			if (CanLand(item, null, blockedByMobile: false) && (self.World.Map.CenterOfCell(item) - b).LengthSquared < maxSearchDistance.LengthSquared)
			{
				return item;
			}
		}
		return null;
	}

	public bool CanLand(IEnumerable<CPos> cells, Actor dockingActor = null, bool blockedByMobile = true)
	{
		foreach (CPos cell in cells)
		{
			if (!CanLand(cell, dockingActor, blockedByMobile))
			{
				return false;
			}
		}
		return true;
	}

	public bool CanLand(CPos cell, Actor dockingActor = null, bool blockedByMobile = true)
	{
		if (!self.World.Map.Contains(cell))
		{
			return false;
		}
		foreach (Actor item in self.World.ActorMap.GetActorsAt(cell))
		{
			if (IsBlockedBy(self, item, dockingActor, blockedByMobile))
			{
				return false;
			}
		}
		if (dockingActor != null)
		{
			return true;
		}
		HashSet<string> hashSet = ((overrideAircraftLanding != null) ? overrideAircraftLanding.LandableTerrainTypes : Info.LandableTerrainTypes);
		return hashSet.Contains(self.World.Map.GetTerrainInfo(cell).Type);
	}

	private bool IsBlockedBy(Actor self, Actor otherActor, Actor ignoreActor, bool blockedByMobile = true)
	{
		if (otherActor == self || otherActor == ignoreActor)
		{
			return false;
		}
		if (!blockedByMobile && self.Owner.RelationshipWith(otherActor.Owner) == PlayerRelationship.Ally && otherActor.TraitOrDefault<Mobile>() != null && otherActor.CurrentActivity == null)
		{
			return false;
		}
		if (self.World.RulesContainTemporaryBlocker)
		{
			ITemporaryBlocker temporaryBlocker = otherActor.TraitOrDefault<ITemporaryBlocker>();
			if (temporaryBlocker != null && temporaryBlocker.CanRemoveBlockage(otherActor, self))
			{
				return false;
			}
		}
		if (Info.Crushes.IsEmpty)
		{
			return true;
		}
		ICrushable[] crushables = otherActor.Crushables;
		foreach (ICrushable crushable in crushables)
		{
			if (crushable.CrushableBy(otherActor, self, Info.Crushes))
			{
				return false;
			}
		}
		return true;
	}

	public bool CanRearmAt(Actor host)
	{
		if (rearmable != null && rearmable.Info.RearmActors.Contains(host.Info.Name))
		{
			return rearmable.RearmableAmmoPools.Any((AmmoPool p) => !p.HasFullAmmo);
		}
		return false;
	}

	public bool CanRepairAt(Actor host)
	{
		if (repairable != null && repairable.Info.RepairActors.Contains(host.Info.Name))
		{
			return self.GetDamageState() != DamageState.Undamaged;
		}
		return false;
	}

	public void ModifyDeathActorInit(Actor self, TypeDictionary init)
	{
		init.Add(new FacingInit(Facing));
	}

	void INotifyBecomingIdle.OnBecomingIdle(Actor self)
	{
		OnBecomingIdle(self);
	}

	protected virtual void OnBecomingIdle(Actor self)
	{
		if (Info.IdleBehavior == IdleBehaviorType.LeaveMap)
		{
			self.QueueActivity(new FlyOffMap(self));
			self.QueueActivity(new RemoveSelf());
			return;
		}
		if (Info.IdleBehavior == IdleBehaviorType.LeaveMapAtClosestEdge)
		{
			CPos c = self.World.Map.ChooseClosestEdgeCell(self.Location);
			self.QueueActivity(new FlyOffMap(self, Target.FromCell(self.World, c)));
			self.QueueActivity(new RemoveSelf());
			return;
		}
		if (Info.IdleBehavior == IdleBehaviorType.ReturnToBase && GetActorBelow() == null)
		{
			self.QueueActivity(new ReturnToBase(self, null, !Info.TakeOffOnResupply));
			return;
		}
		WDist wDist = self.World.Map.DistanceAboveTerrain(CenterPosition);
		if (wDist == LandAltitude)
		{
			if (!CanLand(self.Location) && ReservedActor == null)
			{
				self.QueueActivity(new TakeOff(self));
			}
		}
		else if (Info.IdleBehavior == IdleBehaviorType.Land && Info.LandableTerrainTypes.Count > 0)
		{
			self.QueueActivity(new Land(self));
		}
		else
		{
			self.QueueActivity(new FlyIdle(self));
		}
	}

	public bool CanExistInCell(CPos cell)
	{
		return true;
	}

	public bool IsLeavingCell(CPos location, SubCell subCell = SubCell.Any)
	{
		return false;
	}

	public bool CanEnterCell(CPos cell, Actor ignoreActor = null, BlockedByActor check = BlockedByActor.All)
	{
		return true;
	}

	public SubCell GetValidSubCell(SubCell preferred)
	{
		return SubCell.Invalid;
	}

	public SubCell GetAvailableSubCell(CPos a, SubCell preferredSubCell = SubCell.Any, Actor ignoreActor = null, BlockedByActor check = BlockedByActor.All)
	{
		return SubCell.Invalid;
	}

	public void SetCenterPosition(Actor self, WPos pos)
	{
		SetPosition(self, pos);
	}

	public void SetPosition(Actor self, CPos cell, SubCell subCell = SubCell.Any)
	{
		SetPosition(self, self.World.Map.CenterOfCell(cell) + new WVec(0, 0, CenterPosition.Z));
	}

	public void SetPosition(Actor self, WPos pos)
	{
		CenterPosition = pos;
		if (!self.IsInWorld)
		{
			return;
		}
		WDist wDist = self.World.Map.DistanceAboveTerrain(CenterPosition);
		if (HasInfluence() && wDist.Length <= Info.MinAirborneAltitude)
		{
			(CPos, SubCell)[] second = new (CPos, SubCell)[1] { (TopLeft, SubCell.FullCell) };
			if (Enumerable.SequenceEqual(landingCells, second))
			{
				self.World.ActorMap.RemoveInfluence(self, this);
				landingCells = second;
				self.World.ActorMap.AddInfluence(self, this);
			}
		}
		self.World.UpdateMaps(self, this);
		bool flag = wDist.Length >= Info.MinAirborneAltitude;
		if (flag && !airborne)
		{
			OnAirborneAltitudeReached();
		}
		else if (!flag && airborne)
		{
			OnAirborneAltitudeLeft();
		}
		bool flag2 = wDist == Info.CruiseAltitude;
		if (flag2 && !cruising)
		{
			OnCruisingAltitudeReached();
		}
		else if (!flag2 && cruising)
		{
			OnCruisingAltitudeLeft();
		}
		if (notify && this.notifyCenterPositionChanged != null)
		{
			INotifyCenterPositionChanged[] array = this.notifyCenterPositionChanged;
			foreach (INotifyCenterPositionChanged notifyCenterPositionChanged in array)
			{
				notifyCenterPositionChanged.CenterPositionChanged(self, 0, 0);
			}
		}
		FinishedMoving(self);
	}

	public void FinishedMoving(Actor self)
	{
		if (self.IsAtGroundLevel())
		{
			CrushAction(self, (INotifyCrushed notifyCrushed) => notifyCrushed.OnCrush);
		}
	}

	public void EnteringCell(Actor self)
	{
		CrushAction(self, (INotifyCrushed notifyCrushed) => notifyCrushed.WarnCrush);
	}

	private void CrushAction(Actor self, Func<INotifyCrushed, Action<Actor, Actor, BitSet<CrushClass>>> action)
	{
		IEnumerable<TraitPair<ICrushable>> enumerable = (from a in self.World.ActorMap.GetActorsAt(TopLeft)
			where a != self
			select a).SelectMany((Actor a) => a.Crushables.Select((ICrushable t) => new TraitPair<ICrushable>(a, t)));
		foreach (TraitPair<ICrushable> item in enumerable)
		{
			if (!item.Trait.CrushableBy(item.Actor, self, Info.Crushes) || !item.Actor.IsAtGroundLevel())
			{
				continue;
			}
			foreach (INotifyCrushed item2 in item.Actor.TraitsImplementing<INotifyCrushed>())
			{
				action(item2)(item.Actor, self, Info.Crushes);
			}
		}
	}

	public void AddInfluence((CPos, SubCell)[] landingCells)
	{
		if (HasInfluence())
		{
			throw new InvalidOperationException("Cannot AddInfluence until previous influence is removed with RemoveInfluence");
		}
		this.landingCells = landingCells;
		if (self.IsInWorld)
		{
			self.World.ActorMap.AddInfluence(self, this);
		}
	}

	public void AddInfluence(CPos landingCell)
	{
		AddInfluence(new (CPos, SubCell)[1] { (landingCell, SubCell.FullCell) });
	}

	public void RemoveInfluence()
	{
		if (self.IsInWorld)
		{
			self.World.ActorMap.RemoveInfluence(self, this);
		}
		landingCells = Array.Empty<(CPos, SubCell)>();
	}

	public bool HasInfluence()
	{
		return landingCells.Length != 0;
	}

	public Activity MoveTo(CPos cell, int nearEnough = 0, Actor ignoreActor = null, bool evaluateNearestMovableCell = false, Color? targetLineColor = null)
	{
		Actor actor = self;
		Target t = Target.FromCell(self.World, cell);
		return new Fly(actor, in t, WDist.FromCells(nearEnough), null, targetLineColor);
	}

	public Activity MoveWithinRange(in Target target, WDist range, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return new Fly(self, in target, WDist.Zero, range, initialTargetPosition, targetLineColor);
	}

	public Activity MoveWithinRange(in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return new Fly(self, in target, minRange, maxRange, initialTargetPosition, targetLineColor);
	}

	public Activity MoveFollow(Actor self, in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return new FlyFollow(self, in target, minRange, maxRange, initialTargetPosition, targetLineColor);
	}

	public Activity ReturnToCell(Actor self)
	{
		return null;
	}

	public Activity MoveToTarget(Actor self, in Target target, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return new Fly(self, in target, initialTargetPosition, targetLineColor);
	}

	public Activity MoveIntoTarget(Actor self, in Target target)
	{
		return new Land(self, in target);
	}

	public Activity MoveOntoTarget(Actor self, in Target target, in WVec offset, WAngle? facing, Color? targetLineColor = null)
	{
		return new Land(self, in target, in offset, facing, targetLineColor);
	}

	public Activity LocalMove(Actor self, WPos fromPos, WPos toPos)
	{
		CallFunc callFunc = new CallFunc(() =>
		{
			SetCenterPosition(self, fromPos);
		});
		callFunc.Queue(new Fly(self, Target.FromPos(toPos)));
		return callFunc;
	}

	public int EstimatedMoveDuration(Actor self, WPos fromPos, WPos toPos)
	{
		int movementSpeed = MovementSpeed;
		if (movementSpeed <= 0)
		{
			return 0;
		}
		return (toPos - fromPos).Length / movementSpeed;
	}

	public CPos NearestMoveableCell(CPos cell)
	{
		return cell;
	}

	public bool CanEnterTargetNow(Actor self, in Target target)
	{
		Target targetActor = target;
		if (target.Positions.Any((WPos p) => self.World.ActorMap.GetActorsAt(self.World.Map.CellContaining(p)).Any((Actor a) => a != self && a != targetActor.Actor)))
		{
			return false;
		}
		MakeReservation(target.Actor);
		return true;
	}

	public Order IssueOrder(Actor self, IOrderTargeter order, in Target target, bool queued)
	{
		if (!IsTraitDisabled && (order.OrderID == "Enter" || order.OrderID == "Move" || order.OrderID == "Land" || order.OrderID == "ForceEnter"))
		{
			return new Order(order.OrderID, self, in target, queued);
		}
		return null;
	}

	Order IIssueDeployOrder.IssueDeployOrder(Actor self, bool queued)
	{
		if (IsTraitDisabled || rearmable == null || rearmable.Info.RearmActors.Count == 0)
		{
			return null;
		}
		return new Order("ReturnToBase", self, queued);
	}

	bool IIssueDeployOrder.CanIssueDeployOrder(Actor self, bool queued)
	{
		if (rearmable != null)
		{
			return rearmable.Info.RearmActors.Count > 0;
		}
		return false;
	}

	public string VoicePhraseForOrder(Actor self, Order order)
	{
		if (IsTraitDisabled)
		{
			return null;
		}
		switch (order.OrderString)
		{
		case "Land":
		case "Move":
			if (!Info.MoveIntoShroud && order.Target.Type != TargetType.Invalid)
			{
				CPos cell = self.World.Map.CellContaining(order.Target.CenterPosition);
				if (!self.Owner.Shroud.IsExplored(cell))
				{
					return null;
				}
			}
			return Info.Voice;
		case "Stop":
		case "Enter":
		case "ForceEnter":
		case "Scatter":
			return Info.Voice;
		case "ReturnToBase":
			if (rearmable == null || rearmable.Info.RearmActors.Count <= 0)
			{
				return null;
			}
			return Info.Voice;
		default:
			return null;
		}
	}

	public void ResolveOrder(Actor self, Order order)
	{
		if (IsTraitDisabled)
		{
			return;
		}
		string orderString = order.OrderString;
		switch (orderString)
		{
		case "Move":
		{
			if (!order.Target.IsValidFor(self))
			{
				break;
			}
			CPos cPos2 = self.World.Map.Clamp(self.World.Map.CellContaining(order.Target.CenterPosition));
			if (Info.MoveIntoShroud || self.Owner.Shroud.IsExplored(cPos2))
			{
				if (!order.Queued)
				{
					UnReserve();
				}
				Target t = Target.FromCell(self.World, cPos2);
				bool queued2 = order.Queued;
				WDist nearEnough = WDist.FromCells(8);
				Color? targetLineColor = Info.TargetLineColor;
				self.QueueActivity(queued2, new Fly(self, in t, nearEnough, null, targetLineColor));
				self.ShowTargetLines();
			}
			break;
		}
		case "Land":
		{
			if (!order.Target.IsValidFor(self))
			{
				break;
			}
			CPos cPos = self.World.Map.Clamp(self.World.Map.CellContaining(order.Target.CenterPosition));
			if (Info.MoveIntoShroud || self.Owner.Shroud.IsExplored(cPos))
			{
				if (!order.Queued)
				{
					UnReserve();
				}
				Target target = Target.FromCell(self.World, cPos);
				bool queued = order.Queued;
				Color? targetLineColor = Info.TargetLineColor;
				self.QueueActivity(queued, new Land(self, in target, null, targetLineColor));
				self.ShowTargetLines();
			}
			break;
		}
		case "Enter":
		case "ForceEnter":
		case "Repair":
		{
			if (order.Target.Type != TargetType.Actor)
			{
				break;
			}
			Actor actor = order.Target.Actor;
			bool flag = orderString == "ForceEnter";
			if (AircraftCanResupplyAt(actor, flag || !Info.TakeOffOnResupply) && Reservable.IsAvailableFor(actor, self))
			{
				if (!order.Queued)
				{
					UnReserve();
				}
				bool alwaysLand = flag || !Info.TakeOffOnResupply;
				self.QueueActivity(order.Queued, new ReturnToBase(self, actor, alwaysLand));
				self.ShowTargetLines();
			}
			break;
		}
		case "Stop":
			if (!(self.CurrentActivity is Resupply) && (!(self.CurrentActivity is ReturnToBase) || GetActorBelow() == null))
			{
				self.CancelActivity();
				UnReserve();
			}
			break;
		case "ReturnToBase":
			if (rearmable != null && rearmable.Info.RearmActors.Count != 0 && !(self.CurrentActivity is ReturnToBase) && GetActorBelow() == null)
			{
				if (!order.Queued)
				{
					UnReserve();
				}
				self.QueueActivity(order.Queued, new ReturnToBase(self, null, !Info.TakeOffOnResupply));
				self.ShowTargetLines();
			}
			break;
		case "Scatter":
			self.QueueActivity(order.Queued, new Nudge(self));
			self.ShowTargetLines();
			break;
		}
	}

	private void OnAirborneAltitudeReached()
	{
		if (!airborne)
		{
			airborne = true;
			if (airborneToken == -1)
			{
				airborneToken = self.GrantCondition(Info.AirborneCondition);
			}
		}
	}

	private void OnAirborneAltitudeLeft()
	{
		if (airborne)
		{
			airborne = false;
			if (airborneToken != -1)
			{
				airborneToken = self.RevokeCondition(airborneToken);
			}
		}
	}

	private void OnCruisingAltitudeReached()
	{
		if (!cruising)
		{
			cruising = true;
			if (cruisingToken == -1)
			{
				cruisingToken = self.GrantCondition(Info.CruisingCondition);
			}
		}
	}

	private void OnCruisingAltitudeLeft()
	{
		if (cruising)
		{
			cruising = false;
			if (cruisingToken != -1)
			{
				cruisingToken = self.RevokeCondition(cruisingToken);
			}
		}
	}

	void INotifyActorDisposing.Disposing(Actor self)
	{
		UnReserve();
	}

	void IActorPreviewInitModifier.ModifyActorPreviewInit(Actor self, TypeDictionary inits)
	{
		if (!inits.Contains<DynamicFacingInit>() && !inits.Contains<FacingInit>())
		{
			inits.Add(new DynamicFacingInit(() => Facing));
		}
	}

	Activity ICreationActivity.GetCreationActivity()
	{
		if (creationRallyPoint != null || creationActivityDelay > 0 || creationByMap)
		{
			return new AssociateWithAirfieldActivity(this, creationActivityDelay, creationRallyPoint, creationByMap);
		}
		return null;
	}

	Activity IMove.MoveWithinRange(in Target target, WDist range, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveWithinRange(in target, range, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveWithinRange(in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveWithinRange(in target, minRange, maxRange, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveFollow(Actor self, in Target target, WDist minRange, WDist maxRange, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveFollow(self, in target, minRange, maxRange, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveToTarget(Actor self, in Target target, WPos? initialTargetPosition = null, Color? targetLineColor = null)
	{
		return MoveToTarget(self, in target, initialTargetPosition, targetLineColor);
	}

	Activity IMove.MoveIntoTarget(Actor self, in Target target)
	{
		return MoveIntoTarget(self, in target);
	}

	Activity IMove.MoveOntoTarget(Actor self, in Target target, in WVec offset, WAngle? facing, Color? targetLineColor = null)
	{
		return MoveOntoTarget(self, in target, in offset, facing, targetLineColor);
	}

	bool IMove.CanEnterTargetNow(Actor self, in Target target)
	{
		return CanEnterTargetNow(self, in target);
	}

	Order IIssueOrder.IssueOrder(Actor self, IOrderTargeter order, in Target target, bool queued)
	{
		return IssueOrder(self, order, in target, queued);
	}
}
