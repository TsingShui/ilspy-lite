namespace OpenRA.Mods.Common.Scripting.Global;

public class ColorGlobal : OpenRA.Scripting.ScriptGlobal
{
    public ColorGlobal(OpenRA.Scripting.ScriptContext context) : base(context)
    {
        return;
    }

    public OpenRA.Primitives.Color New(int hue, int saturation, int luminosity)
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        byte l0 = default;
        byte l1 = default;
        byte l2 = default;
        int v3 = __cil_methodspec_call_2B0000FC(hue, 0, 255);
        int v4 = unchecked((int)(unchecked((byte)(v3))));
        l0 = unchecked((byte)(v4));
        int v8 = __cil_methodspec_call_2B0000FC(saturation, 0, 255);
        int v9 = unchecked((int)(unchecked((byte)(v8))));
        l1 = unchecked((byte)(v9));
        int v13 = __cil_methodspec_call_2B0000FC(luminosity, 0, 255);
        int v14 = unchecked((int)(unchecked((byte)(v13))));
        l2 = unchecked((byte)(v14));
        int v16 = unchecked((int)(l0));
        __cil_F v17 = __cil_conv_r4(v16);
        __cil_F v18 = __cil_ldc_r4_bits(0x437F0000u);
        __cil_F v19 = __cil_div_F(v17, v18);
        int v20 = unchecked((int)(l1));
        __cil_F v21 = __cil_conv_r4(v20);
        __cil_F v22 = __cil_ldc_r4_bits(0x437F0000u);
        __cil_F v23 = __cil_div_F(v21, v22);
        int v24 = unchecked((int)(l2));
        __cil_F v25 = __cil_conv_r4(v24);
        __cil_F v26 = __cil_ldc_r4_bits(0x437F0000u);
        __cil_F v27 = __cil_div_F(v25, v26);
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v28 = OpenRA.Primitives.Color.FromAhsl(255, __cil_call_arg_r4(v19), __cil_call_arg_r4(v23), __cil_call_arg_r4(v27));
        return v28;
    }

    public OpenRA.Primitives.Color FromRGB(int red, int green, int blue, int alpha = 255)
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        int v3 = __cil_methodspec_call_2B0000FC(alpha, 0, 255);
        int v7 = __cil_methodspec_call_2B0000FC(red, 0, 255);
        int v11 = __cil_methodspec_call_2B0000FC(green, 0, 255);
        int v15 = __cil_methodspec_call_2B0000FC(blue, 0, 255);
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v16 = OpenRA.Primitives.Color.FromArgb(v3, v7, v11, v15);
        return v16;
    }

    public OpenRA.Primitives.Color FromHex(string value)
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [03, 12, 00, 28, 32, 07, 00, 0A, 2C, 02, 06, 2A, 72, EE, EC, 00, 70, 73, 4A, 06, 00, 0A, 7A]
        // .local [0] valuetype [OpenRA.Game]OpenRA.Primitives.Color
        // IL_0000: ldarg.1 1
        // IL_0001: ldloca.s 0
        // IL_0003: call 0x0A000732 [OpenRA.Game]OpenRA.Primitives.Color::TryParse
        // IL_0008: brfalse.s IL_000C
        // IL_000A: ldloc.0 0
        // IL_000B: ret 
        // IL_000C: ldstr 0x7000ECEE [73, 110, 118, 97, 108, 105, 100, 32, 114, 114, 103, 103, 98, 98, 91, 97, 97, 93, 32, 104, 101, 120, 32, 115, 116, 114, 105, 110, 103, 46] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 72, 00, 72, 00, 67, 00, 67, 00, 62, 00, 62, 00, 5B, 00, 61, 00, 61, 00, 5D, 00, 20, 00, 68, 00, 65, 00, 78, 00, 20, 00, 73, 00, 74, 00, 72, 00, 69, 00, 6E, 00, 67, 00, 2E, 00] terminal-flag=Some(0)
        // IL_0011: newobj 0x0A00064A [Eluant]Eluant.LuaException::.ctor
        // IL_0016: throw 
    }

    public OpenRA.Primitives.Color get_Aqua()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Aqua();
        return v0;
    }

    public OpenRA.Primitives.Color get_Black()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Black();
        return v0;
    }

    public OpenRA.Primitives.Color get_Blue()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Blue();
        return v0;
    }

    public OpenRA.Primitives.Color get_Brown()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Brown();
        return v0;
    }

    public OpenRA.Primitives.Color get_Cyan()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Cyan();
        return v0;
    }

    public OpenRA.Primitives.Color get_DarkBlue()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_DarkBlue();
        return v0;
    }

    public OpenRA.Primitives.Color get_DarkCyan()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_DarkCyan();
        return v0;
    }

    public OpenRA.Primitives.Color get_DarkGray()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_DarkGray();
        return v0;
    }

    public OpenRA.Primitives.Color get_DarkGreen()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_DarkGreen();
        return v0;
    }

    public OpenRA.Primitives.Color get_DarkOrange()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_DarkOrange();
        return v0;
    }

    public OpenRA.Primitives.Color get_DarkRed()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_DarkRed();
        return v0;
    }

    public OpenRA.Primitives.Color get_Fuchsia()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Fuchsia();
        return v0;
    }

    public OpenRA.Primitives.Color get_Gold()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Gold();
        return v0;
    }

    public OpenRA.Primitives.Color get_Gray()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Gray();
        return v0;
    }

    public OpenRA.Primitives.Color get_Green()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Green();
        return v0;
    }

    public OpenRA.Primitives.Color get_LawnGreen()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_LawnGreen();
        return v0;
    }

    public OpenRA.Primitives.Color get_LightBlue()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_LightBlue();
        return v0;
    }

    public OpenRA.Primitives.Color get_LightCyan()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_LightCyan();
        return v0;
    }

    public OpenRA.Primitives.Color get_LightGray()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_LightGray();
        return v0;
    }

    public OpenRA.Primitives.Color get_LightGreen()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_LightGreen();
        return v0;
    }

    public OpenRA.Primitives.Color get_LightYellow()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_LightYellow();
        return v0;
    }

    public OpenRA.Primitives.Color get_Lime()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Lime();
        return v0;
    }

    public OpenRA.Primitives.Color get_LimeGreen()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_LimeGreen();
        return v0;
    }

    public OpenRA.Primitives.Color get_Magenta()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Magenta();
        return v0;
    }

    public OpenRA.Primitives.Color get_Maroon()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Maroon();
        return v0;
    }

    public OpenRA.Primitives.Color get_Navy()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Navy();
        return v0;
    }

    public OpenRA.Primitives.Color get_Olive()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Olive();
        return v0;
    }

    public OpenRA.Primitives.Color get_Orange()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Orange();
        return v0;
    }

    public OpenRA.Primitives.Color get_OrangeRed()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_OrangeRed();
        return v0;
    }

    public OpenRA.Primitives.Color get_Purple()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Purple();
        return v0;
    }

    public OpenRA.Primitives.Color get_Red()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Red();
        return v0;
    }

    public OpenRA.Primitives.Color get_Salmon()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Salmon();
        return v0;
    }

    public OpenRA.Primitives.Color get_SkyBlue()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_SkyBlue();
        return v0;
    }

    public OpenRA.Primitives.Color get_Teal()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Teal();
        return v0;
    }

    public OpenRA.Primitives.Color get_Yellow()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_Yellow();
        return v0;
    }

    public OpenRA.Primitives.Color get_White()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [OpenRA.Game]OpenRA.Primitives.Color; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v0 = OpenRA.Primitives.Color.get_White();
        return v0;
    }
    // property OpenRA.Primitives.Color Aqua { get: get_Aqua; }
    // property OpenRA.Primitives.Color Black { get: get_Black; }
    // property OpenRA.Primitives.Color Blue { get: get_Blue; }
    // property OpenRA.Primitives.Color Brown { get: get_Brown; }
    // property OpenRA.Primitives.Color Cyan { get: get_Cyan; }
    // property OpenRA.Primitives.Color DarkBlue { get: get_DarkBlue; }
    // property OpenRA.Primitives.Color DarkCyan { get: get_DarkCyan; }
    // property OpenRA.Primitives.Color DarkGray { get: get_DarkGray; }
    // property OpenRA.Primitives.Color DarkGreen { get: get_DarkGreen; }
    // property OpenRA.Primitives.Color DarkOrange { get: get_DarkOrange; }
    // property OpenRA.Primitives.Color DarkRed { get: get_DarkRed; }
    // property OpenRA.Primitives.Color Fuchsia { get: get_Fuchsia; }
    // property OpenRA.Primitives.Color Gold { get: get_Gold; }
    // property OpenRA.Primitives.Color Gray { get: get_Gray; }
    // property OpenRA.Primitives.Color Green { get: get_Green; }
    // property OpenRA.Primitives.Color LawnGreen { get: get_LawnGreen; }
    // property OpenRA.Primitives.Color LightBlue { get: get_LightBlue; }
    // property OpenRA.Primitives.Color LightCyan { get: get_LightCyan; }
    // property OpenRA.Primitives.Color LightGray { get: get_LightGray; }
    // property OpenRA.Primitives.Color LightGreen { get: get_LightGreen; }
    // property OpenRA.Primitives.Color LightYellow { get: get_LightYellow; }
    // property OpenRA.Primitives.Color Lime { get: get_Lime; }
    // property OpenRA.Primitives.Color LimeGreen { get: get_LimeGreen; }
    // property OpenRA.Primitives.Color Magenta { get: get_Magenta; }
    // property OpenRA.Primitives.Color Maroon { get: get_Maroon; }
    // property OpenRA.Primitives.Color Navy { get: get_Navy; }
    // property OpenRA.Primitives.Color Olive { get: get_Olive; }
    // property OpenRA.Primitives.Color Orange { get: get_Orange; }
    // property OpenRA.Primitives.Color OrangeRed { get: get_OrangeRed; }
    // property OpenRA.Primitives.Color Purple { get: get_Purple; }
    // property OpenRA.Primitives.Color Red { get: get_Red; }
    // property OpenRA.Primitives.Color Salmon { get: get_Salmon; }
    // property OpenRA.Primitives.Color SkyBlue { get: get_SkyBlue; }
    // property OpenRA.Primitives.Color Teal { get: get_Teal; }
    // property OpenRA.Primitives.Color Yellow { get: get_Yellow; }
    // property OpenRA.Primitives.Color White { get: get_White; }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.DriveInfo, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.DriveInfo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Tasks.Parallel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Tasks.Parallel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.Win32.Registry, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.Win32.Registry, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 11; exact references retained; see --details for identities and provenance.
