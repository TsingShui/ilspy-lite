namespace OpenRA.Mods.Common.Traits;

public class ProductionQueue : OpenRA.Traits.IResolveOrder, OpenRA.Traits.ITick, OpenRA.Mods.Common.Traits.ITechTreeElement, OpenRA.Traits.INotifyOwnerChanged, OpenRA.Mods.Common.Traits.INotifyKilled, OpenRA.Mods.Common.Traits.INotifySold, OpenRA.ISync, OpenRA.Mods.Common.Traits.INotifyTransform, OpenRA.Traits.INotifyCreated
{
    public readonly OpenRA.Mods.Common.Traits.ProductionQueueInfo Info;
    protected readonly System.Collections.Generic.Dictionary<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState> Producible;
    protected readonly System.Collections.Generic.List<OpenRA.Mods.Common.Traits.ProductionItem> Queue;
    private readonly System.Collections.Generic.IEnumerable<OpenRA.ActorInfo> allProducibles;
    private readonly System.Collections.Generic.IEnumerable<OpenRA.ActorInfo> buildableProducibles;
    protected OpenRA.Mods.Common.Traits.Production[] productionTraits;
    private OpenRA.Mods.Common.Traits.PowerManager playerPower;
    protected OpenRA.Mods.Common.Traits.PlayerResources playerResources;
    protected OpenRA.Mods.Common.Traits.DeveloperMode developerMode;
    protected OpenRA.Mods.Common.Traits.TechTree techTree;
    private readonly OpenRA.Actor __il_field_04001542;
    private bool __il_field_04001543;
    private string __il_field_04001544;
    private bool __il_field_04001545;

    public OpenRA.Actor get_Actor()
    {
        __cil_type_01000025 v1 = this.__il_field_04001542;
        return v1;
    }

    public bool get_Enabled()
    {
        return this.__il_field_04001543;
    }

    protected void set_Enabled(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04001543 = __cil_bool_store(v1);
        return;
    }

    public string get_Faction()
    {
        string v1 = this.__il_field_04001544;
        return v1;
    }

    private void set_Faction(string value)
    {
        this.__il_field_04001544 = value;
        return;
    }

    public bool get_IsValidFaction()
    {
        return this.__il_field_04001545;
    }

    private void set_IsValidFaction(bool value)
    {
        int v1 = __cil_bool_load(value);
        this.__il_field_04001545 = __cil_bool_store(v1);
        return;
    }

    public ProductionQueue(OpenRA.ActorInitializer init, OpenRA.Mods.Common.Traits.ProductionQueueInfo info)
    {
        // IL fallback: generic virtual dispatch needs runtime lookup-order modeling
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [02, 73, C1, 15, 00, 0A, 7D, 39, 15, 00, 04, 02, 73, C2, 15, 00, 0A, 7D, 3A, 15, 00, 04, 02, 28]
        // .code-bytes IL_0018: [09, 01, 00, 0A, 02, 03, 7B, 1E, 07, 00, 0A, 7D, 42, 15, 00, 04, 02, 04, 7D, 38, 15, 00, 04, 02]
        // .code-bytes IL_0030: [03, 02, 28, 58, 19, 00, 06, 6F, 60, 01, 00, 0A, 7B, 9B, 06, 00, 0A, 7B, 9C, 06, 00, 0A, 6F, D3]
        // .code-bytes IL_0048: [04, 00, 2B, 28, 5C, 19, 00, 06, 02, 04, 7B, 22, 15, 00, 04, 6F, 9F, 02, 00, 0A, 2C, 13, 04, 7B]
        // .code-bytes IL_0060: [22, 15, 00, 04, 02, 28, 5B, 19, 00, 06, 6F, A0, 02, 00, 0A, 2B, 01, 17, 28, 5E, 19, 00, 06, 02]
        // .code-bytes IL_0078: [02, 28, 5D, 19, 00, 06, 28, 5A, 19, 00, 06, 02, 02, 7B, 39, 15, 00, 04, 7E, 48, 35, 00, 04, 25]
        // .code-bytes IL_0090: [2D, 17, 26, 7E, 47, 35, 00, 04, FE, 06, 0A, 40, 00, 06, 73, C3, 15, 00, 0A, 25, 80, 48, 35, 00]
        // .code-bytes IL_00A8: [04, 28, 59, 06, 00, 2B, 7E, 49, 35, 00, 04, 25, 2D, 17, 26, 7E, 47, 35, 00, 04, FE, 06, 0B, 40]
        // .code-bytes IL_00C0: [00, 06, 73, C4, 15, 00, 0A, 25, 80, 49, 35, 00, 04, 28, 5A, 06, 00, 2B, 7D, 3B, 15, 00, 04, 02]
        // .code-bytes IL_00D8: [02, 7B, 39, 15, 00, 04, 7E, 4A, 35, 00, 04, 25, 2D, 17, 26, 7E, 47, 35, 00, 04, FE, 06, 0C, 40]
        // .code-bytes IL_00F0: [00, 06, 73, C3, 15, 00, 0A, 25, 80, 4A, 35, 00, 04, 28, 59, 06, 00, 2B, 7E, 4B, 35, 00, 04, 25]
        // .code-bytes IL_0108: [2D, 17, 26, 7E, 47, 35, 00, 04, FE, 06, 0D, 40, 00, 06, 73, C4, 15, 00, 0A, 25, 80, 4B, 35, 00]
        // .code-bytes IL_0120: [04, 28, 5A, 06, 00, 2B, 7D, 3C, 15, 00, 04, 2A]
        // IL_0000: ldarg.0 0
        // IL_0001: newobj 0x0A0015C1 class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>::.ctor
        // IL_0006: stfld 0x04001539 OpenRA.Mods.Common.Traits.ProductionQueue::Producible
        // IL_000B: ldarg.0 0
        // IL_000C: newobj 0x0A0015C2 class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>::.ctor
        // IL_0011: stfld 0x0400153A OpenRA.Mods.Common.Traits.ProductionQueue::Queue
        // IL_0016: ldarg.0 0
        // IL_0017: call 0x0A000109 [System.Runtime]System.Object::.ctor
        // IL_001C: ldarg.0 0
        // IL_001D: ldarg.1 1
        // IL_001E: ldfld 0x0A00071E [OpenRA.Game]OpenRA.ActorInitializer::Self
        // IL_0023: stfld 0x04001542 OpenRA.Mods.Common.Traits.ProductionQueue::<Actor>k__BackingField
        // IL_0028: ldarg.0 0
        // IL_0029: ldarg.2 2
        // IL_002A: stfld 0x04001538 OpenRA.Mods.Common.Traits.ProductionQueue::Info
        // IL_002F: ldarg.0 0
        // IL_0030: ldarg.1 1
        // IL_0031: ldarg.0 0
        // IL_0032: call 0x06001958 OpenRA.Mods.Common.Traits.ProductionQueue::get_Actor
        // IL_0037: callvirt 0x0A000160 [OpenRA.Game]OpenRA.Actor::get_Owner
        // IL_003C: ldfld 0x0A00069B [OpenRA.Game]OpenRA.Player::Faction
        // IL_0041: ldfld 0x0A00069C [OpenRA.Game]OpenRA.Traits.FactionInfo::InternalName
        // IL_0046: callvirt 0x2B0004D3 [OpenRA.Game]OpenRA.ActorInitializer::GetValue<class OpenRA.Mods.Common.FactionInit, string>
        // IL_004B: call 0x0600195C OpenRA.Mods.Common.Traits.ProductionQueue::set_Faction
        // IL_0050: ldarg.0 0
        // IL_0051: ldarg.2 2
        // IL_0052: ldfld 0x04001522 OpenRA.Mods.Common.Traits.ProductionQueueInfo::Factions
        // IL_0057: callvirt 0x0A00029F class [System.Collections]System.Collections.Generic.HashSet`1<string>::get_Count
        // IL_005C: brfalse.s IL_0071
        // IL_005E: ldarg.2 2
        // IL_005F: ldfld 0x04001522 OpenRA.Mods.Common.Traits.ProductionQueueInfo::Factions
        // IL_0064: ldarg.0 0
        // IL_0065: call 0x0600195B OpenRA.Mods.Common.Traits.ProductionQueue::get_Faction
        // IL_006A: callvirt 0x0A0002A0 class [System.Collections]System.Collections.Generic.HashSet`1<string>::Contains
        // IL_006F: br.s IL_0072
        // IL_0071: ldc.i4.1 1
        // IL_0072: call 0x0600195E OpenRA.Mods.Common.Traits.ProductionQueue::set_IsValidFaction
        // IL_0077: ldarg.0 0
        // IL_0078: ldarg.0 0
        // IL_0079: call 0x0600195D OpenRA.Mods.Common.Traits.ProductionQueue::get_IsValidFaction
        // IL_007E: call 0x0600195A OpenRA.Mods.Common.Traits.ProductionQueue::set_Enabled
        // IL_0083: ldarg.0 0
        // IL_0084: ldarg.0 0
        // IL_0085: ldfld 0x04001539 OpenRA.Mods.Common.Traits.ProductionQueue::Producible
        // IL_008A: ldsfld 0x04003548 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_0
        // IL_008F: dup 
        // IL_0090: brtrue.s IL_00A9
        // IL_0092: pop 
        // IL_0093: ldsfld 0x04003547 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9
        // IL_0098: ldftn 0x0600400A OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<.ctor>b__25_0
        // IL_009E: newobj 0x0A0015C3 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>, bool>::.ctor
        // IL_00A3: dup 
        // IL_00A4: stsfld 0x04003548 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_0
        // IL_00A9: call 0x2B000659 [System.Linq]System.Linq.Enumerable::Where<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>>
        // IL_00AE: ldsfld 0x04003549 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_1
        // IL_00B3: dup 
        // IL_00B4: brtrue.s IL_00CD
        // IL_00B6: pop 
        // IL_00B7: ldsfld 0x04003547 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9
        // IL_00BC: ldftn 0x0600400B OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<.ctor>b__25_1
        // IL_00C2: newobj 0x0A0015C4 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>, class [OpenRA.Game]OpenRA.ActorInfo>::.ctor
        // IL_00C7: dup 
        // IL_00C8: stsfld 0x04003549 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_1
        // IL_00CD: call 0x2B00065A [System.Linq]System.Linq.Enumerable::Select<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>, class [OpenRA.Game]OpenRA.ActorInfo>
        // IL_00D2: stfld 0x0400153B OpenRA.Mods.Common.Traits.ProductionQueue::allProducibles
        // IL_00D7: ldarg.0 0
        // IL_00D8: ldarg.0 0
        // IL_00D9: ldfld 0x04001539 OpenRA.Mods.Common.Traits.ProductionQueue::Producible
        // IL_00DE: ldsfld 0x0400354A OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_2
        // IL_00E3: dup 
        // IL_00E4: brtrue.s IL_00FD
        // IL_00E6: pop 
        // IL_00E7: ldsfld 0x04003547 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9
        // IL_00EC: ldftn 0x0600400C OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<.ctor>b__25_2
        // IL_00F2: newobj 0x0A0015C3 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>, bool>::.ctor
        // IL_00F7: dup 
        // IL_00F8: stsfld 0x0400354A OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_2
        // IL_00FD: call 0x2B000659 [System.Linq]System.Linq.Enumerable::Where<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>>
        // IL_0102: ldsfld 0x0400354B OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_3
        // IL_0107: dup 
        // IL_0108: brtrue.s IL_0121
        // IL_010A: pop 
        // IL_010B: ldsfld 0x04003547 OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9
        // IL_0110: ldftn 0x0600400D OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<.ctor>b__25_3
        // IL_0116: newobj 0x0A0015C4 class [System.Runtime]System.Func`2<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>, class [OpenRA.Game]OpenRA.ActorInfo>::.ctor
        // IL_011B: dup 
        // IL_011C: stsfld 0x0400354B OpenRA.Mods.Common.Traits.ProductionQueue/<>c::<>9__25_3
        // IL_0121: call 0x2B00065A [System.Linq]System.Linq.Enumerable::Select<valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>, class [OpenRA.Game]OpenRA.ActorInfo>
        // IL_0126: stfld 0x0400153C OpenRA.Mods.Common.Traits.ProductionQueue::buildableProducibles
        // IL_012B: ret 
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F74696679437265617465642E43726561746564(OpenRA.Actor self)
    {
        // structural signature __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 bytes=151280A101129420: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de bytes=151281210212942002: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.Production, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 bytes=1D129420: class OpenRA.Mods.Common.Traits.Production[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000030 v2 = ((OpenRA.Actor)self).Owner;
        __cil_type_01000025 v3 = v2.PlayerActor;
        global::OpenRA.Mods.Common.Traits.PowerManager v4 = __cil_callvirt_2B0003DE(v3);
        this.playerPower = v4;
        __cil_type_01000030 v7 = ((OpenRA.Actor)self).Owner;
        __cil_type_01000025 v8 = v7.PlayerActor;
        global::OpenRA.Mods.Common.Traits.PlayerResources v9 = __cil_callvirt_2B000195(v8);
        this.playerResources = v9;
        __cil_type_01000030 v12 = ((OpenRA.Actor)self).Owner;
        __cil_type_01000025 v13 = v12.PlayerActor;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v14 = __cil_callvirt_2B00039D(v13);
        this.developerMode = v14;
        __cil_type_01000030 v17 = ((OpenRA.Actor)self).Owner;
        __cil_type_01000025 v18 = v17.PlayerActor;
        global::OpenRA.Mods.Common.Traits.TechTree v19 = __cil_callvirt_2B0005C7(v18);
        this.techTree = v19;
        __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 v22 = __cil_callvirt_2B000187(self);
        nint v24 = __cil_ldftn_06001987;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v25 = __cil_newobj_0A001309(this, v24);
        __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 v26 = __cil_methodspec_call_2B00056B(v22, v25);
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v27 = __cil_methodspec_call_2B000188(v26);
        this.productionTraits = v27;
        __cil_direct_06001969(this);
        return;
    }

    protected void ClearQueue()
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_bf76482d0d9dd3fdbd4330e5362ee113342a6a90 bytes=1511824D011293A4: valuetype [System.Collections]System.Collections.Generic.List`1/Enumerator<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_value_bf76482d0d9dd3fdbd4330e5362ee113342a6a90 l0 = default;
        OpenRA.Mods.Common.Traits.ProductionItem l1 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v0 = this;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v1 = v0.Queue;
        __cil_value_bf76482d0d9dd3fdbd4330e5362ee113342a6a90 v2 = __cil_callvirt_0A001561(v1);
        l0 = v2;
        try {
            IL_000C: ;
            goto IL_005B;
            IL_000E: ;
            ref __cil_value_bf76482d0d9dd3fdbd4330e5362ee113342a6a90 v3 = ref l0;
            global::OpenRA.Mods.Common.Traits.ProductionItem v4 = __cil_value_call_0A001562(ref v3);
            l1 = v4;
            global::OpenRA.Mods.Common.Traits.ProductionItem v5 = l1;
            int v6 = __cil_callvirt_06001994(v5);
            int v7 = 0;
            if (v6 <= v7) {
                goto IL_0043;
            } else {
                goto IL_001F;
            }
            IL_001F: ;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v8 = this;
            global::OpenRA.Mods.Common.Traits.PlayerResources v9 = v8.playerResources;
            global::OpenRA.Mods.Common.Traits.ProductionItem v10 = l1;
            int v11 = __cil_callvirt_06001994(v10);
            __cil_callvirt_0600193B(v9, v11);
            global::OpenRA.Mods.Common.Traits.ProductionItem v12 = l1;
            int v13 = __cil_callvirt_06001992(v12);
            global::OpenRA.Mods.Common.Traits.ProductionItem v14 = l1;
            int v15 = __cil_callvirt_06001994(v14);
            int v16 = unchecked(v13 + v15);
            __cil_callvirt_06001993(v12, v16);
            goto IL_0043;
            IL_0043: ;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v17 = this;
            global::OpenRA.Mods.Common.Traits.PlayerResources v18 = v17.playerResources;
            global::OpenRA.Mods.Common.Traits.ProductionItem v19 = l1;
            int v20 = v19.TotalCost;
            global::OpenRA.Mods.Common.Traits.ProductionItem v21 = l1;
            int v22 = __cil_callvirt_06001992(v21);
            int v23 = unchecked(v20 - v22);
            __cil_callvirt_0600193D(v18, v23);
            goto IL_005B;
            IL_005B: ;
            ref __cil_value_bf76482d0d9dd3fdbd4330e5362ee113342a6a90 v24 = ref l0;
            int v25 = __cil_bool_load(__cil_value_call_0A001565(ref v24));
            if (v25 != 0) {
                goto IL_000E;
            } else {
                goto IL_0064;
            }
            IL_0064: ;
            goto IL_0074;
        }
        finally {
            IL_0066: ;
            ref __cil_value_bf76482d0d9dd3fdbd4330e5362ee113342a6a90 v26 = ref l0;
            __cil_constrained_1B0007C6_0A00001A(ref v26);
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0074: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v27 = this;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v28 = v27.Queue;
        __cil_callvirt_0A0015C5(v28);
        return;
    }

    private virtual void __name_4F70656E52412E5472616974732E494E6F746966794F776E65724368616E6765642E4F6E4F776E65724368616E676564(OpenRA.Actor self, OpenRA.Player oldOwner, OpenRA.Player newOwner)
    {
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ProductionQueue s2_0 = default;
        OpenRA.Mods.Common.Traits.ProductionQueue s3_0 = default;
        OpenRA.Mods.Common.Traits.ProductionQueue s4_0 = default;
        int s4_1 = default;
        __cil_direct_06001961(this);
        __cil_type_01000025 v3 = newOwner.PlayerActor;
        global::OpenRA.Mods.Common.Traits.PowerManager v4 = __cil_callvirt_2B0003DE(v3);
        this.playerPower = v4;
        __cil_type_01000025 v7 = newOwner.PlayerActor;
        global::OpenRA.Mods.Common.Traits.PlayerResources v8 = __cil_callvirt_2B000195(v7);
        this.playerResources = v8;
        __cil_type_01000025 v11 = newOwner.PlayerActor;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v12 = __cil_callvirt_2B00039D(v11);
        this.developerMode = v12;
        __cil_type_01000025 v15 = newOwner.PlayerActor;
        global::OpenRA.Mods.Common.Traits.TechTree v16 = __cil_callvirt_2B0005C7(v15);
        this.techTree = v16;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v18 = this.Info;
        int v19 = __cil_bool_load(v18.Sticky);
        if (v19 != 0) {
            goto IL_009E;
        } else {
            goto IL_0057;
        }
        IL_0057: ;
        __cil_type_01000030 v22 = ((OpenRA.Actor)self).Owner;
        __cil_type_010000F5 v23 = v22.Faction;
        string v24 = v23.InternalName;
        this.Faction = v24;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v27 = this.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v28 = v27.Factions;
        int v29 = __cil_callvirt_0A00029F(v28);
        if (v29 == 0) {
            OpenRA.Mods.Common.Traits.ProductionQueue e1_3_0 = this;
            s3_0 = e1_3_0;
            goto IL_0098;
        } else {
            OpenRA.Mods.Common.Traits.ProductionQueue e1_2_0 = this;
            s2_0 = e1_2_0;
            goto IL_0080;
        }
        IL_0080: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v31 = this.Info;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v32 = v31.Factions;
        string v34 = this.Faction;
        int v35 = __cil_bool_load(__cil_callvirt_0A0002A0(v32, v34));
        OpenRA.Mods.Common.Traits.ProductionQueue e2_4_0 = s2_0;
        int e2_4_1 = v35;
        s4_0 = e2_4_0;
        s4_1 = e2_4_1;
        goto IL_0099;
        IL_0098: ;
        OpenRA.Mods.Common.Traits.ProductionQueue e3_4_0 = s3_0;
        int e3_4_1 = 1;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        IL_0099: ;
        __cil_direct_0600195E(s4_0, __cil_bool_store(s4_1));
        IL_009E: ;
        __cil_type_01000025 v38 = oldOwner.PlayerActor;
        global::OpenRA.Mods.Common.Traits.TechTree v39 = __cil_callvirt_2B0005C7(v38);
        __cil_callvirt_060019CE(v39, ((OpenRA.Mods.Common.Traits.ITechTreeElement)(this)));
        __cil_direct_06001969(this);
        global::OpenRA.Mods.Common.Traits.TechTree v43 = this.techTree;
        __cil_callvirt_060019CB(v43);
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494E6F746966794B696C6C65642E4B696C6C6564(OpenRA.Actor killed, OpenRA.Traits.AttackInfo e)
    {
        __cil_type_01000025 v2 = this.Actor;
        if (!System.Object.ReferenceEquals(killed, v2)) {
            goto IL_0016;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        __cil_direct_06001961(this);
        this.Enabled = __cil_bool_store(0);
        IL_0016: ;
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494E6F74696679536F6C642E53656C6C696E67(OpenRA.Actor self)
    {
        __cil_direct_06001961(this);
        this.Enabled = __cil_bool_store(0);
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494E6F74696679536F6C642E536F6C64(OpenRA.Actor self)
    {
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494E6F746966795472616E73666F726D2E4265666F72655472616E73666F726D(OpenRA.Actor self)
    {
        __cil_direct_06001961(this);
        this.Enabled = __cil_bool_store(0);
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494E6F746966795472616E73666F726D2E4F6E5472616E73666F726D(OpenRA.Actor self)
    {
        return;
    }

    private virtual void __name_4F70656E52412E4D6F64732E436F6D6D6F6E2E5472616974732E494E6F746966795472616E73666F726D2E41667465725472616E73666F726D(OpenRA.Actor self)
    {
        return;
    }

    private void CacheProducibles()
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c7dcdb1ec6cd6a419ab6c648f9caa3b0c81e46ec bytes=151280A501128421: class [System.Runtime]System.Collections.Generic.IEnumerator`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd bytes=151280A101128421: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_c7dcdb1ec6cd6a419ab6c648f9caa3b0c81e46ec l0 = default;
        __cil_type_01000108 l1 = default;
        OpenRA.Mods.Common.Traits.BuildableInfo l2 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v0 = this;
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v1 = v0.Producible;
        __cil_callvirt_0A0015C6(v1);
        global::OpenRA.Mods.Common.Traits.ProductionQueue v2 = this;
        int v3 = __cil_bool_load(__cil_direct_06001959(v2));
        if (v3 != 0) {
            goto IL_0014;
        } else {
            goto IL_0013;
        }
        IL_0013: ;
        return;
        IL_0014: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v4 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v5 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v6 = v5.Info;
        string v7 = v6.Type;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v8 = __cil_direct_0600196A(v4, v7);
        __cil_ref_c7dcdb1ec6cd6a419ab6c648f9caa3b0c81e46ec v9 = __cil_callvirt_0A000C70(v8);
        l0 = v9;
        try {
            IL_002B: ;
            goto IL_006A;
            IL_002D: ;
            __cil_ref_c7dcdb1ec6cd6a419ab6c648f9caa3b0c81e46ec v10 = l0;
            __cil_type_01000108 v11 = __cil_callvirt_0A000C71(v10);
            l1 = v11;
            __cil_type_01000108 v12 = l1;
            global::OpenRA.Mods.Common.Traits.BuildableInfo v13 = __cil_callvirt_2B000189(v12);
            l2 = v13;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v14 = this;
            __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v15 = v14.Producible;
            __cil_type_01000108 v16 = l1;
            global::OpenRA.Mods.Common.Traits.ProductionState v17 = __cil_newobj_0600198D();
            __cil_callvirt_0A0015C7(v15, v16, v17);
            global::OpenRA.Mods.Common.Traits.ProductionQueue v18 = this;
            global::OpenRA.Mods.Common.Traits.TechTree v19 = v18.techTree;
            __cil_type_01000108 v20 = l1;
            string v21 = v20.Name;
            global::OpenRA.Mods.Common.Traits.BuildableInfo v22 = l2;
            __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v23 = v22.Prerequisites;
            global::OpenRA.Mods.Common.Traits.BuildableInfo v24 = l2;
            int v25 = v24.BuildLimit;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v26 = this;
            __cil_callvirt_060019CC(v19, v21, v23, v25, ((OpenRA.Mods.Common.Traits.ITechTreeElement)(v26)));
            goto IL_006A;
            IL_006A: ;
            __cil_ref_c7dcdb1ec6cd6a419ab6c648f9caa3b0c81e46ec v27 = l0;
            int v28 = __cil_bool_load(__cil_callvirt_0A00001B(v27));
            if (v28 != 0) {
                goto IL_002D;
            } else {
                goto IL_0072;
            }
            IL_0072: ;
            goto IL_007E;
        }
        finally {
            IL_0074: ;
            __cil_ref_c7dcdb1ec6cd6a419ab6c648f9caa3b0c81e46ec v29 = l0;
            if (v29 is null) {
                goto IL_007D;
            } else {
                goto IL_0077;
            }
            IL_0077: ;
            __cil_ref_c7dcdb1ec6cd6a419ab6c648f9caa3b0c81e46ec v30 = l0;
            __cil_callvirt_0A00001A(v30);
            goto IL_007D;
            IL_007D: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_007E: ;
        return;
    }

    private System.Collections.Generic.IEnumerable<OpenRA.ActorInfo> AllBuildables(string category)
    {
        // structural signature __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd bytes=151280A101128421: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e893aee215eb6d7eaf97610e4fd3c7c2812f12ad bytes=15128A4D01128421: class [System.Runtime]System.Collections.Generic.ICollection`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_6067161193c4aa3959efe989341e7b0d64a6a482 bytes=151281210212842102: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.ActorInfo, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737333365F30 v0 = __cil_newobj_06004013();
        v0.category = category;
        __cil_type_01000025 v4 = this.Actor;
        __cil_type_0100002D v5 = v4.World;
        __cil_type_01000026 v6 = v5.Map;
        __cil_type_0100007F v7 = ((OpenRA.Map)v6).Rules;
        __cil_type_01000277 v8 = v7.Actors;
        __cil_ref_e893aee215eb6d7eaf97610e4fd3c7c2812f12ad v9 = __cil_callvirt_0A000664(v8);
        nint v11 = __cil_ldftn_06004014;
        __cil_ref_6067161193c4aa3959efe989341e7b0d64a6a482 v12 = __cil_newobj_0A000C2F(v0, v11);
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v13 = __cil_methodspec_call_2B0004F1(((__cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd)(v9)), v12);
        return v13;
    }

    public virtual void PrerequisitesAvailable(string key)
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v1 = this.Producible;
        __cil_type_01000025 v3 = this.Actor;
        __cil_type_0100002D v4 = v3.World;
        __cil_type_01000026 v5 = v4.Map;
        __cil_type_0100007F v6 = ((OpenRA.Map)v5).Rules;
        __cil_type_01000277 v7 = v6.Actors;
        __cil_type_01000108 v9 = __cil_callvirt_0A000710(v7, key);
        global::OpenRA.Mods.Common.Traits.ProductionState v10 = __cil_callvirt_0A0015C8(v1, v9);
        v10.Buildable = __cil_bool_store(1);
        return;
    }

    public virtual void PrerequisitesUnavailable(string key)
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v1 = this.Producible;
        __cil_type_01000025 v3 = this.Actor;
        __cil_type_0100002D v4 = v3.World;
        __cil_type_01000026 v5 = v4.Map;
        __cil_type_0100007F v6 = ((OpenRA.Map)v5).Rules;
        __cil_type_01000277 v7 = v6.Actors;
        __cil_type_01000108 v9 = __cil_callvirt_0A000710(v7, key);
        global::OpenRA.Mods.Common.Traits.ProductionState v10 = __cil_callvirt_0A0015C8(v1, v9);
        v10.Buildable = __cil_bool_store(0);
        return;
    }

    public virtual void PrerequisitesItemHidden(string key)
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v1 = this.Producible;
        __cil_type_01000025 v3 = this.Actor;
        __cil_type_0100002D v4 = v3.World;
        __cil_type_01000026 v5 = v4.Map;
        __cil_type_0100007F v6 = ((OpenRA.Map)v5).Rules;
        __cil_type_01000277 v7 = v6.Actors;
        __cil_type_01000108 v9 = __cil_callvirt_0A000710(v7, key);
        global::OpenRA.Mods.Common.Traits.ProductionState v10 = __cil_callvirt_0A0015C8(v1, v9);
        v10.Visible = __cil_bool_store(0);
        return;
    }

    public virtual void PrerequisitesItemVisible(string key)
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v1 = this.Producible;
        __cil_type_01000025 v3 = this.Actor;
        __cil_type_0100002D v4 = v3.World;
        __cil_type_01000026 v5 = v4.Map;
        __cil_type_0100007F v6 = ((OpenRA.Map)v5).Rules;
        __cil_type_01000277 v7 = v6.Actors;
        __cil_type_01000108 v9 = __cil_callvirt_0A000710(v7, key);
        global::OpenRA.Mods.Common.Traits.ProductionState v10 = __cil_callvirt_0A0015C8(v1, v9);
        v10.Visible = __cil_bool_store(1);
        return;
    }

    public virtual bool IsProducing(OpenRA.Mods.Common.Traits.ProductionItem item)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v1 = this.Queue;
        int v2 = __cil_callvirt_0A000C3A(v1);
        if (v2 <= 0) {
            return false;
        } else {
            goto IL_000E;
        }
        IL_000E: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v5 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionItem v7 = __cil_callvirt_0A000C2E(v5, 0);
        return (System.Object.ReferenceEquals(v7, item));
    }

    public virtual bool IsInQueue(OpenRA.ActorInfo actor)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a bytes=15128121021293A402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ProductionItem, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737334325F30 v0 = __cil_newobj_06004015();
        v0.actor = actor;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v4 = this.Queue;
        nint v6 = __cil_ldftn_06004016;
        __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v7 = __cil_newobj_0A00083A(v0, v6);
        return __cil_methodspec_call_2B00030F(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v4)), v7);
    }

    public OpenRA.Mods.Common.Traits.ProductionItem CurrentItem()
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v1 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionItem v3 = __cil_methodspec_call_2B00065B(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v1)), 0);
        return v3;
    }

    public virtual System.Collections.Generic.IEnumerable<OpenRA.Mods.Common.Traits.ProductionItem> AllQueued()
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v1 = this.Queue;
        return v1;
    }

    public virtual System.Collections.Generic.IEnumerable<OpenRA.ActorInfo> AllItems()
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 bytes=151280A101129420: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de bytes=151281210212942002: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.Production, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 bytes=1D129420: class OpenRA.Mods.Common.Traits.Production[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd bytes=151280A101128421: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d584bde60a0ba63454af17d65ecf7caa94573da8 bytes=15128809021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2/KeyCollection<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 s2_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s2_1 = default;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 s3_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s3_1 = default;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v1 = this.productionTraits;
        nint v2 = unchecked((nint)(v1.LongLength));
        if (v2 == 0) {
            goto IL_003B;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v4 = this.productionTraits;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v5 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354C;
        if (v5 is not null) {
            __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e1_3_0 = v4;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e1_3_1 = v5;
            s3_0 = e1_3_0;
            s3_1 = e1_3_1;
            goto IL_002E;
        } else {
            __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e1_2_0 = v4;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e1_2_1 = v5;
            s2_0 = e1_2_0;
            s2_1 = e1_2_1;
            goto IL_0017;
        }
        IL_0017: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63 v6 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003547;
        nint v7 = __cil_ldftn_0600400E;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v8 = __cil_newobj_0A001309(v6, v7);
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354C = v8;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e2_3_0 = s2_0;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e2_3_1 = v8;
        s3_0 = e2_3_0;
        s3_1 = e2_3_1;
        IL_002E: ;
        int v9 = __cil_bool_load(__cil_methodspec_call_2B00065C(((__cil_ref_27a29a4ee766e95f28798e78786bf3288a065108)(s3_0)), s3_1));
        if (v9 == 0) {
            goto IL_003B;
        } else {
            goto IL_0035;
        }
        IL_0035: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v10 = __cil_methodspec_call_2B0002F7();
        return v10;
        IL_003B: ;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v12 = this.developerMode;
        int v13 = __cil_bool_load(__cil_callvirt_060018B1(v12));
        if (v13 == 0) {
            goto IL_0054;
        } else {
            goto IL_0048;
        }
        IL_0048: ;
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v15 = this.Producible;
        __cil_ref_d584bde60a0ba63454af17d65ecf7caa94573da8 v16 = __cil_callvirt_0A0015CA(v15);
        return v16;
        IL_0054: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v18 = this.allProducibles;
        return v18;
    }

    public virtual System.Collections.Generic.IEnumerable<OpenRA.ActorInfo> BuildableItems()
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 bytes=151280A101129420: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de bytes=151281210212942002: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.Production, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 bytes=1D129420: class OpenRA.Mods.Common.Traits.Production[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd bytes=151280A101128421: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_6067161193c4aa3959efe989341e7b0d64a6a482 bytes=151281210212842102: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.ActorInfo, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d584bde60a0ba63454af17d65ecf7caa94573da8 bytes=15128809021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2/KeyCollection<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 s2_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s2_1 = default;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 s3_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s3_1 = default;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v1 = this.productionTraits;
        nint v2 = unchecked((nint)(v1.LongLength));
        if (v2 == 0) {
            goto IL_003B;
        } else {
            goto IL_0009;
        }
        IL_0009: ;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v4 = this.productionTraits;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v5 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354D;
        if (v5 is not null) {
            __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e1_3_0 = v4;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e1_3_1 = v5;
            s3_0 = e1_3_0;
            s3_1 = e1_3_1;
            goto IL_002E;
        } else {
            __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e1_2_0 = v4;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e1_2_1 = v5;
            s2_0 = e1_2_0;
            s2_1 = e1_2_1;
            goto IL_0017;
        }
        IL_0017: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63 v6 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003547;
        nint v7 = __cil_ldftn_0600400F;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v8 = __cil_newobj_0A001309(v6, v7);
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354D = v8;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e2_3_0 = s2_0;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e2_3_1 = v8;
        s3_0 = e2_3_0;
        s3_1 = e2_3_1;
        IL_002E: ;
        int v9 = __cil_bool_load(__cil_methodspec_call_2B00065C(((__cil_ref_27a29a4ee766e95f28798e78786bf3288a065108)(s3_0)), s3_1));
        if (v9 == 0) {
            goto IL_003B;
        } else {
            goto IL_0035;
        }
        IL_0035: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v10 = __cil_methodspec_call_2B0002F7();
        return v10;
        IL_003B: ;
        int v12 = __cil_bool_load(this.Enabled);
        if (v12 != 0) {
            goto IL_0049;
        } else {
            goto IL_0043;
        }
        IL_0043: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v13 = __cil_methodspec_call_2B0002F7();
        return v13;
        IL_0049: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v15 = this.Info;
        int v16 = __cil_bool_load(v15.PayUpFront);
        if (v16 != 0) {
            goto IL_006F;
        } else {
            goto IL_0056;
        }
        IL_0056: ;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v18 = this.developerMode;
        int v19 = __cil_bool_load(__cil_callvirt_060018B1(v18));
        if (v19 == 0) {
            goto IL_006F;
        } else {
            goto IL_0063;
        }
        IL_0063: ;
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v21 = this.Producible;
        __cil_ref_d584bde60a0ba63454af17d65ecf7caa94573da8 v22 = __cil_callvirt_0A0015CA(v21);
        return v22;
        IL_006F: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v24 = this.Info;
        int v25 = __cil_bool_load(v24.PayUpFront);
        if (v25 == 0) {
            goto IL_00A6;
        } else {
            goto IL_007C;
        }
        IL_007C: ;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v27 = this.developerMode;
        int v28 = __cil_bool_load(__cil_callvirt_060018B1(v27));
        if (v28 == 0) {
            goto IL_00A6;
        } else {
            goto IL_0089;
        }
        IL_0089: ;
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v30 = this.Producible;
        __cil_ref_d584bde60a0ba63454af17d65ecf7caa94573da8 v31 = __cil_callvirt_0A0015CA(v30);
        nint v33 = __cil_ldftn_06001988;
        __cil_ref_6067161193c4aa3959efe989341e7b0d64a6a482 v34 = __cil_newobj_0A000C2F(this, v33);
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v35 = __cil_methodspec_call_2B0004F1(((__cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd)(v31)), v34);
        return v35;
        IL_00A6: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v37 = this.Info;
        int v38 = __cil_bool_load(v37.PayUpFront);
        if (v38 == 0) {
            goto IL_00CB;
        } else {
            goto IL_00B3;
        }
        IL_00B3: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v40 = this.buildableProducibles;
        nint v42 = __cil_ldftn_06001989;
        __cil_ref_6067161193c4aa3959efe989341e7b0d64a6a482 v43 = __cil_newobj_0A000C2F(this, v42);
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v44 = __cil_methodspec_call_2B0004F1(v40, v43);
        return v44;
        IL_00CB: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v46 = this.buildableProducibles;
        return v46;
    }

    public virtual bool AnyItemsToBuild()
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 bytes=151280A101129420: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de bytes=151281210212942002: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.Production, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 bytes=1D129420: class OpenRA.Mods.Common.Traits.Production[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd bytes=151280A101128421: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d584bde60a0ba63454af17d65ecf7caa94573da8 bytes=15128809021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2/KeyCollection<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 s3_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s3_1 = default;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 s4_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s4_1 = default;
        int v1 = __cil_bool_load(this.Enabled);
        if (v1 == 0) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v3 = this.productionTraits;
        nint v4 = unchecked((nint)(v3.LongLength));
        if (v4 == 0) {
            goto IL_003D;
        } else {
            goto IL_0011;
        }
        IL_0011: ;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v6 = this.productionTraits;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v7 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354E;
        if (v7 is not null) {
            __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e2_4_0 = v6;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e2_4_1 = v7;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0036;
        } else {
            __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e2_3_0 = v6;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e2_3_1 = v7;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_001F;
        }
        IL_001F: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63 v8 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003547;
        nint v9 = __cil_ldftn_06004010;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v10 = __cil_newobj_0A001309(v8, v9);
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354E = v10;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 e3_4_0 = s3_0;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e3_4_1 = v10;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        IL_0036: ;
        int v11 = __cil_bool_load(__cil_methodspec_call_2B00065D(((__cil_ref_27a29a4ee766e95f28798e78786bf3288a065108)(s4_0)), s4_1));
        if (v11 == 0) {
            return false;
        } else {
            goto IL_003D;
        }
        IL_003D: ;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v13 = this.developerMode;
        int v14 = __cil_bool_load(__cil_callvirt_060018B1(v13));
        if (v14 == 0) {
            goto IL_005C;
        } else {
            goto IL_004A;
        }
        IL_004A: ;
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v16 = this.Producible;
        __cil_ref_d584bde60a0ba63454af17d65ecf7caa94573da8 v17 = __cil_callvirt_0A0015CA(v16);
        int v18 = __cil_callvirt_0A0015CB(v17);
        if (v18 != 0) {
            return true;
        } else {
            goto IL_005C;
        }
        IL_005C: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v20 = this.buildableProducibles;
        return __cil_methodspec_call_2B00065E(v20);
    }

    public bool CanBuild(OpenRA.ActorInfo actor)
    {
        // structural signature __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 bytes=15128189021284211293A0: class [System.Collections]System.Collections.Generic.Dictionary`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ProductionState l0 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v0 = this;
        __cil_ref_099421c13f199b44dc2a2b5da18b4207f3657f18 v1 = v0.Producible;
        __cil_type_01000108 v2 = actor;
        ref global::OpenRA.Mods.Common.Traits.ProductionState v3 = ref l0;
        int v4 = __cil_bool_load(__cil_callvirt_0A0015CC(v1, v2, ref v3));
        if (v4 != 0) {
            goto IL_0012;
        } else {
            goto IL_0010;
        }
        IL_0010: ;
        int v5 = 0;
        return __cil_bool_store(v5);
        IL_0012: ;
        global::OpenRA.Mods.Common.Traits.ProductionState v6 = l0;
        int v7 = __cil_bool_load(v6.Buildable);
        if (v7 != 0) {
            goto IL_0026;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v8 = this;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v9 = v8.developerMode;
        int v10 = __cil_bool_load(__cil_callvirt_060018B1(v9));
        return __cil_bool_store(v10);
        IL_0026: ;
        int v11 = 1;
        return __cil_bool_store(v11);
    }

    private virtual void __name_4F70656E52412E5472616974732E495469636B2E5469636B(OpenRA.Actor self)
    {
        __cil_callvirt_06001978(this, self);
        return;
    }

    protected virtual void Tick(OpenRA.Actor self)
    {
        // structural signature __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 bytes=1D129420: class OpenRA.Mods.Common.Traits.Production[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l0 = default;
        bool l1 = default;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 l2 = default;
        int l3 = default;
        l0 = __cil_bool_store(0);
        l1 = __cil_bool_store(0);
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v3 = this.productionTraits;
        l2 = v3;
        l3 = 0;
        goto IL_0032;
        IL_000F: ;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v5 = l2;
        int v6 = l3;
        global::OpenRA.Mods.Common.Traits.Production v7 = v5[v6];
        int v8 = __cil_bool_load(l0);
        int v10 = __cil_bool_load(v7.get_IsTraitDisabled());
        int v12 = (v10 == 0 ? 1 : 0);
        int v13 = unchecked(v8 | v12);
        l0 = __cil_bool_store(v13);
        int v14 = __cil_bool_load(l1);
        int v16 = __cil_bool_load(v7.get_IsTraitPaused());
        int v18 = (v16 == 0 ? 1 : 0);
        int v19 = unchecked(v14 | v18);
        l1 = __cil_bool_store(v19);
        int v20 = l3;
        l3 = unchecked(v20 + 1);
        IL_0032: ;
        int v23 = l3;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v24 = l2;
        nint v25 = unchecked((nint)(v24.LongLength));
        int v26 = unchecked((int)(v25));
        if (v23 < v26) {
            goto IL_000F;
        } else {
            goto IL_0038;
        }
        IL_0038: ;
        int v27 = __cil_bool_load(l0);
        if (v27 != 0) {
            goto IL_0041;
        } else {
            goto IL_003B;
        }
        IL_003B: ;
        __cil_direct_06001961(this);
        IL_0041: ;
        int v31 = __cil_bool_load(this.IsValidFaction);
        int v32 = __cil_bool_load(l0);
        int v33 = unchecked(v31 & v32);
        this.Enabled = __cil_bool_store(v33);
        int v36 = __cil_bool_load(l1);
        int v38 = (v36 == 0 ? 1 : 0);
        __cil_callvirt_06001979(this, self, __cil_bool_store(v38));
        return;
    }

    protected virtual void TickInner(OpenRA.Actor self, bool allProductionPaused)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_direct_0600197A(this);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v2 = this.Queue;
        int v3 = __cil_callvirt_0A000C3A(v2);
        if (v3 <= 0) {
            goto IL_002E;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        int v5 = __cil_bool_load(allProductionPaused);
        if (v5 != 0) {
            goto IL_002E;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v7 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionItem v9 = __cil_callvirt_0A000C2E(v7, 0);
        global::OpenRA.Mods.Common.Traits.PlayerResources v11 = this.playerResources;
        __cil_callvirt_060019A3(v9, v11);
        IL_002E: ;
        return;
    }

    protected void CancelUnbuildableItems()
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd bytes=151280A101128421: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 bytes=15128121021284210E: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.ActorInfo, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 l0 = default;
        int l1 = default;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd s3_0 = default;
        __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 s3_1 = default;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd s4_0 = default;
        __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 s4_1 = default;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v1 = this.Queue;
        int v2 = __cil_callvirt_0A000C3A(v1);
        if (v2 != 0) {
            goto IL_000E;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        return;
        IL_000E: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v4 = __cil_callvirt_06001974(this);
        __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 v5 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354F;
        if (v5 is not null) {
            __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd e2_4_0 = v4;
            __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 e2_4_1 = v5;
            s4_0 = e2_4_0;
            s4_1 = e2_4_1;
            goto IL_0033;
        } else {
            __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd e2_3_0 = v4;
            __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 e2_3_1 = v5;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            goto IL_001C;
        }
        IL_001C: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63 v6 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003547;
        nint v7 = __cil_ldftn_06004011;
        __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 v8 = __cil_newobj_0A0015CD(v6, v7);
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_0400354F = v8;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd e3_4_0 = s3_0;
        __cil_ref_3f4bb6d985dfe05856023e1735adaa6a8f1f7267 e3_4_1 = v8;
        s4_0 = e3_4_0;
        s4_1 = e3_4_1;
        IL_0033: ;
        __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 v9 = __cil_methodspec_call_2B00065F(s4_0, s4_1);
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v10 = __cil_methodspec_call_2B000066(v9);
        l0 = v10;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v12 = this.Queue;
        int v13 = __cil_callvirt_0A000C3A(v12);
        l1 = unchecked(v13 - 1);
        goto IL_010A;
        IL_0051: ;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v16 = l0;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v18 = this.Queue;
        int v19 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v20 = __cil_callvirt_0A000C2E(v18, v19);
        string v21 = v20.Item;
        int v22 = __cil_bool_load(__cil_callvirt_0A0002A0(v16, v21));
        if (v22 != 0) {
            goto IL_0106;
        } else {
            goto IL_006D;
        }
        IL_006D: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v24 = this.Queue;
        int v25 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v26 = __cil_callvirt_0A000C2E(v24, v25);
        int v27 = __cil_callvirt_06001994(v26);
        if (v27 <= 0) {
            goto IL_00C6;
        } else {
            goto IL_0081;
        }
        IL_0081: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v30 = this.playerResources;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v32 = this.Queue;
        int v33 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v34 = __cil_callvirt_0A000C2E(v32, v33);
        int v35 = __cil_callvirt_06001994(v34);
        __cil_callvirt_0600193B(v30, v35);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v37 = this.Queue;
        int v38 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v39 = __cil_callvirt_0A000C2E(v37, v38);
        int v40 = __cil_callvirt_06001992(v39);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v42 = this.Queue;
        int v43 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v44 = __cil_callvirt_0A000C2E(v42, v43);
        int v45 = __cil_callvirt_06001994(v44);
        int v46 = unchecked(v40 + v45);
        __cil_callvirt_06001993(v39, v46);
        IL_00C6: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v48 = this.playerResources;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v50 = this.Queue;
        int v51 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v52 = __cil_callvirt_0A000C2E(v50, v51);
        int v53 = v52.TotalCost;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v55 = this.Queue;
        int v56 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v57 = __cil_callvirt_0A000C2E(v55, v56);
        int v58 = __cil_callvirt_06001992(v57);
        int v59 = unchecked(v53 - v58);
        __cil_callvirt_0600193D(v48, v59);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v62 = this.Queue;
        int v63 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v64 = __cil_callvirt_0A000C2E(v62, v63);
        __cil_direct_06001982(this, v64);
        IL_0106: ;
        int v65 = unchecked(l1--);
        IL_010A: ;
        int v68 = l1;
        if (v68 >= 0) {
            goto IL_0051;
        } else {
            goto IL_0111;
        }
        IL_0111: ;
        return;
    }

    public bool CanQueue(OpenRA.ActorInfo actor, out string notificationAudio, out string notificationText)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a bytes=15128121021293A402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ProductionItem, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 l0 = default;
        OpenRA.Mods.Common.Traits.BuildableInfo l1 = default;
        int l2 = default;
        int l3 = default;
        IL_0000: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 v0 = __cil_newobj_06004017();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 v1 = l0;
        __cil_type_01000108 v2 = actor;
        v1.actor = v2;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 v3 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v4 = this;
        v3.__il_field_04003554 = v4;
        ref string v5 = ref notificationAudio;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v6 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v7 = v6.Info;
        string v8 = v7.BlockedAudio;
        v5 = v8;
        ref string v9 = ref notificationText;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v10 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v11 = v10.Info;
        string v12 = v11.BlockedTextNotification;
        v9 = v12;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 v13 = l0;
        __cil_type_01000108 v14 = v13.actor;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v15 = __cil_callvirt_2B00011D(v14);
        l1 = v15;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v16 = l1;
        if (v16 is not null) {
            goto IL_003F;
        } else {
            goto IL_003D;
        }
        IL_003D: ;
        int v17 = 0;
        return __cil_bool_store(v17);
        IL_003F: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v18 = this;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v19 = v18.developerMode;
        int v20 = __cil_bool_load(__cil_callvirt_060018B1(v19));
        if (v20 != 0) {
            goto IL_014A;
        } else {
            goto IL_004F;
        }
        IL_004F: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v21 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v22 = v21.Info;
        int v23 = __cil_bool_load(v22.PayUpFront);
        if (v23 == 0) {
            goto IL_007B;
        } else {
            goto IL_005C;
        }
        IL_005C: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 v24 = l0;
        __cil_type_01000108 v25 = v24.actor;
        global::OpenRA.Mods.Common.Traits.ValuedInfo v26 = __cil_callvirt_2B000660(v25);
        int v27 = v26.Cost;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v28 = this;
        global::OpenRA.Mods.Common.Traits.PlayerResources v29 = v28.playerResources;
        int v30 = __cil_callvirt_06001941(v29);
        if (v27 <= v30) {
            goto IL_007B;
        } else {
            goto IL_0079;
        }
        IL_0079: ;
        int v31 = 0;
        return __cil_bool_store(v31);
        IL_007B: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v32 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v33 = v32.Info;
        int v34 = v33.QueueLimit;
        int v35 = 0;
        if (v34 <= v35) {
            goto IL_00BD;
        } else {
            goto IL_0089;
        }
        IL_0089: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v36 = this;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v37 = v36.Queue;
        int v38 = __cil_callvirt_0A000C3A(v37);
        global::OpenRA.Mods.Common.Traits.ProductionQueue v39 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v40 = v39.Info;
        int v41 = v40.QueueLimit;
        if (v38 < v41) {
            goto IL_00BD;
        } else {
            goto IL_00A1;
        }
        IL_00A1: ;
        ref string v42 = ref notificationAudio;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v43 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v44 = v43.Info;
        string v45 = v44.LimitedAudio;
        v42 = v45;
        ref string v46 = ref notificationText;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v47 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v48 = v47.Info;
        string v49 = v48.LimitedTextNotification;
        v46 = v49;
        int v50 = 0;
        return __cil_bool_store(v50);
        IL_00BD: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v51 = this;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v52 = v51.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 v53 = l0;
        nint v54 = __cil_ldftn_06004018;
        __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v55 = __cil_newobj_0A00083A(v53, v54);
        int v56 = __cil_methodspec_call_2B000661(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v52)), v55);
        l2 = v56;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v57 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v58 = v57.Info;
        int v59 = v58.ItemLimit;
        int v60 = 0;
        if (v59 <= v60) {
            goto IL_010D;
        } else {
            goto IL_00E3;
        }
        IL_00E3: ;
        int v61 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v62 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v63 = v62.Info;
        int v64 = v63.ItemLimit;
        if (v61 < v64) {
            goto IL_010D;
        } else {
            goto IL_00F1;
        }
        IL_00F1: ;
        ref string v65 = ref notificationAudio;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v66 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v67 = v66.Info;
        string v68 = v67.LimitedAudio;
        v65 = v68;
        ref string v69 = ref notificationText;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v70 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v71 = v70.Info;
        string v72 = v71.LimitedTextNotification;
        v69 = v72;
        int v73 = 0;
        return __cil_bool_store(v73);
        IL_010D: ;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v74 = l1;
        int v75 = v74.BuildLimit;
        int v76 = 0;
        if (v75 <= v76) {
            goto IL_014A;
        } else {
            goto IL_0116;
        }
        IL_0116: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v77 = this;
        __cil_type_01000025 v78 = __cil_direct_06001958(v77);
        __cil_type_01000030 v79 = ((OpenRA.Actor)v78).Owner;
        __cil_type_0100002D v80 = ((OpenRA.Player)v79).World;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v81 = __cil_callvirt_2B000662(v80);
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335335F30 v82 = l0;
        nint v83 = __cil_ldftn_06004019;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v84 = __cil_newobj_0A00019A(v82, v83);
        int v85 = __cil_methodspec_call_2B000010(v81, v84);
        l3 = v85;
        int v86 = l2;
        int v87 = l3;
        int v88 = unchecked(v86 + v87);
        global::OpenRA.Mods.Common.Traits.BuildableInfo v89 = l1;
        int v90 = v89.BuildLimit;
        if (v88 < v90) {
            goto IL_014A;
        } else {
            goto IL_0148;
        }
        IL_0148: ;
        int v91 = 0;
        return __cil_bool_store(v91);
        IL_014A: ;
        ref string v92 = ref notificationAudio;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v93 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v94 = v93.Info;
        string v95 = v94.QueuedAudio;
        v92 = v95;
        ref string v96 = ref notificationText;
        global::OpenRA.Mods.Common.Traits.ProductionQueue v97 = this;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v98 = v97.Info;
        string v99 = v98.QueuedTextNotification;
        v96 = v99;
        int v100 = 1;
        return __cil_bool_store(v100);
    }

    public virtual void ResolveOrder(OpenRA.Actor self, OpenRA.Order order)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd bytes=151280A101128421: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.ActorInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_6067161193c4aa3959efe989341e7b0d64a6a482 bytes=151281210212842102: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.ActorInfo, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a bytes=15128121021293A402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ProductionItem, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 bytes=151280A101128095: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class [OpenRA.Game]OpenRA.Actor>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 bytes=151281210212809502: class [System.Runtime]System.Func`2<class [OpenRA.Game]OpenRA.Actor, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 l0 = default;
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 l1 = default;
        OpenRA.Mods.Common.Traits.BuildableInfo l2 = default;
        int l3 = default;
        int l4 = default;
        long l5 = default;
        string l6 = default;
        int l9 = default;
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F32 l10 = default;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v0 = __cil_newobj_0600401A();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v1 = l0;
        v1.order = order;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v3 = l0;
        v3.self = self;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v5 = l0;
        v5.__il_field_04003557 = this;
        int v8 = __cil_bool_load(this.Enabled);
        if (v8 != 0) {
            goto IL_0024;
        } else {
            goto IL_0023;
        }
        IL_0023: ;
        return;
        IL_0024: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v9 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v10 = l0;
        __cil_type_01000025 v11 = v10.self;
        __cil_type_0100002D v12 = v11.World;
        __cil_type_01000026 v13 = v12.Map;
        __cil_type_0100007F v14 = ((OpenRA.Map)v13).Rules;
        v9.rules = v14;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v15 = __cil_newobj_0600401F();
        l1 = v15;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v16 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v17 = l0;
        v16.__il_field_0400355B = v17;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v18 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v19 = v18.__il_field_0400355B;
        __cil_type_01000046 v20 = v19.order;
        string v21 = v20.OrderString;
        l6 = v21;
        string v22 = l6;
        string v23 = __cil_ldstr_70022543("StartProduction");
        int v24 = __cil_bool_load(System.String.op_Equality(v22, v23));
        if (v24 != 0) {
            goto IL_008F;
        } else {
            goto IL_006C;
        }
        IL_006C: ;
        string v25 = l6;
        string v26 = __cil_ldstr_70022563("PauseProduction");
        int v27 = __cil_bool_load(System.String.op_Equality(v25, v26));
        if (v27 != 0) {
            goto IL_02C0;
        } else {
            goto IL_007D;
        }
        IL_007D: ;
        string v28 = l6;
        string v29 = __cil_ldstr_70022583("CancelProduction");
        int v30 = __cil_bool_load(System.String.op_Equality(v28, v29));
        if (v30 != 0) {
            goto IL_02EA;
        } else {
            goto IL_008E;
        }
        IL_008E: ;
        return;
        IL_008F: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v31 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v32 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v33 = v32.__il_field_0400355B;
        __cil_type_0100007F v34 = v33.rules;
        __cil_type_01000277 v35 = v34.Actors;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v36 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v37 = v36.__il_field_0400355B;
        __cil_type_01000046 v38 = v37.order;
        string v39 = v38.TargetString;
        __cil_type_01000108 v40 = __cil_callvirt_0A000710(v35, v39);
        v31.unit = v40;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v41 = l1;
        __cil_type_01000108 v42 = v41.unit;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v43 = __cil_callvirt_2B000189(v42);
        l2 = v43;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v44 = l2;
        __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v45 = v44.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v47 = this.Info;
        string v48 = v47.Type;
        int v49 = __cil_bool_load(__cil_callvirt_0A0002A0(v45, v48));
        if (v49 != 0) {
            goto IL_00DF;
        } else {
            goto IL_00DE;
        }
        IL_00DE: ;
        return;
        IL_00DF: ;
        __cil_ref_d54873ec5bff2ee7ac7b49cb218080e9fbac3cdd v51 = __cil_callvirt_06001974(this);
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v52 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v53 = v52.__il_field_0400355B;
        nint v54 = __cil_ldftn_0600401B;
        __cil_ref_6067161193c4aa3959efe989341e7b0d64a6a482 v55 = __cil_newobj_0A000C2F(v53, v54);
        int v56 = __cil_bool_load(__cil_methodspec_call_2B000663(v51, v55));
        if (v56 == 0) {
            goto IL_00FE;
        } else {
            goto IL_00FD;
        }
        IL_00FD: ;
        return;
        IL_00FE: ;
        l3 = 2147483647;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v59 = this.developerMode;
        int v60 = __cil_bool_load(__cil_callvirt_060018B1(v59));
        if (v60 != 0) {
            goto IL_01E8;
        } else {
            goto IL_0114;
        }
        IL_0114: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v62 = this.Info;
        int v63 = v62.QueueLimit;
        if (v63 <= 0) {
            goto IL_013A;
        } else {
            goto IL_0122;
        }
        IL_0122: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v66 = this.Info;
        int v67 = v66.QueueLimit;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v69 = this.Queue;
        int v70 = __cil_callvirt_0A000C3A(v69);
        l3 = unchecked(v67 - v70);
        IL_013A: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v73 = this.Info;
        int v74 = v73.ItemLimit;
        if (v74 <= 0) {
            goto IL_0177;
        } else {
            goto IL_0148;
        }
        IL_0148: ;
        int v76 = l3;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v78 = this.Info;
        int v79 = v78.ItemLimit;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v81 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v82 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v83 = v82.__il_field_0400355B;
        nint v84 = __cil_ldftn_0600401C;
        __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v85 = __cil_newobj_0A00083A(v83, v84);
        int v86 = __cil_methodspec_call_2B000661(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v81)), v85);
        int v87 = unchecked(v79 - v86);
        int v88 = System.Math.Min(v76, v87);
        l3 = v88;
        IL_0177: ;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v89 = l2;
        int v90 = v89.BuildLimit;
        if (v90 <= 0) {
            goto IL_01E3;
        } else {
            goto IL_0180;
        }
        IL_0180: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v93 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v94 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v95 = v94.__il_field_0400355B;
        nint v96 = __cil_ldftn_0600401D;
        __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v97 = __cil_newobj_0A00083A(v95, v96);
        int v98 = __cil_methodspec_call_2B000661(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v93)), v97);
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v99 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v100 = v99.__il_field_0400355B;
        __cil_type_01000025 v101 = v100.self;
        __cil_type_01000030 v102 = ((OpenRA.Actor)v101).Owner;
        __cil_type_0100002D v103 = ((OpenRA.Player)v102).World;
        __cil_ref_e87f69cb05a2ad4441747f803f3841956d5ceed5 v104 = __cil_callvirt_2B000662(v103);
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v105 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v106 = v105.__il_field_0400355B;
        nint v107 = __cil_ldftn_0600401E;
        __cil_ref_336773db2b75a32b546c8fdde24eb69ff79b1310 v108 = __cil_newobj_0A00019A(v106, v107);
        int v109 = __cil_methodspec_call_2B000010(v104, v108);
        int v110 = l3;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v111 = l2;
        int v112 = v111.BuildLimit;
        int v115 = unchecked(v98 + v109);
        int v116 = unchecked(v112 - v115);
        int v117 = System.Math.Min(v110, v116);
        l3 = v117;
        IL_01E3: ;
        int v118 = l3;
        if (v118 > 0) {
            goto IL_01E8;
        } else {
            goto IL_01E7;
        }
        IL_01E7: ;
        return;
        IL_01E8: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v121 = l1;
        __cil_type_01000108 v122 = v121.unit;
        int v123 = __cil_callvirt_0600197E(this, v122);
        l4 = v123;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v124 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v126 = l1;
        __cil_type_01000108 v127 = v126.unit;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v128 = l2;
        int v129 = __cil_callvirt_0600197D(this, v127, v128);
        v124.time = v129;
        int v130 = l3;
        long v131 = unchecked((long)(v130));
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v132 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v133 = v132.__il_field_0400355B;
        __cil_type_01000046 v134 = v133.order;
        int v135 = unchecked((int)(v134.ExtraData));
        long v136 = unchecked((long)(uint)(v135));
        long v137 = System.Math.Min(v131, v136);
        l5 = v137;
        l9 = 0;
        goto IL_02B5;
        IL_022B: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F32 v139 = __cil_newobj_06004021();
        l10 = v139;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F32 v140 = l10;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v141 = l1;
        v140.__il_field_0400355E = v141;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v143 = this.Info;
        int v144 = __cil_bool_load(v143.PayUpFront);
        if (v144 == 0) {
            goto IL_0257;
        } else {
            goto IL_0247;
        }
        IL_0247: ;
        int v145 = l4;
        global::OpenRA.Mods.Common.Traits.PlayerResources v147 = this.playerResources;
        int v148 = __cil_callvirt_06001941(v147);
        if (v145 <= v148) {
            goto IL_0257;
        } else {
            goto IL_0256;
        }
        IL_0256: ;
        return;
        IL_0257: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F32 v149 = l10;
        v149.hasPlayedSound = __cil_bool_store(0);
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F32 v153 = l10;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v154 = v153.__il_field_0400355E;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v155 = v154.__il_field_0400355B;
        __cil_type_01000046 v156 = v155.order;
        string v157 = v156.TargetString;
        int v158 = l4;
        global::OpenRA.Mods.Common.Traits.PowerManager v160 = this.playerPower;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F32 v161 = l10;
        nint v162 = __cil_ldftn_06004022;
        __cil_type_010000B2 v163 = __cil_newobj_0A0001CD(v161, v162);
        global::OpenRA.Mods.Common.Traits.ProductionItem v164 = __cil_newobj_060019A2(this, v157, v158, v160, v163);
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F32 v165 = l10;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v166 = v165.__il_field_0400355E;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v167 = v166.__il_field_0400355B;
        __cil_type_01000046 v168 = v167.order;
        int v169 = __cil_bool_load(v168.Queued);
        int v171 = (v169 == 0 ? 1 : 0);
        __cil_callvirt_06001983(this, v164, __cil_bool_store(v171));
        int v172 = l9;
        l9 = unchecked(v172 + 1);
        IL_02B5: ;
        int v175 = l9;
        long v176 = unchecked((long)(v175));
        long v177 = l5;
        if (v176 < v177) {
            goto IL_022B;
        } else {
            goto IL_02BF;
        }
        IL_02BF: ;
        return;
        IL_02C0: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v179 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v180 = v179.__il_field_0400355B;
        __cil_type_01000046 v181 = v180.order;
        string v182 = v181.TargetString;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v183 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v184 = v183.__il_field_0400355B;
        __cil_type_01000046 v185 = v184.order;
        int v186 = unchecked((int)(v185.ExtraData));
        int v188 = (unchecked((uint)v186) > unchecked((uint)0) ? 1 : 0);
        __cil_callvirt_0600197F(this, v182, __cil_bool_store(v188));
        return;
        IL_02EA: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v190 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v191 = v190.__il_field_0400355B;
        __cil_type_01000046 v192 = v191.order;
        string v193 = v192.TargetString;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v194 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v195 = v194.__il_field_0400355B;
        __cil_type_01000046 v196 = v195.order;
        int v197 = unchecked((int)(v196.ExtraData));
        __cil_callvirt_06001980(this, v193, unchecked((uint)(v197)));
        return;
    }

    public virtual int GetBuildTime(OpenRA.ActorInfo unit, OpenRA.Mods.Common.Traits.BuildableInfo bi)
    {
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2fbef7abdc2aa5a7069e814a861fed3b1dd62741 bytes=151280BD01129994: class [System.Runtime]System.Collections.Generic.IReadOnlyCollection`1<class OpenRA.Mods.Common.Traits.IProductionTimeModifierInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_354da6dc9f4cd72831980fcd1074145f2f8f591b bytes=151281210212999408: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.IProductionTimeModifierInfo, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_df5a9b88c742123d111102831d86aef7642f3975 bytes=151280A101129994: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.IProductionTimeModifierInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int l0 = default;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v1 = this.developerMode;
        int v2 = __cil_bool_load(__cil_callvirt_060018B2(v1));
        if (!(v2 == 0)) {
            return 0;
        }
        int v5 = bi.BuildDuration;
        l0 = v5;
        int v6 = l0;
        if (unchecked((uint)v6) != unchecked((uint)-1)) {
            goto IL_0022;
        } else {
            goto IL_001A;
        }
        IL_001A: ;
        int v10 = __cil_callvirt_0600197E(this, unit);
        l0 = v10;
        IL_0022: ;
        __cil_ref_2fbef7abdc2aa5a7069e814a861fed3b1dd62741 v12 = __cil_callvirt_2B000664(unit);
        nint v14 = __cil_ldftn_0600198A;
        __cil_ref_354da6dc9f4cd72831980fcd1074145f2f8f591b v15 = __cil_newobj_0A0015CE(this, v14);
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v16 = __cil_methodspec_call_2B000665(((__cil_ref_df5a9b88c742123d111102831d86aef7642f3975)(v12)), v15);
        int[] v18 = new int[1];
        int v21 = bi.BuildDurationModifier;
        v18[0] = v21;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v22 = __cil_methodspec_call_2B000037(v16, v18);
        int[] v24 = new int[1];
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v27 = this.Info;
        int v28 = v27.BuildDurationModifier;
        v24[0] = v28;
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v29 = __cil_methodspec_call_2B000037(v22, v24);
        int v30 = l0;
        int v32 = OpenRA.Mods.Common.Util.ApplyPercentageModifiers(v30, v29);
        return v32;
    }

    public virtual int GetProductionCost(OpenRA.ActorInfo unit)
    {
        // structural signature __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba bytes=151280A10108: class [System.Runtime]System.Collections.Generic.IEnumerable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c3a7a63799328ca595e4da53031643570c324613 bytes=151280BD01129990: class [System.Runtime]System.Collections.Generic.IReadOnlyCollection`1<class OpenRA.Mods.Common.Traits.IProductionCostModifierInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_4897658e9aa050787954ce72fa7b7fd14b8e8941 bytes=151281210212999008: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.IProductionCostModifierInfo, int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_755897f3abf3aa66fe4f90ba55e23fa7a5e1aea4 bytes=151280A101129990: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.IProductionCostModifierInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ValuedInfo l0 = default;
        global::OpenRA.Mods.Common.Traits.ValuedInfo v1 = __cil_callvirt_2B00011E(unit);
        l0 = v1;
        global::OpenRA.Mods.Common.Traits.ValuedInfo v2 = l0;
        if (!(v2 is not null)) {
            return 0;
        }
        __cil_ref_c3a7a63799328ca595e4da53031643570c324613 v5 = __cil_callvirt_2B000666(unit);
        nint v7 = __cil_ldftn_0600198B;
        __cil_ref_4897658e9aa050787954ce72fa7b7fd14b8e8941 v8 = __cil_newobj_0A0015CF(this, v7);
        __cil_ref_1c108662ec0019cf11db4adc39a6e85a9dbd40ba v9 = __cil_methodspec_call_2B000667(((__cil_ref_755897f3abf3aa66fe4f90ba55e23fa7a5e1aea4)(v5)), v8);
        global::OpenRA.Mods.Common.Traits.ValuedInfo v10 = l0;
        int v11 = v10.Cost;
        int v13 = OpenRA.Mods.Common.Util.ApplyPercentageModifiers(v11, v9);
        return v13;
    }

    protected virtual void PauseProduction(string itemName, bool paused)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_912820940a8942fb88a871b82082360a7a5e80ec bytes=151283D1011293A4: class [System.Runtime]System.Predicate`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ProductionItem s1_0 = default;
        OpenRA.Mods.Common.Traits.ProductionItem s2_0 = default;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335375F30 v0 = __cil_newobj_06004024();
        v0.itemName = itemName;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v4 = this.Queue;
        nint v6 = __cil_ldftn_06004025;
        __cil_ref_912820940a8942fb88a871b82082360a7a5e80ec v7 = __cil_newobj_0A00155F(v0, v6);
        global::OpenRA.Mods.Common.Traits.ProductionItem v8 = __cil_methodspec_call_2B000631(v4, v7);
        if (v8 is not null) {
            OpenRA.Mods.Common.Traits.ProductionItem e0_2_0 = v8;
            s2_0 = e0_2_0;
            goto IL_0029;
        } else {
            OpenRA.Mods.Common.Traits.ProductionItem e0_1_0 = v8;
            s1_0 = e0_1_0;
            goto IL_0027;
        }
        IL_0027: ;
        return;
        IL_0029: ;
        int v9 = __cil_bool_load(paused);
        __cil_direct_060019A4(s2_0, __cil_bool_store(v9));
        return;
    }

    protected virtual void CancelProduction(string itemName, uint numberToCancel)
    {
        int l0 = default;
        l0 = 0;
        goto IL_0011;
        IL_0004: ;
        int v3 = __cil_bool_load(__cil_direct_06001981(this, itemName));
        if (v3 == 0) {
            goto IL_0017;
        } else {
            goto IL_000D;
        }
        IL_000D: ;
        int v4 = l0;
        l0 = unchecked(v4 + 1);
        IL_0011: ;
        int v7 = l0;
        long v8 = unchecked((long)(v7));
        int v9 = unchecked((int)(numberToCancel));
        long v10 = unchecked((long)(uint)(v9));
        if (v8 < v10) {
            goto IL_0004;
        } else {
            goto IL_0017;
        }
        IL_0017: ;
        return;
    }

    protected bool CancelProductionInner(string itemName)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a bytes=15128121021293A402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ProductionItem, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ProductionItem l1 = default;
        int l2 = default;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335395F30 v0 = __cil_newobj_06004026();
        v0.itemName = itemName;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v4 = this.Queue;
        nint v6 = __cil_ldftn_06004027;
        __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v7 = __cil_newobj_0A00083A(v0, v6);
        global::OpenRA.Mods.Common.Traits.ProductionItem v8 = __cil_methodspec_call_2B000668(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v4)), v7);
        l1 = v8;
        global::OpenRA.Mods.Common.Traits.ProductionItem v9 = l1;
        if (v9 is null) {
            return false;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        global::OpenRA.Mods.Common.Traits.ProductionItem v10 = l1;
        int v11 = __cil_bool_load(__cil_callvirt_0600199F(v10));
        if (v11 == 0) {
            goto IL_007B;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        global::OpenRA.Mods.Common.Traits.ProductionItem v12 = l1;
        __cil_callvirt_060019A0(v12, __cil_bool_store(0));
        l2 = 1;
        goto IL_006B;
        IL_003E: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v16 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionItem v18 = l1;
        string v19 = v18.Item;
        global::OpenRA.Mods.Common.Traits.ProductionItem v20 = l1;
        int v21 = v20.TotalCost;
        global::OpenRA.Mods.Common.Traits.PowerManager v23 = this.playerPower;
        global::OpenRA.Mods.Common.Traits.ProductionItem v24 = l1;
        __cil_type_010000B2 v25 = v24.OnComplete;
        global::OpenRA.Mods.Common.Traits.ProductionItem v26 = __cil_newobj_060019A2(this, v19, v21, v23, v25);
        __cil_callvirt_0A001564(v16, v26);
        int v27 = l2;
        l2 = unchecked(v27 + 1);
        IL_006B: ;
        int v30 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v32 = this.Info;
        int v33 = v32.InfiniteBuildLimit;
        if (v30 < v33) {
            goto IL_003E;
        } else {
            return true;
        }
        IL_007B: ;
        global::OpenRA.Mods.Common.Traits.ProductionItem v34 = l1;
        int v35 = __cil_callvirt_06001994(v34);
        if (v35 <= 0) {
            goto IL_00A8;
        } else {
            goto IL_0084;
        }
        IL_0084: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v38 = this.playerResources;
        global::OpenRA.Mods.Common.Traits.ProductionItem v39 = l1;
        int v40 = __cil_callvirt_06001994(v39);
        __cil_callvirt_0600193B(v38, v40);
        global::OpenRA.Mods.Common.Traits.ProductionItem v41 = l1;
        int v42 = __cil_callvirt_06001992(v41);
        global::OpenRA.Mods.Common.Traits.ProductionItem v43 = l1;
        int v44 = __cil_callvirt_06001994(v43);
        int v45 = unchecked(v42 + v44);
        __cil_callvirt_06001993(v41, v45);
        IL_00A8: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v47 = this.playerResources;
        global::OpenRA.Mods.Common.Traits.ProductionItem v48 = l1;
        int v49 = v48.TotalCost;
        global::OpenRA.Mods.Common.Traits.ProductionItem v50 = l1;
        int v51 = __cil_callvirt_06001992(v50);
        int v52 = unchecked(v49 - v51);
        __cil_callvirt_0600193D(v47, v52);
        global::OpenRA.Mods.Common.Traits.ProductionItem v54 = l1;
        __cil_direct_06001982(this, v54);
        return true;
    }

    public void EndProduction(OpenRA.Mods.Common.Traits.ProductionItem item)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v1 = this.Queue;
        int v3 = __cil_bool_load(__cil_callvirt_0A001563(v1, item));
        int v5 = __cil_bool_load(__cil_callvirt_0600199F(item));
        if (v5 == 0) {
            goto IL_0045;
        } else {
            goto IL_0015;
        }
        IL_0015: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v7 = this.Queue;
        string v10 = item.Item;
        int v12 = item.TotalCost;
        global::OpenRA.Mods.Common.Traits.PowerManager v14 = this.playerPower;
        __cil_type_010000B2 v16 = item.OnComplete;
        global::OpenRA.Mods.Common.Traits.ProductionItem v17 = __cil_newobj_060019A2(this, v10, v12, v14, v16);
        __cil_callvirt_060019A0(v17, __cil_bool_store(1));
        __cil_callvirt_0A001564(v7, v17);
        IL_0045: ;
        return;
    }

    protected virtual void BeginProduction(OpenRA.Mods.Common.Traits.ProductionItem item, bool hasPriority)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a bytes=15128121021293A402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ProductionItem, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_912820940a8942fb88a871b82082360a7a5e80ec bytes=151283D1011293A4: class [System.Runtime]System.Predicate`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 l0 = default;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 l1 = default;
        int l2 = default;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v0 = __cil_newobj_06004028();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v1 = l0;
        v1.item = item;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v4 = this.Info;
        int v5 = __cil_bool_load(v4.PayUpFront);
        if (v5 == 0) {
            goto IL_00AD;
        } else {
            goto IL_001D;
        }
        IL_001D: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v7 = this.playerResources;
        int v8 = v7.Resources;
        if (v8 <= 0) {
            goto IL_005B;
        } else {
            goto IL_002B;
        }
        IL_002B: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v11 = this.playerResources;
        int v12 = v11.Resources;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v13 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v14 = v13.item;
        int v15 = v14.TotalCost;
        if (v12 > v15) {
            goto IL_005B;
        } else {
            goto IL_0043;
        }
        IL_0043: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v16 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v17 = v16.item;
        global::OpenRA.Mods.Common.Traits.PlayerResources v19 = this.playerResources;
        int v20 = v19.Resources;
        __cil_callvirt_06001995(v17, v20);
        goto IL_0089;
        IL_005B: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v22 = this.playerResources;
        int v23 = v22.Resources;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v24 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v25 = v24.item;
        int v26 = v25.TotalCost;
        if (v23 <= v26) {
            goto IL_0089;
        } else {
            goto IL_0073;
        }
        IL_0073: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v27 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v28 = v27.item;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v29 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v30 = v29.item;
        int v31 = v30.TotalCost;
        __cil_callvirt_06001995(v28, v31);
        IL_0089: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v33 = this.playerResources;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v34 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v35 = v34.item;
        int v36 = v35.TotalCost;
        int v38 = __cil_bool_load(__cil_callvirt_0600193E(v33, v36, __cil_bool_store(0)));
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v39 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v40 = v39.item;
        __cil_callvirt_06001993(v40, 0);
        IL_00AD: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v43 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v44 = l0;
        nint v45 = __cil_ldftn_06004029;
        __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v46 = __cil_newobj_0A00083A(v44, v45);
        int v47 = __cil_bool_load(__cil_methodspec_call_2B00030F(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v43)), v46));
        if (v47 == 0) {
            goto IL_00C7;
        } else {
            goto IL_00C6;
        }
        IL_00C6: ;
        return;
        IL_00C7: ;
        int v48 = __cil_bool_load(hasPriority);
        if (v48 == 0) {
            goto IL_00EC;
        } else {
            goto IL_00CA;
        }
        IL_00CA: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v50 = this.Queue;
        int v51 = __cil_callvirt_0A000C3A(v50);
        if (v51 <= 1) {
            goto IL_00EC;
        } else {
            goto IL_00D8;
        }
        IL_00D8: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v54 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v56 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v57 = v56.item;
        __cil_callvirt_0A0015D1(v54, 1, v57);
        goto IL_00FD;
        IL_00EC: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v59 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v60 = l0;
        global::OpenRA.Mods.Common.Traits.ProductionItem v61 = v60.item;
        __cil_callvirt_0A001564(v59, v61);
        IL_00FD: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v63 = this.Info;
        int v64 = v63.InfiniteBuildLimit;
        if (v64 >= 0) {
            goto IL_010C;
        } else {
            goto IL_010B;
        }
        IL_010B: ;
        return;
        IL_010C: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v67 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336315F30 v68 = l0;
        nint v69 = __cil_ldftn_0600402A;
        __cil_ref_912820940a8942fb88a871b82082360a7a5e80ec v70 = __cil_newobj_0A00155F(v68, v69);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v71 = __cil_callvirt_0A001560(v67, v70);
        l1 = v71;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v72 = l1;
        int v73 = __cil_callvirt_0A000C3A(v72);
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v75 = this.Info;
        int v76 = v75.InfiniteBuildLimit;
        if (v73 > v76) {
            goto IL_0138;
        } else {
            goto IL_0137;
        }
        IL_0137: ;
        return;
        IL_0138: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v77 = l1;
        global::OpenRA.Mods.Common.Traits.ProductionItem v79 = __cil_callvirt_0A000C2E(v77, 0);
        __cil_callvirt_060019A0(v79, __cil_bool_store(1));
        l2 = 1;
        goto IL_01C3;
        IL_0149: ;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v82 = l1;
        int v83 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v84 = __cil_callvirt_0A000C2E(v82, v83);
        int v85 = __cil_callvirt_06001994(v84);
        if (v85 <= 0) {
            goto IL_018E;
        } else {
            goto IL_0158;
        }
        IL_0158: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v88 = this.playerResources;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v89 = l1;
        int v90 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v91 = __cil_callvirt_0A000C2E(v89, v90);
        int v92 = __cil_callvirt_06001994(v91);
        __cil_callvirt_0600193B(v88, v92);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v93 = l1;
        int v94 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v95 = __cil_callvirt_0A000C2E(v93, v94);
        int v96 = __cil_callvirt_06001992(v95);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v97 = l1;
        int v98 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v99 = __cil_callvirt_0A000C2E(v97, v98);
        int v100 = __cil_callvirt_06001994(v99);
        int v101 = unchecked(v96 + v100);
        __cil_callvirt_06001993(v95, v101);
        IL_018E: ;
        global::OpenRA.Mods.Common.Traits.PlayerResources v103 = this.playerResources;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v104 = l1;
        int v105 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v106 = __cil_callvirt_0A000C2E(v104, v105);
        int v107 = v106.TotalCost;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v108 = l1;
        int v109 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v110 = __cil_callvirt_0A000C2E(v108, v109);
        int v111 = __cil_callvirt_06001992(v110);
        int v112 = unchecked(v107 - v111);
        __cil_callvirt_0600193D(v103, v112);
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v114 = l1;
        int v115 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v116 = __cil_callvirt_0A000C2E(v114, v115);
        __cil_direct_06001982(this, v116);
        int v117 = l2;
        l2 = unchecked(v117 + 1);
        IL_01C3: ;
        int v120 = l2;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v121 = l1;
        int v122 = __cil_callvirt_0A000C3A(v121);
        if (v120 < v122) {
            goto IL_0149;
        } else {
            goto IL_01CF;
        }
        IL_01CF: ;
        return;
    }

    public virtual int RemainingTimeActual(OpenRA.Mods.Common.Traits.ProductionItem item)
    {
        int v1 = __cil_callvirt_06001996(item);
        return v1;
    }

    public virtual OpenRA.TraitPair<OpenRA.Mods.Common.Traits.Production> MostLikelyProducer()
    {
        // structural signature __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 bytes=151280A101129420: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de bytes=151281210212942002: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.Production, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 bytes=1D129420: class OpenRA.Mods.Common.Traits.Production[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_cdcc044183fdfef1997bf15e798b65d7a8d46fc2 bytes=1511812501129420: valuetype [OpenRA.Game]OpenRA.TraitPair`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_25a6fcdfdf96643ec5dfece9ac2563573201d86f bytes=151282A501129420: class [System.Linq]System.Linq.IOrderedEnumerable`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 s1_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s1_1 = default;
        __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 s2_0 = default;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de s2_1 = default;
        __cil_ref_17e4001fc66d09a69460d6f0bcca48e31fd58a76 v1 = this.productionTraits;
        nint v3 = __cil_ldftn_0600198C;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v4 = __cil_newobj_0A001309(this, v3);
        __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 v5 = __cil_methodspec_call_2B00056B(((__cil_ref_27a29a4ee766e95f28798e78786bf3288a065108)(v1)), v4);
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v6 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003550;
        if (v6 is not null) {
            __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 e0_2_0 = v5;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e0_2_1 = v6;
            s2_0 = e0_2_0;
            s2_1 = e0_2_1;
            goto IL_0036;
        } else {
            __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 e0_1_0 = v5;
            __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e0_1_1 = v6;
            s1_0 = e0_1_0;
            s1_1 = e0_1_1;
            goto IL_001F;
        }
        IL_001F: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63 v7 = OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003547;
        nint v8 = __cil_ldftn_06004012;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de v9 = __cil_newobj_0A001309(v7, v8);
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003550 = v9;
        __cil_ref_27a29a4ee766e95f28798e78786bf3288a065108 e1_2_0 = s1_0;
        __cil_ref_d367abfb455b3d77198c5f866540bcb651a9b8de e1_2_1 = v9;
        s2_0 = e1_2_0;
        s2_1 = e1_2_1;
        IL_0036: ;
        __cil_ref_25a6fcdfdf96643ec5dfece9ac2563573201d86f v10 = __cil_methodspec_call_2B000669(s2_0, s2_1);
        global::OpenRA.Mods.Common.Traits.Production v11 = __cil_methodspec_call_2B00066A(((__cil_ref_27a29a4ee766e95f28798e78786bf3288a065108)(v10)));
        __cil_type_01000025 v13 = this.Actor;
        __cil_value_cdcc044183fdfef1997bf15e798b65d7a8d46fc2 v15 = __cil_value_newobj_0A0015D2(v13, v11);
        return v15;
    }

    protected virtual bool BuildUnit(OpenRA.ActorInfo unit)
    {
        // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a bytes=15128121021293A402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ProductionItem, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_cdcc044183fdfef1997bf15e798b65d7a8d46fc2 bytes=1511812501129420: valuetype [OpenRA.Game]OpenRA.TraitPair`1<class OpenRA.Mods.Common.Traits.Production>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 l0 = default;
        OpenRA.Mods.Common.Traits.Production l1 = default;
        __cil_type_01000098 l2 = default;
        OpenRA.Mods.Common.Traits.BuildableInfo l3 = default;
        string l4 = default;
        OpenRA.Mods.Common.Traits.ProductionItem l5 = default;
        string s6_0 = default;
        string s8_0 = default;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 v0 = __cil_newobj_0600402B();
        l0 = v0;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 v1 = l0;
        v1.unit = unit;
        __cil_value_cdcc044183fdfef1997bf15e798b65d7a8d46fc2 v4 = __cil_callvirt_06001985(this);
        global::OpenRA.Mods.Common.Traits.Production v5 = v4.Trait;
        l1 = v5;
        __cil_type_01000025 v7 = this.Actor;
        int v8 = __cil_bool_load(((OpenRA.Actor)v7).IsInWorld);
        if (v8 == 0) {
            goto IL_0036;
        } else {
            goto IL_0026;
        }
        IL_0026: ;
        __cil_type_01000025 v10 = this.Actor;
        int v11 = __cil_bool_load(((OpenRA.Actor)v10).IsDead);
        if (v11 != 0) {
            goto IL_0036;
        } else {
            goto IL_0033;
        }
        IL_0033: ;
        global::OpenRA.Mods.Common.Traits.Production v12 = l1;
        if (v12 is not null) {
            goto IL_004A;
        } else {
            goto IL_0036;
        }
        IL_0036: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 v14 = l0;
        __cil_type_01000108 v15 = v14.unit;
        string v16 = v15.Name;
        __cil_callvirt_06001980(this, v16, unchecked((uint)(1)));
        return false;
        IL_004A: ;
        __cil_type_01000098 v19 = __cil_newobj_0A000565();
        __cil_type_01000025 v21 = this.Actor;
        __cil_type_01000030 v22 = ((OpenRA.Actor)v21).Owner;
        __cil_type_01000107 v23 = __cil_newobj_0A0006AD(v22);
        v19.Add(((object)(v23)));
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 v24 = l0;
        __cil_type_01000108 v25 = v24.unit;
        string v27 = this.Faction;
        string v28 = OpenRA.Mods.Common.Traits.BuildableInfo.GetInitialFaction(v25, v27);
        global::OpenRA.Mods.Common.FactionInit v29 = __cil_newobj_06000095(v28);
        v19.Add(((object)(v29)));
        l2 = v19;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 v30 = l0;
        __cil_type_01000108 v31 = v30.unit;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v32 = __cil_callvirt_2B000189(v31);
        l3 = v32;
        global::OpenRA.Mods.Common.Traits.DeveloperMode v34 = this.developerMode;
        int v35 = __cil_bool_load(__cil_callvirt_060018B1(v34));
        if (v35 != 0) {
            goto IL_00B2;
        } else {
            goto IL_009B;
        }
        IL_009B: ;
        global::OpenRA.Mods.Common.Traits.BuildableInfo v36 = l3;
        string v37 = v36.BuildAtProductionType;
        if (v37 is not null) {
            string e5_8_0 = v37;
            s8_0 = e5_8_0;
            goto IL_00BD;
        } else {
            string e5_6_0 = v37;
            s6_0 = e5_6_0;
            goto IL_00A4;
        }
        IL_00A4: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v39 = this.Info;
        string v40 = v39.Type;
        string e6_8_0 = v40;
        s8_0 = e6_8_0;
        goto IL_00BD;
        IL_00B2: ;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v42 = this.Info;
        string v43 = v42.Type;
        string e7_8_0 = v43;
        s8_0 = e7_8_0;
        IL_00BD: ;
        l4 = s8_0;
        __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v45 = this.Queue;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 v46 = l0;
        nint v47 = __cil_ldftn_0600402C;
        __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v48 = __cil_newobj_0A00083A(v46, v47);
        global::OpenRA.Mods.Common.Traits.ProductionItem v49 = __cil_methodspec_call_2B000637(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(v45)), v48);
        l5 = v49;
        global::OpenRA.Mods.Common.Traits.Production v50 = l1;
        int v51 = __cil_bool_load(v50.get_IsTraitPaused());
        if (v51 != 0) {
            return false;
        } else {
            goto IL_00E0;
        }
        IL_00E0: ;
        global::OpenRA.Mods.Common.Traits.Production v52 = l1;
        __cil_type_01000025 v54 = this.Actor;
        global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737336345F30 v55 = l0;
        __cil_type_01000108 v56 = v55.unit;
        string v57 = l4;
        __cil_type_01000098 v58 = l2;
        global::OpenRA.Mods.Common.Traits.ProductionItem v59 = l5;
        int v60 = v59.TotalCost;
        int v61 = __cil_bool_load(__cil_callvirt_06001A2F(v52, v54, v56, v57, v58, v60));
        if (v61 == 0) {
            return false;
        } else {
            goto IL_00FE;
        }
        IL_00FE: ;
        global::OpenRA.Mods.Common.Traits.ProductionItem v63 = l5;
        __cil_direct_06001982(this, v63);
        return true;
    }

    private bool __name_3C4F70656E52412E5472616974732E494E6F74696679437265617465642E437265617465643E625F5F32365F30(OpenRA.Mods.Common.Traits.Production p)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::OpenRA.Mods.Common.Traits.ProductionInfo v1 = ((__cil_ref_756748270efa48f79c2da3f162180252759827af)p).Info;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v2 = v1.Produces;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v4 = this.Info;
        string v5 = v4.Type;
        return __cil_methodspec_call_2B000054(((__cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3)(v2)), v5);
    }

    // Metadata name: <BuildableItems>b__46_1
    private bool BuildableItemsLambda46_1(OpenRA.ActorInfo a)
    {
        int v2 = __cil_callvirt_0600197E(this, a);
        global::OpenRA.Mods.Common.Traits.PlayerResources v4 = this.playerResources;
        int v5 = __cil_callvirt_06001941(v4);
        if (v2 <= v5) {
            return true;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        return __cil_callvirt_06001970(this, a);
    }

    // Metadata name: <BuildableItems>b__46_2
    private bool BuildableItemsLambda46_2(OpenRA.ActorInfo a)
    {
        int v2 = __cil_callvirt_0600197E(this, a);
        global::OpenRA.Mods.Common.Traits.PlayerResources v4 = this.playerResources;
        int v5 = __cil_callvirt_06001941(v4);
        if (v2 <= v5) {
            return true;
        } else {
            goto IL_0014;
        }
        IL_0014: ;
        return __cil_callvirt_06001970(this, a);
    }

    // Metadata name: <GetBuildTime>b__55_0
    private int GetBuildTimeLambda55_0(OpenRA.Mods.Common.Traits.IProductionTimeModifierInfo t)
    {
        global::OpenRA.Mods.Common.Traits.TechTree v2 = this.techTree;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v4 = this.Info;
        string v5 = v4.Type;
        int v6 = __cil_callvirt_06001F9A(t, v2, v5);
        return v6;
    }

    // Metadata name: <GetProductionCost>b__56_0
    private int GetProductionCostLambda56_0(OpenRA.Mods.Common.Traits.IProductionCostModifierInfo t)
    {
        global::OpenRA.Mods.Common.Traits.TechTree v2 = this.techTree;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v4 = this.Info;
        string v5 = v4.Type;
        int v6 = __cil_callvirt_06001F99(t, v2, v5);
        return v6;
    }

    // Metadata name: <MostLikelyProducer>b__63_0
    private bool MostLikelyProducerLambda63_0(OpenRA.Mods.Common.Traits.Production p)
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3 bytes=151280A1010E: class [System.Runtime]System.Collections.Generic.IEnumerable`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        int v1 = __cil_bool_load(p.get_IsTraitDisabled());
        if (v1 != 0) {
            return false;
        } else {
            goto IL_0008;
        }
        IL_0008: ;
        global::OpenRA.Mods.Common.Traits.ProductionInfo v3 = ((__cil_ref_756748270efa48f79c2da3f162180252759827af)p).Info;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v4 = v3.Produces;
        global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v6 = this.Info;
        string v7 = v6.Type;
        return __cil_methodspec_call_2B000054(((__cil_ref_efbf0818ff8a22c573094750046401dd30a83cd3)(v4)), v7);
    }
    // property OpenRA.Actor Actor { get: get_Actor; }
    // property bool Enabled { get: get_Enabled; set: set_Enabled; }
    // property string Faction { get: get_Faction; set: set_Faction; }
    // property bool IsValidFaction { get: get_IsValidFaction; set: set_IsValidFaction; }

    private sealed class __name_3C3E63
    {
        public static readonly OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63 __il_field_04003547;
        public static System.Func<System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState>, bool> __il_field_04003548;
        public static System.Func<System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState>, OpenRA.ActorInfo> __il_field_04003549;
        public static System.Func<System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState>, bool> __il_field_0400354A;
        public static System.Func<System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState>, OpenRA.ActorInfo> __il_field_0400354B;
        public static System.Func<OpenRA.Mods.Common.Traits.Production, bool> __il_field_0400354C;
        public static System.Func<OpenRA.Mods.Common.Traits.Production, bool> __il_field_0400354D;
        public static System.Func<OpenRA.Mods.Common.Traits.Production, bool> __il_field_0400354E;
        public static System.Func<OpenRA.ActorInfo, string> __il_field_0400354F;
        public static System.Func<OpenRA.Mods.Common.Traits.Production, bool> __il_field_04003550;

        static __name_3C3E63()
        {
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63 v0 = __cil_newobj_06004009();
            OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E63.__il_field_04003547 = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <.ctor>b__25_0
        internal bool CtorLambda25_0(System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState> a)
        {
            // structural signature __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e bytes=15118235021284211293A0: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e v0 = ref a;
            global::OpenRA.Mods.Common.Traits.ProductionState v1 = __cil_value_call_0A001D14(ref v0);
            int v2 = __cil_bool_load(v1.Buildable);
            if (v2 != 0) {
                goto IL_001B;
            } else {
                goto IL_000E;
            }
            IL_000E: ;
            ref __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e v3 = ref a;
            global::OpenRA.Mods.Common.Traits.ProductionState v4 = __cil_value_call_0A001D14(ref v3);
            int v5 = __cil_bool_load(v4.Visible);
            return __cil_bool_store(v5);
            IL_001B: ;
            int v6 = 1;
            return __cil_bool_store(v6);
        }

        // Metadata name: <.ctor>b__25_1
        internal OpenRA.ActorInfo CtorLambda25_1(System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState> a)
        {
            // structural signature __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e bytes=15118235021284211293A0: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e v0 = ref a;
            __cil_type_01000108 v1 = __cil_value_call_0A001D15(ref v0);
            return v1;
        }

        // Metadata name: <.ctor>b__25_2
        internal bool CtorLambda25_2(System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState> a)
        {
            // structural signature __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e bytes=15118235021284211293A0: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e v0 = ref a;
            global::OpenRA.Mods.Common.Traits.ProductionState v1 = __cil_value_call_0A001D14(ref v0);
            int v2 = __cil_bool_load(v1.Buildable);
            return __cil_bool_store(v2);
        }

        // Metadata name: <.ctor>b__25_3
        internal OpenRA.ActorInfo CtorLambda25_3(System.Collections.Generic.KeyValuePair<OpenRA.ActorInfo, OpenRA.Mods.Common.Traits.ProductionState> a)
        {
            // structural signature __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e bytes=15118235021284211293A0: valuetype [System.Runtime]System.Collections.Generic.KeyValuePair`2<class [OpenRA.Game]OpenRA.ActorInfo, class OpenRA.Mods.Common.Traits.ProductionState>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            IL_0000: ;
            ref __cil_value_029a6f483dcfcf9deb81cc6d93ba510a16a0ff6e v0 = ref a;
            __cil_type_01000108 v1 = __cil_value_call_0A001D15(ref v0);
            return v1;
        }

        // Metadata name: <AllItems>b__45_0
        internal bool AllItemsLambda45_0(OpenRA.Mods.Common.Traits.Production p)
        {
            return p.get_IsTraitDisabled();
        }

        // Metadata name: <BuildableItems>b__46_0
        internal bool BuildableItemsLambda46_0(OpenRA.Mods.Common.Traits.Production p)
        {
            return p.get_IsTraitDisabled();
        }

        // Metadata name: <AnyItemsToBuild>b__47_0
        internal bool AnyItemsToBuildLambda47_0(OpenRA.Mods.Common.Traits.Production p)
        {
            int v1 = __cil_bool_load(p.get_IsTraitDisabled());
            return (v1 == 0);
        }

        // Metadata name: <CancelUnbuildableItems>b__52_0
        internal string CancelUnbuildableItemsLambda52_0(OpenRA.ActorInfo b)
        {
            string v1 = b.Name;
            return v1;
        }

        // Metadata name: <MostLikelyProducer>b__63_1
        internal bool MostLikelyProducerLambda63_1(OpenRA.Mods.Common.Traits.Production p)
        {
            return p.get_IsTraitPaused();
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333365F30
    {
        public string category;

        public __name_3C3E635F5F446973706C6179436C61737333365F30() : base()
        {
            return;
        }

        // Metadata name: <AllBuildables>b__0
        internal bool AllBuildablesLambda0(OpenRA.ActorInfo x)
        {
            // structural signature __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 bytes=151280B9010E: class [System.Collections]System.Collections.Generic.HashSet`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v1 = x.Name;
            int v3 = unchecked((int)(__cil_callvirt_0A000474(v1, 0)));
            if (v3 == 94) {
                return false;
            } else {
                goto IL_0010;
            }
            IL_0010: ;
            int v6 = __cil_bool_load(__cil_callvirt_2B0008E2(x));
            if (v6 == 0) {
                return false;
            } else {
                goto IL_0018;
            }
            IL_0018: ;
            global::OpenRA.Mods.Common.Traits.BuildableInfo v8 = __cil_callvirt_2B000189(x);
            __cil_ref_f9ce568251af2f3ee6cc05d1c8ed599be3647b67 v9 = v8.Queue;
            string v11 = this.category;
            return __cil_callvirt_0A0002A0(v9, v11);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334325F30
    {
        public OpenRA.ActorInfo actor;

        public __name_3C3E635F5F446973706C6179436C61737334325F30() : base()
        {
            return;
        }

        // Metadata name: <IsInQueue>b__0
        internal bool IsInQueueLambda0(OpenRA.Mods.Common.Traits.ProductionItem i)
        {
            string v1 = i.Item;
            __cil_type_01000108 v3 = this.actor;
            string v4 = v3.Name;
            return System.String.op_Equality(v1, v4);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335335F30
    {
        public OpenRA.ActorInfo actor;
        public OpenRA.Mods.Common.Traits.ProductionQueue __il_field_04003554;

        public __name_3C3E635F5F446973706C6179436C61737335335F30() : base()
        {
            return;
        }

        // Metadata name: <CanQueue>b__0
        internal bool CanQueueLambda0(OpenRA.Mods.Common.Traits.ProductionItem i)
        {
            string v1 = i.Item;
            __cil_type_01000108 v3 = this.actor;
            string v4 = v3.Name;
            return System.String.op_Equality(v1, v4);
        }

        // Metadata name: <CanQueue>b__1
        internal bool CanQueueLambda1(OpenRA.Actor a)
        {
            __cil_type_01000108 v1 = a.Info;
            string v2 = v1.Name;
            __cil_type_01000108 v4 = this.actor;
            string v5 = v4.Name;
            int v6 = __cil_bool_load(System.String.op_Equality(v2, v5));
            if (v6 == 0) {
                return false;
            } else {
                goto IL_001D;
            }
            IL_001D: ;
            __cil_type_01000030 v8 = ((OpenRA.Actor)a).Owner;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v10 = this.__il_field_04003554;
            __cil_type_01000025 v11 = __cil_direct_06001958(v10);
            __cil_type_01000030 v12 = ((OpenRA.Actor)v11).Owner;
            return (System.Object.ReferenceEquals(v8, v12));
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335345F30
    {
        public OpenRA.Order order;
        public OpenRA.Actor self;
        public OpenRA.Mods.Common.Traits.ProductionQueue __il_field_04003557;
        public OpenRA.Ruleset rules;

        public __name_3C3E635F5F446973706C6179436C61737335345F30() : base()
        {
            return;
        }

        // Metadata name: <ResolveOrder>b__0
        internal bool ResolveOrderLambda0(OpenRA.ActorInfo b)
        {
            string v1 = b.Name;
            __cil_type_01000046 v3 = this.order;
            string v4 = v3.TargetString;
            return System.String.op_Inequality(v1, v4);
        }

        // Metadata name: <ResolveOrder>b__1
        internal bool ResolveOrderLambda1(OpenRA.Mods.Common.Traits.ProductionItem i)
        {
            string v1 = i.Item;
            __cil_type_01000046 v3 = this.order;
            string v4 = v3.TargetString;
            return System.String.op_Equality(v1, v4);
        }

        // Metadata name: <ResolveOrder>b__2
        internal bool ResolveOrderLambda2(OpenRA.Mods.Common.Traits.ProductionItem pi)
        {
            string v1 = pi.Item;
            __cil_type_01000046 v3 = this.order;
            string v4 = v3.TargetString;
            return System.String.op_Equality(v1, v4);
        }

        // Metadata name: <ResolveOrder>b__3
        internal bool ResolveOrderLambda3(OpenRA.Actor a)
        {
            __cil_type_01000108 v1 = a.Info;
            string v2 = v1.Name;
            __cil_type_01000046 v4 = this.order;
            string v5 = v4.TargetString;
            int v6 = __cil_bool_load(System.String.op_Equality(v2, v5));
            if (v6 == 0) {
                return false;
            } else {
                goto IL_001D;
            }
            IL_001D: ;
            __cil_type_01000030 v8 = ((OpenRA.Actor)a).Owner;
            __cil_type_01000025 v10 = this.self;
            __cil_type_01000030 v11 = ((OpenRA.Actor)v10).Owner;
            return (System.Object.ReferenceEquals(v8, v11));
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335345F31
    {
        public OpenRA.ActorInfo unit;
        public int time;
        public OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 __il_field_0400355B;
        public System.Func<OpenRA.Mods.Common.Traits.ProductionItem, bool> __il_field_0400355C;

        public __name_3C3E635F5F446973706C6179436C61737335345F31() : base()
        {
            return;
        }

        // Metadata name: <ResolveOrder>b__6
        internal bool ResolveOrderLambda6(OpenRA.Mods.Common.Traits.ProductionItem i)
        {
            int v1 = __cil_bool_load(__cil_callvirt_06001999(i));
            if (v1 == 0) {
                return false;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            string v3 = i.Item;
            __cil_type_01000108 v5 = this.unit;
            string v6 = v5.Name;
            return System.String.op_Equality(v3, v6);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335345F32
    {
        public bool hasPlayedSound;
        public OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 __il_field_0400355E;
        public System.Action<OpenRA.World> __il_field_0400355F;

        public __name_3C3E635F5F446973706C6179436C61737335345F32() : base()
        {
            return;
        }

        // Metadata name: <ResolveOrder>b__4
        internal void ResolveOrderLambda4()
        {
            // structural signature __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 bytes=15128159011280B5: class [System.Runtime]System.Action`1<class [OpenRA.Game]OpenRA.World>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_0100002D s1_0 = default;
            __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 s1_1 = default;
            __cil_type_0100002D s2_0 = default;
            __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 s2_1 = default;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v1 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v2 = v1.__il_field_0400355B;
            __cil_type_01000025 v3 = v2.self;
            __cil_type_0100002D v4 = v3.World;
            __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 v6 = this.__il_field_0400355F;
            if (v6 is not null) {
                __cil_type_0100002D e0_2_0 = v4;
                __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 e0_2_1 = v6;
                s2_0 = e0_2_0;
                s2_1 = e0_2_1;
                goto IL_0034;
            } else {
                __cil_type_0100002D e0_1_0 = v4;
                __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 e0_1_1 = v6;
                s1_0 = e0_1_0;
                s1_1 = e0_1_1;
                goto IL_001E;
            }
            IL_001E: ;
            nint v9 = __cil_ldftn_06004023;
            __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 v10 = __cil_newobj_0A00028C(this, v9);
            this.__il_field_0400355F = v10;
            __cil_type_0100002D e1_2_0 = s1_0;
            __cil_ref_56742c4ceb1db92a8003d4c88feb2842f6485202 e1_2_1 = v10;
            s2_0 = e1_2_0;
            s2_1 = e1_2_1;
            IL_0034: ;
            s2_0.AddFrameEndTask(s2_1);
            return;
        }

        // Metadata name: <ResolveOrder>b__5
        internal void ResolveOrderLambda5(OpenRA.World _)
        {
            // structural signature __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 bytes=1512811D011293A4: class [System.Collections]System.Collections.Generic.List`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a bytes=15128121021293A402: class [System.Runtime]System.Func`2<class OpenRA.Mods.Common.Traits.ProductionItem, bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4 bytes=151280A1011293A4: class [System.Runtime]System.Collections.Generic.IEnumerable`1<class OpenRA.Mods.Common.Traits.ProductionItem>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            bool l0 = default;
            __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 s1_0 = default;
            __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a s1_1 = default;
            __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 s2_0 = default;
            __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a s2_1 = default;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v1 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v2 = v1.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v3 = v2.__il_field_04003557;
            __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 v4 = v3.Queue;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v6 = this.__il_field_0400355E;
            __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v7 = v6.__il_field_0400355C;
            if (v7 is not null) {
                __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 e0_2_0 = v4;
                __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a e0_2_1 = v7;
                s2_0 = e0_2_0;
                s2_1 = e0_2_1;
                goto IL_0043;
            } else {
                __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 e0_1_0 = v4;
                __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a e0_1_1 = v7;
                s1_0 = e0_1_0;
                s1_1 = e0_1_1;
                goto IL_0023;
            }
            IL_0023: ;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v9 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v11 = this.__il_field_0400355E;
            nint v12 = __cil_ldftn_06004020;
            __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a v13 = __cil_newobj_0A00083A(v11, v12);
            v9.__il_field_0400355C = v13;
            __cil_ref_363f0ff04a5b9e386ee41c3d2a45ee5f4aaf5f64 e1_2_0 = s1_0;
            __cil_ref_e042c9e3961ac6f2654f9d254d60d2e25ef2740a e1_2_1 = v13;
            s2_0 = e1_2_0;
            s2_1 = e1_2_1;
            IL_0043: ;
            int v15 = __cil_bool_load(__cil_methodspec_call_2B00030F(((__cil_ref_8dc124e61c5a3b7cca1754f5798f03c0b5279ee4)(s2_0)), s2_1));
            if (v15 != 0) {
                goto IL_004B;
            } else {
                goto IL_004A;
            }
            IL_004A: ;
            return;
            IL_004B: ;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v17 = this.__il_field_0400355E;
            __cil_type_01000108 v18 = v17.unit;
            int v19 = __cil_bool_load(__cil_callvirt_2B0002FD(v18));
            l0 = __cil_bool_store(v19);
            int v20 = __cil_bool_load(l0);
            if (v20 == 0) {
                goto IL_0115;
            } else {
                goto IL_0062;
            }
            IL_0062: ;
            int v22 = __cil_bool_load(this.hasPlayedSound);
            if (v22 != 0) {
                goto IL_0115;
            } else {
                goto IL_006D;
            }
            IL_006D: ;
            __cil_type_0100026E v24 = __cil_ldsfld_0A00028E();
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v26 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v27 = v26.__il_field_0400355B;
            __cil_type_0100007F v28 = v27.rules;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v30 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v31 = v30.__il_field_0400355B;
            __cil_type_01000025 v32 = v31.self;
            __cil_type_01000030 v33 = ((OpenRA.Actor)v32).Owner;
            string v34 = __cil_ldstr_7000E82E("Speech");
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v36 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v37 = v36.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v38 = v37.__il_field_04003557;
            global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v39 = v38.Info;
            string v40 = v39.ReadyAudio;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v42 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v43 = v42.__il_field_0400355B;
            __cil_type_01000025 v44 = v43.self;
            __cil_type_01000030 v45 = ((OpenRA.Actor)v44).Owner;
            __cil_type_010000F5 v46 = v45.Faction;
            string v47 = v46.InternalName;
            int v48 = __cil_bool_load(v24.PlayNotification(v28, v33, v34, v40, v47));
            this.hasPlayedSound = __cil_bool_store(v48);
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v50 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v51 = v50.__il_field_0400355B;
            __cil_type_01000025 v52 = v51.self;
            __cil_type_01000030 v53 = ((OpenRA.Actor)v52).Owner;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v55 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v56 = v55.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v57 = v56.__il_field_04003557;
            global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v58 = v57.Info;
            string v59 = v58.ReadyTextNotification;
            OpenRA.TextNotificationsManager.AddTransientLine(v53, v59);
            return;
            IL_0115: ;
            int v60 = __cil_bool_load(l0);
            if (v60 != 0) {
                goto IL_02A6;
            } else {
                goto IL_011B;
            }
            IL_011B: ;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v62 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v63 = v62.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v64 = v63.__il_field_04003557;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v66 = this.__il_field_0400355E;
            __cil_type_01000108 v67 = v66.unit;
            int v68 = __cil_bool_load(__cil_callvirt_06001986(v64, v67));
            if (v68 == 0) {
                goto IL_01E3;
            } else {
                goto IL_0140;
            }
            IL_0140: ;
            __cil_type_0100026E v69 = __cil_ldsfld_0A00028E();
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v71 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v72 = v71.__il_field_0400355B;
            __cil_type_0100007F v73 = v72.rules;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v75 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v76 = v75.__il_field_0400355B;
            __cil_type_01000025 v77 = v76.self;
            __cil_type_01000030 v78 = ((OpenRA.Actor)v77).Owner;
            string v79 = __cil_ldstr_7000E82E("Speech");
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v81 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v82 = v81.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v83 = v82.__il_field_04003557;
            global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v84 = v83.Info;
            string v85 = v84.ReadyAudio;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v87 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v88 = v87.__il_field_0400355B;
            __cil_type_01000025 v89 = v88.self;
            __cil_type_01000030 v90 = ((OpenRA.Actor)v89).Owner;
            __cil_type_010000F5 v91 = v90.Faction;
            string v92 = v91.InternalName;
            int v93 = __cil_bool_load(v69.PlayNotification(v73, v78, v79, v85, v92));
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v95 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v96 = v95.__il_field_0400355B;
            __cil_type_01000025 v97 = v96.self;
            __cil_type_01000030 v98 = ((OpenRA.Actor)v97).Owner;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v100 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v101 = v100.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v102 = v101.__il_field_04003557;
            global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v103 = v102.Info;
            string v104 = v103.ReadyTextNotification;
            OpenRA.TextNotificationsManager.AddTransientLine(v98, v104);
            return;
            IL_01E3: ;
            int v106 = __cil_bool_load(this.hasPlayedSound);
            if (v106 != 0) {
                goto IL_02A6;
            } else {
                goto IL_01EE;
            }
            IL_01EE: ;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v108 = this.__il_field_0400355E;
            int v109 = v108.time;
            if (v109 <= 0) {
                goto IL_02A6;
            } else {
                goto IL_01FF;
            }
            IL_01FF: ;
            __cil_type_0100026E v112 = __cil_ldsfld_0A00028E();
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v114 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v115 = v114.__il_field_0400355B;
            __cil_type_0100007F v116 = v115.rules;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v118 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v119 = v118.__il_field_0400355B;
            __cil_type_01000025 v120 = v119.self;
            __cil_type_01000030 v121 = ((OpenRA.Actor)v120).Owner;
            string v122 = __cil_ldstr_7000E82E("Speech");
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v124 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v125 = v124.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v126 = v125.__il_field_04003557;
            global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v127 = v126.Info;
            string v128 = v127.BlockedAudio;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v130 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v131 = v130.__il_field_0400355B;
            __cil_type_01000025 v132 = v131.self;
            __cil_type_01000030 v133 = ((OpenRA.Actor)v132).Owner;
            __cil_type_010000F5 v134 = v133.Faction;
            string v135 = v134.InternalName;
            int v136 = __cil_bool_load(v112.PlayNotification(v116, v121, v122, v128, v135));
            this.hasPlayedSound = __cil_bool_store(v136);
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v138 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v139 = v138.__il_field_0400355B;
            __cil_type_01000025 v140 = v139.self;
            __cil_type_01000030 v141 = ((OpenRA.Actor)v140).Owner;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F31 v143 = this.__il_field_0400355E;
            global::OpenRA.Mods.Common.Traits.ProductionQueue.__name_3C3E635F5F446973706C6179436C61737335345F30 v144 = v143.__il_field_0400355B;
            global::OpenRA.Mods.Common.Traits.ProductionQueue v145 = v144.__il_field_04003557;
            global::OpenRA.Mods.Common.Traits.ProductionQueueInfo v146 = v145.Info;
            string v147 = v146.BlockedTextNotification;
            OpenRA.TextNotificationsManager.AddTransientLine(v141, v147);
            IL_02A6: ;
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335375F30
    {
        public string itemName;

        public __name_3C3E635F5F446973706C6179436C61737335375F30() : base()
        {
            return;
        }

        // Metadata name: <PauseProduction>b__0
        internal bool PauseProductionLambda0(OpenRA.Mods.Common.Traits.ProductionItem a)
        {
            string v1 = a.Item;
            string v3 = this.itemName;
            return System.String.op_Equality(v1, v3);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335395F30
    {
        public string itemName;

        public __name_3C3E635F5F446973706C6179436C61737335395F30() : base()
        {
            return;
        }

        // Metadata name: <CancelProductionInner>b__0
        internal bool CancelProductionInnerLambda0(OpenRA.Mods.Common.Traits.ProductionItem a)
        {
            string v1 = a.Item;
            string v3 = this.itemName;
            return System.String.op_Equality(v1, v3);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336315F30
    {
        public OpenRA.Mods.Common.Traits.ProductionItem item;

        public __name_3C3E635F5F446973706C6179436C61737336315F30() : base()
        {
            return;
        }

        // Metadata name: <BeginProduction>b__0
        internal bool BeginProductionLambda0(OpenRA.Mods.Common.Traits.ProductionItem i)
        {
            string v1 = i.Item;
            global::OpenRA.Mods.Common.Traits.ProductionItem v3 = this.item;
            string v4 = v3.Item;
            int v5 = __cil_bool_load(System.String.op_Equality(v1, v4));
            if (v5 == 0) {
                return false;
            } else {
                goto IL_0018;
            }
            IL_0018: ;
            return __cil_callvirt_0600199F(i);
        }

        // Metadata name: <BeginProduction>b__1
        internal bool BeginProductionLambda1(OpenRA.Mods.Common.Traits.ProductionItem i)
        {
            string v1 = i.Item;
            global::OpenRA.Mods.Common.Traits.ProductionItem v3 = this.item;
            string v4 = v3.Item;
            return System.String.op_Equality(v1, v4);
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336345F30
    {
        public OpenRA.ActorInfo unit;

        public __name_3C3E635F5F446973706C6179436C61737336345F30() : base()
        {
            return;
        }

        // Metadata name: <BuildUnit>b__0
        internal bool BuildUnitLambda0(OpenRA.Mods.Common.Traits.ProductionItem i)
        {
            int v1 = __cil_bool_load(__cil_callvirt_06001999(i));
            if (v1 == 0) {
                return false;
            } else {
                goto IL_0008;
            }
            IL_0008: ;
            string v3 = i.Item;
            __cil_type_01000108 v5 = this.unit;
            string v6 = v5.Name;
            return System.String.op_Equality(v3, v6);
        }
    }
}

// Dependency identity substituted: System.Runtime, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.TypeConverter, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.TypeConverter, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ObjectModel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ObjectModel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Linq, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Linq, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Http, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Http, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Immutable, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Immutable, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Text.RegularExpressions, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Text.RegularExpressions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Console, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Console, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.IO.FileSystem.DriveInfo, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.IO.FileSystem.DriveInfo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Net.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Net.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Collections.Concurrent, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Collections.Concurrent, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Tasks.Parallel, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Tasks.Parallel, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.InteropServices.RuntimeInformation, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.InteropServices.RuntimeInformation, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.ComponentModel.Primitives, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.ComponentModel.Primitives, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.Thread, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.Thread, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Runtime.Serialization.Formatters, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Runtime.Serialization.Formatters, Version=8.1.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.Win32.Registry, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.Win32.Registry, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Threading.ThreadPool, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> System.Threading.ThreadPool, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: System.Memory, Version=6.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0 -> System.Memory, Version=10.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependencies unresolved: 11; exact references retained; see --details for identities and provenance.
