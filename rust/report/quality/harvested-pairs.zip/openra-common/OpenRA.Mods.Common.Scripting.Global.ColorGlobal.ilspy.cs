using Eluant;
using OpenRA.Primitives;
using OpenRA.Scripting;

namespace OpenRA.Mods.Common.Scripting.Global;

[ScriptGlobal("HSLColor")]
public class ColorGlobal : ScriptGlobal
{
	[Desc(new string[] { "FromHex(\"00FFFF\")" })]
	public Color Aqua => Color.Aqua;

	[Desc(new string[] { "FromHex(\"000000\")" })]
	public Color Black => Color.Black;

	[Desc(new string[] { "FromHex(\"0000FF\")" })]
	public Color Blue => Color.Blue;

	[Desc(new string[] { "FromHex(\"A52A2A\")" })]
	public Color Brown => Color.Brown;

	[Desc(new string[] { "FromHex(\"00FFFF\")" })]
	public Color Cyan => Color.Cyan;

	[Desc(new string[] { "FromHex(\"00008B\")" })]
	public Color DarkBlue => Color.DarkBlue;

	[Desc(new string[] { "FromHex(\"008B8B\")" })]
	public Color DarkCyan => Color.DarkCyan;

	[Desc(new string[] { "FromHex(\"A9A9A9\")" })]
	public Color DarkGray => Color.DarkGray;

	[Desc(new string[] { "FromHex(\"006400\")" })]
	public Color DarkGreen => Color.DarkGreen;

	[Desc(new string[] { "FromHex(\"FF8C00\")" })]
	public Color DarkOrange => Color.DarkOrange;

	[Desc(new string[] { "FromHex(\"8B0000\")" })]
	public Color DarkRed => Color.DarkRed;

	[Desc(new string[] { "FromHex(\"FF00FF\")" })]
	public Color Fuchsia => Color.Fuchsia;

	[Desc(new string[] { "FromHex(\"FFD700\")" })]
	public Color Gold => Color.Gold;

	[Desc(new string[] { "FromHex(\"808080\")" })]
	public Color Gray => Color.Gray;

	[Desc(new string[] { "FromHex(\"008000\")" })]
	public Color Green => Color.Green;

	[Desc(new string[] { "FromHex(\"7CFC00\")" })]
	public Color LawnGreen => Color.LawnGreen;

	[Desc(new string[] { "FromHex(\"ADD8E6\")" })]
	public Color LightBlue => Color.LightBlue;

	[Desc(new string[] { "FromHex(\"E0FFFF\")" })]
	public Color LightCyan => Color.LightCyan;

	[Desc(new string[] { "FromHex(\"D3D3D3\")" })]
	public Color LightGray => Color.LightGray;

	[Desc(new string[] { "FromHex(\"90EE90\")" })]
	public Color LightGreen => Color.LightGreen;

	[Desc(new string[] { "FromHex(\"FFFFE0\")" })]
	public Color LightYellow => Color.LightYellow;

	[Desc(new string[] { "FromHex(\"00FF00\")" })]
	public Color Lime => Color.Lime;

	[Desc(new string[] { "FromHex(\"32CD32\")" })]
	public Color LimeGreen => Color.LimeGreen;

	[Desc(new string[] { "FromHex(\"FF00FF\")" })]
	public Color Magenta => Color.Magenta;

	[Desc(new string[] { "FromHex(\"800000\")" })]
	public Color Maroon => Color.Maroon;

	[Desc(new string[] { "FromHex(\"000080\")" })]
	public Color Navy => Color.Navy;

	[Desc(new string[] { "FromHex(\"808000\")" })]
	public Color Olive => Color.Olive;

	[Desc(new string[] { "FromHex(\"FFA500\")" })]
	public Color Orange => Color.Orange;

	[Desc(new string[] { "FromHex(\"FF4500\")" })]
	public Color OrangeRed => Color.OrangeRed;

	[Desc(new string[] { "FromHex(\"800080\")" })]
	public Color Purple => Color.Purple;

	[Desc(new string[] { "FromHex(\"FF0000\")" })]
	public Color Red => Color.Red;

	[Desc(new string[] { "FromHex(\"FA8072\")" })]
	public Color Salmon => Color.Salmon;

	[Desc(new string[] { "FromHex(\"87CEEB\")" })]
	public Color SkyBlue => Color.SkyBlue;

	[Desc(new string[] { "FromHex(\"008080\")" })]
	public Color Teal => Color.Teal;

	[Desc(new string[] { "FromHex(\"FFFF00\")" })]
	public Color Yellow => Color.Yellow;

	[Desc(new string[] { "FromHex(\"FFFFFF\")" })]
	public Color White => Color.White;

	public ColorGlobal(ScriptContext context)
		: base(context)
	{
	}

	[Desc(new string[] { "Create a new color with the specified hue/saturation/luminosity." })]
	public Color New(int hue, int saturation, int luminosity)
	{
		byte b = (byte)hue.Clamp(0, 255);
		byte b2 = (byte)saturation.Clamp(0, 255);
		byte b3 = (byte)luminosity.Clamp(0, 255);
		return Color.FromAhsl(255, (float)(int)b / 255f, (float)(int)b2 / 255f, (float)(int)b3 / 255f);
	}

	[Desc(new string[] { "Create a new color with the specified red/green/blue/[alpha] values." })]
	public Color FromRGB(int red, int green, int blue, int alpha = 255)
	{
		return Color.FromArgb(alpha.Clamp(0, 255), red.Clamp(0, 255), green.Clamp(0, 255), blue.Clamp(0, 255));
	}

	[Desc(new string[] { "Create a new color with the specified red/green/blue/[alpha] hex string (rrggbb[aa])." })]
	public Color FromHex(string value)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (Color.TryParse(value, out var color))
		{
			return color;
		}
		throw new LuaException("Invalid rrggbb[aa] hex string.");
	}
}
