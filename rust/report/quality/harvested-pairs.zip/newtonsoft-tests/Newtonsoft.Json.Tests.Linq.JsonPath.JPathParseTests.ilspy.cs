using System.Collections.Generic;
using NUnit.Framework;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Linq.JsonPath;

namespace Newtonsoft.Json.Tests.Linq.JsonPath;

[TestFixture]
public class JPathParseTests : TestFixtureBase
{
	[Test]
	public void BooleanQuery_TwoValues()
	{
		JPath jPath = new JPath("[?(1 > 2)]");
		Assert.AreEqual(1, jPath.Filters.Count);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(1, (int)(JToken)(JValue)booleanQueryExpression.Left);
		Assert.AreEqual(2, (int)(JToken)(JValue)booleanQueryExpression.Right);
		Assert.AreEqual(QueryOperator.GreaterThan, booleanQueryExpression.Operator);
	}

	[Test]
	public void BooleanQuery_TwoPaths()
	{
		JPath jPath = new JPath("[?(@.price > @.max_price)]");
		Assert.AreEqual(1, jPath.Filters.Count);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		List<PathFilter> list = (List<PathFilter>)booleanQueryExpression.Left;
		List<PathFilter> list2 = (List<PathFilter>)booleanQueryExpression.Right;
		Assert.AreEqual("price", ((FieldFilter)list[0]).Name);
		Assert.AreEqual("max_price", ((FieldFilter)list2[0]).Name);
		Assert.AreEqual(QueryOperator.GreaterThan, booleanQueryExpression.Operator);
	}

	[Test]
	public void SingleProperty()
	{
		JPath jPath = new JPath("Blah");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void SingleQuotedProperty()
	{
		JPath jPath = new JPath("['Blah']");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void SingleQuotedPropertyWithWhitespace()
	{
		JPath jPath = new JPath("[  'Blah'  ]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void SingleQuotedPropertyWithDots()
	{
		JPath jPath = new JPath("['Blah.Ha']");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("Blah.Ha", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void SingleQuotedPropertyWithBrackets()
	{
		JPath jPath = new JPath("['[*]']");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("[*]", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void SinglePropertyWithRoot()
	{
		JPath jPath = new JPath("$.Blah");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void SinglePropertyWithRootWithStartAndEndWhitespace()
	{
		JPath jPath = new JPath(" $.Blah ");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void RootWithBadWhitespace()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("$ .Blah");
		}, new string[1] { "Unexpected character while parsing path:  " });
	}

	[Test]
	public void NoFieldNameAfterDot()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("$.Blah.");
		}, new string[1] { "Unexpected end while parsing path." });
	}

	[Test]
	public void RootWithBadWhitespace2()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("$. Blah");
		}, new string[1] { "Unexpected character while parsing path:  " });
	}

	[Test]
	public void WildcardPropertyWithRoot()
	{
		JPath jPath = new JPath("$.*");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(null, ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void WildcardArrayWithRoot()
	{
		JPath jPath = new JPath("$.[*]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(null, ((ArrayIndexFilter)jPath.Filters[0]).Index);
	}

	[Test]
	public void RootArrayNoDot()
	{
		JPath jPath = new JPath("$[1]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(1, ((ArrayIndexFilter)jPath.Filters[0]).Index);
	}

	[Test]
	public void WildcardArray()
	{
		JPath jPath = new JPath("[*]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(null, ((ArrayIndexFilter)jPath.Filters[0]).Index);
	}

	[Test]
	public void WildcardArrayWithProperty()
	{
		JPath jPath = new JPath("[ * ].derp");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual(null, ((ArrayIndexFilter)jPath.Filters[0]).Index);
		Assert.AreEqual("derp", ((FieldFilter)jPath.Filters[1]).Name);
	}

	[Test]
	public void QuotedWildcardPropertyWithRoot()
	{
		JPath jPath = new JPath("$.['*']");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("*", ((FieldFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void SingleScanWithRoot()
	{
		JPath jPath = new JPath("$..Blah");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((ScanFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void QueryTrue()
	{
		JPath jPath = new JPath("$.elements[?(true)]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("elements", ((FieldFilter)jPath.Filters[0]).Name);
		Assert.AreEqual(QueryOperator.Exists, ((QueryFilter)jPath.Filters[1]).Expression.Operator);
	}

	[Test]
	public void ScanQuery()
	{
		JPath jPath = new JPath("$.elements..[?(@.id=='AAA')]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("elements", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryScanFilter)jPath.Filters[1]).Expression;
		List<PathFilter> list = (List<PathFilter>)booleanQueryExpression.Left;
		Assert.IsInstanceOf(typeof(FieldFilter), list[0]);
	}

	[Test]
	public void WildcardScanWithRoot()
	{
		JPath jPath = new JPath("$..*");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(null, ((ScanFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void WildcardScanWithRootWithWhitespace()
	{
		JPath jPath = new JPath("$..* ");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(null, ((ScanFilter)jPath.Filters[0]).Name);
	}

	[Test]
	public void TwoProperties()
	{
		JPath jPath = new JPath("Blah.Two");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		Assert.AreEqual("Two", ((FieldFilter)jPath.Filters[1]).Name);
	}

	[Test]
	public void OnePropertyOneScan()
	{
		JPath jPath = new JPath("Blah..Two");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		Assert.AreEqual("Two", ((ScanFilter)jPath.Filters[1]).Name);
	}

	[Test]
	public void SinglePropertyAndIndexer()
	{
		JPath jPath = new JPath("Blah[0]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		Assert.AreEqual(0, ((ArrayIndexFilter)jPath.Filters[1]).Index);
	}

	[Test]
	public void SinglePropertyAndExistsQuery()
	{
		JPath jPath = new JPath("Blah[ ?( @..name ) ]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[1]).Expression;
		Assert.AreEqual(QueryOperator.Exists, booleanQueryExpression.Operator);
		List<PathFilter> list = (List<PathFilter>)booleanQueryExpression.Left;
		Assert.AreEqual(1, list.Count);
		Assert.AreEqual("name", ((ScanFilter)list[0]).Name);
	}

	[Test]
	public void SinglePropertyAndFilterWithWhitespace()
	{
		JPath jPath = new JPath("Blah[ ?( @.name=='hi' ) ]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[1]).Expression;
		Assert.AreEqual(QueryOperator.Equals, booleanQueryExpression.Operator);
		Assert.AreEqual("hi", (string)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void SinglePropertyAndFilterWithEscapeQuote()
	{
		JPath jPath = new JPath("Blah[ ?( @.name=='h\\'i' ) ]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[1]).Expression;
		Assert.AreEqual(QueryOperator.Equals, booleanQueryExpression.Operator);
		Assert.AreEqual("h'i", (string)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void SinglePropertyAndFilterWithDoubleEscape()
	{
		JPath jPath = new JPath("Blah[ ?( @.name=='h\\\\i' ) ]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[1]).Expression;
		Assert.AreEqual(QueryOperator.Equals, booleanQueryExpression.Operator);
		Assert.AreEqual("h\\i", (string)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void SinglePropertyAndFilterWithUnknownEscape()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("Blah[ ?( @.name=='h\\i' ) ]");
		}, new string[1] { "Unknown escape character: \\i" });
	}

	[Test]
	public void SinglePropertyAndFilterWithFalse()
	{
		JPath jPath = new JPath("Blah[ ?( @.name==false ) ]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[1]).Expression;
		Assert.AreEqual(QueryOperator.Equals, booleanQueryExpression.Operator);
		Assert.AreEqual(false, (bool)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void SinglePropertyAndFilterWithTrue()
	{
		JPath jPath = new JPath("Blah[ ?( @.name==true ) ]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[1]).Expression;
		Assert.AreEqual(QueryOperator.Equals, booleanQueryExpression.Operator);
		Assert.AreEqual(true, (bool)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void SinglePropertyAndFilterWithNull()
	{
		JPath jPath = new JPath("Blah[ ?( @.name==null ) ]");
		Assert.AreEqual(2, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[1]).Expression;
		Assert.AreEqual(QueryOperator.Equals, booleanQueryExpression.Operator);
		Assert.AreEqual(null, ((JValue)booleanQueryExpression.Right).Value);
	}

	[Test]
	public void FilterWithScan()
	{
		JPath jPath = new JPath("[?(@..name<>null)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		List<PathFilter> list = (List<PathFilter>)booleanQueryExpression.Left;
		Assert.AreEqual("name", ((ScanFilter)list[0]).Name);
	}

	[Test]
	public void FilterWithNotEquals()
	{
		JPath jPath = new JPath("[?(@.name<>null)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.NotEquals, booleanQueryExpression.Operator);
	}

	[Test]
	public void FilterWithNotEquals2()
	{
		JPath jPath = new JPath("[?(@.name!=null)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.NotEquals, booleanQueryExpression.Operator);
	}

	[Test]
	public void FilterWithLessThan()
	{
		JPath jPath = new JPath("[?(@.name<null)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.LessThan, booleanQueryExpression.Operator);
	}

	[Test]
	public void FilterWithLessThanOrEquals()
	{
		JPath jPath = new JPath("[?(@.name<=null)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.LessThanOrEquals, booleanQueryExpression.Operator);
	}

	[Test]
	public void FilterWithGreaterThan()
	{
		JPath jPath = new JPath("[?(@.name>null)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.GreaterThan, booleanQueryExpression.Operator);
	}

	[Test]
	public void FilterWithGreaterThanOrEquals()
	{
		JPath jPath = new JPath("[?(@.name>=null)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.GreaterThanOrEquals, booleanQueryExpression.Operator);
	}

	[Test]
	public void FilterWithInteger()
	{
		JPath jPath = new JPath("[?(@.name>=12)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(12, (int)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void FilterWithNegativeInteger()
	{
		JPath jPath = new JPath("[?(@.name>=-12)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(-12, (int)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void FilterWithFloat()
	{
		JPath jPath = new JPath("[?(@.name>=12.1)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(12.1, (double)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void FilterExistWithAnd()
	{
		JPath jPath = new JPath("[?(@.name&&@.title)]");
		CompositeExpression compositeExpression = (CompositeExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.And, compositeExpression.Operator);
		Assert.AreEqual(2, compositeExpression.Expressions.Count);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)compositeExpression.Expressions[0];
		List<PathFilter> list = (List<PathFilter>)booleanQueryExpression.Left;
		Assert.AreEqual("name", ((FieldFilter)list[0]).Name);
		Assert.AreEqual(QueryOperator.Exists, booleanQueryExpression.Operator);
		BooleanQueryExpression booleanQueryExpression2 = (BooleanQueryExpression)compositeExpression.Expressions[1];
		List<PathFilter> list2 = (List<PathFilter>)booleanQueryExpression2.Left;
		Assert.AreEqual("title", ((FieldFilter)list2[0]).Name);
		Assert.AreEqual(QueryOperator.Exists, booleanQueryExpression2.Operator);
	}

	[Test]
	public void FilterExistWithAndOr()
	{
		JPath jPath = new JPath("[?(@.name&&@.title||@.pie)]");
		CompositeExpression compositeExpression = (CompositeExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(QueryOperator.And, compositeExpression.Operator);
		Assert.AreEqual(2, compositeExpression.Expressions.Count);
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)compositeExpression.Expressions[0];
		List<PathFilter> list = (List<PathFilter>)booleanQueryExpression.Left;
		Assert.AreEqual("name", ((FieldFilter)list[0]).Name);
		Assert.AreEqual(QueryOperator.Exists, booleanQueryExpression.Operator);
		CompositeExpression compositeExpression2 = (CompositeExpression)compositeExpression.Expressions[1];
		Assert.AreEqual(2, compositeExpression2.Expressions.Count);
		BooleanQueryExpression booleanQueryExpression2 = (BooleanQueryExpression)compositeExpression2.Expressions[0];
		List<PathFilter> list2 = (List<PathFilter>)booleanQueryExpression2.Left;
		Assert.AreEqual("title", ((FieldFilter)list2[0]).Name);
		Assert.AreEqual(QueryOperator.Exists, booleanQueryExpression2.Operator);
		BooleanQueryExpression booleanQueryExpression3 = (BooleanQueryExpression)compositeExpression2.Expressions[1];
		List<PathFilter> list3 = (List<PathFilter>)booleanQueryExpression3.Left;
		Assert.AreEqual("pie", ((FieldFilter)list3[0]).Name);
		Assert.AreEqual(QueryOperator.Exists, booleanQueryExpression3.Operator);
	}

	[Test]
	public void FilterWithRoot()
	{
		JPath jPath = new JPath("[?($.name>=12.1)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		List<PathFilter> list = (List<PathFilter>)booleanQueryExpression.Left;
		Assert.AreEqual(2, list.Count);
		Assert.IsInstanceOf(typeof(RootFilter), list[0]);
		Assert.IsInstanceOf(typeof(FieldFilter), list[1]);
	}

	[Test]
	public void BadOr1()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name||)]");
		}, new string[1] { "Unexpected character while parsing path query: )" });
	}

	[Test]
	public void BaddOr2()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name|)]");
		}, new string[1] { "Unexpected character while parsing path query: |" });
	}

	[Test]
	public void BaddOr3()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name|");
		}, new string[1] { "Unexpected character while parsing path query: |" });
	}

	[Test]
	public void BaddOr4()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name||");
		}, new string[1] { "Path ended with open query." });
	}

	[Test]
	public void NoAtAfterOr()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name||s");
		}, new string[1] { "Unexpected character while parsing path query: s" });
	}

	[Test]
	public void NoPathAfterAt()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name||@");
		}, new string[1] { "Path ended with open query." });
	}

	[Test]
	public void NoPathAfterDot()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name||@.");
		}, new string[1] { "Unexpected end while parsing path." });
	}

	[Test]
	public void NoPathAfterDot2()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[?(@.name||@.)]");
		}, new string[1] { "Unexpected end while parsing path." });
	}

	[Test]
	public void FilterWithFloatExp()
	{
		JPath jPath = new JPath("[?(@.name>=5.56789e+0)]");
		BooleanQueryExpression booleanQueryExpression = (BooleanQueryExpression)((QueryFilter)jPath.Filters[0]).Expression;
		Assert.AreEqual(5.56789, (double)(JToken)booleanQueryExpression.Right);
	}

	[Test]
	public void MultiplePropertiesAndIndexers()
	{
		JPath jPath = new JPath("Blah[0]..Two.Three[1].Four");
		Assert.AreEqual(6, jPath.Filters.Count);
		Assert.AreEqual("Blah", ((FieldFilter)jPath.Filters[0]).Name);
		Assert.AreEqual(0, ((ArrayIndexFilter)jPath.Filters[1]).Index);
		Assert.AreEqual("Two", ((ScanFilter)jPath.Filters[2]).Name);
		Assert.AreEqual("Three", ((FieldFilter)jPath.Filters[3]).Name);
		Assert.AreEqual(1, ((ArrayIndexFilter)jPath.Filters[4]).Index);
		Assert.AreEqual("Four", ((FieldFilter)jPath.Filters[5]).Name);
	}

	[Test]
	public void BadCharactersInIndexer()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("Blah[[0]].Two.Three[1].Four");
		}, new string[1] { "Unexpected character while parsing path indexer: [" });
	}

	[Test]
	public void UnclosedIndexer()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("Blah[0");
		}, new string[1] { "Path ended with open indexer." });
	}

	[Test]
	public void IndexerOnly()
	{
		JPath jPath = new JPath("[111119990]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(111119990, ((ArrayIndexFilter)jPath.Filters[0]).Index);
	}

	[Test]
	public void IndexerOnlyWithWhitespace()
	{
		JPath jPath = new JPath("[  10  ]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(10, ((ArrayIndexFilter)jPath.Filters[0]).Index);
	}

	[Test]
	public void MultipleIndexes()
	{
		JPath jPath = new JPath("[111119990,3]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(2, ((ArrayMultipleIndexFilter)jPath.Filters[0]).Indexes.Count);
		Assert.AreEqual(111119990, ((ArrayMultipleIndexFilter)jPath.Filters[0]).Indexes[0]);
		Assert.AreEqual(3, ((ArrayMultipleIndexFilter)jPath.Filters[0]).Indexes[1]);
	}

	[Test]
	public void MultipleIndexesWithWhitespace()
	{
		JPath jPath = new JPath("[   111119990  ,   3   ]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(2, ((ArrayMultipleIndexFilter)jPath.Filters[0]).Indexes.Count);
		Assert.AreEqual(111119990, ((ArrayMultipleIndexFilter)jPath.Filters[0]).Indexes[0]);
		Assert.AreEqual(3, ((ArrayMultipleIndexFilter)jPath.Filters[0]).Indexes[1]);
	}

	[Test]
	public void MultipleQuotedIndexes()
	{
		JPath jPath = new JPath("['111119990','3']");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(2, ((FieldMultipleFilter)jPath.Filters[0]).Names.Count);
		Assert.AreEqual("111119990", ((FieldMultipleFilter)jPath.Filters[0]).Names[0]);
		Assert.AreEqual("3", ((FieldMultipleFilter)jPath.Filters[0]).Names[1]);
	}

	[Test]
	public void MultipleQuotedIndexesWithWhitespace()
	{
		JPath jPath = new JPath("[ '111119990' , '3' ]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(2, ((FieldMultipleFilter)jPath.Filters[0]).Names.Count);
		Assert.AreEqual("111119990", ((FieldMultipleFilter)jPath.Filters[0]).Names[0]);
		Assert.AreEqual("3", ((FieldMultipleFilter)jPath.Filters[0]).Names[1]);
	}

	[Test]
	public void SlicingIndexAll()
	{
		JPath jPath = new JPath("[111119990:3:2]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(111119990, ((ArraySliceFilter)jPath.Filters[0]).Start);
		Assert.AreEqual(3, ((ArraySliceFilter)jPath.Filters[0]).End);
		Assert.AreEqual(2, ((ArraySliceFilter)jPath.Filters[0]).Step);
	}

	[Test]
	public void SlicingIndex()
	{
		JPath jPath = new JPath("[111119990:3]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(111119990, ((ArraySliceFilter)jPath.Filters[0]).Start);
		Assert.AreEqual(3, ((ArraySliceFilter)jPath.Filters[0]).End);
		Assert.AreEqual(null, ((ArraySliceFilter)jPath.Filters[0]).Step);
	}

	[Test]
	public void SlicingIndexNegative()
	{
		JPath jPath = new JPath("[-111119990:-3:-2]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(-111119990, ((ArraySliceFilter)jPath.Filters[0]).Start);
		Assert.AreEqual(-3, ((ArraySliceFilter)jPath.Filters[0]).End);
		Assert.AreEqual(-2, ((ArraySliceFilter)jPath.Filters[0]).Step);
	}

	[Test]
	public void SlicingIndexEmptyStop()
	{
		JPath jPath = new JPath("[  -3  :  ]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(-3, ((ArraySliceFilter)jPath.Filters[0]).Start);
		Assert.AreEqual(null, ((ArraySliceFilter)jPath.Filters[0]).End);
		Assert.AreEqual(null, ((ArraySliceFilter)jPath.Filters[0]).Step);
	}

	[Test]
	public void SlicingIndexEmptyStart()
	{
		JPath jPath = new JPath("[ : 1 : ]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(null, ((ArraySliceFilter)jPath.Filters[0]).Start);
		Assert.AreEqual(1, ((ArraySliceFilter)jPath.Filters[0]).End);
		Assert.AreEqual(null, ((ArraySliceFilter)jPath.Filters[0]).Step);
	}

	[Test]
	public void SlicingIndexWhitespace()
	{
		JPath jPath = new JPath("[  -111119990  :  -3  :  -2  ]");
		Assert.AreEqual(1, jPath.Filters.Count);
		Assert.AreEqual(-111119990, ((ArraySliceFilter)jPath.Filters[0]).Start);
		Assert.AreEqual(-3, ((ArraySliceFilter)jPath.Filters[0]).End);
		Assert.AreEqual(-2, ((ArraySliceFilter)jPath.Filters[0]).Step);
	}

	[Test]
	public void EmptyIndexer()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[]");
		}, new string[1] { "Array index expected." });
	}

	[Test]
	public void IndexerCloseInProperty()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("]");
		}, new string[1] { "Unexpected character while parsing path: ]" });
	}

	[Test]
	public void AdjacentIndexers()
	{
		JPath jPath = new JPath("[1][0][0][" + int.MaxValue + "]");
		Assert.AreEqual(4, jPath.Filters.Count);
		Assert.AreEqual(1, ((ArrayIndexFilter)jPath.Filters[0]).Index);
		Assert.AreEqual(0, ((ArrayIndexFilter)jPath.Filters[1]).Index);
		Assert.AreEqual(0, ((ArrayIndexFilter)jPath.Filters[2]).Index);
		Assert.AreEqual(int.MaxValue, ((ArrayIndexFilter)jPath.Filters[3]).Index);
	}

	[Test]
	public void MissingDotAfterIndexer()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			new JPath("[1]Blah");
		}, new string[1] { "Unexpected character following indexer: B" });
	}

	[Test]
	public void PropertyFollowingEscapedPropertyName()
	{
		JPath jPath = new JPath("frameworks.dnxcore50.dependencies.['System.Xml.ReaderWriter'].source");
		Assert.AreEqual(5, jPath.Filters.Count);
		Assert.AreEqual("frameworks", ((FieldFilter)jPath.Filters[0]).Name);
		Assert.AreEqual("dnxcore50", ((FieldFilter)jPath.Filters[1]).Name);
		Assert.AreEqual("dependencies", ((FieldFilter)jPath.Filters[2]).Name);
		Assert.AreEqual("System.Xml.ReaderWriter", ((FieldFilter)jPath.Filters[3]).Name);
		Assert.AreEqual("source", ((FieldFilter)jPath.Filters[4]).Name);
	}
}
