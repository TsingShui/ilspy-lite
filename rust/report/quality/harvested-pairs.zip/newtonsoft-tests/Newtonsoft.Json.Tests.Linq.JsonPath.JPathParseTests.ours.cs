namespace Newtonsoft.Json.Tests.Linq.JsonPath;

public class JPathParseTests : Newtonsoft.Json.Tests.TestFixtureBase
{
    public void BooleanQuery_TwoValues()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051A88("[?(1 > 2)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000210 v12 = ((__cil_type_01000210)(object)v11);
        __cil_type_01000211 v13 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v12).Expression;
        __cil_type_01000159 v14 = ((__cil_type_01000159)(object)v13);
        object v16 = ((object)((int)(1)));
        object v18 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v14).Left;
        __cil_type_010000B6 v19 = ((__cil_type_010000B6)(object)v18);
        int v20 = Newtonsoft.Json.Linq.JToken.op_Explicit(((__cil_type_01000091)(v19)));
        object v21 = ((object)((int)(v20)));
        NUnit.Framework.Assert.AreEqual(v16, v21);
        object v23 = ((object)((int)(2)));
        object v25 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v14).Right;
        __cil_type_010000B6 v26 = ((__cil_type_010000B6)(object)v25);
        int v27 = Newtonsoft.Json.Linq.JToken.op_Explicit(((__cil_type_01000091)(v26)));
        object v28 = ((object)((int)(v27)));
        NUnit.Framework.Assert.AreEqual(v23, v28);
        object v30 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(6)));
        int v32 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v14).Operator));
        object v33 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v32)));
        NUnit.Framework.Assert.AreEqual(v30, v33);
        return;
    }

    public void BooleanQuery_TwoPaths()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_7004F0F3("[?(@.price > @.max_price)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000210 v12 = ((__cil_type_01000210)(object)v11);
        __cil_type_01000211 v13 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v12).Expression;
        __cil_type_01000159 v14 = ((__cil_type_01000159)(object)v13);
        object v16 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v14).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v17 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v16);
        object v19 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v14).Right;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v20 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v19);
        string v21 = __cil_ldstr_70051A9E("price");
        __cil_type_0100015A v24 = __cil_callvirt_0A00092C(v17, 0);
        __cil_type_01000213 v25 = ((__cil_type_01000213)(object)v24);
        string v26 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v25).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v21)), ((object)(v26)));
        string v27 = __cil_ldstr_70051AAA("max_price");
        __cil_type_0100015A v30 = __cil_callvirt_0A00092C(v20, 0);
        __cil_type_01000213 v31 = ((__cil_type_01000213)(object)v30);
        string v32 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v31).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v27)), ((object)(v32)));
        object v34 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(6)));
        int v36 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v14).Operator));
        object v37 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v36)));
        NUnit.Framework.Assert.AreEqual(v34, v37);
        return;
    }

    public void SingleProperty()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70005A51("Blah");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void SingleQuotedProperty()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_7004E7E2("['Blah']");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void SingleQuotedPropertyWithWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051ABE("[  'Blah'  ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void SingleQuotedPropertyWithDots()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051AD8("['Blah.Ha']");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70051AF0("Blah.Ha");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void SingleQuotedPropertyWithBrackets()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051B00("['[*]']");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_7004ED08("[*]");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void SinglePropertyWithRoot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051B10("$.Blah");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void SinglePropertyWithRootWithStartAndEndWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051B1E(" $.Blah ");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void RootWithBadWhitespace()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0E;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CDB;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0E = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70051B30("Unexpected character while parsing path:  ");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void NoFieldNameAfterDot()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0F;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CDC;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0F = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70051B86("Unexpected end while parsing path.");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void RootWithBadWhitespace2()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E10;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CDD;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E10 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70051B30("Unexpected character while parsing path:  ");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void WildcardPropertyWithRoot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_7004E7DA("$.*");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000213 v12 = ((__cil_type_01000213)(object)v11);
        string v13 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v12).Name;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v13)));
        return;
    }

    public void WildcardArrayWithRoot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70051BCC("$.[*]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000214 v12 = ((__cil_type_01000214)(object)v11);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v13 = __cil_callvirt_0A000932(v12);
        object v14 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v13)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v14);
        return;
    }

    public void RootArrayNoDot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70051BD8("$[1]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000214 v14 = ((__cil_type_01000214)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A000932(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        return;
    }

    public void WildcardArray()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_7004ED08("[*]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000214 v12 = ((__cil_type_01000214)(object)v11);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v13 = __cil_callvirt_0A000932(v12);
        object v14 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v13)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v14);
        return;
    }

    public void WildcardArrayWithProperty()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70051BE2("[ * ].derp");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000214 v12 = ((__cil_type_01000214)(object)v11);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v13 = __cil_callvirt_0A000932(v12);
        object v14 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v13)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v14);
        string v15 = __cil_ldstr_70051BF8("derp");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v17 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v19 = __cil_callvirt_0A00092C(v17, 1);
        __cil_type_01000213 v20 = ((__cil_type_01000213)(object)v19);
        string v21 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v20).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v15)), ((object)(v21)));
        return;
    }

    public void QuotedWildcardPropertyWithRoot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051C02("$.['*']");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70051C12("*");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void SingleScanWithRoot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051C16("$..Blah");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000215 v13 = ((__cil_type_01000215)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.ScanFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        return;
    }

    public void QueryTrue()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_7004D70B("$.elements[?(true)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_7004D6E7("elements");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        object v16 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v18 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v20 = __cil_callvirt_0A00092C(v18, 1);
        __cil_type_01000210 v21 = ((__cil_type_01000210)(object)v20);
        __cil_type_01000211 v22 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v21).Expression;
        int v23 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v22).Operator));
        object v24 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v23)));
        NUnit.Framework.Assert.AreEqual(v16, v24);
        return;
    }

    public void ScanQuery()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 bytes=118685: valuetype [mscorlib]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_7004D6AD("$.elements..[?(@.id=='AAA')]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_7004D6E7("elements");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000216 v19 = ((__cil_type_01000216)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryScanFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v24 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v23);
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v25 = __cil_ldtoken_type_01000213;
        __cil_type_01000007 v26 = System.Type.GetTypeFromHandle(v25);
        __cil_type_0100015A v29 = __cil_callvirt_0A00092C(v24, 0);
        NUnit.Framework.Assert.IsInstanceOf(v26, ((object)(v29)));
        return;
    }

    public void WildcardScanWithRoot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_7004ED30("$..*");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000215 v12 = ((__cil_type_01000215)(object)v11);
        string v13 = ((Newtonsoft.Json.Linq.JsonPath.ScanFilter)v12).Name;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v13)));
        return;
    }

    public void WildcardScanWithRootWithWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051C26("$..* ");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_01000215 v12 = ((__cil_type_01000215)(object)v11);
        string v13 = ((Newtonsoft.Json.Linq.JsonPath.ScanFilter)v12).Name;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v13)));
        return;
    }

    public void TwoProperties()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051C32("Blah.Two");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        string v15 = __cil_ldstr_700248EF("Two");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v17 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v19 = __cil_callvirt_0A00092C(v17, 1);
        __cil_type_01000213 v20 = ((__cil_type_01000213)(object)v19);
        string v21 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v20).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v15)), ((object)(v21)));
        return;
    }

    public void OnePropertyOneScan()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051C44("Blah..Two");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        string v15 = __cil_ldstr_700248EF("Two");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v17 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v19 = __cil_callvirt_0A00092C(v17, 1);
        __cil_type_01000215 v20 = ((__cil_type_01000215)(object)v19);
        string v21 = ((Newtonsoft.Json.Linq.JsonPath.ScanFilter)v20).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v15)), ((object)(v21)));
        return;
    }

    public void SinglePropertyAndIndexer()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70051C58("Blah[0]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        object v16 = ((object)((int)(0)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v18 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v20 = __cil_callvirt_0A00092C(v18, 1);
        __cil_type_01000214 v21 = ((__cil_type_01000214)(object)v20);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v22 = __cil_callvirt_0A000932(v21);
        object v23 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v22)));
        NUnit.Framework.Assert.AreEqual(v16, v23);
        return;
    }

    public void SinglePropertyAndExistsQuery()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051C68("Blah[ ?( @..name ) ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000210 v19 = ((__cil_type_01000210)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(3)));
        int v25 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v21).Operator));
        object v26 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v25)));
        NUnit.Framework.Assert.AreEqual(v23, v26);
        object v28 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v29 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v28);
        object v31 = ((object)((int)(1)));
        int v33 = __cil_callvirt_0A00092B(v29);
        object v34 = ((object)((int)(v33)));
        NUnit.Framework.Assert.AreEqual(v31, v34);
        string v35 = __cil_ldstr_700042B3("name");
        __cil_type_0100015A v38 = __cil_callvirt_0A00092C(v29, 0);
        __cil_type_01000215 v39 = ((__cil_type_01000215)(object)v38);
        string v40 = ((Newtonsoft.Json.Linq.JsonPath.ScanFilter)v39).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v35)), ((object)(v40)));
        return;
    }

    public void SinglePropertyAndFilterWithWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051C92("Blah[ ?( @.name=='hi' ) ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000210 v19 = ((__cil_type_01000210)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(1)));
        int v25 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v21).Operator));
        object v26 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v25)));
        NUnit.Framework.Assert.AreEqual(v23, v26);
        string v27 = __cil_ldstr_70001E6F("hi");
        object v29 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Right;
        __cil_type_01000091 v30 = ((__cil_type_01000091)(object)v29);
        string v31 = Newtonsoft.Json.Linq.JToken.op_Explicit(v30);
        NUnit.Framework.Assert.AreEqual(((object)(v27)), ((object)(v31)));
        return;
    }

    public void SinglePropertyAndFilterWithEscapeQuote()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051CC6("Blah[ ?( @.name=='h\\'i' ) ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000210 v19 = ((__cil_type_01000210)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(1)));
        int v25 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v21).Operator));
        object v26 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v25)));
        NUnit.Framework.Assert.AreEqual(v23, v26);
        string v27 = __cil_ldstr_70051CFE("h'i");
        object v29 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Right;
        __cil_type_01000091 v30 = ((__cil_type_01000091)(object)v29);
        string v31 = Newtonsoft.Json.Linq.JToken.op_Explicit(v30);
        NUnit.Framework.Assert.AreEqual(((object)(v27)), ((object)(v31)));
        return;
    }

    public void SinglePropertyAndFilterWithDoubleEscape()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051D06("Blah[ ?( @.name=='h\\\\i' ) ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000210 v19 = ((__cil_type_01000210)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(1)));
        int v25 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v21).Operator));
        object v26 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v25)));
        NUnit.Framework.Assert.AreEqual(v23, v26);
        string v27 = __cil_ldstr_70051D3E("h\\i");
        object v29 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Right;
        __cil_type_01000091 v30 = ((__cil_type_01000091)(object)v29);
        string v31 = Newtonsoft.Json.Linq.JToken.op_Explicit(v30);
        NUnit.Framework.Assert.AreEqual(((object)(v27)), ((object)(v31)));
        return;
    }

    public void SinglePropertyAndFilterWithUnknownEscape()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E11;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CDE;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E11 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70051D46("Unknown escape character: \\i");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void SinglePropertyAndFilterWithFalse()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051D80("Blah[ ?( @.name==false ) ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000210 v19 = ((__cil_type_01000210)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(1)));
        int v25 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v21).Operator));
        object v26 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v25)));
        NUnit.Framework.Assert.AreEqual(v23, v26);
        object v28 = ((object)(__cil_bool_store(0)));
        object v30 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Right;
        __cil_type_01000091 v31 = ((__cil_type_01000091)(object)v30);
        int v32 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.op_Explicit(v31));
        object v33 = ((object)(__cil_bool_store(v32)));
        NUnit.Framework.Assert.AreEqual(v28, v33);
        return;
    }

    public void SinglePropertyAndFilterWithTrue()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051DB6("Blah[ ?( @.name==true ) ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000210 v19 = ((__cil_type_01000210)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(1)));
        int v25 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v21).Operator));
        object v26 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v25)));
        NUnit.Framework.Assert.AreEqual(v23, v26);
        object v28 = ((object)(__cil_bool_store(1)));
        object v30 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Right;
        __cil_type_01000091 v31 = ((__cil_type_01000091)(object)v30);
        int v32 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.op_Explicit(v31));
        object v33 = ((object)(__cil_bool_store(v32)));
        NUnit.Framework.Assert.AreEqual(v28, v33);
        return;
    }

    public void SinglePropertyAndFilterWithNull()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051DEA("Blah[ ?( @.name==null ) ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v16 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v18 = __cil_callvirt_0A00092C(v16, 1);
        __cil_type_01000210 v19 = ((__cil_type_01000210)(object)v18);
        __cil_type_01000211 v20 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v19).Expression;
        __cil_type_01000159 v21 = ((__cil_type_01000159)(object)v20);
        object v23 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(1)));
        int v25 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v21).Operator));
        object v26 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v25)));
        NUnit.Framework.Assert.AreEqual(v23, v26);
        object v28 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v21).Right;
        __cil_type_010000B6 v29 = ((__cil_type_010000B6)(object)v28);
        object v30 = ((Newtonsoft.Json.Linq.JValue)v29).Value;
        NUnit.Framework.Assert.AreEqual(((object)(null)), v30);
        return;
    }

    public void FilterWithScan()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051E1E("[?(@..name<>null)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v8).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v10);
        string v12 = __cil_ldstr_700042B3("name");
        __cil_type_0100015A v15 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000215 v16 = ((__cil_type_01000215)(object)v15);
        string v17 = ((Newtonsoft.Json.Linq.JsonPath.ScanFilter)v16).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v12)), ((object)(v17)));
        return;
    }

    public void FilterWithNotEquals()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051E44("[?(@.name<>null)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(2)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        return;
    }

    public void FilterWithNotEquals2()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051E68("[?(@.name!=null)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(2)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        return;
    }

    public void FilterWithLessThan()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051E8C("[?(@.name<null)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(4)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        return;
    }

    public void FilterWithLessThanOrEquals()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051EAE("[?(@.name<=null)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(5)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        return;
    }

    public void FilterWithGreaterThan()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051ED2("[?(@.name>null)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(6)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        return;
    }

    public void FilterWithGreaterThanOrEquals()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051EF4("[?(@.name>=null)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(7)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        return;
    }

    public void FilterWithInteger()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051F18("[?(@.name>=12)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((int)(12)));
        object v12 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v8).Right;
        __cil_type_01000091 v13 = ((__cil_type_01000091)(object)v12);
        int v14 = Newtonsoft.Json.Linq.JToken.op_Explicit(v13);
        object v15 = ((object)((int)(v14)));
        NUnit.Framework.Assert.AreEqual(v10, v15);
        return;
    }

    public void FilterWithNegativeInteger()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051F38("[?(@.name>=-12)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((object)((int)(-12)));
        object v12 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v8).Right;
        __cil_type_01000091 v13 = ((__cil_type_01000091)(object)v12);
        int v14 = Newtonsoft.Json.Linq.JToken.op_Explicit(v13);
        object v15 = ((object)((int)(v14)));
        NUnit.Framework.Assert.AreEqual(v10, v15);
        return;
    }

    public void FilterWithFloat()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70051F5A("[?(@.name>=12.1)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        double v9 = __cil_ldc_r8_bits(0x4028333333333333uL);
        object v10 = ((object)((double)(v9)));
        object v12 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v8).Right;
        __cil_type_01000091 v13 = ((__cil_type_01000091)(object)v12);
        double v14 = Newtonsoft.Json.Linq.JToken.op_Explicit(v13);
        double v15 = __cil_conv_r8(v14);
        object v16 = ((object)((double)(v15)));
        NUnit.Framework.Assert.AreEqual(v10, v16);
        return;
    }

    public void FilterExistWithAnd()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 bytes=1512814901128845: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.QueryExpression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051F7E("[?(@.name&&@.title)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_0100015B v8 = ((__cil_type_0100015B)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(8)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        object v15 = ((object)((int)(2)));
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v17 = __cil_callvirt_0A000935(v8);
        int v18 = __cil_callvirt_0A000936(v17);
        object v19 = ((object)((int)(v18)));
        NUnit.Framework.Assert.AreEqual(v15, v19);
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v21 = __cil_callvirt_0A000935(v8);
        __cil_type_01000211 v23 = __cil_callvirt_0A000937(v21, 0);
        __cil_type_01000159 v24 = ((__cil_type_01000159)(object)v23);
        object v26 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v24).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v27 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v26);
        string v28 = __cil_ldstr_700042B3("name");
        __cil_type_0100015A v31 = __cil_callvirt_0A00092C(v27, 0);
        __cil_type_01000213 v32 = ((__cil_type_01000213)(object)v31);
        string v33 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v32).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v28)), ((object)(v33)));
        object v35 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(3)));
        int v37 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v24).Operator));
        object v38 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v37)));
        NUnit.Framework.Assert.AreEqual(v35, v38);
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v40 = __cil_callvirt_0A000935(v8);
        __cil_type_01000211 v42 = __cil_callvirt_0A000937(v40, 1);
        __cil_type_01000159 v43 = ((__cil_type_01000159)(object)v42);
        object v45 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v43).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v46 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v45);
        string v47 = __cil_ldstr_70019BAA("title");
        __cil_type_0100015A v50 = __cil_callvirt_0A00092C(v46, 0);
        __cil_type_01000213 v51 = ((__cil_type_01000213)(object)v50);
        string v52 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v51).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v47)), ((object)(v52)));
        object v54 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(3)));
        int v56 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v43).Operator));
        object v57 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v56)));
        NUnit.Framework.Assert.AreEqual(v54, v57);
        return;
    }

    public void FilterExistWithAndOr()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 bytes=1512814901128845: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.QueryExpression>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000C8 alias=__cil_enum_020000C8 underlying=int: global::@Newtonsoft.@Json.@Linq.@JsonPath.@QueryOperator; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70051FA8("[?(@.name&&@.title||@.pie)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_0100015B v8 = ((__cil_type_0100015B)(object)v7);
        object v10 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(8)));
        int v12 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v8).Operator));
        object v13 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        object v15 = ((object)((int)(2)));
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v17 = __cil_callvirt_0A000935(v8);
        int v18 = __cil_callvirt_0A000936(v17);
        object v19 = ((object)((int)(v18)));
        NUnit.Framework.Assert.AreEqual(v15, v19);
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v21 = __cil_callvirt_0A000935(v8);
        __cil_type_01000211 v23 = __cil_callvirt_0A000937(v21, 0);
        __cil_type_01000159 v24 = ((__cil_type_01000159)(object)v23);
        object v26 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v24).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v27 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v26);
        string v28 = __cil_ldstr_700042B3("name");
        __cil_type_0100015A v31 = __cil_callvirt_0A00092C(v27, 0);
        __cil_type_01000213 v32 = ((__cil_type_01000213)(object)v31);
        string v33 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v32).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v28)), ((object)(v33)));
        object v35 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(3)));
        int v37 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v24).Operator));
        object v38 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v37)));
        NUnit.Framework.Assert.AreEqual(v35, v38);
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v40 = __cil_callvirt_0A000935(v8);
        __cil_type_01000211 v42 = __cil_callvirt_0A000937(v40, 1);
        __cil_type_0100015B v43 = ((__cil_type_0100015B)(object)v42);
        object v45 = ((object)((int)(2)));
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v47 = __cil_callvirt_0A000935(v43);
        int v48 = __cil_callvirt_0A000936(v47);
        object v49 = ((object)((int)(v48)));
        NUnit.Framework.Assert.AreEqual(v45, v49);
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v51 = __cil_callvirt_0A000935(v43);
        __cil_type_01000211 v53 = __cil_callvirt_0A000937(v51, 0);
        __cil_type_01000159 v54 = ((__cil_type_01000159)(object)v53);
        object v56 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v54).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v57 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v56);
        string v58 = __cil_ldstr_70019BAA("title");
        __cil_type_0100015A v61 = __cil_callvirt_0A00092C(v57, 0);
        __cil_type_01000213 v62 = ((__cil_type_01000213)(object)v61);
        string v63 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v62).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v58)), ((object)(v63)));
        object v65 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(3)));
        int v67 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v54).Operator));
        object v68 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v67)));
        NUnit.Framework.Assert.AreEqual(v65, v68);
        __cil_ref_320206ca6da856f53a36a05febfed9a8d260a9c6 v70 = __cil_callvirt_0A000935(v43);
        __cil_type_01000211 v72 = __cil_callvirt_0A000937(v70, 1);
        __cil_type_01000159 v73 = ((__cil_type_01000159)(object)v72);
        object v75 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v73).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v76 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v75);
        string v77 = __cil_ldstr_700065A2("pie");
        __cil_type_0100015A v80 = __cil_callvirt_0A00092C(v76, 0);
        __cil_type_01000213 v81 = ((__cil_type_01000213)(object)v80);
        string v82 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v81).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v77)), ((object)(v82)));
        object v84 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(3)));
        int v86 = unchecked((int)(((Newtonsoft.Json.Linq.JsonPath.QueryExpression)v73).Operator));
        object v87 = ((object)((Newtonsoft.Json.Linq.JsonPath.QueryOperator)(v86)));
        NUnit.Framework.Assert.AreEqual(v84, v87);
        return;
    }

    public void FilterWithRoot()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 bytes=118685: valuetype [mscorlib]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70051FE0("[?($.name>=12.1)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        object v10 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v8).Left;
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = ((__cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475)(object)v10);
        object v13 = ((object)((int)(2)));
        int v15 = __cil_callvirt_0A00092B(v11);
        object v16 = ((object)((int)(v15)));
        NUnit.Framework.Assert.AreEqual(v13, v16);
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v17 = __cil_ldtoken_type_01000217;
        __cil_type_01000007 v18 = System.Type.GetTypeFromHandle(v17);
        __cil_type_0100015A v21 = __cil_callvirt_0A00092C(v11, 0);
        NUnit.Framework.Assert.IsInstanceOf(v18, ((object)(v21)));
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v22 = __cil_ldtoken_type_01000213;
        __cil_type_01000007 v23 = System.Type.GetTypeFromHandle(v22);
        __cil_type_0100015A v26 = __cil_callvirt_0A00092C(v11, 1);
        NUnit.Framework.Assert.IsInstanceOf(v23, ((object)(v26)));
        return;
    }

    public void BadOr1()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E12;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CDF;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E12 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70052004("Unexpected character while parsing path query: )");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void BaddOr2()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E13;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE0;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E13 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70052066("Unexpected character while parsing path query: |");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void BaddOr3()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E14;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE1;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E14 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70052066("Unexpected character while parsing path query: |");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void BaddOr4()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E15;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE2;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E15 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700520C8("Path ended with open query.");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void NoAtAfterOr()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E16;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE3;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E16 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70052100("Unexpected character while parsing path query: s");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void NoPathAfterAt()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E17;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE4;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E17 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700520C8("Path ended with open query.");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void NoPathAfterDot()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E18;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE5;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E18 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70051B86("Unexpected end while parsing path.");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void NoPathAfterDot2()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E19;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE6;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E19 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70051B86("Unexpected end while parsing path.");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void FilterWithFloatExp()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70052162("[?(@.name>=5.56789e+0)]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v3 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v5 = __cil_callvirt_0A00092C(v3, 0);
        __cil_type_01000210 v6 = ((__cil_type_01000210)(object)v5);
        __cil_type_01000211 v7 = ((Newtonsoft.Json.Linq.JsonPath.QueryFilter)v6).Expression;
        __cil_type_01000159 v8 = ((__cil_type_01000159)(object)v7);
        double v9 = __cil_ldc_r8_bits(0x40164584F4C6E6DAuL);
        object v10 = ((object)((double)(v9)));
        object v12 = ((Newtonsoft.Json.Linq.JsonPath.BooleanQueryExpression)v8).Right;
        __cil_type_01000091 v13 = ((__cil_type_01000091)(object)v12);
        double v14 = Newtonsoft.Json.Linq.JToken.op_Explicit(v13);
        double v15 = __cil_conv_r8(v14);
        object v16 = ((object)((double)(v15)));
        NUnit.Framework.Assert.AreEqual(v10, v16);
        return;
    }

    public void MultiplePropertiesAndIndexers()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70052192("Blah[0]..Two.Three[1].Four");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(6)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70005A51("Blah");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        object v16 = ((object)((int)(0)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v18 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v20 = __cil_callvirt_0A00092C(v18, 1);
        __cil_type_01000214 v21 = ((__cil_type_01000214)(object)v20);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v22 = __cil_callvirt_0A000932(v21);
        object v23 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v22)));
        NUnit.Framework.Assert.AreEqual(v16, v23);
        string v24 = __cil_ldstr_700248EF("Two");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v26 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v28 = __cil_callvirt_0A00092C(v26, 2);
        __cil_type_01000215 v29 = ((__cil_type_01000215)(object)v28);
        string v30 = ((Newtonsoft.Json.Linq.JsonPath.ScanFilter)v29).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v24)), ((object)(v30)));
        string v31 = __cil_ldstr_700258B8("Three");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v33 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v35 = __cil_callvirt_0A00092C(v33, 3);
        __cil_type_01000213 v36 = ((__cil_type_01000213)(object)v35);
        string v37 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v36).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v31)), ((object)(v37)));
        object v39 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v41 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v43 = __cil_callvirt_0A00092C(v41, 4);
        __cil_type_01000214 v44 = ((__cil_type_01000214)(object)v43);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v45 = __cil_callvirt_0A000932(v44);
        object v46 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v45)));
        NUnit.Framework.Assert.AreEqual(v39, v46);
        string v47 = __cil_ldstr_7002EFBA("Four");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v49 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v51 = __cil_callvirt_0A00092C(v49, 5);
        __cil_type_01000213 v52 = ((__cil_type_01000213)(object)v51);
        string v53 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v52).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v47)), ((object)(v53)));
        return;
    }

    public void BadCharactersInIndexer()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1A;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE7;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1A = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700521C8("Unexpected character while parsing path indexer: [");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void UnclosedIndexer()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1B;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE8;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1B = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7005222E("Path ended with open indexer.");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void IndexerOnly()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_7005226A("[111119990]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(111119990)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000214 v14 = ((__cil_type_01000214)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A000932(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        return;
    }

    public void IndexerOnlyWithWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70052282("[  10  ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(10)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000214 v14 = ((__cil_type_01000214)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A000932(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        return;
    }

    public void MultipleIndexes()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e bytes=151281490108: class [mscorlib]System.Collections.Generic.List`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70052294("[111119990,3]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000218 v14 = ((__cil_type_01000218)(object)v13);
        __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e v15 = __cil_callvirt_0A000938(v14);
        int v16 = __cil_callvirt_0A00040F(v15);
        object v17 = ((object)((int)(v16)));
        NUnit.Framework.Assert.AreEqual(v9, v17);
        object v19 = ((object)((int)(111119990)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v21 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v23 = __cil_callvirt_0A00092C(v21, 0);
        __cil_type_01000218 v24 = ((__cil_type_01000218)(object)v23);
        __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e v25 = __cil_callvirt_0A000938(v24);
        int v27 = __cil_callvirt_0A000410(v25, 0);
        object v28 = ((object)((int)(v27)));
        NUnit.Framework.Assert.AreEqual(v19, v28);
        object v30 = ((object)((int)(3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v32 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v34 = __cil_callvirt_0A00092C(v32, 0);
        __cil_type_01000218 v35 = ((__cil_type_01000218)(object)v34);
        __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e v36 = __cil_callvirt_0A000938(v35);
        int v38 = __cil_callvirt_0A000410(v36, 1);
        object v39 = ((object)((int)(v38)));
        NUnit.Framework.Assert.AreEqual(v30, v39);
        return;
    }

    public void MultipleIndexesWithWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e bytes=151281490108: class [mscorlib]System.Collections.Generic.List`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_700522B0("[   111119990  ,   3   ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000218 v14 = ((__cil_type_01000218)(object)v13);
        __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e v15 = __cil_callvirt_0A000938(v14);
        int v16 = __cil_callvirt_0A00040F(v15);
        object v17 = ((object)((int)(v16)));
        NUnit.Framework.Assert.AreEqual(v9, v17);
        object v19 = ((object)((int)(111119990)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v21 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v23 = __cil_callvirt_0A00092C(v21, 0);
        __cil_type_01000218 v24 = ((__cil_type_01000218)(object)v23);
        __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e v25 = __cil_callvirt_0A000938(v24);
        int v27 = __cil_callvirt_0A000410(v25, 0);
        object v28 = ((object)((int)(v27)));
        NUnit.Framework.Assert.AreEqual(v19, v28);
        object v30 = ((object)((int)(3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v32 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v34 = __cil_callvirt_0A00092C(v32, 0);
        __cil_type_01000218 v35 = ((__cil_type_01000218)(object)v34);
        __cil_ref_7fd7a1aa5d03d41b30b34ec8739eafb7aa24741e v36 = __cil_callvirt_0A000938(v35);
        int v38 = __cil_callvirt_0A000410(v36, 1);
        object v39 = ((object)((int)(v38)));
        NUnit.Framework.Assert.AreEqual(v30, v39);
        return;
    }

    public void MultipleQuotedIndexes()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 bytes=15128149010E: class [mscorlib]System.Collections.Generic.List`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_700522E2("['111119990','3']");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000219 v14 = ((__cil_type_01000219)(object)v13);
        __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 v15 = __cil_callvirt_0A000939(v14);
        int v16 = __cil_callvirt_0A000258(v15);
        object v17 = ((object)((int)(v16)));
        NUnit.Framework.Assert.AreEqual(v9, v17);
        string v18 = __cil_ldstr_70052306("111119990");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v20 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v22 = __cil_callvirt_0A00092C(v20, 0);
        __cil_type_01000219 v23 = ((__cil_type_01000219)(object)v22);
        __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 v24 = __cil_callvirt_0A000939(v23);
        string v26 = __cil_callvirt_0A000259(v24, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v18)), ((object)(v26)));
        string v27 = __cil_ldstr_70011FAB("3");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v29 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v31 = __cil_callvirt_0A00092C(v29, 0);
        __cil_type_01000219 v32 = ((__cil_type_01000219)(object)v31);
        __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 v33 = __cil_callvirt_0A000939(v32);
        string v35 = __cil_callvirt_0A000259(v33, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v27)), ((object)(v35)));
        return;
    }

    public void MultipleQuotedIndexesWithWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 bytes=15128149010E: class [mscorlib]System.Collections.Generic.List`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_7005231A("[ '111119990' , '3' ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_01000219 v14 = ((__cil_type_01000219)(object)v13);
        __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 v15 = __cil_callvirt_0A000939(v14);
        int v16 = __cil_callvirt_0A000258(v15);
        object v17 = ((object)((int)(v16)));
        NUnit.Framework.Assert.AreEqual(v9, v17);
        string v18 = __cil_ldstr_70052306("111119990");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v20 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v22 = __cil_callvirt_0A00092C(v20, 0);
        __cil_type_01000219 v23 = ((__cil_type_01000219)(object)v22);
        __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 v24 = __cil_callvirt_0A000939(v23);
        string v26 = __cil_callvirt_0A000259(v24, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v18)), ((object)(v26)));
        string v27 = __cil_ldstr_70011FAB("3");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v29 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v31 = __cil_callvirt_0A00092C(v29, 0);
        __cil_type_01000219 v32 = ((__cil_type_01000219)(object)v31);
        __cil_ref_23a10bafee77363212afe4374bf1db0e582bbaf9 v33 = __cil_callvirt_0A000939(v32);
        string v35 = __cil_callvirt_0A000259(v33, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v27)), ((object)(v35)));
        return;
    }

    public void SlicingIndexAll()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70052346("[111119990:3:2]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(111119990)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_0100021A v14 = ((__cil_type_0100021A)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A00093A(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        object v18 = ((object)((int)(3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v20 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v22 = __cil_callvirt_0A00092C(v20, 0);
        __cil_type_0100021A v23 = ((__cil_type_0100021A)(object)v22);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v24 = __cil_callvirt_0A00093B(v23);
        object v25 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v24)));
        NUnit.Framework.Assert.AreEqual(v18, v25);
        object v27 = ((object)((int)(2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v29 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v31 = __cil_callvirt_0A00092C(v29, 0);
        __cil_type_0100021A v32 = ((__cil_type_0100021A)(object)v31);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v33 = __cil_callvirt_0A00093C(v32);
        object v34 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v33)));
        NUnit.Framework.Assert.AreEqual(v27, v34);
        return;
    }

    public void SlicingIndex()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70052366("[111119990:3]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(111119990)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_0100021A v14 = ((__cil_type_0100021A)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A00093A(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        object v18 = ((object)((int)(3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v20 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v22 = __cil_callvirt_0A00092C(v20, 0);
        __cil_type_0100021A v23 = ((__cil_type_0100021A)(object)v22);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v24 = __cil_callvirt_0A00093B(v23);
        object v25 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v24)));
        NUnit.Framework.Assert.AreEqual(v18, v25);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v27 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v29 = __cil_callvirt_0A00092C(v27, 0);
        __cil_type_0100021A v30 = ((__cil_type_0100021A)(object)v29);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v31 = __cil_callvirt_0A00093C(v30);
        object v32 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v31)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v32);
        return;
    }

    public void SlicingIndexNegative()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70052382("[-111119990:-3:-2]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(-111119990)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_0100021A v14 = ((__cil_type_0100021A)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A00093A(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        object v18 = ((object)((int)(-3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v20 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v22 = __cil_callvirt_0A00092C(v20, 0);
        __cil_type_0100021A v23 = ((__cil_type_0100021A)(object)v22);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v24 = __cil_callvirt_0A00093B(v23);
        object v25 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v24)));
        NUnit.Framework.Assert.AreEqual(v18, v25);
        object v27 = ((object)((int)(-2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v29 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v31 = __cil_callvirt_0A00092C(v29, 0);
        __cil_type_0100021A v32 = ((__cil_type_0100021A)(object)v31);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v33 = __cil_callvirt_0A00093C(v32);
        object v34 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v33)));
        NUnit.Framework.Assert.AreEqual(v27, v34);
        return;
    }

    public void SlicingIndexEmptyStop()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_700523A8("[  -3  :  ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(-3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_0100021A v14 = ((__cil_type_0100021A)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A00093A(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v18 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v20 = __cil_callvirt_0A00092C(v18, 0);
        __cil_type_0100021A v21 = ((__cil_type_0100021A)(object)v20);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v22 = __cil_callvirt_0A00093B(v21);
        object v23 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v22)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v23);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v25 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v27 = __cil_callvirt_0A00092C(v25, 0);
        __cil_type_0100021A v28 = ((__cil_type_0100021A)(object)v27);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v29 = __cil_callvirt_0A00093C(v28);
        object v30 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v29)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v30);
        return;
    }

    public void SlicingIndexEmptyStart()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_700523C0("[ : 1 : ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v11 = __cil_callvirt_0A00092C(v9, 0);
        __cil_type_0100021A v12 = ((__cil_type_0100021A)(object)v11);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v13 = __cil_callvirt_0A00093A(v12);
        object v14 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v13)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v14);
        object v16 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v18 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v20 = __cil_callvirt_0A00092C(v18, 0);
        __cil_type_0100021A v21 = ((__cil_type_0100021A)(object)v20);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v22 = __cil_callvirt_0A00093B(v21);
        object v23 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v22)));
        NUnit.Framework.Assert.AreEqual(v16, v23);
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v25 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v27 = __cil_callvirt_0A00092C(v25, 0);
        __cil_type_0100021A v28 = ((__cil_type_0100021A)(object)v27);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v29 = __cil_callvirt_0A00093C(v28);
        object v30 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v29)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), v30);
        return;
    }

    public void SlicingIndexWhitespace()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_700523D4("[  -111119990  :  -3  :  -2  ]");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        object v9 = ((object)((int)(-111119990)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v11 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v13 = __cil_callvirt_0A00092C(v11, 0);
        __cil_type_0100021A v14 = ((__cil_type_0100021A)(object)v13);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v15 = __cil_callvirt_0A00093A(v14);
        object v16 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v15)));
        NUnit.Framework.Assert.AreEqual(v9, v16);
        object v18 = ((object)((int)(-3)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v20 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v22 = __cil_callvirt_0A00092C(v20, 0);
        __cil_type_0100021A v23 = ((__cil_type_0100021A)(object)v22);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v24 = __cil_callvirt_0A00093B(v23);
        object v25 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v24)));
        NUnit.Framework.Assert.AreEqual(v18, v25);
        object v27 = ((object)((int)(-2)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v29 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v31 = __cil_callvirt_0A00092C(v29, 0);
        __cil_type_0100021A v32 = ((__cil_type_0100021A)(object)v31);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v33 = __cil_callvirt_0A00093C(v32);
        object v34 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v33)));
        NUnit.Framework.Assert.AreEqual(v27, v34);
        return;
    }

    public void EmptyIndexer()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1C;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CE9;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1C = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70052412("Array index expected.");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void IndexerCloseInProperty()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1D;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CEA;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1D = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7005243E("Unexpected character while parsing path: ]");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void AdjacentIndexers()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_70052494("[1][0][0][");
        object v2 = ((object)((int)(2147483647)));
        string v3 = __cil_ldstr_700524AA("]");
        string v4 = System.String.Concat(((object)(v0)), v2, ((object)(v3)));
        __cil_type_01000158 v5 = __cil_newobj_0A000929(v4);
        object v7 = ((object)((int)(4)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v9 = __cil_callvirt_0A00092A(v5);
        int v10 = __cil_callvirt_0A00092B(v9);
        object v11 = ((object)((int)(v10)));
        NUnit.Framework.Assert.AreEqual(v7, v11);
        object v13 = ((object)((int)(1)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v15 = __cil_callvirt_0A00092A(v5);
        __cil_type_0100015A v17 = __cil_callvirt_0A00092C(v15, 0);
        __cil_type_01000214 v18 = ((__cil_type_01000214)(object)v17);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v19 = __cil_callvirt_0A000932(v18);
        object v20 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v19)));
        NUnit.Framework.Assert.AreEqual(v13, v20);
        object v22 = ((object)((int)(0)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v24 = __cil_callvirt_0A00092A(v5);
        __cil_type_0100015A v26 = __cil_callvirt_0A00092C(v24, 1);
        __cil_type_01000214 v27 = ((__cil_type_01000214)(object)v26);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v28 = __cil_callvirt_0A000932(v27);
        object v29 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v28)));
        NUnit.Framework.Assert.AreEqual(v22, v29);
        object v31 = ((object)((int)(0)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v33 = __cil_callvirt_0A00092A(v5);
        __cil_type_0100015A v35 = __cil_callvirt_0A00092C(v33, 2);
        __cil_type_01000214 v36 = ((__cil_type_01000214)(object)v35);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v37 = __cil_callvirt_0A000932(v36);
        object v38 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v37)));
        NUnit.Framework.Assert.AreEqual(v31, v38);
        object v40 = ((object)((int)(2147483647)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v42 = __cil_callvirt_0A00092A(v5);
        __cil_type_0100015A v44 = __cil_callvirt_0A00092C(v42, 3);
        __cil_type_01000214 v45 = ((__cil_type_01000214)(object)v44);
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v46 = __cil_callvirt_0A000932(v45);
        object v47 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v46)));
        NUnit.Framework.Assert.AreEqual(v40, v47);
        return;
    }

    public void MissingDotAfterIndexer()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1E;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D;
        nint v2 = __cil_ldftn_06001CEB;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E1E = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700524AE("Unexpected character following indexer: B");
        v5[0] = v7;
        __cil_type_010001A4 v8 = __cil_methodspec_call_2B00001F(s2_0, v5);
        return;
    }

    public void PropertyFollowingEscapedPropertyName()
    {
        // structural signature __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 bytes=1512814901128569: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JsonPath.PathFilter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70052502("frameworks.dnxcore50.dependencies.['System.Xml.ReaderWriter'].source");
        __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
        object v3 = ((object)((int)(5)));
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v5 = __cil_callvirt_0A00092A(v1);
        int v6 = __cil_callvirt_0A00092B(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v8 = __cil_ldstr_70048064("frameworks");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v10 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v12 = __cil_callvirt_0A00092C(v10, 0);
        __cil_type_01000213 v13 = ((__cil_type_01000213)(object)v12);
        string v14 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v13).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v14)));
        string v15 = __cil_ldstr_7004807A("dnxcore50");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v17 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v19 = __cil_callvirt_0A00092C(v17, 1);
        __cil_type_01000213 v20 = ((__cil_type_01000213)(object)v19);
        string v21 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v20).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v15)), ((object)(v21)));
        string v22 = __cil_ldstr_7004808E("dependencies");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v24 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v26 = __cil_callvirt_0A00092C(v24, 2);
        __cil_type_01000213 v27 = ((__cil_type_01000213)(object)v26);
        string v28 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v27).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v22)), ((object)(v28)));
        string v29 = __cil_ldstr_700480A8("System.Xml.ReaderWriter");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v31 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v33 = __cil_callvirt_0A00092C(v31, 3);
        __cil_type_01000213 v34 = ((__cil_type_01000213)(object)v33);
        string v35 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v34).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v29)), ((object)(v35)));
        string v36 = __cil_ldstr_700480D8("source");
        __cil_ref_20577db61ee5e5fab706b97ef9c04b2f6070d475 v38 = __cil_callvirt_0A00092A(v1);
        __cil_type_0100015A v40 = __cil_callvirt_0A00092C(v38, 4);
        __cil_type_01000213 v41 = ((__cil_type_01000213)(object)v40);
        string v42 = ((Newtonsoft.Json.Linq.JsonPath.FieldFilter)v41).Name;
        NUnit.Framework.Assert.AreEqual(((object)(v36)), ((object)(v42)));
        return;
    }

    public JPathParseTests() : base()
    {
        return;
    }

    private sealed class __name_3C3E63
    {
        public static readonly Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 __il_field_04000E0D;
        public static System.Action __il_field_04000E0E;
        public static System.Action __il_field_04000E0F;
        public static System.Action __il_field_04000E10;
        public static System.Action __il_field_04000E11;
        public static System.Action __il_field_04000E12;
        public static System.Action __il_field_04000E13;
        public static System.Action __il_field_04000E14;
        public static System.Action __il_field_04000E15;
        public static System.Action __il_field_04000E16;
        public static System.Action __il_field_04000E17;
        public static System.Action __il_field_04000E18;
        public static System.Action __il_field_04000E19;
        public static System.Action __il_field_04000E1A;
        public static System.Action __il_field_04000E1B;
        public static System.Action __il_field_04000E1C;
        public static System.Action __il_field_04000E1D;
        public static System.Action __il_field_04000E1E;

        static __name_3C3E63()
        {
            global::Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63 v0 = __cil_newobj_06001CDA();
            Newtonsoft.Json.Tests.Linq.JsonPath.JPathParseTests.__name_3C3E63.__il_field_04000E0D = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <RootWithBadWhitespace>b__9_0
        internal void RootWithBadWhitespaceLambda9_0()
        {
            string v0 = __cil_ldstr_70075D16("$ .Blah");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <NoFieldNameAfterDot>b__10_0
        internal void NoFieldNameAfterDotLambda10_0()
        {
            string v0 = __cil_ldstr_70075D26("$.Blah.");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <RootWithBadWhitespace2>b__11_0
        internal void RootWithBadWhitespace2Lambda11_0()
        {
            string v0 = __cil_ldstr_70075D36("$. Blah");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <SinglePropertyAndFilterWithUnknownEscape>b__30_0
        internal void SinglePropertyAndFilterWithUnknownEscapeLambda30_0()
        {
            string v0 = __cil_ldstr_70075D46("Blah[ ?( @.name=='h\\i' ) ]");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <BadOr1>b__47_0
        internal void BadOr1Lambda47_0()
        {
            string v0 = __cil_ldstr_70075D7C("[?(@.name||)]");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <BaddOr2>b__48_0
        internal void BaddOr2Lambda48_0()
        {
            string v0 = __cil_ldstr_70075D98("[?(@.name|)]");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <BaddOr3>b__49_0
        internal void BaddOr3Lambda49_0()
        {
            string v0 = __cil_ldstr_70075DB2("[?(@.name|");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <BaddOr4>b__50_0
        internal void BaddOr4Lambda50_0()
        {
            string v0 = __cil_ldstr_70075DC8("[?(@.name||");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <NoAtAfterOr>b__51_0
        internal void NoAtAfterOrLambda51_0()
        {
            string v0 = __cil_ldstr_70075DE0("[?(@.name||s");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <NoPathAfterAt>b__52_0
        internal void NoPathAfterAtLambda52_0()
        {
            string v0 = __cil_ldstr_70075DFA("[?(@.name||@");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <NoPathAfterDot>b__53_0
        internal void NoPathAfterDotLambda53_0()
        {
            string v0 = __cil_ldstr_70075E14("[?(@.name||@.");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <NoPathAfterDot2>b__54_0
        internal void NoPathAfterDot2Lambda54_0()
        {
            string v0 = __cil_ldstr_70075E30("[?(@.name||@.)]");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <BadCharactersInIndexer>b__57_0
        internal void BadCharactersInIndexerLambda57_0()
        {
            string v0 = __cil_ldstr_70075E50("Blah[[0]].Two.Three[1].Four");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <UnclosedIndexer>b__58_0
        internal void UnclosedIndexerLambda58_0()
        {
            string v0 = __cil_ldstr_70075E88("Blah[0");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <EmptyIndexer>b__71_0
        internal void EmptyIndexerLambda71_0()
        {
            string v0 = __cil_ldstr_70020C91("[]");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <IndexerCloseInProperty>b__72_0
        internal void IndexerCloseInPropertyLambda72_0()
        {
            string v0 = __cil_ldstr_700524AA("]");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }

        // Metadata name: <MissingDotAfterIndexer>b__74_0
        internal void MissingDotAfterIndexerLambda74_0()
        {
            string v0 = __cil_ldstr_70075E96("[1]Blah");
            __cil_type_01000158 v1 = __cil_newobj_0A000929(v0);
            return;
        }
    }
}

// Dependency identity substituted: System.Data.DataSetExtensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0 -> System.Data.DataSetExtensions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.CSharp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency unresolved: System.Data.Entity, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; reference identity retained.

// Dependency unresolved: System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, ContentType=0x0; reference identity retained.

// Dependency unresolved: System.Data.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; reference identity retained.
