namespace Newtonsoft.Json.Tests.Linq;

public class JObjectTests : Newtonsoft.Json.Tests.TestFixtureBase
{
    public void EmbedJValueStringInNewJObject()
    {
        // structural signature __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 bytes=118685: valuetype [mscorlib]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_4d0832c2c0024033a1bb5e79864111559cb3fd8a bytes=151228011282D9: class <>f__AnonymousType8`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JValue>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe bytes=151283D901151283ED031283E11C0E: class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite, object, string>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd bytes=151283ED031283E11C0E: class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite, object, string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 bytes=151283D901151283ED031283E11C1C: class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite, object, object>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_843b6a43263074c1f82e8180d212b465af9a944c bytes=1D128771: class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c58d40c5ff1967688d6d5840b6c23de92ecbc45c bytes=1512814501121D: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_c0dd81f6be0d905e7fce4f6832b650ab591d5f34 bytes=1512814501128771: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_5e6b614e5ff7481a76609878f955de0b00c50743 bytes=151283ED031283E11C1C: class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite, object, object>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x0200000B alias=__cil_enum_0200000B underlying=int: global::@Microsoft.@CSharp.@RuntimeBinder.@CSharpArgumentInfoFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        // enum storage token=0x0200000E alias=__cil_enum_0200000E underlying=int: global::@Microsoft.@CSharp.@RuntimeBinder.@CSharpBinderFlags; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        __cil_type_010000B6 l1 = default;
        object l2 = default;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd s4_0 = default;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe s4_1 = default;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd s5_0 = default;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe s5_1 = default;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd s6_0 = default;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe s6_1 = default;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd s10_0 = default;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe s10_1 = default;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd s11_0 = default;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe s11_1 = default;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd s12_0 = default;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe s12_1 = default;
        l0 = null;
        string v0 = l0;
        __cil_type_010000B6 v1 = __cil_newobj_0A0005C2(v0);
        l1 = v1;
        __cil_type_010000B6 v2 = l1;
        __cil_ref_4d0832c2c0024033a1bb5e79864111559cb3fd8a v3 = __cil_newobj_0A0005C3(v2);
        __cil_type_01000023 v4 = Newtonsoft.Json.Linq.JObject.FromObject(((object)(v3)));
        l2 = v4;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v5 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1B;
        if (v5 is null) {
            goto IL_001F;
        } else {
            goto IL_001D;
        }
        IL_001D: ;
        goto IL_0043;
        IL_001F: ;
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v7 = __cil_ldtoken_type_01000181;
        __cil_type_01000007 v8 = System.Type.GetTypeFromHandle(v7);
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v9 = __cil_ldtoken_type_0200021F;
        __cil_type_01000007 v10 = System.Type.GetTypeFromHandle(v9);
        __cil_type_010001DF v11 = Microsoft.CSharp.RuntimeBinder.Binder.Convert(unchecked((Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags)(0)), v8, v10);
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v12 = __cil_reference_call_0A0003EB(v11);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1B = v12;
        IL_0043: ;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v13 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1B;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd v14 = v13.Target;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v15 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1B;
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v16 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1A;
        if (v16 is null) {
            __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e3_5_0 = v14;
            __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e3_5_1 = v15;
            s5_0 = e3_5_0;
            s5_1 = e3_5_1;
            goto IL_005B;
        } else {
            __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e3_4_0 = v14;
            __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e3_4_1 = v15;
            s4_0 = e3_4_0;
            s4_1 = e3_4_1;
            goto IL_0059;
        }
        IL_0059: ;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e4_6_0 = s4_0;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e4_6_1 = s4_1;
        s6_0 = e4_6_0;
        s6_1 = e4_6_1;
        goto IL_008B;
        IL_005B: ;
        string v18 = __cil_ldstr_7000C764("ToString");
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v19 = __cil_ldtoken_type_0200021F;
        __cil_type_01000007 v20 = System.Type.GetTypeFromHandle(v19);
        __cil_ref_843b6a43263074c1f82e8180d212b465af9a944c v22 = __cil_newarr_010001DC(1);
        __cil_type_010001DC v25 = Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo.Create(unchecked((Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags)(0)), ((string)(null)));
        v22[0] = v25;
        __cil_type_010001DF v26 = Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(unchecked((Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags)(0)), v18, ((__cil_ref_c58d40c5ff1967688d6d5840b6c23de92ecbc45c)(null)), v20, ((__cil_ref_c0dd81f6be0d905e7fce4f6832b650ab591d5f34)(v22)));
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v27 = __cil_reference_call_0A00043D(v26);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1A = v27;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e5_6_0 = s5_0;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e5_6_1 = s5_1;
        s6_0 = e5_6_0;
        s6_1 = e5_6_1;
        IL_008B: ;
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v28 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1A;
        __cil_ref_5e6b614e5ff7481a76609878f955de0b00c50743 v29 = v28.Target;
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v30 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1A;
        object v31 = l2;
        object v32 = __cil_callvirt_0A00043F(v29, ((__cil_type_010000F8)(v30)), v31);
        string v33 = __cil_callvirt_0A0003F1(s6_0, ((__cil_type_010000F8)(s6_1)), v32);
        string v34 = __cil_ldstr_70019BB6("{\u000D\u000A  \"title\": null\u000D\u000A}");
        Newtonsoft.Json.Tests.StringAssert.AreEqual(v34, v33);
        __cil_type_010000B6 v36 = l1;
        object v37 = ((Newtonsoft.Json.Linq.JValue)v36).Value;
        NUnit.Framework.Assert.AreEqual(((object)(null)), v37);
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v38 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1D;
        if (v38 is null) {
            goto IL_00C8;
        } else {
            goto IL_00C6;
        }
        IL_00C6: ;
        goto IL_00ED;
        IL_00C8: ;
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v40 = __cil_ldtoken_type_01000181;
        __cil_type_01000007 v41 = System.Type.GetTypeFromHandle(v40);
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v42 = __cil_ldtoken_type_0200021F;
        __cil_type_01000007 v43 = System.Type.GetTypeFromHandle(v42);
        __cil_type_010001DF v44 = Microsoft.CSharp.RuntimeBinder.Binder.Convert(unchecked((Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags)(16)), v41, v43);
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v45 = __cil_reference_call_0A0003EB(v44);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1D = v45;
        IL_00ED: ;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v46 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1D;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd v47 = v46.Target;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe v48 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1D;
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v49 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1C;
        if (v49 is null) {
            __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e9_11_0 = v47;
            __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e9_11_1 = v48;
            s11_0 = e9_11_0;
            s11_1 = e9_11_1;
            goto IL_0105;
        } else {
            __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e9_10_0 = v47;
            __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e9_10_1 = v48;
            s10_0 = e9_10_0;
            s10_1 = e9_10_1;
            goto IL_0103;
        }
        IL_0103: ;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e10_12_0 = s10_0;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e10_12_1 = s10_1;
        s12_0 = e10_12_0;
        s12_1 = e10_12_1;
        goto IL_0134;
        IL_0105: ;
        string v51 = __cil_ldstr_70019BAA("title");
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v52 = __cil_ldtoken_type_0200021F;
        __cil_type_01000007 v53 = System.Type.GetTypeFromHandle(v52);
        __cil_ref_843b6a43263074c1f82e8180d212b465af9a944c v55 = __cil_newarr_010001DC(1);
        __cil_type_010001DC v58 = Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo.Create(unchecked((Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags)(0)), ((string)(null)));
        v55[0] = v58;
        __cil_type_010001DF v59 = Microsoft.CSharp.RuntimeBinder.Binder.GetMember(unchecked((Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags)(0)), v51, v53, ((__cil_ref_c0dd81f6be0d905e7fce4f6832b650ab591d5f34)(v55)));
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v60 = __cil_reference_call_0A00043D(v59);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1C = v60;
        __cil_ref_233a489bacbfb999200b6ab0526469f3103381fd e11_12_0 = s11_0;
        __cil_ref_b6f179a5356f1af94a7e244804f643fbf44600fe e11_12_1 = s11_1;
        s12_0 = e11_12_0;
        s12_1 = e11_12_1;
        IL_0134: ;
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v61 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1C;
        __cil_ref_5e6b614e5ff7481a76609878f955de0b00c50743 v62 = v61.Target;
        __cil_ref_2073ea6507ed5ac0f34db6b457d4bae2ef815777 v63 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E6F5F5F30.__il_field_04000B1C;
        object v64 = l2;
        object v65 = __cil_callvirt_0A00043F(v62, ((__cil_type_010000F8)(v63)), v64);
        string v66 = __cil_callvirt_0A0003F1(s12_0, ((__cil_type_010000F8)(s12_1)), v65);
        NUnit.Framework.Assert.IsNull(((object)(v66)));
        return;
    }

    public void ReadWithSupportMultipleContent()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 3
        // .initlocals true
        // .code-bytes IL_0000: [00, 72, 00, 32, 04, 70, 0A, 73, 2B, 08, 00, 0A, 0B, 06, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A]
        // .code-bytes IL_0018: [0C, 08, 17, 6F, 32, 05, 00, 0A, 00, 2B, 28, 00, 08, 28, 6C, 06, 00, 0A, 74, 23, 00, 00, 01, 0D]
        // .code-bytes IL_0030: [07, 09, 6F, 2C, 08, 00, 0A, 00, 08, 6F, 72, 01, 00, 0A, 16, FE, 01, 13, 04, 11, 04, 2C, 03, 00]
        // .code-bytes IL_0048: [2B, 06, 00, 17, 13, 05, 2B, D3, 18, 8C, 83, 01, 00, 01, 07, 6F, 2D, 08, 00, 0A, 8C, 83, 01, 00]
        // .code-bytes IL_0060: [01, 28, C7, 00, 00, 0A, 00, 72, 58, 08, 00, 70, 07, 16, 6F, 2E, 08, 00, 0A, 72, B3, 42, 00, 70]
        // .code-bytes IL_0078: [6F, 73, 04, 00, 0A, 28, D4, 02, 00, 0A, 28, C7, 00, 00, 0A, 00, 72, 56, 32, 04, 70, 07, 17, 6F]
        // .code-bytes IL_0090: [2E, 08, 00, 0A, 72, B3, 42, 00, 70, 6F, 73, 04, 00, 0A, 28, D4, 02, 00, 0A, 28, C7, 00, 00, 0A]
        // .code-bytes IL_00A8: [00, 2A]
        // .local [0] string
        // .local [1] class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject>
        // .local [2] class [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader
        // .local [3] class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject
        // .local [4] bool
        // .local [5] bool
        // IL_0000: nop 
        // IL_0001: ldstr 0x70043200 [123, 32, 39, 110, 97, 109, 101, 39, 58, 32, 39, 65, 100, 109, 105, 110, 39, 32, 125, 123, 32, 39, 110, 97, 109, 101, 39, 58, 32, 39, 80, 117, 98, 108, 105, 115, 104, 101, 114, 39, 32, 125] utf16-bytes=[7B, 00, 20, 00, 27, 00, 6E, 00, 61, 00, 6D, 00, 65, 00, 27, 00, 3A, 00, 20, 00, 27, 00, 41, 00, 64, 00, 6D, 00, 69, 00, 6E, 00, 27, 00, 20, 00, 7D, 00, 7B, 00, 20, 00, 27, 00, 6E, 00, 61, 00, 6D, 00, 65, 00, 27, 00, 3A, 00, 20, 00, 27, 00, 50, 00, 75, 00, 62, 00, 6C, 00, 69, 00, 73, 00, 68, 00, 65, 00, 72, 00, 27, 00, 20, 00, 7D, 00] terminal-flag=Some(1)
        // IL_0006: stloc.0 0
        // IL_0007: newobj 0x0A00082B class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject>::.ctor
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0013: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0018: stloc.2 2
        // IL_0019: ldloc.2 2
        // IL_001A: ldc.i4.1 1
        // IL_001B: callvirt 0x0A000532 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::set_SupportMultipleContent
        // IL_0020: nop 
        // IL_0021: br.s IL_004B
        // IL_0023: nop 
        // IL_0024: ldloc.2 2
        // IL_0025: call 0x0A00066C [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::ReadFrom
        // IL_002A: castclass 0x01000023 [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject
        // IL_002F: stloc.3 3
        // IL_0030: ldloc.1 1
        // IL_0031: ldloc.3 3
        // IL_0032: callvirt 0x0A00082C class [mscorlib]System.Collections.Generic.ICollection`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject>::Add
        // IL_0037: nop 
        // IL_0038: ldloc.2 2
        // IL_0039: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_003E: ldc.i4.0 0
        // IL_003F: ceq 
        // IL_0041: stloc.s 4
        // IL_0043: ldloc.s 4
        // IL_0045: brfalse.s IL_004A
        // IL_0047: nop 
        // IL_0048: br.s IL_0050
        // IL_004A: nop 
        // IL_004B: ldc.i4.1 1
        // IL_004C: stloc.s 5
        // IL_004E: br.s IL_0023
        // IL_0050: ldc.i4.2 2
        // IL_0051: box 0x01000183 [mscorlib]System.Int32
        // IL_0056: ldloc.1 1
        // IL_0057: callvirt 0x0A00082D class [mscorlib]System.Collections.Generic.ICollection`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject>::get_Count
        // IL_005C: box 0x01000183 [mscorlib]System.Int32
        // IL_0061: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0066: nop 
        // IL_0067: ldstr 0x70000858 [65, 100, 109, 105, 110] utf16-bytes=[41, 00, 64, 00, 6D, 00, 69, 00, 6E, 00] terminal-flag=Some(0)
        // IL_006C: ldloc.1 1
        // IL_006D: ldc.i4.0 0
        // IL_006E: callvirt 0x0A00082E class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject>::get_Item
        // IL_0073: ldstr 0x700042B3 [110, 97, 109, 101] utf16-bytes=[6E, 00, 61, 00, 6D, 00, 65, 00] terminal-flag=Some(0)
        // IL_0078: callvirt 0x0A000473 [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject::get_Item
        // IL_007D: call 0x0A0002D4 [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::op_Explicit
        // IL_0082: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0087: nop 
        // IL_0088: ldstr 0x70043256 [80, 117, 98, 108, 105, 115, 104, 101, 114] utf16-bytes=[50, 00, 75, 00, 62, 00, 6C, 00, 69, 00, 73, 00, 68, 00, 65, 00, 72, 00] terminal-flag=Some(0)
        // IL_008D: ldloc.1 1
        // IL_008E: ldc.i4.1 1
        // IL_008F: callvirt 0x0A00082E class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject>::get_Item
        // IL_0094: ldstr 0x700042B3 [110, 97, 109, 101] utf16-bytes=[6E, 00, 61, 00, 6D, 00, 65, 00] terminal-flag=Some(0)
        // IL_0099: callvirt 0x0A000473 [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject::get_Item
        // IL_009E: call 0x0A0002D4 [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::op_Explicit
        // IL_00A3: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00A8: nop 
        // IL_00A9: ret 
    }

    public void JObjectWithComments()
    {
        string v0 = __cil_ldstr_7004326A("{ /*comment2*/\u000D\u000A        \"Name\": /*comment3*/ \"Apple\" /*comment4*/, /*comment5*/\u000D\u000A        \"ExpiryDate\": \"\\/Date(1230422400000)\\/\",\u000D\u000A        \"Price\": 3.99,\u000D\u000A        \"Sizes\": /*comment6*/ [ /*comment7*/\u000D\u000A          \"Small\", /*comment8*/\u000D\u000A          \"Medium\" /*comment9*/,\u000D\u000A          /*comment10*/ \"Large\"\u000D\u000A        /*comment11*/ ] /*comment12*/\u000D\u000A      } /*comment13*/");
        __cil_type_01000091 v2 = Newtonsoft.Json.Linq.JToken.Parse(v0);
        string v3 = __cil_ldstr_7001A6DF("Apple");
        string v5 = __cil_ldstr_70001B27("Name");
        __cil_type_01000091 v6 = __cil_callvirt_0A0002D3(v2, ((object)(v5)));
        string v7 = Newtonsoft.Json.Linq.JToken.op_Explicit(v6);
        NUnit.Framework.Assert.AreEqual(((object)(v3)), ((object)(v7)));
        return;
    }

    public void WritePropertyWithNoValue()
    {
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7004353F("novalue");
        __cil_type_010000F2 v3 = __cil_newobj_0A00082F(v2);
        v0.Add(((object)(v3)));
        string v4 = __cil_ldstr_7004354F("{\u000D\u000A  \"novalue\": null\u000D\u000A}");
        string v6 = v0.ToString();
        Newtonsoft.Json.Tests.StringAssert.AreEqual(v4, v6);
        return;
    }

    public void Keys()
    {
        // structural signature __cil_ref_084f9ea402e932f88be7ab6dd58b4e9da19cb0d5 bytes=15128081020E128245: class [mscorlib]System.Collections.Generic.IDictionary`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_03093b8f691fe01b4064f1094f9a300729d3c422 bytes=15128239010E: class [mscorlib]System.Collections.Generic.ICollection`1<string>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        object v3 = ((object)((int)(0)));
        __cil_ref_03093b8f691fe01b4064f1094f9a300729d3c422 v5 = __cil_callvirt_0A000830(v0);
        int v6 = __cil_callvirt_0A0004E8(v5);
        object v7 = ((object)((int)(v6)));
        NUnit.Framework.Assert.AreEqual(v3, v7);
        string v9 = __cil_ldstr_700042BD("value");
        __cil_type_01000091 v11 = Newtonsoft.Json.Linq.JToken.op_Implicit(__cil_bool_store(1));
        __cil_callvirt_0A00046E(v0, v9, v11);
        object v13 = ((object)((int)(1)));
        __cil_ref_03093b8f691fe01b4064f1094f9a300729d3c422 v15 = __cil_callvirt_0A000830(v0);
        int v16 = __cil_callvirt_0A0004E8(v15);
        object v17 = ((object)((int)(v16)));
        NUnit.Framework.Assert.AreEqual(v13, v17);
        return;
    }

    public void TryGetValue()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 l0 = default;
        __cil_type_01000091 l1 = default;
        IL_0000: ;
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        l0 = v0;
        __cil_type_01000023 v1 = l0;
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        int v3 = 1;
        long v4 = unchecked((long)(v3));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v1.Add(v2, ((__cil_type_01000091)(v5)));
        int v6 = 1;
        object v7 = ((object)((int)(v6)));
        __cil_type_01000023 v8 = l0;
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v9 = v8.Children();
        object v10 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v9)));
        int v11 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v10)));
        object v12 = ((object)((int)(v11)));
        NUnit.Framework.Assert.AreEqual(v7, v12);
        int v13 = 0;
        object v14 = ((object)(__cil_bool_store(v13)));
        __cil_type_01000023 v15 = l0;
        string v16 = __cil_ldstr_700435A3("sdf");
        ref __cil_type_01000091 v17 = ref l1;
        int v18 = __cil_bool_load(v15.TryGetValue(v16, ref v17));
        object v19 = ((object)(__cil_bool_store(v18)));
        NUnit.Framework.Assert.AreEqual(v14, v19);
        __cil_type_01000091 v20 = l1;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v20)));
        int v21 = 0;
        object v22 = ((object)(__cil_bool_store(v21)));
        __cil_type_01000023 v23 = l0;
        ref __cil_type_01000091 v24 = ref l1;
        int v25 = __cil_bool_load(v23.TryGetValue(((string)(null)), ref v24));
        object v26 = ((object)(__cil_bool_store(v25)));
        NUnit.Framework.Assert.AreEqual(v22, v26);
        __cil_type_01000091 v27 = l1;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v27)));
        int v28 = 1;
        object v29 = ((object)(__cil_bool_store(v28)));
        __cil_type_01000023 v30 = l0;
        string v31 = __cil_ldstr_7004357F("PropertyNameValue");
        ref __cil_type_01000091 v32 = ref l1;
        int v33 = __cil_bool_load(v30.TryGetValue(v31, ref v32));
        object v34 = ((object)(__cil_bool_store(v33)));
        NUnit.Framework.Assert.AreEqual(v29, v34);
        int v35 = 1;
        object v36 = ((object)(__cil_bool_store(v35)));
        int v37 = 1;
        long v38 = unchecked((long)(v37));
        __cil_type_010000B6 v39 = __cil_newobj_0A000730(v38);
        __cil_type_01000091 v40 = l1;
        int v41 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.DeepEquals(((__cil_type_01000091)(v39)), v40));
        object v42 = ((object)(__cil_bool_store(v41)));
        NUnit.Framework.Assert.AreEqual(v36, v42);
        return;
    }

    public void DictionaryItemShouldSet()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 l0 = default;
        __cil_type_01000091 l1 = default;
        IL_0000: ;
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        l0 = v0;
        __cil_type_01000023 v1 = l0;
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        int v3 = 1;
        long v4 = unchecked((long)(v3));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        __cil_callvirt_0A00046E(v1, v2, ((__cil_type_01000091)(v5)));
        int v6 = 1;
        object v7 = ((object)((int)(v6)));
        __cil_type_01000023 v8 = l0;
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v9 = v8.Children();
        object v10 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v9)));
        int v11 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v10)));
        object v12 = ((object)((int)(v11)));
        NUnit.Framework.Assert.AreEqual(v7, v12);
        int v13 = 1;
        object v14 = ((object)(__cil_bool_store(v13)));
        __cil_type_01000023 v15 = l0;
        string v16 = __cil_ldstr_7004357F("PropertyNameValue");
        ref __cil_type_01000091 v17 = ref l1;
        int v18 = __cil_bool_load(v15.TryGetValue(v16, ref v17));
        object v19 = ((object)(__cil_bool_store(v18)));
        NUnit.Framework.Assert.AreEqual(v14, v19);
        int v20 = 1;
        object v21 = ((object)(__cil_bool_store(v20)));
        int v22 = 1;
        long v23 = unchecked((long)(v22));
        __cil_type_010000B6 v24 = __cil_newobj_0A000730(v23);
        __cil_type_01000091 v25 = l1;
        int v26 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.DeepEquals(((__cil_type_01000091)(v24)), v25));
        object v27 = ((object)(__cil_bool_store(v26)));
        NUnit.Framework.Assert.AreEqual(v21, v27);
        __cil_type_01000023 v28 = l0;
        string v29 = __cil_ldstr_7004357F("PropertyNameValue");
        int v30 = 2;
        long v31 = unchecked((long)(v30));
        __cil_type_010000B6 v32 = __cil_newobj_0A000730(v31);
        __cil_callvirt_0A00046E(v28, v29, ((__cil_type_01000091)(v32)));
        int v33 = 1;
        object v34 = ((object)((int)(v33)));
        __cil_type_01000023 v35 = l0;
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v36 = v35.Children();
        object v37 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v36)));
        int v38 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v37)));
        object v39 = ((object)((int)(v38)));
        NUnit.Framework.Assert.AreEqual(v34, v39);
        int v40 = 1;
        object v41 = ((object)(__cil_bool_store(v40)));
        __cil_type_01000023 v42 = l0;
        string v43 = __cil_ldstr_7004357F("PropertyNameValue");
        ref __cil_type_01000091 v44 = ref l1;
        int v45 = __cil_bool_load(v42.TryGetValue(v43, ref v44));
        object v46 = ((object)(__cil_bool_store(v45)));
        NUnit.Framework.Assert.AreEqual(v41, v46);
        int v47 = 1;
        object v48 = ((object)(__cil_bool_store(v47)));
        int v49 = 2;
        long v50 = unchecked((long)(v49));
        __cil_type_010000B6 v51 = __cil_newobj_0A000730(v50);
        __cil_type_01000091 v52 = l1;
        int v53 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.DeepEquals(((__cil_type_01000091)(v51)), v52));
        object v54 = ((object)(__cil_bool_store(v53)));
        NUnit.Framework.Assert.AreEqual(v48, v54);
        __cil_type_01000023 v55 = l0;
        string v56 = __cil_ldstr_7004357F("PropertyNameValue");
        __cil_callvirt_0A00046E(v55, v56, ((__cil_type_01000091)(null)));
        int v57 = 1;
        object v58 = ((object)((int)(v57)));
        __cil_type_01000023 v59 = l0;
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v60 = v59.Children();
        object v61 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v60)));
        int v62 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v61)));
        object v63 = ((object)((int)(v62)));
        NUnit.Framework.Assert.AreEqual(v58, v63);
        int v64 = 1;
        object v65 = ((object)(__cil_bool_store(v64)));
        __cil_type_01000023 v66 = l0;
        string v67 = __cil_ldstr_7004357F("PropertyNameValue");
        ref __cil_type_01000091 v68 = ref l1;
        int v69 = __cil_bool_load(v66.TryGetValue(v67, ref v68));
        object v70 = ((object)(__cil_bool_store(v69)));
        NUnit.Framework.Assert.AreEqual(v65, v70);
        int v71 = 1;
        object v72 = ((object)(__cil_bool_store(v71)));
        __cil_type_010000B6 v73 = Newtonsoft.Json.Linq.JValue.CreateNull();
        __cil_type_01000091 v74 = l1;
        int v75 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.DeepEquals(((__cil_type_01000091)(v73)), v74));
        object v76 = ((object)(__cil_bool_store(v75)));
        NUnit.Framework.Assert.AreEqual(v72, v76);
        return;
    }

    public void Remove()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        long v4 = unchecked((long)(1));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v0.Add(v2, ((__cil_type_01000091)(v5)));
        object v7 = ((object)((int)(1)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v9 = v0.Children();
        object v10 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v9)));
        int v11 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v10)));
        object v12 = ((object)((int)(v11)));
        NUnit.Framework.Assert.AreEqual(v7, v12);
        object v14 = ((object)(__cil_bool_store(0)));
        string v16 = __cil_ldstr_700435A3("sdf");
        int v17 = __cil_bool_load(v0.Remove(v16));
        object v18 = ((object)(__cil_bool_store(v17)));
        NUnit.Framework.Assert.AreEqual(v14, v18);
        object v20 = ((object)(__cil_bool_store(0)));
        int v22 = __cil_bool_load(v0.Remove(((string)(null))));
        object v23 = ((object)(__cil_bool_store(v22)));
        NUnit.Framework.Assert.AreEqual(v20, v23);
        object v25 = ((object)(__cil_bool_store(1)));
        string v27 = __cil_ldstr_7004357F("PropertyNameValue");
        int v28 = __cil_bool_load(v0.Remove(v27));
        object v29 = ((object)(__cil_bool_store(v28)));
        NUnit.Framework.Assert.AreEqual(v25, v29);
        object v31 = ((object)((int)(0)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v33 = v0.Children();
        object v34 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v33)));
        int v35 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v34)));
        object v36 = ((object)((int)(v35)));
        NUnit.Framework.Assert.AreEqual(v31, v36);
        return;
    }

    public void GenericCollectionRemove()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 bytes=15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        long v1 = unchecked((long)(1));
        __cil_type_010000B6 v2 = __cil_newobj_0A000730(v1);
        __cil_type_01000023 v3 = __cil_newobj_0A000466();
        string v5 = __cil_ldstr_7004357F("PropertyNameValue");
        v3.Add(v5, ((__cil_type_01000091)(v2)));
        object v8 = ((object)((int)(1)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v10 = v3.Children();
        object v11 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v10)));
        int v12 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v11)));
        object v13 = ((object)((int)(v12)));
        NUnit.Framework.Assert.AreEqual(v8, v13);
        object v15 = ((object)(__cil_bool_store(0)));
        string v17 = __cil_ldstr_700435AB("PropertyNameValue1");
        long v19 = unchecked((long)(1));
        __cil_type_010000B6 v20 = __cil_newobj_0A000730(v19);
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v21 = __cil_value_newobj_0A000833(v17, v20);
        int v22 = __cil_bool_load(__cil_callvirt_0A000834(v3, v21));
        object v23 = ((object)(__cil_bool_store(v22)));
        NUnit.Framework.Assert.AreEqual(v15, v23);
        object v25 = ((object)(__cil_bool_store(0)));
        string v27 = __cil_ldstr_7004357F("PropertyNameValue");
        long v29 = unchecked((long)(2));
        __cil_type_010000B6 v30 = __cil_newobj_0A000730(v29);
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v31 = __cil_value_newobj_0A000833(v27, v30);
        int v32 = __cil_bool_load(__cil_callvirt_0A000834(v3, v31));
        object v33 = ((object)(__cil_bool_store(v32)));
        NUnit.Framework.Assert.AreEqual(v25, v33);
        object v35 = ((object)(__cil_bool_store(0)));
        string v37 = __cil_ldstr_7004357F("PropertyNameValue");
        long v39 = unchecked((long)(1));
        __cil_type_010000B6 v40 = __cil_newobj_0A000730(v39);
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v41 = __cil_value_newobj_0A000833(v37, v40);
        int v42 = __cil_bool_load(__cil_callvirt_0A000834(v3, v41));
        object v43 = ((object)(__cil_bool_store(v42)));
        NUnit.Framework.Assert.AreEqual(v35, v43);
        object v45 = ((object)(__cil_bool_store(1)));
        string v47 = __cil_ldstr_7004357F("PropertyNameValue");
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v49 = __cil_value_newobj_0A000833(v47, v2);
        int v50 = __cil_bool_load(__cil_callvirt_0A000834(v3, v49));
        object v51 = ((object)(__cil_bool_store(v50)));
        NUnit.Framework.Assert.AreEqual(v45, v51);
        object v53 = ((object)((int)(0)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v55 = v3.Children();
        object v56 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v55)));
        int v57 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v56)));
        object v58 = ((object)((int)(v57)));
        NUnit.Framework.Assert.AreEqual(v53, v58);
        return;
    }

    public void DuplicatePropertyNameShouldThrow()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1F;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B0E;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1F = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700435D1("Can not add property PropertyNameValue to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void GenericDictionaryAdd()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        long v4 = unchecked((long)(1));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v0.Add(v2, ((__cil_type_01000091)(v5)));
        object v7 = ((object)((int)(1)));
        string v9 = __cil_ldstr_7004357F("PropertyNameValue");
        __cil_type_01000091 v10 = __cil_callvirt_0A000473(v0, v9);
        int v11 = Newtonsoft.Json.Linq.JToken.op_Explicit(v10);
        object v12 = ((object)((int)(v11)));
        NUnit.Framework.Assert.AreEqual(v7, v12);
        string v14 = __cil_ldstr_700435AB("PropertyNameValue1");
        v0.Add(v14, ((__cil_type_01000091)(null)));
        string v16 = __cil_ldstr_700435AB("PropertyNameValue1");
        __cil_type_01000091 v17 = __cil_callvirt_0A000473(v0, v16);
        __cil_type_010000B6 v18 = ((__cil_type_010000B6)(object)v17);
        object v19 = ((Newtonsoft.Json.Linq.JValue)v18).Value;
        NUnit.Framework.Assert.AreEqual(((object)(null)), v19);
        object v21 = ((object)((int)(2)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v23 = v0.Children();
        object v24 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v23)));
        int v25 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v24)));
        object v26 = ((object)((int)(v25)));
        NUnit.Framework.Assert.AreEqual(v21, v26);
        return;
    }

    public void GenericCollectionAdd()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 bytes=15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        long v4 = unchecked((long)(1));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v6 = __cil_value_newobj_0A000833(v2, v5);
        __cil_callvirt_0A000835(v0, v6);
        object v8 = ((object)((int)(1)));
        string v10 = __cil_ldstr_7004357F("PropertyNameValue");
        __cil_type_01000091 v11 = __cil_callvirt_0A000473(v0, v10);
        int v12 = Newtonsoft.Json.Linq.JToken.op_Explicit(v11);
        object v13 = ((object)((int)(v12)));
        NUnit.Framework.Assert.AreEqual(v8, v13);
        object v15 = ((object)((int)(1)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v17 = v0.Children();
        object v18 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v17)));
        int v19 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v18)));
        object v20 = ((object)((int)(v19)));
        NUnit.Framework.Assert.AreEqual(v15, v20);
        return;
    }

    public void GenericCollectionClear()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        long v4 = unchecked((long)(1));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v0.Add(v2, ((__cil_type_01000091)(v5)));
        object v7 = ((object)((int)(1)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v9 = v0.Children();
        object v10 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v9)));
        int v11 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v10)));
        object v12 = ((object)((int)(v11)));
        NUnit.Framework.Assert.AreEqual(v7, v12);
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v14 = v0.Children();
        object v15 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v14)));
        __cil_type_01000091 v17 = __cil_methodspec_call_2B000244(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v15)), 0);
        __cil_type_010000F2 v18 = ((__cil_type_010000F2)(object)v17);
        __cil_callvirt_0A000836(v0);
        object v21 = ((object)((int)(0)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v23 = v0.Children();
        object v24 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v23)));
        int v25 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v24)));
        object v26 = ((object)((int)(v25)));
        NUnit.Framework.Assert.AreEqual(v21, v26);
        __cil_type_01000154 v28 = ((Newtonsoft.Json.Linq.JToken)v18).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v28)));
        return;
    }

    public void GenericCollectionContains()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 bytes=15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        __cil_type_010000B6 l0 = default;
        __cil_type_01000023 l1 = default;
        bool l2 = default;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 l3 = default;
        IL_0000: ;
        int v0 = 1;
        long v1 = unchecked((long)(v0));
        __cil_type_010000B6 v2 = __cil_newobj_0A000730(v1);
        l0 = v2;
        __cil_type_01000023 v3 = __cil_newobj_0A000466();
        l1 = v3;
        __cil_type_01000023 v4 = l1;
        string v5 = __cil_ldstr_7004357F("PropertyNameValue");
        __cil_type_010000B6 v6 = l0;
        v4.Add(v5, ((__cil_type_01000091)(v6)));
        int v7 = 1;
        object v8 = ((object)((int)(v7)));
        __cil_type_01000023 v9 = l1;
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v10 = v9.Children();
        object v11 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v10)));
        int v12 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v11)));
        object v13 = ((object)((int)(v12)));
        NUnit.Framework.Assert.AreEqual(v8, v13);
        __cil_type_01000023 v14 = l1;
        string v15 = __cil_ldstr_7004357F("PropertyNameValue");
        int v16 = 1;
        long v17 = unchecked((long)(v16));
        __cil_type_010000B6 v18 = __cil_newobj_0A000730(v17);
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v19 = __cil_value_newobj_0A000833(v15, v18);
        int v20 = __cil_bool_load(__cil_callvirt_0A000837(v14, v19));
        l2 = __cil_bool_store(v20);
        int v21 = 0;
        object v22 = ((object)(__cil_bool_store(v21)));
        int v23 = __cil_bool_load(l2);
        object v24 = ((object)(__cil_bool_store(v23)));
        NUnit.Framework.Assert.AreEqual(v22, v24);
        __cil_type_01000023 v25 = l1;
        string v26 = __cil_ldstr_7004357F("PropertyNameValue");
        __cil_type_010000B6 v27 = l0;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v28 = __cil_value_newobj_0A000833(v26, v27);
        int v29 = __cil_bool_load(__cil_callvirt_0A000837(v25, v28));
        l2 = __cil_bool_store(v29);
        int v30 = 1;
        object v31 = ((object)(__cil_bool_store(v30)));
        int v32 = __cil_bool_load(l2);
        object v33 = ((object)(__cil_bool_store(v32)));
        NUnit.Framework.Assert.AreEqual(v31, v33);
        __cil_type_01000023 v34 = l1;
        string v35 = __cil_ldstr_7004357F("PropertyNameValue");
        int v36 = 2;
        long v37 = unchecked((long)(v36));
        __cil_type_010000B6 v38 = __cil_newobj_0A000730(v37);
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v39 = __cil_value_newobj_0A000833(v35, v38);
        int v40 = __cil_bool_load(__cil_callvirt_0A000837(v34, v39));
        l2 = __cil_bool_store(v40);
        int v41 = 0;
        object v42 = ((object)(__cil_bool_store(v41)));
        int v43 = __cil_bool_load(l2);
        object v44 = ((object)(__cil_bool_store(v43)));
        NUnit.Framework.Assert.AreEqual(v42, v44);
        __cil_type_01000023 v45 = l1;
        string v46 = __cil_ldstr_700435AB("PropertyNameValue1");
        int v47 = 1;
        long v48 = unchecked((long)(v47));
        __cil_type_010000B6 v49 = __cil_newobj_0A000730(v48);
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v50 = __cil_value_newobj_0A000833(v46, v49);
        int v51 = __cil_bool_load(__cil_callvirt_0A000837(v45, v50));
        l2 = __cil_bool_store(v51);
        int v52 = 0;
        object v53 = ((object)(__cil_bool_store(v52)));
        int v54 = __cil_bool_load(l2);
        object v55 = ((object)(__cil_bool_store(v54)));
        NUnit.Framework.Assert.AreEqual(v53, v55);
        __cil_type_01000023 v56 = l1;
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v57 = ref l3;
        v57 = default;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v58 = l3;
        int v59 = __cil_bool_load(__cil_callvirt_0A000837(v56, v58));
        l2 = __cil_bool_store(v59);
        int v60 = 0;
        object v61 = ((object)(__cil_bool_store(v60)));
        int v62 = __cil_bool_load(l2);
        object v63 = ((object)(__cil_bool_store(v62)));
        NUnit.Framework.Assert.AreEqual(v61, v63);
        return;
    }

    public void GenericDictionaryContains()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        bool l1 = default;
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        long v4 = unchecked((long)(1));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v0.Add(v2, ((__cil_type_01000091)(v5)));
        object v7 = ((object)((int)(1)));
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v9 = v0.Children();
        object v10 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v9)));
        int v11 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v10)));
        object v12 = ((object)((int)(v11)));
        NUnit.Framework.Assert.AreEqual(v7, v12);
        string v14 = __cil_ldstr_7004357F("PropertyNameValue");
        int v15 = __cil_bool_load(__cil_callvirt_0A000838(v0, v14));
        l1 = __cil_bool_store(v15);
        object v17 = ((object)(__cil_bool_store(1)));
        int v18 = __cil_bool_load(l1);
        object v19 = ((object)(__cil_bool_store(v18)));
        NUnit.Framework.Assert.AreEqual(v17, v19);
        return;
    }

    public void GenericCollectionCopyTo()
    {
        // structural signature __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 bytes=1511855501128245: valuetype [Newtonsoft.Json]Newtonsoft.Json.Linq.JEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 bytes=15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 bytes=1D15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 l0 = default;
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 l1 = default;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 l2 = default;
        IL_0000: ;
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        l0 = v0;
        __cil_type_01000023 v1 = l0;
        string v2 = __cil_ldstr_7004357F("PropertyNameValue");
        int v3 = 1;
        long v4 = unchecked((long)(v3));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v1.Add(v2, ((__cil_type_01000091)(v5)));
        __cil_type_01000023 v6 = l0;
        string v7 = __cil_ldstr_700436CE("PropertyNameValue2");
        int v8 = 2;
        long v9 = unchecked((long)(v8));
        __cil_type_010000B6 v10 = __cil_newobj_0A000730(v9);
        v6.Add(v7, ((__cil_type_01000091)(v10)));
        __cil_type_01000023 v11 = l0;
        string v12 = __cil_ldstr_700436F4("PropertyNameValue3");
        int v13 = 3;
        long v14 = unchecked((long)(v13));
        __cil_type_010000B6 v15 = __cil_newobj_0A000730(v14);
        v11.Add(v12, ((__cil_type_01000091)(v15)));
        int v16 = 3;
        object v17 = ((object)((int)(v16)));
        __cil_type_01000023 v18 = l0;
        __cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90 v19 = v18.Children();
        object v20 = ((object)((__cil_value_d83b0c53ab6dcfdd34b7137bea937cb88c8cfc90)(v19)));
        int v21 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v20)));
        object v22 = ((object)((int)(v21)));
        NUnit.Framework.Assert.AreEqual(v17, v22);
        int v23 = 5;
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v24 = __cil_newarr_1B000149(v23);
        l1 = v24;
        __cil_type_01000023 v25 = l0;
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v26 = l1;
        int v27 = 1;
        __cil_callvirt_0A000839(v25, v26, v27);
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v28 = ref l2;
        v28 = default;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v29 = l2;
        object v30 = ((object)((__cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207)(v29)));
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v31 = l1;
        int v32 = 0;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v33 = __cil_ldelem_1B000149(v31, v32);
        object v34 = ((object)((__cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207)(v33)));
        NUnit.Framework.Assert.AreEqual(v30, v34);
        string v35 = __cil_ldstr_7004357F("PropertyNameValue");
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v36 = l1;
        int v37 = 1;
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v38 = ref __cil_ldelema_1B000149(v36, v37);
        string v39 = __cil_value_call_0A0005D5(ref v38);
        NUnit.Framework.Assert.AreEqual(((object)(v35)), ((object)(v39)));
        int v40 = 1;
        object v41 = ((object)((int)(v40)));
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v42 = l1;
        int v43 = 1;
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v44 = ref __cil_ldelema_1B000149(v42, v43);
        __cil_type_01000091 v45 = __cil_value_call_0A0005D6(ref v44);
        int v46 = Newtonsoft.Json.Linq.JToken.op_Explicit(v45);
        object v47 = ((object)((int)(v46)));
        NUnit.Framework.Assert.AreEqual(v41, v47);
        string v48 = __cil_ldstr_700436CE("PropertyNameValue2");
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v49 = l1;
        int v50 = 2;
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v51 = ref __cil_ldelema_1B000149(v49, v50);
        string v52 = __cil_value_call_0A0005D5(ref v51);
        NUnit.Framework.Assert.AreEqual(((object)(v48)), ((object)(v52)));
        int v53 = 2;
        object v54 = ((object)((int)(v53)));
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v55 = l1;
        int v56 = 2;
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v57 = ref __cil_ldelema_1B000149(v55, v56);
        __cil_type_01000091 v58 = __cil_value_call_0A0005D6(ref v57);
        int v59 = Newtonsoft.Json.Linq.JToken.op_Explicit(v58);
        object v60 = ((object)((int)(v59)));
        NUnit.Framework.Assert.AreEqual(v54, v60);
        string v61 = __cil_ldstr_700436F4("PropertyNameValue3");
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v62 = l1;
        int v63 = 3;
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v64 = ref __cil_ldelema_1B000149(v62, v63);
        string v65 = __cil_value_call_0A0005D5(ref v64);
        NUnit.Framework.Assert.AreEqual(((object)(v61)), ((object)(v65)));
        int v66 = 3;
        object v67 = ((object)((int)(v66)));
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v68 = l1;
        int v69 = 3;
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v70 = ref __cil_ldelema_1B000149(v68, v69);
        __cil_type_01000091 v71 = __cil_value_call_0A0005D6(ref v70);
        int v72 = Newtonsoft.Json.Linq.JToken.op_Explicit(v71);
        object v73 = ((object)((int)(v72)));
        NUnit.Framework.Assert.AreEqual(v67, v73);
        ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v74 = ref l2;
        v74 = default;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v75 = l2;
        object v76 = ((object)((__cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207)(v75)));
        __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v77 = l1;
        int v78 = 4;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v79 = __cil_ldelem_1B000149(v77, v78);
        object v80 = ((object)((__cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207)(v79)));
        NUnit.Framework.Assert.AreEqual(v76, v80);
        return;
    }

    public void GenericCollectionCopyToNullArrayShouldThrow()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B20;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B0F;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B20 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700424BC("Value cannot be null.\u000D\u000AParameter name: array");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void GenericCollectionCopyToNegativeArrayIndexShouldThrow()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B21;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B10;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B21 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70042516("arrayIndex is less than 0.\u000D\u000AParameter name: arrayIndex");
        v5[0] = v7;
        global::System.ArgumentOutOfRangeException v8 = __cil_methodspec_call_2B00005B(s2_0, v5);
        return;
    }

    public void GenericCollectionCopyToArrayIndexEqualGreaterToArrayLengthShouldThrow()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B22;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B11;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B22 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70042584("arrayIndex is equal to or greater than the length of array.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void GenericCollectionCopyToInsufficientArrayCapacity()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B23;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B12;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B23 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700425FC("The number of elements in the source JObject is greater than the available space from arrayIndex to the end of the destination array.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void FromObjectRaw()
    {
        // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@Newtonsoft.@Json.@Linq.@JTokenType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v0 = __cil_newobj_06000655();
        string v1 = __cil_ldstr_7001D902("FirstNameValue");
        __cil_callvirt_06000650(v0, v1);
        string v2 = __cil_ldstr_70004199("[1,2,3,4,5]");
        __cil_type_010000AC v3 = __cil_newobj_0A0005FA(v2);
        __cil_callvirt_06000652(v0, v3);
        string v4 = __cil_ldstr_7001D920("LastNameValue");
        __cil_callvirt_06000654(v0, v4);
        __cil_type_01000023 v6 = Newtonsoft.Json.Linq.JObject.FromObject(((object)(v0)));
        string v7 = __cil_ldstr_7001D902("FirstNameValue");
        string v9 = __cil_ldstr_7004371A("first_name");
        __cil_type_01000091 v10 = __cil_callvirt_0A000473(v6, v9);
        string v11 = Newtonsoft.Json.Linq.JToken.op_Explicit(v10);
        NUnit.Framework.Assert.AreEqual(((object)(v7)), ((object)(v11)));
        object v13 = ((object)((Newtonsoft.Json.Linq.JTokenType)(13)));
        string v15 = __cil_ldstr_70043730("RawContent");
        __cil_type_01000091 v16 = __cil_callvirt_0A000473(v6, v15);
        __cil_type_010000B6 v17 = ((__cil_type_010000B6)(object)v16);
        int v18 = unchecked((int)(((Newtonsoft.Json.Linq.JToken)v17).Type));
        object v19 = ((object)((Newtonsoft.Json.Linq.JTokenType)(v18)));
        NUnit.Framework.Assert.AreEqual(v13, v19);
        string v20 = __cil_ldstr_70004199("[1,2,3,4,5]");
        string v22 = __cil_ldstr_70043730("RawContent");
        __cil_type_01000091 v23 = __cil_callvirt_0A000473(v6, v22);
        string v24 = Newtonsoft.Json.Linq.JToken.op_Explicit(v23);
        NUnit.Framework.Assert.AreEqual(((object)(v20)), ((object)(v24)));
        string v25 = __cil_ldstr_7001D920("LastNameValue");
        string v27 = __cil_ldstr_70043746("last_name");
        __cil_type_01000091 v28 = __cil_callvirt_0A000473(v6, v27);
        string v29 = Newtonsoft.Json.Linq.JToken.op_Explicit(v28);
        NUnit.Framework.Assert.AreEqual(((object)(v25)), ((object)(v29)));
        return;
    }

    public void JTokenReader()
    {
        // enum storage token=0x02000026 alias=__cil_enum_02000026 underlying=int: global::@Newtonsoft.@Json.@JsonToken; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v0 = __cil_newobj_06000655();
        string v1 = __cil_ldstr_7001D902("FirstNameValue");
        __cil_callvirt_06000650(v0, v1);
        string v2 = __cil_ldstr_70004199("[1,2,3,4,5]");
        __cil_type_010000AC v3 = __cil_newobj_0A0005FA(v2);
        __cil_callvirt_06000652(v0, v3);
        string v4 = __cil_ldstr_7001D920("LastNameValue");
        __cil_callvirt_06000654(v0, v4);
        __cil_type_01000023 v6 = Newtonsoft.Json.Linq.JObject.FromObject(((object)(v0)));
        __cil_type_0100013D v8 = __cil_newobj_0A0006EF(v6);
        int v10 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v10));
        object v12 = ((object)((Newtonsoft.Json.JsonToken)(1)));
        int v14 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v15 = ((object)((Newtonsoft.Json.JsonToken)(v14)));
        NUnit.Framework.Assert.AreEqual(v12, v15);
        int v17 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v17));
        object v19 = ((object)((Newtonsoft.Json.JsonToken)(4)));
        int v21 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v22 = ((object)((Newtonsoft.Json.JsonToken)(v21)));
        NUnit.Framework.Assert.AreEqual(v19, v22);
        int v24 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v24));
        object v26 = ((object)((Newtonsoft.Json.JsonToken)(9)));
        int v28 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v29 = ((object)((Newtonsoft.Json.JsonToken)(v28)));
        NUnit.Framework.Assert.AreEqual(v26, v29);
        int v31 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v31));
        object v33 = ((object)((Newtonsoft.Json.JsonToken)(4)));
        int v35 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v36 = ((object)((Newtonsoft.Json.JsonToken)(v35)));
        NUnit.Framework.Assert.AreEqual(v33, v36);
        int v38 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v38));
        object v40 = ((object)((Newtonsoft.Json.JsonToken)(6)));
        int v42 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v43 = ((object)((Newtonsoft.Json.JsonToken)(v42)));
        NUnit.Framework.Assert.AreEqual(v40, v43);
        int v45 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v45));
        object v47 = ((object)((Newtonsoft.Json.JsonToken)(4)));
        int v49 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v50 = ((object)((Newtonsoft.Json.JsonToken)(v49)));
        NUnit.Framework.Assert.AreEqual(v47, v50);
        int v52 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v52));
        object v54 = ((object)((Newtonsoft.Json.JsonToken)(9)));
        int v56 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v57 = ((object)((Newtonsoft.Json.JsonToken)(v56)));
        NUnit.Framework.Assert.AreEqual(v54, v57);
        int v59 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v59));
        object v61 = ((object)((Newtonsoft.Json.JsonToken)(13)));
        int v63 = unchecked((int)(((Newtonsoft.Json.JsonReader)v8).TokenType));
        object v64 = ((object)((Newtonsoft.Json.JsonToken)(v63)));
        NUnit.Framework.Assert.AreEqual(v61, v64);
        int v66 = __cil_bool_load(v8.Read());
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v66));
        return;
    }

    public void DeserializeFromRaw()
    {
        // structural signature __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 bytes=118685: valuetype [mscorlib]System.RuntimeTypeHandle; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        Newtonsoft.Json.Tests.TestObjects.PersonRaw l0 = default;
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v0 = __cil_newobj_06000655();
        string v1 = __cil_ldstr_7001D902("FirstNameValue");
        __cil_callvirt_06000650(v0, v1);
        string v2 = __cil_ldstr_70004199("[1,2,3,4,5]");
        __cil_type_010000AC v3 = __cil_newobj_0A0005FA(v2);
        __cil_callvirt_06000652(v0, v3);
        string v4 = __cil_ldstr_7001D920("LastNameValue");
        __cil_callvirt_06000654(v0, v4);
        l0 = v0;
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v5 = l0;
        __cil_type_01000023 v6 = Newtonsoft.Json.Linq.JObject.FromObject(((object)(v5)));
        __cil_type_0100013D v8 = __cil_newobj_0A0006EF(v6);
        __cil_type_01000026 v9 = __cil_newobj_0A000112();
        __cil_value_2bcc8d7e5e3197a2a5263340b809abd382b55f15 v12 = __cil_ldtoken_type_02000122;
        __cil_type_01000007 v13 = System.Type.GetTypeFromHandle(v12);
        object v14 = __cil_callvirt_0A000502(v9, v8, v13);
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v15 = ((Newtonsoft.Json.Tests.TestObjects.PersonRaw)(object)v14);
        l0 = v15;
        string v16 = __cil_ldstr_7001D902("FirstNameValue");
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v17 = l0;
        string v18 = __cil_callvirt_0600064F(v17);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), ((object)(v18)));
        string v19 = __cil_ldstr_7001D920("LastNameValue");
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v20 = l0;
        string v21 = __cil_callvirt_06000653(v20);
        NUnit.Framework.Assert.AreEqual(((object)(v19)), ((object)(v21)));
        string v22 = __cil_ldstr_70004199("[1,2,3,4,5]");
        global::Newtonsoft.Json.Tests.TestObjects.PersonRaw v23 = l0;
        __cil_type_010000AC v24 = __cil_callvirt_06000651(v23);
        object v25 = ((Newtonsoft.Json.Linq.JValue)v24).Value;
        NUnit.Framework.Assert.AreEqual(((object)(v22)), v25);
        return;
    }

    public void Parse_ShouldThrowOnUnexpectedToken()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B24;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B13;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B24 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7004375A("Error reading JObject from JsonReader. Current JsonReader item is not an object: StartArray. Path '', line 1, position 1.");
        v5[0] = v7;
        __cil_type_01000031 v8 = __cil_methodspec_call_2B000012(s2_0, v5);
        return;
    }

    public void ParseJavaScriptDate()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [mscorlib]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_7004384F("[new Date(1207285200000)]");
        object v2 = Newtonsoft.Json.JsonConvert.DeserializeObject(v0);
        __cil_type_0100010B v3 = ((__cil_type_0100010B)(object)v2);
        __cil_type_01000091 v6 = __cil_callvirt_0A000460(v3, 0);
        __cil_type_010000B6 v7 = ((__cil_type_010000B6)(object)v6);
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v9 = Newtonsoft.Json.Utilities.DateTimeUtils.ConvertJavaScriptTicksToDateTime(1207285200000L);
        object v10 = ((object)((__cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6)(v9)));
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v12 = Newtonsoft.Json.Linq.JToken.op_Explicit(((__cil_type_01000091)(v7)));
        object v13 = ((object)((__cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6)(v12)));
        NUnit.Framework.Assert.AreEqual(v10, v13);
        return;
    }

    public void GenericValueCast()
    {
        // IL fallback: generic virtual dispatch needs runtime lookup-order modeling
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [00, 72, 83, 38, 04, 70, 0A, 06, 28, 23, 01, 00, 0A, 74, 23, 00, 00, 01, 0B, 07, 72, E7, 3B, 00]
        // .code-bytes IL_0018: [70, 6F, 49, 02, 00, 2B, 0C, 17, 8C, 8C, 01, 00, 01, 08, 8C, 77, 00, 00, 1B, 28, C7, 00, 00, 0A]
        // .code-bytes IL_0030: [00, 72, 9D, 38, 04, 70, 0A, 06, 28, 23, 01, 00, 0A, 74, 23, 00, 00, 01, 0B, 07, 72, E7, 3B, 00]
        // .code-bytes IL_0048: [70, 6F, 49, 02, 00, 2B, 0C, 14, 08, 8C, 77, 00, 00, 1B, 28, C7, 00, 00, 0A, 00, 2A]
        // .local [0] string
        // .local [1] class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject
        // .local [2] valuetype [mscorlib]System.Nullable`1<bool>
        // IL_0000: nop 
        // IL_0001: ldstr 0x70043883 [123, 34, 102, 111, 111, 34, 58, 116, 114, 117, 101, 125] utf16-bytes=[7B, 00, 22, 00, 66, 00, 6F, 00, 6F, 00, 22, 00, 3A, 00, 74, 00, 72, 00, 75, 00, 65, 00, 7D, 00] terminal-flag=Some(0)
        // IL_0006: stloc.0 0
        // IL_0007: ldloc.0 0
        // IL_0008: call 0x0A000123 [Newtonsoft.Json]Newtonsoft.Json.JsonConvert::DeserializeObject
        // IL_000D: castclass 0x01000023 [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject
        // IL_0012: stloc.1 1
        // IL_0013: ldloc.1 1
        // IL_0014: ldstr 0x70003BE7 [102, 111, 111] utf16-bytes=[66, 00, 6F, 00, 6F, 00] terminal-flag=Some(0)
        // IL_0019: callvirt 0x2B000249 [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::Value<valuetype [mscorlib]System.Nullable`1<bool>>
        // IL_001E: stloc.2 2
        // IL_001F: ldc.i4.1 1
        // IL_0020: box 0x0100018C [mscorlib]System.Boolean
        // IL_0025: ldloc.2 2
        // IL_0026: box 0x1B000077 valuetype [mscorlib]System.Nullable`1<bool>
        // IL_002B: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0030: nop 
        // IL_0031: ldstr 0x7004389D [123, 34, 102, 111, 111, 34, 58, 110, 117, 108, 108, 125] utf16-bytes=[7B, 00, 22, 00, 66, 00, 6F, 00, 6F, 00, 22, 00, 3A, 00, 6E, 00, 75, 00, 6C, 00, 6C, 00, 7D, 00] terminal-flag=Some(0)
        // IL_0036: stloc.0 0
        // IL_0037: ldloc.0 0
        // IL_0038: call 0x0A000123 [Newtonsoft.Json]Newtonsoft.Json.JsonConvert::DeserializeObject
        // IL_003D: castclass 0x01000023 [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject
        // IL_0042: stloc.1 1
        // IL_0043: ldloc.1 1
        // IL_0044: ldstr 0x70003BE7 [102, 111, 111] utf16-bytes=[66, 00, 6F, 00, 6F, 00] terminal-flag=Some(0)
        // IL_0049: callvirt 0x2B000249 [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::Value<valuetype [mscorlib]System.Nullable`1<bool>>
        // IL_004E: stloc.2 2
        // IL_004F: ldnull 
        // IL_0050: ldloc.2 2
        // IL_0051: box 0x1B000077 valuetype [mscorlib]System.Nullable`1<bool>
        // IL_0056: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_005B: nop 
        // IL_005C: ret 
    }

    public void Blog()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B25;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B14;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B25 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_700438B7("Invalid property identifier character: ]. Path 'name', line 3, position 4.");
        v5[0] = v7;
        __cil_type_01000031 v8 = __cil_methodspec_call_2B000012(s2_0, v5);
        return;
    }

    public void RawChildValues()
    {
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7004394E("val1");
        string v3 = __cil_ldstr_7000208A("1");
        __cil_type_010000AC v4 = __cil_newobj_0A0005FA(v3);
        __cil_callvirt_0A00046E(v0, v2, ((__cil_type_01000091)(v4)));
        string v6 = __cil_ldstr_70043958("val2");
        string v7 = __cil_ldstr_7000208A("1");
        __cil_type_010000AC v8 = __cil_newobj_0A0005FA(v7);
        __cil_callvirt_0A00046E(v0, v6, ((__cil_type_01000091)(v8)));
        string v10 = v0.ToString();
        string v11 = __cil_ldstr_70043962("{\u000D\u000A  \"val1\": 1,\u000D\u000A  \"val2\": 1\u000D\u000A}");
        Newtonsoft.Json.Tests.StringAssert.AreEqual(v11, v10);
        return;
    }

    public void Iterate()
    {
        // structural signature __cil_ref_675ac2918d1c558c2dbf70860d0cd83a037218aa bytes=1512816501128245: class [mscorlib]System.Collections.Generic.IEnumerator`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 l0 = default;
        __cil_type_01000091 l1 = default;
        int l2 = default;
        __cil_ref_675ac2918d1c558c2dbf70860d0cd83a037218aa l3 = default;
        __cil_type_010000F2 l4 = default;
        IL_0000: ;
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        l0 = v0;
        __cil_type_01000023 v1 = l0;
        string v2 = __cil_ldstr_700435AB("PropertyNameValue1");
        int v3 = 1;
        long v4 = unchecked((long)(v3));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v1.Add(v2, ((__cil_type_01000091)(v5)));
        __cil_type_01000023 v6 = l0;
        string v7 = __cil_ldstr_700436CE("PropertyNameValue2");
        int v8 = 2;
        long v9 = unchecked((long)(v8));
        __cil_type_010000B6 v10 = __cil_newobj_0A000730(v9);
        v6.Add(v7, ((__cil_type_01000091)(v10)));
        __cil_type_01000023 v11 = l0;
        l1 = v11;
        int v12 = 1;
        l2 = v12;
        __cil_type_01000091 v13 = l1;
        __cil_ref_675ac2918d1c558c2dbf70860d0cd83a037218aa v14 = __cil_callvirt_0A00060C(v13);
        l3 = v14;
        try {
            IL_0039: ;
            goto IL_0088;
            IL_003B: ;
            __cil_ref_675ac2918d1c558c2dbf70860d0cd83a037218aa v15 = l3;
            __cil_type_01000091 v16 = __cil_callvirt_0A00060D(v15);
            __cil_type_010000F2 v17 = ((__cil_type_010000F2)(object)v16);
            l4 = v17;
            string v18 = __cil_ldstr_7004357F("PropertyNameValue");
            int v19 = l2;
            object v20 = ((object)((int)(v19)));
            string v21 = System.String.Concat(((object)(v18)), v20);
            __cil_type_010000F2 v22 = l4;
            string v23 = ((Newtonsoft.Json.Linq.JProperty)v22).Name;
            NUnit.Framework.Assert.AreEqual(((object)(v21)), ((object)(v23)));
            int v24 = l2;
            object v25 = ((object)((int)(v24)));
            __cil_type_010000F2 v26 = l4;
            __cil_type_01000091 v27 = ((Newtonsoft.Json.Linq.JProperty)v26).Value;
            int v28 = Newtonsoft.Json.Linq.JToken.op_Explicit(v27);
            object v29 = ((object)((int)(v28)));
            NUnit.Framework.Assert.AreEqual(v25, v29);
            int v30 = l2;
            int v31 = 1;
            int v32 = unchecked(v30 + v31);
            l2 = v32;
            goto IL_0088;
            IL_0088: ;
            __cil_ref_675ac2918d1c558c2dbf70860d0cd83a037218aa v33 = l3;
            int v34 = __cil_bool_load(__cil_callvirt_0A00002C(v33));
            if (v34 != 0) {
                goto IL_003B;
            } else {
                goto IL_0090;
            }
            IL_0090: ;
            goto IL_009D;
        }
        finally {
            IL_0092: ;
            __cil_ref_675ac2918d1c558c2dbf70860d0cd83a037218aa v35 = l3;
            if (v35 is null) {
                goto IL_009C;
            } else {
                goto IL_0095;
            }
            IL_0095: ;
            __cil_ref_675ac2918d1c558c2dbf70860d0cd83a037218aa v36 = l3;
            __cil_callvirt_0A00002B(v36);
            goto IL_009C;
            IL_009C: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_009D: ;
        return;
    }

    public void KeyValuePairIterate()
    {
        // structural signature __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 bytes=15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_ref_7739c498e4eaf6fa7eb92671b8da6e08ad4a1986 bytes=151281650115118285020E128245: class [mscorlib]System.Collections.Generic.IEnumerator`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 l0 = default;
        int l1 = default;
        __cil_ref_7739c498e4eaf6fa7eb92671b8da6e08ad4a1986 l2 = default;
        __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 l3 = default;
        IL_0000: ;
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        l0 = v0;
        __cil_type_01000023 v1 = l0;
        string v2 = __cil_ldstr_700435AB("PropertyNameValue1");
        int v3 = 1;
        long v4 = unchecked((long)(v3));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        v1.Add(v2, ((__cil_type_01000091)(v5)));
        __cil_type_01000023 v6 = l0;
        string v7 = __cil_ldstr_700436CE("PropertyNameValue2");
        int v8 = 2;
        long v9 = unchecked((long)(v8));
        __cil_type_010000B6 v10 = __cil_newobj_0A000730(v9);
        v6.Add(v7, ((__cil_type_01000091)(v10)));
        int v11 = 1;
        l1 = v11;
        __cil_type_01000023 v12 = l0;
        __cil_ref_7739c498e4eaf6fa7eb92671b8da6e08ad4a1986 v13 = v12.GetEnumerator();
        l2 = v13;
        try {
            IL_0037: ;
            goto IL_0080;
            IL_0039: ;
            __cil_ref_7739c498e4eaf6fa7eb92671b8da6e08ad4a1986 v14 = l2;
            __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v15 = __cil_callvirt_0A0005D4(v14);
            l3 = v15;
            string v16 = __cil_ldstr_7004357F("PropertyNameValue");
            int v17 = l1;
            object v18 = ((object)((int)(v17)));
            string v19 = System.String.Concat(((object)(v16)), v18);
            ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v20 = ref l3;
            string v21 = __cil_value_call_0A0005D5(ref v20);
            NUnit.Framework.Assert.AreEqual(((object)(v19)), ((object)(v21)));
            int v22 = l1;
            object v23 = ((object)((int)(v22)));
            ref __cil_value_013834f3a221925d0ff71ca8cd2252114c8c7207 v24 = ref l3;
            __cil_type_01000091 v25 = __cil_value_call_0A0005D6(ref v24);
            int v26 = Newtonsoft.Json.Linq.JToken.op_Explicit(v25);
            object v27 = ((object)((int)(v26)));
            NUnit.Framework.Assert.AreEqual(v23, v27);
            int v28 = l1;
            int v29 = 1;
            int v30 = unchecked(v28 + v29);
            l1 = v30;
            goto IL_0080;
            IL_0080: ;
            __cil_ref_7739c498e4eaf6fa7eb92671b8da6e08ad4a1986 v31 = l2;
            int v32 = __cil_bool_load(__cil_callvirt_0A00002C(v31));
            if (v32 != 0) {
                goto IL_0039;
            } else {
                goto IL_0088;
            }
            IL_0088: ;
            goto IL_0095;
        }
        finally {
            IL_008A: ;
            __cil_ref_7739c498e4eaf6fa7eb92671b8da6e08ad4a1986 v33 = l2;
            if (v33 is null) {
                goto IL_0094;
            } else {
                goto IL_008D;
            }
            IL_008D: ;
            __cil_ref_7739c498e4eaf6fa7eb92671b8da6e08ad4a1986 v34 = l2;
            __cil_callvirt_0A00002B(v34);
            goto IL_0094;
            IL_0094: ;
            goto __cil_finally_end_0;
            __cil_finally_end_0: ;
        }
        IL_0095: ;
        return;
    }

    public void WriteObjectNullStringValue()
    {
        // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@Newtonsoft.@Json.@Linq.@JTokenType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string l0 = default;
        l0 = null;
        string v0 = l0;
        __cil_type_010000B6 v1 = __cil_newobj_0A0005C2(v0);
        object v3 = ((Newtonsoft.Json.Linq.JValue)v1).Value;
        NUnit.Framework.Assert.AreEqual(((object)(null)), v3);
        object v5 = ((object)((Newtonsoft.Json.Linq.JTokenType)(8)));
        int v7 = unchecked((int)(((Newtonsoft.Json.Linq.JToken)v1).Type));
        object v8 = ((object)((Newtonsoft.Json.Linq.JTokenType)(v7)));
        NUnit.Framework.Assert.AreEqual(v5, v8);
        __cil_type_01000023 v9 = __cil_newobj_0A000466();
        string v11 = __cil_ldstr_70019BAA("title");
        __cil_callvirt_0A00046E(v9, v11, ((__cil_type_01000091)(v1)));
        string v14 = v9.ToString();
        string v15 = __cil_ldstr_70019BB6("{\u000D\u000A  \"title\": null\u000D\u000A}");
        Newtonsoft.Json.Tests.StringAssert.AreEqual(v15, v14);
        return;
    }

    public void Example()
    {
        string v0 = __cil_ldstr_700439A2("{\u000D\u000A        \"Name\": \"Apple\",\u000D\u000A        \"Expiry\": new Date(1230422400000),\u000D\u000A        \"Price\": 3.99,\u000D\u000A        \"Sizes\": [\u000D\u000A          \"Small\",\u000D\u000A          \"Medium\",\u000D\u000A          \"Large\"\u000D\u000A        ]\u000D\u000A      }");
        __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        string v4 = __cil_ldstr_70001B27("Name");
        __cil_type_01000091 v5 = __cil_callvirt_0A000473(v2, v4);
        string v6 = Newtonsoft.Json.Linq.JToken.op_Explicit(v5);
        string v8 = __cil_ldstr_70043B2B("Sizes");
        __cil_type_01000091 v9 = __cil_callvirt_0A000473(v2, v8);
        __cil_type_0100010B v10 = ((__cil_type_0100010B)(object)v9);
        __cil_type_01000091 v13 = __cil_callvirt_0A000460(v10, 0);
        string v14 = Newtonsoft.Json.Linq.JToken.op_Explicit(v13);
        string v15 = __cil_ldstr_7001A6DF("Apple");
        NUnit.Framework.Assert.AreEqual(((object)(v15)), ((object)(v6)));
        string v17 = __cil_ldstr_7000DD5A("Small");
        NUnit.Framework.Assert.AreEqual(((object)(v17)), ((object)(v14)));
        return;
    }

    public void DeserializeClassManually()
    {
        string v0 = __cil_ldstr_70043B37("{\u000D\u000A  \"short\":\u000D\u000A  {\u000D\u000A    \"original\":\"http://www.foo.com/\",\u000D\u000A    \"short\":\"krehqk\",\u000D\u000A    \"error\":\u000D\u000A    {\u000D\u000A      \"code\":0,\u000D\u000A      \"msg\":\"No action taken\"\u000D\u000A    }\u000D\u000A  }\u000D\u000A}");
        __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        global::Newtonsoft.Json.Tests.TestObjects.Shortie v3 = __cil_newobj_0600079C();
        string v5 = __cil_ldstr_700201B2("short");
        __cil_type_01000091 v6 = __cil_callvirt_0A000473(v2, v5);
        string v7 = __cil_ldstr_70043C82("original");
        __cil_type_01000091 v8 = __cil_callvirt_0A0002D3(v6, ((object)(v7)));
        string v9 = Newtonsoft.Json.Linq.JToken.op_Explicit(v8);
        __cil_callvirt_06000795(v3, v9);
        string v11 = __cil_ldstr_700201B2("short");
        __cil_type_01000091 v12 = __cil_callvirt_0A000473(v2, v11);
        string v13 = __cil_ldstr_700201B2("short");
        __cil_type_01000091 v14 = __cil_callvirt_0A0002D3(v12, ((object)(v13)));
        string v15 = Newtonsoft.Json.Linq.JToken.op_Explicit(v14);
        __cil_callvirt_06000799(v3, v15);
        global::Newtonsoft.Json.Tests.TestObjects.ShortieException v16 = __cil_newobj_060007A1();
        string v18 = __cil_ldstr_700201B2("short");
        __cil_type_01000091 v19 = __cil_callvirt_0A000473(v2, v18);
        string v20 = __cil_ldstr_70043C94("error");
        __cil_type_01000091 v21 = __cil_callvirt_0A0002D3(v19, ((object)(v20)));
        string v22 = __cil_ldstr_70043CA0("code");
        __cil_type_01000091 v23 = __cil_callvirt_0A0002D3(v21, ((object)(v22)));
        int v24 = Newtonsoft.Json.Linq.JToken.op_Explicit(v23);
        __cil_callvirt_0600079E(v16, v24);
        string v26 = __cil_ldstr_700201B2("short");
        __cil_type_01000091 v27 = __cil_callvirt_0A000473(v2, v26);
        string v28 = __cil_ldstr_70043C94("error");
        __cil_type_01000091 v29 = __cil_callvirt_0A0002D3(v27, ((object)(v28)));
        string v30 = __cil_ldstr_70043CAA("msg");
        __cil_type_01000091 v31 = __cil_callvirt_0A0002D3(v29, ((object)(v30)));
        string v32 = Newtonsoft.Json.Linq.JToken.op_Explicit(v31);
        __cil_callvirt_060007A0(v16, v32);
        __cil_callvirt_0600079B(v3, v16);
        string v33 = __cil_ldstr_70043CB2("http://www.foo.com/");
        string v35 = __cil_callvirt_06000794(v3);
        NUnit.Framework.Assert.AreEqual(((object)(v33)), ((object)(v35)));
        string v36 = __cil_ldstr_70043CDA("krehqk");
        string v38 = __cil_callvirt_06000798(v3);
        NUnit.Framework.Assert.AreEqual(((object)(v36)), ((object)(v38)));
        string v40 = __cil_callvirt_06000796(v3);
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v40)));
        object v42 = ((object)((int)(0)));
        global::Newtonsoft.Json.Tests.TestObjects.ShortieException v44 = __cil_callvirt_0600079A(v3);
        int v45 = __cil_callvirt_0600079D(v44);
        object v46 = ((object)((int)(v45)));
        NUnit.Framework.Assert.AreEqual(v42, v46);
        string v47 = __cil_ldstr_70043CE8("No action taken");
        global::Newtonsoft.Json.Tests.TestObjects.ShortieException v49 = __cil_callvirt_0600079A(v3);
        string v50 = __cil_callvirt_0600079F(v49);
        NUnit.Framework.Assert.AreEqual(((object)(v47)), ((object)(v50)));
        return;
    }

    public void JObjectContainingHtml()
    {
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_70043D08("rc");
        long v4 = unchecked((long)(200));
        __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
        __cil_callvirt_0A00046E(v0, v2, ((__cil_type_01000091)(v5)));
        string v7 = __cil_ldstr_70043D0E("m");
        string v8 = __cil_ldstr_7000208E("");
        __cil_type_010000B6 v9 = __cil_newobj_0A0005C2(v8);
        __cil_callvirt_0A00046E(v0, v7, ((__cil_type_01000091)(v9)));
        string v11 = __cil_ldstr_70043D12("o");
        string v12 = __cil_ldstr_70043D16("<div class='s1'>\u000D\u000A</div>");
        __cil_type_010000B6 v13 = __cil_newobj_0A0005C2(v12);
        __cil_callvirt_0A00046E(v0, v11, ((__cil_type_01000091)(v13)));
        string v14 = __cil_ldstr_70043D48("{\u000D\u000A  \"rc\": 200,\u000D\u000A  \"m\": \"\",\u000D\u000A  \"o\": \"<div class='s1'>\\r\\n</div>\"\u000D\u000A}");
        string v16 = v0.ToString();
        Newtonsoft.Json.Tests.StringAssert.AreEqual(v14, v16);
        return;
    }

    public void ImplicitValueConversions()
    {
        // structural signature __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 bytes=118085: valuetype [mscorlib]System.DateTime; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        string v2 = __cil_ldstr_7001ED8B("FirstName");
        string v3 = __cil_ldstr_7000EB33("Maurice");
        __cil_type_010000B6 v4 = __cil_newobj_0A0005C2(v3);
        __cil_callvirt_0A00046E(v0, v2, ((__cil_type_01000091)(v4)));
        string v6 = __cil_ldstr_7001ED9F("LastName");
        string v7 = __cil_ldstr_7000EB43("Moss");
        __cil_type_010000B6 v8 = __cil_newobj_0A0005C2(v7);
        __cil_callvirt_0A00046E(v0, v6, ((__cil_type_01000091)(v8)));
        string v10 = __cil_ldstr_7003CD78("BirthDate");
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v14 = __cil_newobj_0A0000CC(1977, 12, 30);
        __cil_type_010000B6 v15 = __cil_newobj_0A0007D2(v14);
        __cil_callvirt_0A00046E(v0, v10, ((__cil_type_01000091)(v15)));
        string v17 = __cil_ldstr_70043DD1("Department");
        string v18 = __cil_ldstr_70001E8F("IT");
        __cil_type_010000B6 v19 = __cil_newobj_0A0005C2(v18);
        __cil_callvirt_0A00046E(v0, v17, ((__cil_type_01000091)(v19)));
        string v21 = __cil_ldstr_70043DE7("JobTitle");
        string v22 = __cil_ldstr_7000EB4D("Support");
        __cil_type_010000B6 v23 = __cil_newobj_0A0005C2(v22);
        __cil_callvirt_0A00046E(v0, v21, ((__cil_type_01000091)(v23)));
        string v24 = __cil_ldstr_70043DF9("{\u000D\u000A  \"FirstName\": \"Maurice\",\u000D\u000A  \"LastName\": \"Moss\",\u000D\u000A  \"BirthDate\": \"1977-12-30T00:00:00\",\u000D\u000A  \"Department\": \"IT\",\u000D\u000A  \"JobTitle\": \"Support\"\u000D\u000A}");
        string v26 = v0.ToString();
        Newtonsoft.Json.Tests.StringAssert.AreEqual(v24, v26);
        __cil_type_01000023 v27 = __cil_newobj_0A000466();
        string v29 = __cil_ldstr_7001ED8B("FirstName");
        string v30 = __cil_ldstr_70043F16("Jen");
        __cil_type_01000091 v31 = Newtonsoft.Json.Linq.JToken.op_Implicit(v30);
        __cil_callvirt_0A00046E(v27, v29, v31);
        string v33 = __cil_ldstr_7001ED9F("LastName");
        string v34 = __cil_ldstr_70043F1E("Barber");
        __cil_type_01000091 v35 = Newtonsoft.Json.Linq.JToken.op_Implicit(v34);
        __cil_callvirt_0A00046E(v27, v33, v35);
        string v37 = __cil_ldstr_7003CD78("BirthDate");
        __cil_value_625aea2dd1a31ad130bf96e01b5f7559f7a115a6 v41 = __cil_newobj_0A0000CC(1978, 3, 15);
        __cil_type_01000091 v42 = Newtonsoft.Json.Linq.JToken.op_Implicit(v41);
        __cil_callvirt_0A00046E(v27, v37, v42);
        string v44 = __cil_ldstr_70043DD1("Department");
        string v45 = __cil_ldstr_70001E8F("IT");
        __cil_type_01000091 v46 = Newtonsoft.Json.Linq.JToken.op_Implicit(v45);
        __cil_callvirt_0A00046E(v27, v44, v46);
        string v48 = __cil_ldstr_70043DE7("JobTitle");
        string v49 = __cil_ldstr_70043F2C("Manager");
        __cil_type_01000091 v50 = Newtonsoft.Json.Linq.JToken.op_Implicit(v49);
        __cil_callvirt_0A00046E(v27, v48, v50);
        string v51 = __cil_ldstr_70043F3C("{\u000D\u000A  \"FirstName\": \"Jen\",\u000D\u000A  \"LastName\": \"Barber\",\u000D\u000A  \"BirthDate\": \"1978-03-15T00:00:00\",\u000D\u000A  \"Department\": \"IT\",\u000D\u000A  \"JobTitle\": \"Manager\"\u000D\u000A}");
        string v53 = v27.ToString();
        Newtonsoft.Json.Tests.StringAssert.AreEqual(v51, v53);
        return;
    }

    public void ReplaceJPropertyWithJPropertyWithSameName()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_af758ae3796a9160d2426c0d25e4182bdace0a77 bytes=15128145011283C9: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JProperty>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        object v18 = __cil_callvirt_0A0004C3(v13, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v3)), v18);
        object v22 = __cil_callvirt_0A0004C3(v13, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v6)), v22);
        string v23 = __cil_ldstr_70016BAD("Test1");
        string v24 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v25 = __cil_newobj_0A000476(v23, v24);
        v3.Replace(((__cil_type_01000091)(v25)));
        __cil_type_01000154 v29 = ((Newtonsoft.Json.Linq.JToken)v3).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v29)));
        __cil_type_01000154 v32 = ((Newtonsoft.Json.Linq.JToken)v25).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(v13)), ((object)(v32)));
        object v36 = __cil_callvirt_0A0004C3(v13, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v25)), v36);
        object v40 = __cil_callvirt_0A0004C3(v13, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v6)), v40);
        object v42 = ((object)((int)(2)));
        int v44 = __cil_callvirt_0A0004C2(v13);
        object v45 = ((object)((int)(v44)));
        NUnit.Framework.Assert.AreEqual(v42, v45);
        object v47 = ((object)((int)(2)));
        __cil_ref_af758ae3796a9160d2426c0d25e4182bdace0a77 v49 = v13.Properties();
        int v50 = __cil_methodspec_call_2B00024A(v49);
        object v51 = ((object)((int)(v50)));
        NUnit.Framework.Assert.AreEqual(v47, v51);
        string v52 = __cil_ldstr_70044055("Test4");
        string v53 = __cil_ldstr_70044061("IV");
        __cil_type_010000F2 v54 = __cil_newobj_0A000476(v52, v53);
        v6.Replace(((__cil_type_01000091)(v54)));
        __cil_type_01000154 v58 = ((Newtonsoft.Json.Linq.JToken)v6).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v58)));
        __cil_type_01000154 v61 = ((Newtonsoft.Json.Linq.JToken)v54).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(v13)), ((object)(v61)));
        object v65 = __cil_callvirt_0A0004C3(v13, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v25)), v65);
        object v69 = __cil_callvirt_0A0004C3(v13, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v54)), v69);
        return;
    }

    public void PropertyChanged()
    {
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 v0 = __cil_newobj_06001B24();
        v0.changed = null;
        v0.changedCount = 0;
        __cil_type_01000023 v4 = __cil_newobj_0A000466();
        nint v7 = __cil_ldftn_06001B25;
        __cil_type_010000B8 v8 = __cil_newobj_0A000798(v0, v7);
        __cil_callvirt_0A000799(v4, v8);
        string v10 = __cil_ldstr_70044067("StringValue");
        string v11 = __cil_ldstr_70013627("value1");
        __cil_type_01000091 v12 = Newtonsoft.Json.Linq.JToken.op_Implicit(v11);
        __cil_callvirt_0A00046E(v4, v10, v12);
        string v13 = __cil_ldstr_70013627("value1");
        object v15 = v0.changed;
        NUnit.Framework.Assert.AreEqual(((object)(v13)), v15);
        string v16 = __cil_ldstr_70013627("value1");
        string v18 = __cil_ldstr_70044067("StringValue");
        __cil_type_01000091 v19 = __cil_callvirt_0A000473(v4, v18);
        string v20 = Newtonsoft.Json.Linq.JToken.op_Explicit(v19);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), ((object)(v20)));
        object v22 = ((object)((int)(1)));
        int v24 = v0.changedCount;
        object v25 = ((object)((int)(v24)));
        NUnit.Framework.Assert.AreEqual(v22, v25);
        string v27 = __cil_ldstr_70044067("StringValue");
        string v28 = __cil_ldstr_70013627("value1");
        __cil_type_01000091 v29 = Newtonsoft.Json.Linq.JToken.op_Implicit(v28);
        __cil_callvirt_0A00046E(v4, v27, v29);
        object v31 = ((object)((int)(1)));
        int v33 = v0.changedCount;
        object v34 = ((object)((int)(v33)));
        NUnit.Framework.Assert.AreEqual(v31, v34);
        string v36 = __cil_ldstr_70044067("StringValue");
        string v37 = __cil_ldstr_70013635("value2");
        __cil_type_01000091 v38 = Newtonsoft.Json.Linq.JToken.op_Implicit(v37);
        __cil_callvirt_0A00046E(v4, v36, v38);
        string v39 = __cil_ldstr_70013635("value2");
        object v41 = v0.changed;
        NUnit.Framework.Assert.AreEqual(((object)(v39)), v41);
        string v42 = __cil_ldstr_70013635("value2");
        string v44 = __cil_ldstr_70044067("StringValue");
        __cil_type_01000091 v45 = __cil_callvirt_0A000473(v4, v44);
        string v46 = Newtonsoft.Json.Linq.JToken.op_Explicit(v45);
        NUnit.Framework.Assert.AreEqual(((object)(v42)), ((object)(v46)));
        object v48 = ((object)((int)(2)));
        int v50 = v0.changedCount;
        object v51 = ((object)((int)(v50)));
        NUnit.Framework.Assert.AreEqual(v48, v51);
        string v53 = __cil_ldstr_70044067("StringValue");
        __cil_callvirt_0A00046E(v4, v53, ((__cil_type_01000091)(null)));
        object v55 = v0.changed;
        NUnit.Framework.Assert.AreEqual(((object)(null)), v55);
        string v57 = __cil_ldstr_70044067("StringValue");
        __cil_type_01000091 v58 = __cil_callvirt_0A000473(v4, v57);
        string v59 = Newtonsoft.Json.Linq.JToken.op_Explicit(v58);
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v59)));
        object v61 = ((object)((int)(3)));
        int v63 = v0.changedCount;
        object v64 = ((object)((int)(v63)));
        NUnit.Framework.Assert.AreEqual(v61, v64);
        string v66 = __cil_ldstr_7004407F("NullValue");
        __cil_callvirt_0A00046E(v4, v66, ((__cil_type_01000091)(null)));
        object v68 = v0.changed;
        NUnit.Framework.Assert.AreEqual(((object)(null)), v68);
        __cil_type_010000B6 v69 = Newtonsoft.Json.Linq.JValue.CreateNull();
        string v71 = __cil_ldstr_7004407F("NullValue");
        __cil_type_01000091 v72 = __cil_callvirt_0A000473(v4, v71);
        NUnit.Framework.Assert.AreEqual(((object)(v69)), ((object)(v72)));
        object v74 = ((object)((int)(4)));
        int v76 = v0.changedCount;
        object v77 = ((object)((int)(v76)));
        NUnit.Framework.Assert.AreEqual(v74, v77);
        string v79 = __cil_ldstr_7004407F("NullValue");
        __cil_callvirt_0A00046E(v4, v79, ((__cil_type_01000091)(null)));
        object v81 = ((object)((int)(4)));
        int v83 = v0.changedCount;
        object v84 = ((object)((int)(v83)));
        NUnit.Framework.Assert.AreEqual(v81, v84);
        return;
    }

    public void IListContains()
    {
        string v0 = __cil_ldstr_70011314("Test");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        __cil_type_01000023 v5 = __cil_newobj_0A000477(v3);
        int v8 = __cil_bool_load(__cil_callvirt_0A00083E(v5, ((object)(v3))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v8));
        string v10 = __cil_ldstr_70011314("Test");
        object v12 = ((object)((int)(1)));
        __cil_type_010000F2 v13 = __cil_newobj_0A000476(v10, v12);
        int v14 = __cil_bool_load(__cil_callvirt_0A00083E(v5, ((object)(v13))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v14));
        return;
    }

    public void IListIndexOf()
    {
        string v0 = __cil_ldstr_70011314("Test");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        __cil_type_01000023 v5 = __cil_newobj_0A000477(v3);
        object v7 = ((object)((int)(0)));
        int v10 = __cil_callvirt_0A00083F(v5, ((object)(v3)));
        object v11 = ((object)((int)(v10)));
        NUnit.Framework.Assert.AreEqual(v7, v11);
        object v13 = ((object)((int)(-1)));
        string v15 = __cil_ldstr_70011314("Test");
        object v17 = ((object)((int)(1)));
        __cil_type_010000F2 v18 = __cil_newobj_0A000476(v15, v17);
        int v19 = __cil_callvirt_0A00083F(v5, ((object)(v18)));
        object v20 = ((object)((int)(v19)));
        NUnit.Framework.Assert.AreEqual(v13, v20);
        return;
    }

    public void IListClear()
    {
        string v0 = __cil_ldstr_70011314("Test");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        __cil_type_01000023 v5 = __cil_newobj_0A000477(v3);
        object v7 = ((object)((int)(1)));
        int v9 = __cil_callvirt_0A0004C2(v5);
        object v10 = ((object)((int)(v9)));
        NUnit.Framework.Assert.AreEqual(v7, v10);
        __cil_callvirt_0A000840(v5);
        object v13 = ((object)((int)(0)));
        int v15 = __cil_callvirt_0A0004C2(v5);
        object v16 = ((object)((int)(v15)));
        NUnit.Framework.Assert.AreEqual(v13, v16);
        return;
    }

    public void IListCopyTo()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        int v15 = __cil_callvirt_0A0004C2(v13);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v16 = __cil_newarr_01000018(v15);
        __cil_callvirt_0A000841(v13, ((__cil_type_0100011F)(v16)), 0);
        object v23 = v16[0];
        NUnit.Framework.Assert.AreEqual(((object)(v3)), v23);
        object v27 = v16[1];
        NUnit.Framework.Assert.AreEqual(((object)(v6)), v27);
        return;
    }

    public void IListAdd()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        int v19 = __cil_callvirt_0A000842(v13, ((object)(v16)));
        object v21 = ((object)((int)(3)));
        int v23 = __cil_callvirt_0A0004C2(v13);
        object v24 = ((object)((int)(v23)));
        NUnit.Framework.Assert.AreEqual(v21, v24);
        object v28 = __cil_callvirt_0A0004C3(v13, 2);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), v28);
        return;
    }

    public void IListAddBadToken()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B26;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B15;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B26 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044093("Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void IListAddBadValue()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B27;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B16;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B27 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044126("Argument is not a JToken.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void IListAddPropertyWithExistingName()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B28;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B17;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B28 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7004415A("Can not add property Test2 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void IListRemove()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        __cil_callvirt_0A000843(v13, ((object)(v16)));
        object v20 = ((object)((int)(2)));
        int v22 = __cil_callvirt_0A0004C2(v13);
        object v23 = ((object)((int)(v22)));
        NUnit.Framework.Assert.AreEqual(v20, v23);
        __cil_callvirt_0A000843(v13, ((object)(v3)));
        object v27 = ((object)((int)(1)));
        int v29 = __cil_callvirt_0A0004C2(v13);
        object v30 = ((object)((int)(v29)));
        NUnit.Framework.Assert.AreEqual(v27, v30);
        int v33 = __cil_bool_load(__cil_callvirt_0A00083E(v13, ((object)(v3))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v33));
        int v36 = __cil_bool_load(__cil_callvirt_0A00083E(v13, ((object)(v6))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v36));
        __cil_callvirt_0A000843(v13, ((object)(v6)));
        object v40 = ((object)((int)(0)));
        int v42 = __cil_callvirt_0A0004C2(v13);
        object v43 = ((object)((int)(v42)));
        NUnit.Framework.Assert.AreEqual(v40, v43);
        int v46 = __cil_bool_load(__cil_callvirt_0A00083E(v13, ((object)(v6))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v46));
        __cil_type_01000154 v48 = ((Newtonsoft.Json.Linq.JToken)v6).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v48)));
        return;
    }

    public void IListRemoveAt()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        __cil_callvirt_0A000844(v13, 0);
        __cil_callvirt_0A000843(v13, ((object)(v3)));
        object v19 = ((object)((int)(1)));
        int v21 = __cil_callvirt_0A0004C2(v13);
        object v22 = ((object)((int)(v21)));
        NUnit.Framework.Assert.AreEqual(v19, v22);
        __cil_callvirt_0A000843(v13, ((object)(v6)));
        object v26 = ((object)((int)(0)));
        int v28 = __cil_callvirt_0A0004C2(v13);
        object v29 = ((object)((int)(v28)));
        NUnit.Framework.Assert.AreEqual(v26, v29);
        return;
    }

    public void IListInsert()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        __cil_callvirt_0A000845(v13, 1, ((object)(v16)));
        __cil_type_01000154 v22 = ((Newtonsoft.Json.Linq.JToken)v16).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(v13)), ((object)(v22)));
        object v26 = __cil_callvirt_0A0004C3(v13, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v3)), v26);
        object v30 = __cil_callvirt_0A0004C3(v13, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), v30);
        object v34 = __cil_callvirt_0A0004C3(v13, 2);
        NUnit.Framework.Assert.AreEqual(((object)(v6)), v34);
        return;
    }

    public void IListIsReadOnly()
    {
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        int v2 = __cil_bool_load(__cil_callvirt_0A000846(v0));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v2));
        return;
    }

    public void IListIsFixedSize()
    {
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        int v2 = __cil_bool_load(__cil_callvirt_0A000847(v0));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v2));
        return;
    }

    public void IListSetItem()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        __cil_callvirt_0A000848(v13, 0, ((object)(v16)));
        object v23 = __cil_callvirt_0A0004C3(v13, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), v23);
        object v27 = __cil_callvirt_0A0004C3(v13, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v6)), v27);
        return;
    }

    public void IListSetItemAlreadyExists()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B29;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B18;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B29 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7004423F("Can not add property Test3 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void IListSetItemInvalid()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2A;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B19;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2A = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044093("Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void IListSyncRoot()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        object v15 = __cil_callvirt_0A000849(v13);
        NUnit.Framework.Assert.IsNotNull(v15);
        return;
    }

    public void IListIsSynchronized()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        int v15 = __cil_bool_load(__cil_callvirt_0A00084A(v13));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v15));
        return;
    }

    public void GenericListJTokenContains()
    {
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70011314("Test");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        __cil_type_01000023 v5 = __cil_newobj_0A000477(v3);
        int v8 = __cil_bool_load(__cil_callvirt_0A00084B(v5, ((__cil_type_01000091)(v3))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v8));
        string v10 = __cil_ldstr_70011314("Test");
        object v12 = ((object)((int)(1)));
        __cil_type_010000F2 v13 = __cil_newobj_0A000476(v10, v12);
        int v14 = __cil_bool_load(__cil_callvirt_0A00084B(v5, ((__cil_type_01000091)(v13))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v14));
        return;
    }

    public void GenericListJTokenIndexOf()
    {
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70011314("Test");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        __cil_type_01000023 v5 = __cil_newobj_0A000477(v3);
        object v7 = ((object)((int)(0)));
        int v10 = __cil_callvirt_0A00084C(v5, ((__cil_type_01000091)(v3)));
        object v11 = ((object)((int)(v10)));
        NUnit.Framework.Assert.AreEqual(v7, v11);
        object v13 = ((object)((int)(-1)));
        string v15 = __cil_ldstr_70011314("Test");
        object v17 = ((object)((int)(1)));
        __cil_type_010000F2 v18 = __cil_newobj_0A000476(v15, v17);
        int v19 = __cil_callvirt_0A00084C(v5, ((__cil_type_01000091)(v18)));
        object v20 = ((object)((int)(v19)));
        NUnit.Framework.Assert.AreEqual(v13, v20);
        return;
    }

    public void GenericListJTokenClear()
    {
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70011314("Test");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        __cil_type_01000023 v5 = __cil_newobj_0A000477(v3);
        object v7 = ((object)((int)(1)));
        int v9 = __cil_callvirt_0A000756(v5);
        object v10 = ((object)((int)(v9)));
        NUnit.Framework.Assert.AreEqual(v7, v10);
        __cil_callvirt_0A00084D(v5);
        object v13 = ((object)((int)(0)));
        int v15 = __cil_callvirt_0A000756(v5);
        object v16 = ((object)((int)(v15)));
        NUnit.Framework.Assert.AreEqual(v13, v16);
        return;
    }

    public void GenericListJTokenCopyTo()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_fe2e55e04ee8a6c5172d4dd8c73becbeaacc7975 bytes=1D128245: class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        int v15 = __cil_callvirt_0A000756(v13);
        __cil_ref_fe2e55e04ee8a6c5172d4dd8c73becbeaacc7975 v16 = __cil_newarr_01000091(v15);
        __cil_callvirt_0A00080E(v13, v16, 0);
        __cil_type_01000091 v23 = v16[0];
        NUnit.Framework.Assert.AreEqual(((object)(v3)), ((object)(v23)));
        __cil_type_01000091 v27 = v16[1];
        NUnit.Framework.Assert.AreEqual(((object)(v6)), ((object)(v27)));
        return;
    }

    public void GenericListJTokenAdd()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        __cil_callvirt_0A00084E(v13, ((__cil_type_01000091)(v16)));
        object v20 = ((object)((int)(3)));
        int v22 = __cil_callvirt_0A000756(v13);
        object v23 = ((object)((int)(v22)));
        NUnit.Framework.Assert.AreEqual(v20, v23);
        __cil_type_01000091 v27 = __cil_callvirt_0A000757(v13, 2);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), ((object)(v27)));
        return;
    }

    public void GenericListJTokenAddBadToken()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2B;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B1A;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2B = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044093("Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void GenericListJTokenAddBadValue()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2C;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B1B;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2C = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044093("Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void GenericListJTokenAddPropertyWithExistingName()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2D;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B1C;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2D = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7004415A("Can not add property Test2 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void GenericListJTokenRemove()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        int v19 = __cil_bool_load(__cil_callvirt_0A00084F(v13, ((__cil_type_01000091)(v16))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v19));
        object v21 = ((object)((int)(2)));
        int v23 = __cil_callvirt_0A000756(v13);
        object v24 = ((object)((int)(v23)));
        NUnit.Framework.Assert.AreEqual(v21, v24);
        int v27 = __cil_bool_load(__cil_callvirt_0A00084F(v13, ((__cil_type_01000091)(v3))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v27));
        object v29 = ((object)((int)(1)));
        int v31 = __cil_callvirt_0A000756(v13);
        object v32 = ((object)((int)(v31)));
        NUnit.Framework.Assert.AreEqual(v29, v32);
        int v35 = __cil_bool_load(__cil_callvirt_0A00084B(v13, ((__cil_type_01000091)(v3))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v35));
        int v38 = __cil_bool_load(__cil_callvirt_0A00084B(v13, ((__cil_type_01000091)(v6))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v38));
        int v41 = __cil_bool_load(__cil_callvirt_0A00084F(v13, ((__cil_type_01000091)(v6))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v41));
        object v43 = ((object)((int)(0)));
        int v45 = __cil_callvirt_0A000756(v13);
        object v46 = ((object)((int)(v45)));
        NUnit.Framework.Assert.AreEqual(v43, v46);
        int v49 = __cil_bool_load(__cil_callvirt_0A00084B(v13, ((__cil_type_01000091)(v6))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v49));
        __cil_type_01000154 v51 = ((Newtonsoft.Json.Linq.JToken)v6).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v51)));
        return;
    }

    public void GenericListJTokenRemoveAt()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        __cil_callvirt_0A000850(v13, 0);
        int v18 = __cil_bool_load(__cil_callvirt_0A00084F(v13, ((__cil_type_01000091)(v3))));
        object v20 = ((object)((int)(1)));
        int v22 = __cil_callvirt_0A000756(v13);
        object v23 = ((object)((int)(v22)));
        NUnit.Framework.Assert.AreEqual(v20, v23);
        int v26 = __cil_bool_load(__cil_callvirt_0A00084F(v13, ((__cil_type_01000091)(v6))));
        object v28 = ((object)((int)(0)));
        int v30 = __cil_callvirt_0A000756(v13);
        object v31 = ((object)((int)(v30)));
        NUnit.Framework.Assert.AreEqual(v28, v31);
        return;
    }

    public void GenericListJTokenInsert()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        __cil_callvirt_0A000851(v13, 1, ((__cil_type_01000091)(v16)));
        __cil_type_01000154 v22 = ((Newtonsoft.Json.Linq.JToken)v16).Parent;
        NUnit.Framework.Assert.AreEqual(((object)(v13)), ((object)(v22)));
        __cil_type_01000091 v26 = __cil_callvirt_0A000757(v13, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v3)), ((object)(v26)));
        __cil_type_01000091 v30 = __cil_callvirt_0A000757(v13, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), ((object)(v30)));
        __cil_type_01000091 v34 = __cil_callvirt_0A000757(v13, 2);
        NUnit.Framework.Assert.AreEqual(((object)(v6)), ((object)(v34)));
        return;
    }

    public void GenericListJTokenIsReadOnly()
    {
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        int v2 = __cil_bool_load(__cil_callvirt_0A000852(v0));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v2));
        return;
    }

    public void GenericListJTokenSetItem()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70016BAD("Test1");
        object v2 = ((object)((int)(1)));
        __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
        string v4 = __cil_ldstr_70016BB9("Test2");
        string v5 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
        v8[0] = v3;
        v8[1] = v6;
        __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
        string v14 = __cil_ldstr_70016BC5("Test3");
        string v15 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
        __cil_callvirt_0A000853(v13, 0, ((__cil_type_01000091)(v16)));
        __cil_type_01000091 v23 = __cil_callvirt_0A000757(v13, 0);
        NUnit.Framework.Assert.AreEqual(((object)(v16)), ((object)(v23)));
        __cil_type_01000091 v27 = __cil_callvirt_0A000757(v13, 1);
        NUnit.Framework.Assert.AreEqual(((object)(v6)), ((object)(v27)));
        return;
    }

    public void GenericListJTokenSetItemAlreadyExists()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2E;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B1D;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2E = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7004423F("Can not add property Test3 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void CollectionChanged()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68 bytes=1511811501118541: valuetype [mscorlib]System.Nullable`1<valuetype [System]System.Collections.Specialized.NotifyCollectionChangedAction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
        // enum storage token=0x0200001A alias=__cil_enum_0200001A underlying=int: global::@System.@Collections.@Specialized.@NotifyCollectionChangedAction; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 l0 = default;
        __cil_type_010000F2 l1 = default;
        __cil_type_010000F2 l2 = default;
        __cil_type_01000023 l3 = default;
        __cil_type_010000F2 l4 = default;
        __cil_type_010000F2 l5 = default;
        IL_0000: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v0 = __cil_newobj_06001B26();
        l0 = v0;
        string v1 = __cil_ldstr_70016BAD("Test1");
        int v2 = 1;
        object v3 = ((object)((int)(v2)));
        __cil_type_010000F2 v4 = __cil_newobj_0A000476(v1, v3);
        l1 = v4;
        string v5 = __cil_ldstr_70016BB9("Test2");
        string v6 = __cil_ldstr_700248EF("Two");
        __cil_type_010000F2 v7 = __cil_newobj_0A000476(v5, v6);
        l2 = v7;
        int v8 = 2;
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v9 = __cil_newarr_01000018(v8);
        int v10 = 0;
        __cil_type_010000F2 v11 = l1;
        v9[v10] = v11;
        int v12 = 1;
        __cil_type_010000F2 v13 = l2;
        v9[v12] = v13;
        __cil_type_01000023 v14 = __cil_newobj_0A000641(v9);
        l3 = v14;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v15 = l0;
        ref __cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68 v16 = ref v15.changedType;
        v16 = default;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v17 = l0;
        ref __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v18 = ref v17.index;
        v18 = default;
        __cil_type_01000023 v19 = l3;
        __cil_type_0100020D v20 = ((__cil_type_01000154)v19)._collectionChanged;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v21 = l0;
        nint v22 = __cil_ldftn_06001B27;
        __cil_type_0100020D v23 = __cil_newobj_0A000855(v21, v22);
        __cil_type_010001C7 v24 = System.Delegate.Combine(((__cil_type_010001C7)(v20)), ((__cil_type_010001C7)(v23)));
        __cil_type_0100020D v25 = ((__cil_type_0100020D)(object)v24);
        ((__cil_type_01000154)v19)._collectionChanged = v25;
        string v26 = __cil_ldstr_70016BC5("Test3");
        string v27 = __cil_ldstr_7002532B("III");
        __cil_type_010000F2 v28 = __cil_newobj_0A000476(v26, v27);
        l4 = v28;
        __cil_type_01000023 v29 = l3;
        __cil_type_010000F2 v30 = l4;
        v29.Add(((object)(v30)));
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v31 = l0;
        __cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68 v32 = v31.changedType;
        object v33 = ((object)((__cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68)(v32)));
        int v34 = 0;
        object v35 = ((object)((System.Collections.Specialized.NotifyCollectionChangedAction)(v34)));
        NUnit.Framework.Assert.AreEqual(v33, v35);
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v36 = l0;
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v37 = v36.index;
        object v38 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v37)));
        int v39 = 2;
        object v40 = ((object)((int)(v39)));
        NUnit.Framework.Assert.AreEqual(v38, v40);
        __cil_type_010000F2 v41 = l4;
        __cil_type_01000023 v42 = l3;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v43 = l0;
        ref __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v44 = ref v43.index;
        int v45 = __cil_value_call_0A000856(ref v44);
        __cil_type_01000091 v46 = __cil_callvirt_0A000757(v42, v45);
        NUnit.Framework.Assert.AreEqual(((object)(v41)), ((object)(v46)));
        string v47 = __cil_ldstr_70044055("Test4");
        string v48 = __cil_ldstr_70044061("IV");
        __cil_type_010000F2 v49 = __cil_newobj_0A000476(v47, v48);
        l5 = v49;
        __cil_type_01000023 v50 = l3;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v51 = l0;
        ref __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v52 = ref v51.index;
        int v53 = __cil_value_call_0A000856(ref v52);
        __cil_type_010000F2 v54 = l5;
        __cil_callvirt_0A000853(v50, v53, ((__cil_type_01000091)(v54)));
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v55 = l0;
        __cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68 v56 = v55.changedType;
        object v57 = ((object)((__cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68)(v56)));
        int v58 = 2;
        object v59 = ((object)((System.Collections.Specialized.NotifyCollectionChangedAction)(v58)));
        NUnit.Framework.Assert.AreEqual(v57, v59);
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v60 = l0;
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v61 = v60.index;
        object v62 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v61)));
        int v63 = 2;
        object v64 = ((object)((int)(v63)));
        NUnit.Framework.Assert.AreEqual(v62, v64);
        __cil_type_010000F2 v65 = l5;
        __cil_type_01000023 v66 = l3;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v67 = l0;
        ref __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v68 = ref v67.index;
        int v69 = __cil_value_call_0A000856(ref v68);
        __cil_type_01000091 v70 = __cil_callvirt_0A000757(v66, v69);
        NUnit.Framework.Assert.AreEqual(((object)(v65)), ((object)(v70)));
        __cil_type_01000023 v71 = l3;
        __cil_type_010000F2 v72 = l4;
        int v73 = __cil_bool_load(__cil_callvirt_0A00084B(v71, ((__cil_type_01000091)(v72))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v73));
        __cil_type_01000023 v74 = l3;
        __cil_type_010000F2 v75 = l5;
        int v76 = __cil_bool_load(__cil_callvirt_0A00084B(v74, ((__cil_type_01000091)(v75))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v76));
        __cil_type_01000023 v77 = l3;
        string v78 = __cil_ldstr_70016BAD("Test1");
        int v79 = 2;
        __cil_type_01000091 v80 = Newtonsoft.Json.Linq.JToken.op_Implicit(v79);
        __cil_callvirt_0A00046E(v77, v78, v80);
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v81 = l0;
        __cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68 v82 = v81.changedType;
        object v83 = ((object)((__cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68)(v82)));
        int v84 = 2;
        object v85 = ((object)((System.Collections.Specialized.NotifyCollectionChangedAction)(v84)));
        NUnit.Framework.Assert.AreEqual(v83, v85);
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737336395F30 v86 = l0;
        __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v87 = v86.index;
        object v88 = ((object)((__cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391)(v87)));
        int v89 = 0;
        object v90 = ((object)((int)(v89)));
        NUnit.Framework.Assert.AreEqual(v88, v90);
        int v91 = 2;
        object v92 = ((object)((int)(v91)));
        __cil_type_01000023 v93 = l3;
        string v94 = __cil_ldstr_70016BAD("Test1");
        __cil_type_01000091 v95 = __cil_callvirt_0A000473(v93, v94);
        int v96 = Newtonsoft.Json.Linq.JToken.op_Explicit(v95);
        object v97 = ((object)((int)(v96)));
        NUnit.Framework.Assert.AreEqual(v92, v97);
        return;
    }

    public void GetGeocodeAddress()
    {
        string v0 = __cil_ldstr_70044324("{\u000D\u000A  \"name\": \"Address: 435 North Mulford Road Rockford, IL 61107\",\u000D\u000A  \"Status\": {\u000D\u000A    \"code\": 200,\u000D\u000A    \"request\": \"geocode\"\u000D\u000A  },\u000D\u000A  \"Placemark\": [ {\u000D\u000A    \"id\": \"p1\",\u000D\u000A    \"address\": \"435 N Mulford Rd, Rockford, IL 61107, USA\",\u000D\u000A    \"AddressDetails\": {\u000D\u000A   \"Accuracy\" : 8,\u000D\u000A   \"Country\" : {\u000D\u000A      \"AdministrativeArea\" : {\u000D\u000A         \"AdministrativeAreaName\" : \"IL\",\u000D\u000A         \"SubAdministrativeArea\" : {\u000D\u000A            \"Locality\" : {\u000D\u000A               \"LocalityName\" : \"Rockford\",\u000D\u000A               \"PostalCode\" : {\u000D\u000A                  \"PostalCodeNumber\" : \"61107\"\u000D\u000A               },\u000D\u000A               \"Thoroughfare\" : {\u000D\u000A                  \"ThoroughfareName\" : \"435 N Mulford Rd\"\u000D\u000A               }\u000D\u000A            },\u000D\u000A            \"SubAdministrativeAreaName\" : \"Winnebago\"\u000D\u000A         }\u000D\u000A      },\u000D\u000A      \"CountryName\" : \"USA\",\u000D\u000A      \"CountryNameCode\" : \"US\"\u000D\u000A   }\u000D\u000A},\u000D\u000A    \"ExtendedData\": {\u000D\u000A      \"LatLonBox\": {\u000D\u000A        \"north\": 42.2753076,\u000D\u000A        \"south\": 42.2690124,\u000D\u000A        \"east\": -88.9964645,\u000D\u000A        \"west\": -89.0027597\u000D\u000A      }\u000D\u000A    },\u000D\u000A    \"Point\": {\u000D\u000A      \"coordinates\": [ -88.9995886, 42.2721596, 0 ]\u000D\u000A    }\u000D\u000A  } ]\u000D\u000A}");
        __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        string v4 = __cil_ldstr_70044BEB("Placemark");
        __cil_type_01000091 v5 = __cil_callvirt_0A000473(v2, v4);
        object v7 = ((object)((int)(0)));
        __cil_type_01000091 v8 = __cil_callvirt_0A0002D3(v5, v7);
        string v9 = __cil_ldstr_70044BFF("AddressDetails");
        __cil_type_01000091 v10 = __cil_callvirt_0A0002D3(v8, ((object)(v9)));
        string v11 = __cil_ldstr_70044C1D("Country");
        __cil_type_01000091 v12 = __cil_callvirt_0A0002D3(v10, ((object)(v11)));
        string v13 = __cil_ldstr_70044C2D("AdministrativeArea");
        __cil_type_01000091 v14 = __cil_callvirt_0A0002D3(v12, ((object)(v13)));
        string v15 = __cil_ldstr_70044C53("SubAdministrativeArea");
        __cil_type_01000091 v16 = __cil_callvirt_0A0002D3(v14, ((object)(v15)));
        string v17 = __cil_ldstr_70044C7F("Locality");
        __cil_type_01000091 v18 = __cil_callvirt_0A0002D3(v16, ((object)(v17)));
        string v19 = __cil_ldstr_70044C91("Thoroughfare");
        __cil_type_01000091 v20 = __cil_callvirt_0A0002D3(v18, ((object)(v19)));
        string v21 = __cil_ldstr_70044CAB("ThoroughfareName");
        __cil_type_01000091 v22 = __cil_callvirt_0A0002D3(v20, ((object)(v21)));
        string v23 = Newtonsoft.Json.Linq.JToken.op_Explicit(v22);
        string v24 = __cil_ldstr_70044CCD("435 N Mulford Rd");
        NUnit.Framework.Assert.AreEqual(((object)(v24)), ((object)(v23)));
        return;
    }

    public void SetValueWithInvalidPropertyName()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2F;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B1E;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B2F = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044CEF("Set JObject values with invalid key value: 0. Object property name expected.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void SetValue()
    {
        string v0 = __cil_ldstr_70044D8A("TestKey");
        __cil_type_01000023 v1 = __cil_newobj_0A000466();
        long v5 = unchecked((long)(3));
        __cil_type_010000B6 v6 = __cil_newobj_0A000730(v5);
        __cil_callvirt_0A00081C(v1, v0, ((__cil_type_01000091)(v6)));
        object v8 = ((object)((int)(3)));
        __cil_type_01000091 v11 = __cil_callvirt_0A0002D3(v1, v0);
        int v12 = Newtonsoft.Json.Linq.JToken.op_Explicit(v11);
        object v13 = ((object)((int)(v12)));
        NUnit.Framework.Assert.AreEqual(v8, v13);
        return;
    }

    public void ParseMultipleProperties()
    {
        string v0 = __cil_ldstr_70044D9A("{\u000D\u000A        \"Name\": \"Name1\",\u000D\u000A        \"Name\": \"Name2\"\u000D\u000A      }");
        __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        string v4 = __cil_ldstr_70001B27("Name");
        __cil_type_01000091 v5 = __cil_callvirt_0A000473(v2, v4);
        string v6 = Newtonsoft.Json.Linq.JToken.op_Explicit(v5);
        string v7 = __cil_ldstr_70044E16("Name2");
        NUnit.Framework.Assert.AreEqual(((object)(v7)), ((object)(v6)));
        return;
    }

    public void InvalidValueCastExceptionMessage()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B30;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B1F;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B30 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044E22("Can not convert Object to String.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void InvalidPropertyValueCastExceptionMessage()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B31;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B20;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B31 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044E22("Can not convert Object to String.");
        v5[0] = v7;
        global::System.ArgumentException v8 = __cil_methodspec_call_2B000011(s2_0, v5);
        return;
    }

    public void ParseIncomplete()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B32;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B21;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B32 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70044E66("Unexpected end of content while loading JObject. Path 'foo', line 1, position 6.");
        v5[0] = v7;
        global::System.Exception v8 = __cil_methodspec_call_2B000063(s2_0, v5);
        return;
    }

    public void LoadFromNestedObject()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 4
        // .initlocals true
        // .code-bytes IL_0000: [00, 72, 09, 4F, 04, 70, 0A, 06, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 0B, 07, 6F, 72, 01, 00]
        // .code-bytes IL_0018: [0A, 26, 07, 6F, 72, 01, 00, 0A, 26, 07, 6F, 72, 01, 00, 0A, 26, 07, 6F, 72, 01, 00, 0A, 26, 07]
        // .code-bytes IL_0030: [6F, 72, 01, 00, 0A, 26, 07, 28, 6C, 06, 00, 0A, 74, 23, 00, 00, 01, 0C, 08, 28, 78, 01, 00, 0A]
        // .code-bytes IL_0048: [00, 72, D8, 4F, 04, 70, 08, 17, 16, 8D, 24, 00, 00, 01, 6F, 57, 08, 00, 0A, 28, EA, 01, 00, 06]
        // .code-bytes IL_0060: [00, 2A]
        // .local [0] string
        // .local [1] class [Newtonsoft.Json]Newtonsoft.Json.JsonReader
        // .local [2] class [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject
        // IL_0000: nop 
        // IL_0001: ldstr 0x70044F09 [123, 13, 10, 32, 32, 34, 115, 104, 111, 114, 116, 34, 58, 13, 10, 32, 32, 123, 13, 10, 32, 32, 32, 32, 34, 101, 114, 114, 111, 114, 34, 58, 13, 10, 32, 32, 32, 32, 123, 13, 10, 32, 32, 32, 32, 32, 32, 34, 99, 111, 100, 101, 34, 58, 48, 44, 13, 10, 32, 32, 32, 32, 32, 32, 34, 109, 115, 103, 34, 58, 34, 78, 111, 32, 97, 99, 116, 105, 111, 110, 32, 116, 97, 107, 101, 110, 34, 13, 10, 32, 32, 32, 32, 125, 13, 10, 32, 32, 125, 13, 10, 125] utf16-bytes=[7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 22, 00, 73, 00, 68, 00, 6F, 00, 72, 00, 74, 00, 22, 00, 3A, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 22, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 22, 00, 3A, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 20, 00, 20, 00, 22, 00, 63, 00, 6F, 00, 64, 00, 65, 00, 22, 00, 3A, 00, 30, 00, 2C, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 20, 00, 20, 00, 22, 00, 6D, 00, 73, 00, 67, 00, 22, 00, 3A, 00, 22, 00, 4E, 00, 6F, 00, 20, 00, 61, 00, 63, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 74, 00, 61, 00, 6B, 00, 65, 00, 6E, 00, 22, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 7D, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 7D, 00, 0D, 00, 0A, 00, 7D, 00] terminal-flag=Some(0)
        // IL_0006: stloc.0 0
        // IL_0007: ldloc.0 0
        // IL_0008: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_000D: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0012: stloc.1 1
        // IL_0013: ldloc.1 1
        // IL_0014: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0019: pop 
        // IL_001A: ldloc.1 1
        // IL_001B: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0020: pop 
        // IL_0021: ldloc.1 1
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.1 1
        // IL_0029: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_002E: pop 
        // IL_002F: ldloc.1 1
        // IL_0030: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0035: pop 
        // IL_0036: ldloc.1 1
        // IL_0037: call 0x0A00066C [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::ReadFrom
        // IL_003C: castclass 0x01000023 [Newtonsoft.Json]Newtonsoft.Json.Linq.JObject
        // IL_0041: stloc.2 2
        // IL_0042: ldloc.2 2
        // IL_0043: call 0x0A000178 [nunit.framework]NUnit.Framework.Assert::IsNotNull
        // IL_0048: nop 
        // IL_0049: ldstr 0x70044FD8 [123, 13, 10, 32, 32, 34, 99, 111, 100, 101, 34, 58, 32, 48, 44, 13, 10, 32, 32, 34, 109, 115, 103, 34, 58, 32, 34, 78, 111, 32, 97, 99, 116, 105, 111, 110, 32, 116, 97, 107, 101, 110, 34, 13, 10, 125] utf16-bytes=[7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 22, 00, 63, 00, 6F, 00, 64, 00, 65, 00, 22, 00, 3A, 00, 20, 00, 30, 00, 2C, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 22, 00, 6D, 00, 73, 00, 67, 00, 22, 00, 3A, 00, 20, 00, 22, 00, 4E, 00, 6F, 00, 20, 00, 61, 00, 63, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 74, 00, 61, 00, 6B, 00, 65, 00, 6E, 00, 22, 00, 0D, 00, 0A, 00, 7D, 00] terminal-flag=Some(0)
        // IL_004E: ldloc.2 2
        // IL_004F: ldc.i4.1 1
        // IL_0050: ldc.i4.0 0
        // IL_0051: newarr 0x01000024 [Newtonsoft.Json]Newtonsoft.Json.JsonConverter
        // IL_0056: callvirt 0x0A000857 [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::ToString
        // IL_005B: call 0x060001EA Newtonsoft.Json.Tests.StringAssert::AreEqual
        // IL_0060: nop 
        // IL_0061: ret 
    }

    public void LoadFromNestedObjectIncomplete()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B33;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B22;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B33 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_70045036("Unexpected end of content while loading JObject. Path 'short.error.code', line 6, position 14.");
        v5[0] = v7;
        __cil_type_01000031 v8 = __cil_methodspec_call_2B000012(s2_0, v5);
        return;
    }

    public void ParseEmptyObjectWithComment()
    {
        string v0 = __cil_ldstr_700450F5("{ /* A Comment */ }");
        __cil_type_01000023 v1 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        object v3 = ((object)((int)(0)));
        int v5 = ((Newtonsoft.Json.Linq.JContainer)v1).Count;
        object v6 = ((object)((int)(v5)));
        NUnit.Framework.Assert.AreEqual(v3, v6);
        return;
    }

    public void FromObjectTimeSpan()
    {
        // structural signature __cil_value_20479484cdc009da279db2fa36e6745455a3a57e bytes=118171: valuetype [mscorlib]System.TimeSpan; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        double v0 = __cil_ldc_r8_bits(0x3FF0000000000000uL);
        __cil_value_20479484cdc009da279db2fa36e6745455a3a57e v1 = System.TimeSpan.FromDays(unchecked((double)(v0)));
        object v2 = ((object)((__cil_value_20479484cdc009da279db2fa36e6745455a3a57e)(v1)));
        __cil_type_01000091 v3 = Newtonsoft.Json.Linq.JToken.FromObject(v2);
        __cil_type_010000B6 v4 = ((__cil_type_010000B6)(object)v3);
        object v6 = ((Newtonsoft.Json.Linq.JValue)v4).Value;
        double v7 = __cil_ldc_r8_bits(0x3FF0000000000000uL);
        __cil_value_20479484cdc009da279db2fa36e6745455a3a57e v8 = System.TimeSpan.FromDays(unchecked((double)(v7)));
        object v9 = ((object)((__cil_value_20479484cdc009da279db2fa36e6745455a3a57e)(v8)));
        NUnit.Framework.Assert.AreEqual(v6, v9);
        string v10 = __cil_ldstr_700421D4("1.00:00:00");
        string v12 = v4.ToString();
        NUnit.Framework.Assert.AreEqual(((object)(v10)), ((object)(v12)));
        return;
    }

    public void FromObjectUri()
    {
        string v0 = __cil_ldstr_7004511D("http://www.stuff.co.nz");
        __cil_type_010000BD v1 = __cil_newobj_0A00022E(v0);
        __cil_type_01000091 v2 = Newtonsoft.Json.Linq.JToken.FromObject(((object)(v1)));
        __cil_type_010000B6 v3 = ((__cil_type_010000B6)(object)v2);
        object v5 = ((Newtonsoft.Json.Linq.JValue)v3).Value;
        string v6 = __cil_ldstr_7004511D("http://www.stuff.co.nz");
        __cil_type_010000BD v7 = __cil_newobj_0A00022E(v6);
        NUnit.Framework.Assert.AreEqual(v5, ((object)(v7)));
        string v8 = __cil_ldstr_7004514B("http://www.stuff.co.nz/");
        string v10 = v3.ToString();
        NUnit.Framework.Assert.AreEqual(((object)(v8)), ((object)(v10)));
        return;
    }

    public void FromObjectGuid()
    {
        // structural signature __cil_value_c03a715af32b9e508e8998ccad1b81a8fa3fb10a bytes=1180E5: valuetype [mscorlib]System.Guid; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        string v0 = __cil_ldstr_7004517B("9065ACF3-C820-467D-BE50-8D4664BEAF35");
        __cil_value_c03a715af32b9e508e8998ccad1b81a8fa3fb10a v1 = __cil_newobj_0A000126(v0);
        object v2 = ((object)((__cil_value_c03a715af32b9e508e8998ccad1b81a8fa3fb10a)(v1)));
        __cil_type_01000091 v3 = Newtonsoft.Json.Linq.JToken.FromObject(v2);
        __cil_type_010000B6 v4 = ((__cil_type_010000B6)(object)v3);
        object v6 = ((Newtonsoft.Json.Linq.JValue)v4).Value;
        string v7 = __cil_ldstr_7004517B("9065ACF3-C820-467D-BE50-8D4664BEAF35");
        __cil_value_c03a715af32b9e508e8998ccad1b81a8fa3fb10a v8 = __cil_newobj_0A000126(v7);
        object v9 = ((object)((__cil_value_c03a715af32b9e508e8998ccad1b81a8fa3fb10a)(v8)));
        NUnit.Framework.Assert.AreEqual(v6, v9);
        string v10 = __cil_ldstr_700451C5("9065acf3-c820-467d-be50-8d4664beaf35");
        string v12 = v4.ToString();
        NUnit.Framework.Assert.AreEqual(((object)(v10)), ((object)(v12)));
        return;
    }

    public void ParseAdditionalContent()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B34;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E;
        nint v2 = __cil_ldftn_06001B23;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B34 = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(1);
        string v7 = __cil_ldstr_7004520F("Additional text encountered after finished reading JSON content: ,. Path '', line 10, position 1.");
        v5[0] = v7;
        __cil_type_01000031 v8 = __cil_methodspec_call_2B000012(s2_0, v5);
        return;
    }

    public void DeepEqualsIgnoreOrder()
    {
        // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_value_e60002d542b429be31d50a8a202248e380492dd8 bytes=1180A1: valuetype [mscorlib]System.Decimal; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole struct value snapshot/copy, preserving embedded references; no boxing, construction, host layout or address inference.
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v1 = __cil_newarr_01000018(5);
        string v3 = __cil_ldstr_70002D21("null");
        __cil_type_010000F2 v4 = __cil_newobj_0A0007F7(v3, null);
        v1[0] = v4;
        string v6 = __cil_ldstr_700452D4("integer");
        object v8 = ((object)((int)(1)));
        __cil_type_010000F2 v9 = __cil_newobj_0A000476(v6, v8);
        v1[1] = v9;
        string v11 = __cil_ldstr_70005265("string");
        string v12 = __cil_ldstr_70013541("string!");
        __cil_type_010000F2 v13 = __cil_newobj_0A000476(v11, v12);
        v1[2] = v13;
        string v15 = __cil_ldstr_700452E4("decimal");
        __cil_value_e60002d542b429be31d50a8a202248e380492dd8 v21 = __cil_newobj_0A000129(5, 0, 0, 0, 1);
        object v22 = ((object)((__cil_value_e60002d542b429be31d50a8a202248e380492dd8)(v21)));
        __cil_type_010000F2 v23 = __cil_newobj_0A000476(v15, v22);
        v1[3] = v23;
        string v25 = __cil_ldstr_7003BBCE("array");
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v27 = __cil_newarr_01000018(2);
        object v30 = ((object)((int)(1)));
        v27[0] = v30;
        object v33 = ((object)((int)(2)));
        v27[1] = v33;
        __cil_type_0100010B v34 = __cil_newobj_0A0002D0(v27);
        __cil_type_010000F2 v35 = __cil_newobj_0A000476(v25, v34);
        v1[4] = v35;
        __cil_type_01000023 v36 = __cil_newobj_0A000641(v1);
        int v39 = __cil_bool_load(v36.DeepEquals(((__cil_type_01000091)(v36))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v39));
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v41 = __cil_newarr_01000018(5);
        string v43 = __cil_ldstr_70002D21("null");
        __cil_type_010000F2 v44 = __cil_newobj_0A0007F7(v43, null);
        v41[0] = v44;
        string v46 = __cil_ldstr_70005265("string");
        string v47 = __cil_ldstr_70013541("string!");
        __cil_type_010000F2 v48 = __cil_newobj_0A000476(v46, v47);
        v41[1] = v48;
        string v50 = __cil_ldstr_700452E4("decimal");
        __cil_value_e60002d542b429be31d50a8a202248e380492dd8 v56 = __cil_newobj_0A000129(5, 0, 0, 0, 1);
        object v57 = ((object)((__cil_value_e60002d542b429be31d50a8a202248e380492dd8)(v56)));
        __cil_type_010000F2 v58 = __cil_newobj_0A000476(v50, v57);
        v41[2] = v58;
        string v60 = __cil_ldstr_700452D4("integer");
        object v62 = ((object)((int)(1)));
        __cil_type_010000F2 v63 = __cil_newobj_0A000476(v60, v62);
        v41[3] = v63;
        string v65 = __cil_ldstr_7003BBCE("array");
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v67 = __cil_newarr_01000018(2);
        object v70 = ((object)((int)(1)));
        v67[0] = v70;
        object v73 = ((object)((int)(2)));
        v67[1] = v73;
        __cil_type_0100010B v74 = __cil_newobj_0A0002D0(v67);
        __cil_type_010000F2 v75 = __cil_newobj_0A000476(v65, v74);
        v41[4] = v75;
        __cil_type_01000023 v76 = __cil_newobj_0A000641(v41);
        int v79 = __cil_bool_load(v36.DeepEquals(((__cil_type_01000091)(v76))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v79));
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v81 = __cil_newarr_01000018(5);
        string v83 = __cil_ldstr_70002D21("null");
        __cil_type_010000F2 v84 = __cil_newobj_0A0007F7(v83, null);
        v81[0] = v84;
        string v86 = __cil_ldstr_70005265("string");
        string v87 = __cil_ldstr_70013541("string!");
        __cil_type_010000F2 v88 = __cil_newobj_0A000476(v86, v87);
        v81[1] = v88;
        string v90 = __cil_ldstr_700452E4("decimal");
        __cil_value_e60002d542b429be31d50a8a202248e380492dd8 v96 = __cil_newobj_0A000129(5, 0, 0, 0, 1);
        object v97 = ((object)((__cil_value_e60002d542b429be31d50a8a202248e380492dd8)(v96)));
        __cil_type_010000F2 v98 = __cil_newobj_0A000476(v90, v97);
        v81[2] = v98;
        string v100 = __cil_ldstr_700452D4("integer");
        object v102 = ((object)((int)(2)));
        __cil_type_010000F2 v103 = __cil_newobj_0A000476(v100, v102);
        v81[3] = v103;
        string v105 = __cil_ldstr_7003BBCE("array");
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v107 = __cil_newarr_01000018(2);
        object v110 = ((object)((int)(1)));
        v107[0] = v110;
        object v113 = ((object)((int)(2)));
        v107[1] = v113;
        __cil_type_0100010B v114 = __cil_newobj_0A0002D0(v107);
        __cil_type_010000F2 v115 = __cil_newobj_0A000476(v105, v114);
        v81[4] = v115;
        __cil_type_01000023 v116 = __cil_newobj_0A000641(v81);
        int v119 = __cil_bool_load(v36.DeepEquals(((__cil_type_01000091)(v116))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v119));
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v121 = __cil_newarr_01000018(5);
        string v123 = __cil_ldstr_70002D21("null");
        __cil_type_010000F2 v124 = __cil_newobj_0A0007F7(v123, null);
        v121[0] = v124;
        string v126 = __cil_ldstr_70005265("string");
        string v127 = __cil_ldstr_70013541("string!");
        __cil_type_010000F2 v128 = __cil_newobj_0A000476(v126, v127);
        v121[1] = v128;
        string v130 = __cil_ldstr_700452E4("decimal");
        __cil_value_e60002d542b429be31d50a8a202248e380492dd8 v136 = __cil_newobj_0A000129(5, 0, 0, 0, 1);
        object v137 = ((object)((__cil_value_e60002d542b429be31d50a8a202248e380492dd8)(v136)));
        __cil_type_010000F2 v138 = __cil_newobj_0A000476(v130, v137);
        v121[2] = v138;
        string v140 = __cil_ldstr_700452D4("integer");
        object v142 = ((object)((int)(1)));
        __cil_type_010000F2 v143 = __cil_newobj_0A000476(v140, v142);
        v121[3] = v143;
        string v145 = __cil_ldstr_7003BBCE("array");
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v147 = __cil_newarr_01000018(2);
        object v150 = ((object)((int)(2)));
        v147[0] = v150;
        object v153 = ((object)((int)(1)));
        v147[1] = v153;
        __cil_type_0100010B v154 = __cil_newobj_0A0002D0(v147);
        __cil_type_010000F2 v155 = __cil_newobj_0A000476(v145, v154);
        v121[4] = v155;
        __cil_type_01000023 v156 = __cil_newobj_0A000641(v121);
        int v159 = __cil_bool_load(v36.DeepEquals(((__cil_type_01000091)(v156))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v159));
        __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v161 = __cil_newarr_01000018(4);
        string v163 = __cil_ldstr_70002D21("null");
        __cil_type_010000F2 v164 = __cil_newobj_0A0007F7(v163, null);
        v161[0] = v164;
        string v166 = __cil_ldstr_70005265("string");
        string v167 = __cil_ldstr_70013541("string!");
        __cil_type_010000F2 v168 = __cil_newobj_0A000476(v166, v167);
        v161[1] = v168;
        string v170 = __cil_ldstr_700452E4("decimal");
        __cil_value_e60002d542b429be31d50a8a202248e380492dd8 v176 = __cil_newobj_0A000129(5, 0, 0, 0, 1);
        object v177 = ((object)((__cil_value_e60002d542b429be31d50a8a202248e380492dd8)(v176)));
        __cil_type_010000F2 v178 = __cil_newobj_0A000476(v170, v177);
        v161[2] = v178;
        string v180 = __cil_ldstr_700452D4("integer");
        object v182 = ((object)((int)(1)));
        __cil_type_010000F2 v183 = __cil_newobj_0A000476(v180, v182);
        v161[3] = v183;
        __cil_type_01000023 v184 = __cil_newobj_0A000641(v161);
        int v187 = __cil_bool_load(v36.DeepEquals(((__cil_type_01000091)(v184))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v187));
        int v189 = __cil_bool_load(v36.DeepEquals(((__cil_type_01000091)(null))));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v189));
        return;
    }

    public void ToListOnEmptyObject()
    {
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_8a0b9dc6abcd0a9d0509012399513d991e5cb9ce bytes=15127D0115118285020E128245: class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_49cf0cb85330f19b2dd55edd375276573aa12835 bytes=1512814901128245: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_1524a0a3e79a8c5ecb7cf6869c9d65865341ddb7 bytes=151281450115118285020E128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_76538df9184cc157d2f5e1acd9c9a844367c7879 bytes=151281490115118285020E128245: class [mscorlib]System.Collections.Generic.List`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_01000023 l0 = default;
        __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 l1 = default;
        __cil_ref_8a0b9dc6abcd0a9d0509012399513d991e5cb9ce l2 = default;
        string v0 = __cil_ldstr_70004193("{}");
        __cil_type_01000023 v1 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        l0 = v1;
        __cil_type_01000023 v2 = l0;
        __cil_ref_49cf0cb85330f19b2dd55edd375276573aa12835 v3 = __cil_methodspec_call_2B00015A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v2)));
        l1 = v3;
        object v5 = ((object)((int)(0)));
        __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 v6 = l1;
        int v7 = __cil_callvirt_0A000756(v6);
        object v8 = ((object)((int)(v7)));
        NUnit.Framework.Assert.AreEqual(v5, v8);
        __cil_type_01000023 v9 = l0;
        __cil_ref_76538df9184cc157d2f5e1acd9c9a844367c7879 v10 = __cil_methodspec_call_2B00024B(((__cil_ref_1524a0a3e79a8c5ecb7cf6869c9d65865341ddb7)(v9)));
        l2 = v10;
        object v12 = ((object)((int)(0)));
        __cil_ref_8a0b9dc6abcd0a9d0509012399513d991e5cb9ce v13 = l2;
        int v14 = __cil_callvirt_0A000463(v13);
        object v15 = ((object)((int)(v14)));
        NUnit.Framework.Assert.AreEqual(v12, v15);
        string v16 = __cil_ldstr_700452F4("{'hi':null}");
        __cil_type_01000023 v17 = Newtonsoft.Json.Linq.JObject.Parse(v16);
        l0 = v17;
        __cil_type_01000023 v18 = l0;
        __cil_ref_49cf0cb85330f19b2dd55edd375276573aa12835 v19 = __cil_methodspec_call_2B00015A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v18)));
        l1 = v19;
        object v21 = ((object)((int)(1)));
        __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 v22 = l1;
        int v23 = __cil_callvirt_0A000756(v22);
        object v24 = ((object)((int)(v23)));
        NUnit.Framework.Assert.AreEqual(v21, v24);
        __cil_type_01000023 v25 = l0;
        __cil_ref_76538df9184cc157d2f5e1acd9c9a844367c7879 v26 = __cil_methodspec_call_2B00024B(((__cil_ref_1524a0a3e79a8c5ecb7cf6869c9d65865341ddb7)(v25)));
        l2 = v26;
        object v28 = ((object)((int)(1)));
        __cil_ref_8a0b9dc6abcd0a9d0509012399513d991e5cb9ce v29 = l2;
        int v30 = __cil_callvirt_0A000463(v29);
        object v31 = ((object)((int)(v30)));
        NUnit.Framework.Assert.AreEqual(v28, v31);
        return;
    }

    public void EmptyObjectDeepEquals()
    {
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        __cil_type_01000023 v1 = __cil_newobj_0A000466();
        int v2 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.DeepEquals(((__cil_type_01000091)(v0)), ((__cil_type_01000091)(v1))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v2));
        __cil_type_01000023 v3 = __cil_newobj_0A000466();
        __cil_type_01000023 v4 = __cil_newobj_0A000466();
        string v6 = __cil_ldstr_70001E6F("hi");
        string v7 = __cil_ldstr_7004530C("bye");
        __cil_type_01000091 v8 = Newtonsoft.Json.Linq.JToken.op_Implicit(v7);
        v4.Add(v6, v8);
        string v10 = __cil_ldstr_70001E6F("hi");
        int v11 = __cil_bool_load(v4.Remove(v10));
        int v14 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.DeepEquals(((__cil_type_01000091)(v3)), ((__cil_type_01000091)(v4))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v14));
        int v17 = __cil_bool_load(Newtonsoft.Json.Linq.JToken.DeepEquals(((__cil_type_01000091)(v4)), ((__cil_type_01000091)(v3))));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v17));
        return;
    }

    public void GetValueBlogExample()
    {
        // enum storage token=0x0200019A alias=__cil_enum_0200019A underlying=int: global::@System.@StringComparison; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_70045314("{\u000D\u000A        'name': 'Lower',\u000D\u000A        'NAME': 'Upper'\u000D\u000A      }");
        __cil_type_01000023 v1 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        string v3 = __cil_ldstr_70045390("NAME");
        __cil_type_01000091 v5 = v1.GetValue(v3, unchecked((System.StringComparison)(5)));
        string v6 = Newtonsoft.Json.Linq.JToken.op_Explicit(v5);
        string v8 = __cil_ldstr_70001B27("Name");
        __cil_type_01000091 v10 = v1.GetValue(v8, unchecked((System.StringComparison)(5)));
        string v11 = Newtonsoft.Json.Linq.JToken.op_Explicit(v10);
        string v12 = __cil_ldstr_7004539A("Upper");
        NUnit.Framework.Assert.AreEqual(((object)(v12)), ((object)(v6)));
        string v14 = __cil_ldstr_700453A6("Lower");
        NUnit.Framework.Assert.AreEqual(((object)(v14)), ((object)(v11)));
        return;
    }

    public void GetValue()
    {
        // enum storage token=0x0200019A alias=__cil_enum_0200019A underlying=int: global::@System.@StringComparison; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        __cil_type_01000023 l0 = default;
        __cil_type_01000091 l1 = default;
        IL_0000: ;
        __cil_type_01000023 v0 = __cil_newobj_0A000466();
        l0 = v0;
        __cil_type_01000023 v1 = l0;
        string v2 = __cil_ldstr_70001B27("Name");
        string v3 = __cil_ldstr_7000DB80("Name!");
        __cil_type_01000091 v4 = Newtonsoft.Json.Linq.JToken.op_Implicit(v3);
        __cil_callvirt_0A00046E(v1, v2, v4);
        __cil_type_01000023 v5 = l0;
        string v6 = __cil_ldstr_700042B3("name");
        string v7 = __cil_ldstr_70033A33("name!");
        __cil_type_01000091 v8 = Newtonsoft.Json.Linq.JToken.op_Implicit(v7);
        __cil_callvirt_0A00046E(v5, v6, v8);
        __cil_type_01000023 v9 = l0;
        string v10 = __cil_ldstr_70019BAA("title");
        string v11 = __cil_ldstr_700453B2("Title!");
        __cil_type_01000091 v12 = Newtonsoft.Json.Linq.JToken.op_Implicit(v11);
        __cil_callvirt_0A00046E(v9, v10, v12);
        __cil_type_01000023 v13 = l0;
        string v14 = __cil_ldstr_70045390("NAME");
        int v15 = 4;
        __cil_type_01000091 v16 = v13.GetValue(v14, unchecked((System.StringComparison)(v15)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v16)));
        __cil_type_01000023 v17 = l0;
        string v18 = __cil_ldstr_70045390("NAME");
        __cil_type_01000091 v19 = v17.GetValue(v18);
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v19)));
        __cil_type_01000023 v20 = l0;
        string v21 = __cil_ldstr_700453C0("TITLE");
        __cil_type_01000091 v22 = v20.GetValue(v21);
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v22)));
        string v23 = __cil_ldstr_7000DB80("Name!");
        __cil_type_01000023 v24 = l0;
        string v25 = __cil_ldstr_70045390("NAME");
        int v26 = 5;
        __cil_type_01000091 v27 = v24.GetValue(v25, unchecked((System.StringComparison)(v26)));
        string v28 = Newtonsoft.Json.Linq.JToken.op_Explicit(v27);
        NUnit.Framework.Assert.AreEqual(((object)(v23)), ((object)(v28)));
        string v29 = __cil_ldstr_70033A33("name!");
        __cil_type_01000023 v30 = l0;
        string v31 = __cil_ldstr_700042B3("name");
        int v32 = 4;
        __cil_type_01000091 v33 = v30.GetValue(v31, unchecked((System.StringComparison)(v32)));
        string v34 = Newtonsoft.Json.Linq.JToken.op_Explicit(v33);
        NUnit.Framework.Assert.AreEqual(((object)(v29)), ((object)(v34)));
        __cil_type_01000023 v35 = l0;
        int v36 = 4;
        __cil_type_01000091 v37 = v35.GetValue(((string)(null)), unchecked((System.StringComparison)(v36)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v37)));
        __cil_type_01000023 v38 = l0;
        __cil_type_01000091 v39 = v38.GetValue(((string)(null)));
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v39)));
        __cil_type_01000023 v40 = l0;
        string v41 = __cil_ldstr_70045390("NAME");
        int v42 = 4;
        ref __cil_type_01000091 v43 = ref l1;
        int v44 = __cil_bool_load(v40.TryGetValue(v41, unchecked((System.StringComparison)(v42)), ref v43));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v44));
        __cil_type_01000091 v45 = l1;
        NUnit.Framework.Assert.AreEqual(((object)(null)), ((object)(v45)));
        __cil_type_01000023 v46 = l0;
        string v47 = __cil_ldstr_70045390("NAME");
        ref __cil_type_01000091 v48 = ref l1;
        int v49 = __cil_bool_load(v46.TryGetValue(v47, ref v48));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v49));
        __cil_type_01000023 v50 = l0;
        string v51 = __cil_ldstr_700453C0("TITLE");
        ref __cil_type_01000091 v52 = ref l1;
        int v53 = __cil_bool_load(v50.TryGetValue(v51, ref v52));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v53));
        __cil_type_01000023 v54 = l0;
        string v55 = __cil_ldstr_70045390("NAME");
        int v56 = 5;
        ref __cil_type_01000091 v57 = ref l1;
        int v58 = __cil_bool_load(v54.TryGetValue(v55, unchecked((System.StringComparison)(v56)), ref v57));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v58));
        string v59 = __cil_ldstr_7000DB80("Name!");
        __cil_type_01000091 v60 = l1;
        string v61 = Newtonsoft.Json.Linq.JToken.op_Explicit(v60);
        NUnit.Framework.Assert.AreEqual(((object)(v59)), ((object)(v61)));
        __cil_type_01000023 v62 = l0;
        string v63 = __cil_ldstr_700042B3("name");
        int v64 = 4;
        ref __cil_type_01000091 v65 = ref l1;
        int v66 = __cil_bool_load(v62.TryGetValue(v63, unchecked((System.StringComparison)(v64)), ref v65));
        NUnit.Framework.Assert.IsTrue(__cil_bool_store(v66));
        string v67 = __cil_ldstr_70033A33("name!");
        __cil_type_01000091 v68 = l1;
        string v69 = Newtonsoft.Json.Linq.JToken.op_Explicit(v68);
        NUnit.Framework.Assert.AreEqual(((object)(v67)), ((object)(v69)));
        __cil_type_01000023 v70 = l0;
        int v71 = 4;
        ref __cil_type_01000091 v72 = ref l1;
        int v73 = __cil_bool_load(v70.TryGetValue(((string)(null)), unchecked((System.StringComparison)(v71)), ref v72));
        NUnit.Framework.Assert.IsFalse(__cil_bool_store(v73));
        return;
    }

    public void FromObjectInsideConverterWithCustomSerializer()
    {
        // structural signature __cil_ref_dfa758fd79771e71f94f6eae4d619082ce83c71f bytes=1512814901128091: class [mscorlib]System.Collections.Generic.List`1<class [Newtonsoft.Json]Newtonsoft.Json.JsonConverter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // structural signature __cil_ref_cb77ce36cae9ee3c15c8151621020d6ffdb592cd bytes=15127D01128091: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.JsonConverter>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::Newtonsoft.Json.Tests.TestObjects.Organization.Person v0 = __cil_newobj_0600088A();
        string v1 = __cil_ldstr_700453CC("Daniel Wertheim");
        __cil_callvirt_06000883(v0, v1);
        __cil_type_0100004E v2 = __cil_newobj_0A0000C1();
        __cil_ref_dfa758fd79771e71f94f6eae4d619082ce83c71f v3 = __cil_newobj_0A0004DC();
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.FooJsonConverter v4 = __cil_newobj_06001B0B();
        __cil_callvirt_0A0004DD(v3, ((__cil_type_01000024)(v4)));
        __cil_callvirt_0A0004DE(v2, ((__cil_ref_cb77ce36cae9ee3c15c8151621020d6ffdb592cd)(v3)));
        __cil_type_010000FC v5 = __cil_newobj_0A0003F3();
        ((Newtonsoft.Json.JsonSerializerSettings)v2).ContractResolver = ((__cil_type_01000103)(v5));
        string v8 = Newtonsoft.Json.JsonConvert.SerializeObject(((object)(v0)), v2);
        string v9 = __cil_ldstr_700453EC("{\"foo\":\"bar\",\"name\":\"Daniel Wertheim\",\"birthDate\":\"0001-01-01T00:00:00\",\"lastModified\":\"0001-01-01T00:00:00\"}");
        NUnit.Framework.Assert.AreEqual(((object)(v9)), ((object)(v8)));
        return;
    }

    public void Parse_NoComments()
    {
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        // enum storage token=0x020000AB alias=__cil_enum_020000AB underlying=int: global::@Newtonsoft.@Json.@Linq.@CommentHandling; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
        string v0 = __cil_ldstr_700454C9("{'prop':[1,2/*comment*/,3]}");
        __cil_type_0100016F v2 = __cil_newobj_0A00081E();
        ((Newtonsoft.Json.Linq.JsonLoadSettings)v2).CommentHandling = unchecked((Newtonsoft.Json.Linq.CommentHandling)(0));
        __cil_type_01000023 v4 = Newtonsoft.Json.Linq.JObject.Parse(v0, v2);
        object v6 = ((object)((int)(3)));
        string v8 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v9 = __cil_callvirt_0A000473(v4, v8);
        int v10 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v9)));
        object v11 = ((object)((int)(v10)));
        NUnit.Framework.Assert.AreEqual(v6, v11);
        object v13 = ((object)((int)(1)));
        string v15 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v16 = __cil_callvirt_0A000473(v4, v15);
        object v18 = ((object)((int)(0)));
        __cil_type_01000091 v19 = __cil_callvirt_0A0002D3(v16, v18);
        int v20 = Newtonsoft.Json.Linq.JToken.op_Explicit(v19);
        object v21 = ((object)((int)(v20)));
        NUnit.Framework.Assert.AreEqual(v13, v21);
        object v23 = ((object)((int)(2)));
        string v25 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v26 = __cil_callvirt_0A000473(v4, v25);
        object v28 = ((object)((int)(1)));
        __cil_type_01000091 v29 = __cil_callvirt_0A0002D3(v26, v28);
        int v30 = Newtonsoft.Json.Linq.JToken.op_Explicit(v29);
        object v31 = ((object)((int)(v30)));
        NUnit.Framework.Assert.AreEqual(v23, v31);
        object v33 = ((object)((int)(3)));
        string v35 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v36 = __cil_callvirt_0A000473(v4, v35);
        object v38 = ((object)((int)(2)));
        __cil_type_01000091 v39 = __cil_callvirt_0A0002D3(v36, v38);
        int v40 = Newtonsoft.Json.Linq.JToken.op_Explicit(v39);
        object v41 = ((object)((int)(v40)));
        NUnit.Framework.Assert.AreEqual(v33, v41);
        return;
    }

    public void Parse_ExcessiveContentJustComments()
    {
        // structural signature __cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f bytes=1512814501128245: class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        string v0 = __cil_ldstr_70045501("{'prop':[1,2,3]}/*comment*/\u000D\u000A//Another comment.");
        __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
        object v4 = ((object)((int)(3)));
        string v6 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v7 = __cil_callvirt_0A000473(v2, v6);
        int v8 = __cil_methodspec_call_2B00011A(((__cil_ref_390390ee1b4b13bca8639ba6af51693416319b0f)(v7)));
        object v9 = ((object)((int)(v8)));
        NUnit.Framework.Assert.AreEqual(v4, v9);
        object v11 = ((object)((int)(1)));
        string v13 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v14 = __cil_callvirt_0A000473(v2, v13);
        object v16 = ((object)((int)(0)));
        __cil_type_01000091 v17 = __cil_callvirt_0A0002D3(v14, v16);
        int v18 = Newtonsoft.Json.Linq.JToken.op_Explicit(v17);
        object v19 = ((object)((int)(v18)));
        NUnit.Framework.Assert.AreEqual(v11, v19);
        object v21 = ((object)((int)(2)));
        string v23 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v24 = __cil_callvirt_0A000473(v2, v23);
        object v26 = ((object)((int)(1)));
        __cil_type_01000091 v27 = __cil_callvirt_0A0002D3(v24, v26);
        int v28 = Newtonsoft.Json.Linq.JToken.op_Explicit(v27);
        object v29 = ((object)((int)(v28)));
        NUnit.Framework.Assert.AreEqual(v21, v29);
        object v31 = ((object)((int)(3)));
        string v33 = __cil_ldstr_70004283("prop");
        __cil_type_01000091 v34 = __cil_callvirt_0A000473(v2, v33);
        object v36 = ((object)((int)(2)));
        __cil_type_01000091 v37 = __cil_callvirt_0A0002D3(v34, v36);
        int v38 = Newtonsoft.Json.Linq.JToken.op_Explicit(v37);
        object v39 = ((object)((int)(v38)));
        NUnit.Framework.Assert.AreEqual(v31, v39);
        return;
    }

    public void Parse_ExcessiveContent()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737339335F30 v0 = __cil_newobj_06001B28();
        string v2 = __cil_ldstr_70045561("{'prop':[1,2,3]}/*comment*/\u000D\u000A//Another comment.\u000D\u000A[]");
        v0.json = v2;
        nint v4 = __cil_ldftn_06001B29;
        __cil_type_0100005D v5 = __cil_newobj_0A000108(v0, v4);
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v7 = __cil_newarr_01000181(1);
        string v9 = __cil_ldstr_7004303E("Additional text encountered after finished reading JSON content: [. Path '', line 3, position 0.");
        v7[0] = v9;
        __cil_type_01000031 v10 = __cil_methodspec_call_2B000012(v5, v7);
        return;
    }

    public JObjectTests() : base()
    {
        return;
    }

    public class FooJsonConverter : Newtonsoft.Json.JsonConverter
    {
        public override void WriteJson(Newtonsoft.Json.JsonWriter writer, object value, Newtonsoft.Json.JsonSerializer serializer)
        {
            // structural signature __cil_ref_ddc89dbc81b64ef04d719c23ad5adc75088b833a bytes=1D128091: class [Newtonsoft.Json]Newtonsoft.Json.JsonConverter[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // enum storage token=0x020000BC alias=__cil_enum_020000BC underlying=int: global::@Newtonsoft.@Json.@Linq.@JTokenType; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            __cil_type_01000091 l0 = default;
            bool l1 = default;
            __cil_type_01000026 v1 = __cil_newobj_0A000112();
            __cil_type_010000FC v2 = __cil_newobj_0A0003F3();
            ((Newtonsoft.Json.JsonSerializer)v1).ContractResolver = ((__cil_type_01000103)(v2));
            __cil_type_01000091 v3 = Newtonsoft.Json.Linq.JToken.FromObject(value, v1);
            l0 = v3;
            __cil_type_01000091 v4 = l0;
            int v5 = unchecked((int)(((Newtonsoft.Json.Linq.JToken)v4).Type));
            int v7 = (v5 == 1 ? 1 : 0);
            l1 = __cil_bool_store(v7);
            int v8 = __cil_bool_load(l1);
            if (v8 == 0) {
                goto IL_0055;
            } else {
                goto IL_0026;
            }
            IL_0026: ;
            __cil_type_01000091 v9 = l0;
            __cil_type_01000023 v10 = ((__cil_type_01000023)(object)v9);
            string v12 = __cil_ldstr_70003BE7("foo");
            string v13 = __cil_ldstr_7000D19F("bar");
            __cil_type_010000F2 v14 = __cil_newobj_0A000476(v12, v13);
            v10.AddFirst(((object)(v14)));
            __cil_ref_ddc89dbc81b64ef04d719c23ad5adc75088b833a v18 = __cil_newarr_01000024(0);
            v10.WriteTo(writer, v18);
            goto IL_0065;
            IL_0055: ;
            __cil_type_01000091 v19 = l0;
            __cil_ref_ddc89dbc81b64ef04d719c23ad5adc75088b833a v22 = __cil_newarr_01000024(0);
            v19.WriteTo(writer, v22);
            IL_0065: ;
            return;
        }

        public override object ReadJson(Newtonsoft.Json.JsonReader reader, System.Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer)
        {
            string v0 = __cil_ldstr_7007583B("This custom converter only supportes serialization and not deserialization.");
            global::System.NotSupportedException v1 = __cil_newobj_0A000B86(v0);
            throw v1;
        }

        public override bool get_CanRead()
        {
            bool l0 = default;
            l0 = __cil_bool_store(0);
            return l0;
        }

        public override bool CanConvert(System.Type objectType)
        {
            bool l0 = default;
            l0 = __cil_bool_store(1);
            return l0;
        }

        public FooJsonConverter() : base()
        {
            return;
        }
        // property bool CanRead { get: get_CanRead; }
    }

    private static class __name_3C3E6F5F5F30
    {
        public static System.Runtime.CompilerServices.CallSite<System.Func<System.Runtime.CompilerServices.CallSite, object, object>> __il_field_04000B1A;
        public static System.Runtime.CompilerServices.CallSite<System.Func<System.Runtime.CompilerServices.CallSite, object, string>> __il_field_04000B1B;
        public static System.Runtime.CompilerServices.CallSite<System.Func<System.Runtime.CompilerServices.CallSite, object, object>> __il_field_04000B1C;
        public static System.Runtime.CompilerServices.CallSite<System.Func<System.Runtime.CompilerServices.CallSite, object, string>> __il_field_04000B1D;
    }

    private sealed class __name_3C3E63
    {
        public static readonly Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 __il_field_04000B1E;
        public static System.Action __il_field_04000B1F;
        public static System.Action __il_field_04000B20;
        public static System.Action __il_field_04000B21;
        public static System.Action __il_field_04000B22;
        public static System.Action __il_field_04000B23;
        public static System.Action __il_field_04000B24;
        public static System.Action __il_field_04000B25;
        public static System.Action __il_field_04000B26;
        public static System.Action __il_field_04000B27;
        public static System.Action __il_field_04000B28;
        public static System.Action __il_field_04000B29;
        public static System.Action __il_field_04000B2A;
        public static System.Action __il_field_04000B2B;
        public static System.Action __il_field_04000B2C;
        public static System.Action __il_field_04000B2D;
        public static System.Action __il_field_04000B2E;
        public static System.Action __il_field_04000B2F;
        public static System.Action __il_field_04000B30;
        public static System.Action __il_field_04000B31;
        public static System.Action __il_field_04000B32;
        public static System.Action __il_field_04000B33;
        public static System.Action __il_field_04000B34;

        static __name_3C3E63()
        {
            global::Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63 v0 = __cil_newobj_06001B0D();
            Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E63.__il_field_04000B1E = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <DuplicatePropertyNameShouldThrow>b__9_0
        internal void DuplicatePropertyNameShouldThrowLambda9_0()
        {
            __cil_type_01000023 v0 = __cil_newobj_0A000466();
            string v2 = __cil_ldstr_7004357F("PropertyNameValue");
            v0.Add(v2, ((__cil_type_01000091)(null)));
            string v4 = __cil_ldstr_7004357F("PropertyNameValue");
            v0.Add(v4, ((__cil_type_01000091)(null)));
            return;
        }

        // Metadata name: <GenericCollectionCopyToNullArrayShouldThrow>b__16_0
        internal void GenericCollectionCopyToNullArrayShouldThrowLambda16_0()
        {
            // structural signature __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 bytes=1D15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000023 v0 = __cil_newobj_0A000466();
            __cil_callvirt_0A000839(v0, ((__cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07)(null)), 0);
            return;
        }

        // Metadata name: <GenericCollectionCopyToNegativeArrayIndexShouldThrow>b__17_0
        internal void GenericCollectionCopyToNegativeArrayIndexShouldThrowLambda17_0()
        {
            // structural signature __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 bytes=1D15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000023 v0 = __cil_newobj_0A000466();
            __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v3 = __cil_newarr_1B000149(1);
            __cil_callvirt_0A000839(v0, v3, -1);
            return;
        }

        // Metadata name: <GenericCollectionCopyToArrayIndexEqualGreaterToArrayLengthShouldThrow>b__18_0
        internal void GenericCollectionCopyToArrayIndexEqualGreaterToArrayLengthShouldThrowLambda18_0()
        {
            // structural signature __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 bytes=1D15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000023 v0 = __cil_newobj_0A000466();
            __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v3 = __cil_newarr_1B000149(1);
            __cil_callvirt_0A000839(v0, v3, 1);
            return;
        }

        // Metadata name: <GenericCollectionCopyToInsufficientArrayCapacity>b__19_0
        internal void GenericCollectionCopyToInsufficientArrayCapacityLambda19_0()
        {
            // structural signature __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 bytes=1D15118285020E128245: valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string, class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000023 v0 = __cil_newobj_0A000466();
            string v2 = __cil_ldstr_7004357F("PropertyNameValue");
            long v4 = unchecked((long)(1));
            __cil_type_010000B6 v5 = __cil_newobj_0A000730(v4);
            v0.Add(v2, ((__cil_type_01000091)(v5)));
            string v7 = __cil_ldstr_700436CE("PropertyNameValue2");
            long v9 = unchecked((long)(2));
            __cil_type_010000B6 v10 = __cil_newobj_0A000730(v9);
            v0.Add(v7, ((__cil_type_01000091)(v10)));
            string v12 = __cil_ldstr_700436F4("PropertyNameValue3");
            long v14 = unchecked((long)(3));
            __cil_type_010000B6 v15 = __cil_newobj_0A000730(v14);
            v0.Add(v12, ((__cil_type_01000091)(v15)));
            __cil_ref_6ff9785b50e9de084be8fed6eb5213ac098f2b07 v18 = __cil_newarr_1B000149(3);
            __cil_callvirt_0A000839(v0, v18, 1);
            return;
        }

        // Metadata name: <Parse_ShouldThrowOnUnexpectedToken>b__23_0
        internal void Parse_ShouldThrowOnUnexpectedTokenLambda23_0()
        {
            string v0 = __cil_ldstr_700758D4("[\"prop\"]");
            __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
            return;
        }

        // Metadata name: <Blog>b__26_0
        internal void BlogLambda26_0()
        {
            string v0 = __cil_ldstr_700758E6("{\u000D\u000A    \"name\": \"James\",\u000D\u000A    ]!#$THIS IS: BAD JSON![{}}}}]\u000D\u000A  }");
            __cil_type_01000023 v1 = Newtonsoft.Json.Linq.JObject.Parse(v0);
            return;
        }

        // Metadata name: <IListAddBadToken>b__42_0
        internal void IListAddBadTokenLambda42_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v15 = __cil_ldstr_70075966("Bad!");
            __cil_type_010000B6 v16 = __cil_newobj_0A0005C2(v15);
            int v17 = __cil_callvirt_0A000842(v13, ((object)(v16)));
            return;
        }

        // Metadata name: <IListAddBadValue>b__43_0
        internal void IListAddBadValueLambda43_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v15 = __cil_ldstr_70075966("Bad!");
            int v16 = __cil_callvirt_0A000842(v13, ((object)(v15)));
            return;
        }

        // Metadata name: <IListAddPropertyWithExistingName>b__44_0
        internal void IListAddPropertyWithExistingNameLambda44_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v14 = __cil_ldstr_70016BB9("Test2");
            string v15 = __cil_ldstr_70010AB0("II");
            __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
            int v19 = __cil_callvirt_0A000842(v13, ((object)(v16)));
            return;
        }

        // Metadata name: <IListSetItemAlreadyExists>b__51_0
        internal void IListSetItemAlreadyExistsLambda51_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v14 = __cil_ldstr_70016BC5("Test3");
            string v15 = __cil_ldstr_7002532B("III");
            __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
            __cil_callvirt_0A000848(v13, 0, ((object)(v16)));
            __cil_callvirt_0A000848(v13, 1, ((object)(v16)));
            return;
        }

        // Metadata name: <IListSetItemInvalid>b__52_0
        internal void IListSetItemInvalidLambda52_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            __cil_type_010000B6 v17 = __cil_newobj_0A0007D3(1);
            __cil_callvirt_0A000848(v13, 0, ((object)(v17)));
            return;
        }

        // Metadata name: <GenericListJTokenAddBadToken>b__60_0
        internal void GenericListJTokenAddBadTokenLambda60_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v15 = __cil_ldstr_70075966("Bad!");
            __cil_type_010000B6 v16 = __cil_newobj_0A0005C2(v15);
            __cil_callvirt_0A00084E(v13, ((__cil_type_01000091)(v16)));
            return;
        }

        // Metadata name: <GenericListJTokenAddBadValue>b__61_0
        internal void GenericListJTokenAddBadValueLambda61_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v15 = __cil_ldstr_70075966("Bad!");
            __cil_type_01000091 v16 = Newtonsoft.Json.Linq.JToken.op_Implicit(v15);
            __cil_callvirt_0A00084E(v13, v16);
            return;
        }

        // Metadata name: <GenericListJTokenAddPropertyWithExistingName>b__62_0
        internal void GenericListJTokenAddPropertyWithExistingNameLambda62_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v14 = __cil_ldstr_70016BB9("Test2");
            string v15 = __cil_ldstr_70010AB0("II");
            __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
            __cil_callvirt_0A00084E(v13, ((__cil_type_01000091)(v16)));
            return;
        }

        // Metadata name: <GenericListJTokenSetItemAlreadyExists>b__68_0
        internal void GenericListJTokenSetItemAlreadyExistsLambda68_0()
        {
            // structural signature __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff bytes=1D1C: object[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            // structural signature __cil_ref_ab9a576fc2e3f48027863613cb079d850e810958 bytes=15127D01128245: class [mscorlib]System.Collections.Generic.IList`1<class [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            string v0 = __cil_ldstr_70016BAD("Test1");
            object v2 = ((object)((int)(1)));
            __cil_type_010000F2 v3 = __cil_newobj_0A000476(v0, v2);
            string v4 = __cil_ldstr_70016BB9("Test2");
            string v5 = __cil_ldstr_700248EF("Two");
            __cil_type_010000F2 v6 = __cil_newobj_0A000476(v4, v5);
            __cil_ref_e7eaa865b7f517eaa2bf5136f52c92b364a1d1ff v8 = __cil_newarr_01000018(2);
            v8[0] = v3;
            v8[1] = v6;
            __cil_type_01000023 v13 = __cil_newobj_0A000641(v8);
            string v14 = __cil_ldstr_70016BC5("Test3");
            string v15 = __cil_ldstr_7002532B("III");
            __cil_type_010000F2 v16 = __cil_newobj_0A000476(v14, v15);
            __cil_callvirt_0A000853(v13, 0, ((__cil_type_01000091)(v16)));
            __cil_callvirt_0A000853(v13, 1, ((__cil_type_01000091)(v16)));
            return;
        }

        // Metadata name: <SetValueWithInvalidPropertyName>b__71_0
        internal void SetValueWithInvalidPropertyNameLambda71_0()
        {
            __cil_type_01000023 v0 = __cil_newobj_0A000466();
            object v3 = ((object)((int)(0)));
            long v5 = unchecked((long)(3));
            __cil_type_010000B6 v6 = __cil_newobj_0A000730(v5);
            __cil_callvirt_0A00081C(v0, v3, ((__cil_type_01000091)(v6)));
            return;
        }

        // Metadata name: <InvalidValueCastExceptionMessage>b__74_0
        internal void InvalidValueCastExceptionMessageLambda74_0()
        {
            string v0 = __cil_ldstr_70075970("{\u000D\u000A  \"responseData\": {}, \u000D\u000A  \"responseDetails\": null, \u000D\u000A  \"responseStatus\": 200\u000D\u000A}");
            __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
            string v4 = __cil_ldstr_70023E09("responseData");
            __cil_type_01000091 v5 = __cil_callvirt_0A000473(v2, v4);
            string v6 = Newtonsoft.Json.Linq.JToken.op_Explicit(v5);
            return;
        }

        // Metadata name: <InvalidPropertyValueCastExceptionMessage>b__75_0
        internal void InvalidPropertyValueCastExceptionMessageLambda75_0()
        {
            string v0 = __cil_ldstr_70075970("{\u000D\u000A  \"responseData\": {}, \u000D\u000A  \"responseDetails\": null, \u000D\u000A  \"responseStatus\": 200\u000D\u000A}");
            __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
            string v4 = __cil_ldstr_70023E09("responseData");
            __cil_type_010000F2 v5 = v2.Property(v4);
            string v6 = Newtonsoft.Json.Linq.JToken.op_Explicit(((__cil_type_01000091)(v5)));
            return;
        }

        // Metadata name: <ParseIncomplete>b__76_0
        internal void ParseIncompleteLambda76_0()
        {
            string v0 = __cil_ldstr_70075A17("{ foo:");
            __cil_type_01000023 v1 = Newtonsoft.Json.Linq.JObject.Parse(v0);
            return;
        }

        // Metadata name: <LoadFromNestedObjectIncomplete>b__78_0
        internal void LoadFromNestedObjectIncompleteLambda78_0()
        {
            // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
            // .maxstack 1
            // .initlocals true
            // .code-bytes IL_0000: [00, 72, 25, 5A, 07, 70, 0A, 06, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 0B, 07, 6F, 72, 01, 00]
            // .code-bytes IL_0018: [0A, 26, 07, 6F, 72, 01, 00, 0A, 26, 07, 6F, 72, 01, 00, 0A, 26, 07, 6F, 72, 01, 00, 0A, 26, 07]
            // .code-bytes IL_0030: [6F, 72, 01, 00, 0A, 26, 07, 28, 6C, 06, 00, 0A, 26, 2A]
            // .local [0] string
            // .local [1] class [Newtonsoft.Json]Newtonsoft.Json.JsonReader
            // IL_0000: nop 
            // IL_0001: ldstr 0x70075A25 [123, 13, 10, 32, 32, 34, 115, 104, 111, 114, 116, 34, 58, 13, 10, 32, 32, 123, 13, 10, 32, 32, 32, 32, 34, 101, 114, 114, 111, 114, 34, 58, 13, 10, 32, 32, 32, 32, 123, 13, 10, 32, 32, 32, 32, 32, 32, 34, 99, 111, 100, 101, 34, 58, 48] utf16-bytes=[7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 22, 00, 73, 00, 68, 00, 6F, 00, 72, 00, 74, 00, 22, 00, 3A, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 22, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 22, 00, 3A, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 20, 00, 20, 00, 22, 00, 63, 00, 6F, 00, 64, 00, 65, 00, 22, 00, 3A, 00, 30, 00] terminal-flag=Some(0)
            // IL_0006: stloc.0 0
            // IL_0007: ldloc.0 0
            // IL_0008: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
            // IL_000D: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
            // IL_0012: stloc.1 1
            // IL_0013: ldloc.1 1
            // IL_0014: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
            // IL_0019: pop 
            // IL_001A: ldloc.1 1
            // IL_001B: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
            // IL_0020: pop 
            // IL_0021: ldloc.1 1
            // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
            // IL_0027: pop 
            // IL_0028: ldloc.1 1
            // IL_0029: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
            // IL_002E: pop 
            // IL_002F: ldloc.1 1
            // IL_0030: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
            // IL_0035: pop 
            // IL_0036: ldloc.1 1
            // IL_0037: call 0x0A00066C [Newtonsoft.Json]Newtonsoft.Json.Linq.JToken::ReadFrom
            // IL_003C: pop 
            // IL_003D: ret 
        }

        // Metadata name: <ParseAdditionalContent>b__83_0
        internal void ParseAdditionalContentLambda83_0()
        {
            string v0 = __cil_ldstr_70075A95("{\u000D\u000A\"Name\": \"Apple\",\u000D\u000A\"Expiry\": new Date(1230422400000),\u000D\u000A\"Price\": 3.99,\u000D\u000A\"Sizes\": [\u000D\u000A\"Small\",\u000D\u000A\"Medium\",\u000D\u000A\"Large\"\u000D\u000A]\u000D\u000A}, 987987");
            __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v0);
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333365F30
    {
        public object changed;
        public int changedCount;

        public __name_3C3E635F5F446973706C6179436C61737333365F30() : base()
        {
            return;
        }

        // Metadata name: <PropertyChanged>b__0
        internal void PropertyChangedLambda0(object sender, System.ComponentModel.PropertyChangedEventArgs args)
        {
            __cil_type_01000023 l0 = default;
            Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 s1_0 = default;
            Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 s2_0 = default;
            Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 s3_0 = default;
            object s3_1 = default;
            __cil_type_01000023 v1 = ((__cil_type_01000023)(object)sender);
            l0 = v1;
            __cil_type_01000023 v3 = l0;
            string v5 = __cil_callvirt_0A000B73(args);
            __cil_type_01000091 v6 = __cil_callvirt_0A000473(v3, v5);
            if (v6 is not null) {
                Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 e0_2_0 = this;
                s2_0 = e0_2_0;
                goto IL_001A;
            } else {
                Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 e0_1_0 = this;
                s1_0 = e0_1_0;
                goto IL_0017;
            }
            IL_0017: ;
            Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 e1_3_0 = s1_0;
            object e1_3_1 = null;
            s3_0 = e1_3_0;
            s3_1 = e1_3_1;
            goto IL_0030;
            IL_001A: ;
            __cil_type_01000023 v7 = l0;
            string v9 = __cil_callvirt_0A000B73(args);
            __cil_type_01000091 v10 = __cil_callvirt_0A000473(v7, v9);
            __cil_type_010000B6 v11 = ((__cil_type_010000B6)(object)v10);
            object v12 = ((Newtonsoft.Json.Linq.JValue)v11).Value;
            Newtonsoft.Json.Tests.Linq.JObjectTests.__name_3C3E635F5F446973706C6179436C61737333365F30 e2_3_0 = s2_0;
            object e2_3_1 = v12;
            s3_0 = e2_3_0;
            s3_1 = e2_3_1;
            IL_0030: ;
            s3_0.changed = s3_1;
            int v14 = this.changedCount;
            this.changedCount = unchecked(v14 + 1);
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336395F30
    {
        public System.Nullable<System.Collections.Specialized.NotifyCollectionChangedAction> changedType;
        public System.Nullable<int> index;

        public __name_3C3E635F5F446973706C6179436C61737336395F30() : base()
        {
            return;
        }

        // Metadata name: <CollectionChanged>b__0
        internal void CollectionChangedLambda0(object s, System.Collections.Specialized.NotifyCollectionChangedEventArgs a)
        {
            // structural signature __cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68 bytes=1511811501118541: valuetype [mscorlib]System.Nullable`1<valuetype [System]System.Collections.Specialized.NotifyCollectionChangedAction>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            // enum storage token=0x0200001A alias=__cil_enum_0200001A underlying=int: global::@System.@Collections.@Specialized.@NotifyCollectionChangedAction; exact input-scoped value type; loads normalize to CLI integer stack bits and stores truncate to the declared width.
            int v2 = unchecked((int)(__cil_callvirt_0A000B87(a)));
            __cil_value_119f97b29fa5b403c93f45e6059e14507be1ea68 v3 = __cil_value_newobj_0A000B88(unchecked((System.Collections.Specialized.NotifyCollectionChangedAction)(v2)));
            this.changedType = v3;
            int v6 = __cil_callvirt_0A000B89(a);
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v7 = __cil_value_newobj_0A0001F6(v6);
            this.index = v7;
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737339335F30
    {
        public string json;

        public __name_3C3E635F5F446973706C6179436C61737339335F30() : base()
        {
            return;
        }

        // Metadata name: <Parse_ExcessiveContent>b__0
        internal void Parse_ExcessiveContentLambda0()
        {
            string v1 = this.json;
            __cil_type_01000023 v2 = Newtonsoft.Json.Linq.JObject.Parse(v1);
            return;
        }
    }
}

// Dependency identity substituted: System.Data.DataSetExtensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0 -> System.Data.DataSetExtensions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.CSharp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency unresolved: System.Data.Entity, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; reference identity retained.

// Dependency unresolved: System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, ContentType=0x0; reference identity retained.

// Dependency unresolved: System.Data.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; reference identity retained.
