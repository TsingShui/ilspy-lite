using System;
using System.Globalization;
using System.IO;
using System.Text;
using NUnit.Framework;
using Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests;

namespace Newtonsoft.Json.Tests.JsonTextReaderTests;

[TestFixture]
[Category("JsonTextReaderTests")]
public class ExceptionHandlingTests : TestFixtureBase
{
	[Test]
	public void ReadAsBytes_MissingComma()
	{
		byte[] bytes = Encoding.UTF8.GetBytes("Hello world");
		string s = "['" + Convert.ToBase64String(bytes) + "' '" + Convert.ToBase64String(bytes) + "']";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(reader.Read());
		CollectionAssert.AreEquivalent(bytes, reader.ReadAsBytes());
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "After parsing a value an unexpected character was encountered: '. Path '[0]', line 1, position 20." });
	}

	[Test]
	public void ReadAsInt32_MissingComma()
	{
		string s = "[0 1 2]";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(0, reader.ReadAsInt32().Value);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsInt32();
		}, new string[1] { "After parsing a value an unexpected character was encountered: 1. Path '[0]', line 1, position 3." });
	}

	[Test]
	public void ReadAsBoolean_MissingComma()
	{
		string s = "[true false true]";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(true, reader.ReadAsBoolean().Value);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBoolean();
		}, new string[1] { "After parsing a value an unexpected character was encountered: f. Path '[0]', line 1, position 6." });
	}

	[Test]
	public void ReadAsDateTime_MissingComma()
	{
		string s = "['2017-02-04T00:00:00Z' '2018-02-04T00:00:00Z' '2019-02-04T00:00:00Z']";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(new DateTime(2017, 2, 4, 0, 0, 0, DateTimeKind.Utc), reader.ReadAsDateTime().Value);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTime();
		}, new string[1] { "After parsing a value an unexpected character was encountered: '. Path '[0]', line 1, position 24." });
	}

	[Test]
	public void ReadAsDateTimeOffset_MissingComma()
	{
		string s = "['2017-02-04T00:00:00Z' '2018-02-04T00:00:00Z' '2019-02-04T00:00:00Z']";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(new DateTimeOffset(2017, 2, 4, 0, 0, 0, TimeSpan.Zero), reader.ReadAsDateTimeOffset().Value);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTimeOffset();
		}, new string[1] { "After parsing a value an unexpected character was encountered: '. Path '[0]', line 1, position 24." });
	}

	[Test]
	public void ReadAsString_MissingComma()
	{
		string s = "['2017-02-04T00:00:00Z' '2018-02-04T00:00:00Z' '2019-02-04T00:00:00Z']";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(reader.Read());
		Assert.AreEqual("2017-02-04T00:00:00Z", reader.ReadAsString());
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "After parsing a value an unexpected character was encountered: '. Path '[0]', line 1, position 24." });
	}

	[Test]
	public void Read_MissingComma()
	{
		string s = "[0 1 2]";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(reader.Read());
		Assert.IsTrue(reader.Read());
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "After parsing a value an unexpected character was encountered: 1. Path '[0]', line 1, position 3." });
	}

	[Test]
	public void UnexpectedEndAfterReadingN()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("n"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 1." });
	}

	[Test]
	public void UnexpectedEndAfterReadingNu()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("nu"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 2." });
	}

	[Test]
	public void UnexpectedEndAfterReadingNe()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("ne"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 2." });
	}

	[Test]
	public void UnexpectedEndOfHex()
	{
		JsonReader reader = new JsonTextReader(new StringReader("'h\\u123"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end while parsing Unicode escape sequence. Path '', line 1, position 4." });
	}

	[Test]
	public void UnexpectedEndOfControlCharacter()
	{
		JsonReader reader = new JsonTextReader(new StringReader("'h\\"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unterminated string. Expected delimiter: '. Path '', line 1, position 3." });
	}

	[Test]
	public void ReadInvalidNonBase10Number()
	{
		string s = "0aq2dun13.hod";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected character encountered while parsing number: q. Path '', line 1, position 2." });
		reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDecimal();
		}, new string[1] { "Unexpected character encountered while parsing number: q. Path '', line 1, position 2." });
		reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsInt32();
		}, new string[1] { "Unexpected character encountered while parsing number: q. Path '', line 1, position 2." });
	}

	[Test]
	public void ThrowErrorWhenParsingUnquoteStringThatStartsWithNE()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("{ \"ItemName\": \"value\", \"u\":netanelsalinger,\"r\":9 }"));
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(JsonToken.StartObject, reader.TokenType);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(JsonToken.PropertyName, reader.TokenType);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(JsonToken.String, reader.TokenType);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(JsonToken.PropertyName, reader.TokenType);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected content while parsing JSON. Path 'u', line 1, position 29." });
	}

	[Test]
	public void UnexpectedEndOfString()
	{
		JsonReader reader = new JsonTextReader(new StringReader("'hi"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unterminated string. Expected delimiter: '. Path '', line 1, position 3." });
	}

	[Test]
	public void UnexpectedEndTokenWhenParsingOddEndToken()
	{
		JsonReader reader = new JsonTextReader(new StringReader("{}}"));
		Assert.IsTrue(reader.Read());
		Assert.IsTrue(reader.Read());
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Additional text encountered after finished reading JSON content: }. Path '', line 1, position 2." });
	}

	[Test]
	public void ResetJsonTextReaderErrorCount()
	{
		ToggleReaderError toggleReaderError = new ToggleReaderError(new StringReader("{'first':1,'second':2,'third':3}"));
		JsonTextReader jsonTextReader = new JsonTextReader(toggleReaderError);
		Assert.IsTrue(jsonTextReader.Read());
		toggleReaderError.Error = true;
		ExceptionAssert.Throws<Exception>(() =>
		{
			jsonTextReader.Read();
		}, new string[1] { "Read error" });
		ExceptionAssert.Throws<Exception>(() =>
		{
			jsonTextReader.Read();
		}, new string[1] { "Read error" });
		toggleReaderError.Error = false;
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual("first", jsonTextReader.Value);
		toggleReaderError.Error = true;
		ExceptionAssert.Throws<Exception>(() =>
		{
			jsonTextReader.Read();
		}, new string[1] { "Read error" });
		toggleReaderError.Error = false;
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(1L, jsonTextReader.Value);
		toggleReaderError.Error = true;
		ExceptionAssert.Throws<Exception>(() =>
		{
			jsonTextReader.Read();
		}, new string[1] { "Read error" });
		ExceptionAssert.Throws<Exception>(() =>
		{
			jsonTextReader.Read();
		}, new string[1] { "Read error" });
		ExceptionAssert.Throws<Exception>(() =>
		{
			jsonTextReader.Read();
		}, new string[1] { "Read error" });
		toggleReaderError.Error = false;
	}

	[Test]
	public void MatchWithInsufficentCharacters()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("nul"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 3." });
	}

	[Test]
	public void MatchWithWrongCharacters()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("nulz"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Error parsing null value. Path '', line 1, position 3." });
	}

	[Test]
	public void MatchWithNoTrailingSeparator()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("nullz"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Error parsing null value. Path '', line 1, position 4." });
	}

	[Test]
	public void UnclosedComment()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("/* sdf"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end while parsing comment. Path '', line 1, position 6." });
	}

	[Test]
	public void BadCommentStart()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("/sdf"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Error parsing comment. Expected: *, got s. Path '', line 1, position 1." });
	}

	[Test]
	public void MissingColon()
	{
		string s = "{\r\n    \"A\" : true,\r\n    \"B\" \"";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		reader.Read();
		Assert.AreEqual(JsonToken.StartObject, reader.TokenType);
		reader.Read();
		Assert.AreEqual(JsonToken.PropertyName, reader.TokenType);
		reader.Read();
		Assert.AreEqual(JsonToken.Boolean, reader.TokenType);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Invalid character after parsing property name. Expected ':' but got: \". Path 'A', line 3, position 8." });
	}

	[Test]
	public void NullTextReader()
	{
		ExceptionAssert.Throws<ArgumentNullException>(() =>
		{
			new JsonTextReader(null);
		}, new string[2]
		{
			"Value cannot be null." + Environment.NewLine + "Parameter name: reader",
			"Argument cannot be null." + Environment.NewLine + "Parameter name: reader"
		});
	}

	[Test]
	public void ParseConstructorWithBadCharacter()
	{
		string s = "new Date,()";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			Assert.IsTrue(reader.Read());
		}, new string[1] { "Unexpected character while parsing constructor: ,. Path '', line 1, position 8." });
	}

	[Test]
	public void ParseConstructorWithUnexpectedEnd()
	{
		string s = "new Dat";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end while parsing constructor. Path '', line 1, position 7." });
	}

	[Test]
	public void ParseConstructorWithUnexpectedCharacter()
	{
		string s = "new Date !";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected character while parsing constructor: !. Path '', line 1, position 9." });
	}

	[Test]
	public void ParseAdditionalContent_Comma()
	{
		string s = "[\r\n\"Small\",\r\n\"Medium\",\r\n\"Large\"\r\n],";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			while (reader.Read())
			{
			}
		}, new string[1] { "Additional text encountered after finished reading JSON content: ,. Path '', line 5, position 1." });
	}

	[Test]
	public void ParseAdditionalContent_Text()
	{
		string s = "[\r\n\"Small\",\r\n\"Medium\",\r\n\"Large\"\r\n]content";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		reader.SetCharBuffer(new char[2]);
		reader.Read();
		Assert.AreEqual(1, reader.LineNumber);
		reader.Read();
		Assert.AreEqual(2, reader.LineNumber);
		reader.Read();
		Assert.AreEqual(3, reader.LineNumber);
		reader.Read();
		Assert.AreEqual(4, reader.LineNumber);
		reader.Read();
		Assert.AreEqual(5, reader.LineNumber);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Additional text encountered after finished reading JSON content: c. Path '', line 5, position 1." });
	}

	[Test]
	public void ParseAdditionalContent_WhitespaceThenText()
	{
		string s = "'hi' a";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			while (reader.Read())
			{
			}
		}, new string[1] { "Additional text encountered after finished reading JSON content: a. Path '', line 1, position 5." });
	}

	[Test]
	public void ParseIncompleteCommentSeparator()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("true/"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Error parsing boolean value. Path '', line 1, position 4." });
	}

	[Test]
	public void ReadBadCharInArray()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[}"));
		reader.Read();
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected character encountered while parsing value: }. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsBytesNoContentWrappedObject()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("{"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadBytesEmptyWrappedObject()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("{}"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Error reading bytes. Unexpected token: StartObject. Path '', line 1, position 2." });
	}

	[Test]
	public void ReadIntegerWithError()
	{
		string s = "{\r\n    ChildId: 333333333333333333333333333333333333333\r\n}";
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.StartObject, jsonTextReader.TokenType);
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.PropertyName, jsonTextReader.TokenType);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			jsonTextReader.ReadAsInt32();
		}, new string[1] { "JSON integer 333333333333333333333333333333333333333 is too large or small for an Int32. Path 'ChildId', line 2, position 52." });
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.EndObject, jsonTextReader.TokenType);
		Assert.IsFalse(jsonTextReader.Read());
	}

	[Test]
	public void ReadIntegerWithErrorInArray()
	{
		string s = "[\r\n  333333333333333333333333333333333333333,\r\n  3.3,\r\n  ,\r\n  0f\r\n]";
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.StartArray, jsonTextReader.TokenType);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			jsonTextReader.ReadAsInt32();
		}, new string[1] { "JSON integer 333333333333333333333333333333333333333 is too large or small for an Int32. Path '[0]', line 2, position 41." });
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			jsonTextReader.ReadAsInt32();
		}, new string[1] { "Input string '3.3' is not a valid integer. Path '[1]', line 3, position 5." });
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			jsonTextReader.ReadAsInt32();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[2]', line 4, position 3." });
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			jsonTextReader.ReadAsInt32();
		}, new string[1] { "Input string '0f' is not a valid integer. Path '[3]', line 5, position 4." });
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.EndArray, jsonTextReader.TokenType);
		Assert.IsFalse(jsonTextReader.Read());
	}

	[Test]
	public void ReadBytesWithError()
	{
		string s = "{\r\n    ChildId: '123'\r\n}";
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(s));
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.StartObject, jsonTextReader.TokenType);
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.PropertyName, jsonTextReader.TokenType);
		try
		{
			jsonTextReader.ReadAsBytes();
		}
		catch (FormatException)
		{
		}
		Assert.IsTrue(jsonTextReader.Read());
		Assert.AreEqual(JsonToken.EndObject, jsonTextReader.TokenType);
		Assert.IsFalse(jsonTextReader.Read());
	}

	[Test]
	public void ReadInt32Overflow()
	{
		long num = 2147483647L;
		JsonTextReader reader = new JsonTextReader(new StringReader(num.ToString(CultureInfo.InvariantCulture)));
		reader.Read();
		Assert.AreEqual(typeof(long), reader.ValueType);
		for (int i = 1; i < 1000; i++)
		{
			long total = i + num;
			ExceptionAssert.Throws<JsonReaderException>(() =>
			{
				reader = new JsonTextReader(new StringReader(total.ToString(CultureInfo.InvariantCulture)));
				reader.ReadAsInt32();
			}, new string[1] { "JSON integer " + total + " is too large or small for an Int32. Path '', line 1, position 10." });
		}
	}

	[Test]
	public void ReadInt32Overflow_Negative()
	{
		long num = -2147483648L;
		JsonTextReader reader = new JsonTextReader(new StringReader(num.ToString(CultureInfo.InvariantCulture)));
		reader.Read();
		Assert.AreEqual(typeof(long), reader.ValueType);
		Assert.AreEqual(num, reader.Value);
		for (int i = 1; i < 1000; i++)
		{
			long total = -i + num;
			ExceptionAssert.Throws<JsonReaderException>(() =>
			{
				reader = new JsonTextReader(new StringReader(total.ToString(CultureInfo.InvariantCulture)));
				reader.ReadAsInt32();
			}, new string[1] { "JSON integer " + total + " is too large or small for an Int32. Path '', line 1, position 11." });
		}
	}

	[Test]
	public void ReadAsString_Null_AdditionalBadData()
	{
		string s = "nullllll";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "Error parsing null value. Path '', line 1, position 4." });
	}

	[Test]
	public void ReadAsBoolean_AdditionalBadData()
	{
		string s = "falseeeee";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBoolean();
		}, new string[1] { "Unexpected character encountered while parsing value: e. Path '', line 1, position 5." });
	}

	[Test]
	public void ReadAsString_AdditionalBadData()
	{
		string s = "falseeeee";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "Unexpected character encountered while parsing value: e. Path '', line 1, position 5." });
	}

	[Test]
	public void ReadAsBoolean_UnexpectedEnd()
	{
		string s = "tru";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBoolean();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 3." });
	}

	[Test]
	public void ReadAsBoolean_BadData()
	{
		string s = "pie";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBoolean();
		}, new string[1] { "Unexpected character encountered while parsing value: p. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsString_BadData()
	{
		string s = "pie";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "Unexpected character encountered while parsing value: p. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsDouble_BadData()
	{
		string s = "pie";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDouble();
		}, new string[1] { "Unexpected character encountered while parsing value: p. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsDouble_Boolean()
	{
		string s = "true";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDouble();
		}, new string[1] { "Unexpected character encountered while parsing value: t. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsBytes_BadData()
	{
		string s = "pie";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected character encountered while parsing value: p. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsBytesIntegerArrayWithNoEnd()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[1"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected end when reading bytes. Path '[0]', line 1, position 2." });
	}

	[Test]
	public void ReadAsBytesArrayWithBadContent()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[1.0]"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected token when reading bytes: Float. Path '[0]', line 1, position 4." });
	}

	[Test]
	public void ReadAsBytesBadContent()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("new Date()"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected character encountered while parsing value: e. Path '', line 1, position 2." });
	}

	[Test]
	public void ReadAsBytes_CommaErrors()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[,'']"));
		reader.Read();
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[0]', line 1, position 2." });
		CollectionAssert.AreEquivalent(new byte[0], reader.ReadAsBytes());
		Assert.IsTrue(reader.Read());
	}

	[Test]
	public void ReadAsBytes_InvalidEndArray()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("]"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected character encountered while parsing value: ]. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsBytes_CommaErrors_Multiple()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("['',,'']"));
		reader.Read();
		CollectionAssert.AreEquivalent(new byte[0], reader.ReadAsBytes());
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[1]', line 1, position 5." });
		CollectionAssert.AreEquivalent(new byte[0], reader.ReadAsBytes());
		Assert.IsTrue(reader.Read());
	}

	[Test]
	public void ReadBytesWithBadCharacter()
	{
		JsonReader reader = new JsonTextReader(new StringReader("true"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unexpected character encountered while parsing value: t. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadBytesWithUnexpectedEnd()
	{
		string s = "Hello world!";
		byte[] bytes = Encoding.UTF8.GetBytes(s);
		JsonReader reader = new JsonTextReader(new StringReader("'" + Convert.ToBase64String(bytes)));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsBytes();
		}, new string[1] { "Unterminated string. Expected delimiter: '. Path '', line 1, position 17." });
	}

	[Test]
	public void ReadAsDateTime_BadData()
	{
		string s = "pie";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTime();
		}, new string[1] { "Unexpected character encountered while parsing value: p. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsDateTime_Boolean()
	{
		string s = "true";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTime();
		}, new string[1] { "Unexpected character encountered while parsing value: t. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadAsDateTimeOffsetBadContent()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("new Date()"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTimeOffset();
		}, new string[1] { "Unexpected character encountered while parsing value: e. Path '', line 1, position 2." });
	}

	[Test]
	public void ReadAsDecimalBadContent()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("new Date()"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDecimal();
		}, new string[1] { "Unexpected character encountered while parsing value: e. Path '', line 1, position 2." });
	}

	[Test]
	public void ReadAsDecimalBadContent_SecondLine()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("\r\nnew Date()"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDecimal();
		}, new string[1] { "Unexpected character encountered while parsing value: e. Path '', line 2, position 2." });
	}

	[Test]
	public void ReadInt32WithBadCharacter()
	{
		JsonReader reader = new JsonTextReader(new StringReader("true"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsInt32();
		}, new string[1] { "Unexpected character encountered while parsing value: t. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadNumberValue_CommaErrors()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[,1]"));
		reader.Read();
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsInt32();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[0]', line 1, position 2." });
		Assert.AreEqual(1, reader.ReadAsInt32());
		Assert.IsTrue(reader.Read());
	}

	[Test]
	public void ReadNumberValue_InvalidEndArray()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("]"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsInt32();
		}, new string[1] { "Unexpected character encountered while parsing value: ]. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadNumberValue_CommaErrors_Multiple()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[1,,1]"));
		reader.Read();
		reader.ReadAsInt32();
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsInt32();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[1]', line 1, position 4." });
		Assert.AreEqual(1, reader.ReadAsInt32());
		Assert.IsTrue(reader.Read());
	}

	[Test]
	public void ReadAsString_UnexpectedEnd()
	{
		string s = "tru";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 3." });
	}

	[Test]
	public void ReadAsString_Null_UnexpectedEnd()
	{
		string s = "nul";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "Unexpected end when reading JSON. Path '', line 1, position 3." });
	}

	[Test]
	public void ReadStringValue_InvalidEndArray()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("]"));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTime();
		}, new string[1] { "Unexpected character encountered while parsing value: ]. Path '', line 1, position 1." });
	}

	[Test]
	public void ReadStringValue_CommaErrors()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[,'']"));
		reader.Read();
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[0]', line 1, position 2." });
		Assert.AreEqual(string.Empty, reader.ReadAsString());
		Assert.IsTrue(reader.Read());
	}

	[Test]
	public void ReadStringValue_CommaErrors_Multiple()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("['',,'']"));
		reader.Read();
		reader.ReadAsInt32();
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsString();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[1]', line 1, position 5." });
		Assert.AreEqual(string.Empty, reader.ReadAsString());
		Assert.IsTrue(reader.Read());
	}

	[Test]
	public void ReadStringValue_Numbers_NotString()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("[56,56]"));
		reader.Read();
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTime();
		}, new string[1] { "Unexpected character encountered while parsing value: 5. Path '', line 1, position 2." });
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTime();
		}, new string[1] { "Unexpected character encountered while parsing value: 6. Path '', line 1, position 3." });
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.ReadAsDateTime();
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path '[0]', line 1, position 4." });
		Assert.AreEqual(56, reader.ReadAsInt32());
		Assert.IsTrue(reader.Read());
	}

	[Test]
	public void ErrorReadingComment()
	{
		string content = "/";
		JsonTextReader reader = new JsonTextReader(new StreamReader(new SlowStream(content, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false), 1)));
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end while parsing comment. Path '', line 1, position 1." });
	}

	[Test]
	public void EscapedPathInExceptionMessage()
	{
		string json = "{\r\n  \"frameworks\": {\r\n    \"dnxcore50\": {\r\n      \"dependencies\": {\r\n        \"System.Xml.ReaderWriter\": {\r\n          \"source\": !!! !!!\r\n        }\r\n      }\r\n    }\r\n  }\r\n}";
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(json));
			while (jsonTextReader.Read())
			{
			}
		}, new string[1] { "Unexpected character encountered while parsing value: !. Path 'frameworks.dnxcore50.dependencies['System.Xml.ReaderWriter'].source', line 6, position 20." });
	}

	[Test]
	public void MaxDepth()
	{
		string s = "[[]]";
		JsonTextReader reader = new JsonTextReader(new StringReader(s))
		{
			MaxDepth = 1
		};
		Assert.IsTrue(reader.Read());
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			Assert.IsTrue(reader.Read());
		}, new string[1] { "The reader's MaxDepth of 1 has been exceeded. Path '[0]', line 1, position 2." });
	}

	[Test]
	public void MaxDepthDoesNotRecursivelyError()
	{
		string s = "[[[[]]],[[]]]";
		JsonTextReader reader = new JsonTextReader(new StringReader(s))
		{
			MaxDepth = 1
		};
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(0, reader.Depth);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			Assert.IsTrue(reader.Read());
		}, new string[1] { "The reader's MaxDepth of 1 has been exceeded. Path '[0]', line 1, position 2." });
		Assert.AreEqual(1, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(2, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(3, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(3, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(2, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(1, reader.Depth);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			Assert.IsTrue(reader.Read());
		}, new string[1] { "The reader's MaxDepth of 1 has been exceeded. Path '[1]', line 1, position 9." });
		Assert.AreEqual(1, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(2, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(2, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(1, reader.Depth);
		Assert.IsTrue(reader.Read());
		Assert.AreEqual(0, reader.Depth);
		Assert.IsFalse(reader.Read());
	}

	[Test]
	public void UnexpectedEndWhenParsingUnquotedProperty()
	{
		JsonReader reader = new JsonTextReader(new StringReader("{aww"));
		Assert.IsTrue(reader.Read());
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			reader.Read();
		}, new string[1] { "Unexpected end while parsing unquoted property name. Path '', line 1, position 4." });
	}
}
