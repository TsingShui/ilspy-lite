namespace Newtonsoft.Json.Tests.JsonTextReaderTests;

public class ExceptionHandlingTests : Newtonsoft.Json.Tests.TestFixtureBase
{
    public void ReadAsBytes_MissingComma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 79, 1E, 00, 06, 0A, 00, 28, 51, 01, 00, 0A, 72, BB, B1, 00, 70, 6F, 1F, 02, 00, 0A, 0B, 1B]
        // .code-bytes IL_0018: [8D, 81, 01, 00, 01, 25, 16, 72, 5B, 30, 05, 70, A2, 25, 17, 07, 28, 61, 02, 00, 0A, A2, 25, 18]
        // .code-bytes IL_0030: [72, 61, 30, 05, 70, A2, 25, 19, 07, 28, 61, 02, 00, 0A, A2, 25, 1A, 72, 69, 30, 05, 70, A2, 28]
        // .code-bytes IL_0048: [58, 01, 00, 0A, 0C, 06, 08, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D, 97, 10, 00, 04, 06, 7B]
        // .code-bytes IL_0060: [97, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 07, 06, 7B, 97, 10, 00, 04, 6F, 62]
        // .code-bytes IL_0078: [02, 00, 0A, 28, 63, 02, 00, 0A, 00, 06, FE, 06, 7A, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81]
        // .code-bytes IL_0090: [01, 00, 01, 25, 16, 72, 6F, 30, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass0_0
        // .local [1] uint8[]
        // .local [2] string
        // IL_0000: newobj 0x06001E79 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass0_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: call 0x0A000151 [mscorlib]System.Text.Encoding::get_UTF8
        // IL_000C: ldstr 0x7000B1BB [72, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100] utf16-bytes=[48, 00, 65, 00, 6C, 00, 6C, 00, 6F, 00, 20, 00, 77, 00, 6F, 00, 72, 00, 6C, 00, 64, 00] terminal-flag=Some(0)
        // IL_0011: callvirt 0x0A00021F [mscorlib]System.Text.Encoding::GetBytes
        // IL_0016: stloc.1 1
        // IL_0017: ldc.i4.5 5
        // IL_0018: newarr 0x01000181 [mscorlib]System.String
        // IL_001D: dup 
        // IL_001E: ldc.i4.0 0
        // IL_001F: ldstr 0x7005305B [91, 39] utf16-bytes=[5B, 00, 27, 00] terminal-flag=Some(1)
        // IL_0024: stelem.ref 
        // IL_0025: dup 
        // IL_0026: ldc.i4.1 1
        // IL_0027: ldloc.1 1
        // IL_0028: call 0x0A000261 [mscorlib]System.Convert::ToBase64String
        // IL_002D: stelem.ref 
        // IL_002E: dup 
        // IL_002F: ldc.i4.2 2
        // IL_0030: ldstr 0x70053061 [39, 32, 39] utf16-bytes=[27, 00, 20, 00, 27, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: dup 
        // IL_0037: ldc.i4.3 3
        // IL_0038: ldloc.1 1
        // IL_0039: call 0x0A000261 [mscorlib]System.Convert::ToBase64String
        // IL_003E: stelem.ref 
        // IL_003F: dup 
        // IL_0040: ldc.i4.4 4
        // IL_0041: ldstr 0x70053069 [39, 93] utf16-bytes=[27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_0046: stelem.ref 
        // IL_0047: call 0x0A000158 [mscorlib]System.String::Concat
        // IL_004C: stloc.2 2
        // IL_004D: ldloc.0 0
        // IL_004E: ldloc.2 2
        // IL_004F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0054: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0059: stfld 0x04001097 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass0_0::reader
        // IL_005E: ldloc.0 0
        // IL_005F: ldfld 0x04001097 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass0_0::reader
        // IL_0064: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0069: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_006E: nop 
        // IL_006F: ldloc.1 1
        // IL_0070: ldloc.0 0
        // IL_0071: ldfld 0x04001097 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass0_0::reader
        // IL_0076: callvirt 0x0A000262 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsBytes
        // IL_007B: call 0x0A000263 [nunit.framework]NUnit.Framework.CollectionAssert::AreEquivalent
        // IL_0080: nop 
        // IL_0081: ldloc.0 0
        // IL_0082: ldftn 0x06001E7A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass0_0::<ReadAsBytes_MissingComma>b__0
        // IL_0088: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_008D: ldc.i4.1 1
        // IL_008E: newarr 0x01000181 [mscorlib]System.String
        // IL_0093: dup 
        // IL_0094: ldc.i4.0 0
        // IL_0095: ldstr 0x7005306F [65, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 97, 32, 118, 97, 108, 117, 101, 32, 97, 110, 32, 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 97, 115, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 58, 32, 39, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 48, 46] utf16-bytes=[41, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 75, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 27, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 30, 00, 2E, 00] terminal-flag=Some(1)
        // IL_009A: stelem.ref 
        // IL_009B: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_00A0: pop 
        // IL_00A1: ret 
    }

    public void ReadAsInt32_MissingComma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 7B, 1E, 00, 06, 0A, 00, 72, 36, 31, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, 98, 10, 00, 04, 06, 7B, 98, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 16]
        // .code-bytes IL_0030: [8C, 83, 01, 00, 01, 06, 7B, 98, 10, 00, 04, 6F, 64, 02, 00, 0A, 0C, 12, 02, 28, 56, 08, 00, 0A]
        // .code-bytes IL_0048: [8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, FE, 06, 7C, 1E, 00, 06, 73, 08, 01, 00, 0A, 17]
        // .code-bytes IL_0060: [8D, 81, 01, 00, 01, 25, 16, 72, 46, 31, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass1_0
        // .local [1] string
        // .local [2] valuetype [mscorlib]System.Nullable`1<int32>
        // IL_0000: newobj 0x06001E7B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass1_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053136 [91, 48, 32, 49, 32, 50, 93] utf16-bytes=[5B, 00, 30, 00, 20, 00, 31, 00, 20, 00, 32, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x04001098 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass1_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x04001098 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass1_0::reader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldc.i4.0 0
        // IL_0030: box 0x01000183 [mscorlib]System.Int32
        // IL_0035: ldloc.0 0
        // IL_0036: ldfld 0x04001098 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass1_0::reader
        // IL_003B: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
        // IL_0040: stloc.2 2
        // IL_0041: ldloca.s 2
        // IL_0043: call 0x0A000856 valuetype [mscorlib]System.Nullable`1<int32>::get_Value
        // IL_0048: box 0x01000183 [mscorlib]System.Int32
        // IL_004D: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0052: nop 
        // IL_0053: ldloc.0 0
        // IL_0054: ldftn 0x06001E7C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass1_0::<ReadAsInt32_MissingComma>b__0
        // IL_005A: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_005F: ldc.i4.1 1
        // IL_0060: newarr 0x01000181 [mscorlib]System.String
        // IL_0065: dup 
        // IL_0066: ldc.i4.0 0
        // IL_0067: ldstr 0x70053146 [65, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 97, 32, 118, 97, 108, 117, 101, 32, 97, 110, 32, 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 97, 115, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 58, 32, 49, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[41, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 75, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 31, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_006C: stelem.ref 
        // IL_006D: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0072: pop 
        // IL_0073: ret 
    }

    public void ReadAsBoolean_MissingComma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 7D, 1E, 00, 06, 0A, 00, 72, 0B, 32, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, 99, 10, 00, 04, 06, 7B, 99, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 17]
        // .code-bytes IL_0030: [8C, 8C, 01, 00, 01, 06, 7B, 99, 10, 00, 04, 6F, 6F, 08, 00, 0A, 0C, 12, 02, 28, 6D, 09, 00, 0A]
        // .code-bytes IL_0048: [8C, 8C, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, FE, 06, 7E, 1E, 00, 06, 73, 08, 01, 00, 0A, 17]
        // .code-bytes IL_0060: [8D, 81, 01, 00, 01, 25, 16, 72, 2F, 32, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass2_0
        // .local [1] string
        // .local [2] valuetype [mscorlib]System.Nullable`1<bool>
        // IL_0000: newobj 0x06001E7D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass2_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x7005320B [91, 116, 114, 117, 101, 32, 102, 97, 108, 115, 101, 32, 116, 114, 117, 101, 93] utf16-bytes=[5B, 00, 74, 00, 72, 00, 75, 00, 65, 00, 20, 00, 66, 00, 61, 00, 6C, 00, 73, 00, 65, 00, 20, 00, 74, 00, 72, 00, 75, 00, 65, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x04001099 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass2_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x04001099 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass2_0::reader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldc.i4.1 1
        // IL_0030: box 0x0100018C [mscorlib]System.Boolean
        // IL_0035: ldloc.0 0
        // IL_0036: ldfld 0x04001099 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass2_0::reader
        // IL_003B: callvirt 0x0A00086F [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsBoolean
        // IL_0040: stloc.2 2
        // IL_0041: ldloca.s 2
        // IL_0043: call 0x0A00096D valuetype [mscorlib]System.Nullable`1<bool>::get_Value
        // IL_0048: box 0x0100018C [mscorlib]System.Boolean
        // IL_004D: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0052: nop 
        // IL_0053: ldloc.0 0
        // IL_0054: ldftn 0x06001E7E Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass2_0::<ReadAsBoolean_MissingComma>b__0
        // IL_005A: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_005F: ldc.i4.1 1
        // IL_0060: newarr 0x01000181 [mscorlib]System.String
        // IL_0065: dup 
        // IL_0066: ldc.i4.0 0
        // IL_0067: ldstr 0x7005322F [65, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 97, 32, 118, 97, 108, 117, 101, 32, 97, 110, 32, 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 97, 115, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 58, 32, 102, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 54, 46] utf16-bytes=[41, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 75, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 66, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 36, 00, 2E, 00] terminal-flag=Some(1)
        // IL_006C: stelem.ref 
        // IL_006D: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0072: pop 
        // IL_0073: ret 
    }

    public void ReadAsDateTime_MissingComma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 7F, 1E, 00, 06, 0A, 00, 72, F4, 32, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, 9A, 10, 00, 04, 06, 7B, 9A, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 20]
        // .code-bytes IL_0030: [E1, 07, 00, 00, 18, 1A, 16, 16, 16, 17, 73, D0, 00, 00, 0A, 8C, 21, 00, 00, 01, 06, 7B, 9A, 10]
        // .code-bytes IL_0048: [00, 04, 6F, 6C, 08, 00, 0A, 0C, 12, 02, 28, 6E, 09, 00, 0A, 8C, 21, 00, 00, 01, 28, C7, 00, 00]
        // .code-bytes IL_0060: [0A, 00, 06, FE, 06, 80, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 83]
        // .code-bytes IL_0078: [33, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass3_0
        // .local [1] string
        // .local [2] valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>
        // IL_0000: newobj 0x06001E7F Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass3_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700532F4 [91, 39, 50, 48, 49, 55, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 32, 39, 50, 48, 49, 56, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 32, 39, 50, 48, 49, 57, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 93] utf16-bytes=[5B, 00, 27, 00, 32, 00, 30, 00, 31, 00, 37, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 20, 00, 27, 00, 32, 00, 30, 00, 31, 00, 38, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 20, 00, 27, 00, 32, 00, 30, 00, 31, 00, 39, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x0400109A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass3_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x0400109A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass3_0::reader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldc.i4 2017
        // IL_0034: ldc.i4.2 2
        // IL_0035: ldc.i4.4 4
        // IL_0036: ldc.i4.0 0
        // IL_0037: ldc.i4.0 0
        // IL_0038: ldc.i4.0 0
        // IL_0039: ldc.i4.1 1
        // IL_003A: newobj 0x0A0000D0 [mscorlib]System.DateTime::.ctor
        // IL_003F: box 0x01000021 [mscorlib]System.DateTime
        // IL_0044: ldloc.0 0
        // IL_0045: ldfld 0x0400109A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass3_0::reader
        // IL_004A: callvirt 0x0A00086C [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsDateTime
        // IL_004F: stloc.2 2
        // IL_0050: ldloca.s 2
        // IL_0052: call 0x0A00096E valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>::get_Value
        // IL_0057: box 0x01000021 [mscorlib]System.DateTime
        // IL_005C: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0061: nop 
        // IL_0062: ldloc.0 0
        // IL_0063: ldftn 0x06001E80 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass3_0::<ReadAsDateTime_MissingComma>b__0
        // IL_0069: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_006E: ldc.i4.1 1
        // IL_006F: newarr 0x01000181 [mscorlib]System.String
        // IL_0074: dup 
        // IL_0075: ldc.i4.0 0
        // IL_0076: ldstr 0x70053383 [65, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 97, 32, 118, 97, 108, 117, 101, 32, 97, 110, 32, 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 97, 115, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 58, 32, 39, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 52, 46] utf16-bytes=[41, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 75, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 27, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_007B: stelem.ref 
        // IL_007C: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0081: pop 
        // IL_0082: ret 
    }

    public void ReadAsDateTimeOffset_MissingComma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, 81, 1E, 00, 06, 0A, 00, 72, F4, 32, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, 9B, 10, 00, 04, 06, 7B, 9B, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 20]
        // .code-bytes IL_0030: [E1, 07, 00, 00, 18, 1A, 16, 16, 16, 7E, 2D, 01, 00, 0A, 73, 46, 01, 00, 0A, 8C, 46, 00, 00, 01]
        // .code-bytes IL_0048: [06, 7B, 9B, 10, 00, 04, 6F, 68, 08, 00, 0A, 0C, 12, 02, 28, 6F, 09, 00, 0A, 8C, 46, 00, 00, 01]
        // .code-bytes IL_0060: [28, C7, 00, 00, 0A, 00, 06, FE, 06, 82, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0078: [25, 16, 72, 83, 33, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass4_0
        // .local [1] string
        // .local [2] valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTimeOffset>
        // IL_0000: newobj 0x06001E81 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass4_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700532F4 [91, 39, 50, 48, 49, 55, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 32, 39, 50, 48, 49, 56, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 32, 39, 50, 48, 49, 57, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 93] utf16-bytes=[5B, 00, 27, 00, 32, 00, 30, 00, 31, 00, 37, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 20, 00, 27, 00, 32, 00, 30, 00, 31, 00, 38, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 20, 00, 27, 00, 32, 00, 30, 00, 31, 00, 39, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x0400109B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass4_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x0400109B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass4_0::reader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldc.i4 2017
        // IL_0034: ldc.i4.2 2
        // IL_0035: ldc.i4.4 4
        // IL_0036: ldc.i4.0 0
        // IL_0037: ldc.i4.0 0
        // IL_0038: ldc.i4.0 0
        // IL_0039: ldsfld 0x0A00012D [mscorlib]System.TimeSpan::Zero
        // IL_003E: newobj 0x0A000146 [mscorlib]System.DateTimeOffset::.ctor
        // IL_0043: box 0x01000046 [mscorlib]System.DateTimeOffset
        // IL_0048: ldloc.0 0
        // IL_0049: ldfld 0x0400109B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass4_0::reader
        // IL_004E: callvirt 0x0A000868 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsDateTimeOffset
        // IL_0053: stloc.2 2
        // IL_0054: ldloca.s 2
        // IL_0056: call 0x0A00096F valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTimeOffset>::get_Value
        // IL_005B: box 0x01000046 [mscorlib]System.DateTimeOffset
        // IL_0060: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0065: nop 
        // IL_0066: ldloc.0 0
        // IL_0067: ldftn 0x06001E82 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass4_0::<ReadAsDateTimeOffset_MissingComma>b__0
        // IL_006D: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0072: ldc.i4.1 1
        // IL_0073: newarr 0x01000181 [mscorlib]System.String
        // IL_0078: dup 
        // IL_0079: ldc.i4.0 0
        // IL_007A: ldstr 0x70053383 [65, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 97, 32, 118, 97, 108, 117, 101, 32, 97, 110, 32, 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 97, 115, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 58, 32, 39, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 52, 46] utf16-bytes=[41, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 75, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 27, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_007F: stelem.ref 
        // IL_0080: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0085: pop 
        // IL_0086: ret 
    }

    public void ReadAsString_MissingComma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 83, 1E, 00, 06, 0A, 00, 72, F4, 32, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, 9C, 10, 00, 04, 06, 7B, 9C, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 72]
        // .code-bytes IL_0030: [4A, 34, 05, 70, 06, 7B, 9C, 10, 00, 04, 6F, 62, 01, 00, 0A, 28, C7, 00, 00, 0A, 00, 06, FE, 06]
        // .code-bytes IL_0048: [84, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 83, 33, 05, 70, A2, 28]
        // .code-bytes IL_0060: [12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass5_0
        // .local [1] string
        // IL_0000: newobj 0x06001E83 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass5_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700532F4 [91, 39, 50, 48, 49, 55, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 32, 39, 50, 48, 49, 56, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 32, 39, 50, 48, 49, 57, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90, 39, 93] utf16-bytes=[5B, 00, 27, 00, 32, 00, 30, 00, 31, 00, 37, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 20, 00, 27, 00, 32, 00, 30, 00, 31, 00, 38, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 20, 00, 27, 00, 32, 00, 30, 00, 31, 00, 39, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00, 27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x0400109C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass5_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x0400109C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass5_0::reader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldstr 0x7005344A [50, 48, 49, 55, 45, 48, 50, 45, 48, 52, 84, 48, 48, 58, 48, 48, 58, 48, 48, 90] utf16-bytes=[32, 00, 30, 00, 31, 00, 37, 00, 2D, 00, 30, 00, 32, 00, 2D, 00, 30, 00, 34, 00, 54, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 3A, 00, 30, 00, 30, 00, 5A, 00] terminal-flag=Some(1)
        // IL_0034: ldloc.0 0
        // IL_0035: ldfld 0x0400109C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass5_0::reader
        // IL_003A: callvirt 0x0A000162 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsString
        // IL_003F: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0044: nop 
        // IL_0045: ldloc.0 0
        // IL_0046: ldftn 0x06001E84 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass5_0::<ReadAsString_MissingComma>b__0
        // IL_004C: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0051: ldc.i4.1 1
        // IL_0052: newarr 0x01000181 [mscorlib]System.String
        // IL_0057: dup 
        // IL_0058: ldc.i4.0 0
        // IL_0059: ldstr 0x70053383 [65, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 97, 32, 118, 97, 108, 117, 101, 32, 97, 110, 32, 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 97, 115, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 58, 32, 39, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 52, 46] utf16-bytes=[41, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 75, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 27, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_005E: stelem.ref 
        // IL_005F: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0064: pop 
        // IL_0065: ret 
    }

    public void Read_MissingComma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 85, 1E, 00, 06, 0A, 00, 72, 36, 31, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, 9D, 10, 00, 04, 06, 7B, 9D, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 06]
        // .code-bytes IL_0030: [7B, 9D, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 06, FE, 06, 86, 1E, 00, 06, 73]
        // .code-bytes IL_0048: [08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 46, 31, 05, 70, A2, 28, 12, 00, 00, 2B, 26]
        // .code-bytes IL_0060: [2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass6_0
        // .local [1] string
        // IL_0000: newobj 0x06001E85 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass6_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053136 [91, 48, 32, 49, 32, 50, 93] utf16-bytes=[5B, 00, 30, 00, 20, 00, 31, 00, 20, 00, 32, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x0400109D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass6_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x0400109D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass6_0::reader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldloc.0 0
        // IL_0030: ldfld 0x0400109D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass6_0::reader
        // IL_0035: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_003A: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_003F: nop 
        // IL_0040: ldloc.0 0
        // IL_0041: ldftn 0x06001E86 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass6_0::<Read_MissingComma>b__0
        // IL_0047: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_004C: ldc.i4.1 1
        // IL_004D: newarr 0x01000181 [mscorlib]System.String
        // IL_0052: dup 
        // IL_0053: ldc.i4.0 0
        // IL_0054: ldstr 0x70053146 [65, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 97, 32, 118, 97, 108, 117, 101, 32, 97, 110, 32, 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 97, 115, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 58, 32, 49, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[41, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 75, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 61, 00, 73, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 31, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0059: stelem.ref 
        // IL_005A: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_005F: pop 
        // IL_0060: ret 
    }

    public void UnexpectedEndAfterReadingN()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 87, 1E, 00, 06, 0A, 00, 06, 72, 15, D6, 00, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [9E, 10, 00, 04, 06, FE, 06, 88, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 74, 34, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass7_0
        // IL_0000: newobj 0x06001E87 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass7_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x7000D615 [110] utf16-bytes=[6E, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x0400109E Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass7_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001E88 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass7_0::<UnexpectedEndAfterReadingN>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70053474 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void UnexpectedEndAfterReadingNu()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 89, 1E, 00, 06, 0A, 00, 06, 72, F2, 34, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [9F, 10, 00, 04, 06, FE, 06, 8A, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, F8, 34, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass8_0
        // IL_0000: newobj 0x06001E89 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass8_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700534F2 [110, 117] utf16-bytes=[6E, 00, 75, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x0400109F Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass8_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001E8A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass8_0::<UnexpectedEndAfterReadingNu>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x700534F8 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void UnexpectedEndAfterReadingNe()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 8B, 1E, 00, 06, 0A, 00, 06, 72, 76, 35, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A0, 10, 00, 04, 06, FE, 06, 8C, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, F8, 34, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass9_0
        // IL_0000: newobj 0x06001E8B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass9_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053576 [110, 101] utf16-bytes=[6E, 00, 65, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass9_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001E8C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass9_0::<UnexpectedEndAfterReadingNe>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x700534F8 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void UnexpectedEndOfHex()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 8D, 1E, 00, 06, 0A, 00, 06, 72, 7C, 35, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A1, 10, 00, 04, 06, FE, 06, 8E, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 8C, 35, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass10_0
        // IL_0000: newobj 0x06001E8D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass10_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x7005357C [39, 104, 92, 117, 49, 50, 51] utf16-bytes=[27, 00, 68, 00, 5C, 00, 75, 00, 31, 00, 32, 00, 33, 00] terminal-flag=Some(1)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass10_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001E8E Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass10_0::<UnexpectedEndOfHex>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x7005358C [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 85, 110, 105, 99, 111, 100, 101, 32, 101, 115, 99, 97, 112, 101, 32, 115, 101, 113, 117, 101, 110, 99, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 55, 00, 6E, 00, 69, 00, 63, 00, 6F, 00, 64, 00, 65, 00, 20, 00, 65, 00, 73, 00, 63, 00, 61, 00, 70, 00, 65, 00, 20, 00, 73, 00, 65, 00, 71, 00, 75, 00, 65, 00, 6E, 00, 63, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void UnexpectedEndOfControlCharacter()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 8F, 1E, 00, 06, 0A, 00, 06, 72, 33, 36, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A2, 10, 00, 04, 06, FE, 06, 90, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 3B, 36, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass11_0
        // IL_0000: newobj 0x06001E8F Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass11_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053633 [39, 104, 92] utf16-bytes=[27, 00, 68, 00, 5C, 00] terminal-flag=Some(1)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass11_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001E90 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass11_0::<UnexpectedEndOfControlCharacter>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x7005363B [85, 110, 116, 101, 114, 109, 105, 110, 97, 116, 101, 100, 32, 115, 116, 114, 105, 110, 103, 46, 32, 69, 120, 112, 101, 99, 116, 101, 100, 32, 100, 101, 108, 105, 109, 105, 116, 101, 114, 58, 32, 39, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 6D, 00, 69, 00, 6E, 00, 61, 00, 74, 00, 65, 00, 64, 00, 20, 00, 73, 00, 74, 00, 72, 00, 69, 00, 6E, 00, 67, 00, 2E, 00, 20, 00, 45, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 64, 00, 65, 00, 6C, 00, 69, 00, 6D, 00, 69, 00, 74, 00, 65, 00, 72, 00, 3A, 00, 20, 00, 27, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadInvalidNonBase10Number()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 91, 1E, 00, 06, 0A, 00, 72, CE, 36, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, A3, 10, 00, 04, 06, FE, 06, 92, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, EA, 36, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01]
        // .code-bytes IL_0048: [00, 0A, 7D, A3, 10, 00, 04, 06, FE, 06, 93, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00]
        // .code-bytes IL_0060: [01, 25, 16, 72, EA, 36, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F]
        // .code-bytes IL_0078: [01, 00, 0A, 7D, A3, 10, 00, 04, 06, FE, 06, 94, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01]
        // .code-bytes IL_0090: [00, 01, 25, 16, 72, EA, 36, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0
        // .local [1] string
        // IL_0000: newobj 0x06001E91 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700536CE [48, 97, 113, 50, 100, 117, 110, 49, 51, 46, 104, 111, 100] utf16-bytes=[30, 00, 61, 00, 71, 00, 32, 00, 64, 00, 75, 00, 6E, 00, 31, 00, 33, 00, 2E, 00, 68, 00, 6F, 00, 64, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010A3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001E92 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0::<ReadInvalidNonBase10Number>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x700536EA [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 110, 117, 109, 98, 101, 114, 58, 32, 113, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 6E, 00, 75, 00, 6D, 00, 62, 00, 65, 00, 72, 00, 3A, 00, 20, 00, 71, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ldloc.0 0
        // IL_003F: ldloc.1 1
        // IL_0040: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0045: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_004A: stfld 0x040010A3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0::reader
        // IL_004F: ldloc.0 0
        // IL_0050: ldftn 0x06001E93 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0::<ReadInvalidNonBase10Number>b__1
        // IL_0056: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_005B: ldc.i4.1 1
        // IL_005C: newarr 0x01000181 [mscorlib]System.String
        // IL_0061: dup 
        // IL_0062: ldc.i4.0 0
        // IL_0063: ldstr 0x700536EA [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 110, 117, 109, 98, 101, 114, 58, 32, 113, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 6E, 00, 75, 00, 6D, 00, 62, 00, 65, 00, 72, 00, 3A, 00, 20, 00, 71, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0068: stelem.ref 
        // IL_0069: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_006E: pop 
        // IL_006F: ldloc.0 0
        // IL_0070: ldloc.1 1
        // IL_0071: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0076: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_007B: stfld 0x040010A3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0::reader
        // IL_0080: ldloc.0 0
        // IL_0081: ldftn 0x06001E94 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass12_0::<ReadInvalidNonBase10Number>b__2
        // IL_0087: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_008C: ldc.i4.1 1
        // IL_008D: newarr 0x01000181 [mscorlib]System.String
        // IL_0092: dup 
        // IL_0093: ldc.i4.0 0
        // IL_0094: ldstr 0x700536EA [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 110, 117, 109, 98, 101, 114, 58, 32, 113, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 6E, 00, 75, 00, 6D, 00, 62, 00, 65, 00, 72, 00, 3A, 00, 20, 00, 71, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0099: stelem.ref 
        // IL_009A: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_009F: pop 
        // IL_00A0: ret 
    }

    public void ThrowErrorWhenParsingUnquoteStringThatStartsWithNE()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 95, 1E, 00, 06, 0A, 00, 06, 72, 99, 37, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A4, 10, 00, 04, 06, 7B, A4, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 17, 8C, 72]
        // .code-bytes IL_0030: [00, 00, 01, 06, 7B, A4, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A]
        // .code-bytes IL_0048: [00, 06, 7B, A4, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 1A, 8C, 72, 00, 00, 01]
        // .code-bytes IL_0060: [06, 7B, A4, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B]
        // .code-bytes IL_0078: [A4, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 1F, 09, 8C, 72, 00, 00, 01, 06, 7B]
        // .code-bytes IL_0090: [A4, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, A4, 10]
        // .code-bytes IL_00A8: [00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 1A, 8C, 72, 00, 00, 01, 06, 7B, A4, 10, 00]
        // .code-bytes IL_00C0: [04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00, 06, FE, 06, 96, 1E, 00, 06]
        // .code-bytes IL_00D8: [73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, FF, 37, 05, 70, A2, 28, 12, 00, 00, 2B]
        // .code-bytes IL_00F0: [26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0
        // IL_0000: newobj 0x06001E95 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053799 [123, 32, 34, 73, 116, 101, 109, 78, 97, 109, 101, 34, 58, 32, 34, 118, 97, 108, 117, 101, 34, 44, 32, 34, 117, 34, 58, 110, 101, 116, 97, 110, 101, 108, 115, 97, 108, 105, 110, 103, 101, 114, 44, 34, 114, 34, 58, 57, 32, 125] utf16-bytes=[7B, 00, 20, 00, 22, 00, 49, 00, 74, 00, 65, 00, 6D, 00, 4E, 00, 61, 00, 6D, 00, 65, 00, 22, 00, 3A, 00, 20, 00, 22, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 22, 00, 2C, 00, 20, 00, 22, 00, 75, 00, 22, 00, 3A, 00, 6E, 00, 65, 00, 74, 00, 61, 00, 6E, 00, 65, 00, 6C, 00, 73, 00, 61, 00, 6C, 00, 69, 00, 6E, 00, 67, 00, 65, 00, 72, 00, 2C, 00, 22, 00, 72, 00, 22, 00, 3A, 00, 39, 00, 20, 00, 7D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002C: nop 
        // IL_002D: ldc.i4.1 1
        // IL_002E: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0033: ldloc.0 0
        // IL_0034: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_0039: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_003E: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0043: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0048: nop 
        // IL_0049: ldloc.0 0
        // IL_004A: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_004F: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0054: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0059: nop 
        // IL_005A: ldc.i4.4 4
        // IL_005B: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0060: ldloc.0 0
        // IL_0061: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_0066: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_006B: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0070: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0075: nop 
        // IL_0076: ldloc.0 0
        // IL_0077: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_007C: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0081: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0086: nop 
        // IL_0087: ldc.i4.s 9
        // IL_0089: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_008E: ldloc.0 0
        // IL_008F: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_0094: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_0099: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_009E: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00A3: nop 
        // IL_00A4: ldloc.0 0
        // IL_00A5: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_00AA: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00AF: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00B4: nop 
        // IL_00B5: ldc.i4.4 4
        // IL_00B6: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_00BB: ldloc.0 0
        // IL_00BC: ldfld 0x040010A4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::reader
        // IL_00C1: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_00C6: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_00CB: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00D0: nop 
        // IL_00D1: ldloc.0 0
        // IL_00D2: ldftn 0x06001E96 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass13_0::<ThrowErrorWhenParsingUnquoteStringThatStartsWithNE>b__0
        // IL_00D8: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_00DD: ldc.i4.1 1
        // IL_00DE: newarr 0x01000181 [mscorlib]System.String
        // IL_00E3: dup 
        // IL_00E4: ldc.i4.0 0
        // IL_00E5: ldstr 0x700537FF [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 111, 110, 116, 101, 110, 116, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 117, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 57, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 74, 00, 65, 00, 6E, 00, 74, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 75, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 39, 00, 2E, 00] terminal-flag=Some(1)
        // IL_00EA: stelem.ref 
        // IL_00EB: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_00F0: pop 
        // IL_00F1: ret 
    }

    public void UnexpectedEndOfString()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 97, 1E, 00, 06, 0A, 00, 06, 72, 8C, 38, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A5, 10, 00, 04, 06, FE, 06, 98, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 3B, 36, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass14_0
        // IL_0000: newobj 0x06001E97 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass14_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x7005388C [39, 104, 105] utf16-bytes=[27, 00, 68, 00, 69, 00] terminal-flag=Some(1)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass14_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001E98 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass14_0::<UnexpectedEndOfString>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x7005363B [85, 110, 116, 101, 114, 109, 105, 110, 97, 116, 101, 100, 32, 115, 116, 114, 105, 110, 103, 46, 32, 69, 120, 112, 101, 99, 116, 101, 100, 32, 100, 101, 108, 105, 109, 105, 116, 101, 114, 58, 32, 39, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 6D, 00, 69, 00, 6E, 00, 61, 00, 74, 00, 65, 00, 64, 00, 20, 00, 73, 00, 74, 00, 72, 00, 69, 00, 6E, 00, 67, 00, 2E, 00, 20, 00, 45, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 64, 00, 65, 00, 6C, 00, 69, 00, 6D, 00, 69, 00, 74, 00, 65, 00, 72, 00, 3A, 00, 20, 00, 27, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void UnexpectedEndTokenWhenParsingOddEndToken()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 99, 1E, 00, 06, 0A, 00, 06, 72, 94, 38, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A6, 10, 00, 04, 06, 7B, A6, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 06, 7B, A6]
        // .code-bytes IL_0030: [10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 06, FE, 06, 9A, 1E, 00, 06, 73, 08, 01]
        // .code-bytes IL_0048: [00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 9C, 38, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass15_0
        // IL_0000: newobj 0x06001E99 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass15_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053894 [123, 125, 125] utf16-bytes=[7B, 00, 7D, 00, 7D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass15_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010A6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass15_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002C: nop 
        // IL_002D: ldloc.0 0
        // IL_002E: ldfld 0x040010A6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass15_0::reader
        // IL_0033: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0038: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_003D: nop 
        // IL_003E: ldloc.0 0
        // IL_003F: ldftn 0x06001E9A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass15_0::<UnexpectedEndTokenWhenParsingOddEndToken>b__0
        // IL_0045: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_004A: ldc.i4.1 1
        // IL_004B: newarr 0x01000181 [mscorlib]System.String
        // IL_0050: dup 
        // IL_0051: ldc.i4.0 0
        // IL_0052: ldstr 0x7005389C [65, 100, 100, 105, 116, 105, 111, 110, 97, 108, 32, 116, 101, 120, 116, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 97, 102, 116, 101, 114, 32, 102, 105, 110, 105, 115, 104, 101, 100, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 32, 99, 111, 110, 116, 101, 110, 116, 58, 32, 125, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[41, 00, 64, 00, 64, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 61, 00, 6C, 00, 20, 00, 74, 00, 65, 00, 78, 00, 74, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 61, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 66, 00, 69, 00, 6E, 00, 69, 00, 73, 00, 68, 00, 65, 00, 64, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 74, 00, 65, 00, 6E, 00, 74, 00, 3A, 00, 20, 00, 7D, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0057: stelem.ref 
        // IL_0058: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_005D: pop 
        // IL_005E: ret 
    }

    public void ResetJsonTextReaderErrorCount()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 9B, 1E, 00, 06, 0A, 00, 72, 5F, 39, 05, 70, 73, 0E, 01, 00, 0A, 73, B3, 08, 00, 06, 0B, 06]
        // .code-bytes IL_0018: [07, 73, 0F, 01, 00, 0A, 7D, A7, 10, 00, 04, 06, 7B, A7, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6]
        // .code-bytes IL_0030: [00, 00, 0A, 00, 07, 17, 6F, B2, 08, 00, 06, 00, 06, FE, 06, 9C, 1E, 00, 06, 73, 08, 01, 00, 0A]
        // .code-bytes IL_0048: [17, 8D, 81, 01, 00, 01, 25, 16, 72, 8F, DA, 00, 70, A2, 28, 63, 00, 00, 2B, 26, 06, FE, 06, 9D]
        // .code-bytes IL_0060: [1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 8F, DA, 00, 70, A2, 28, 63]
        // .code-bytes IL_0078: [00, 00, 2B, 26, 07, 16, 6F, B2, 08, 00, 06, 00, 06, 7B, A7, 10, 00, 04, 6F, 72, 01, 00, 0A, 28]
        // .code-bytes IL_0090: [D6, 00, 00, 0A, 00, 72, C4, 1A, 01, 70, 06, 7B, A7, 10, 00, 04, 6F, 54, 02, 00, 0A, 28, C7, 00]
        // .code-bytes IL_00A8: [00, 0A, 00, 07, 17, 6F, B2, 08, 00, 06, 00, 06, FE, 06, 9E, 1E, 00, 06, 73, 08, 01, 00, 0A, 17]
        // .code-bytes IL_00C0: [8D, 81, 01, 00, 01, 25, 16, 72, 8F, DA, 00, 70, A2, 28, 63, 00, 00, 2B, 26, 07, 16, 6F, B2, 08]
        // .code-bytes IL_00D8: [00, 06, 00, 06, 7B, A7, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 17, 6A, 8C, 90]
        // .code-bytes IL_00F0: [01, 00, 01, 06, 7B, A7, 10, 00, 04, 6F, 54, 02, 00, 0A, 28, C7, 00, 00, 0A, 00, 07, 17, 6F, B2]
        // .code-bytes IL_0108: [08, 00, 06, 00, 06, FE, 06, 9F, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0120: [72, 8F, DA, 00, 70, A2, 28, 63, 00, 00, 2B, 26, 06, FE, 06, A0, 1E, 00, 06, 73, 08, 01, 00, 0A]
        // .code-bytes IL_0138: [17, 8D, 81, 01, 00, 01, 25, 16, 72, 8F, DA, 00, 70, A2, 28, 63, 00, 00, 2B, 26, 06, FE, 06, A1]
        // .code-bytes IL_0150: [1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 8F, DA, 00, 70, A2, 28, 63]
        // .code-bytes IL_0168: [00, 00, 2B, 26, 07, 16, 6F, B2, 08, 00, 06, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0
        // .local [1] class Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError
        // IL_0000: newobj 0x06001E9B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x7005395F [123, 39, 102, 105, 114, 115, 116, 39, 58, 49, 44, 39, 115, 101, 99, 111, 110, 100, 39, 58, 50, 44, 39, 116, 104, 105, 114, 100, 39, 58, 51, 125] utf16-bytes=[7B, 00, 27, 00, 66, 00, 69, 00, 72, 00, 73, 00, 74, 00, 27, 00, 3A, 00, 31, 00, 2C, 00, 27, 00, 73, 00, 65, 00, 63, 00, 6F, 00, 6E, 00, 64, 00, 27, 00, 3A, 00, 32, 00, 2C, 00, 27, 00, 74, 00, 68, 00, 69, 00, 72, 00, 64, 00, 27, 00, 3A, 00, 33, 00, 7D, 00] terminal-flag=Some(1)
        // IL_000C: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0011: newobj 0x060008B3 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError::.ctor
        // IL_0016: stloc.1 1
        // IL_0017: ldloc.0 0
        // IL_0018: ldloc.1 1
        // IL_0019: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_001E: stfld 0x040010A7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::jsonTextReader
        // IL_0023: ldloc.0 0
        // IL_0024: ldfld 0x040010A7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::jsonTextReader
        // IL_0029: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_002E: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0033: nop 
        // IL_0034: ldloc.1 1
        // IL_0035: ldc.i4.1 1
        // IL_0036: callvirt 0x060008B2 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError::set_Error
        // IL_003B: nop 
        // IL_003C: ldloc.0 0
        // IL_003D: ldftn 0x06001E9C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::<ResetJsonTextReaderErrorCount>b__0
        // IL_0043: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0048: ldc.i4.1 1
        // IL_0049: newarr 0x01000181 [mscorlib]System.String
        // IL_004E: dup 
        // IL_004F: ldc.i4.0 0
        // IL_0050: ldstr 0x7000DA8F [82, 101, 97, 100, 32, 101, 114, 114, 111, 114] utf16-bytes=[52, 00, 65, 00, 61, 00, 64, 00, 20, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_0055: stelem.ref 
        // IL_0056: call 0x2B000063 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [mscorlib]System.Exception>
        // IL_005B: pop 
        // IL_005C: ldloc.0 0
        // IL_005D: ldftn 0x06001E9D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::<ResetJsonTextReaderErrorCount>b__1
        // IL_0063: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0068: ldc.i4.1 1
        // IL_0069: newarr 0x01000181 [mscorlib]System.String
        // IL_006E: dup 
        // IL_006F: ldc.i4.0 0
        // IL_0070: ldstr 0x7000DA8F [82, 101, 97, 100, 32, 101, 114, 114, 111, 114] utf16-bytes=[52, 00, 65, 00, 61, 00, 64, 00, 20, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_0075: stelem.ref 
        // IL_0076: call 0x2B000063 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [mscorlib]System.Exception>
        // IL_007B: pop 
        // IL_007C: ldloc.1 1
        // IL_007D: ldc.i4.0 0
        // IL_007E: callvirt 0x060008B2 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError::set_Error
        // IL_0083: nop 
        // IL_0084: ldloc.0 0
        // IL_0085: ldfld 0x040010A7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::jsonTextReader
        // IL_008A: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_008F: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0094: nop 
        // IL_0095: ldstr 0x70011AC4 [102, 105, 114, 115, 116] utf16-bytes=[66, 00, 69, 00, 72, 00, 73, 00, 74, 00] terminal-flag=Some(0)
        // IL_009A: ldloc.0 0
        // IL_009B: ldfld 0x040010A7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::jsonTextReader
        // IL_00A0: callvirt 0x0A000254 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Value
        // IL_00A5: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00AA: nop 
        // IL_00AB: ldloc.1 1
        // IL_00AC: ldc.i4.1 1
        // IL_00AD: callvirt 0x060008B2 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError::set_Error
        // IL_00B2: nop 
        // IL_00B3: ldloc.0 0
        // IL_00B4: ldftn 0x06001E9E Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::<ResetJsonTextReaderErrorCount>b__2
        // IL_00BA: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_00BF: ldc.i4.1 1
        // IL_00C0: newarr 0x01000181 [mscorlib]System.String
        // IL_00C5: dup 
        // IL_00C6: ldc.i4.0 0
        // IL_00C7: ldstr 0x7000DA8F [82, 101, 97, 100, 32, 101, 114, 114, 111, 114] utf16-bytes=[52, 00, 65, 00, 61, 00, 64, 00, 20, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_00CC: stelem.ref 
        // IL_00CD: call 0x2B000063 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [mscorlib]System.Exception>
        // IL_00D2: pop 
        // IL_00D3: ldloc.1 1
        // IL_00D4: ldc.i4.0 0
        // IL_00D5: callvirt 0x060008B2 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError::set_Error
        // IL_00DA: nop 
        // IL_00DB: ldloc.0 0
        // IL_00DC: ldfld 0x040010A7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::jsonTextReader
        // IL_00E1: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00E6: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00EB: nop 
        // IL_00EC: ldc.i4.1 1
        // IL_00ED: conv.i8 
        // IL_00EE: box 0x01000190 [mscorlib]System.Int64
        // IL_00F3: ldloc.0 0
        // IL_00F4: ldfld 0x040010A7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::jsonTextReader
        // IL_00F9: callvirt 0x0A000254 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Value
        // IL_00FE: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0103: nop 
        // IL_0104: ldloc.1 1
        // IL_0105: ldc.i4.1 1
        // IL_0106: callvirt 0x060008B2 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError::set_Error
        // IL_010B: nop 
        // IL_010C: ldloc.0 0
        // IL_010D: ldftn 0x06001E9F Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::<ResetJsonTextReaderErrorCount>b__3
        // IL_0113: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0118: ldc.i4.1 1
        // IL_0119: newarr 0x01000181 [mscorlib]System.String
        // IL_011E: dup 
        // IL_011F: ldc.i4.0 0
        // IL_0120: ldstr 0x7000DA8F [82, 101, 97, 100, 32, 101, 114, 114, 111, 114] utf16-bytes=[52, 00, 65, 00, 61, 00, 64, 00, 20, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_0125: stelem.ref 
        // IL_0126: call 0x2B000063 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [mscorlib]System.Exception>
        // IL_012B: pop 
        // IL_012C: ldloc.0 0
        // IL_012D: ldftn 0x06001EA0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::<ResetJsonTextReaderErrorCount>b__4
        // IL_0133: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0138: ldc.i4.1 1
        // IL_0139: newarr 0x01000181 [mscorlib]System.String
        // IL_013E: dup 
        // IL_013F: ldc.i4.0 0
        // IL_0140: ldstr 0x7000DA8F [82, 101, 97, 100, 32, 101, 114, 114, 111, 114] utf16-bytes=[52, 00, 65, 00, 61, 00, 64, 00, 20, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_0145: stelem.ref 
        // IL_0146: call 0x2B000063 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [mscorlib]System.Exception>
        // IL_014B: pop 
        // IL_014C: ldloc.0 0
        // IL_014D: ldftn 0x06001EA1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass16_0::<ResetJsonTextReaderErrorCount>b__5
        // IL_0153: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0158: ldc.i4.1 1
        // IL_0159: newarr 0x01000181 [mscorlib]System.String
        // IL_015E: dup 
        // IL_015F: ldc.i4.0 0
        // IL_0160: ldstr 0x7000DA8F [82, 101, 97, 100, 32, 101, 114, 114, 111, 114] utf16-bytes=[52, 00, 65, 00, 61, 00, 64, 00, 20, 00, 65, 00, 72, 00, 72, 00, 6F, 00, 72, 00] terminal-flag=Some(0)
        // IL_0165: stelem.ref 
        // IL_0166: call 0x2B000063 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [mscorlib]System.Exception>
        // IL_016B: pop 
        // IL_016C: ldloc.1 1
        // IL_016D: ldc.i4.0 0
        // IL_016E: callvirt 0x060008B2 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.ToggleReaderError::set_Error
        // IL_0173: nop 
        // IL_0174: ret 
    }

    public void MatchWithInsufficentCharacters()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, A2, 1E, 00, 06, 0A, 00, 06, 72, A1, 39, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A8, 10, 00, 04, 06, FE, 06, A3, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, A9, 39, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass17_0
        // IL_0000: newobj 0x06001EA2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass17_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700539A1 [110, 117, 108] utf16-bytes=[6E, 00, 75, 00, 6C, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass17_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EA3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass17_0::<MatchWithInsufficentCharacters>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x700539A9 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void MatchWithWrongCharacters()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, A4, 1E, 00, 06, 0A, 00, 06, 72, 27, 3A, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [A9, 10, 00, 04, 06, FE, 06, A5, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 31, 3A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass18_0
        // IL_0000: newobj 0x06001EA4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass18_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053A27 [110, 117, 108, 122] utf16-bytes=[6E, 00, 75, 00, 6C, 00, 7A, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010A9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass18_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EA5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass18_0::<MatchWithWrongCharacters>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70053A31 [69, 114, 114, 111, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 110, 117, 108, 108, 32, 118, 97, 108, 117, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[45, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 6E, 00, 75, 00, 6C, 00, 6C, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void MatchWithNoTrailingSeparator()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, A6, 1E, 00, 06, 0A, 00, 06, 72, 9F, 3A, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [AA, 10, 00, 04, 06, FE, 06, A7, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, AB, 3A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass19_0
        // IL_0000: newobj 0x06001EA6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass19_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053A9F [110, 117, 108, 108, 122] utf16-bytes=[6E, 00, 75, 00, 6C, 00, 6C, 00, 7A, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010AA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass19_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EA7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass19_0::<MatchWithNoTrailingSeparator>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70053AAB [69, 114, 114, 111, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 110, 117, 108, 108, 32, 118, 97, 108, 117, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[45, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 6E, 00, 75, 00, 6C, 00, 6C, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void UnclosedComment()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, A8, 1E, 00, 06, 0A, 00, 06, 72, 19, 3B, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [AB, 10, 00, 04, 06, FE, 06, A9, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 27, 3B, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass20_0
        // IL_0000: newobj 0x06001EA8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass20_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053B19 [47, 42, 32, 115, 100, 102] utf16-bytes=[2F, 00, 2A, 00, 20, 00, 73, 00, 64, 00, 66, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010AB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass20_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EA9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass20_0::<UnclosedComment>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70053B27 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 99, 111, 109, 109, 101, 110, 116, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 54, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 65, 00, 6E, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 36, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void BadCommentStart()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, AA, 1E, 00, 06, 0A, 00, 06, 72, AE, 3B, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [AC, 10, 00, 04, 06, FE, 06, AB, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, B8, 3B, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass21_0
        // IL_0000: newobj 0x06001EAA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass21_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70053BAE [47, 115, 100, 102] utf16-bytes=[2F, 00, 73, 00, 64, 00, 66, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010AC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass21_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EAB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass21_0::<BadCommentStart>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70053BB8 [69, 114, 114, 111, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 99, 111, 109, 109, 101, 110, 116, 46, 32, 69, 120, 112, 101, 99, 116, 101, 100, 58, 32, 42, 44, 32, 103, 111, 116, 32, 115, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[45, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 65, 00, 6E, 00, 74, 00, 2E, 00, 20, 00, 45, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 3A, 00, 20, 00, 2A, 00, 2C, 00, 20, 00, 67, 00, 6F, 00, 74, 00, 20, 00, 73, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void MissingColon()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, AC, 1E, 00, 06, 0A, 00, 72, 49, 3C, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, AD, 10, 00, 04, 06, 7B, AD, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 17, 8C, 72, 00, 00, 01]
        // .code-bytes IL_0030: [06, 7B, AD, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B]
        // .code-bytes IL_0048: [AD, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 1A, 8C, 72, 00, 00, 01, 06, 7B, AD, 10, 00, 04, 6F, 53]
        // .code-bytes IL_0060: [02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, AD, 10, 00, 04, 6F, 72, 01, 00]
        // .code-bytes IL_0078: [0A, 26, 1F, 0A, 8C, 72, 00, 00, 01, 06, 7B, AD, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00]
        // .code-bytes IL_0090: [01, 28, C7, 00, 00, 0A, 00, 06, FE, 06, AD, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00]
        // .code-bytes IL_00A8: [01, 25, 16, 72, 85, 3C, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0
        // .local [1] string
        // IL_0000: newobj 0x06001EAC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053C49 [123, 13, 10, 32, 32, 32, 32, 34, 65, 34, 32, 58, 32, 116, 114, 117, 101, 44, 13, 10, 32, 32, 32, 32, 34, 66, 34, 32, 34] utf16-bytes=[7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 22, 00, 41, 00, 22, 00, 20, 00, 3A, 00, 20, 00, 74, 00, 72, 00, 75, 00, 65, 00, 2C, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 22, 00, 42, 00, 22, 00, 20, 00, 22, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010AD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x040010AD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::reader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: pop 
        // IL_002A: ldc.i4.1 1
        // IL_002B: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0030: ldloc.0 0
        // IL_0031: ldfld 0x040010AD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::reader
        // IL_0036: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_003B: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0040: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0045: nop 
        // IL_0046: ldloc.0 0
        // IL_0047: ldfld 0x040010AD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::reader
        // IL_004C: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0051: pop 
        // IL_0052: ldc.i4.4 4
        // IL_0053: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0058: ldloc.0 0
        // IL_0059: ldfld 0x040010AD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::reader
        // IL_005E: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_0063: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0068: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_006D: nop 
        // IL_006E: ldloc.0 0
        // IL_006F: ldfld 0x040010AD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::reader
        // IL_0074: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0079: pop 
        // IL_007A: ldc.i4.s 10
        // IL_007C: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0081: ldloc.0 0
        // IL_0082: ldfld 0x040010AD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::reader
        // IL_0087: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_008C: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0091: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0096: nop 
        // IL_0097: ldloc.0 0
        // IL_0098: ldftn 0x06001EAD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass22_0::<MissingColon>b__0
        // IL_009E: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_00A3: ldc.i4.1 1
        // IL_00A4: newarr 0x01000181 [mscorlib]System.String
        // IL_00A9: dup 
        // IL_00AA: ldc.i4.0 0
        // IL_00AB: ldstr 0x70053C85 [73, 110, 118, 97, 108, 105, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 97, 102, 116, 101, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 112, 114, 111, 112, 101, 114, 116, 121, 32, 110, 97, 109, 101, 46, 32, 69, 120, 112, 101, 99, 116, 101, 100, 32, 39, 58, 39, 32, 98, 117, 116, 32, 103, 111, 116, 58, 32, 34, 46, 32, 80, 97, 116, 104, 32, 39, 65, 39, 44, 32, 108, 105, 110, 101, 32, 51, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 56, 46] utf16-bytes=[49, 00, 6E, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 61, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 70, 00, 72, 00, 6F, 00, 70, 00, 65, 00, 72, 00, 74, 00, 79, 00, 20, 00, 6E, 00, 61, 00, 6D, 00, 65, 00, 2E, 00, 20, 00, 45, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 27, 00, 3A, 00, 27, 00, 20, 00, 62, 00, 75, 00, 74, 00, 20, 00, 67, 00, 6F, 00, 74, 00, 3A, 00, 20, 00, 22, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 41, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 33, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 38, 00, 2E, 00] terminal-flag=Some(1)
        // IL_00B0: stelem.ref 
        // IL_00B1: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_00B6: pop 
        // IL_00B7: ret 
    }

    public void NullTextReader()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        __cil_type_0100005D s1_0 = default;
        __cil_type_0100005D s2_0 = default;
        __cil_type_0100005D v0 = Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E63.__il_field_040010AF;
        if (v0 is not null) {
            __cil_type_0100005D e0_2_0 = v0;
            s2_0 = e0_2_0;
            goto IL_0020;
        } else {
            __cil_type_0100005D e0_1_0 = v0;
            s1_0 = e0_1_0;
            goto IL_0009;
        }
        IL_0009: ;
        global::Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E63 v1 = Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E63.__il_field_040010AE;
        nint v2 = __cil_ldftn_06001EB0;
        __cil_type_0100005D v3 = __cil_newobj_0A000108(v1, v2);
        Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E63.__il_field_040010AF = v3;
        __cil_type_0100005D e1_2_0 = v3;
        s2_0 = e1_2_0;
        IL_0020: ;
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v5 = __cil_newarr_01000181(2);
        string v7 = __cil_ldstr_70027B7C("Value cannot be null.");
        string v8 = System.Environment.get_NewLine();
        string v9 = __cil_ldstr_70053D52("Parameter name: reader");
        string v10 = System.String.Concat(v7, v8, v9);
        v5[0] = v10;
        string v12 = __cil_ldstr_70027BD4("Argument cannot be null.");
        string v13 = System.Environment.get_NewLine();
        string v14 = __cil_ldstr_70053D52("Parameter name: reader");
        string v15 = System.String.Concat(v12, v13, v14);
        v5[1] = v15;
        global::System.ArgumentNullException v16 = __cil_methodspec_call_2B00005A(s2_0, v5);
        return;
    }

    public void ParseConstructorWithBadCharacter()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, B1, 1E, 00, 06, 0A, 00, 72, 80, 3D, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, B0, 10, 00, 04, 06, FE, 06, B2, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, 98, 3D, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass24_0
        // .local [1] string
        // IL_0000: newobj 0x06001EB1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass24_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053D80 [110, 101, 119, 32, 68, 97, 116, 101, 44, 40, 41] utf16-bytes=[6E, 00, 65, 00, 77, 00, 20, 00, 44, 00, 61, 00, 74, 00, 65, 00, 2C, 00, 28, 00, 29, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010B0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass24_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EB2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass24_0::<ParseConstructorWithBadCharacter>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70053D98 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 99, 111, 110, 115, 116, 114, 117, 99, 116, 111, 114, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 56, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 73, 00, 74, 00, 72, 00, 75, 00, 63, 00, 74, 00, 6F, 00, 72, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 38, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ParseConstructorWithUnexpectedEnd()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, B3, 1E, 00, 06, 0A, 00, 72, 39, 3E, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, B1, 10, 00, 04, 06, FE, 06, B4, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, 49, 3E, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass25_0
        // .local [1] string
        // IL_0000: newobj 0x06001EB3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass25_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053E39 [110, 101, 119, 32, 68, 97, 116] utf16-bytes=[6E, 00, 65, 00, 77, 00, 20, 00, 44, 00, 61, 00, 74, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010B1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass25_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EB4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass25_0::<ParseConstructorWithUnexpectedEnd>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70053E49 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 99, 111, 110, 115, 116, 114, 117, 99, 116, 111, 114, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 55, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 73, 00, 74, 00, 72, 00, 75, 00, 63, 00, 74, 00, 6F, 00, 72, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 37, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ParseConstructorWithUnexpectedCharacter()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, B5, 1E, 00, 06, 0A, 00, 72, D8, 3E, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, B2, 10, 00, 04, 06, FE, 06, B6, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, EE, 3E, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass26_0
        // .local [1] string
        // IL_0000: newobj 0x06001EB5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass26_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053ED8 [110, 101, 119, 32, 68, 97, 116, 101, 32, 33] utf16-bytes=[6E, 00, 65, 00, 77, 00, 20, 00, 44, 00, 61, 00, 74, 00, 65, 00, 20, 00, 21, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010B2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass26_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EB6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass26_0::<ParseConstructorWithUnexpectedCharacter>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70053EEE [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 99, 111, 110, 115, 116, 114, 117, 99, 116, 111, 114, 58, 32, 33, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 57, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 73, 00, 74, 00, 72, 00, 75, 00, 63, 00, 74, 00, 6F, 00, 72, 00, 3A, 00, 20, 00, 21, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 39, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ParseAdditionalContent_Comma()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, B7, 1E, 00, 06, 0A, 00, 72, 8F, 3F, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, B3, 10, 00, 04, 06, FE, 06, B8, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, 6F, 2E, 04, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass27_0
        // .local [1] string
        // IL_0000: newobj 0x06001EB7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass27_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053F8F [91, 13, 10, 34, 83, 109, 97, 108, 108, 34, 44, 13, 10, 34, 77, 101, 100, 105, 117, 109, 34, 44, 13, 10, 34, 76, 97, 114, 103, 101, 34, 13, 10, 93, 44] utf16-bytes=[5B, 00, 0D, 00, 0A, 00, 22, 00, 53, 00, 6D, 00, 61, 00, 6C, 00, 6C, 00, 22, 00, 2C, 00, 0D, 00, 0A, 00, 22, 00, 4D, 00, 65, 00, 64, 00, 69, 00, 75, 00, 6D, 00, 22, 00, 2C, 00, 0D, 00, 0A, 00, 22, 00, 4C, 00, 61, 00, 72, 00, 67, 00, 65, 00, 22, 00, 0D, 00, 0A, 00, 5D, 00, 2C, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010B3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass27_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EB8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass27_0::<ParseAdditionalContent_Comma>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70042E6F [65, 100, 100, 105, 116, 105, 111, 110, 97, 108, 32, 116, 101, 120, 116, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 97, 102, 116, 101, 114, 32, 102, 105, 110, 105, 115, 104, 101, 100, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 32, 99, 111, 110, 116, 101, 110, 116, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 53, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[41, 00, 64, 00, 64, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 61, 00, 6C, 00, 20, 00, 74, 00, 65, 00, 78, 00, 74, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 61, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 66, 00, 69, 00, 6E, 00, 69, 00, 73, 00, 68, 00, 65, 00, 64, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 74, 00, 65, 00, 6E, 00, 74, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 35, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ParseAdditionalContent_Text()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, B9, 1E, 00, 06, 0A, 00, 72, D7, 3F, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, B4, 10, 00, 04, 06, 7B, B4, 10, 00, 04, 18, 8D, 9D, 01, 00, 01, 6F, 70, 09, 00, 0A, 00]
        // .code-bytes IL_0030: [06, 7B, B4, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 17, 8C, 83, 01, 00, 01, 06, 7B, B4, 10, 00, 04]
        // .code-bytes IL_0048: [6F, 71, 09, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, B4, 10, 00, 04, 6F, 72]
        // .code-bytes IL_0060: [01, 00, 0A, 26, 18, 8C, 83, 01, 00, 01, 06, 7B, B4, 10, 00, 04, 6F, 71, 09, 00, 0A, 8C, 83, 01]
        // .code-bytes IL_0078: [00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, B4, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 19, 8C, 83, 01]
        // .code-bytes IL_0090: [00, 01, 06, 7B, B4, 10, 00, 04, 6F, 71, 09, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00]
        // .code-bytes IL_00A8: [06, 7B, B4, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 1A, 8C, 83, 01, 00, 01, 06, 7B, B4, 10, 00, 04]
        // .code-bytes IL_00C0: [6F, 71, 09, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, B4, 10, 00, 04, 6F, 72]
        // .code-bytes IL_00D8: [01, 00, 0A, 26, 1B, 8C, 83, 01, 00, 01, 06, 7B, B4, 10, 00, 04, 6F, 71, 09, 00, 0A, 8C, 83, 01]
        // .code-bytes IL_00F0: [00, 01, 28, C7, 00, 00, 0A, 00, 06, FE, 06, BA, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01]
        // .code-bytes IL_0108: [00, 01, 25, 16, 72, 2B, 40, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0
        // .local [1] string
        // IL_0000: newobj 0x06001EB9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70053FD7 [91, 13, 10, 34, 83, 109, 97, 108, 108, 34, 44, 13, 10, 34, 77, 101, 100, 105, 117, 109, 34, 44, 13, 10, 34, 76, 97, 114, 103, 101, 34, 13, 10, 93, 99, 111, 110, 116, 101, 110, 116] utf16-bytes=[5B, 00, 0D, 00, 0A, 00, 22, 00, 53, 00, 6D, 00, 61, 00, 6C, 00, 6C, 00, 22, 00, 2C, 00, 0D, 00, 0A, 00, 22, 00, 4D, 00, 65, 00, 64, 00, 69, 00, 75, 00, 6D, 00, 22, 00, 2C, 00, 0D, 00, 0A, 00, 22, 00, 4C, 00, 61, 00, 72, 00, 67, 00, 65, 00, 22, 00, 0D, 00, 0A, 00, 5D, 00, 63, 00, 6F, 00, 6E, 00, 74, 00, 65, 00, 6E, 00, 74, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_0024: ldc.i4.2 2
        // IL_0025: newarr 0x0100019D [mscorlib]System.Char
        // IL_002A: callvirt 0x0A000970 [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::SetCharBuffer
        // IL_002F: nop 
        // IL_0030: ldloc.0 0
        // IL_0031: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_0036: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_003B: pop 
        // IL_003C: ldc.i4.1 1
        // IL_003D: box 0x01000183 [mscorlib]System.Int32
        // IL_0042: ldloc.0 0
        // IL_0043: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_0048: callvirt 0x0A000971 [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::get_LineNumber
        // IL_004D: box 0x01000183 [mscorlib]System.Int32
        // IL_0052: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0057: nop 
        // IL_0058: ldloc.0 0
        // IL_0059: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_005E: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0063: pop 
        // IL_0064: ldc.i4.2 2
        // IL_0065: box 0x01000183 [mscorlib]System.Int32
        // IL_006A: ldloc.0 0
        // IL_006B: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_0070: callvirt 0x0A000971 [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::get_LineNumber
        // IL_0075: box 0x01000183 [mscorlib]System.Int32
        // IL_007A: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_007F: nop 
        // IL_0080: ldloc.0 0
        // IL_0081: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_0086: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_008B: pop 
        // IL_008C: ldc.i4.3 3
        // IL_008D: box 0x01000183 [mscorlib]System.Int32
        // IL_0092: ldloc.0 0
        // IL_0093: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_0098: callvirt 0x0A000971 [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::get_LineNumber
        // IL_009D: box 0x01000183 [mscorlib]System.Int32
        // IL_00A2: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00A7: nop 
        // IL_00A8: ldloc.0 0
        // IL_00A9: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_00AE: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00B3: pop 
        // IL_00B4: ldc.i4.4 4
        // IL_00B5: box 0x01000183 [mscorlib]System.Int32
        // IL_00BA: ldloc.0 0
        // IL_00BB: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_00C0: callvirt 0x0A000971 [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::get_LineNumber
        // IL_00C5: box 0x01000183 [mscorlib]System.Int32
        // IL_00CA: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00CF: nop 
        // IL_00D0: ldloc.0 0
        // IL_00D1: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_00D6: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00DB: pop 
        // IL_00DC: ldc.i4.5 5
        // IL_00DD: box 0x01000183 [mscorlib]System.Int32
        // IL_00E2: ldloc.0 0
        // IL_00E3: ldfld 0x040010B4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::reader
        // IL_00E8: callvirt 0x0A000971 [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::get_LineNumber
        // IL_00ED: box 0x01000183 [mscorlib]System.Int32
        // IL_00F2: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00F7: nop 
        // IL_00F8: ldloc.0 0
        // IL_00F9: ldftn 0x06001EBA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass28_0::<ParseAdditionalContent_Text>b__0
        // IL_00FF: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0104: ldc.i4.1 1
        // IL_0105: newarr 0x01000181 [mscorlib]System.String
        // IL_010A: dup 
        // IL_010B: ldc.i4.0 0
        // IL_010C: ldstr 0x7005402B [65, 100, 100, 105, 116, 105, 111, 110, 97, 108, 32, 116, 101, 120, 116, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 97, 102, 116, 101, 114, 32, 102, 105, 110, 105, 115, 104, 101, 100, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 32, 99, 111, 110, 116, 101, 110, 116, 58, 32, 99, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 53, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[41, 00, 64, 00, 64, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 61, 00, 6C, 00, 20, 00, 74, 00, 65, 00, 78, 00, 74, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 61, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 66, 00, 69, 00, 6E, 00, 69, 00, 73, 00, 68, 00, 65, 00, 64, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 74, 00, 65, 00, 6E, 00, 74, 00, 3A, 00, 20, 00, 63, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 35, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0111: stelem.ref 
        // IL_0112: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0117: pop 
        // IL_0118: ret 
    }

    public void ParseAdditionalContent_WhitespaceThenText()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, BB, 1E, 00, 06, 0A, 00, 72, EE, 40, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, B5, 10, 00, 04, 06, FE, 06, BC, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, FC, 40, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass29_0
        // .local [1] string
        // IL_0000: newobj 0x06001EBB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass29_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700540EE [39, 104, 105, 39, 32, 97] utf16-bytes=[27, 00, 68, 00, 69, 00, 27, 00, 20, 00, 61, 00] terminal-flag=Some(1)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010B5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass29_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EBC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass29_0::<ParseAdditionalContent_WhitespaceThenText>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x700540FC [65, 100, 100, 105, 116, 105, 111, 110, 97, 108, 32, 116, 101, 120, 116, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 97, 102, 116, 101, 114, 32, 102, 105, 110, 105, 115, 104, 101, 100, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 32, 99, 111, 110, 116, 101, 110, 116, 58, 32, 97, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 53, 46] utf16-bytes=[41, 00, 64, 00, 64, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 61, 00, 6C, 00, 20, 00, 74, 00, 65, 00, 78, 00, 74, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 61, 00, 66, 00, 74, 00, 65, 00, 72, 00, 20, 00, 66, 00, 69, 00, 6E, 00, 69, 00, 73, 00, 68, 00, 65, 00, 64, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 63, 00, 6F, 00, 6E, 00, 74, 00, 65, 00, 6E, 00, 74, 00, 3A, 00, 20, 00, 61, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 35, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ParseIncompleteCommentSeparator()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, BD, 1E, 00, 06, 0A, 00, 06, 72, BF, 41, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [B6, 10, 00, 04, 06, FE, 06, BE, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, CB, 41, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass30_0
        // IL_0000: newobj 0x06001EBD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass30_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700541BF [116, 114, 117, 101, 47] utf16-bytes=[74, 00, 72, 00, 75, 00, 65, 00, 2F, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010B6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass30_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EBE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass30_0::<ParseIncompleteCommentSeparator>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x700541CB [69, 114, 114, 111, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 98, 111, 111, 108, 101, 97, 110, 32, 118, 97, 108, 117, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[45, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 62, 00, 6F, 00, 6F, 00, 6C, 00, 65, 00, 61, 00, 6E, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadBadCharInArray()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, BF, 1E, 00, 06, 0A, 00, 06, 72, 3F, 42, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [B7, 10, 00, 04, 06, 7B, B7, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 06, FE, 06, C0, 1E, 00, 06, 73]
        // .code-bytes IL_0030: [08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 45, 42, 05, 70, A2, 28, 12, 00, 00, 2B, 26]
        // .code-bytes IL_0048: [2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass31_0
        // IL_0000: newobj 0x06001EBF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass31_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x7005423F [91, 125] utf16-bytes=[5B, 00, 7D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010B7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass31_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010B7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass31_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.0 0
        // IL_0029: ldftn 0x06001EC0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass31_0::<ReadBadCharInArray>b__0
        // IL_002F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0034: ldc.i4.1 1
        // IL_0035: newarr 0x01000181 [mscorlib]System.String
        // IL_003A: dup 
        // IL_003B: ldc.i4.0 0
        // IL_003C: ldstr 0x70054245 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 125, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 7D, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0041: stelem.ref 
        // IL_0042: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0047: pop 
        // IL_0048: ret 
    }

    public void ReadAsBytesNoContentWrappedObject()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, C1, 1E, 00, 06, 0A, 00, 06, 72, F2, 42, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [B8, 10, 00, 04, 06, FE, 06, C2, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 74, 34, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass32_0
        // IL_0000: newobj 0x06001EC1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass32_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700542F2 [123] utf16-bytes=[7B, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010B8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass32_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EC2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass32_0::<ReadAsBytesNoContentWrappedObject>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70053474 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadBytesEmptyWrappedObject()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, C3, 1E, 00, 06, 0A, 00, 06, 72, 93, 41, 00, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [B9, 10, 00, 04, 06, FE, 06, C4, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, F6, 42, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass33_0
        // IL_0000: newobj 0x06001EC3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass33_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70004193 [123, 125] utf16-bytes=[7B, 00, 7D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010B9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass33_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EC4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass33_0::<ReadBytesEmptyWrappedObject>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x700542F6 [69, 114, 114, 111, 114, 32, 114, 101, 97, 100, 105, 110, 103, 32, 98, 121, 116, 101, 115, 46, 32, 85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 111, 107, 101, 110, 58, 32, 83, 116, 97, 114, 116, 79, 98, 106, 101, 99, 116, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[45, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 62, 00, 79, 00, 74, 00, 65, 00, 73, 00, 2E, 00, 20, 00, 55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 6B, 00, 65, 00, 6E, 00, 3A, 00, 20, 00, 53, 00, 74, 00, 61, 00, 72, 00, 74, 00, 4F, 00, 62, 00, 6A, 00, 65, 00, 63, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadIntegerWithError()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, C5, 1E, 00, 06, 0A, 00, 72, 99, 43, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, BA, 10, 00, 04, 06, 7B, BA, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 17]
        // .code-bytes IL_0030: [8C, 72, 00, 00, 01, 06, 7B, BA, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00]
        // .code-bytes IL_0048: [00, 0A, 00, 06, 7B, BA, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 1A, 8C, 72, 00]
        // .code-bytes IL_0060: [00, 01, 06, 7B, BA, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00]
        // .code-bytes IL_0078: [06, FE, 06, C6, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 0F, 44, 05]
        // .code-bytes IL_0090: [70, A2, 28, 12, 00, 00, 2B, 26, 06, 7B, BA, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A]
        // .code-bytes IL_00A8: [00, 1F, 0D, 8C, 72, 00, 00, 01, 06, 7B, BA, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01]
        // .code-bytes IL_00C0: [28, C7, 00, 00, 0A, 00, 06, 7B, BA, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, DF, 01, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0
        // .local [1] string
        // IL_0000: newobj 0x06001EC5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70054399 [123, 13, 10, 32, 32, 32, 32, 67, 104, 105, 108, 100, 73, 100, 58, 32, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 13, 10, 125] utf16-bytes=[7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 43, 00, 68, 00, 69, 00, 6C, 00, 64, 00, 49, 00, 64, 00, 3A, 00, 20, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 0D, 00, 0A, 00, 7D, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldc.i4.1 1
        // IL_0030: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0035: ldloc.0 0
        // IL_0036: ldfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_003B: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_0040: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0045: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_004A: nop 
        // IL_004B: ldloc.0 0
        // IL_004C: ldfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_0051: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0056: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_005B: nop 
        // IL_005C: ldc.i4.4 4
        // IL_005D: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0062: ldloc.0 0
        // IL_0063: ldfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_0068: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_006D: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0072: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0077: nop 
        // IL_0078: ldloc.0 0
        // IL_0079: ldftn 0x06001EC6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::<ReadIntegerWithError>b__0
        // IL_007F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0084: ldc.i4.1 1
        // IL_0085: newarr 0x01000181 [mscorlib]System.String
        // IL_008A: dup 
        // IL_008B: ldc.i4.0 0
        // IL_008C: ldstr 0x7005440F [74, 83, 79, 78, 32, 105, 110, 116, 101, 103, 101, 114, 32, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 32, 105, 115, 32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 32, 111, 114, 32, 115, 109, 97, 108, 108, 32, 102, 111, 114, 32, 97, 110, 32, 73, 110, 116, 51, 50, 46, 32, 80, 97, 116, 104, 32, 39, 67, 104, 105, 108, 100, 73, 100, 39, 44, 32, 108, 105, 110, 101, 32, 50, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 53, 50, 46] utf16-bytes=[4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 20, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 20, 00, 69, 00, 73, 00, 20, 00, 74, 00, 6F, 00, 6F, 00, 20, 00, 6C, 00, 61, 00, 72, 00, 67, 00, 65, 00, 20, 00, 6F, 00, 72, 00, 20, 00, 73, 00, 6D, 00, 61, 00, 6C, 00, 6C, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 49, 00, 6E, 00, 74, 00, 33, 00, 32, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 43, 00, 68, 00, 69, 00, 6C, 00, 64, 00, 49, 00, 64, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 32, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 35, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0091: stelem.ref 
        // IL_0092: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0097: pop 
        // IL_0098: ldloc.0 0
        // IL_0099: ldfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_009E: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00A3: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00A8: nop 
        // IL_00A9: ldc.i4.s 13
        // IL_00AB: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_00B0: ldloc.0 0
        // IL_00B1: ldfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_00B6: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_00BB: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_00C0: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00C5: nop 
        // IL_00C6: ldloc.0 0
        // IL_00C7: ldfld 0x040010BA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass34_0::jsonTextReader
        // IL_00CC: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00D1: call 0x0A0001DF [nunit.framework]NUnit.Framework.Assert::IsFalse
        // IL_00D6: nop 
        // IL_00D7: ret 
    }

    public void ReadIntegerWithErrorInArray()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, C7, 1E, 00, 06, 0A, 00, 72, 0C, 45, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, BB, 10, 00, 04, 06, 7B, BB, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 18]
        // .code-bytes IL_0030: [8C, 72, 00, 00, 01, 06, 7B, BB, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00]
        // .code-bytes IL_0048: [00, 0A, 00, 06, FE, 06, C8, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72]
        // .code-bytes IL_0060: [95, 45, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 06, FE, 06, C9, 1E, 00, 06, 73, 08, 01, 00, 0A, 17]
        // .code-bytes IL_0078: [8D, 81, 01, 00, 01, 25, 16, 72, 8A, 46, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 06, FE, 06, CA, 1E]
        // .code-bytes IL_0090: [00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 21, 47, 05, 70, A2, 28, 12, 00]
        // .code-bytes IL_00A8: [00, 2B, 26, 06, FE, 06, CB, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72]
        // .code-bytes IL_00C0: [D4, 47, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 06, 7B, BB, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6]
        // .code-bytes IL_00D8: [00, 00, 0A, 00, 1F, 0E, 8C, 72, 00, 00, 01, 06, 7B, BB, 10, 00, 04, 6F, 53, 02, 00, 0A, 8C, 72]
        // .code-bytes IL_00F0: [00, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, BB, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, DF, 01, 00]
        // .code-bytes IL_0108: [0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0
        // .local [1] string
        // IL_0000: newobj 0x06001EC7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x7005450C [91, 13, 10, 32, 32, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 44, 13, 10, 32, 32, 51, 46, 51, 44, 13, 10, 32, 32, 44, 13, 10, 32, 32, 48, 102, 13, 10, 93] utf16-bytes=[5B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 2C, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 33, 00, 2E, 00, 33, 00, 2C, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 2C, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 30, 00, 66, 00, 0D, 00, 0A, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010BB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::jsonTextReader
        // IL_001E: ldloc.0 0
        // IL_001F: ldfld 0x040010BB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::jsonTextReader
        // IL_0024: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0029: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002E: nop 
        // IL_002F: ldc.i4.2 2
        // IL_0030: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0035: ldloc.0 0
        // IL_0036: ldfld 0x040010BB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::jsonTextReader
        // IL_003B: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_0040: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0045: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_004A: nop 
        // IL_004B: ldloc.0 0
        // IL_004C: ldftn 0x06001EC8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::<ReadIntegerWithErrorInArray>b__0
        // IL_0052: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0057: ldc.i4.1 1
        // IL_0058: newarr 0x01000181 [mscorlib]System.String
        // IL_005D: dup 
        // IL_005E: ldc.i4.0 0
        // IL_005F: ldstr 0x70054595 [74, 83, 79, 78, 32, 105, 110, 116, 101, 103, 101, 114, 32, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 32, 105, 115, 32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 32, 111, 114, 32, 115, 109, 97, 108, 108, 32, 102, 111, 114, 32, 97, 110, 32, 73, 110, 116, 51, 50, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 50, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 49, 46] utf16-bytes=[4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 20, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 33, 00, 20, 00, 69, 00, 73, 00, 20, 00, 74, 00, 6F, 00, 6F, 00, 20, 00, 6C, 00, 61, 00, 72, 00, 67, 00, 65, 00, 20, 00, 6F, 00, 72, 00, 20, 00, 73, 00, 6D, 00, 61, 00, 6C, 00, 6C, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 49, 00, 6E, 00, 74, 00, 33, 00, 32, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 32, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0064: stelem.ref 
        // IL_0065: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_006A: pop 
        // IL_006B: ldloc.0 0
        // IL_006C: ldftn 0x06001EC9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::<ReadIntegerWithErrorInArray>b__1
        // IL_0072: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0077: ldc.i4.1 1
        // IL_0078: newarr 0x01000181 [mscorlib]System.String
        // IL_007D: dup 
        // IL_007E: ldc.i4.0 0
        // IL_007F: ldstr 0x7005468A [73, 110, 112, 117, 116, 32, 115, 116, 114, 105, 110, 103, 32, 39, 51, 46, 51, 39, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 118, 97, 108, 105, 100, 32, 105, 110, 116, 101, 103, 101, 114, 46, 32, 80, 97, 116, 104, 32, 39, 91, 49, 93, 39, 44, 32, 108, 105, 110, 101, 32, 51, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 53, 46] utf16-bytes=[49, 00, 6E, 00, 70, 00, 75, 00, 74, 00, 20, 00, 73, 00, 74, 00, 72, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 27, 00, 33, 00, 2E, 00, 33, 00, 27, 00, 20, 00, 69, 00, 73, 00, 20, 00, 6E, 00, 6F, 00, 74, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 31, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 33, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 35, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0084: stelem.ref 
        // IL_0085: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_008A: pop 
        // IL_008B: ldloc.0 0
        // IL_008C: ldftn 0x06001ECA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::<ReadIntegerWithErrorInArray>b__2
        // IL_0092: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0097: ldc.i4.1 1
        // IL_0098: newarr 0x01000181 [mscorlib]System.String
        // IL_009D: dup 
        // IL_009E: ldc.i4.0 0
        // IL_009F: ldstr 0x70054721 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 50, 93, 39, 44, 32, 108, 105, 110, 101, 32, 52, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 32, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 34, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_00A4: stelem.ref 
        // IL_00A5: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_00AA: pop 
        // IL_00AB: ldloc.0 0
        // IL_00AC: ldftn 0x06001ECB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::<ReadIntegerWithErrorInArray>b__3
        // IL_00B2: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_00B7: ldc.i4.1 1
        // IL_00B8: newarr 0x01000181 [mscorlib]System.String
        // IL_00BD: dup 
        // IL_00BE: ldc.i4.0 0
        // IL_00BF: ldstr 0x700547D4 [73, 110, 112, 117, 116, 32, 115, 116, 114, 105, 110, 103, 32, 39, 48, 102, 39, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 118, 97, 108, 105, 100, 32, 105, 110, 116, 101, 103, 101, 114, 46, 32, 80, 97, 116, 104, 32, 39, 91, 51, 93, 39, 44, 32, 108, 105, 110, 101, 32, 53, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[49, 00, 6E, 00, 70, 00, 75, 00, 74, 00, 20, 00, 73, 00, 74, 00, 72, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 27, 00, 30, 00, 66, 00, 27, 00, 20, 00, 69, 00, 73, 00, 20, 00, 6E, 00, 6F, 00, 74, 00, 20, 00, 61, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 69, 00, 64, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 33, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 35, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_00C4: stelem.ref 
        // IL_00C5: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_00CA: pop 
        // IL_00CB: ldloc.0 0
        // IL_00CC: ldfld 0x040010BB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::jsonTextReader
        // IL_00D1: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00D6: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00DB: nop 
        // IL_00DC: ldc.i4.s 14
        // IL_00DE: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_00E3: ldloc.0 0
        // IL_00E4: ldfld 0x040010BB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::jsonTextReader
        // IL_00E9: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_00EE: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_00F3: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00F8: nop 
        // IL_00F9: ldloc.0 0
        // IL_00FA: ldfld 0x040010BB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass35_0::jsonTextReader
        // IL_00FF: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0104: call 0x0A0001DF [nunit.framework]NUnit.Framework.Assert::IsFalse
        // IL_0109: nop 
        // IL_010A: ret 
    }

    public void ReadBytesWithError()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 2
        // .initlocals true
        // .code-bytes IL_0000: [00, 72, 69, 48, 05, 70, 0A, 06, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 0B, 07, 6F, 72, 01, 00]
        // .code-bytes IL_0018: [0A, 28, D6, 00, 00, 0A, 00, 17, 8C, 72, 00, 00, 01, 07, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01]
        // .code-bytes IL_0030: [28, C7, 00, 00, 0A, 00, 07, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 1A, 8C, 72, 00, 00, 01]
        // .code-bytes IL_0048: [07, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00, 00, 07, 6F, 62, 02, 00, 0A]
        // .code-bytes IL_0060: [26, 00, DE, 05, 26, 00, 00, DE, 00, 07, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 1F, 0D, 8C]
        // .code-bytes IL_0078: [72, 00, 00, 01, 07, 6F, 53, 02, 00, 0A, 8C, 72, 00, 00, 01, 28, C7, 00, 00, 0A, 00, 07, 6F, 72]
        // .code-bytes IL_0090: [01, 00, 0A, 28, DF, 01, 00, 0A, 00, 2A]
        // .local [0] string
        // .local [1] class [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader
        // IL_0000: nop 
        // IL_0001: ldstr 0x70054869 [123, 13, 10, 32, 32, 32, 32, 67, 104, 105, 108, 100, 73, 100, 58, 32, 39, 49, 50, 51, 39, 13, 10, 125] utf16-bytes=[7B, 00, 0D, 00, 0A, 00, 20, 00, 20, 00, 20, 00, 20, 00, 43, 00, 68, 00, 69, 00, 6C, 00, 64, 00, 49, 00, 64, 00, 3A, 00, 20, 00, 27, 00, 31, 00, 32, 00, 33, 00, 27, 00, 0D, 00, 0A, 00, 7D, 00] terminal-flag=Some(1)
        // IL_0006: stloc.0 0
        // IL_0007: ldloc.0 0
        // IL_0008: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_000D: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0012: stloc.1 1
        // IL_0013: ldloc.1 1
        // IL_0014: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0019: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_001E: nop 
        // IL_001F: ldc.i4.1 1
        // IL_0020: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0025: ldloc.1 1
        // IL_0026: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_002B: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0030: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0035: nop 
        // IL_0036: ldloc.1 1
        // IL_0037: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_003C: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0041: nop 
        // IL_0042: ldc.i4.4 4
        // IL_0043: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0048: ldloc.1 1
        // IL_0049: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_004E: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0053: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0058: nop 
        // IL_0059: nop 
        // IL_005A: ldloc.1 1
        // IL_005B: callvirt 0x0A000262 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsBytes
        // IL_0060: pop 
        // IL_0061: nop 
        // IL_0062: leave.s IL_0069
        // IL_0064: pop 
        // IL_0065: nop 
        // IL_0066: nop 
        // IL_0067: leave.s IL_0069
        // IL_0069: ldloc.1 1
        // IL_006A: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_006F: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0074: nop 
        // IL_0075: ldc.i4.s 13
        // IL_0077: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_007C: ldloc.1 1
        // IL_007D: callvirt 0x0A000253 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_TokenType
        // IL_0082: box 0x01000072 [Newtonsoft.Json]Newtonsoft.Json.JsonToken
        // IL_0087: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_008C: nop 
        // IL_008D: ldloc.1 1
        // IL_008E: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0093: call 0x0A0001DF [nunit.framework]NUnit.Framework.Assert::IsFalse
        // IL_0098: nop 
        // IL_0099: ret 
        // .eh-raw ExceptionHandler { kind: Catch(Token(TypeRef[109])), try_offset: 89, try_length: 11, handler_offset: 100, handler_length: 5, raw_flags: 0 }
        // .try IL_0059..IL_0064 catch 0x0100006D [mscorlib]System.FormatException IL_0064..IL_0069
    }

    public void ReadInt32Overflow()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, CC, 1E, 00, 06, 0A, 00, 20, FF, FF, FF, 7F, 6A, 0B, 06, 12, 01, 28, CA, 01, 00, 0A, 28, 72]
        // .code-bytes IL_0018: [09, 00, 0A, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D, BC, 10, 00, 04, 06, 7B, BC, 10, 00, 04]
        // .code-bytes IL_0030: [6F, 72, 01, 00, 0A, 26, D0, 90, 01, 00, 01, 28, 4E, 01, 00, 0A, 06, 7B, BC, 10, 00, 04, 6F, 73]
        // .code-bytes IL_0048: [01, 00, 0A, 28, C7, 00, 00, 0A, 00, 17, 0C, 2B, 52, 73, CD, 1E, 00, 06, 0D, 09, 06, 7D, BE, 10]
        // .code-bytes IL_0060: [00, 04, 00, 09, 08, 6A, 07, 58, 7D, BD, 10, 00, 04, 09, FE, 06, CE, 1E, 00, 06, 73, 08, 01, 00]
        // .code-bytes IL_0078: [0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 9B, 48, 05, 70, 09, 7B, BD, 10, 00, 04, 8C, 90, 01, 00]
        // .code-bytes IL_0090: [01, 72, B7, 48, 05, 70, 28, 41, 01, 00, 0A, A2, 28, 12, 00, 00, 2B, 26, 00, 08, 17, 58, 0C, 08]
        // .code-bytes IL_00A8: [20, E8, 03, 00, 00, FE, 04, 13, 04, 11, 04, 2D, A0, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_0
        // .local [1] int64
        // .local [2] int32
        // .local [3] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1
        // .local [4] bool
        // IL_0000: newobj 0x06001ECC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldc.i4 2147483647
        // IL_000C: conv.i8 
        // IL_000D: stloc.1 1
        // IL_000E: ldloc.0 0
        // IL_000F: ldloca.s 1
        // IL_0011: call 0x0A0001CA [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture
        // IL_0016: call 0x0A000972 [mscorlib]System.Int64::ToString
        // IL_001B: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0020: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0025: stfld 0x040010BC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_0::reader
        // IL_002A: ldloc.0 0
        // IL_002B: ldfld 0x040010BC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_0::reader
        // IL_0030: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0035: pop 
        // IL_0036: ldtoken 0x01000190 [mscorlib]System.Int64
        // IL_003B: call 0x0A00014E [mscorlib]System.Type::GetTypeFromHandle
        // IL_0040: ldloc.0 0
        // IL_0041: ldfld 0x040010BC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_0::reader
        // IL_0046: callvirt 0x0A000173 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_ValueType
        // IL_004B: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0050: nop 
        // IL_0051: ldc.i4.1 1
        // IL_0052: stloc.2 2
        // IL_0053: br.s IL_00A7
        // IL_0055: newobj 0x06001ECD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::.ctor
        // IL_005A: stloc.3 3
        // IL_005B: ldloc.3 3
        // IL_005C: ldloc.0 0
        // IL_005D: stfld 0x040010BE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::CS$<>8__locals1
        // IL_0062: nop 
        // IL_0063: ldloc.3 3
        // IL_0064: ldloc.2 2
        // IL_0065: conv.i8 
        // IL_0066: ldloc.1 1
        // IL_0067: add 
        // IL_0068: stfld 0x040010BD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::total
        // IL_006D: ldloc.3 3
        // IL_006E: ldftn 0x06001ECE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::<ReadInt32Overflow>b__0
        // IL_0074: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0079: ldc.i4.1 1
        // IL_007A: newarr 0x01000181 [mscorlib]System.String
        // IL_007F: dup 
        // IL_0080: ldc.i4.0 0
        // IL_0081: ldstr 0x7005489B [74, 83, 79, 78, 32, 105, 110, 116, 101, 103, 101, 114, 32] utf16-bytes=[4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 20, 00] terminal-flag=Some(0)
        // IL_0086: ldloc.3 3
        // IL_0087: ldfld 0x040010BD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::total
        // IL_008C: box 0x01000190 [mscorlib]System.Int64
        // IL_0091: ldstr 0x700548B7 [32, 105, 115, 32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 32, 111, 114, 32, 115, 109, 97, 108, 108, 32, 102, 111, 114, 32, 97, 110, 32, 73, 110, 116, 51, 50, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 48, 46] utf16-bytes=[20, 00, 69, 00, 73, 00, 20, 00, 74, 00, 6F, 00, 6F, 00, 20, 00, 6C, 00, 61, 00, 72, 00, 67, 00, 65, 00, 20, 00, 6F, 00, 72, 00, 20, 00, 73, 00, 6D, 00, 61, 00, 6C, 00, 6C, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 49, 00, 6E, 00, 74, 00, 33, 00, 32, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 30, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0096: call 0x0A000141 [mscorlib]System.String::Concat
        // IL_009B: stelem.ref 
        // IL_009C: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_00A1: pop 
        // IL_00A2: nop 
        // IL_00A3: ldloc.2 2
        // IL_00A4: ldc.i4.1 1
        // IL_00A5: add 
        // IL_00A6: stloc.2 2
        // IL_00A7: ldloc.2 2
        // IL_00A8: ldc.i4 1000
        // IL_00AD: clt 
        // IL_00AF: stloc.s 4
        // IL_00B1: ldloc.s 4
        // IL_00B3: brtrue.s IL_0055
        // IL_00B5: ret 
    }

    public void ReadInt32Overflow_Negative()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 7
        // .initlocals true
        // .code-bytes IL_0000: [73, CF, 1E, 00, 06, 0A, 00, 20, 00, 00, 00, 80, 6A, 0B, 06, 12, 01, 28, CA, 01, 00, 0A, 28, 72]
        // .code-bytes IL_0018: [09, 00, 0A, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D, BF, 10, 00, 04, 06, 7B, BF, 10, 00, 04]
        // .code-bytes IL_0030: [6F, 72, 01, 00, 0A, 26, D0, 90, 01, 00, 01, 28, 4E, 01, 00, 0A, 06, 7B, BF, 10, 00, 04, 6F, 73]
        // .code-bytes IL_0048: [01, 00, 0A, 28, C7, 00, 00, 0A, 00, 07, 8C, 90, 01, 00, 01, 06, 7B, BF, 10, 00, 04, 6F, 54, 02]
        // .code-bytes IL_0060: [00, 0A, 28, C7, 00, 00, 0A, 00, 17, 0C, 2B, 53, 73, D0, 1E, 00, 06, 0D, 09, 06, 7D, C1, 10, 00]
        // .code-bytes IL_0078: [04, 00, 09, 08, 65, 6A, 07, 58, 7D, C0, 10, 00, 04, 09, FE, 06, D1, 1E, 00, 06, 73, 08, 01, 00]
        // .code-bytes IL_0090: [0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 9B, 48, 05, 70, 09, 7B, C0, 10, 00, 04, 8C, 90, 01, 00]
        // .code-bytes IL_00A8: [01, 72, 3E, 49, 05, 70, 28, 41, 01, 00, 0A, A2, 28, 12, 00, 00, 2B, 26, 00, 08, 17, 58, 0C, 08]
        // .code-bytes IL_00C0: [20, E8, 03, 00, 00, FE, 04, 13, 04, 11, 04, 2D, 9F, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0
        // .local [1] int64
        // .local [2] int32
        // .local [3] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1
        // .local [4] bool
        // IL_0000: newobj 0x06001ECF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldc.i4 -2147483648
        // IL_000C: conv.i8 
        // IL_000D: stloc.1 1
        // IL_000E: ldloc.0 0
        // IL_000F: ldloca.s 1
        // IL_0011: call 0x0A0001CA [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture
        // IL_0016: call 0x0A000972 [mscorlib]System.Int64::ToString
        // IL_001B: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0020: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0025: stfld 0x040010BF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0::reader
        // IL_002A: ldloc.0 0
        // IL_002B: ldfld 0x040010BF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0::reader
        // IL_0030: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0035: pop 
        // IL_0036: ldtoken 0x01000190 [mscorlib]System.Int64
        // IL_003B: call 0x0A00014E [mscorlib]System.Type::GetTypeFromHandle
        // IL_0040: ldloc.0 0
        // IL_0041: ldfld 0x040010BF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0::reader
        // IL_0046: callvirt 0x0A000173 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_ValueType
        // IL_004B: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0050: nop 
        // IL_0051: ldloc.1 1
        // IL_0052: box 0x01000190 [mscorlib]System.Int64
        // IL_0057: ldloc.0 0
        // IL_0058: ldfld 0x040010BF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0::reader
        // IL_005D: callvirt 0x0A000254 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Value
        // IL_0062: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0067: nop 
        // IL_0068: ldc.i4.1 1
        // IL_0069: stloc.2 2
        // IL_006A: br.s IL_00BF
        // IL_006C: newobj 0x06001ED0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::.ctor
        // IL_0071: stloc.3 3
        // IL_0072: ldloc.3 3
        // IL_0073: ldloc.0 0
        // IL_0074: stfld 0x040010C1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::CS$<>8__locals1
        // IL_0079: nop 
        // IL_007A: ldloc.3 3
        // IL_007B: ldloc.2 2
        // IL_007C: neg 
        // IL_007D: conv.i8 
        // IL_007E: ldloc.1 1
        // IL_007F: add 
        // IL_0080: stfld 0x040010C0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::total
        // IL_0085: ldloc.3 3
        // IL_0086: ldftn 0x06001ED1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::<ReadInt32Overflow_Negative>b__0
        // IL_008C: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0091: ldc.i4.1 1
        // IL_0092: newarr 0x01000181 [mscorlib]System.String
        // IL_0097: dup 
        // IL_0098: ldc.i4.0 0
        // IL_0099: ldstr 0x7005489B [74, 83, 79, 78, 32, 105, 110, 116, 101, 103, 101, 114, 32] utf16-bytes=[4A, 00, 53, 00, 4F, 00, 4E, 00, 20, 00, 69, 00, 6E, 00, 74, 00, 65, 00, 67, 00, 65, 00, 72, 00, 20, 00] terminal-flag=Some(0)
        // IL_009E: ldloc.3 3
        // IL_009F: ldfld 0x040010C0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::total
        // IL_00A4: box 0x01000190 [mscorlib]System.Int64
        // IL_00A9: ldstr 0x7005493E [32, 105, 115, 32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 32, 111, 114, 32, 115, 109, 97, 108, 108, 32, 102, 111, 114, 32, 97, 110, 32, 73, 110, 116, 51, 50, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 49, 46] utf16-bytes=[20, 00, 69, 00, 73, 00, 20, 00, 74, 00, 6F, 00, 6F, 00, 20, 00, 6C, 00, 61, 00, 72, 00, 67, 00, 65, 00, 20, 00, 6F, 00, 72, 00, 20, 00, 73, 00, 6D, 00, 61, 00, 6C, 00, 6C, 00, 20, 00, 66, 00, 6F, 00, 72, 00, 20, 00, 61, 00, 6E, 00, 20, 00, 49, 00, 6E, 00, 74, 00, 33, 00, 32, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_00AE: call 0x0A000141 [mscorlib]System.String::Concat
        // IL_00B3: stelem.ref 
        // IL_00B4: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_00B9: pop 
        // IL_00BA: nop 
        // IL_00BB: ldloc.2 2
        // IL_00BC: ldc.i4.1 1
        // IL_00BD: add 
        // IL_00BE: stloc.2 2
        // IL_00BF: ldloc.2 2
        // IL_00C0: ldc.i4 1000
        // IL_00C5: clt 
        // IL_00C7: stloc.s 4
        // IL_00C9: ldloc.s 4
        // IL_00CB: brtrue.s IL_006C
        // IL_00CD: ret 
    }

    public void ReadAsString_Null_AdditionalBadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, D2, 1E, 00, 06, 0A, 00, 72, C5, 49, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C2, 10, 00, 04, 06, FE, 06, D3, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, AB, 3A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass39_0
        // .local [1] string
        // IL_0000: newobj 0x06001ED2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass39_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700549C5 [110, 117, 108, 108, 108, 108, 108, 108] utf16-bytes=[6E, 00, 75, 00, 6C, 00, 6C, 00, 6C, 00, 6C, 00, 6C, 00, 6C, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass39_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001ED3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass39_0::<ReadAsString_Null_AdditionalBadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70053AAB [69, 114, 114, 111, 114, 32, 112, 97, 114, 115, 105, 110, 103, 32, 110, 117, 108, 108, 32, 118, 97, 108, 117, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[45, 00, 72, 00, 72, 00, 6F, 00, 72, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 6E, 00, 75, 00, 6C, 00, 6C, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsBoolean_AdditionalBadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, D4, 1E, 00, 06, 0A, 00, 72, D7, 49, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C3, 10, 00, 04, 06, FE, 06, D5, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, EB, 49, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass40_0
        // .local [1] string
        // IL_0000: newobj 0x06001ED4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass40_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700549D7 [102, 97, 108, 115, 101, 101, 101, 101, 101] utf16-bytes=[66, 00, 61, 00, 6C, 00, 73, 00, 65, 00, 65, 00, 65, 00, 65, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass40_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001ED5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass40_0::<ReadAsBoolean_AdditionalBadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x700549EB [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 53, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 35, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsString_AdditionalBadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, D6, 1E, 00, 06, 0A, 00, 72, D7, 49, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C4, 10, 00, 04, 06, FE, 06, D7, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, EB, 49, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass41_0
        // .local [1] string
        // IL_0000: newobj 0x06001ED6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass41_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700549D7 [102, 97, 108, 115, 101, 101, 101, 101, 101] utf16-bytes=[66, 00, 61, 00, 6C, 00, 73, 00, 65, 00, 65, 00, 65, 00, 65, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass41_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001ED7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass41_0::<ReadAsString_AdditionalBadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x700549EB [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 53, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 35, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsBoolean_UnexpectedEnd()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, D8, 1E, 00, 06, 0A, 00, 72, 98, 4A, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C5, 10, 00, 04, 06, FE, 06, D9, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A9, 39, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass42_0
        // .local [1] string
        // IL_0000: newobj 0x06001ED8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass42_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70054A98 [116, 114, 117] utf16-bytes=[74, 00, 72, 00, 75, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass42_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001ED9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass42_0::<ReadAsBoolean_UnexpectedEnd>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x700539A9 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsBoolean_BadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, DA, 1E, 00, 06, 0A, 00, 72, A2, 65, 00, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C6, 10, 00, 04, 06, FE, 06, DB, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A0, 4A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass43_0
        // .local [1] string
        // IL_0000: newobj 0x06001EDA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass43_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700065A2 [112, 105, 101] utf16-bytes=[70, 00, 69, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass43_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EDB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass43_0::<ReadAsBoolean_BadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70054AA0 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 112, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 70, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsString_BadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, DC, 1E, 00, 06, 0A, 00, 72, A2, 65, 00, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C7, 10, 00, 04, 06, FE, 06, DD, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A0, 4A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass44_0
        // .local [1] string
        // IL_0000: newobj 0x06001EDC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass44_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700065A2 [112, 105, 101] utf16-bytes=[70, 00, 69, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass44_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EDD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass44_0::<ReadAsString_BadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70054AA0 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 112, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 70, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsDouble_BadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, DE, 1E, 00, 06, 0A, 00, 72, A2, 65, 00, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C8, 10, 00, 04, 06, FE, 06, DF, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A0, 4A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass45_0
        // .local [1] string
        // IL_0000: newobj 0x06001EDE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass45_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700065A2 [112, 105, 101] utf16-bytes=[70, 00, 69, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass45_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EDF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass45_0::<ReadAsDouble_BadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70054AA0 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 112, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 70, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsDouble_Boolean()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, E0, 1E, 00, 06, 0A, 00, 72, 67, 2D, 00, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, C9, 10, 00, 04, 06, FE, 06, E1, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, 4D, 4B, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass46_0
        // .local [1] string
        // IL_0000: newobj 0x06001EE0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass46_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70002D67 [116, 114, 117, 101] utf16-bytes=[74, 00, 72, 00, 75, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010C9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass46_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EE1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass46_0::<ReadAsDouble_Boolean>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70054B4D [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 116, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsBytes_BadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, E2, 1E, 00, 06, 0A, 00, 72, A2, 65, 00, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, CA, 10, 00, 04, 06, FE, 06, E3, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A0, 4A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass47_0
        // .local [1] string
        // IL_0000: newobj 0x06001EE2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass47_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700065A2 [112, 105, 101] utf16-bytes=[70, 00, 69, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010CA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass47_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EE3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass47_0::<ReadAsBytes_BadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70054AA0 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 112, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 70, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsBytesIntegerArrayWithNoEnd()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, E4, 1E, 00, 06, 0A, 00, 06, 72, FA, 4B, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [CB, 10, 00, 04, 06, FE, 06, E5, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 00, 4C, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass48_0
        // IL_0000: newobj 0x06001EE4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass48_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054BFA [91, 49] utf16-bytes=[5B, 00, 31, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010CB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass48_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EE5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass48_0::<ReadAsBytesIntegerArrayWithNoEnd>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054C00 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 98, 121, 116, 101, 115, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 62, 00, 79, 00, 74, 00, 65, 00, 73, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadAsBytesArrayWithBadContent()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, E6, 1E, 00, 06, 0A, 00, 06, 72, 87, 4C, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [CC, 10, 00, 04, 06, FE, 06, E7, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 93, 4C, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass49_0
        // IL_0000: newobj 0x06001EE6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass49_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054C87 [91, 49, 46, 48, 93] utf16-bytes=[5B, 00, 31, 00, 2E, 00, 30, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010CC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass49_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EE7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass49_0::<ReadAsBytesArrayWithBadContent>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054C93 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 111, 107, 101, 110, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 98, 121, 116, 101, 115, 58, 32, 70, 108, 111, 97, 116, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 74, 00, 6F, 00, 6B, 00, 65, 00, 6E, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 62, 00, 79, 00, 74, 00, 65, 00, 73, 00, 3A, 00, 20, 00, 46, 00, 6C, 00, 6F, 00, 61, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadAsBytesBadContent()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, E8, 1E, 00, 06, 0A, 00, 06, 72, 2C, 4D, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [CD, 10, 00, 04, 06, FE, 06, E9, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 42, 4D, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass50_0
        // IL_0000: newobj 0x06001EE8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass50_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054D2C [110, 101, 119, 32, 68, 97, 116, 101, 40, 41] utf16-bytes=[6E, 00, 65, 00, 77, 00, 20, 00, 44, 00, 61, 00, 74, 00, 65, 00, 28, 00, 29, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010CD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass50_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EE9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass50_0::<ReadAsBytesBadContent>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054D42 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadAsBytes_CommaErrors()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, EA, 1E, 00, 06, 0A, 00, 06, 72, EF, 4D, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [CE, 10, 00, 04, 06, 7B, CE, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 06, FE, 06, EB, 1E, 00, 06, 73]
        // .code-bytes IL_0030: [08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, FB, 4D, 05, 70, A2, 28, 12, 00, 00, 2B, 26]
        // .code-bytes IL_0048: [16, 8D, 97, 01, 00, 01, 06, 7B, CE, 10, 00, 04, 6F, 62, 02, 00, 0A, 28, 63, 02, 00, 0A, 00, 06]
        // .code-bytes IL_0060: [7B, CE, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass51_0
        // IL_0000: newobj 0x06001EEA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass51_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054DEF [91, 44, 39, 39, 93] utf16-bytes=[5B, 00, 2C, 00, 27, 00, 27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010CE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass51_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010CE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass51_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.0 0
        // IL_0029: ldftn 0x06001EEB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass51_0::<ReadAsBytes_CommaErrors>b__0
        // IL_002F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0034: ldc.i4.1 1
        // IL_0035: newarr 0x01000181 [mscorlib]System.String
        // IL_003A: dup 
        // IL_003B: ldc.i4.0 0
        // IL_003C: ldstr 0x70054DFB [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0041: stelem.ref 
        // IL_0042: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0047: pop 
        // IL_0048: ldc.i4.0 0
        // IL_0049: newarr 0x01000197 [mscorlib]System.Byte
        // IL_004E: ldloc.0 0
        // IL_004F: ldfld 0x040010CE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass51_0::reader
        // IL_0054: callvirt 0x0A000262 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsBytes
        // IL_0059: call 0x0A000263 [nunit.framework]NUnit.Framework.CollectionAssert::AreEquivalent
        // IL_005E: nop 
        // IL_005F: ldloc.0 0
        // IL_0060: ldfld 0x040010CE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass51_0::reader
        // IL_0065: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_006A: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_006F: nop 
        // IL_0070: ret 
    }

    public void ReadAsBytes_InvalidEndArray()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, EC, 1E, 00, 06, 0A, 00, 06, 72, AA, 24, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [CF, 10, 00, 04, 06, FE, 06, ED, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, AE, 4E, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass52_0
        // IL_0000: newobj 0x06001EEC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass52_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700524AA [93] utf16-bytes=[5D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010CF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass52_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EED Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass52_0::<ReadAsBytes_InvalidEndArray>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054EAE [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 93, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 5D, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadAsBytes_CommaErrors_Multiple()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, EE, 1E, 00, 06, 0A, 00, 06, 72, 5B, 4F, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [D0, 10, 00, 04, 06, 7B, D0, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 16, 8D, 97, 01, 00, 01, 06, 7B]
        // .code-bytes IL_0030: [D0, 10, 00, 04, 6F, 62, 02, 00, 0A, 28, 63, 02, 00, 0A, 00, 06, FE, 06, EF, 1E, 00, 06, 73, 08]
        // .code-bytes IL_0048: [01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 6D, 4F, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 16]
        // .code-bytes IL_0060: [8D, 97, 01, 00, 01, 06, 7B, D0, 10, 00, 04, 6F, 62, 02, 00, 0A, 28, 63, 02, 00, 0A, 00, 06, 7B]
        // .code-bytes IL_0078: [D0, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0
        // IL_0000: newobj 0x06001EEE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054F5B [91, 39, 39, 44, 44, 39, 39, 93] utf16-bytes=[5B, 00, 27, 00, 27, 00, 2C, 00, 2C, 00, 27, 00, 27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010D0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010D0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldc.i4.0 0
        // IL_0029: newarr 0x01000197 [mscorlib]System.Byte
        // IL_002E: ldloc.0 0
        // IL_002F: ldfld 0x040010D0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0::reader
        // IL_0034: callvirt 0x0A000262 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsBytes
        // IL_0039: call 0x0A000263 [nunit.framework]NUnit.Framework.CollectionAssert::AreEquivalent
        // IL_003E: nop 
        // IL_003F: ldloc.0 0
        // IL_0040: ldftn 0x06001EEF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0::<ReadAsBytes_CommaErrors_Multiple>b__0
        // IL_0046: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_004B: ldc.i4.1 1
        // IL_004C: newarr 0x01000181 [mscorlib]System.String
        // IL_0051: dup 
        // IL_0052: ldc.i4.0 0
        // IL_0053: ldstr 0x70054F6D [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 49, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 53, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 31, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 35, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0058: stelem.ref 
        // IL_0059: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_005E: pop 
        // IL_005F: ldc.i4.0 0
        // IL_0060: newarr 0x01000197 [mscorlib]System.Byte
        // IL_0065: ldloc.0 0
        // IL_0066: ldfld 0x040010D0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0::reader
        // IL_006B: callvirt 0x0A000262 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsBytes
        // IL_0070: call 0x0A000263 [nunit.framework]NUnit.Framework.CollectionAssert::AreEquivalent
        // IL_0075: nop 
        // IL_0076: ldloc.0 0
        // IL_0077: ldfld 0x040010D0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass53_0::reader
        // IL_007C: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0081: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0086: nop 
        // IL_0087: ret 
    }

    public void ReadBytesWithBadCharacter()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, F0, 1E, 00, 06, 0A, 00, 06, 72, 67, 2D, 00, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [D1, 10, 00, 04, 06, FE, 06, F1, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 4D, 4B, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass54_0
        // IL_0000: newobj 0x06001EF0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass54_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70002D67 [116, 114, 117, 101] utf16-bytes=[74, 00, 72, 00, 75, 00, 65, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010D1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass54_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EF1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass54_0::<ReadBytesWithBadCharacter>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054B4D [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 116, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadBytesWithUnexpectedEnd()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, F2, 1E, 00, 06, 0A, 00, 72, 15, 5B, 04, 70, 0B, 28, 51, 01, 00, 0A, 07, 6F, 1F, 02, 00, 0A]
        // .code-bytes IL_0018: [0C, 06, 72, C5, EA, 00, 70, 08, 28, 61, 02, 00, 0A, 28, 3B, 01, 00, 0A, 73, 0E, 01, 00, 0A, 73]
        // .code-bytes IL_0030: [0F, 01, 00, 0A, 7D, D2, 10, 00, 04, 06, FE, 06, F3, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81]
        // .code-bytes IL_0048: [01, 00, 01, 25, 16, 72, 20, 50, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass55_0
        // .local [1] string
        // .local [2] uint8[]
        // IL_0000: newobj 0x06001EF2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass55_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70045B15 [72, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100, 33] utf16-bytes=[48, 00, 65, 00, 6C, 00, 6C, 00, 6F, 00, 20, 00, 77, 00, 6F, 00, 72, 00, 6C, 00, 64, 00, 21, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: call 0x0A000151 [mscorlib]System.Text.Encoding::get_UTF8
        // IL_0012: ldloc.1 1
        // IL_0013: callvirt 0x0A00021F [mscorlib]System.Text.Encoding::GetBytes
        // IL_0018: stloc.2 2
        // IL_0019: ldloc.0 0
        // IL_001A: ldstr 0x7000EAC5 [39] utf16-bytes=[27, 00] terminal-flag=Some(1)
        // IL_001F: ldloc.2 2
        // IL_0020: call 0x0A000261 [mscorlib]System.Convert::ToBase64String
        // IL_0025: call 0x0A00013B [mscorlib]System.String::Concat
        // IL_002A: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_002F: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0034: stfld 0x040010D2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass55_0::reader
        // IL_0039: ldloc.0 0
        // IL_003A: ldftn 0x06001EF3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass55_0::<ReadBytesWithUnexpectedEnd>b__0
        // IL_0040: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0045: ldc.i4.1 1
        // IL_0046: newarr 0x01000181 [mscorlib]System.String
        // IL_004B: dup 
        // IL_004C: ldc.i4.0 0
        // IL_004D: ldstr 0x70055020 [85, 110, 116, 101, 114, 109, 105, 110, 97, 116, 101, 100, 32, 115, 116, 114, 105, 110, 103, 46, 32, 69, 120, 112, 101, 99, 116, 101, 100, 32, 100, 101, 108, 105, 109, 105, 116, 101, 114, 58, 32, 39, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 55, 46] utf16-bytes=[55, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 6D, 00, 69, 00, 6E, 00, 61, 00, 74, 00, 65, 00, 64, 00, 20, 00, 73, 00, 74, 00, 72, 00, 69, 00, 6E, 00, 67, 00, 2E, 00, 20, 00, 45, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 64, 00, 65, 00, 6C, 00, 69, 00, 6D, 00, 69, 00, 74, 00, 65, 00, 72, 00, 3A, 00, 20, 00, 27, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 37, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0052: stelem.ref 
        // IL_0053: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0058: pop 
        // IL_0059: ret 
    }

    public void ReadAsDateTime_BadData()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, F4, 1E, 00, 06, 0A, 00, 72, A2, 65, 00, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, D3, 10, 00, 04, 06, FE, 06, F5, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A0, 4A, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass56_0
        // .local [1] string
        // IL_0000: newobj 0x06001EF4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass56_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700065A2 [112, 105, 101] utf16-bytes=[70, 00, 69, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010D3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass56_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EF5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass56_0::<ReadAsDateTime_BadData>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70054AA0 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 112, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 70, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsDateTime_Boolean()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, F6, 1E, 00, 06, 0A, 00, 72, 67, 2D, 00, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, D4, 10, 00, 04, 06, FE, 06, F7, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, 4D, 4B, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass57_0
        // .local [1] string
        // IL_0000: newobj 0x06001EF6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass57_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70002D67 [116, 114, 117, 101] utf16-bytes=[74, 00, 72, 00, 75, 00, 65, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010D4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass57_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001EF7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass57_0::<ReadAsDateTime_Boolean>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x70054B4D [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 116, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsDateTimeOffsetBadContent()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, F8, 1E, 00, 06, 0A, 00, 06, 72, 2C, 4D, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [D5, 10, 00, 04, 06, FE, 06, F9, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 42, 4D, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass58_0
        // IL_0000: newobj 0x06001EF8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass58_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054D2C [110, 101, 119, 32, 68, 97, 116, 101, 40, 41] utf16-bytes=[6E, 00, 65, 00, 77, 00, 20, 00, 44, 00, 61, 00, 74, 00, 65, 00, 28, 00, 29, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010D5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass58_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EF9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass58_0::<ReadAsDateTimeOffsetBadContent>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054D42 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadAsDecimalBadContent()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, FA, 1E, 00, 06, 0A, 00, 06, 72, 2C, 4D, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [D6, 10, 00, 04, 06, FE, 06, FB, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 42, 4D, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass59_0
        // IL_0000: newobj 0x06001EFA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass59_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054D2C [110, 101, 119, 32, 68, 97, 116, 101, 40, 41] utf16-bytes=[6E, 00, 65, 00, 77, 00, 20, 00, 44, 00, 61, 00, 74, 00, 65, 00, 28, 00, 29, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010D6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass59_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EFB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass59_0::<ReadAsDecimalBadContent>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054D42 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadAsDecimalBadContent_SecondLine()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, FC, 1E, 00, 06, 0A, 00, 06, 72, B5, 50, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [D7, 10, 00, 04, 06, FE, 06, FD, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, CF, 50, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass60_0
        // IL_0000: newobj 0x06001EFC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass60_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700550B5 [13, 10, 110, 101, 119, 32, 68, 97, 116, 101, 40, 41] utf16-bytes=[0D, 00, 0A, 00, 6E, 00, 65, 00, 77, 00, 20, 00, 44, 00, 61, 00, 74, 00, 65, 00, 28, 00, 29, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010D7 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass60_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EFD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass60_0::<ReadAsDecimalBadContent_SecondLine>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x700550CF [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 50, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 32, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadInt32WithBadCharacter()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, FE, 1E, 00, 06, 0A, 00, 06, 72, 67, 2D, 00, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [D8, 10, 00, 04, 06, FE, 06, FF, 1E, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, 4D, 4B, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass61_0
        // IL_0000: newobj 0x06001EFE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass61_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70002D67 [116, 114, 117, 101] utf16-bytes=[74, 00, 72, 00, 75, 00, 65, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010D8 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass61_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001EFF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass61_0::<ReadInt32WithBadCharacter>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054B4D [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 116, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadNumberValue_CommaErrors()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 00, 1F, 00, 06, 0A, 00, 06, 72, 7C, 51, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [D9, 10, 00, 04, 06, 7B, D9, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 06, FE, 06, 01, 1F, 00, 06, 73]
        // .code-bytes IL_0030: [08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, FB, 4D, 05, 70, A2, 28, 12, 00, 00, 2B, 26]
        // .code-bytes IL_0048: [17, 8C, 83, 01, 00, 01, 06, 7B, D9, 10, 00, 04, 6F, 64, 02, 00, 0A, 8C, 7D, 00, 00, 1B, 28, C7]
        // .code-bytes IL_0060: [00, 00, 0A, 00, 06, 7B, D9, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass62_0
        // IL_0000: newobj 0x06001F00 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass62_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x7005517C [91, 44, 49, 93] utf16-bytes=[5B, 00, 2C, 00, 31, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010D9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass62_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010D9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass62_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.0 0
        // IL_0029: ldftn 0x06001F01 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass62_0::<ReadNumberValue_CommaErrors>b__0
        // IL_002F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0034: ldc.i4.1 1
        // IL_0035: newarr 0x01000181 [mscorlib]System.String
        // IL_003A: dup 
        // IL_003B: ldc.i4.0 0
        // IL_003C: ldstr 0x70054DFB [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0041: stelem.ref 
        // IL_0042: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0047: pop 
        // IL_0048: ldc.i4.1 1
        // IL_0049: box 0x01000183 [mscorlib]System.Int32
        // IL_004E: ldloc.0 0
        // IL_004F: ldfld 0x040010D9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass62_0::reader
        // IL_0054: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
        // IL_0059: box 0x1B00007D valuetype [mscorlib]System.Nullable`1<int32>
        // IL_005E: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0063: nop 
        // IL_0064: ldloc.0 0
        // IL_0065: ldfld 0x040010D9 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass62_0::reader
        // IL_006A: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_006F: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0074: nop 
        // IL_0075: ret 
    }

    public void ReadNumberValue_InvalidEndArray()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 02, 1F, 00, 06, 0A, 00, 06, 72, AA, 24, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [DA, 10, 00, 04, 06, FE, 06, 03, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, AE, 4E, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass63_0
        // IL_0000: newobj 0x06001F02 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass63_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700524AA [93] utf16-bytes=[5D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010DA Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass63_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001F03 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass63_0::<ReadNumberValue_InvalidEndArray>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054EAE [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 93, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 5D, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadNumberValue_CommaErrors_Multiple()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 04, 1F, 00, 06, 0A, 00, 06, 72, 86, 51, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [DB, 10, 00, 04, 06, 7B, DB, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 06, 7B, DB, 10, 00, 04, 6F, 64]
        // .code-bytes IL_0030: [02, 00, 0A, 26, 06, FE, 06, 05, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0048: [72, 94, 51, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 17, 8C, 83, 01, 00, 01, 06, 7B, DB, 10, 00, 04]
        // .code-bytes IL_0060: [6F, 64, 02, 00, 0A, 8C, 7D, 00, 00, 1B, 28, C7, 00, 00, 0A, 00, 06, 7B, DB, 10, 00, 04, 6F, 72]
        // .code-bytes IL_0078: [01, 00, 0A, 28, D6, 00, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0
        // IL_0000: newobj 0x06001F04 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70055186 [91, 49, 44, 44, 49, 93] utf16-bytes=[5B, 00, 31, 00, 2C, 00, 2C, 00, 31, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010DB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010DB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.0 0
        // IL_0029: ldfld 0x040010DB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0::reader
        // IL_002E: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
        // IL_0033: pop 
        // IL_0034: ldloc.0 0
        // IL_0035: ldftn 0x06001F05 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0::<ReadNumberValue_CommaErrors_Multiple>b__0
        // IL_003B: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0040: ldc.i4.1 1
        // IL_0041: newarr 0x01000181 [mscorlib]System.String
        // IL_0046: dup 
        // IL_0047: ldc.i4.0 0
        // IL_0048: ldstr 0x70055194 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 49, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 31, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_004D: stelem.ref 
        // IL_004E: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0053: pop 
        // IL_0054: ldc.i4.1 1
        // IL_0055: box 0x01000183 [mscorlib]System.Int32
        // IL_005A: ldloc.0 0
        // IL_005B: ldfld 0x040010DB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0::reader
        // IL_0060: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
        // IL_0065: box 0x1B00007D valuetype [mscorlib]System.Nullable`1<int32>
        // IL_006A: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_006F: nop 
        // IL_0070: ldloc.0 0
        // IL_0071: ldfld 0x040010DB Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass64_0::reader
        // IL_0076: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_007B: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0080: nop 
        // IL_0081: ret 
    }

    public void ReadAsString_UnexpectedEnd()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 06, 1F, 00, 06, 0A, 00, 72, 98, 4A, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, DC, 10, 00, 04, 06, FE, 06, 07, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A9, 39, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass65_0
        // .local [1] string
        // IL_0000: newobj 0x06001F06 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass65_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70054A98 [116, 114, 117] utf16-bytes=[74, 00, 72, 00, 75, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010DC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass65_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001F07 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass65_0::<ReadAsString_UnexpectedEnd>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x700539A9 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadAsString_Null_UnexpectedEnd()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 08, 1F, 00, 06, 0A, 00, 72, A1, 39, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 7D, DD, 10, 00, 04, 06, FE, 06, 09, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01]
        // .code-bytes IL_0030: [25, 16, 72, A9, 39, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass66_0
        // .local [1] string
        // IL_0000: newobj 0x06001F08 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass66_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x700539A1 [110, 117, 108] utf16-bytes=[6E, 00, 75, 00, 6C, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: stfld 0x040010DD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass66_0::reader
        // IL_001E: ldloc.0 0
        // IL_001F: ldftn 0x06001F09 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass66_0::<ReadAsString_Null_UnexpectedEnd>b__0
        // IL_0025: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_002A: ldc.i4.1 1
        // IL_002B: newarr 0x01000181 [mscorlib]System.String
        // IL_0030: dup 
        // IL_0031: ldc.i4.0 0
        // IL_0032: ldstr 0x700539A9 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 101, 110, 32, 114, 101, 97, 100, 105, 110, 103, 32, 74, 83, 79, 78, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 65, 00, 6E, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 4A, 00, 53, 00, 4F, 00, 4E, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0037: stelem.ref 
        // IL_0038: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003D: pop 
        // IL_003E: ret 
    }

    public void ReadStringValue_InvalidEndArray()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 0A, 1F, 00, 06, 0A, 00, 06, 72, AA, 24, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [DE, 10, 00, 04, 06, FE, 06, 0B, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0030: [72, AE, 4E, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass67_0
        // IL_0000: newobj 0x06001F0A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass67_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700524AA [93] utf16-bytes=[5D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010DE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass67_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldftn 0x06001F0B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass67_0::<ReadStringValue_InvalidEndArray>b__0
        // IL_0023: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0028: ldc.i4.1 1
        // IL_0029: newarr 0x01000181 [mscorlib]System.String
        // IL_002E: dup 
        // IL_002F: ldc.i4.0 0
        // IL_0030: ldstr 0x70054EAE [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 93, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 5D, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0035: stelem.ref 
        // IL_0036: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_003B: pop 
        // IL_003C: ret 
    }

    public void ReadStringValue_CommaErrors()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 0C, 1F, 00, 06, 0A, 00, 06, 72, EF, 4D, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [DF, 10, 00, 04, 06, 7B, DF, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 06, FE, 06, 0D, 1F, 00, 06, 73]
        // .code-bytes IL_0030: [08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, FB, 4D, 05, 70, A2, 28, 12, 00, 00, 2B, 26]
        // .code-bytes IL_0048: [7E, 22, 01, 00, 0A, 06, 7B, DF, 10, 00, 04, 6F, 62, 01, 00, 0A, 28, C7, 00, 00, 0A, 00, 06, 7B]
        // .code-bytes IL_0060: [DF, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass68_0
        // IL_0000: newobj 0x06001F0C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass68_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054DEF [91, 44, 39, 39, 93] utf16-bytes=[5B, 00, 2C, 00, 27, 00, 27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010DF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass68_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010DF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass68_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.0 0
        // IL_0029: ldftn 0x06001F0D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass68_0::<ReadStringValue_CommaErrors>b__0
        // IL_002F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0034: ldc.i4.1 1
        // IL_0035: newarr 0x01000181 [mscorlib]System.String
        // IL_003A: dup 
        // IL_003B: ldc.i4.0 0
        // IL_003C: ldstr 0x70054DFB [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0041: stelem.ref 
        // IL_0042: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0047: pop 
        // IL_0048: ldsfld 0x0A000122 [mscorlib]System.String::Empty
        // IL_004D: ldloc.0 0
        // IL_004E: ldfld 0x040010DF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass68_0::reader
        // IL_0053: callvirt 0x0A000162 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsString
        // IL_0058: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_005D: nop 
        // IL_005E: ldloc.0 0
        // IL_005F: ldfld 0x040010DF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass68_0::reader
        // IL_0064: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0069: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_006E: nop 
        // IL_006F: ret 
    }

    public void ReadStringValue_CommaErrors_Multiple()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 0E, 1F, 00, 06, 0A, 00, 06, 72, 5B, 4F, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [E0, 10, 00, 04, 06, 7B, E0, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 06, 7B, E0, 10, 00, 04, 6F, 64]
        // .code-bytes IL_0030: [02, 00, 0A, 26, 06, FE, 06, 0F, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16]
        // .code-bytes IL_0048: [72, 6D, 4F, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 7E, 22, 01, 00, 0A, 06, 7B, E0, 10, 00, 04, 6F]
        // .code-bytes IL_0060: [62, 01, 00, 0A, 28, C7, 00, 00, 0A, 00, 06, 7B, E0, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00]
        // .code-bytes IL_0078: [00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0
        // IL_0000: newobj 0x06001F0E Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70054F5B [91, 39, 39, 44, 44, 39, 39, 93] utf16-bytes=[5B, 00, 27, 00, 27, 00, 2C, 00, 2C, 00, 27, 00, 27, 00, 5D, 00] terminal-flag=Some(1)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010E0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010E0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.0 0
        // IL_0029: ldfld 0x040010E0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0::reader
        // IL_002E: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
        // IL_0033: pop 
        // IL_0034: ldloc.0 0
        // IL_0035: ldftn 0x06001F0F Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0::<ReadStringValue_CommaErrors_Multiple>b__0
        // IL_003B: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0040: ldc.i4.1 1
        // IL_0041: newarr 0x01000181 [mscorlib]System.String
        // IL_0046: dup 
        // IL_0047: ldc.i4.0 0
        // IL_0048: ldstr 0x70054F6D [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 49, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 53, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 31, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 35, 00, 2E, 00] terminal-flag=Some(1)
        // IL_004D: stelem.ref 
        // IL_004E: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0053: pop 
        // IL_0054: ldsfld 0x0A000122 [mscorlib]System.String::Empty
        // IL_0059: ldloc.0 0
        // IL_005A: ldfld 0x040010E0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0::reader
        // IL_005F: callvirt 0x0A000162 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsString
        // IL_0064: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0069: nop 
        // IL_006A: ldloc.0 0
        // IL_006B: ldfld 0x040010E0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass69_0::reader
        // IL_0070: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0075: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_007A: nop 
        // IL_007B: ret 
    }

    public void ReadStringValue_Numbers_NotString()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 10, 1F, 00, 06, 0A, 00, 06, 72, 47, 52, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [E1, 10, 00, 04, 06, 7B, E1, 10, 00, 04, 6F, 72, 01, 00, 0A, 26, 06, FE, 06, 11, 1F, 00, 06, 73]
        // .code-bytes IL_0030: [08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 57, 52, 05, 70, A2, 28, 12, 00, 00, 2B, 26]
        // .code-bytes IL_0048: [06, FE, 06, 12, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 04, 53, 05]
        // .code-bytes IL_0060: [70, A2, 28, 12, 00, 00, 2B, 26, 06, FE, 06, 13, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01]
        // .code-bytes IL_0078: [00, 01, 25, 16, 72, B1, 53, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 1F, 38, 8C, 83, 01, 00, 01, 06]
        // .code-bytes IL_0090: [7B, E1, 10, 00, 04, 6F, 64, 02, 00, 0A, 8C, 7D, 00, 00, 1B, 28, C7, 00, 00, 0A, 00, 06, 7B, E1]
        // .code-bytes IL_00A8: [10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0
        // IL_0000: newobj 0x06001F10 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x70055247 [91, 53, 54, 44, 53, 54, 93] utf16-bytes=[5B, 00, 35, 00, 36, 00, 2C, 00, 35, 00, 36, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010E1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010E1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: pop 
        // IL_0028: ldloc.0 0
        // IL_0029: ldftn 0x06001F11 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::<ReadStringValue_Numbers_NotString>b__0
        // IL_002F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0034: ldc.i4.1 1
        // IL_0035: newarr 0x01000181 [mscorlib]System.String
        // IL_003A: dup 
        // IL_003B: ldc.i4.0 0
        // IL_003C: ldstr 0x70055257 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 53, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 35, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0041: stelem.ref 
        // IL_0042: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0047: pop 
        // IL_0048: ldloc.0 0
        // IL_0049: ldftn 0x06001F12 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::<ReadStringValue_Numbers_NotString>b__1
        // IL_004F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0054: ldc.i4.1 1
        // IL_0055: newarr 0x01000181 [mscorlib]System.String
        // IL_005A: dup 
        // IL_005B: ldc.i4.0 0
        // IL_005C: ldstr 0x70055304 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 54, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 51, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 36, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 33, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0061: stelem.ref 
        // IL_0062: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0067: pop 
        // IL_0068: ldloc.0 0
        // IL_0069: ldftn 0x06001F13 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::<ReadStringValue_Numbers_NotString>b__2
        // IL_006F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0074: ldc.i4.1 1
        // IL_0075: newarr 0x01000181 [mscorlib]System.String
        // IL_007A: dup 
        // IL_007B: ldc.i4.0 0
        // IL_007C: ldstr 0x700553B1 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 101, 110, 99, 111, 117, 110, 116, 101, 114, 101, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 118, 97, 108, 117, 101, 58, 32, 44, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 63, 00, 68, 00, 61, 00, 72, 00, 61, 00, 63, 00, 74, 00, 65, 00, 72, 00, 20, 00, 65, 00, 6E, 00, 63, 00, 6F, 00, 75, 00, 6E, 00, 74, 00, 65, 00, 72, 00, 65, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 76, 00, 61, 00, 6C, 00, 75, 00, 65, 00, 3A, 00, 20, 00, 2C, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0081: stelem.ref 
        // IL_0082: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0087: pop 
        // IL_0088: ldc.i4.s 56
        // IL_008A: box 0x01000183 [mscorlib]System.Int32
        // IL_008F: ldloc.0 0
        // IL_0090: ldfld 0x040010E1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::reader
        // IL_0095: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
        // IL_009A: box 0x1B00007D valuetype [mscorlib]System.Nullable`1<int32>
        // IL_009F: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00A4: nop 
        // IL_00A5: ldloc.0 0
        // IL_00A6: ldfld 0x040010E1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass70_0::reader
        // IL_00AB: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00B0: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00B5: nop 
        // IL_00B6: ret 
    }

    public void ErrorReadingComment()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 14, 1F, 00, 06, 0A, 00, 72, 19, D6, 00, 70, 0B, 06, 07, 16, 73, D4, 01, 00, 0A, 17, 73, A5]
        // .code-bytes IL_0018: [08, 00, 06, 73, 31, 05, 00, 0A, 73, 0F, 01, 00, 0A, 7D, E2, 10, 00, 04, 06, FE, 06, 15, 1F, 00]
        // .code-bytes IL_0030: [06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 64, 54, 05, 70, A2, 28, 12, 00, 00]
        // .code-bytes IL_0048: [2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass71_0
        // .local [1] string
        // IL_0000: newobj 0x06001F14 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass71_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x7000D619 [47] utf16-bytes=[2F, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: ldc.i4.0 0
        // IL_0010: newobj 0x0A0001D4 [mscorlib]System.Text.UTF8Encoding::.ctor
        // IL_0015: ldc.i4.1 1
        // IL_0016: newobj 0x060008A5 Newtonsoft.Json.Tests.TestObjects.JsonTextReaderTests.SlowStream::.ctor
        // IL_001B: newobj 0x0A000531 [mscorlib]System.IO.StreamReader::.ctor
        // IL_0020: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0025: stfld 0x040010E2 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass71_0::reader
        // IL_002A: ldloc.0 0
        // IL_002B: ldftn 0x06001F15 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass71_0::<ErrorReadingComment>b__0
        // IL_0031: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0036: ldc.i4.1 1
        // IL_0037: newarr 0x01000181 [mscorlib]System.String
        // IL_003C: dup 
        // IL_003D: ldc.i4.0 0
        // IL_003E: ldstr 0x70055464 [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 99, 111, 109, 109, 101, 110, 116, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 49, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 63, 00, 6F, 00, 6D, 00, 6D, 00, 65, 00, 6E, 00, 74, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 31, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0043: stelem.ref 
        // IL_0044: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0049: pop 
        // IL_004A: ret 
    }

    public void EscapedPathInExceptionMessage()
    {
        // structural signature __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 bytes=1D0E: string[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
        global::Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E635F5F446973706C6179436C61737337325F30 v0 = __cil_newobj_06001F16();
        string v2 = __cil_ldstr_700554EB("{\u000D\u000A  \"frameworks\": {\u000D\u000A    \"dnxcore50\": {\u000D\u000A      \"dependencies\": {\u000D\u000A        \"System.Xml.ReaderWriter\": {\u000D\u000A          \"source\": !!! !!!\u000D\u000A        }\u000D\u000A      }\u000D\u000A    }\u000D\u000A  }\u000D\u000A}");
        v0.json = v2;
        nint v4 = __cil_ldftn_06001F17;
        __cil_type_0100005D v5 = __cil_newobj_0A000108(v0, v4);
        __cil_ref_7bdb48770b79a01877dba09fc617d959d2ebf4a4 v7 = __cil_newarr_01000181(1);
        string v9 = __cil_ldstr_7005563C("Unexpected character encountered while parsing value: !. Path 'frameworks.dnxcore50.dependencies['System.Xml.ReaderWriter'].source', line 6, position 20.");
        v7[0] = v9;
        __cil_type_01000031 v10 = __cil_methodspec_call_2B000012(v5, v7);
        return;
    }

    public void MaxDepth()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 18, 1F, 00, 06, 0A, 00, 72, 71, 57, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 25, 17, 73, F6, 01, 00, 0A, 6F, ED, 06, 00, 0A, 00, 7D, E4, 10, 00, 04, 06, 7B, E4, 10, 00]
        // .code-bytes IL_0030: [04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 06, FE, 06, 19, 1F, 00, 06, 73, 08, 01, 00, 0A]
        // .code-bytes IL_0048: [17, 8D, 81, 01, 00, 01, 25, 16, 72, 7B, 57, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass73_0
        // .local [1] string
        // IL_0000: newobj 0x06001F18 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass73_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70055771 [91, 91, 93, 93] utf16-bytes=[5B, 00, 5B, 00, 5D, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: dup 
        // IL_001A: ldc.i4.1 1
        // IL_001B: newobj 0x0A0001F6 valuetype [mscorlib]System.Nullable`1<int32>::.ctor
        // IL_0020: callvirt 0x0A0006ED [Newtonsoft.Json]Newtonsoft.Json.JsonReader::set_MaxDepth
        // IL_0025: nop 
        // IL_0026: stfld 0x040010E4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass73_0::reader
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x040010E4 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass73_0::reader
        // IL_0031: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0036: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_003B: nop 
        // IL_003C: ldloc.0 0
        // IL_003D: ldftn 0x06001F19 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass73_0::<MaxDepth>b__0
        // IL_0043: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0048: ldc.i4.1 1
        // IL_0049: newarr 0x01000181 [mscorlib]System.String
        // IL_004E: dup 
        // IL_004F: ldc.i4.0 0
        // IL_0050: ldstr 0x7005577B [84, 104, 101, 32, 114, 101, 97, 100, 101, 114, 39, 115, 32, 77, 97, 120, 68, 101, 112, 116, 104, 32, 111, 102, 32, 49, 32, 104, 97, 115, 32, 98, 101, 101, 110, 32, 101, 120, 99, 101, 101, 100, 101, 100, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[54, 00, 68, 00, 65, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 65, 00, 72, 00, 27, 00, 73, 00, 20, 00, 4D, 00, 61, 00, 78, 00, 44, 00, 65, 00, 70, 00, 74, 00, 68, 00, 20, 00, 6F, 00, 66, 00, 20, 00, 31, 00, 20, 00, 68, 00, 61, 00, 73, 00, 20, 00, 62, 00, 65, 00, 65, 00, 6E, 00, 20, 00, 65, 00, 78, 00, 63, 00, 65, 00, 65, 00, 64, 00, 65, 00, 64, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0055: stelem.ref 
        // IL_0056: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_005B: pop 
        // IL_005C: ret 
    }

    public void MaxDepthDoesNotRecursivelyError()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 1A, 1F, 00, 06, 0A, 00, 72, 18, 58, 05, 70, 0B, 06, 07, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00]
        // .code-bytes IL_0018: [0A, 25, 17, 73, F6, 01, 00, 0A, 6F, ED, 06, 00, 0A, 00, 7D, E5, 10, 00, 04, 06, 7B, E5, 10, 00]
        // .code-bytes IL_0030: [04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 16, 8C, 83, 01, 00, 01, 06, 7B, E5, 10, 00, 04]
        // .code-bytes IL_0048: [6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, FE, 06, 1B, 1F, 00, 06, 73]
        // .code-bytes IL_0060: [08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 7B, 57, 05, 70, A2, 28, 12, 00, 00, 2B, 26]
        // .code-bytes IL_0078: [17, 8C, 83, 01, 00, 01, 06, 7B, E5, 10, 00, 04, 6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7]
        // .code-bytes IL_0090: [00, 00, 0A, 00, 06, 7B, E5, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 18, 8C, 83]
        // .code-bytes IL_00A8: [01, 00, 01, 06, 7B, E5, 10, 00, 04, 6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A]
        // .code-bytes IL_00C0: [00, 06, 7B, E5, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 19, 8C, 83, 01, 00, 01]
        // .code-bytes IL_00D8: [06, 7B, E5, 10, 00, 04, 6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B]
        // .code-bytes IL_00F0: [E5, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 19, 8C, 83, 01, 00, 01, 06, 7B, E5]
        // .code-bytes IL_0108: [10, 00, 04, 6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, E5, 10, 00]
        // .code-bytes IL_0120: [04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 18, 8C, 83, 01, 00, 01, 06, 7B, E5, 10, 00, 04]
        // .code-bytes IL_0138: [6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, E5, 10, 00, 04, 6F, 72]
        // .code-bytes IL_0150: [01, 00, 0A, 28, D6, 00, 00, 0A, 00, 17, 8C, 83, 01, 00, 01, 06, 7B, E5, 10, 00, 04, 6F, 51, 02]
        // .code-bytes IL_0168: [00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, FE, 06, 1C, 1F, 00, 06, 73, 08, 01, 00]
        // .code-bytes IL_0180: [0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, 34, 58, 05, 70, A2, 28, 12, 00, 00, 2B, 26, 17, 8C, 83]
        // .code-bytes IL_0198: [01, 00, 01, 06, 7B, E5, 10, 00, 04, 6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A]
        // .code-bytes IL_01B0: [00, 06, 7B, E5, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 18, 8C, 83, 01, 00, 01]
        // .code-bytes IL_01C8: [06, 7B, E5, 10, 00, 04, 6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B]
        // .code-bytes IL_01E0: [E5, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 18, 8C, 83, 01, 00, 01, 06, 7B, E5]
        // .code-bytes IL_01F8: [10, 00, 04, 6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, E5, 10, 00]
        // .code-bytes IL_0210: [04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 17, 8C, 83, 01, 00, 01, 06, 7B, E5, 10, 00, 04]
        // .code-bytes IL_0228: [6F, 51, 02, 00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, E5, 10, 00, 04, 6F, 72]
        // .code-bytes IL_0240: [01, 00, 0A, 28, D6, 00, 00, 0A, 00, 16, 8C, 83, 01, 00, 01, 06, 7B, E5, 10, 00, 04, 6F, 51, 02]
        // .code-bytes IL_0258: [00, 0A, 8C, 83, 01, 00, 01, 28, C7, 00, 00, 0A, 00, 06, 7B, E5, 10, 00, 04, 6F, 72, 01, 00, 0A]
        // .code-bytes IL_0270: [28, DF, 01, 00, 0A, 00, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0
        // .local [1] string
        // IL_0000: newobj 0x06001F1A Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldstr 0x70055818 [91, 91, 91, 91, 93, 93, 93, 44, 91, 91, 93, 93, 93] utf16-bytes=[5B, 00, 5B, 00, 5B, 00, 5B, 00, 5D, 00, 5D, 00, 5D, 00, 2C, 00, 5B, 00, 5B, 00, 5D, 00, 5D, 00, 5D, 00] terminal-flag=Some(0)
        // IL_000C: stloc.1 1
        // IL_000D: ldloc.0 0
        // IL_000E: ldloc.1 1
        // IL_000F: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0014: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0019: dup 
        // IL_001A: ldc.i4.1 1
        // IL_001B: newobj 0x0A0001F6 valuetype [mscorlib]System.Nullable`1<int32>::.ctor
        // IL_0020: callvirt 0x0A0006ED [Newtonsoft.Json]Newtonsoft.Json.JsonReader::set_MaxDepth
        // IL_0025: nop 
        // IL_0026: stfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_002B: ldloc.0 0
        // IL_002C: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0031: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0036: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_003B: nop 
        // IL_003C: ldc.i4.0 0
        // IL_003D: box 0x01000183 [mscorlib]System.Int32
        // IL_0042: ldloc.0 0
        // IL_0043: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0048: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_004D: box 0x01000183 [mscorlib]System.Int32
        // IL_0052: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0057: nop 
        // IL_0058: ldloc.0 0
        // IL_0059: ldftn 0x06001F1B Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::<MaxDepthDoesNotRecursivelyError>b__0
        // IL_005F: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0064: ldc.i4.1 1
        // IL_0065: newarr 0x01000181 [mscorlib]System.String
        // IL_006A: dup 
        // IL_006B: ldc.i4.0 0
        // IL_006C: ldstr 0x7005577B [84, 104, 101, 32, 114, 101, 97, 100, 101, 114, 39, 115, 32, 77, 97, 120, 68, 101, 112, 116, 104, 32, 111, 102, 32, 49, 32, 104, 97, 115, 32, 98, 101, 101, 110, 32, 101, 120, 99, 101, 101, 100, 101, 100, 46, 32, 80, 97, 116, 104, 32, 39, 91, 48, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 50, 46] utf16-bytes=[54, 00, 68, 00, 65, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 65, 00, 72, 00, 27, 00, 73, 00, 20, 00, 4D, 00, 61, 00, 78, 00, 44, 00, 65, 00, 70, 00, 74, 00, 68, 00, 20, 00, 6F, 00, 66, 00, 20, 00, 31, 00, 20, 00, 68, 00, 61, 00, 73, 00, 20, 00, 62, 00, 65, 00, 65, 00, 6E, 00, 20, 00, 65, 00, 78, 00, 63, 00, 65, 00, 65, 00, 64, 00, 65, 00, 64, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 30, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 32, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0071: stelem.ref 
        // IL_0072: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0077: pop 
        // IL_0078: ldc.i4.1 1
        // IL_0079: box 0x01000183 [mscorlib]System.Int32
        // IL_007E: ldloc.0 0
        // IL_007F: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0084: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_0089: box 0x01000183 [mscorlib]System.Int32
        // IL_008E: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0093: nop 
        // IL_0094: ldloc.0 0
        // IL_0095: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_009A: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_009F: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00A4: nop 
        // IL_00A5: ldc.i4.2 2
        // IL_00A6: box 0x01000183 [mscorlib]System.Int32
        // IL_00AB: ldloc.0 0
        // IL_00AC: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_00B1: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_00B6: box 0x01000183 [mscorlib]System.Int32
        // IL_00BB: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00C0: nop 
        // IL_00C1: ldloc.0 0
        // IL_00C2: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_00C7: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00CC: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00D1: nop 
        // IL_00D2: ldc.i4.3 3
        // IL_00D3: box 0x01000183 [mscorlib]System.Int32
        // IL_00D8: ldloc.0 0
        // IL_00D9: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_00DE: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_00E3: box 0x01000183 [mscorlib]System.Int32
        // IL_00E8: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_00ED: nop 
        // IL_00EE: ldloc.0 0
        // IL_00EF: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_00F4: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_00F9: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_00FE: nop 
        // IL_00FF: ldc.i4.3 3
        // IL_0100: box 0x01000183 [mscorlib]System.Int32
        // IL_0105: ldloc.0 0
        // IL_0106: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_010B: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_0110: box 0x01000183 [mscorlib]System.Int32
        // IL_0115: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_011A: nop 
        // IL_011B: ldloc.0 0
        // IL_011C: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0121: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0126: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_012B: nop 
        // IL_012C: ldc.i4.2 2
        // IL_012D: box 0x01000183 [mscorlib]System.Int32
        // IL_0132: ldloc.0 0
        // IL_0133: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0138: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_013D: box 0x01000183 [mscorlib]System.Int32
        // IL_0142: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0147: nop 
        // IL_0148: ldloc.0 0
        // IL_0149: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_014E: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0153: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0158: nop 
        // IL_0159: ldc.i4.1 1
        // IL_015A: box 0x01000183 [mscorlib]System.Int32
        // IL_015F: ldloc.0 0
        // IL_0160: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0165: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_016A: box 0x01000183 [mscorlib]System.Int32
        // IL_016F: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0174: nop 
        // IL_0175: ldloc.0 0
        // IL_0176: ldftn 0x06001F1C Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::<MaxDepthDoesNotRecursivelyError>b__1
        // IL_017C: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0181: ldc.i4.1 1
        // IL_0182: newarr 0x01000181 [mscorlib]System.String
        // IL_0187: dup 
        // IL_0188: ldc.i4.0 0
        // IL_0189: ldstr 0x70055834 [84, 104, 101, 32, 114, 101, 97, 100, 101, 114, 39, 115, 32, 77, 97, 120, 68, 101, 112, 116, 104, 32, 111, 102, 32, 49, 32, 104, 97, 115, 32, 98, 101, 101, 110, 32, 101, 120, 99, 101, 101, 100, 101, 100, 46, 32, 80, 97, 116, 104, 32, 39, 91, 49, 93, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 57, 46] utf16-bytes=[54, 00, 68, 00, 65, 00, 20, 00, 72, 00, 65, 00, 61, 00, 64, 00, 65, 00, 72, 00, 27, 00, 73, 00, 20, 00, 4D, 00, 61, 00, 78, 00, 44, 00, 65, 00, 70, 00, 74, 00, 68, 00, 20, 00, 6F, 00, 66, 00, 20, 00, 31, 00, 20, 00, 68, 00, 61, 00, 73, 00, 20, 00, 62, 00, 65, 00, 65, 00, 6E, 00, 20, 00, 65, 00, 78, 00, 63, 00, 65, 00, 65, 00, 64, 00, 65, 00, 64, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 5B, 00, 31, 00, 5D, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 39, 00, 2E, 00] terminal-flag=Some(1)
        // IL_018E: stelem.ref 
        // IL_018F: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_0194: pop 
        // IL_0195: ldc.i4.1 1
        // IL_0196: box 0x01000183 [mscorlib]System.Int32
        // IL_019B: ldloc.0 0
        // IL_019C: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_01A1: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_01A6: box 0x01000183 [mscorlib]System.Int32
        // IL_01AB: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_01B0: nop 
        // IL_01B1: ldloc.0 0
        // IL_01B2: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_01B7: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_01BC: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_01C1: nop 
        // IL_01C2: ldc.i4.2 2
        // IL_01C3: box 0x01000183 [mscorlib]System.Int32
        // IL_01C8: ldloc.0 0
        // IL_01C9: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_01CE: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_01D3: box 0x01000183 [mscorlib]System.Int32
        // IL_01D8: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_01DD: nop 
        // IL_01DE: ldloc.0 0
        // IL_01DF: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_01E4: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_01E9: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_01EE: nop 
        // IL_01EF: ldc.i4.2 2
        // IL_01F0: box 0x01000183 [mscorlib]System.Int32
        // IL_01F5: ldloc.0 0
        // IL_01F6: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_01FB: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_0200: box 0x01000183 [mscorlib]System.Int32
        // IL_0205: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_020A: nop 
        // IL_020B: ldloc.0 0
        // IL_020C: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0211: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0216: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_021B: nop 
        // IL_021C: ldc.i4.1 1
        // IL_021D: box 0x01000183 [mscorlib]System.Int32
        // IL_0222: ldloc.0 0
        // IL_0223: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0228: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_022D: box 0x01000183 [mscorlib]System.Int32
        // IL_0232: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0237: nop 
        // IL_0238: ldloc.0 0
        // IL_0239: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_023E: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0243: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_0248: nop 
        // IL_0249: ldc.i4.0 0
        // IL_024A: box 0x01000183 [mscorlib]System.Int32
        // IL_024F: ldloc.0 0
        // IL_0250: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_0255: callvirt 0x0A000251 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::get_Depth
        // IL_025A: box 0x01000183 [mscorlib]System.Int32
        // IL_025F: call 0x0A0000C7 [nunit.framework]NUnit.Framework.Assert::AreEqual
        // IL_0264: nop 
        // IL_0265: ldloc.0 0
        // IL_0266: ldfld 0x040010E5 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass74_0::reader
        // IL_026B: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0270: call 0x0A0001DF [nunit.framework]NUnit.Framework.Assert::IsFalse
        // IL_0275: nop 
        // IL_0276: ret 
    }

    public void UnexpectedEndWhenParsingUnquotedProperty()
    {
        // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
        // .maxstack 5
        // .initlocals true
        // .code-bytes IL_0000: [73, 1D, 1F, 00, 06, 0A, 00, 06, 72, D1, 58, 05, 70, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D]
        // .code-bytes IL_0018: [E6, 10, 00, 04, 06, 7B, E6, 10, 00, 04, 6F, 72, 01, 00, 0A, 28, D6, 00, 00, 0A, 00, 06, FE, 06]
        // .code-bytes IL_0030: [1E, 1F, 00, 06, 73, 08, 01, 00, 0A, 17, 8D, 81, 01, 00, 01, 25, 16, 72, DB, 58, 05, 70, A2, 28]
        // .code-bytes IL_0048: [12, 00, 00, 2B, 26, 2A]
        // .local [0] class Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass75_0
        // IL_0000: newobj 0x06001F1D Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass75_0::.ctor
        // IL_0005: stloc.0 0
        // IL_0006: nop 
        // IL_0007: ldloc.0 0
        // IL_0008: ldstr 0x700558D1 [123, 97, 119, 119] utf16-bytes=[7B, 00, 61, 00, 77, 00, 77, 00] terminal-flag=Some(0)
        // IL_000D: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
        // IL_0012: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
        // IL_0017: stfld 0x040010E6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass75_0::reader
        // IL_001C: ldloc.0 0
        // IL_001D: ldfld 0x040010E6 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass75_0::reader
        // IL_0022: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
        // IL_0027: call 0x0A0000D6 [nunit.framework]NUnit.Framework.Assert::IsTrue
        // IL_002C: nop 
        // IL_002D: ldloc.0 0
        // IL_002E: ldftn 0x06001F1E Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass75_0::<UnexpectedEndWhenParsingUnquotedProperty>b__0
        // IL_0034: newobj 0x0A000108 [mscorlib]System.Action::.ctor
        // IL_0039: ldc.i4.1 1
        // IL_003A: newarr 0x01000181 [mscorlib]System.String
        // IL_003F: dup 
        // IL_0040: ldc.i4.0 0
        // IL_0041: ldstr 0x700558DB [85, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 101, 110, 100, 32, 119, 104, 105, 108, 101, 32, 112, 97, 114, 115, 105, 110, 103, 32, 117, 110, 113, 117, 111, 116, 101, 100, 32, 112, 114, 111, 112, 101, 114, 116, 121, 32, 110, 97, 109, 101, 46, 32, 80, 97, 116, 104, 32, 39, 39, 44, 32, 108, 105, 110, 101, 32, 49, 44, 32, 112, 111, 115, 105, 116, 105, 111, 110, 32, 52, 46] utf16-bytes=[55, 00, 6E, 00, 65, 00, 78, 00, 70, 00, 65, 00, 63, 00, 74, 00, 65, 00, 64, 00, 20, 00, 65, 00, 6E, 00, 64, 00, 20, 00, 77, 00, 68, 00, 69, 00, 6C, 00, 65, 00, 20, 00, 70, 00, 61, 00, 72, 00, 73, 00, 69, 00, 6E, 00, 67, 00, 20, 00, 75, 00, 6E, 00, 71, 00, 75, 00, 6F, 00, 74, 00, 65, 00, 64, 00, 20, 00, 70, 00, 72, 00, 6F, 00, 70, 00, 65, 00, 72, 00, 74, 00, 79, 00, 20, 00, 6E, 00, 61, 00, 6D, 00, 65, 00, 2E, 00, 20, 00, 50, 00, 61, 00, 74, 00, 68, 00, 20, 00, 27, 00, 27, 00, 2C, 00, 20, 00, 6C, 00, 69, 00, 6E, 00, 65, 00, 20, 00, 31, 00, 2C, 00, 20, 00, 70, 00, 6F, 00, 73, 00, 69, 00, 74, 00, 69, 00, 6F, 00, 6E, 00, 20, 00, 34, 00, 2E, 00] terminal-flag=Some(1)
        // IL_0046: stelem.ref 
        // IL_0047: call 0x2B000012 Newtonsoft.Json.Tests.ExceptionAssert::Throws<class [Newtonsoft.Json]Newtonsoft.Json.JsonReaderException>
        // IL_004C: pop 
        // IL_004D: ret 
    }

    public ExceptionHandlingTests() : base()
    {
        return;
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373305F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373305F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytes_MissingComma>b__0
        internal void ReadAsBytes_MissingCommaLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373315F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373315F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsInt32_MissingComma>b__0
        internal void ReadAsInt32_MissingCommaLambda0()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373325F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373325F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBoolean_MissingComma>b__0
        internal void ReadAsBoolean_MissingCommaLambda0()
        {
            // structural signature __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 bytes=151181150102: valuetype [mscorlib]System.Nullable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 v2 = v1.ReadAsBoolean();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373335F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373335F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDateTime_MissingComma>b__0
        internal void ReadAsDateTime_MissingCommaLambda0()
        {
            // structural signature __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d bytes=1511811501118085: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d v2 = v1.ReadAsDateTime();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373345F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373345F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDateTimeOffset_MissingComma>b__0
        internal void ReadAsDateTimeOffset_MissingCommaLambda0()
        {
            // structural signature __cil_value_0aec0fba23dd4f18517263251935b4aa79a008ce bytes=1511811501118119: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTimeOffset>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_0aec0fba23dd4f18517263251935b4aa79a008ce v2 = v1.ReadAsDateTimeOffset();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373355F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373355F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsString_MissingComma>b__0
        internal void ReadAsString_MissingCommaLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373365F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373365F30() : base()
        {
            return;
        }

        // Metadata name: <Read_MissingComma>b__0
        internal void Read_MissingCommaLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373375F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373375F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndAfterReadingN>b__0
        internal void UnexpectedEndAfterReadingNLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373385F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373385F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndAfterReadingNu>b__0
        internal void UnexpectedEndAfterReadingNuLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C617373395F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C617373395F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndAfterReadingNe>b__0
        internal void UnexpectedEndAfterReadingNeLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331305F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331305F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndOfHex>b__0
        internal void UnexpectedEndOfHexLambda0()
        {
            __cil_type_01000027 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331315F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331315F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndOfControlCharacter>b__0
        internal void UnexpectedEndOfControlCharacterLambda0()
        {
            __cil_type_01000027 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331325F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331325F30() : base()
        {
            return;
        }

        // Metadata name: <ReadInvalidNonBase10Number>b__0
        internal void ReadInvalidNonBase10NumberLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }

        // Metadata name: <ReadInvalidNonBase10Number>b__1
        internal void ReadInvalidNonBase10NumberLambda1()
        {
            // structural signature __cil_value_794398513e322fbf3020b98a715664958624dca8 bytes=15118115011180A1: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.Decimal>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_794398513e322fbf3020b98a715664958624dca8 v2 = v1.ReadAsDecimal();
            return;
        }

        // Metadata name: <ReadInvalidNonBase10Number>b__2
        internal void ReadInvalidNonBase10NumberLambda2()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331335F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331335F30() : base()
        {
            return;
        }

        // Metadata name: <ThrowErrorWhenParsingUnquoteStringThatStartsWithNE>b__0
        internal void ThrowErrorWhenParsingUnquoteStringThatStartsWithNELambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331345F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331345F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndOfString>b__0
        internal void UnexpectedEndOfStringLambda0()
        {
            __cil_type_01000027 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331355F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331355F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndTokenWhenParsingOddEndToken>b__0
        internal void UnexpectedEndTokenWhenParsingOddEndTokenLambda0()
        {
            __cil_type_01000027 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331365F30
    {
        public Newtonsoft.Json.JsonTextReader jsonTextReader;

        public __name_3C3E635F5F446973706C6179436C61737331365F30() : base()
        {
            return;
        }

        // Metadata name: <ResetJsonTextReaderErrorCount>b__0
        internal void ResetJsonTextReaderErrorCountLambda0()
        {
            __cil_type_01000043 v1 = this.jsonTextReader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }

        // Metadata name: <ResetJsonTextReaderErrorCount>b__1
        internal void ResetJsonTextReaderErrorCountLambda1()
        {
            __cil_type_01000043 v1 = this.jsonTextReader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }

        // Metadata name: <ResetJsonTextReaderErrorCount>b__2
        internal void ResetJsonTextReaderErrorCountLambda2()
        {
            __cil_type_01000043 v1 = this.jsonTextReader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }

        // Metadata name: <ResetJsonTextReaderErrorCount>b__3
        internal void ResetJsonTextReaderErrorCountLambda3()
        {
            __cil_type_01000043 v1 = this.jsonTextReader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }

        // Metadata name: <ResetJsonTextReaderErrorCount>b__4
        internal void ResetJsonTextReaderErrorCountLambda4()
        {
            __cil_type_01000043 v1 = this.jsonTextReader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }

        // Metadata name: <ResetJsonTextReaderErrorCount>b__5
        internal void ResetJsonTextReaderErrorCountLambda5()
        {
            __cil_type_01000043 v1 = this.jsonTextReader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331375F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331375F30() : base()
        {
            return;
        }

        // Metadata name: <MatchWithInsufficentCharacters>b__0
        internal void MatchWithInsufficentCharactersLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331385F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331385F30() : base()
        {
            return;
        }

        // Metadata name: <MatchWithWrongCharacters>b__0
        internal void MatchWithWrongCharactersLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737331395F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737331395F30() : base()
        {
            return;
        }

        // Metadata name: <MatchWithNoTrailingSeparator>b__0
        internal void MatchWithNoTrailingSeparatorLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332305F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332305F30() : base()
        {
            return;
        }

        // Metadata name: <UnclosedComment>b__0
        internal void UnclosedCommentLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332315F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332315F30() : base()
        {
            return;
        }

        // Metadata name: <BadCommentStart>b__0
        internal void BadCommentStartLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332325F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332325F30() : base()
        {
            return;
        }

        // Metadata name: <MissingColon>b__0
        internal void MissingColonLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E63
    {
        public static readonly Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E63 __il_field_040010AE;
        public static System.Action __il_field_040010AF;

        static __name_3C3E63()
        {
            global::Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E63 v0 = __cil_newobj_06001EAF();
            Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E63.__il_field_040010AE = v0;
            return;
        }

        public __name_3C3E63() : base()
        {
            return;
        }

        // Metadata name: <NullTextReader>b__23_0
        internal void NullTextReaderLambda23_0()
        {
            // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [00, 14, 73, 0F, 01, 00, 0A, 26, 2A]
            // IL_0000: nop 
            // IL_0001: ldnull 
            // IL_0002: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
            // IL_0007: pop 
            // IL_0008: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332345F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332345F30() : base()
        {
            return;
        }

        // Metadata name: <ParseConstructorWithBadCharacter>b__0
        internal void ParseConstructorWithBadCharacterLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            NUnit.Framework.Assert.IsTrue(__cil_bool_store(v2));
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332355F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332355F30() : base()
        {
            return;
        }

        // Metadata name: <ParseConstructorWithUnexpectedEnd>b__0
        internal void ParseConstructorWithUnexpectedEndLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332365F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332365F30() : base()
        {
            return;
        }

        // Metadata name: <ParseConstructorWithUnexpectedCharacter>b__0
        internal void ParseConstructorWithUnexpectedCharacterLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332375F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332375F30() : base()
        {
            return;
        }

        // Metadata name: <ParseAdditionalContent_Comma>b__0
        internal void ParseAdditionalContent_CommaLambda0()
        {
            bool l0 = default;
            goto IL_0005;
            IL_0003: ;
            IL_0005: ;
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            l0 = __cil_bool_store(v2);
            int v3 = __cil_bool_load(l0);
            if (v3 != 0) {
                goto IL_0003;
            } else {
                goto IL_0014;
            }
            IL_0014: ;
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332385F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332385F30() : base()
        {
            return;
        }

        // Metadata name: <ParseAdditionalContent_Text>b__0
        internal void ParseAdditionalContent_TextLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737332395F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737332395F30() : base()
        {
            return;
        }

        // Metadata name: <ParseAdditionalContent_WhitespaceThenText>b__0
        internal void ParseAdditionalContent_WhitespaceThenTextLambda0()
        {
            bool l0 = default;
            goto IL_0005;
            IL_0003: ;
            IL_0005: ;
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            l0 = __cil_bool_store(v2);
            int v3 = __cil_bool_load(l0);
            if (v3 != 0) {
                goto IL_0003;
            } else {
                goto IL_0014;
            }
            IL_0014: ;
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333305F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737333305F30() : base()
        {
            return;
        }

        // Metadata name: <ParseIncompleteCommentSeparator>b__0
        internal void ParseIncompleteCommentSeparatorLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333315F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737333315F30() : base()
        {
            return;
        }

        // Metadata name: <ReadBadCharInArray>b__0
        internal void ReadBadCharInArrayLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333325F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737333325F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytesNoContentWrappedObject>b__0
        internal void ReadAsBytesNoContentWrappedObjectLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333335F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737333335F30() : base()
        {
            return;
        }

        // Metadata name: <ReadBytesEmptyWrappedObject>b__0
        internal void ReadBytesEmptyWrappedObjectLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333345F30
    {
        public Newtonsoft.Json.JsonTextReader jsonTextReader;

        public __name_3C3E635F5F446973706C6179436C61737333345F30() : base()
        {
            return;
        }

        // Metadata name: <ReadIntegerWithError>b__0
        internal void ReadIntegerWithErrorLambda0()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.jsonTextReader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333355F30
    {
        public Newtonsoft.Json.JsonTextReader jsonTextReader;

        public __name_3C3E635F5F446973706C6179436C61737333355F30() : base()
        {
            return;
        }

        // Metadata name: <ReadIntegerWithErrorInArray>b__0
        internal void ReadIntegerWithErrorInArrayLambda0()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.jsonTextReader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }

        // Metadata name: <ReadIntegerWithErrorInArray>b__1
        internal void ReadIntegerWithErrorInArrayLambda1()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.jsonTextReader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }

        // Metadata name: <ReadIntegerWithErrorInArray>b__2
        internal void ReadIntegerWithErrorInArrayLambda2()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.jsonTextReader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }

        // Metadata name: <ReadIntegerWithErrorInArray>b__3
        internal void ReadIntegerWithErrorInArrayLambda3()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.jsonTextReader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333375F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737333375F30() : base()
        {
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333375F31
    {
        public long total;
        public Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E635F5F446973706C6179436C61737333375F30 __il_field_040010BE;

        public __name_3C3E635F5F446973706C6179436C61737333375F31() : base()
        {
            return;
        }

        // Metadata name: <ReadInt32Overflow>b__0
        internal void ReadInt32OverflowLambda0()
        {
            // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [00, 02, 7B, BE, 10, 00, 04, 02, 7C, BD, 10, 00, 04, 28, CA, 01, 00, 0A, 28, 72, 09, 00, 0A, 73]
            // .code-bytes IL_0018: [0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D, BC, 10, 00, 04, 02, 7B, BE, 10, 00, 04, 7B, BC, 10, 00]
            // .code-bytes IL_0030: [04, 6F, 64, 02, 00, 0A, 26, 2A]
            // IL_0000: nop 
            // IL_0001: ldarg.0 0
            // IL_0002: ldfld 0x040010BE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::CS$<>8__locals1
            // IL_0007: ldarg.0 0
            // IL_0008: ldflda 0x040010BD Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::total
            // IL_000D: call 0x0A0001CA [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture
            // IL_0012: call 0x0A000972 [mscorlib]System.Int64::ToString
            // IL_0017: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
            // IL_001C: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
            // IL_0021: stfld 0x040010BC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_0::reader
            // IL_0026: ldarg.0 0
            // IL_0027: ldfld 0x040010BE Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_1::CS$<>8__locals1
            // IL_002C: ldfld 0x040010BC Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass37_0::reader
            // IL_0031: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
            // IL_0036: pop 
            // IL_0037: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333385F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737333385F30() : base()
        {
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333385F31
    {
        public long total;
        public Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests.__name_3C3E635F5F446973706C6179436C61737333385F30 __il_field_040010C1;

        public __name_3C3E635F5F446973706C6179436C61737333385F31() : base()
        {
            return;
        }

        // Metadata name: <ReadInt32Overflow_Negative>b__0
        internal void ReadInt32Overflow_NegativeLambda0()
        {
            // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
            // .maxstack 8
            // .initlocals false
            // .code-bytes IL_0000: [00, 02, 7B, C1, 10, 00, 04, 02, 7C, C0, 10, 00, 04, 28, CA, 01, 00, 0A, 28, 72, 09, 00, 0A, 73]
            // .code-bytes IL_0018: [0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 7D, BF, 10, 00, 04, 02, 7B, C1, 10, 00, 04, 7B, BF, 10, 00]
            // .code-bytes IL_0030: [04, 6F, 64, 02, 00, 0A, 26, 2A]
            // IL_0000: nop 
            // IL_0001: ldarg.0 0
            // IL_0002: ldfld 0x040010C1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::CS$<>8__locals1
            // IL_0007: ldarg.0 0
            // IL_0008: ldflda 0x040010C0 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::total
            // IL_000D: call 0x0A0001CA [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture
            // IL_0012: call 0x0A000972 [mscorlib]System.Int64::ToString
            // IL_0017: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
            // IL_001C: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
            // IL_0021: stfld 0x040010BF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0::reader
            // IL_0026: ldarg.0 0
            // IL_0027: ldfld 0x040010C1 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_1::CS$<>8__locals1
            // IL_002C: ldfld 0x040010BF Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass38_0::reader
            // IL_0031: callvirt 0x0A000264 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::ReadAsInt32
            // IL_0036: pop 
            // IL_0037: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737333395F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737333395F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsString_Null_AdditionalBadData>b__0
        internal void ReadAsString_Null_AdditionalBadDataLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334305F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334305F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBoolean_AdditionalBadData>b__0
        internal void ReadAsBoolean_AdditionalBadDataLambda0()
        {
            // structural signature __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 bytes=151181150102: valuetype [mscorlib]System.Nullable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 v2 = v1.ReadAsBoolean();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334315F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334315F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsString_AdditionalBadData>b__0
        internal void ReadAsString_AdditionalBadDataLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334325F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334325F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBoolean_UnexpectedEnd>b__0
        internal void ReadAsBoolean_UnexpectedEndLambda0()
        {
            // structural signature __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 bytes=151181150102: valuetype [mscorlib]System.Nullable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 v2 = v1.ReadAsBoolean();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334335F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334335F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBoolean_BadData>b__0
        internal void ReadAsBoolean_BadDataLambda0()
        {
            // structural signature __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 bytes=151181150102: valuetype [mscorlib]System.Nullable`1<bool>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_ac4763b604437aa4a3ea3afcc3f007bdc218a048 v2 = v1.ReadAsBoolean();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334345F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334345F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsString_BadData>b__0
        internal void ReadAsString_BadDataLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334355F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334355F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDouble_BadData>b__0
        internal void ReadAsDouble_BadDataLambda0()
        {
            // structural signature __cil_value_0c8535a3fa6a62a183f954283688730df50bd31f bytes=15118115010D: valuetype [mscorlib]System.Nullable`1<float64>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_0c8535a3fa6a62a183f954283688730df50bd31f v2 = v1.ReadAsDouble();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334365F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334365F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDouble_Boolean>b__0
        internal void ReadAsDouble_BooleanLambda0()
        {
            // structural signature __cil_value_0c8535a3fa6a62a183f954283688730df50bd31f bytes=15118115010D: valuetype [mscorlib]System.Nullable`1<float64>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_0c8535a3fa6a62a183f954283688730df50bd31f v2 = v1.ReadAsDouble();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334375F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334375F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytes_BadData>b__0
        internal void ReadAsBytes_BadDataLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334385F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334385F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytesIntegerArrayWithNoEnd>b__0
        internal void ReadAsBytesIntegerArrayWithNoEndLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737334395F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737334395F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytesArrayWithBadContent>b__0
        internal void ReadAsBytesArrayWithBadContentLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335305F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335305F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytesBadContent>b__0
        internal void ReadAsBytesBadContentLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335315F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335315F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytes_CommaErrors>b__0
        internal void ReadAsBytes_CommaErrorsLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335325F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335325F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytes_InvalidEndArray>b__0
        internal void ReadAsBytes_InvalidEndArrayLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335335F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335335F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsBytes_CommaErrors_Multiple>b__0
        internal void ReadAsBytes_CommaErrors_MultipleLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335345F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335345F30() : base()
        {
            return;
        }

        // Metadata name: <ReadBytesWithBadCharacter>b__0
        internal void ReadBytesWithBadCharacterLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000027 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335355F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335355F30() : base()
        {
            return;
        }

        // Metadata name: <ReadBytesWithUnexpectedEnd>b__0
        internal void ReadBytesWithUnexpectedEndLambda0()
        {
            // structural signature __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 bytes=1D05: uint8[]; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; exact reference identity, no member/layout inference.
            __cil_type_01000027 v1 = this.reader;
            __cil_ref_032b9a04b56fba320e3ea99685cb1b602d797648 v2 = v1.ReadAsBytes();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335365F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335365F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDateTime_BadData>b__0
        internal void ReadAsDateTime_BadDataLambda0()
        {
            // structural signature __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d bytes=1511811501118085: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d v2 = v1.ReadAsDateTime();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335375F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335375F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDateTime_Boolean>b__0
        internal void ReadAsDateTime_BooleanLambda0()
        {
            // structural signature __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d bytes=1511811501118085: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d v2 = v1.ReadAsDateTime();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335385F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335385F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDateTimeOffsetBadContent>b__0
        internal void ReadAsDateTimeOffsetBadContentLambda0()
        {
            // structural signature __cil_value_0aec0fba23dd4f18517263251935b4aa79a008ce bytes=1511811501118119: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTimeOffset>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_0aec0fba23dd4f18517263251935b4aa79a008ce v2 = v1.ReadAsDateTimeOffset();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737335395F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737335395F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDecimalBadContent>b__0
        internal void ReadAsDecimalBadContentLambda0()
        {
            // structural signature __cil_value_794398513e322fbf3020b98a715664958624dca8 bytes=15118115011180A1: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.Decimal>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_794398513e322fbf3020b98a715664958624dca8 v2 = v1.ReadAsDecimal();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336305F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336305F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsDecimalBadContent_SecondLine>b__0
        internal void ReadAsDecimalBadContent_SecondLineLambda0()
        {
            // structural signature __cil_value_794398513e322fbf3020b98a715664958624dca8 bytes=15118115011180A1: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.Decimal>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_794398513e322fbf3020b98a715664958624dca8 v2 = v1.ReadAsDecimal();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336315F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336315F30() : base()
        {
            return;
        }

        // Metadata name: <ReadInt32WithBadCharacter>b__0
        internal void ReadInt32WithBadCharacterLambda0()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000027 v1 = this.reader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336325F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336325F30() : base()
        {
            return;
        }

        // Metadata name: <ReadNumberValue_CommaErrors>b__0
        internal void ReadNumberValue_CommaErrorsLambda0()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336335F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336335F30() : base()
        {
            return;
        }

        // Metadata name: <ReadNumberValue_InvalidEndArray>b__0
        internal void ReadNumberValue_InvalidEndArrayLambda0()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336345F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336345F30() : base()
        {
            return;
        }

        // Metadata name: <ReadNumberValue_CommaErrors_Multiple>b__0
        internal void ReadNumberValue_CommaErrors_MultipleLambda0()
        {
            // structural signature __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 bytes=151181150108: valuetype [mscorlib]System.Nullable`1<int32>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_5cf1662422964f50c6bd3358ed80de677cd6b391 v2 = v1.ReadAsInt32();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336355F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336355F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsString_UnexpectedEnd>b__0
        internal void ReadAsString_UnexpectedEndLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336365F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336365F30() : base()
        {
            return;
        }

        // Metadata name: <ReadAsString_Null_UnexpectedEnd>b__0
        internal void ReadAsString_Null_UnexpectedEndLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336375F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336375F30() : base()
        {
            return;
        }

        // Metadata name: <ReadStringValue_InvalidEndArray>b__0
        internal void ReadStringValue_InvalidEndArrayLambda0()
        {
            // structural signature __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d bytes=1511811501118085: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d v2 = v1.ReadAsDateTime();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336385F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336385F30() : base()
        {
            return;
        }

        // Metadata name: <ReadStringValue_CommaErrors>b__0
        internal void ReadStringValue_CommaErrorsLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737336395F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737336395F30() : base()
        {
            return;
        }

        // Metadata name: <ReadStringValue_CommaErrors_Multiple>b__0
        internal void ReadStringValue_CommaErrors_MultipleLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            string v2 = v1.ReadAsString();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337305F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737337305F30() : base()
        {
            return;
        }

        // Metadata name: <ReadStringValue_Numbers_NotString>b__0
        internal void ReadStringValue_Numbers_NotStringLambda0()
        {
            // structural signature __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d bytes=1511811501118085: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d v2 = v1.ReadAsDateTime();
            return;
        }

        // Metadata name: <ReadStringValue_Numbers_NotString>b__1
        internal void ReadStringValue_Numbers_NotStringLambda1()
        {
            // structural signature __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d bytes=1511811501118085: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d v2 = v1.ReadAsDateTime();
            return;
        }

        // Metadata name: <ReadStringValue_Numbers_NotString>b__2
        internal void ReadStringValue_Numbers_NotStringLambda2()
        {
            // structural signature __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d bytes=1511811501118085: valuetype [mscorlib]System.Nullable`1<valuetype [mscorlib]System.DateTime>; type-owner=0x00000000 method-owner=0x00000000; tokens scoped to this input image; whole constructed value snapshot/copy in the original instantiation; no boxing, construction, host layout or address inference.
            __cil_type_01000043 v1 = this.reader;
            __cil_value_4ab65ac3f5de197e0f776b2f21d5cb4a8c02260d v2 = v1.ReadAsDateTime();
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337315F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737337315F30() : base()
        {
            return;
        }

        // Metadata name: <ErrorReadingComment>b__0
        internal void ErrorReadingCommentLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337325F30
    {
        public string json;

        public __name_3C3E635F5F446973706C6179436C61737337325F30() : base()
        {
            return;
        }

        // Metadata name: <EscapedPathInExceptionMessage>b__0
        internal void EscapedPathInExceptionMessageLambda0()
        {
            // IL fallback: external allocation needs dependency facts; only local classes and local instantiations are admitted
            // .maxstack 1
            // .initlocals true
            // .code-bytes IL_0000: [00, 02, 7B, E3, 10, 00, 04, 73, 0E, 01, 00, 0A, 73, 0F, 01, 00, 0A, 0A, 2B, 02, 00, 00, 06, 6F]
            // .code-bytes IL_0018: [72, 01, 00, 0A, 0B, 07, 2D, F4, 2A]
            // .local [0] class [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader
            // .local [1] bool
            // IL_0000: nop 
            // IL_0001: ldarg.0 0
            // IL_0002: ldfld 0x040010E3 Newtonsoft.Json.Tests.JsonTextReaderTests.ExceptionHandlingTests/<>c__DisplayClass72_0::json
            // IL_0007: newobj 0x0A00010E [mscorlib]System.IO.StringReader::.ctor
            // IL_000C: newobj 0x0A00010F [Newtonsoft.Json]Newtonsoft.Json.JsonTextReader::.ctor
            // IL_0011: stloc.0 0
            // IL_0012: br.s IL_0016
            // IL_0014: nop 
            // IL_0015: nop 
            // IL_0016: ldloc.0 0
            // IL_0017: callvirt 0x0A000172 [Newtonsoft.Json]Newtonsoft.Json.JsonReader::Read
            // IL_001C: stloc.1 1
            // IL_001D: ldloc.1 1
            // IL_001E: brtrue.s IL_0014
            // IL_0020: ret 
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337335F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737337335F30() : base()
        {
            return;
        }

        // Metadata name: <MaxDepth>b__0
        internal void MaxDepthLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            NUnit.Framework.Assert.IsTrue(__cil_bool_store(v2));
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337345F30
    {
        public Newtonsoft.Json.JsonTextReader reader;

        public __name_3C3E635F5F446973706C6179436C61737337345F30() : base()
        {
            return;
        }

        // Metadata name: <MaxDepthDoesNotRecursivelyError>b__0
        internal void MaxDepthDoesNotRecursivelyErrorLambda0()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            NUnit.Framework.Assert.IsTrue(__cil_bool_store(v2));
            return;
        }

        // Metadata name: <MaxDepthDoesNotRecursivelyError>b__1
        internal void MaxDepthDoesNotRecursivelyErrorLambda1()
        {
            __cil_type_01000043 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            NUnit.Framework.Assert.IsTrue(__cil_bool_store(v2));
            return;
        }
    }

    private sealed class __name_3C3E635F5F446973706C6179436C61737337355F30
    {
        public Newtonsoft.Json.JsonReader reader;

        public __name_3C3E635F5F446973706C6179436C61737337355F30() : base()
        {
            return;
        }

        // Metadata name: <UnexpectedEndWhenParsingUnquotedProperty>b__0
        internal void UnexpectedEndWhenParsingUnquotedPropertyLambda0()
        {
            __cil_type_01000027 v1 = this.reader;
            int v2 = __cil_bool_load(v1.Read());
            return;
        }
    }
}

// Dependency identity substituted: System.Data.DataSetExtensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0 -> System.Data.DataSetExtensions, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency identity substituted: Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0 -> Microsoft.CSharp, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, ContentType=0x0; IlSpy, metadata only, not original-runtime behavior proof.

// Dependency unresolved: System.Data.Entity, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; reference identity retained.

// Dependency unresolved: System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, ContentType=0x0; reference identity retained.

// Dependency unresolved: System.Data.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, ContentType=0x0; reference identity retained.
