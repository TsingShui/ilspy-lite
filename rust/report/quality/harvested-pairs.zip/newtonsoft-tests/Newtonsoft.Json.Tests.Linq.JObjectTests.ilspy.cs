using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using NUnit.Framework;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Tests.TestObjects;
using Newtonsoft.Json.Tests.TestObjects.Organization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Tests.Linq;

[TestFixture]
public class JObjectTests : TestFixtureBase
{
	public class FooJsonConverter : JsonConverter
	{
		public override bool CanRead => false;

		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			JToken jToken = JToken.FromObject(value, new JsonSerializer
			{
				ContractResolver = new CamelCasePropertyNamesContractResolver()
			});
			if (jToken.Type == JTokenType.Object)
			{
				JObject jObject = (JObject)jToken;
				jObject.AddFirst(new JProperty("foo", "bar"));
				jObject.WriteTo(writer);
			}
			else
			{
				jToken.WriteTo(writer);
			}
		}

		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			throw new NotSupportedException("This custom converter only supportes serialization and not deserialization.");
		}

		public override bool CanConvert(Type objectType)
		{
			return true;
		}
	}

	[Test]
	public void EmbedJValueStringInNewJObject()
	{
		string value = null;
		JValue jValue = new JValue(value);
		dynamic val = JObject.FromObject(new
		{
			title = jValue
		});
		string actual = val.ToString();
		StringAssert.AreEqual("{\r\n  \"title\": null\r\n}", actual);
		Assert.AreEqual(null, jValue.Value);
		Assert.IsNull((string)val.title);
	}

	[Test]
	public void ReadWithSupportMultipleContent()
	{
		string s = "{ 'name': 'Admin' }{ 'name': 'Publisher' }";
		IList<JObject> list = new List<JObject>();
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(s));
		jsonTextReader.SupportMultipleContent = true;
		do
		{
			JObject item = (JObject)JToken.ReadFrom(jsonTextReader);
			list.Add(item);
		}
		while (jsonTextReader.Read());
		Assert.AreEqual(2, list.Count);
		Assert.AreEqual("Admin", (string)list[0]["name"]);
		Assert.AreEqual("Publisher", (string)list[1]["name"]);
	}

	[Test]
	public void JObjectWithComments()
	{
		string json = "{ /*comment2*/\r\n        \"Name\": /*comment3*/ \"Apple\" /*comment4*/, /*comment5*/\r\n        \"ExpiryDate\": \"\\/Date(1230422400000)\\/\",\r\n        \"Price\": 3.99,\r\n        \"Sizes\": /*comment6*/ [ /*comment7*/\r\n          \"Small\", /*comment8*/\r\n          \"Medium\" /*comment9*/,\r\n          /*comment10*/ \"Large\"\r\n        /*comment11*/ ] /*comment12*/\r\n      } /*comment13*/";
		JToken jToken = JToken.Parse(json);
		Assert.AreEqual("Apple", (string)jToken["Name"]);
	}

	[Test]
	public void WritePropertyWithNoValue()
	{
		JObject jObject = new JObject();
		jObject.Add(new JProperty("novalue"));
		StringAssert.AreEqual("{\r\n  \"novalue\": null\r\n}", jObject.ToString());
	}

	[Test]
	public void Keys()
	{
		JObject jObject = new JObject();
		IDictionary<string, JToken> dictionary = jObject;
		Assert.AreEqual(0, dictionary.Keys.Count);
		jObject["value"] = true;
		Assert.AreEqual(1, dictionary.Keys.Count);
	}

	[Test]
	public void TryGetValue()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", new JValue(1L));
		Assert.AreEqual(1, jObject.Children().Count());
		Assert.AreEqual(false, jObject.TryGetValue("sdf", out var value));
		Assert.AreEqual(null, value);
		Assert.AreEqual(false, jObject.TryGetValue(null, out value));
		Assert.AreEqual(null, value);
		Assert.AreEqual(true, jObject.TryGetValue("PropertyNameValue", out value));
		Assert.AreEqual(true, JToken.DeepEquals(new JValue(1L), value));
	}

	[Test]
	public void DictionaryItemShouldSet()
	{
		JObject jObject = new JObject();
		jObject["PropertyNameValue"] = new JValue(1L);
		Assert.AreEqual(1, jObject.Children().Count());
		Assert.AreEqual(true, jObject.TryGetValue("PropertyNameValue", out var value));
		Assert.AreEqual(true, JToken.DeepEquals(new JValue(1L), value));
		jObject["PropertyNameValue"] = new JValue(2L);
		Assert.AreEqual(1, jObject.Children().Count());
		Assert.AreEqual(true, jObject.TryGetValue("PropertyNameValue", out value));
		Assert.AreEqual(true, JToken.DeepEquals(new JValue(2L), value));
		jObject["PropertyNameValue"] = null;
		Assert.AreEqual(1, jObject.Children().Count());
		Assert.AreEqual(true, jObject.TryGetValue("PropertyNameValue", out value));
		Assert.AreEqual(true, JToken.DeepEquals(JValue.CreateNull(), value));
	}

	[Test]
	public void Remove()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", new JValue(1L));
		Assert.AreEqual(1, jObject.Children().Count());
		Assert.AreEqual(false, jObject.Remove("sdf"));
		Assert.AreEqual(false, jObject.Remove(null));
		Assert.AreEqual(true, jObject.Remove("PropertyNameValue"));
		Assert.AreEqual(0, jObject.Children().Count());
	}

	[Test]
	public void GenericCollectionRemove()
	{
		JValue value = new JValue(1L);
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", value);
		Assert.AreEqual(1, jObject.Children().Count());
		Assert.AreEqual(false, ((ICollection<KeyValuePair<string, JToken>>)jObject).Remove(new KeyValuePair<string, JToken>("PropertyNameValue1", new JValue(1L))));
		Assert.AreEqual(false, ((ICollection<KeyValuePair<string, JToken>>)jObject).Remove(new KeyValuePair<string, JToken>("PropertyNameValue", new JValue(2L))));
		Assert.AreEqual(false, ((ICollection<KeyValuePair<string, JToken>>)jObject).Remove(new KeyValuePair<string, JToken>("PropertyNameValue", new JValue(1L))));
		Assert.AreEqual(true, ((ICollection<KeyValuePair<string, JToken>>)jObject).Remove(new KeyValuePair<string, JToken>("PropertyNameValue", value)));
		Assert.AreEqual(0, jObject.Children().Count());
	}

	[Test]
	public void DuplicatePropertyNameShouldThrow()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JObject jObject = new JObject
			{
				{ "PropertyNameValue", null },
				{ "PropertyNameValue", null }
			};
		}, new string[1] { "Can not add property PropertyNameValue to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object." });
	}

	[Test]
	public void GenericDictionaryAdd()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", new JValue(1L));
		Assert.AreEqual(1, (int)jObject["PropertyNameValue"]);
		jObject.Add("PropertyNameValue1", null);
		Assert.AreEqual(null, ((JValue)jObject["PropertyNameValue1"]).Value);
		Assert.AreEqual(2, jObject.Children().Count());
	}

	[Test]
	public void GenericCollectionAdd()
	{
		JObject jObject = new JObject();
		((ICollection<KeyValuePair<string, JToken>>)jObject).Add(new KeyValuePair<string, JToken>("PropertyNameValue", new JValue(1L)));
		Assert.AreEqual(1, (int)jObject["PropertyNameValue"]);
		Assert.AreEqual(1, jObject.Children().Count());
	}

	[Test]
	public void GenericCollectionClear()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", new JValue(1L));
		Assert.AreEqual(1, jObject.Children().Count());
		JProperty jProperty = (JProperty)jObject.Children().ElementAt(0);
		((ICollection<KeyValuePair<string, JToken>>)jObject).Clear();
		Assert.AreEqual(0, jObject.Children().Count());
		Assert.AreEqual(null, jProperty.Parent);
	}

	[Test]
	public void GenericCollectionContains()
	{
		JValue value = new JValue(1L);
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", value);
		Assert.AreEqual(1, jObject.Children().Count());
		bool flag = ((ICollection<KeyValuePair<string, JToken>>)jObject).Contains(new KeyValuePair<string, JToken>("PropertyNameValue", new JValue(1L)));
		Assert.AreEqual(false, flag);
		flag = ((ICollection<KeyValuePair<string, JToken>>)jObject).Contains(new KeyValuePair<string, JToken>("PropertyNameValue", value));
		Assert.AreEqual(true, flag);
		flag = ((ICollection<KeyValuePair<string, JToken>>)jObject).Contains(new KeyValuePair<string, JToken>("PropertyNameValue", new JValue(2L)));
		Assert.AreEqual(false, flag);
		flag = ((ICollection<KeyValuePair<string, JToken>>)jObject).Contains(new KeyValuePair<string, JToken>("PropertyNameValue1", new JValue(1L)));
		Assert.AreEqual(false, flag);
		flag = ((ICollection<KeyValuePair<string, JToken>>)jObject).Contains(default(KeyValuePair<string, JToken>));
		Assert.AreEqual(false, flag);
	}

	[Test]
	public void GenericDictionaryContains()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", new JValue(1L));
		Assert.AreEqual(1, jObject.Children().Count());
		bool flag = ((IDictionary<string, JToken>)jObject).ContainsKey("PropertyNameValue");
		Assert.AreEqual(true, flag);
	}

	[Test]
	public void GenericCollectionCopyTo()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue", new JValue(1L));
		jObject.Add("PropertyNameValue2", new JValue(2L));
		jObject.Add("PropertyNameValue3", new JValue(3L));
		Assert.AreEqual(3, jObject.Children().Count());
		KeyValuePair<string, JToken>[] array = new KeyValuePair<string, JToken>[5];
		((ICollection<KeyValuePair<string, JToken>>)jObject).CopyTo(array, 1);
		Assert.AreEqual(default(KeyValuePair<string, JToken>), array[0]);
		Assert.AreEqual("PropertyNameValue", array[1].Key);
		Assert.AreEqual(1, (int)array[1].Value);
		Assert.AreEqual("PropertyNameValue2", array[2].Key);
		Assert.AreEqual(2, (int)array[2].Value);
		Assert.AreEqual("PropertyNameValue3", array[3].Key);
		Assert.AreEqual(3, (int)array[3].Value);
		Assert.AreEqual(default(KeyValuePair<string, JToken>), array[4]);
	}

	[Test]
	public void GenericCollectionCopyToNullArrayShouldThrow()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JObject jObject = new JObject();
			((ICollection<KeyValuePair<string, JToken>>)jObject).CopyTo((KeyValuePair<string, JToken>[])null, 0);
		}, new string[1] { "Value cannot be null.\r\nParameter name: array" });
	}

	[Test]
	public void GenericCollectionCopyToNegativeArrayIndexShouldThrow()
	{
		ExceptionAssert.Throws<ArgumentOutOfRangeException>(() =>
		{
			JObject jObject = new JObject();
			((ICollection<KeyValuePair<string, JToken>>)jObject).CopyTo(new KeyValuePair<string, JToken>[1], -1);
		}, new string[1] { "arrayIndex is less than 0.\r\nParameter name: arrayIndex" });
	}

	[Test]
	public void GenericCollectionCopyToArrayIndexEqualGreaterToArrayLengthShouldThrow()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JObject jObject = new JObject();
			((ICollection<KeyValuePair<string, JToken>>)jObject).CopyTo(new KeyValuePair<string, JToken>[1], 1);
		}, new string[1] { "arrayIndex is equal to or greater than the length of array." });
	}

	[Test]
	public void GenericCollectionCopyToInsufficientArrayCapacity()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JObject jObject = new JObject();
			jObject.Add("PropertyNameValue", new JValue(1L));
			jObject.Add("PropertyNameValue2", new JValue(2L));
			jObject.Add("PropertyNameValue3", new JValue(3L));
			((ICollection<KeyValuePair<string, JToken>>)jObject).CopyTo(new KeyValuePair<string, JToken>[3], 1);
		}, new string[1] { "The number of elements in the source JObject is greater than the available space from arrayIndex to the end of the destination array." });
	}

	[Test]
	public void FromObjectRaw()
	{
		PersonRaw o = new PersonRaw
		{
			FirstName = "FirstNameValue",
			RawContent = new JRaw("[1,2,3,4,5]"),
			LastName = "LastNameValue"
		};
		JObject jObject = JObject.FromObject(o);
		Assert.AreEqual("FirstNameValue", (string)jObject["first_name"]);
		Assert.AreEqual(JTokenType.Raw, ((JValue)jObject["RawContent"]).Type);
		Assert.AreEqual("[1,2,3,4,5]", (string)jObject["RawContent"]);
		Assert.AreEqual("LastNameValue", (string)jObject["last_name"]);
	}

	[Test]
	public void JTokenReader()
	{
		PersonRaw o = new PersonRaw
		{
			FirstName = "FirstNameValue",
			RawContent = new JRaw("[1,2,3,4,5]"),
			LastName = "LastNameValue"
		};
		JObject token = JObject.FromObject(o);
		JsonReader jsonReader = new JTokenReader(token);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.StartObject, jsonReader.TokenType);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.PropertyName, jsonReader.TokenType);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.String, jsonReader.TokenType);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.PropertyName, jsonReader.TokenType);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.Raw, jsonReader.TokenType);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.PropertyName, jsonReader.TokenType);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.String, jsonReader.TokenType);
		Assert.IsTrue(jsonReader.Read());
		Assert.AreEqual(JsonToken.EndObject, jsonReader.TokenType);
		Assert.IsFalse(jsonReader.Read());
	}

	[Test]
	public void DeserializeFromRaw()
	{
		PersonRaw o = new PersonRaw
		{
			FirstName = "FirstNameValue",
			RawContent = new JRaw("[1,2,3,4,5]"),
			LastName = "LastNameValue"
		};
		JObject token = JObject.FromObject(o);
		JsonReader reader = new JTokenReader(token);
		JsonSerializer jsonSerializer = new JsonSerializer();
		o = (PersonRaw)jsonSerializer.Deserialize(reader, typeof(PersonRaw));
		Assert.AreEqual("FirstNameValue", o.FirstName);
		Assert.AreEqual("LastNameValue", o.LastName);
		Assert.AreEqual("[1,2,3,4,5]", o.RawContent.Value);
	}

	[Test]
	public void Parse_ShouldThrowOnUnexpectedToken()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			string json = "[\"prop\"]";
			JObject.Parse(json);
		}, new string[1] { "Error reading JObject from JsonReader. Current JsonReader item is not an object: StartArray. Path '', line 1, position 1." });
	}

	[Test]
	public void ParseJavaScriptDate()
	{
		string value = "[new Date(1207285200000)]";
		JArray jArray = (JArray)JsonConvert.DeserializeObject(value);
		JValue jValue = (JValue)jArray[0];
		Assert.AreEqual(DateTimeUtils.ConvertJavaScriptTicksToDateTime(1207285200000L), (DateTime)(JToken)jValue);
	}

	[Test]
	public void GenericValueCast()
	{
		string value = "{\"foo\":true}";
		JObject jObject = (JObject)JsonConvert.DeserializeObject(value);
		bool? flag = jObject.Value<bool?>("foo");
		Assert.AreEqual(true, flag);
		value = "{\"foo\":null}";
		jObject = (JObject)JsonConvert.DeserializeObject(value);
		flag = jObject.Value<bool?>("foo");
		Assert.AreEqual(null, flag);
	}

	[Test]
	public void Blog()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JObject.Parse("{\r\n    \"name\": \"James\",\r\n    ]!#$THIS IS: BAD JSON![{}}}}]\r\n  }");
		}, new string[1] { "Invalid property identifier character: ]. Path 'name', line 3, position 4." });
	}

	[Test]
	public void RawChildValues()
	{
		JObject jObject = new JObject();
		jObject["val1"] = new JRaw("1");
		jObject["val2"] = new JRaw("1");
		string actual = jObject.ToString();
		StringAssert.AreEqual("{\r\n  \"val1\": 1,\r\n  \"val2\": 1\r\n}", actual);
	}

	[Test]
	public void Iterate()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue1", new JValue(1L));
		jObject.Add("PropertyNameValue2", new JValue(2L));
		JToken jToken = jObject;
		int num = 1;
		foreach (JProperty item in (IEnumerable<JToken>)jToken)
		{
			Assert.AreEqual("PropertyNameValue" + num, item.Name);
			Assert.AreEqual(num, (int)item.Value);
			num++;
		}
	}

	[Test]
	public void KeyValuePairIterate()
	{
		JObject jObject = new JObject();
		jObject.Add("PropertyNameValue1", new JValue(1L));
		jObject.Add("PropertyNameValue2", new JValue(2L));
		int num = 1;
		foreach (KeyValuePair<string, JToken> item in jObject)
		{
			Assert.AreEqual("PropertyNameValue" + num, item.Key);
			Assert.AreEqual(num, (int)item.Value);
			num++;
		}
	}

	[Test]
	public void WriteObjectNullStringValue()
	{
		string value = null;
		JValue jValue = new JValue(value);
		Assert.AreEqual(null, jValue.Value);
		Assert.AreEqual(JTokenType.String, jValue.Type);
		JObject jObject = new JObject();
		jObject["title"] = jValue;
		string actual = jObject.ToString();
		StringAssert.AreEqual("{\r\n  \"title\": null\r\n}", actual);
	}

	[Test]
	public void Example()
	{
		string json = "{\r\n        \"Name\": \"Apple\",\r\n        \"Expiry\": new Date(1230422400000),\r\n        \"Price\": 3.99,\r\n        \"Sizes\": [\r\n          \"Small\",\r\n          \"Medium\",\r\n          \"Large\"\r\n        ]\r\n      }";
		JObject jObject = JObject.Parse(json);
		string actual = (string)jObject["Name"];
		JArray jArray = (JArray)jObject["Sizes"];
		string actual2 = (string)jArray[0];
		Assert.AreEqual("Apple", actual);
		Assert.AreEqual("Small", actual2);
	}

	[Test]
	public void DeserializeClassManually()
	{
		string json = "{\r\n  \"short\":\r\n  {\r\n    \"original\":\"http://www.foo.com/\",\r\n    \"short\":\"krehqk\",\r\n    \"error\":\r\n    {\r\n      \"code\":0,\r\n      \"msg\":\"No action taken\"\r\n    }\r\n  }\r\n}";
		JObject jObject = JObject.Parse(json);
		Shortie shortie = new Shortie
		{
			Original = (string)jObject["short"]["original"],
			Short = (string)jObject["short"]["short"],
			Error = new ShortieException
			{
				Code = (int)jObject["short"]["error"]["code"],
				ErrorMessage = (string)jObject["short"]["error"]["msg"]
			}
		};
		Assert.AreEqual("http://www.foo.com/", shortie.Original);
		Assert.AreEqual("krehqk", shortie.Short);
		Assert.AreEqual(null, shortie.Shortened);
		Assert.AreEqual(0, shortie.Error.Code);
		Assert.AreEqual("No action taken", shortie.Error.ErrorMessage);
	}

	[Test]
	public void JObjectContainingHtml()
	{
		JObject jObject = new JObject();
		jObject["rc"] = new JValue(200L);
		jObject["m"] = new JValue("");
		jObject["o"] = new JValue("<div class='s1'>\r\n</div>");
		StringAssert.AreEqual("{\r\n  \"rc\": 200,\r\n  \"m\": \"\",\r\n  \"o\": \"<div class='s1'>\\r\\n</div>\"\r\n}", jObject.ToString());
	}

	[Test]
	public void ImplicitValueConversions()
	{
		JObject jObject = new JObject();
		jObject["FirstName"] = new JValue("Maurice");
		jObject["LastName"] = new JValue("Moss");
		jObject["BirthDate"] = new JValue(new DateTime(1977, 12, 30));
		jObject["Department"] = new JValue("IT");
		jObject["JobTitle"] = new JValue("Support");
		StringAssert.AreEqual("{\r\n  \"FirstName\": \"Maurice\",\r\n  \"LastName\": \"Moss\",\r\n  \"BirthDate\": \"1977-12-30T00:00:00\",\r\n  \"Department\": \"IT\",\r\n  \"JobTitle\": \"Support\"\r\n}", jObject.ToString());
		JObject jObject2 = new JObject();
		jObject2["FirstName"] = "Jen";
		jObject2["LastName"] = "Barber";
		jObject2["BirthDate"] = new DateTime(1978, 3, 15);
		jObject2["Department"] = "IT";
		jObject2["JobTitle"] = "Manager";
		StringAssert.AreEqual("{\r\n  \"FirstName\": \"Jen\",\r\n  \"LastName\": \"Barber\",\r\n  \"BirthDate\": \"1978-03-15T00:00:00\",\r\n  \"Department\": \"IT\",\r\n  \"JobTitle\": \"Manager\"\r\n}", jObject2.ToString());
	}

	[Test]
	public void ReplaceJPropertyWithJPropertyWithSameName()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		JObject jObject = new JObject(jProperty, jProperty2);
		IList list = jObject;
		Assert.AreEqual(jProperty, list[0]);
		Assert.AreEqual(jProperty2, list[1]);
		JProperty jProperty3 = new JProperty("Test1", "III");
		jProperty.Replace(jProperty3);
		Assert.AreEqual(null, jProperty.Parent);
		Assert.AreEqual(list, jProperty3.Parent);
		Assert.AreEqual(jProperty3, list[0]);
		Assert.AreEqual(jProperty2, list[1]);
		Assert.AreEqual(2, list.Count);
		Assert.AreEqual(2, jObject.Properties().Count());
		JProperty jProperty4 = new JProperty("Test4", "IV");
		jProperty2.Replace(jProperty4);
		Assert.AreEqual(null, jProperty2.Parent);
		Assert.AreEqual(list, jProperty4.Parent);
		Assert.AreEqual(jProperty3, list[0]);
		Assert.AreEqual(jProperty4, list[1]);
	}

	[Test]
	public void PropertyChanged()
	{
		object changed = null;
		int changedCount = 0;
		JObject jObject = new JObject();
		jObject.PropertyChanged += (object sender, PropertyChangedEventArgs args) =>
		{
			JObject jObject2 = (JObject)sender;
			changed = ((jObject2[args.PropertyName] != null) ? ((JValue)jObject2[args.PropertyName]).Value : null);
			changedCount++;
		};
		jObject["StringValue"] = "value1";
		Assert.AreEqual("value1", changed);
		Assert.AreEqual("value1", (string)jObject["StringValue"]);
		Assert.AreEqual(1, changedCount);
		jObject["StringValue"] = "value1";
		Assert.AreEqual(1, changedCount);
		jObject["StringValue"] = "value2";
		Assert.AreEqual("value2", changed);
		Assert.AreEqual("value2", (string)jObject["StringValue"]);
		Assert.AreEqual(2, changedCount);
		jObject["StringValue"] = null;
		Assert.AreEqual(null, changed);
		Assert.AreEqual(null, (string)jObject["StringValue"]);
		Assert.AreEqual(3, changedCount);
		jObject["NullValue"] = null;
		Assert.AreEqual(null, changed);
		Assert.AreEqual(JValue.CreateNull(), jObject["NullValue"]);
		Assert.AreEqual(4, changedCount);
		jObject["NullValue"] = null;
		Assert.AreEqual(4, changedCount);
	}

	[Test]
	public void IListContains()
	{
		JProperty jProperty = new JProperty("Test", 1);
		IList list = new JObject(jProperty);
		Assert.IsTrue(list.Contains(jProperty));
		Assert.IsFalse(list.Contains(new JProperty("Test", 1)));
	}

	[Test]
	public void IListIndexOf()
	{
		JProperty jProperty = new JProperty("Test", 1);
		IList list = new JObject(jProperty);
		Assert.AreEqual(0, list.IndexOf(jProperty));
		Assert.AreEqual(-1, list.IndexOf(new JProperty("Test", 1)));
	}

	[Test]
	public void IListClear()
	{
		JProperty content = new JProperty("Test", 1);
		IList list = new JObject(content);
		Assert.AreEqual(1, list.Count);
		list.Clear();
		Assert.AreEqual(0, list.Count);
	}

	[Test]
	public void IListCopyTo()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		object[] array = new object[list.Count];
		list.CopyTo(array, 0);
		Assert.AreEqual(jProperty, array[0]);
		Assert.AreEqual(jProperty2, array[1]);
	}

	[Test]
	public void IListAdd()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		JProperty jProperty3 = new JProperty("Test3", "III");
		list.Add(jProperty3);
		Assert.AreEqual(3, list.Count);
		Assert.AreEqual(jProperty3, list[2]);
	}

	[Test]
	public void IListAddBadToken()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList list = new JObject(jProperty, jProperty2) { (object?)new JValue("Bad!") };
		}, new string[1] { "Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject." });
	}

	[Test]
	public void IListAddBadValue()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList list = new JObject(jProperty, jProperty2) { (object?)"Bad!" };
		}, new string[1] { "Argument is not a JToken." });
	}

	[Test]
	public void IListAddPropertyWithExistingName()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList list = new JObject(jProperty, jProperty2);
			JProperty value = new JProperty("Test2", "II");
			list.Add(value);
		}, new string[1] { "Can not add property Test2 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object." });
	}

	[Test]
	public void IListRemove()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		JProperty value = new JProperty("Test3", "III");
		list.Remove(value);
		Assert.AreEqual(2, list.Count);
		list.Remove(jProperty);
		Assert.AreEqual(1, list.Count);
		Assert.IsFalse(list.Contains(jProperty));
		Assert.IsTrue(list.Contains(jProperty2));
		list.Remove(jProperty2);
		Assert.AreEqual(0, list.Count);
		Assert.IsFalse(list.Contains(jProperty2));
		Assert.AreEqual(null, jProperty2.Parent);
	}

	[Test]
	public void IListRemoveAt()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		list.RemoveAt(0);
		list.Remove(jProperty);
		Assert.AreEqual(1, list.Count);
		list.Remove(jProperty2);
		Assert.AreEqual(0, list.Count);
	}

	[Test]
	public void IListInsert()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		JProperty jProperty3 = new JProperty("Test3", "III");
		list.Insert(1, jProperty3);
		Assert.AreEqual(list, jProperty3.Parent);
		Assert.AreEqual(jProperty, list[0]);
		Assert.AreEqual(jProperty3, list[1]);
		Assert.AreEqual(jProperty2, list[2]);
	}

	[Test]
	public void IListIsReadOnly()
	{
		IList list = new JObject();
		Assert.IsFalse(list.IsReadOnly);
	}

	[Test]
	public void IListIsFixedSize()
	{
		IList list = new JObject();
		Assert.IsFalse(list.IsFixedSize);
	}

	[Test]
	public void IListSetItem()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		JProperty expected = (JProperty)(list[0] = new JProperty("Test3", "III"));
		Assert.AreEqual(expected, list[0]);
		Assert.AreEqual(jProperty2, list[1]);
	}

	[Test]
	public void IListSetItemAlreadyExists()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList list = new JObject(jProperty, jProperty2);
			JProperty value = (JProperty)(list[0] = new JProperty("Test3", "III"));
			list[1] = value;
		}, new string[1] { "Can not add property Test3 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object." });
	}

	[Test]
	public void IListSetItemInvalid()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList list = new JObject(jProperty, jProperty2) { [0] = new JValue(value: true) };
		}, new string[1] { "Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject." });
	}

	[Test]
	public void IListSyncRoot()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		Assert.IsNotNull(list.SyncRoot);
	}

	[Test]
	public void IListIsSynchronized()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList list = new JObject(jProperty, jProperty2);
		Assert.IsFalse(list.IsSynchronized);
	}

	[Test]
	public void GenericListJTokenContains()
	{
		JProperty jProperty = new JProperty("Test", 1);
		IList<JToken> list = new JObject(jProperty);
		Assert.IsTrue(list.Contains(jProperty));
		Assert.IsFalse(list.Contains(new JProperty("Test", 1)));
	}

	[Test]
	public void GenericListJTokenIndexOf()
	{
		JProperty jProperty = new JProperty("Test", 1);
		IList<JToken> list = new JObject(jProperty);
		Assert.AreEqual(0, list.IndexOf(jProperty));
		Assert.AreEqual(-1, list.IndexOf(new JProperty("Test", 1)));
	}

	[Test]
	public void GenericListJTokenClear()
	{
		JProperty content = new JProperty("Test", 1);
		IList<JToken> list = new JObject(content);
		Assert.AreEqual(1, list.Count);
		list.Clear();
		Assert.AreEqual(0, list.Count);
	}

	[Test]
	public void GenericListJTokenCopyTo()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList<JToken> list = new JObject(jProperty, jProperty2);
		JToken[] array = new JToken[list.Count];
		list.CopyTo(array, 0);
		Assert.AreEqual(jProperty, array[0]);
		Assert.AreEqual(jProperty2, array[1]);
	}

	[Test]
	public void GenericListJTokenAdd()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList<JToken> list = new JObject(jProperty, jProperty2);
		JProperty jProperty3 = new JProperty("Test3", "III");
		list.Add(jProperty3);
		Assert.AreEqual(3, list.Count);
		Assert.AreEqual(jProperty3, list[2]);
	}

	[Test]
	public void GenericListJTokenAddBadToken()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList<JToken> list = new JObject(jProperty, jProperty2) { (JToken)new JValue("Bad!") };
		}, new string[1] { "Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject." });
	}

	[Test]
	public void GenericListJTokenAddBadValue()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList<JToken> list = new JObject(jProperty, jProperty2) { (JToken)"Bad!" };
		}, new string[1] { "Can not add Newtonsoft.Json.Linq.JValue to Newtonsoft.Json.Linq.JObject." });
	}

	[Test]
	public void GenericListJTokenAddPropertyWithExistingName()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList<JToken> list = new JObject(jProperty, jProperty2);
			JProperty item = new JProperty("Test2", "II");
			list.Add(item);
		}, new string[1] { "Can not add property Test2 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object." });
	}

	[Test]
	public void GenericListJTokenRemove()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList<JToken> list = new JObject(jProperty, jProperty2);
		JProperty item = new JProperty("Test3", "III");
		Assert.IsFalse(list.Remove(item));
		Assert.AreEqual(2, list.Count);
		Assert.IsTrue(list.Remove(jProperty));
		Assert.AreEqual(1, list.Count);
		Assert.IsFalse(list.Contains(jProperty));
		Assert.IsTrue(list.Contains(jProperty2));
		Assert.IsTrue(list.Remove(jProperty2));
		Assert.AreEqual(0, list.Count);
		Assert.IsFalse(list.Contains(jProperty2));
		Assert.AreEqual(null, jProperty2.Parent);
	}

	[Test]
	public void GenericListJTokenRemoveAt()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList<JToken> list = new JObject(jProperty, jProperty2);
		list.RemoveAt(0);
		list.Remove(jProperty);
		Assert.AreEqual(1, list.Count);
		list.Remove(jProperty2);
		Assert.AreEqual(0, list.Count);
	}

	[Test]
	public void GenericListJTokenInsert()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList<JToken> list = new JObject(jProperty, jProperty2);
		JProperty jProperty3 = new JProperty("Test3", "III");
		list.Insert(1, jProperty3);
		Assert.AreEqual(list, jProperty3.Parent);
		Assert.AreEqual(jProperty, list[0]);
		Assert.AreEqual(jProperty3, list[1]);
		Assert.AreEqual(jProperty2, list[2]);
	}

	[Test]
	public void GenericListJTokenIsReadOnly()
	{
		IList<JToken> list = new JObject();
		Assert.IsFalse(list.IsReadOnly);
	}

	[Test]
	public void GenericListJTokenSetItem()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		IList<JToken> list = new JObject(jProperty, jProperty2);
		JProperty expected = (JProperty)(list[0] = new JProperty("Test3", "III"));
		Assert.AreEqual(expected, list[0]);
		Assert.AreEqual(jProperty2, list[1]);
	}

	[Test]
	public void GenericListJTokenSetItemAlreadyExists()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JProperty jProperty = new JProperty("Test1", 1);
			JProperty jProperty2 = new JProperty("Test2", "Two");
			IList<JToken> list = new JObject(jProperty, jProperty2);
			JProperty value = (JProperty)(list[0] = new JProperty("Test3", "III"));
			list[1] = value;
		}, new string[1] { "Can not add property Test3 to Newtonsoft.Json.Linq.JObject. Property with the same name already exists on object." });
	}

	[Test]
	public void CollectionChanged()
	{
		JProperty jProperty = new JProperty("Test1", 1);
		JProperty jProperty2 = new JProperty("Test2", "Two");
		JObject jObject = new JObject(jProperty, jProperty2);
		NotifyCollectionChangedAction? changedType = null;
		int? index = null;
		jObject._collectionChanged = (NotifyCollectionChangedEventHandler)Delegate.Combine(jObject._collectionChanged, (NotifyCollectionChangedEventHandler)((object s, NotifyCollectionChangedEventArgs a) =>
		{
			changedType = a.Action;
			index = a.NewStartingIndex;
		}));
		JProperty jProperty3 = new JProperty("Test3", "III");
		jObject.Add(jProperty3);
		Assert.AreEqual(changedType, NotifyCollectionChangedAction.Add);
		Assert.AreEqual(index, 2);
		Assert.AreEqual(jProperty3, ((IList<JToken>)jObject)[index.Value]);
		JProperty jProperty4 = new JProperty("Test4", "IV");
		((IList<JToken>)jObject)[index.Value] = jProperty4;
		Assert.AreEqual(changedType, NotifyCollectionChangedAction.Replace);
		Assert.AreEqual(index, 2);
		Assert.AreEqual(jProperty4, ((IList<JToken>)jObject)[index.Value]);
		Assert.IsFalse(((ICollection<JToken>)jObject).Contains((JToken)jProperty3));
		Assert.IsTrue(((ICollection<JToken>)jObject).Contains((JToken)jProperty4));
		jObject["Test1"] = 2;
		Assert.AreEqual(changedType, NotifyCollectionChangedAction.Replace);
		Assert.AreEqual(index, 0);
		Assert.AreEqual(2, (int)jObject["Test1"]);
	}

	[Test]
	public void GetGeocodeAddress()
	{
		string json = "{\r\n  \"name\": \"Address: 435 North Mulford Road Rockford, IL 61107\",\r\n  \"Status\": {\r\n    \"code\": 200,\r\n    \"request\": \"geocode\"\r\n  },\r\n  \"Placemark\": [ {\r\n    \"id\": \"p1\",\r\n    \"address\": \"435 N Mulford Rd, Rockford, IL 61107, USA\",\r\n    \"AddressDetails\": {\r\n   \"Accuracy\" : 8,\r\n   \"Country\" : {\r\n      \"AdministrativeArea\" : {\r\n         \"AdministrativeAreaName\" : \"IL\",\r\n         \"SubAdministrativeArea\" : {\r\n            \"Locality\" : {\r\n               \"LocalityName\" : \"Rockford\",\r\n               \"PostalCode\" : {\r\n                  \"PostalCodeNumber\" : \"61107\"\r\n               },\r\n               \"Thoroughfare\" : {\r\n                  \"ThoroughfareName\" : \"435 N Mulford Rd\"\r\n               }\r\n            },\r\n            \"SubAdministrativeAreaName\" : \"Winnebago\"\r\n         }\r\n      },\r\n      \"CountryName\" : \"USA\",\r\n      \"CountryNameCode\" : \"US\"\r\n   }\r\n},\r\n    \"ExtendedData\": {\r\n      \"LatLonBox\": {\r\n        \"north\": 42.2753076,\r\n        \"south\": 42.2690124,\r\n        \"east\": -88.9964645,\r\n        \"west\": -89.0027597\r\n      }\r\n    },\r\n    \"Point\": {\r\n      \"coordinates\": [ -88.9995886, 42.2721596, 0 ]\r\n    }\r\n  } ]\r\n}";
		JObject jObject = JObject.Parse(json);
		string actual = (string)jObject["Placemark"][0]["AddressDetails"]["Country"]["AdministrativeArea"]["SubAdministrativeArea"]["Locality"]["Thoroughfare"]["ThoroughfareName"];
		Assert.AreEqual("435 N Mulford Rd", actual);
	}

	[Test]
	public void SetValueWithInvalidPropertyName()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			JObject jObject = new JObject { [0] = new JValue(3L) };
		}, new string[1] { "Set JObject values with invalid key value: 0. Object property name expected." });
	}

	[Test]
	public void SetValue()
	{
		object key = "TestKey";
		JObject jObject = new JObject();
		jObject[key] = new JValue(3L);
		Assert.AreEqual(3, (int)jObject[key]);
	}

	[Test]
	public void ParseMultipleProperties()
	{
		string json = "{\r\n        \"Name\": \"Name1\",\r\n        \"Name\": \"Name2\"\r\n      }";
		JObject jObject = JObject.Parse(json);
		string actual = (string)jObject["Name"];
		Assert.AreEqual("Name2", actual);
	}

	[Test]
	public void InvalidValueCastExceptionMessage()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			string json = "{\r\n  \"responseData\": {}, \r\n  \"responseDetails\": null, \r\n  \"responseStatus\": 200\r\n}";
			JObject jObject = JObject.Parse(json);
			string text = (string)jObject["responseData"];
		}, new string[1] { "Can not convert Object to String." });
	}

	[Test]
	public void InvalidPropertyValueCastExceptionMessage()
	{
		ExceptionAssert.Throws<ArgumentException>(() =>
		{
			string json = "{\r\n  \"responseData\": {}, \r\n  \"responseDetails\": null, \r\n  \"responseStatus\": 200\r\n}";
			JObject jObject = JObject.Parse(json);
			string text = (string)(JToken)jObject.Property("responseData");
		}, new string[1] { "Can not convert Object to String." });
	}

	[Test]
	public void ParseIncomplete()
	{
		ExceptionAssert.Throws<Exception>(() =>
		{
			JObject.Parse("{ foo:");
		}, new string[1] { "Unexpected end of content while loading JObject. Path 'foo', line 1, position 6." });
	}

	[Test]
	public void LoadFromNestedObject()
	{
		string s = "{\r\n  \"short\":\r\n  {\r\n    \"error\":\r\n    {\r\n      \"code\":0,\r\n      \"msg\":\"No action taken\"\r\n    }\r\n  }\r\n}";
		JsonReader jsonReader = new JsonTextReader(new StringReader(s));
		jsonReader.Read();
		jsonReader.Read();
		jsonReader.Read();
		jsonReader.Read();
		jsonReader.Read();
		JObject jObject = (JObject)JToken.ReadFrom(jsonReader);
		Assert.IsNotNull(jObject);
		StringAssert.AreEqual("{\r\n  \"code\": 0,\r\n  \"msg\": \"No action taken\"\r\n}", jObject.ToString(Formatting.Indented));
	}

	[Test]
	public void LoadFromNestedObjectIncomplete()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			string s = "{\r\n  \"short\":\r\n  {\r\n    \"error\":\r\n    {\r\n      \"code\":0";
			JsonReader jsonReader = new JsonTextReader(new StringReader(s));
			jsonReader.Read();
			jsonReader.Read();
			jsonReader.Read();
			jsonReader.Read();
			jsonReader.Read();
			JToken.ReadFrom(jsonReader);
		}, new string[1] { "Unexpected end of content while loading JObject. Path 'short.error.code', line 6, position 14." });
	}

	[Test]
	public void ParseEmptyObjectWithComment()
	{
		JObject jObject = JObject.Parse("{ /* A Comment */ }");
		Assert.AreEqual(0, jObject.Count);
	}

	[Test]
	public void FromObjectTimeSpan()
	{
		JValue jValue = (JValue)JToken.FromObject(TimeSpan.FromDays(1.0));
		Assert.AreEqual(jValue.Value, TimeSpan.FromDays(1.0));
		Assert.AreEqual("1.00:00:00", jValue.ToString());
	}

	[Test]
	public void FromObjectUri()
	{
		JValue jValue = (JValue)JToken.FromObject(new Uri("http://www.stuff.co.nz"));
		Assert.AreEqual(jValue.Value, new Uri("http://www.stuff.co.nz"));
		Assert.AreEqual("http://www.stuff.co.nz/", jValue.ToString());
	}

	[Test]
	public void FromObjectGuid()
	{
		JValue jValue = (JValue)JToken.FromObject(new Guid("9065ACF3-C820-467D-BE50-8D4664BEAF35"));
		Assert.AreEqual(jValue.Value, new Guid("9065ACF3-C820-467D-BE50-8D4664BEAF35"));
		Assert.AreEqual("9065acf3-c820-467d-be50-8d4664beaf35", jValue.ToString());
	}

	[Test]
	public void ParseAdditionalContent()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			string json = "{\r\n\"Name\": \"Apple\",\r\n\"Expiry\": new Date(1230422400000),\r\n\"Price\": 3.99,\r\n\"Sizes\": [\r\n\"Small\",\r\n\"Medium\",\r\n\"Large\"\r\n]\r\n}, 987987";
			JObject jObject = JObject.Parse(json);
		}, new string[1] { "Additional text encountered after finished reading JSON content: ,. Path '', line 10, position 1." });
	}

	[Test]
	public void DeepEqualsIgnoreOrder()
	{
		JObject jObject = new JObject(new JProperty("null", null), new JProperty("integer", 1), new JProperty("string", "string!"), new JProperty("decimal", 0.5m), new JProperty("array", new JArray(1, 2)));
		Assert.IsTrue(jObject.DeepEquals(jObject));
		JObject node = new JObject(new JProperty("null", null), new JProperty("string", "string!"), new JProperty("decimal", 0.5m), new JProperty("integer", 1), new JProperty("array", new JArray(1, 2)));
		Assert.IsTrue(jObject.DeepEquals(node));
		JObject node2 = new JObject(new JProperty("null", null), new JProperty("string", "string!"), new JProperty("decimal", 0.5m), new JProperty("integer", 2), new JProperty("array", new JArray(1, 2)));
		Assert.IsFalse(jObject.DeepEquals(node2));
		JObject node3 = new JObject(new JProperty("null", null), new JProperty("string", "string!"), new JProperty("decimal", 0.5m), new JProperty("integer", 1), new JProperty("array", new JArray(2, 1)));
		Assert.IsFalse(jObject.DeepEquals(node3));
		JObject node4 = new JObject(new JProperty("null", null), new JProperty("string", "string!"), new JProperty("decimal", 0.5m), new JProperty("integer", 1));
		Assert.IsFalse(jObject.DeepEquals(node4));
		Assert.IsFalse(jObject.DeepEquals(null));
	}

	[Test]
	public void ToListOnEmptyObject()
	{
		JObject source = JObject.Parse("{}");
		IList<JToken> list = source.ToList<JToken>();
		Assert.AreEqual(0, list.Count);
		IList<KeyValuePair<string, JToken>> list2 = source.ToList<KeyValuePair<string, JToken>>();
		Assert.AreEqual(0, list2.Count);
		source = JObject.Parse("{'hi':null}");
		list = source.ToList<JToken>();
		Assert.AreEqual(1, list.Count);
		list2 = source.ToList<KeyValuePair<string, JToken>>();
		Assert.AreEqual(1, list2.Count);
	}

	[Test]
	public void EmptyObjectDeepEquals()
	{
		Assert.IsTrue(JToken.DeepEquals(new JObject(), new JObject()));
		JObject jObject = new JObject();
		JObject jObject2 = new JObject();
		jObject2.Add("hi", "bye");
		jObject2.Remove("hi");
		Assert.IsTrue(JToken.DeepEquals(jObject, jObject2));
		Assert.IsTrue(JToken.DeepEquals(jObject2, jObject));
	}

	[Test]
	public void GetValueBlogExample()
	{
		JObject jObject = JObject.Parse("{\r\n        'name': 'Lower',\r\n        'NAME': 'Upper'\r\n      }");
		string actual = (string)jObject.GetValue("NAME", StringComparison.OrdinalIgnoreCase);
		string actual2 = (string)jObject.GetValue("Name", StringComparison.OrdinalIgnoreCase);
		Assert.AreEqual("Upper", actual);
		Assert.AreEqual("Lower", actual2);
	}

	[Test]
	public void GetValue()
	{
		JObject jObject = new JObject();
		jObject["Name"] = "Name!";
		jObject["name"] = "name!";
		jObject["title"] = "Title!";
		Assert.AreEqual(null, jObject.GetValue("NAME", StringComparison.Ordinal));
		Assert.AreEqual(null, jObject.GetValue("NAME"));
		Assert.AreEqual(null, jObject.GetValue("TITLE"));
		Assert.AreEqual("Name!", (string)jObject.GetValue("NAME", StringComparison.OrdinalIgnoreCase));
		Assert.AreEqual("name!", (string)jObject.GetValue("name", StringComparison.Ordinal));
		Assert.AreEqual(null, jObject.GetValue(null, StringComparison.Ordinal));
		Assert.AreEqual(null, jObject.GetValue(null));
		Assert.IsFalse(jObject.TryGetValue("NAME", StringComparison.Ordinal, out var value));
		Assert.AreEqual(null, value);
		Assert.IsFalse(jObject.TryGetValue("NAME", out value));
		Assert.IsFalse(jObject.TryGetValue("TITLE", out value));
		Assert.IsTrue(jObject.TryGetValue("NAME", StringComparison.OrdinalIgnoreCase, out value));
		Assert.AreEqual("Name!", (string)value);
		Assert.IsTrue(jObject.TryGetValue("name", StringComparison.Ordinal, out value));
		Assert.AreEqual("name!", (string)value);
		Assert.IsFalse(jObject.TryGetValue(null, StringComparison.Ordinal, out value));
	}

	[Test]
	public void FromObjectInsideConverterWithCustomSerializer()
	{
		Person value = new Person
		{
			Name = "Daniel Wertheim"
		};
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			Converters = new List<JsonConverter>
			{
				new FooJsonConverter()
			},
			ContractResolver = new CamelCasePropertyNamesContractResolver()
		};
		string actual = JsonConvert.SerializeObject(value, settings);
		Assert.AreEqual("{\"foo\":\"bar\",\"name\":\"Daniel Wertheim\",\"birthDate\":\"0001-01-01T00:00:00\",\"lastModified\":\"0001-01-01T00:00:00\"}", actual);
	}

	[Test]
	public void Parse_NoComments()
	{
		string json = "{'prop':[1,2/*comment*/,3]}";
		JObject jObject = JObject.Parse(json, new JsonLoadSettings
		{
			CommentHandling = CommentHandling.Ignore
		});
		Assert.AreEqual(3, jObject["prop"].Count());
		Assert.AreEqual(1, (int)jObject["prop"][0]);
		Assert.AreEqual(2, (int)jObject["prop"][1]);
		Assert.AreEqual(3, (int)jObject["prop"][2]);
	}

	[Test]
	public void Parse_ExcessiveContentJustComments()
	{
		string json = "{'prop':[1,2,3]}/*comment*/\r\n//Another comment.";
		JObject jObject = JObject.Parse(json);
		Assert.AreEqual(3, jObject["prop"].Count());
		Assert.AreEqual(1, (int)jObject["prop"][0]);
		Assert.AreEqual(2, (int)jObject["prop"][1]);
		Assert.AreEqual(3, (int)jObject["prop"][2]);
	}

	[Test]
	public void Parse_ExcessiveContent()
	{
		string json = "{'prop':[1,2,3]}/*comment*/\r\n//Another comment.\r\n[]";
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JObject.Parse(json);
		}, new string[1] { "Additional text encountered after finished reading JSON content: [. Path '', line 3, position 0." });
	}
}
