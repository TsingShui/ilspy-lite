using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Drawing;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Xml.Linq;
using NUnit.Framework;
using Newtonsoft.Json.Bson;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Tests.Linq;
using Newtonsoft.Json.Tests.TestObjects;
using Newtonsoft.Json.Tests.TestObjects.Events;
using Newtonsoft.Json.Tests.TestObjects.GeoCoding;
using Newtonsoft.Json.Tests.TestObjects.Organization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Tests.Serialization;

[TestFixture]
public class JsonSerializerTest : TestFixtureBase
{
	public struct AlmostImmutableStruct(string value, int value2)
	{
		public string Value { get; } = value;

		public int Value2 { get; set; } = value2;
	}

	public struct ImmutableStructWithConstructorAttribute(string value)
	{
		public string Value { get; } = value;
	}

	[Test]
	public void ListSourceSerialize()
	{
		ListSourceTest listSourceTest = new ListSourceTest();
		listSourceTest.strprop = "test";
		string text = JsonConvert.SerializeObject(listSourceTest);
		Assert.AreEqual("{\"strprop\":\"test\"}", text);
		ListSourceTest listSourceTest2 = JsonConvert.DeserializeObject<ListSourceTest>(text);
		Assert.AreEqual("test", listSourceTest2.strprop);
	}

	[Test]
	public void DeserializeImmutableStruct()
	{
		ImmutableStruct immutableStruct = JsonConvert.DeserializeObject<ImmutableStruct>("{ \"Value\": \"working\", \"Value2\": 2 }");
		Assert.AreEqual("working", immutableStruct.Value);
		Assert.AreEqual(2, immutableStruct.Value2);
	}

	[Test]
	public void DeserializeAlmostImmutableStruct()
	{
		AlmostImmutableStruct almostImmutableStruct = JsonConvert.DeserializeObject<AlmostImmutableStruct>("{ \"Value\": \"working\", \"Value2\": 2 }");
		Assert.AreEqual(null, almostImmutableStruct.Value);
		Assert.AreEqual(2, almostImmutableStruct.Value2);
	}

	[Test]
	public void DontCloseInputOnDeserializeError()
	{
		using FileStream fileStream = System.IO.File.OpenRead(TestFixtureBase.ResolvePath("large.json"));
		try
		{
			using (JsonTextReader jsonTextReader = new JsonTextReader(new StreamReader(fileStream)))
			{
				jsonTextReader.SupportMultipleContent = true;
				jsonTextReader.CloseInput = false;
				jsonTextReader.Read();
				JsonSerializer jsonSerializer = new JsonSerializer();
				jsonSerializer.CheckAdditionalContent = false;
				jsonSerializer.Deserialize<IList<ErroringClass>>(jsonTextReader);
			}
			Assert.Fail();
		}
		catch (Exception)
		{
			Assert.IsTrue(fileStream.Position > 0);
			fileStream.Seek(0L, SeekOrigin.Begin);
			Assert.AreEqual(0, fileStream.Position);
		}
	}

	[Test]
	public void SerializeInterfaceWithHiddenProperties()
	{
		ISubclass value = MyFactory.InstantiateSubclass();
		IMainClass value2 = MyFactory.InstantiateManiClass();
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"ID\": 123,\r\n  \"Name\": \"ABC\",\r\n  \"P1\": true,\r\n  \"P2\": 44\r\n}", actual);
		string actual2 = JsonConvert.SerializeObject(value2, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"ID\": 567,\r\n  \"Name\": \"XYZ\",\r\n  \"Subclass\": {\r\n    \"ID\": 123,\r\n    \"Name\": \"ABC\",\r\n    \"P1\": true,\r\n    \"P2\": 44\r\n  }\r\n}", actual2);
	}

	[Test]
	public void DeserializeGenericIEnumerableWithImplicitConversion()
	{
		string value = "{\r\n  \"Enumerable\": [ \"abc\", \"def\" ] \r\n}";
		GenericIEnumerableWithImplicitConversion genericIEnumerableWithImplicitConversion = JsonConvert.DeserializeObject<GenericIEnumerableWithImplicitConversion>(value);
		ClassWithImplicitOperator[] array = genericIEnumerableWithImplicitConversion.Enumerable.ToArray();
		Assert.AreEqual(2, array.Length);
		Assert.AreEqual("abc", array[0].Value);
		Assert.AreEqual("def", array[1].Value);
	}

	[Test]
	public void DeserializeMSDateTimeOffset()
	{
		DateTimeOffset dateTimeOffset = JsonConvert.DeserializeObject<DateTimeOffset>("\"/Date(1418924498000+0800)/\"");
		long num = DateTimeUtils.ConvertDateTimeToJavaScriptTicks(dateTimeOffset.DateTime, dateTimeOffset.Offset);
		Assert.AreEqual(1418924498000L, num);
		Assert.AreEqual(8, dateTimeOffset.Offset.Hours);
	}

	[Test]
	public void DeserializeBoolean_Null()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IList<bool>>("[null]");
		}, new string[1] { "Error converting value {null} to type 'System.Boolean'. Path '[0]', line 1, position 5." });
	}

	[Test]
	public void DeserializeBoolean_DateTime()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<IList<bool>>("['2000-12-20T10:55:55Z']");
		}, new string[1] { "Could not convert string to boolean: 2000-12-20T10:55:55Z. Path '[0]', line 1, position 23." });
	}

	[Test]
	public void DeserializeBoolean_BadString()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<IList<bool>>("['pie']");
		}, new string[1] { "Could not convert string to boolean: pie. Path '[0]', line 1, position 6." });
	}

	[Test]
	public void DeserializeBoolean_EmptyString()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IList<bool>>("['']");
		}, new string[1] { "Error converting value {null} to type 'System.Boolean'. Path '[0]', line 1, position 3." });
	}

	[Test]
	public void CaseInsensitiveRequiredPropertyConstructorCreation()
	{
		FooRequired fooRequired = new FooRequired(new string[3] { "A", "B", "C" });
		string text = JsonConvert.SerializeObject(fooRequired);
		StringAssert.AreEqual("{\"Bars\":[\"A\",\"B\",\"C\"]}", text);
		FooRequired fooRequired2 = JsonConvert.DeserializeObject<FooRequired>(text);
		Assert.AreEqual(fooRequired.Bars.Count, fooRequired2.Bars.Count);
		Assert.AreEqual(fooRequired.Bars[0], fooRequired2.Bars[0]);
		Assert.AreEqual(fooRequired.Bars[1], fooRequired2.Bars[1]);
		Assert.AreEqual(fooRequired.Bars[2], fooRequired2.Bars[2]);
	}

	[Test]
	public void CoercedEmptyStringWithRequired()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<Binding>("{requiredProperty:''}");
		}, new string[1] { "Required property 'RequiredProperty' expects a value but got null. Path '', line 1, position 21." });
	}

	[Test]
	public void CoercedEmptyStringWithRequired_DisallowNull()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<Binding_DisallowNull>("{requiredProperty:''}");
		}, new string[1] { "Required property 'RequiredProperty' expects a non-null value. Path '', line 1, position 21." });
	}

	[Test]
	public void DisallowNull_NoValue()
	{
		Binding_DisallowNull binding_DisallowNull = JsonConvert.DeserializeObject<Binding_DisallowNull>("{}");
		Assert.IsNull(binding_DisallowNull.RequiredProperty);
	}

	[Test]
	public void CoercedEmptyStringWithRequiredConstructor()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<FooRequired>("{Bars:''}");
		}, new string[1] { "Required property 'Bars' expects a value but got null. Path '', line 1, position 9." });
	}

	[Test]
	public void NoErrorWhenValueDoesNotMatchIgnoredProperty()
	{
		IgnoredProperty ignoredProperty = JsonConvert.DeserializeObject<IgnoredProperty>("{'StringProp1':[1,2,3],'StringProp2':{}}");
		Assert.IsNull(ignoredProperty.StringProp1);
		Assert.IsNull(ignoredProperty.StringProp2);
	}

	[Test]
	public void Serialize_Required_DisallowedNull()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.SerializeObject(new Binding_DisallowNull());
		}, new string[1] { "Cannot write a null value for property 'RequiredProperty'. Property requires a non-null value. Path ''." });
	}

	[Test]
	public void Serialize_Required_DisallowedNull_NullValueHandlingIgnore()
	{
		string actual = JsonConvert.SerializeObject(new Binding_DisallowNull(), new JsonSerializerSettings
		{
			NullValueHandling = NullValueHandling.Ignore
		});
		Assert.AreEqual("{}", actual);
	}

	[Test]
	public void Serialize_ItemRequired_DisallowedNull()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.SerializeObject(new DictionaryWithNoNull());
		}, new string[1] { "Cannot write a null value for property 'Name'. Property requires a non-null value. Path ''." });
	}

	[Test]
	public void DictionaryKeyContractResolverTest()
	{
		var value = new
		{
			Name = "James",
			Age = 1,
			RoleNames = new Dictionary<string, bool>
			{
				{ "IsAdmin", true },
				{ "IsModerator", false }
			}
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			ContractResolver = new DictionaryKeyContractResolver()
		});
		Assert.AreEqual("{\r\n  \"NAME\": \"James\",\r\n  \"AGE\": 1,\r\n  \"ROLENAMES\": {\r\n    \"IsAdmin\": true,\r\n    \"IsModerator\": false\r\n  }\r\n}", actual);
	}

	[Test]
	public void IncompleteContainers()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IList<object>>("[1,");
		}, new string[1] { "Unexpected end when deserializing array. Path '[0]', line 1, position 3." });
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IList<int>>("[1,");
		}, new string[1] { "Unexpected end when deserializing array. Path '[0]', line 1, position 3." });
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IList<int>>("[1");
		}, new string[1] { "Unexpected end when deserializing array. Path '[0]', line 1, position 2." });
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IDictionary<string, int>>("{'key':1,");
		}, new string[1] { "Unexpected end when deserializing object. Path 'key', line 1, position 9." });
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IDictionary<string, int>>("{'key':1");
		}, new string[1] { "Unexpected end when deserializing object. Path 'key', line 1, position 8." });
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IncompleteTestClass>("{'key':1,");
		}, new string[1] { "Unexpected end when deserializing object. Path 'key', line 1, position 9." });
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<IncompleteTestClass>("{'key':1");
		}, new string[1] { "Unexpected end when deserializing object. Path 'key', line 1, position 8." });
	}

	[Test]
	public void DeserializeEnumsByName()
	{
		EnumA enumA = JsonConvert.DeserializeObject<EnumA>("'ValueA'");
		Assert.AreEqual(EnumA.ValueA, enumA);
		EnumA enumA2 = JsonConvert.DeserializeObject<EnumA>("'value_a'", new JsonConverter[1]
		{
			new StringEnumConverter()
		});
		Assert.AreEqual(EnumA.ValueA, enumA2);
	}

	[Test]
	public void RequiredPropertyTest()
	{
		RequiredPropertyTestClass c1 = new RequiredPropertyTestClass();
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.SerializeObject(c1);
		}, new string[1] { "Cannot write a null value for property 'Name'. Property requires a value. Path ''." });
		RequiredPropertyTestClass value = new RequiredPropertyTestClass
		{
			Name = "Name!"
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"Name\":\"Name!\"}", actual);
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<RequiredPropertyTestClass>("{}");
		}, new string[1] { "Required property 'Name' not found in JSON. Path '', line 1, position 2." });
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<RequiredPropertyTestClass>("{\"Name\":null}");
		}, new string[1] { "Required property 'Name' expects a value but got null. Path '', line 1, position 13." });
		RequiredPropertyTestClass requiredPropertyTestClass = JsonConvert.DeserializeObject<RequiredPropertyTestClass>("{\"Name\":\"Name!\"}");
		Assert.AreEqual("Name!", requiredPropertyTestClass.Name);
	}

	[Test]
	public void RequiredPropertyConstructorTest()
	{
		RequiredPropertyConstructorTestClass c1 = new RequiredPropertyConstructorTestClass(null);
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.SerializeObject(c1);
		}, new string[1] { "Cannot write a null value for property 'Name'. Property requires a value. Path ''." });
		RequiredPropertyConstructorTestClass value = new RequiredPropertyConstructorTestClass("Name!");
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"Name\":\"Name!\"}", actual);
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<RequiredPropertyConstructorTestClass>("{}");
		}, new string[1] { "Required property 'Name' not found in JSON. Path '', line 1, position 2." });
		RequiredPropertyConstructorTestClass requiredPropertyConstructorTestClass = JsonConvert.DeserializeObject<RequiredPropertyConstructorTestClass>("{\"Name\":\"Name!\"}");
		Assert.AreEqual("Name!", requiredPropertyConstructorTestClass.Name);
	}

	[Test]
	public void NeverResolveIgnoredPropertyTypes()
	{
		Version version = new Version(1, 2, 3, 4);
		IgnoredPropertiesTestClass value = new IgnoredPropertiesTestClass
		{
			IgnoredProperty = version,
			IgnoredList = new List<Version> { version },
			IgnoredDictionary = new Dictionary<string, Version> { { "Value", version } },
			Name = "Name!"
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			ContractResolver = new IgnoredPropertiesContractResolver()
		});
		Assert.AreEqual("{\r\n  \"Name\": \"Name!\"\r\n}", actual);
		string value2 = "{\r\n  \"IgnoredList\": [\r\n    {\r\n      \"Major\": 1,\r\n      \"Minor\": 2,\r\n      \"Build\": 3,\r\n      \"Revision\": 4,\r\n      \"MajorRevision\": 0,\r\n      \"MinorRevision\": 4\r\n    }\r\n  ],\r\n  \"IgnoredDictionary\": {\r\n    \"Value\": {\r\n      \"Major\": 1,\r\n      \"Minor\": 2,\r\n      \"Build\": 3,\r\n      \"Revision\": 4,\r\n      \"MajorRevision\": 0,\r\n      \"MinorRevision\": 4\r\n    }\r\n  },\r\n  \"Name\": \"Name!\"\r\n}";
		IgnoredPropertiesTestClass ignoredPropertiesTestClass = JsonConvert.DeserializeObject<IgnoredPropertiesTestClass>(value2, new JsonSerializerSettings
		{
			ContractResolver = new IgnoredPropertiesContractResolver()
		});
		Assert.AreEqual("Name!", ignoredPropertiesTestClass.Name);
	}

	[Test]
	public void SerializeValueTuple()
	{
		(int, int, string) tuple = ValueTuple.Create(1, 2, "string");
		string text = JsonConvert.SerializeObject(tuple, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Item1\": 1,\r\n  \"Item2\": 2,\r\n  \"Item3\": \"string\"\r\n}", text);
		(int, int, string) tuple2 = JsonConvert.DeserializeObject<(int, int, string)>(text);
		Assert.AreEqual(1, tuple2.Item1);
		Assert.AreEqual(2, tuple2.Item2);
		Assert.AreEqual("string", tuple2.Item3);
	}

	[Test]
	public void DeserializeStructWithConstructorAttribute()
	{
		Assert.AreEqual("working", JsonConvert.DeserializeObject<ImmutableStructWithConstructorAttribute>("{ \"Value\": \"working\" }").Value);
	}

	[Test]
	public void SerializeMetadataType()
	{
		CustomerWithMetadataType value = new CustomerWithMetadataType
		{
			UpdatedBy_Id = Guid.NewGuid()
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{}", actual);
		CustomerWithMetadataType customerWithMetadataType = JsonConvert.DeserializeObject<CustomerWithMetadataType>("{'UpdatedBy_Id':'F6E0666D-13C7-4745-B486-800812C8F6DE'}");
		Assert.AreEqual(Guid.Empty, customerWithMetadataType.UpdatedBy_Id);
	}

	[Test]
	public void SerializeMetadataType2()
	{
		FaqItem value = new FaqItem
		{
			FaqId = 1,
			Sections = 
			{
				new FaqSection()
			}
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"FaqId\": 1,\r\n  \"Name\": null,\r\n  \"IsDeleted\": false,\r\n  \"FullSectionsProp\": [\r\n    {}\r\n  ]\r\n}", text);
		FaqItem faqItem = JsonConvert.DeserializeObject<FaqItem>(text);
		Assert.AreEqual(1, faqItem.FaqId);
		Assert.AreEqual(1, faqItem.Sections.Count);
	}

	[Test]
	public void SerializeMetadataTypeInheritance()
	{
		FaqItemProxy faqItemProxy = new FaqItemProxy();
		faqItemProxy.FaqId = 1;
		faqItemProxy.Sections.Add(new FaqSection());
		faqItemProxy.IsProxy = true;
		string text = JsonConvert.SerializeObject(faqItemProxy, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"IsProxy\": true,\r\n  \"FaqId\": 1,\r\n  \"Name\": null,\r\n  \"IsDeleted\": false,\r\n  \"FullSectionsProp\": [\r\n    {}\r\n  ]\r\n}", text);
		FaqItemProxy faqItemProxy2 = JsonConvert.DeserializeObject<FaqItemProxy>(text);
		Assert.AreEqual(1, faqItemProxy2.FaqId);
		Assert.AreEqual(1, faqItemProxy2.Sections.Count);
	}

	[Test]
	public void DeserializeNullToJTokenProperty()
	{
		NullTestClass nullTestClass = JsonConvert.DeserializeObject<NullTestClass>("{\r\n    \"Value1\": null,\r\n    \"Value2\": null,\r\n    \"Value3\": null,\r\n    \"Value4\": null,\r\n    \"Value5\": null\r\n}");
		Assert.IsNull(nullTestClass.Value1);
		Assert.AreEqual(JTokenType.Null, nullTestClass.Value2.Type);
		Assert.AreEqual(JTokenType.Raw, nullTestClass.Value3.Type);
		Assert.AreEqual(JTokenType.Null, nullTestClass.Value4.Type);
		Assert.IsNull(nullTestClass.Value5);
	}

	[Test]
	public void DeserializeObservableCollection()
	{
		ObservableCollection<string> observableCollection = JsonConvert.DeserializeObject<ObservableCollection<string>>("['1','2']");
		Assert.AreEqual(2, observableCollection.Count);
		Assert.AreEqual("1", observableCollection[0]);
		Assert.AreEqual("2", observableCollection[1]);
	}

	[Test]
	public void SerializeObservableCollection()
	{
		ObservableCollection<string> value = new ObservableCollection<string> { "1", "2" };
		string text = JsonConvert.SerializeObject(value);
		Assert.AreEqual("[\"1\",\"2\"]", text);
		ObservableCollection<string> observableCollection = JsonConvert.DeserializeObject<ObservableCollection<string>>(text);
		Assert.AreEqual(2, observableCollection.Count);
		Assert.AreEqual("1", observableCollection[0]);
		Assert.AreEqual("2", observableCollection[1]);
	}

	[Test]
	public void DeserializeBoolAsStringInDictionary()
	{
		Dictionary<string, string> dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>("{\"Test1\":false}");
		Assert.AreEqual(1, dictionary.Count);
		Assert.AreEqual("false", dictionary["Test1"]);
	}

	[Test]
	public void PopulateResetSettings()
	{
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader("[\"2000-01-01T01:01:01+00:00\"]"));
		Assert.AreEqual(DateParseHandling.DateTime, jsonTextReader.DateParseHandling);
		JsonSerializer jsonSerializer = new JsonSerializer();
		jsonSerializer.DateParseHandling = DateParseHandling.DateTimeOffset;
		IList<object> list = new List<object>();
		jsonSerializer.Populate(jsonTextReader, list);
		Assert.AreEqual(typeof(DateTimeOffset), list[0].GetType());
		Assert.AreEqual(new DateTimeOffset(2000, 1, 1, 1, 1, 1, TimeSpan.Zero), list[0]);
		Assert.AreEqual(DateParseHandling.DateTime, jsonTextReader.DateParseHandling);
	}

	[Test]
	public void NewProperty()
	{
		Assert.AreEqual("{\"IsTransient\":true}", JsonConvert.SerializeObject(new ChildClass
		{
			IsTransient = true
		}));
		ChildClass childClass = JsonConvert.DeserializeObject<ChildClass>("{\"IsTransient\":true}");
		Assert.AreEqual(true, childClass.IsTransient);
	}

	[Test]
	public void NewPropertyVirtual()
	{
		Assert.AreEqual("{\"IsTransient\":true}", JsonConvert.SerializeObject(new ChildClassVirtual
		{
			IsTransient = true
		}));
		ChildClassVirtual childClassVirtual = JsonConvert.DeserializeObject<ChildClassVirtual>("{\"IsTransient\":true}");
		Assert.AreEqual(true, childClassVirtual.IsTransient);
	}

	[Test]
	public void CanSerializeWithBuiltInTypeAsGenericArgument()
	{
		ResponseWithNewGenericProperty<int> responseWithNewGenericProperty = new ResponseWithNewGenericProperty<int>
		{
			Message = "Trying out integer as type parameter",
			Data = 25,
			Result = "This should be fine"
		};
		string value = JsonConvert.SerializeObject(responseWithNewGenericProperty);
		ResponseWithNewGenericProperty<int> responseWithNewGenericProperty2 = JsonConvert.DeserializeObject<ResponseWithNewGenericProperty<int>>(value);
		Assert.AreEqual(responseWithNewGenericProperty.Data, responseWithNewGenericProperty2.Data);
		Assert.AreEqual(responseWithNewGenericProperty.Message, responseWithNewGenericProperty2.Message);
		Assert.AreEqual(responseWithNewGenericProperty.Result, responseWithNewGenericProperty2.Result);
	}

	[Test]
	public void CanSerializeWithBuiltInTypeAsGenericArgumentVirtual()
	{
		ResponseWithNewGenericPropertyVirtual<int> responseWithNewGenericPropertyVirtual = new ResponseWithNewGenericPropertyVirtual<int>
		{
			Message = "Trying out integer as type parameter",
			Data = 25,
			Result = "This should be fine"
		};
		string value = JsonConvert.SerializeObject(responseWithNewGenericPropertyVirtual);
		ResponseWithNewGenericPropertyVirtual<int> responseWithNewGenericPropertyVirtual2 = JsonConvert.DeserializeObject<ResponseWithNewGenericPropertyVirtual<int>>(value);
		Assert.AreEqual(responseWithNewGenericPropertyVirtual.Data, responseWithNewGenericPropertyVirtual2.Data);
		Assert.AreEqual(responseWithNewGenericPropertyVirtual.Message, responseWithNewGenericPropertyVirtual2.Message);
		Assert.AreEqual(responseWithNewGenericPropertyVirtual.Result, responseWithNewGenericPropertyVirtual2.Result);
	}

	[Test]
	public void CanSerializeWithBuiltInTypeAsGenericArgumentOverride()
	{
		ResponseWithNewGenericPropertyOverride<int> responseWithNewGenericPropertyOverride = new ResponseWithNewGenericPropertyOverride<int>
		{
			Message = "Trying out integer as type parameter",
			Data = 25,
			Result = "This should be fine"
		};
		string value = JsonConvert.SerializeObject(responseWithNewGenericPropertyOverride);
		ResponseWithNewGenericPropertyOverride<int> responseWithNewGenericPropertyOverride2 = JsonConvert.DeserializeObject<ResponseWithNewGenericPropertyOverride<int>>(value);
		Assert.AreEqual(responseWithNewGenericPropertyOverride.Data, responseWithNewGenericPropertyOverride2.Data);
		Assert.AreEqual(responseWithNewGenericPropertyOverride.Message, responseWithNewGenericPropertyOverride2.Message);
		Assert.AreEqual(responseWithNewGenericPropertyOverride.Result, responseWithNewGenericPropertyOverride2.Result);
	}

	[Test]
	public void CanSerializedWithGenericClosedTypeAsArgument()
	{
		ResponseWithNewGenericProperty<List<int>> responseWithNewGenericProperty = new ResponseWithNewGenericProperty<List<int>>
		{
			Message = "More complex case - generic list of int",
			Data = Enumerable.Range(50, 70).ToList(),
			Result = "This should be fine too"
		};
		string value = JsonConvert.SerializeObject(responseWithNewGenericProperty);
		ResponseWithNewGenericProperty<List<int>> responseWithNewGenericProperty2 = JsonConvert.DeserializeObject<ResponseWithNewGenericProperty<List<int>>>(value);
		CollectionAssert.AreEqual(responseWithNewGenericProperty.Data, responseWithNewGenericProperty2.Data);
		Assert.AreEqual(responseWithNewGenericProperty.Message, responseWithNewGenericProperty2.Message);
		Assert.AreEqual(responseWithNewGenericProperty.Result, responseWithNewGenericProperty2.Result);
	}

	[Test]
	public void DeserializeVersionString()
	{
		string value = "['1.2.3.4']";
		List<Version> list = JsonConvert.DeserializeObject<List<Version>>(value);
		Assert.AreEqual(1, list[0].Major);
		Assert.AreEqual(2, list[0].Minor);
		Assert.AreEqual(3, list[0].Build);
		Assert.AreEqual(4, list[0].Revision);
	}

	[Test]
	public void DeserializeVersionString_Fail()
	{
		string json = "['1.2.3.4444444444444444444444']";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<List<Version>>(json);
		}, new string[1] { "Error converting value \"1.2.3.4444444444444444444444\" to type 'System.Version'. Path '[0]', line 1, position 31." });
	}

	[Test]
	public void DeserializeJObjectWithComments()
	{
		string text = "/* Test */\r\n            {\r\n                /*Test*/\"A\":/* Test */true/* Test */,\r\n                /* Test */\"B\":/* Test */false/* Test */,\r\n                /* Test */\"C\":/* Test */[\r\n                    /* Test */\r\n                    1/* Test */\r\n                ]/* Test */\r\n            }\r\n            /* Test */";
		JObject jObject = (JObject)JsonConvert.DeserializeObject(text);
		Assert.AreEqual(3, jObject.Count);
		Assert.AreEqual(true, (bool)jObject["A"]);
		Assert.AreEqual(false, (bool)jObject["B"]);
		Assert.AreEqual(1, jObject["C"].Count());
		Assert.AreEqual(1, (int)jObject["C"][0]);
		Assert.IsTrue(JToken.DeepEquals(jObject, JObject.Parse(text)));
		text = "{/* Test */}";
		jObject = (JObject)JsonConvert.DeserializeObject(text);
		Assert.AreEqual(0, jObject.Count);
		Assert.IsTrue(JToken.DeepEquals(jObject, JObject.Parse(text)));
		text = "{\"A\": true/* Test */}";
		jObject = (JObject)JsonConvert.DeserializeObject(text);
		Assert.AreEqual(1, jObject.Count);
		Assert.AreEqual(true, (bool)jObject["A"]);
		Assert.IsTrue(JToken.DeepEquals(jObject, JObject.Parse(text)));
	}

	[Test]
	public void DeserializeCommentTestObjectWithComments()
	{
		CommentTestObject commentTestObject = JsonConvert.DeserializeObject<CommentTestObject>("{/* Test */}");
		Assert.AreEqual(null, commentTestObject.A);
		commentTestObject = JsonConvert.DeserializeObject<CommentTestObject>("{\"A\": true/* Test */}");
		Assert.AreEqual(true, commentTestObject.A);
	}

	[Test]
	public void JsonSerializerProperties()
	{
		JsonSerializer jsonSerializer = new JsonSerializer();
		DefaultSerializationBinder defaultSerializationBinder = (DefaultSerializationBinder)(jsonSerializer.Binder = new DefaultSerializationBinder());
		Assert.AreEqual(defaultSerializationBinder, jsonSerializer.Binder);
		Assert.IsInstanceOf(typeof(DefaultSerializationBinder), jsonSerializer.SerializationBinder);
		jsonSerializer.SerializationBinder = defaultSerializationBinder;
		Assert.AreEqual(defaultSerializationBinder, jsonSerializer.SerializationBinder);
		Assert.AreEqual(defaultSerializationBinder, jsonSerializer.Binder);
		jsonSerializer.CheckAdditionalContent = true;
		Assert.AreEqual(true, jsonSerializer.CheckAdditionalContent);
		jsonSerializer.ConstructorHandling = ConstructorHandling.AllowNonPublicDefaultConstructor;
		Assert.AreEqual(ConstructorHandling.AllowNonPublicDefaultConstructor, jsonSerializer.ConstructorHandling);
		jsonSerializer.Context = new StreamingContext(StreamingContextStates.Other);
		Assert.AreEqual(new StreamingContext(StreamingContextStates.Other), jsonSerializer.Context);
		CamelCasePropertyNamesContractResolver expected = (CamelCasePropertyNamesContractResolver)(jsonSerializer.ContractResolver = new CamelCasePropertyNamesContractResolver());
		Assert.AreEqual(expected, jsonSerializer.ContractResolver);
		jsonSerializer.Converters.Add(new StringEnumConverter());
		Assert.AreEqual(1, jsonSerializer.Converters.Count);
		jsonSerializer.Culture = new CultureInfo("en-nz");
		Assert.AreEqual("en-NZ", jsonSerializer.Culture.ToString());
		jsonSerializer.EqualityComparer = EqualityComparer<object>.Default;
		Assert.AreEqual(EqualityComparer<object>.Default, jsonSerializer.EqualityComparer);
		jsonSerializer.DateFormatHandling = DateFormatHandling.MicrosoftDateFormat;
		Assert.AreEqual(DateFormatHandling.MicrosoftDateFormat, jsonSerializer.DateFormatHandling);
		jsonSerializer.DateFormatString = "yyyy";
		Assert.AreEqual("yyyy", jsonSerializer.DateFormatString);
		jsonSerializer.DateParseHandling = DateParseHandling.None;
		Assert.AreEqual(DateParseHandling.None, jsonSerializer.DateParseHandling);
		jsonSerializer.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
		Assert.AreEqual(DateTimeZoneHandling.Utc, jsonSerializer.DateTimeZoneHandling);
		jsonSerializer.DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate;
		Assert.AreEqual(DefaultValueHandling.IgnoreAndPopulate, jsonSerializer.DefaultValueHandling);
		jsonSerializer.FloatFormatHandling = FloatFormatHandling.Symbol;
		Assert.AreEqual(FloatFormatHandling.Symbol, jsonSerializer.FloatFormatHandling);
		jsonSerializer.FloatParseHandling = FloatParseHandling.Decimal;
		Assert.AreEqual(FloatParseHandling.Decimal, jsonSerializer.FloatParseHandling);
		jsonSerializer.Formatting = Formatting.Indented;
		Assert.AreEqual(Formatting.Indented, jsonSerializer.Formatting);
		jsonSerializer.MaxDepth = 9001;
		Assert.AreEqual(9001, jsonSerializer.MaxDepth);
		jsonSerializer.MissingMemberHandling = MissingMemberHandling.Error;
		Assert.AreEqual(MissingMemberHandling.Error, jsonSerializer.MissingMemberHandling);
		jsonSerializer.NullValueHandling = NullValueHandling.Ignore;
		Assert.AreEqual(NullValueHandling.Ignore, jsonSerializer.NullValueHandling);
		jsonSerializer.ObjectCreationHandling = ObjectCreationHandling.Replace;
		Assert.AreEqual(ObjectCreationHandling.Replace, jsonSerializer.ObjectCreationHandling);
		jsonSerializer.PreserveReferencesHandling = PreserveReferencesHandling.All;
		Assert.AreEqual(PreserveReferencesHandling.All, jsonSerializer.PreserveReferencesHandling);
		jsonSerializer.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
		Assert.AreEqual(ReferenceLoopHandling.Ignore, jsonSerializer.ReferenceLoopHandling);
		IdReferenceResolver expected2 = (IdReferenceResolver)(jsonSerializer.ReferenceResolver = new IdReferenceResolver());
		Assert.AreEqual(expected2, jsonSerializer.ReferenceResolver);
		jsonSerializer.StringEscapeHandling = StringEscapeHandling.EscapeNonAscii;
		Assert.AreEqual(StringEscapeHandling.EscapeNonAscii, jsonSerializer.StringEscapeHandling);
		MemoryTraceWriter expected3 = (MemoryTraceWriter)(jsonSerializer.TraceWriter = new MemoryTraceWriter());
		Assert.AreEqual(expected3, jsonSerializer.TraceWriter);
		jsonSerializer.TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Full;
		Assert.AreEqual(TypeNameAssemblyFormatHandling.Full, jsonSerializer.TypeNameAssemblyFormatHandling);
		jsonSerializer.TypeNameHandling = TypeNameHandling.All;
		Assert.AreEqual(TypeNameHandling.All, jsonSerializer.TypeNameHandling);
	}

	[Test]
	public void JsonSerializerSettingsProperties()
	{
		JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings();
		DefaultSerializationBinder expected = (DefaultSerializationBinder)(jsonSerializerSettings.Binder = new DefaultSerializationBinder());
		Assert.AreEqual(expected, jsonSerializerSettings.Binder);
		jsonSerializerSettings.CheckAdditionalContent = true;
		Assert.AreEqual(true, jsonSerializerSettings.CheckAdditionalContent);
		jsonSerializerSettings.ConstructorHandling = ConstructorHandling.AllowNonPublicDefaultConstructor;
		Assert.AreEqual(ConstructorHandling.AllowNonPublicDefaultConstructor, jsonSerializerSettings.ConstructorHandling);
		jsonSerializerSettings.Context = new StreamingContext(StreamingContextStates.Other);
		Assert.AreEqual(new StreamingContext(StreamingContextStates.Other), jsonSerializerSettings.Context);
		CamelCasePropertyNamesContractResolver expected2 = (CamelCasePropertyNamesContractResolver)(jsonSerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver());
		Assert.AreEqual(expected2, jsonSerializerSettings.ContractResolver);
		jsonSerializerSettings.Converters.Add(new StringEnumConverter());
		Assert.AreEqual(1, jsonSerializerSettings.Converters.Count);
		jsonSerializerSettings.Culture = new CultureInfo("en-nz");
		Assert.AreEqual("en-NZ", jsonSerializerSettings.Culture.ToString());
		jsonSerializerSettings.EqualityComparer = EqualityComparer<object>.Default;
		Assert.AreEqual(EqualityComparer<object>.Default, jsonSerializerSettings.EqualityComparer);
		jsonSerializerSettings.DateFormatHandling = DateFormatHandling.MicrosoftDateFormat;
		Assert.AreEqual(DateFormatHandling.MicrosoftDateFormat, jsonSerializerSettings.DateFormatHandling);
		jsonSerializerSettings.DateFormatString = "yyyy";
		Assert.AreEqual("yyyy", jsonSerializerSettings.DateFormatString);
		jsonSerializerSettings.DateParseHandling = DateParseHandling.None;
		Assert.AreEqual(DateParseHandling.None, jsonSerializerSettings.DateParseHandling);
		jsonSerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
		Assert.AreEqual(DateTimeZoneHandling.Utc, jsonSerializerSettings.DateTimeZoneHandling);
		jsonSerializerSettings.DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate;
		Assert.AreEqual(DefaultValueHandling.IgnoreAndPopulate, jsonSerializerSettings.DefaultValueHandling);
		jsonSerializerSettings.FloatFormatHandling = FloatFormatHandling.Symbol;
		Assert.AreEqual(FloatFormatHandling.Symbol, jsonSerializerSettings.FloatFormatHandling);
		jsonSerializerSettings.FloatParseHandling = FloatParseHandling.Decimal;
		Assert.AreEqual(FloatParseHandling.Decimal, jsonSerializerSettings.FloatParseHandling);
		jsonSerializerSettings.Formatting = Formatting.Indented;
		Assert.AreEqual(Formatting.Indented, jsonSerializerSettings.Formatting);
		jsonSerializerSettings.MaxDepth = 9001;
		Assert.AreEqual(9001, jsonSerializerSettings.MaxDepth);
		jsonSerializerSettings.MissingMemberHandling = MissingMemberHandling.Error;
		Assert.AreEqual(MissingMemberHandling.Error, jsonSerializerSettings.MissingMemberHandling);
		jsonSerializerSettings.NullValueHandling = NullValueHandling.Ignore;
		Assert.AreEqual(NullValueHandling.Ignore, jsonSerializerSettings.NullValueHandling);
		jsonSerializerSettings.ObjectCreationHandling = ObjectCreationHandling.Replace;
		Assert.AreEqual(ObjectCreationHandling.Replace, jsonSerializerSettings.ObjectCreationHandling);
		jsonSerializerSettings.PreserveReferencesHandling = PreserveReferencesHandling.All;
		Assert.AreEqual(PreserveReferencesHandling.All, jsonSerializerSettings.PreserveReferencesHandling);
		jsonSerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
		Assert.AreEqual(ReferenceLoopHandling.Ignore, jsonSerializerSettings.ReferenceLoopHandling);
		IdReferenceResolver referenceResolver = new IdReferenceResolver();
		jsonSerializerSettings.ReferenceResolver = referenceResolver;
		Assert.AreEqual(referenceResolver, jsonSerializerSettings.ReferenceResolver);
		Assert.AreEqual(referenceResolver, jsonSerializerSettings.ReferenceResolverProvider());
		jsonSerializerSettings.ReferenceResolverProvider = () => referenceResolver;
		Assert.AreEqual(referenceResolver, jsonSerializerSettings.ReferenceResolverProvider());
		jsonSerializerSettings.StringEscapeHandling = StringEscapeHandling.EscapeNonAscii;
		Assert.AreEqual(StringEscapeHandling.EscapeNonAscii, jsonSerializerSettings.StringEscapeHandling);
		MemoryTraceWriter expected3 = (MemoryTraceWriter)(jsonSerializerSettings.TraceWriter = new MemoryTraceWriter());
		Assert.AreEqual(expected3, jsonSerializerSettings.TraceWriter);
		jsonSerializerSettings.TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Full;
		Assert.AreEqual(TypeNameAssemblyFormatHandling.Full, jsonSerializerSettings.TypeNameAssemblyFormatHandling);
		jsonSerializerSettings.TypeNameHandling = TypeNameHandling.All;
		Assert.AreEqual(TypeNameHandling.All, jsonSerializerSettings.TypeNameHandling);
	}

	[Test]
	public void JsonSerializerProxyProperties()
	{
		JsonSerializerProxy jsonSerializerProxy = new JsonSerializerProxy(new JsonSerializerInternalReader(new JsonSerializer()));
		DefaultSerializationBinder defaultSerializationBinder = (DefaultSerializationBinder)(jsonSerializerProxy.Binder = new DefaultSerializationBinder());
		Assert.AreEqual(defaultSerializationBinder, jsonSerializerProxy.Binder);
		Assert.IsInstanceOf(typeof(DefaultSerializationBinder), jsonSerializerProxy.SerializationBinder);
		jsonSerializerProxy.SerializationBinder = defaultSerializationBinder;
		Assert.AreEqual(defaultSerializationBinder, jsonSerializerProxy.SerializationBinder);
		Assert.AreEqual(defaultSerializationBinder, jsonSerializerProxy.Binder);
		jsonSerializerProxy.CheckAdditionalContent = true;
		Assert.AreEqual(true, jsonSerializerProxy.CheckAdditionalContent);
		jsonSerializerProxy.ConstructorHandling = ConstructorHandling.AllowNonPublicDefaultConstructor;
		Assert.AreEqual(ConstructorHandling.AllowNonPublicDefaultConstructor, jsonSerializerProxy.ConstructorHandling);
		jsonSerializerProxy.Context = new StreamingContext(StreamingContextStates.Other);
		Assert.AreEqual(new StreamingContext(StreamingContextStates.Other), jsonSerializerProxy.Context);
		CamelCasePropertyNamesContractResolver expected = (CamelCasePropertyNamesContractResolver)(jsonSerializerProxy.ContractResolver = new CamelCasePropertyNamesContractResolver());
		Assert.AreEqual(expected, jsonSerializerProxy.ContractResolver);
		jsonSerializerProxy.Converters.Add(new StringEnumConverter());
		Assert.AreEqual(1, jsonSerializerProxy.Converters.Count);
		jsonSerializerProxy.Culture = new CultureInfo("en-nz");
		Assert.AreEqual("en-NZ", jsonSerializerProxy.Culture.ToString());
		jsonSerializerProxy.EqualityComparer = EqualityComparer<object>.Default;
		Assert.AreEqual(EqualityComparer<object>.Default, jsonSerializerProxy.EqualityComparer);
		jsonSerializerProxy.DateFormatHandling = DateFormatHandling.MicrosoftDateFormat;
		Assert.AreEqual(DateFormatHandling.MicrosoftDateFormat, jsonSerializerProxy.DateFormatHandling);
		jsonSerializerProxy.DateFormatString = "yyyy";
		Assert.AreEqual("yyyy", jsonSerializerProxy.DateFormatString);
		jsonSerializerProxy.DateParseHandling = DateParseHandling.None;
		Assert.AreEqual(DateParseHandling.None, jsonSerializerProxy.DateParseHandling);
		jsonSerializerProxy.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
		Assert.AreEqual(DateTimeZoneHandling.Utc, jsonSerializerProxy.DateTimeZoneHandling);
		jsonSerializerProxy.DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate;
		Assert.AreEqual(DefaultValueHandling.IgnoreAndPopulate, jsonSerializerProxy.DefaultValueHandling);
		jsonSerializerProxy.FloatFormatHandling = FloatFormatHandling.Symbol;
		Assert.AreEqual(FloatFormatHandling.Symbol, jsonSerializerProxy.FloatFormatHandling);
		jsonSerializerProxy.FloatParseHandling = FloatParseHandling.Decimal;
		Assert.AreEqual(FloatParseHandling.Decimal, jsonSerializerProxy.FloatParseHandling);
		jsonSerializerProxy.Formatting = Formatting.Indented;
		Assert.AreEqual(Formatting.Indented, jsonSerializerProxy.Formatting);
		jsonSerializerProxy.MaxDepth = 9001;
		Assert.AreEqual(9001, jsonSerializerProxy.MaxDepth);
		jsonSerializerProxy.MissingMemberHandling = MissingMemberHandling.Error;
		Assert.AreEqual(MissingMemberHandling.Error, jsonSerializerProxy.MissingMemberHandling);
		jsonSerializerProxy.NullValueHandling = NullValueHandling.Ignore;
		Assert.AreEqual(NullValueHandling.Ignore, jsonSerializerProxy.NullValueHandling);
		jsonSerializerProxy.ObjectCreationHandling = ObjectCreationHandling.Replace;
		Assert.AreEqual(ObjectCreationHandling.Replace, jsonSerializerProxy.ObjectCreationHandling);
		jsonSerializerProxy.PreserveReferencesHandling = PreserveReferencesHandling.All;
		Assert.AreEqual(PreserveReferencesHandling.All, jsonSerializerProxy.PreserveReferencesHandling);
		jsonSerializerProxy.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
		Assert.AreEqual(ReferenceLoopHandling.Ignore, jsonSerializerProxy.ReferenceLoopHandling);
		IdReferenceResolver expected2 = (IdReferenceResolver)(jsonSerializerProxy.ReferenceResolver = new IdReferenceResolver());
		Assert.AreEqual(expected2, jsonSerializerProxy.ReferenceResolver);
		jsonSerializerProxy.StringEscapeHandling = StringEscapeHandling.EscapeNonAscii;
		Assert.AreEqual(StringEscapeHandling.EscapeNonAscii, jsonSerializerProxy.StringEscapeHandling);
		MemoryTraceWriter expected3 = (MemoryTraceWriter)(jsonSerializerProxy.TraceWriter = new MemoryTraceWriter());
		Assert.AreEqual(expected3, jsonSerializerProxy.TraceWriter);
		jsonSerializerProxy.TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Full;
		Assert.AreEqual(TypeNameAssemblyFormatHandling.Full, jsonSerializerProxy.TypeNameAssemblyFormatHandling);
		jsonSerializerProxy.TypeNameHandling = TypeNameHandling.All;
		Assert.AreEqual(TypeNameHandling.All, jsonSerializerProxy.TypeNameHandling);
	}

	[Test]
	public void DeserializeLargeFloat()
	{
		object obj = JsonConvert.DeserializeObject("100000000000000000000000000000000000000.0");
		CustomAssert.IsInstanceOfType(typeof(double), obj);
		Assert.IsTrue(MathUtils.ApproxEquals(1E+38, (double)obj));
	}

	[Test]
	public void SerializeDeserializeRegex()
	{
		Regex value = new Regex("(hi)", RegexOptions.CultureInvariant);
		string value2 = JsonConvert.SerializeObject(value, Formatting.Indented);
		Regex regex = JsonConvert.DeserializeObject<Regex>(value2);
		Assert.AreEqual("(hi)", regex.ToString());
		Assert.AreEqual(RegexOptions.CultureInvariant, regex.Options);
	}

	[Test]
	public void EmbedJValueStringInNewJObject()
	{
		string value = null;
		JValue jValue = new JValue(value);
		JObject jObject = JObject.FromObject(new
		{
			title = jValue
		});
		JObject jObject2 = new JObject { { "title", jValue } };
		string actual = jObject.ToString();
		Assert.AreEqual(null, jValue.Value);
		Assert.AreEqual(JTokenType.String, jValue.Type);
		StringAssert.AreEqual("{\r\n  \"title\": null\r\n}", actual);
	}

	[Test]
	public void BaseClassSerializesAsExpected()
	{
		Foo1 value = new Foo1
		{
			foo = "value"
		};
		string actual = JsonConvert.SerializeObject(value);
		string expected = "{\"foo\":\"value\"}";
		Assert.AreEqual(expected, actual);
	}

	[Test]
	public void BaseClassDeserializesAsExpected()
	{
		string value = "{\"foo\":\"value\"}";
		Foo1 foo = JsonConvert.DeserializeObject<Foo1>(value);
		Assert.AreEqual("value", foo.foo);
	}

	[Test]
	public void DerivedClassHidingBasePropertySerializesAsExpected()
	{
		FooBar1 value = new FooBar1
		{
			foo = new Bar1
			{
				bar = "value"
			}
		};
		string actual = JsonConvert.SerializeObject(value);
		string expected = "{\"foo\":{\"bar\":\"value\"}}";
		Assert.AreEqual(expected, actual);
	}

	[Test]
	public void DerivedClassHidingBasePropertyDeserializesAsExpected()
	{
		string value = "{\"foo\":{\"bar\":\"value\"}}";
		FooBar1 fooBar = JsonConvert.DeserializeObject<FooBar1>(value);
		Assert.IsNotNull(fooBar.foo);
		Assert.AreEqual("value", fooBar.foo.bar);
	}

	[Test]
	public void DerivedGenericClassHidingBasePropertySerializesAsExpected()
	{
		Foo1<Bar1> value = new Foo1<Bar1>
		{
			foo = new Bar1
			{
				bar = "value"
			},
			foo2 = new Bar1
			{
				bar = "value2"
			}
		};
		string actual = JsonConvert.SerializeObject(value);
		string expected = "{\"foo\":{\"bar\":\"value\"},\"foo2\":{\"bar\":\"value2\"}}";
		Assert.AreEqual(expected, actual);
	}

	[Test]
	public void DerivedGenericClassHidingBasePropertyDeserializesAsExpected()
	{
		string value = "{\"foo\":{\"bar\":\"value\"},\"foo2\":{\"bar\":\"value2\"}}";
		Foo1<Bar1> foo = JsonConvert.DeserializeObject<Foo1<Bar1>>(value);
		Assert.IsNotNull(foo.foo2);
		Assert.AreEqual("value2", foo.foo2.bar);
		Assert.IsNotNull(foo.foo);
		Assert.AreEqual("value", foo.foo.bar);
	}

	[Test]
	public void ConversionOperator()
	{
		Dictionary<DictionaryKeyCast, int> dictionary = new Dictionary<DictionaryKeyCast, int>();
		for (int i = 0; i < 800; i++)
		{
			dictionary.Add(new DictionaryKeyCast(i.ToString(CultureInfo.InvariantCulture), i), i);
		}
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			Formatting = Formatting.Indented
		};
		JsonSerializer jsonSerializer = JsonSerializer.Create(settings);
		MemoryStream memoryStream = new MemoryStream();
		StreamWriter streamWriter = new StreamWriter(memoryStream);
		jsonSerializer.Serialize(streamWriter, dictionary);
		streamWriter.Flush();
		memoryStream.Seek(0L, SeekOrigin.Begin);
		Stopwatch stopwatch = Stopwatch.StartNew();
		object obj = jsonSerializer.Deserialize(new StreamReader(memoryStream), typeof(Dictionary<DictionaryKeyCast, int>));
		stopwatch.Stop();
	}

	[Test]
	public void ChildDataContractTestWithHidden()
	{
		ChildDataContractWithHidden value = new ChildDataContractWithHidden
		{
			VirtualMember = "VirtualMember!",
			NonVirtualMember = "NonVirtualMember!",
			NewMember = "NewMember!"
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"NewMember\":\"NewMember!\",\"virtualMember\":\"VirtualMember!\",\"nonVirtualMember\":\"NonVirtualMember!\"}", actual);
	}

	[Test]
	public void SubWithoutContractNewPropertiesTest()
	{
		BaseWithContract baseWithContract = new SubWithoutContractNewProperties
		{
			JustAProperty = "JustAProperty!",
			Virtual = "Virtual!",
			VirtualWithDataMember = "VirtualWithDataMember!",
			WithDataMember = "WithDataMember!"
		};
		baseWithContract.JustAProperty = "JustAProperty2!";
		baseWithContract.Virtual = "Virtual2!";
		baseWithContract.VirtualWithDataMember = "VirtualWithDataMember2!";
		baseWithContract.WithDataMember = "WithDataMember2!";
		string actual = AssertSerializeDeserializeEqual(baseWithContract);
		StringAssert.AreEqual("{\r\n  \"JustAProperty\": \"JustAProperty2!\",\r\n  \"Virtual\": \"Virtual2!\",\r\n  \"VirtualWithDataMemberBase\": \"VirtualWithDataMember2!\",\r\n  \"VirtualWithDataMemberSub\": \"VirtualWithDataMember!\",\r\n  \"WithDataMemberBase\": \"WithDataMember2!\",\r\n  \"WithDataMemberSub\": \"WithDataMember!\"\r\n}", actual);
	}

	[Test]
	public void SubWithoutContractVirtualPropertiesTest()
	{
		BaseWithContract baseWithContract = new SubWithoutContractVirtualProperties
		{
			JustAProperty = "JustAProperty!",
			Virtual = "Virtual!",
			VirtualWithDataMember = "VirtualWithDataMember!",
			WithDataMember = "WithDataMember!"
		};
		baseWithContract.JustAProperty = "JustAProperty2!";
		baseWithContract.Virtual = "Virtual2!";
		baseWithContract.VirtualWithDataMember = "VirtualWithDataMember2!";
		baseWithContract.WithDataMember = "WithDataMember2!";
		string actual = JsonConvert.SerializeObject(baseWithContract, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"VirtualWithDataMemberBase\": \"VirtualWithDataMember2!\",\r\n  \"VirtualSub\": \"Virtual2!\",\r\n  \"WithDataMemberBase\": \"WithDataMember2!\",\r\n  \"JustAProperty\": \"JustAProperty2!\"\r\n}", actual);
	}

	[Test]
	public void SubWithContractNewPropertiesTest()
	{
		BaseWithContract baseWithContract = new SubWithContractNewProperties
		{
			JustAProperty = "JustAProperty!",
			Virtual = "Virtual!",
			VirtualWithDataMember = "VirtualWithDataMember!",
			WithDataMember = "WithDataMember!"
		};
		baseWithContract.JustAProperty = "JustAProperty2!";
		baseWithContract.Virtual = "Virtual2!";
		baseWithContract.VirtualWithDataMember = "VirtualWithDataMember2!";
		baseWithContract.WithDataMember = "WithDataMember2!";
		string actual = AssertSerializeDeserializeEqual(baseWithContract);
		StringAssert.AreEqual("{\r\n  \"JustAProperty\": \"JustAProperty2!\",\r\n  \"JustAProperty2\": \"JustAProperty!\",\r\n  \"Virtual\": \"Virtual2!\",\r\n  \"Virtual2\": \"Virtual!\",\r\n  \"VirtualWithDataMemberBase\": \"VirtualWithDataMember2!\",\r\n  \"VirtualWithDataMemberSub\": \"VirtualWithDataMember!\",\r\n  \"WithDataMemberBase\": \"WithDataMember2!\",\r\n  \"WithDataMemberSub\": \"WithDataMember!\"\r\n}", actual);
	}

	[Test]
	public void SubWithContractVirtualPropertiesTest()
	{
		BaseWithContract baseWithContract = new SubWithContractVirtualProperties
		{
			JustAProperty = "JustAProperty!",
			Virtual = "Virtual!",
			VirtualWithDataMember = "VirtualWithDataMember!",
			WithDataMember = "WithDataMember!"
		};
		baseWithContract.JustAProperty = "JustAProperty2!";
		baseWithContract.Virtual = "Virtual2!";
		baseWithContract.VirtualWithDataMember = "VirtualWithDataMember2!";
		baseWithContract.WithDataMember = "WithDataMember2!";
		string actual = AssertSerializeDeserializeEqual(baseWithContract);
		StringAssert.AreEqual("{\r\n  \"JustAProperty\": \"JustAProperty2!\",\r\n  \"Virtual\": \"Virtual2!\",\r\n  \"VirtualWithDataMemberBase\": \"VirtualWithDataMember2!\",\r\n  \"VirtualWithDataMemberSub\": \"VirtualWithDataMember!\",\r\n  \"WithDataMemberBase\": \"WithDataMember2!\"\r\n}", actual);
	}

	private string AssertSerializeDeserializeEqual(object o)
	{
		MemoryStream memoryStream = new MemoryStream();
		DataContractJsonSerializer dataContractJsonSerializer = new DataContractJsonSerializer(o.GetType());
		dataContractJsonSerializer.WriteObject(memoryStream, o);
		byte[] array = memoryStream.ToArray();
		JObject jObject = JObject.Parse(Encoding.UTF8.GetString(array, 0, array.Length));
		jObject = new JObject(from p in jObject.Properties()
			orderby p.Name
			select p);
		JObject jObject2 = JObject.Parse(JsonConvert.SerializeObject(o));
		jObject2 = new JObject(from p in jObject2.Properties()
			orderby p.Name
			select p);
		Assert.AreEqual(jObject.Count, jObject2.Count);
		foreach (KeyValuePair<string, JToken> item in jObject)
		{
			Assert.IsTrue(JToken.DeepEquals(jObject2[item.Key], item.Value), "Property not equal: " + item.Key);
		}
		return jObject2.ToString();
	}

	[Test]
	public void PersonTypedObjectDeserialization()
	{
		Store store = new Store();
		string value = JsonConvert.SerializeObject(store);
		Store store2 = (Store)JsonConvert.DeserializeObject(value, typeof(Store));
		Assert.AreEqual(store.Establised, store2.Establised);
		Assert.AreEqual(store.product.Count, store2.product.Count);
		Console.WriteLine(value);
	}

	[Test]
	public void TypedObjectDeserialization()
	{
		Product product = new Product();
		product.Name = "Apple";
		product.ExpiryDate = new DateTime(2008, 12, 28);
		product.Price = 3.99m;
		product.Sizes = new string[3] { "Small", "Medium", "Large" };
		string value = JsonConvert.SerializeObject(product);
		Product product2 = (Product)JsonConvert.DeserializeObject(value, typeof(Product));
		Assert.AreEqual("Apple", product2.Name);
		Assert.AreEqual(new DateTime(2008, 12, 28), product2.ExpiryDate);
		Assert.AreEqual(3.99m, product2.Price);
		Assert.AreEqual("Small", product2.Sizes[0]);
		Assert.AreEqual("Medium", product2.Sizes[1]);
		Assert.AreEqual("Large", product2.Sizes[2]);
	}

	[Test]
	public void JsonConvertSerializer()
	{
		string value = "{\"Name\":\"Orange\", \"Price\":3.99, \"ExpiryDate\":\"01/24/2010 12:00:00\"}";
		Product product = JsonConvert.DeserializeObject(value, typeof(Product)) as Product;
		Assert.AreEqual("Orange", product.Name);
		Assert.AreEqual(new DateTime(2010, 1, 24, 12, 0, 0), product.ExpiryDate);
		Assert.AreEqual(3.99m, product.Price);
	}

	[Test]
	public void DeserializeJavaScriptDate()
	{
		DateTime dateTime = new DateTime(2010, 3, 30);
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary["date"] = dateTime;
		string value = JsonConvert.SerializeObject(dictionary);
		MemoryStream memoryStream = new MemoryStream();
		DataContractJsonSerializer dataContractJsonSerializer = new DataContractJsonSerializer(typeof(Dictionary<string, object>));
		dataContractJsonSerializer.WriteObject(memoryStream, dictionary);
		byte[] array = memoryStream.ToArray();
		string text = Encoding.UTF8.GetString(array, 0, array.Length);
		Dictionary<string, object> dictionary2 = (Dictionary<string, object>)JsonConvert.DeserializeObject(value, typeof(Dictionary<string, object>));
		DateTime dateTime2 = (DateTime)dictionary2["date"];
		Assert.AreEqual(dateTime, dateTime2);
	}

	[Test]
	public void TestMethodExecutorObject()
	{
		MethodExecutorObject methodExecutorObject = new MethodExecutorObject();
		methodExecutorObject.serverClassName = "BanSubs";
		methodExecutorObject.serverMethodParams = new object[4] { "21321546", "101", "1236", "D:\\1.txt" };
		methodExecutorObject.clientGetResultFunction = "ClientBanSubsCB";
		string value = JsonConvert.SerializeObject(methodExecutorObject);
		MethodExecutorObject methodExecutorObject2 = JsonConvert.DeserializeObject(value, typeof(MethodExecutorObject)) as MethodExecutorObject;
		Assert.AreNotSame(methodExecutorObject, methodExecutorObject2);
		Assert.AreEqual(methodExecutorObject2.serverClassName, "BanSubs");
		Assert.AreEqual(methodExecutorObject2.serverMethodParams.Length, 4);
		CustomAssert.Contains(methodExecutorObject2.serverMethodParams, "101");
		Assert.AreEqual(methodExecutorObject2.clientGetResultFunction, "ClientBanSubsCB");
	}

	[Test]
	public void HashtableDeserialization()
	{
		string value = "{\"Name\":\"Orange\", \"Price\":3.99, \"ExpiryDate\":\"01/24/2010 12:00:00\"}";
		Hashtable hashtable = JsonConvert.DeserializeObject(value, typeof(Hashtable)) as Hashtable;
		Assert.AreEqual("Orange", hashtable["Name"].ToString());
	}

	[Test]
	public void TypedHashtableDeserialization()
	{
		string value = "{\"Name\":\"Orange\", \"Hash\":{\"ExpiryDate\":\"01/24/2010 12:00:00\",\"UntypedArray\":[\"01/24/2010 12:00:00\"]}}";
		TypedSubHashtable typedSubHashtable = JsonConvert.DeserializeObject(value, typeof(TypedSubHashtable)) as TypedSubHashtable;
		Assert.AreEqual("01/24/2010 12:00:00", typedSubHashtable.Hash["ExpiryDate"].ToString());
		StringAssert.AreEqual("[\r\n  \"01/24/2010 12:00:00\"\r\n]", typedSubHashtable.Hash["UntypedArray"].ToString());
	}

	[Test]
	public void SerializeDeserializeGetOnlyProperty()
	{
		string value = JsonConvert.SerializeObject(new GetOnlyPropertyClass());
		GetOnlyPropertyClass getOnlyPropertyClass = JsonConvert.DeserializeObject<GetOnlyPropertyClass>(value);
		Assert.AreEqual(getOnlyPropertyClass.Field, "Field");
		Assert.AreEqual(getOnlyPropertyClass.GetOnlyProperty, "GetOnlyProperty");
	}

	[Test]
	public void SerializeDeserializeSetOnlyProperty()
	{
		string value = JsonConvert.SerializeObject(new SetOnlyPropertyClass());
		SetOnlyPropertyClass setOnlyPropertyClass = JsonConvert.DeserializeObject<SetOnlyPropertyClass>(value);
		Assert.AreEqual(setOnlyPropertyClass.Field, "Field");
	}

	[Test]
	public void JsonIgnoreAttributeTest()
	{
		string actual = JsonConvert.SerializeObject(new JsonIgnoreAttributeTestClass());
		Assert.AreEqual("{\"Field\":0,\"Property\":21}", actual);
		JsonIgnoreAttributeTestClass jsonIgnoreAttributeTestClass = JsonConvert.DeserializeObject<JsonIgnoreAttributeTestClass>("{\"Field\":99,\"Property\":-1,\"IgnoredField\":-1,\"IgnoredObject\":[1,2,3,4,5]}");
		Assert.AreEqual(0, jsonIgnoreAttributeTestClass.IgnoredField);
		Assert.AreEqual(99, jsonIgnoreAttributeTestClass.Field);
	}

	[Test]
	public void GoogleSearchAPI()
	{
		string value = "{\r\n    results:\r\n        [\r\n            {\r\n                GsearchResultClass:\"GwebSearch\",\r\n                unescapedUrl : \"http://www.google.com/\",\r\n                url : \"http://www.google.com/\",\r\n                visibleUrl : \"www.google.com\",\r\n                cacheUrl : \r\n\"http://www.google.com/search?q=cache:zhool8dxBV4J:www.google.com\",\r\n                title : \"Google\",\r\n                titleNoFormatting : \"Google\",\r\n                content : \"Enables users to search the Web, Usenet, and \r\nimages. Features include PageRank,   caching and translation of \r\nresults, and an option to find similar pages.\"\r\n            },\r\n            {\r\n                GsearchResultClass:\"GwebSearch\",\r\n                unescapedUrl : \"http://news.google.com/\",\r\n                url : \"http://news.google.com/\",\r\n                visibleUrl : \"news.google.com\",\r\n                cacheUrl : \r\n\"http://www.google.com/search?q=cache:Va_XShOz_twJ:news.google.com\",\r\n                title : \"Google News\",\r\n                titleNoFormatting : \"Google News\",\r\n                content : \"Aggregated headlines and a search engine of many of the world's news sources.\"\r\n            },\r\n            \r\n            {\r\n                GsearchResultClass:\"GwebSearch\",\r\n                unescapedUrl : \"http://groups.google.com/\",\r\n                url : \"http://groups.google.com/\",\r\n                visibleUrl : \"groups.google.com\",\r\n                cacheUrl : \r\n\"http://www.google.com/search?q=cache:x2uPD3hfkn0J:groups.google.com\",\r\n                title : \"Google Groups\",\r\n                titleNoFormatting : \"Google Groups\",\r\n                content : \"Enables users to search and browse the Usenet \r\narchives which consist of over 700   million messages, and post new \r\ncomments.\"\r\n            },\r\n            \r\n            {\r\n                GsearchResultClass:\"GwebSearch\",\r\n                unescapedUrl : \"http://maps.google.com/\",\r\n                url : \"http://maps.google.com/\",\r\n                visibleUrl : \"maps.google.com\",\r\n                cacheUrl : \r\n\"http://www.google.com/search?q=cache:dkf5u2twBXIJ:maps.google.com\",\r\n                title : \"Google Maps\",\r\n                titleNoFormatting : \"Google Maps\",\r\n                content : \"Provides directions, interactive maps, and \r\nsatellite/aerial imagery of the United   States. Can also search by \r\nkeyword such as type of business.\"\r\n            }\r\n        ],\r\n        \r\n    adResults:\r\n        [\r\n            {\r\n                GsearchResultClass:\"GwebSearch.ad\",\r\n                title : \"Gartner Symposium/ITxpo\",\r\n                content1 : \"Meet brilliant Gartner IT analysts\",\r\n                content2 : \"20-23 May 2007- Barcelona, Spain\",\r\n                url : \r\n\"http://www.google.com/url?sa=L&ai=BVualExYGRo3hD5ianAPJvejjD8-s6ye7kdTwArbI4gTAlrECEAEYASDXtMMFOAFQubWAjvr_____AWDXw_4EiAEBmAEAyAEBgAIB&num=1&q=http://www.gartner.com/it/sym/2007/spr8/spr8.jsp%3Fsrc%3D_spain_07_%26WT.srch%3D1&usg=__CxRH06E4Xvm9Muq13S4MgMtnziY=\", \r\n\r\n                impressionUrl : \r\n\"http://www.google.com/uds/css/ad-indicator-on.gif?ai=BVualExYGRo3hD5ianAPJvejjD8-s6ye7kdTwArbI4gTAlrECEAEYASDXtMMFOAFQubWAjvr_____AWDXw_4EiAEBmAEAyAEBgAIB\", \r\n\r\n                unescapedUrl : \r\n\"http://www.google.com/url?sa=L&ai=BVualExYGRo3hD5ianAPJvejjD8-s6ye7kdTwArbI4gTAlrECEAEYASDXtMMFOAFQubWAjvr_____AWDXw_4EiAEBmAEAyAEBgAIB&num=1&q=http://www.gartner.com/it/sym/2007/spr8/spr8.jsp%3Fsrc%3D_spain_07_%26WT.srch%3D1&usg=__CxRH06E4Xvm9Muq13S4MgMtnziY=\", \r\n\r\n                visibleUrl : \"www.gartner.com\"\r\n            }\r\n        ]\r\n}\r\n";
		object obj = JsonConvert.DeserializeObject(value);
		string empty = string.Empty;
		empty += empty;
	}

	[Test]
	public void TorrentDeserializeTest()
	{
		string value = "{\r\n\"\":\"\",\r\n\"label\": [\r\n       [\"SomeName\",6]\r\n],\r\n\"torrents\": [\r\n       [\"192D99A5C943555CB7F00A852821CF6D6DB3008A\",201,\"filename.avi\",178311826,1000,178311826,72815250,408,1603,7,121430,\"NameOfLabelPrevioslyDefined\",3,6,0,8,128954,-1,0],\r\n],\r\n\"torrentc\": \"1816000723\"\r\n}";
		JObject jObject = (JObject)JsonConvert.DeserializeObject(value);
		Assert.AreEqual(4, jObject.Children().Count());
		JToken jToken = jObject["torrents"];
		JToken jToken2 = jToken[0];
		Assert.AreEqual(jToken2.Children().Count(), 19);
	}

	[Test]
	public void JsonPropertyClassSerialize()
	{
		JsonPropertyClass jsonPropertyClass = new JsonPropertyClass();
		jsonPropertyClass.Pie = "Delicious";
		jsonPropertyClass.SweetCakesCount = int.MaxValue;
		string text = JsonConvert.SerializeObject(jsonPropertyClass);
		Assert.AreEqual("{\"pie\":\"Delicious\",\"pie1\":\"PieChart!\",\"sweet_cakes_count\":2147483647}", text);
		JsonPropertyClass jsonPropertyClass2 = JsonConvert.DeserializeObject<JsonPropertyClass>(text);
		Assert.AreEqual(jsonPropertyClass.Pie, jsonPropertyClass2.Pie);
		Assert.AreEqual(jsonPropertyClass.SweetCakesCount, jsonPropertyClass2.SweetCakesCount);
	}

	[Test]
	public void BadJsonPropertyClassSerialize()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.SerializeObject(new BadJsonPropertyClass());
		}, new string[1] { "A member with the name 'pie' already exists on 'Newtonsoft.Json.Tests.TestObjects.BadJsonPropertyClass'. Use the JsonPropertyAttribute to specify another name." });
	}

	[Test]
	public void InvalidBackslash()
	{
		string json = "[\"vvv\\jvvv\"]";
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<List<string>>(json);
		}, new string[1] { "Bad JSON escape sequence: \\j. Path '', line 1, position 7." });
	}

	[Test]
	public void Unicode()
	{
		string text = "[\"PRE\\u003cPOST\"]";
		DataContractJsonSerializer dataContractJsonSerializer = new DataContractJsonSerializer(typeof(List<string>));
		List<string> list = (List<string>)dataContractJsonSerializer.ReadObject(new MemoryStream(Encoding.UTF8.GetBytes(text)));
		List<string> list2 = JsonConvert.DeserializeObject<List<string>>(text);
		Assert.AreEqual(1, list2.Count);
		Assert.AreEqual(list[0], list2[0]);
	}

	[Test]
	public void BackslashEqivilence()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Expected Obj, but got Unknown
		string text = "[\"vvv\\/vvv\\tvvv\\\"vvv\\bvvv\\nvvv\\rvvv\\\\vvv\\fvvv\"]";
		JavaScriptSerializer val = new JavaScriptSerializer();
		List<string> list = val.Deserialize<List<string>>(text);
		DataContractJsonSerializer dataContractJsonSerializer = new DataContractJsonSerializer(typeof(List<string>));
		List<string> list2 = (List<string>)dataContractJsonSerializer.ReadObject(new MemoryStream(Encoding.UTF8.GetBytes(text)));
		List<string> list3 = JsonConvert.DeserializeObject<List<string>>(text);
		Assert.AreEqual(1, list3.Count);
		Assert.AreEqual(list2[0], list3[0]);
		Assert.AreEqual(list[0], list3[0]);
	}

	[Test]
	public void DateTimeTest()
	{
		List<DateTime> list = new List<DateTime>
		{
			new DateTime(100, 1, 1, 1, 1, 1, DateTimeKind.Local),
			new DateTime(100, 1, 1, 1, 1, 1, DateTimeKind.Unspecified),
			new DateTime(100, 1, 1, 1, 1, 1, DateTimeKind.Utc),
			new DateTime(2000, 1, 1, 1, 1, 1, DateTimeKind.Local),
			new DateTime(2000, 1, 1, 1, 1, 1, DateTimeKind.Unspecified),
			new DateTime(2000, 1, 1, 1, 1, 1, DateTimeKind.Utc)
		};
		MemoryStream memoryStream = new MemoryStream();
		DataContractJsonSerializer dataContractJsonSerializer = new DataContractJsonSerializer(typeof(List<DateTime>));
		dataContractJsonSerializer.WriteObject(memoryStream, list);
		memoryStream.Seek(0L, SeekOrigin.Begin);
		StreamReader streamReader = new StreamReader(memoryStream);
		string expected = streamReader.ReadToEnd();
		string actual = JsonConvert.SerializeObject(list, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
		});
		Assert.AreEqual(expected, actual);
	}

	[Test]
	public void DateTimeOffsetIso()
	{
		List<DateTimeOffset> value = new List<DateTimeOffset>
		{
			new DateTimeOffset(new DateTime(100, 1, 1, 1, 1, 1, DateTimeKind.Utc)),
			new DateTimeOffset(2000, 1, 1, 1, 1, 1, TimeSpan.Zero),
			new DateTimeOffset(2000, 1, 1, 1, 1, 1, TimeSpan.FromHours(13.0)),
			new DateTimeOffset(2000, 1, 1, 1, 1, 1, TimeSpan.FromHours(-3.5))
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("[\"0100-01-01T01:01:01+00:00\",\"2000-01-01T01:01:01+00:00\",\"2000-01-01T01:01:01+13:00\",\"2000-01-01T01:01:01-03:30\"]", actual);
	}

	[Test]
	public void DateTimeOffsetMsAjax()
	{
		List<DateTimeOffset> value = new List<DateTimeOffset>
		{
			new DateTimeOffset(new DateTime(100, 1, 1, 1, 1, 1, DateTimeKind.Utc)),
			new DateTimeOffset(2000, 1, 1, 1, 1, 1, TimeSpan.Zero),
			new DateTimeOffset(2000, 1, 1, 1, 1, 1, TimeSpan.FromHours(13.0)),
			new DateTimeOffset(2000, 1, 1, 1, 1, 1, TimeSpan.FromHours(-3.5))
		};
		string actual = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
		});
		Assert.AreEqual("[\"\\/Date(-59011455539000+0000)\\/\",\"\\/Date(946688461000+0000)\\/\",\"\\/Date(946641661000+1300)\\/\",\"\\/Date(946701061000-0330)\\/\"]", actual);
	}

	[Test]
	public void NonStringKeyDictionary()
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		dictionary.Add(-5, 6);
		dictionary.Add(int.MinValue, int.MaxValue);
		string text = JsonConvert.SerializeObject(dictionary);
		Assert.AreEqual("{\"-5\":6,\"-2147483648\":2147483647}", text);
		Dictionary<int, int> actual = JsonConvert.DeserializeObject<Dictionary<int, int>>(text);
		CollectionAssert.AreEqual(dictionary, actual);
	}

	[Test]
	public void AnonymousObjectSerialization()
	{
		var anon = new
		{
			StringValue = "I am a string",
			IntValue = int.MaxValue,
			NestedAnonymous = new
			{
				NestedValue = byte.MaxValue
			},
			NestedArray = new int[2] { 1, 2 },
			Product = new Product
			{
				Name = "TestProduct"
			}
		};
		string text = JsonConvert.SerializeObject(anon);
		Assert.AreEqual("{\"StringValue\":\"I am a string\",\"IntValue\":2147483647,\"NestedAnonymous\":{\"NestedValue\":255},\"NestedArray\":[1,2],\"Product\":{\"Name\":\"TestProduct\",\"ExpiryDate\":\"2000-01-01T00:00:00Z\",\"Price\":0.0,\"Sizes\":null}}", text);
		anon = JsonConvert.DeserializeAnonymousType(text, anon);
		Assert.AreEqual("I am a string", anon.StringValue);
		Assert.AreEqual(int.MaxValue, anon.IntValue);
		Assert.AreEqual(255, anon.NestedAnonymous.NestedValue);
		Assert.AreEqual(2, anon.NestedArray.Length);
		Assert.AreEqual(1, anon.NestedArray[0]);
		Assert.AreEqual(2, anon.NestedArray[1]);
		Assert.AreEqual("TestProduct", anon.Product.Name);
	}

	[Test]
	public void AnonymousObjectSerializationWithSetting()
	{
		DateTime dateTime = new DateTime(2000, 1, 1);
		var anon = new
		{
			DateValue = dateTime
		};
		JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings();
		jsonSerializerSettings.Converters.Add(new IsoDateTimeConverter
		{
			DateTimeFormat = "yyyy"
		});
		string text = JsonConvert.SerializeObject(anon, jsonSerializerSettings);
		Assert.AreEqual("{\"DateValue\":\"2000\"}", text);
		anon = JsonConvert.DeserializeAnonymousType(text, anon, jsonSerializerSettings);
		Assert.AreEqual(dateTime, anon.DateValue);
	}

	[Test]
	public void SerializeObject()
	{
		string actual = JsonConvert.SerializeObject(new object());
		Assert.AreEqual("{}", actual);
	}

	[Test]
	public void SerializeNull()
	{
		string actual = JsonConvert.SerializeObject(null);
		Assert.AreEqual("null", actual);
	}

	[Test]
	public void CanDeserializeIntArrayWhenNotFirstPropertyInJson()
	{
		string value = "{foo:'hello',bar:[1,2,3]}";
		ClassWithArray classWithArray = JsonConvert.DeserializeObject<ClassWithArray>(value);
		Assert.AreEqual("hello", classWithArray.Foo);
		Assert.AreEqual(4, classWithArray.Bar.Count);
		Assert.AreEqual(int.MaxValue, classWithArray.Bar[0]);
		Assert.AreEqual(1, classWithArray.Bar[1]);
		Assert.AreEqual(2, classWithArray.Bar[2]);
		Assert.AreEqual(3, classWithArray.Bar[3]);
	}

	[Test]
	public void CanDeserializeIntArray_WhenArrayIsFirstPropertyInJson()
	{
		string value = "{bar:[1,2,3], foo:'hello'}";
		ClassWithArray classWithArray = JsonConvert.DeserializeObject<ClassWithArray>(value);
		Assert.AreEqual("hello", classWithArray.Foo);
		Assert.AreEqual(4, classWithArray.Bar.Count);
		Assert.AreEqual(int.MaxValue, classWithArray.Bar[0]);
		Assert.AreEqual(1, classWithArray.Bar[1]);
		Assert.AreEqual(2, classWithArray.Bar[2]);
		Assert.AreEqual(3, classWithArray.Bar[3]);
	}

	[Test]
	public void ObjectCreationHandlingReplace()
	{
		string s = "{bar:[1,2,3], foo:'hello'}";
		JsonSerializer jsonSerializer = new JsonSerializer();
		jsonSerializer.ObjectCreationHandling = ObjectCreationHandling.Replace;
		ClassWithArray classWithArray = (ClassWithArray)jsonSerializer.Deserialize(new StringReader(s), typeof(ClassWithArray));
		Assert.AreEqual("hello", classWithArray.Foo);
		Assert.AreEqual(1, classWithArray.Bar.Count);
	}

	[Test]
	public void CanDeserializeSerializedJson()
	{
		ClassWithArray classWithArray = new ClassWithArray();
		classWithArray.Foo = "hello";
		classWithArray.Bar.Add(1L);
		classWithArray.Bar.Add(2L);
		classWithArray.Bar.Add(3L);
		string value = JsonConvert.SerializeObject(classWithArray);
		ClassWithArray classWithArray2 = JsonConvert.DeserializeObject<ClassWithArray>(value);
		Assert.AreEqual("hello", classWithArray2.Foo);
		Assert.AreEqual(5, classWithArray2.Bar.Count);
		Assert.AreEqual(int.MaxValue, classWithArray2.Bar[0]);
		Assert.AreEqual(int.MaxValue, classWithArray2.Bar[1]);
		Assert.AreEqual(1, classWithArray2.Bar[2]);
		Assert.AreEqual(2, classWithArray2.Bar[3]);
		Assert.AreEqual(3, classWithArray2.Bar[4]);
	}

	[Test]
	public void SerializeConverableObjects()
	{
		string text = JsonConvert.SerializeObject(new ConverableMembers(), Formatting.Indented);
		string text2 = null;
		text2 = "{\r\n  \"String\": \"string\",\r\n  \"Int32\": 2147483647,\r\n  \"UInt32\": 4294967295,\r\n  \"Byte\": 255,\r\n  \"SByte\": 127,\r\n  \"Short\": 32767,\r\n  \"UShort\": 65535,\r\n  \"Long\": 9223372036854775807,\r\n  \"ULong\": 9223372036854775807,\r\n  \"Double\": 1.7976931348623157E+308,\r\n  \"Float\": 3.40282347E+38,\r\n  \"Bool\": true,\r\n  \"Char\": \"\\u0000\"\r\n}";
		StringAssert.AreEqual(text2, text);
		ConverableMembers converableMembers = JsonConvert.DeserializeObject<ConverableMembers>(text);
		Assert.AreEqual("string", converableMembers.String);
		Assert.AreEqual(double.MaxValue, converableMembers.Double);
	}

	[Test]
	public void SerializeStack()
	{
		Stack<object> stack = new Stack<object>();
		stack.Push(1);
		stack.Push(2);
		stack.Push(3);
		string actual = JsonConvert.SerializeObject(stack);
		Assert.AreEqual("[3,2,1]", actual);
	}

	[Test]
	public void FormattingOverride()
	{
		var value = new
		{
			Formatting = "test"
		};
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			Formatting = Formatting.Indented
		};
		string expected = JsonConvert.SerializeObject(value, settings);
		string actual = JsonConvert.SerializeObject(value, Formatting.None, settings);
		Assert.AreNotEqual(expected, actual);
	}

	[Test]
	public void DateTimeTimeZone()
	{
		DateTime dateTime = new DateTime(2001, 4, 4, 0, 0, 0, DateTimeKind.Utc);
		string actual = JsonConvert.SerializeObject(dateTime);
		Assert.AreEqual("\"2001-04-04T00:00:00Z\"", actual);
	}

	[Test]
	public void GuidTest()
	{
		Guid guid = new Guid("BED7F4EA-1A96-11d2-8F08-00A0C9A6186D");
		string text = JsonConvert.SerializeObject(new ClassWithGuid
		{
			GuidField = guid
		});
		Assert.AreEqual("{\"GuidField\":\"bed7f4ea-1a96-11d2-8f08-00a0c9a6186d\"}", text);
		ClassWithGuid classWithGuid = JsonConvert.DeserializeObject<ClassWithGuid>(text);
		Assert.AreEqual(guid, classWithGuid.GuidField);
	}

	[Test]
	public void EnumTest()
	{
		string text = JsonConvert.SerializeObject(StringComparison.CurrentCultureIgnoreCase);
		Assert.AreEqual("1", text);
		StringComparison stringComparison = JsonConvert.DeserializeObject<StringComparison>(text);
		Assert.AreEqual(StringComparison.CurrentCultureIgnoreCase, stringComparison);
	}

	[Test]
	public void TimeSpanTest()
	{
		TimeSpan timeSpan = new TimeSpan(0, 23, 59, 1);
		string text = JsonConvert.SerializeObject(new ClassWithTimeSpan
		{
			TimeSpanField = timeSpan
		}, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"TimeSpanField\": \"23:59:01\"\r\n}", text);
		ClassWithTimeSpan classWithTimeSpan = JsonConvert.DeserializeObject<ClassWithTimeSpan>(text);
		Assert.AreEqual(timeSpan, classWithTimeSpan.TimeSpanField);
	}

	[Test]
	public void JsonIgnoreAttributeOnClassTest()
	{
		string actual = JsonConvert.SerializeObject(new JsonIgnoreAttributeOnClassTestClass());
		Assert.AreEqual("{\"TheField\":0,\"Property\":21}", actual);
		JsonIgnoreAttributeOnClassTestClass jsonIgnoreAttributeOnClassTestClass = JsonConvert.DeserializeObject<JsonIgnoreAttributeOnClassTestClass>("{\"TheField\":99,\"Property\":-1,\"IgnoredField\":-1}");
		Assert.AreEqual(0, jsonIgnoreAttributeOnClassTestClass.IgnoredField);
		Assert.AreEqual(99, jsonIgnoreAttributeOnClassTestClass.Field);
	}

	[Test]
	public void ConstructorCaseSensitivity()
	{
		ConstructorCaseSensitivityClass value = new ConstructorCaseSensitivityClass("param1", "Param1", "Param2");
		string value2 = JsonConvert.SerializeObject(value);
		ConstructorCaseSensitivityClass constructorCaseSensitivityClass = JsonConvert.DeserializeObject<ConstructorCaseSensitivityClass>(value2);
		Assert.AreEqual("param1", constructorCaseSensitivityClass.param1);
		Assert.AreEqual("Param1", constructorCaseSensitivityClass.Param1);
		Assert.AreEqual("Param2", constructorCaseSensitivityClass.Param2);
	}

	[Test]
	public void SerializerShouldUseClassConverter()
	{
		ConverterPrecedenceClass value = new ConverterPrecedenceClass("!Test!");
		string text = JsonConvert.SerializeObject(value);
		Assert.AreEqual("[\"Class\",\"!Test!\"]", text);
		ConverterPrecedenceClass converterPrecedenceClass = JsonConvert.DeserializeObject<ConverterPrecedenceClass>(text);
		Assert.AreEqual("!Test!", converterPrecedenceClass.TestValue);
	}

	[Test]
	public void SerializerShouldUseClassConverterOverArgumentConverter()
	{
		ConverterPrecedenceClass value = new ConverterPrecedenceClass("!Test!");
		string text = JsonConvert.SerializeObject(value, new ArgumentConverterPrecedenceClassConverter());
		Assert.AreEqual("[\"Class\",\"!Test!\"]", text);
		ConverterPrecedenceClass converterPrecedenceClass = JsonConvert.DeserializeObject<ConverterPrecedenceClass>(text, new JsonConverter[1]
		{
			new ArgumentConverterPrecedenceClassConverter()
		});
		Assert.AreEqual("!Test!", converterPrecedenceClass.TestValue);
	}

	[Test]
	public void SerializerShouldUseMemberConverter_IsoDate()
	{
		DateTime dateTime = new DateTime(DateTimeUtils.InitialJavaScriptDateTicks, DateTimeKind.Utc);
		MemberConverterClass value = new MemberConverterClass
		{
			DefaultConverter = dateTime,
			MemberConverter = dateTime
		};
		string text = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"DefaultConverter\":\"1970-01-01T00:00:00Z\",\"MemberConverter\":\"1970-01-01T00:00:00Z\"}", text);
		MemberConverterClass memberConverterClass = JsonConvert.DeserializeObject<MemberConverterClass>(text);
		Assert.AreEqual(dateTime, memberConverterClass.DefaultConverter);
		Assert.AreEqual(dateTime, memberConverterClass.MemberConverter);
	}

	[Test]
	public void SerializerShouldUseMemberConverter_MsDate()
	{
		DateTime dateTime = new DateTime(DateTimeUtils.InitialJavaScriptDateTicks, DateTimeKind.Utc);
		MemberConverterClass value = new MemberConverterClass
		{
			DefaultConverter = dateTime,
			MemberConverter = dateTime
		};
		string text = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
		});
		Assert.AreEqual("{\"DefaultConverter\":\"\\/Date(0)\\/\",\"MemberConverter\":\"1970-01-01T00:00:00Z\"}", text);
		MemberConverterClass memberConverterClass = JsonConvert.DeserializeObject<MemberConverterClass>(text);
		Assert.AreEqual(dateTime, memberConverterClass.DefaultConverter);
		Assert.AreEqual(dateTime, memberConverterClass.MemberConverter);
	}

	[Test]
	public void SerializerShouldUseMemberConverter_MsDate_DateParseNone()
	{
		DateTime dateTime = new DateTime(DateTimeUtils.InitialJavaScriptDateTicks, DateTimeKind.Utc);
		MemberConverterClass value = new MemberConverterClass
		{
			DefaultConverter = dateTime,
			MemberConverter = dateTime
		};
		string text = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
		});
		Assert.AreEqual("{\"DefaultConverter\":\"\\/Date(0)\\/\",\"MemberConverter\":\"1970-01-01T00:00:00Z\"}", text);
		MemberConverterClass memberConverterClass = JsonConvert.DeserializeObject<MemberConverterClass>(text, new JsonSerializerSettings
		{
			DateParseHandling = DateParseHandling.None
		});
		Assert.AreEqual(new DateTime(1970, 1, 1), memberConverterClass.DefaultConverter);
		Assert.AreEqual(new DateTime(1970, 1, 1), memberConverterClass.MemberConverter);
	}

	[Test]
	public void SerializerShouldUseMemberConverter_IsoDate_DateParseNone()
	{
		DateTime dateTime = new DateTime(DateTimeUtils.InitialJavaScriptDateTicks, DateTimeKind.Utc);
		MemberConverterClass value = new MemberConverterClass
		{
			DefaultConverter = dateTime,
			MemberConverter = dateTime
		};
		string text = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.IsoDateFormat
		});
		Assert.AreEqual("{\"DefaultConverter\":\"1970-01-01T00:00:00Z\",\"MemberConverter\":\"1970-01-01T00:00:00Z\"}", text);
		MemberConverterClass memberConverterClass = JsonConvert.DeserializeObject<MemberConverterClass>(text);
		Assert.AreEqual(dateTime, memberConverterClass.DefaultConverter);
		Assert.AreEqual(dateTime, memberConverterClass.MemberConverter);
	}

	[Test]
	public void SerializerShouldUseMemberConverterOverArgumentConverter()
	{
		DateTime dateTime = new DateTime(DateTimeUtils.InitialJavaScriptDateTicks, DateTimeKind.Utc);
		MemberConverterClass value = new MemberConverterClass
		{
			DefaultConverter = dateTime,
			MemberConverter = dateTime
		};
		string text = JsonConvert.SerializeObject(value, new JavaScriptDateTimeConverter());
		Assert.AreEqual("{\"DefaultConverter\":new Date(0),\"MemberConverter\":\"1970-01-01T00:00:00Z\"}", text);
		MemberConverterClass memberConverterClass = JsonConvert.DeserializeObject<MemberConverterClass>(text, new JsonConverter[1]
		{
			new JavaScriptDateTimeConverter()
		});
		Assert.AreEqual(dateTime, memberConverterClass.DefaultConverter);
		Assert.AreEqual(dateTime, memberConverterClass.MemberConverter);
	}

	[Test]
	public void ConverterAttributeExample()
	{
		DateTime dateTime = Convert.ToDateTime("1970-01-01T00:00:00Z").ToUniversalTime();
		MemberConverterClass value = new MemberConverterClass
		{
			DefaultConverter = dateTime,
			MemberConverter = dateTime
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"DefaultConverter\": \"1970-01-01T00:00:00Z\",\r\n  \"MemberConverter\": \"1970-01-01T00:00:00Z\"\r\n}", actual);
	}

	[Test]
	public void SerializerShouldUseMemberConverterOverClassAndArgumentConverter()
	{
		ClassAndMemberConverterClass classAndMemberConverterClass = new ClassAndMemberConverterClass();
		classAndMemberConverterClass.DefaultConverter = new ConverterPrecedenceClass("DefaultConverterValue");
		classAndMemberConverterClass.MemberConverter = new ConverterPrecedenceClass("MemberConverterValue");
		string text = JsonConvert.SerializeObject(classAndMemberConverterClass, new ArgumentConverterPrecedenceClassConverter());
		Assert.AreEqual("{\"DefaultConverter\":[\"Class\",\"DefaultConverterValue\"],\"MemberConverter\":[\"Member\",\"MemberConverterValue\"]}", text);
		ClassAndMemberConverterClass classAndMemberConverterClass2 = JsonConvert.DeserializeObject<ClassAndMemberConverterClass>(text, new JsonConverter[1]
		{
			new ArgumentConverterPrecedenceClassConverter()
		});
		Assert.AreEqual("DefaultConverterValue", classAndMemberConverterClass2.DefaultConverter.TestValue);
		Assert.AreEqual("MemberConverterValue", classAndMemberConverterClass2.MemberConverter.TestValue);
	}

	[Test]
	public void IncompatibleJsonAttributeShouldThrow()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			IncompatibleJsonAttributeClass value = new IncompatibleJsonAttributeClass();
			JsonConvert.SerializeObject(value);
		}, new string[1] { "Unexpected value when converting date. Expected DateTime or DateTimeOffset, got Newtonsoft.Json.Tests.TestObjects.IncompatibleJsonAttributeClass." });
	}

	[Test]
	public void GenericAbstractProperty()
	{
		string actual = JsonConvert.SerializeObject(new GenericImpl());
		Assert.AreEqual("{\"Id\":0}", actual);
	}

	[Test]
	public void DeserializeNullable()
	{
		string actual = JsonConvert.SerializeObject(null);
		Assert.AreEqual("null", actual);
		actual = JsonConvert.SerializeObject(1);
		Assert.AreEqual("1", actual);
	}

	[Test]
	public void SerializeJsonRaw()
	{
		PersonRaw value = new PersonRaw
		{
			FirstName = "FirstNameValue",
			RawContent = new JRaw("[1,2,3,4,5]"),
			LastName = "LastNameValue"
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"first_name\":\"FirstNameValue\",\"RawContent\":[1,2,3,4,5],\"last_name\":\"LastNameValue\"}", actual);
	}

	[Test]
	public void DeserializeJsonRaw()
	{
		string value = "{\"first_name\":\"FirstNameValue\",\"RawContent\":[1,2,3,4,5],\"last_name\":\"LastNameValue\"}";
		PersonRaw personRaw = JsonConvert.DeserializeObject<PersonRaw>(value);
		Assert.AreEqual("FirstNameValue", personRaw.FirstName);
		Assert.AreEqual("[1,2,3,4,5]", personRaw.RawContent.ToString());
		Assert.AreEqual("LastNameValue", personRaw.LastName);
	}

	[Test]
	public void DeserializeNullableMember()
	{
		UserNullable value = new UserNullable
		{
			Id = new Guid("AD6205E8-0DF4-465d-AEA6-8BA18E93A7E7"),
			FName = "FirstValue",
			LName = "LastValue",
			RoleId = 5,
			NullableRoleId = 6,
			NullRoleId = null,
			Active = true
		};
		string text = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"Id\":\"ad6205e8-0df4-465d-aea6-8ba18e93a7e7\",\"FName\":\"FirstValue\",\"LName\":\"LastValue\",\"RoleId\":5,\"NullableRoleId\":6,\"NullRoleId\":null,\"Active\":true}", text);
		UserNullable userNullable = JsonConvert.DeserializeObject<UserNullable>(text);
		Assert.AreEqual(new Guid("AD6205E8-0DF4-465d-AEA6-8BA18E93A7E7"), userNullable.Id);
		Assert.AreEqual("FirstValue", userNullable.FName);
		Assert.AreEqual("LastValue", userNullable.LName);
		Assert.AreEqual(5, userNullable.RoleId);
		Assert.AreEqual(6, userNullable.NullableRoleId);
		Assert.AreEqual(null, userNullable.NullRoleId);
		Assert.AreEqual(true, userNullable.Active);
	}

	[Test]
	public void DeserializeInt64ToNullableDouble()
	{
		string value = "{\"Height\":1}";
		DoubleClass doubleClass = JsonConvert.DeserializeObject<DoubleClass>(value);
		Assert.AreEqual(1, doubleClass.Height);
	}

	[Test]
	public void SerializeTypeProperty()
	{
		string assemblyQualifiedName = typeof(bool).AssemblyQualifiedName;
		TypeClass typeClass = new TypeClass();
		typeClass.TypeProperty = typeof(bool);
		TypeClass value = typeClass;
		string text = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"TypeProperty\":\"" + assemblyQualifiedName + "\"}", text);
		TypeClass typeClass2 = JsonConvert.DeserializeObject<TypeClass>(text);
		Assert.AreEqual(typeof(bool), typeClass2.TypeProperty);
		string assemblyQualifiedName2 = typeof(JsonSerializerTest).AssemblyQualifiedName;
		typeClass = new TypeClass();
		typeClass.TypeProperty = typeof(JsonSerializerTest);
		value = typeClass;
		text = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"TypeProperty\":\"" + assemblyQualifiedName2 + "\"}", text);
		typeClass2 = JsonConvert.DeserializeObject<TypeClass>(text);
		Assert.AreEqual(typeof(JsonSerializerTest), typeClass2.TypeProperty);
	}

	[Test]
	public void RequiredMembersClass()
	{
		RequiredMembersClass value = new RequiredMembersClass
		{
			BirthDate = new DateTime(2000, 12, 20, 10, 55, 55, DateTimeKind.Utc),
			FirstName = "Bob",
			LastName = "Smith",
			MiddleName = "Cosmo"
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"FirstName\": \"Bob\",\r\n  \"MiddleName\": \"Cosmo\",\r\n  \"LastName\": \"Smith\",\r\n  \"BirthDate\": \"2000-12-20T10:55:55Z\"\r\n}", text);
		RequiredMembersClass requiredMembersClass = JsonConvert.DeserializeObject<RequiredMembersClass>(text);
		Assert.AreEqual("Bob", requiredMembersClass.FirstName);
		Assert.AreEqual(new DateTime(2000, 12, 20, 10, 55, 55, DateTimeKind.Utc), requiredMembersClass.BirthDate);
	}

	[Test]
	public void DeserializeRequiredMembersClassWithNullValues()
	{
		string value = "{\r\n  \"FirstName\": \"I can't be null bro!\",\r\n  \"MiddleName\": null,\r\n  \"LastName\": null,\r\n  \"BirthDate\": \"\\/Date(977309755000)\\/\"\r\n}";
		RequiredMembersClass requiredMembersClass = JsonConvert.DeserializeObject<RequiredMembersClass>(value);
		Assert.AreEqual("I can't be null bro!", requiredMembersClass.FirstName);
		Assert.AreEqual(null, requiredMembersClass.MiddleName);
		Assert.AreEqual(null, requiredMembersClass.LastName);
	}

	[Test]
	public void DeserializeRequiredMembersClassNullRequiredValueProperty()
	{
		try
		{
			string value = "{\r\n  \"FirstName\": null,\r\n  \"MiddleName\": null,\r\n  \"LastName\": null,\r\n  \"BirthDate\": \"\\/Date(977309755000)\\/\"\r\n}";
			JsonConvert.DeserializeObject<RequiredMembersClass>(value);
			Assert.Fail();
		}
		catch (JsonSerializationException ex)
		{
			Assert.IsTrue(ex.Message.StartsWith("Required property 'FirstName' expects a value but got null. Path ''"));
		}
	}

	[Test]
	public void SerializeRequiredMembersClassNullRequiredValueProperty()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			RequiredMembersClass value = new RequiredMembersClass
			{
				FirstName = null,
				BirthDate = new DateTime(2000, 10, 10, 10, 10, 10, DateTimeKind.Utc),
				LastName = null,
				MiddleName = null
			};
			string text = JsonConvert.SerializeObject(value);
		}, new string[1] { "Cannot write a null value for property 'FirstName'. Property requires a value. Path ''." });
	}

	[Test]
	public void RequiredMembersClassMissingRequiredProperty()
	{
		try
		{
			string value = "{\r\n  \"FirstName\": \"Bob\"\r\n}";
			JsonConvert.DeserializeObject<RequiredMembersClass>(value);
			Assert.Fail();
		}
		catch (JsonSerializationException ex)
		{
			Assert.IsTrue(ex.Message.StartsWith("Required property 'LastName' not found in JSON. Path ''"));
		}
	}

	[Test]
	public void SerializeJaggedArray()
	{
		JaggedArray jaggedArray = new JaggedArray();
		jaggedArray.Before = "Before!";
		jaggedArray.After = "After!";
		jaggedArray.Coordinates = new int[4][]
		{
			new int[2] { 1, 1 },
			new int[2] { 1, 2 },
			new int[2] { 2, 1 },
			new int[2] { 2, 2 }
		};
		string actual = JsonConvert.SerializeObject(jaggedArray);
		Assert.AreEqual("{\"Before\":\"Before!\",\"Coordinates\":[[1,1],[1,2],[2,1],[2,2]],\"After\":\"After!\"}", actual);
	}

	[Test]
	public void DeserializeJaggedArray()
	{
		string text = "{\"Before\":\"Before!\",\"Coordinates\":[[1,1],[1,2],[2,1],[2,2]],\"After\":\"After!\"}";
		JaggedArray jaggedArray = JsonConvert.DeserializeObject<JaggedArray>(text);
		Assert.AreEqual("Before!", jaggedArray.Before);
		Assert.AreEqual("After!", jaggedArray.After);
		Assert.AreEqual(4, jaggedArray.Coordinates.Length);
		Assert.AreEqual(2, jaggedArray.Coordinates[0].Length);
		Assert.AreEqual(1, jaggedArray.Coordinates[0][0]);
		Assert.AreEqual(2, jaggedArray.Coordinates[1][1]);
		string actual = JsonConvert.SerializeObject(jaggedArray);
		Assert.AreEqual(text, actual);
	}

	[Test]
	public void DeserializeGoogleGeoCode()
	{
		string value = "{\r\n  \"name\": \"1600 Amphitheatre Parkway, Mountain View, CA, USA\",\r\n  \"Status\": {\r\n    \"code\": 200,\r\n    \"request\": \"geocode\"\r\n  },\r\n  \"Placemark\": [\r\n    {\r\n      \"address\": \"1600 Amphitheatre Pkwy, Mountain View, CA 94043, USA\",\r\n      \"AddressDetails\": {\r\n        \"Country\": {\r\n          \"CountryNameCode\": \"US\",\r\n          \"AdministrativeArea\": {\r\n            \"AdministrativeAreaName\": \"CA\",\r\n            \"SubAdministrativeArea\": {\r\n              \"SubAdministrativeAreaName\": \"Santa Clara\",\r\n              \"Locality\": {\r\n                \"LocalityName\": \"Mountain View\",\r\n                \"Thoroughfare\": {\r\n                  \"ThoroughfareName\": \"1600 Amphitheatre Pkwy\"\r\n                },\r\n                \"PostalCode\": {\r\n                  \"PostalCodeNumber\": \"94043\"\r\n                }\r\n              }\r\n            }\r\n          }\r\n        },\r\n        \"Accuracy\": 8\r\n      },\r\n      \"Point\": {\r\n        \"coordinates\": [-122.083739, 37.423021, 0]\r\n      }\r\n    }\r\n  ]\r\n}";
		GoogleMapGeocoderStructure googleMapGeocoderStructure = JsonConvert.DeserializeObject<GoogleMapGeocoderStructure>(value);
	}

	[Test]
	public void DeserializeInterfaceProperty()
	{
		InterfacePropertyTestClass interfacePropertyTestClass = new InterfacePropertyTestClass();
		interfacePropertyTestClass.co = new Co();
		string strFromTest = JsonConvert.SerializeObject(interfacePropertyTestClass);
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			InterfacePropertyTestClass interfacePropertyTestClass2 = (InterfacePropertyTestClass)JsonConvert.DeserializeObject(strFromTest, typeof(InterfacePropertyTestClass));
		}, new string[1] { "Could not create an instance of type Newtonsoft.Json.Tests.TestObjects.ICo. Type is an interface or abstract class and cannot be instantiated. Path 'co.Name', line 1, position 14." });
	}

	private Person GetPerson()
	{
		return new Person
		{
			Name = "Mike Manager",
			BirthDate = new DateTime(1983, 8, 3, 0, 0, 0, DateTimeKind.Utc),
			Department = "IT",
			LastModified = new DateTime(2009, 2, 15, 0, 0, 0, DateTimeKind.Utc)
		};
	}

	[Test]
	public void WriteJsonDates()
	{
		LogEntry value = new LogEntry
		{
			LogDate = new DateTime(2009, 2, 15, 0, 0, 0, DateTimeKind.Utc),
			Details = "Application started."
		};
		string actual = JsonConvert.SerializeObject(value);
		string actual2 = JsonConvert.SerializeObject(value, new IsoDateTimeConverter());
		string actual3 = JsonConvert.SerializeObject(value, new JavaScriptDateTimeConverter());
		Assert.AreEqual("{\"Details\":\"Application started.\",\"LogDate\":\"2009-02-15T00:00:00Z\"}", actual);
		Assert.AreEqual("{\"Details\":\"Application started.\",\"LogDate\":\"2009-02-15T00:00:00Z\"}", actual2);
		Assert.AreEqual("{\"Details\":\"Application started.\",\"LogDate\":new Date(1234656000000)}", actual3);
	}

	public void GenericListAndDictionaryInterfaceProperties()
	{
		GenericListAndDictionaryInterfaceProperties genericListAndDictionaryInterfaceProperties = new GenericListAndDictionaryInterfaceProperties();
		genericListAndDictionaryInterfaceProperties.IDictionaryProperty = new Dictionary<string, int>
		{
			{ "one", 1 },
			{ "two", 2 },
			{ "three", 3 }
		};
		genericListAndDictionaryInterfaceProperties.IListProperty = new List<int> { 1, 2, 3 };
		genericListAndDictionaryInterfaceProperties.IEnumerableProperty = new List<int> { 4, 5, 6 };
		string text = JsonConvert.SerializeObject(genericListAndDictionaryInterfaceProperties, Formatting.Indented);
		Assert.AreEqual("{\r\n  \"IEnumerableProperty\": [\r\n    4,\r\n    5,\r\n    6\r\n  ],\r\n  \"IListProperty\": [\r\n    1,\r\n    2,\r\n    3\r\n  ],\r\n  \"IDictionaryProperty\": {\r\n    \"one\": 1,\r\n    \"two\": 2,\r\n    \"three\": 3\r\n  }\r\n}", text);
		GenericListAndDictionaryInterfaceProperties genericListAndDictionaryInterfaceProperties2 = JsonConvert.DeserializeObject<GenericListAndDictionaryInterfaceProperties>(text);
		Assert.IsNotNull(genericListAndDictionaryInterfaceProperties2);
		CollectionAssert.AreEqual(genericListAndDictionaryInterfaceProperties.IListProperty.ToArray(), genericListAndDictionaryInterfaceProperties2.IListProperty.ToArray());
		CollectionAssert.AreEqual(genericListAndDictionaryInterfaceProperties.IEnumerableProperty.ToArray(), genericListAndDictionaryInterfaceProperties2.IEnumerableProperty.ToArray());
		CollectionAssert.AreEqual(genericListAndDictionaryInterfaceProperties.IDictionaryProperty.ToArray(), genericListAndDictionaryInterfaceProperties2.IDictionaryProperty.ToArray());
	}

	[Test]
	public void DeserializeBestMatchPropertyCase()
	{
		string value = "{\r\n  \"firstName\": \"firstName\",\r\n  \"FirstName\": \"FirstName\",\r\n  \"LastName\": \"LastName\",\r\n  \"lastName\": \"lastName\",\r\n}";
		PropertyCase propertyCase = JsonConvert.DeserializeObject<PropertyCase>(value);
		Assert.IsNotNull(propertyCase);
		Assert.AreEqual("firstName", propertyCase.firstName);
		Assert.AreEqual("FirstName", propertyCase.FirstName);
		Assert.AreEqual("LastName", propertyCase.LastName);
		Assert.AreEqual("lastName", propertyCase.lastName);
	}

	[Test]
	public void PopulateDefaultValueWhenUsingConstructor()
	{
		string value = "{ 'testProperty1': 'value' }";
		ConstructorAndDefaultValueAttributeTestClass constructorAndDefaultValueAttributeTestClass = JsonConvert.DeserializeObject<ConstructorAndDefaultValueAttributeTestClass>(value, new JsonSerializerSettings
		{
			DefaultValueHandling = DefaultValueHandling.Populate
		});
		Assert.AreEqual("value", constructorAndDefaultValueAttributeTestClass.TestProperty1);
		Assert.AreEqual(21, constructorAndDefaultValueAttributeTestClass.TestProperty2);
		constructorAndDefaultValueAttributeTestClass = JsonConvert.DeserializeObject<ConstructorAndDefaultValueAttributeTestClass>(value, new JsonSerializerSettings
		{
			DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate
		});
		Assert.AreEqual("value", constructorAndDefaultValueAttributeTestClass.TestProperty1);
		Assert.AreEqual(21, constructorAndDefaultValueAttributeTestClass.TestProperty2);
	}

	[Test]
	public void RequiredWhenUsingConstructor()
	{
		try
		{
			string value = "{ 'testProperty1': 'value' }";
			JsonConvert.DeserializeObject<ConstructorAndRequiredTestClass>(value);
			Assert.Fail();
		}
		catch (JsonSerializationException ex)
		{
			Assert.IsTrue(ex.Message.StartsWith("Required property 'TestProperty2' not found in JSON. Path ''"));
		}
	}

	[Test]
	public void DeserializePropertiesOnToNonDefaultConstructor()
	{
		SubKlass subKlass = new SubKlass("my subprop");
		subKlass.SuperProp = "overrided superprop";
		string text = JsonConvert.SerializeObject(subKlass);
		Assert.AreEqual("{\"SubProp\":\"my subprop\",\"SuperProp\":\"overrided superprop\"}", text);
		SubKlass value = JsonConvert.DeserializeObject<SubKlass>(text);
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"SubProp\":\"my subprop\",\"SuperProp\":\"overrided superprop\"}", actual);
	}

	[Test]
	public void DeserializePropertiesOnToNonDefaultConstructorWithReferenceTracking()
	{
		SubKlass subKlass = new SubKlass("my subprop");
		subKlass.SuperProp = "overrided superprop";
		string text = JsonConvert.SerializeObject(subKlass, new JsonSerializerSettings
		{
			PreserveReferencesHandling = PreserveReferencesHandling.Objects
		});
		Assert.AreEqual("{\"$id\":\"1\",\"SubProp\":\"my subprop\",\"SuperProp\":\"overrided superprop\"}", text);
		SubKlass value = JsonConvert.DeserializeObject<SubKlass>(text, new JsonSerializerSettings
		{
			PreserveReferencesHandling = PreserveReferencesHandling.Objects
		});
		string actual = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			PreserveReferencesHandling = PreserveReferencesHandling.Objects
		});
		Assert.AreEqual("{\"$id\":\"1\",\"SubProp\":\"my subprop\",\"SuperProp\":\"overrided superprop\"}", actual);
	}

	[Test]
	public void SerializeJsonPropertyWithHandlingValues()
	{
		JsonPropertyWithHandlingValues jsonPropertyWithHandlingValues = new JsonPropertyWithHandlingValues();
		jsonPropertyWithHandlingValues.DefaultValueHandlingIgnoreProperty = "Default!";
		jsonPropertyWithHandlingValues.DefaultValueHandlingIncludeProperty = "Default!";
		jsonPropertyWithHandlingValues.DefaultValueHandlingPopulateProperty = "Default!";
		jsonPropertyWithHandlingValues.DefaultValueHandlingIgnoreAndPopulateProperty = "Default!";
		string actual = JsonConvert.SerializeObject(jsonPropertyWithHandlingValues, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"DefaultValueHandlingIncludeProperty\": \"Default!\",\r\n  \"DefaultValueHandlingPopulateProperty\": \"Default!\",\r\n  \"NullValueHandlingIncludeProperty\": null,\r\n  \"ReferenceLoopHandlingErrorProperty\": null,\r\n  \"ReferenceLoopHandlingIgnoreProperty\": null,\r\n  \"ReferenceLoopHandlingSerializeProperty\": null\r\n}", actual);
		actual = JsonConvert.SerializeObject(jsonPropertyWithHandlingValues, Formatting.Indented, new JsonSerializerSettings
		{
			NullValueHandling = NullValueHandling.Ignore
		});
		StringAssert.AreEqual("{\r\n  \"DefaultValueHandlingIncludeProperty\": \"Default!\",\r\n  \"DefaultValueHandlingPopulateProperty\": \"Default!\",\r\n  \"NullValueHandlingIncludeProperty\": null\r\n}", actual);
	}

	[Test]
	public void DeserializeJsonPropertyWithHandlingValues()
	{
		string value = "{}";
		JsonPropertyWithHandlingValues jsonPropertyWithHandlingValues = JsonConvert.DeserializeObject<JsonPropertyWithHandlingValues>(value);
		Assert.AreEqual("Default!", jsonPropertyWithHandlingValues.DefaultValueHandlingIgnoreAndPopulateProperty);
		Assert.AreEqual("Default!", jsonPropertyWithHandlingValues.DefaultValueHandlingPopulateProperty);
		Assert.AreEqual(null, jsonPropertyWithHandlingValues.DefaultValueHandlingIgnoreProperty);
		Assert.AreEqual(null, jsonPropertyWithHandlingValues.DefaultValueHandlingIncludeProperty);
	}

	[Test]
	public void JsonPropertyWithHandlingValues_ReferenceLoopError()
	{
		string fullName = typeof(JsonPropertyWithHandlingValues).FullName;
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonPropertyWithHandlingValues jsonPropertyWithHandlingValues = new JsonPropertyWithHandlingValues();
			jsonPropertyWithHandlingValues.ReferenceLoopHandlingErrorProperty = jsonPropertyWithHandlingValues;
			JsonConvert.SerializeObject(jsonPropertyWithHandlingValues, Formatting.Indented, new JsonSerializerSettings
			{
				ReferenceLoopHandling = ReferenceLoopHandling.Ignore
			});
		}, new string[1] { "Self referencing loop detected for property 'ReferenceLoopHandlingErrorProperty' with type '" + fullName + "'. Path ''." });
	}

	[Test]
	public void PartialClassDeserialize()
	{
		string value = "{\r\n    \"request\": \"ux.settings.update\",\r\n    \"sid\": \"14c561bd-32a8-457e-b4e5-4bba0832897f\",\r\n    \"uid\": \"30c39065-0f31-de11-9442-001e3786a8ec\",\r\n    \"fidOrder\": [\r\n        \"id\",\r\n        \"andytest_name\",\r\n        \"andytest_age\",\r\n        \"andytest_address\",\r\n        \"andytest_phone\",\r\n        \"date\",\r\n        \"title\",\r\n        \"titleId\"\r\n    ],\r\n    \"entityName\": \"Andy Test\",\r\n    \"setting\": \"entity.field.order\"\r\n}";
		RequestOnly requestOnly = JsonConvert.DeserializeObject<RequestOnly>(value);
		Assert.AreEqual("ux.settings.update", requestOnly.Request);
		NonRequest nonRequest = JsonConvert.DeserializeObject<NonRequest>(value);
		Assert.AreEqual(new Guid("14c561bd-32a8-457e-b4e5-4bba0832897f"), nonRequest.Sid);
		Assert.AreEqual(new Guid("30c39065-0f31-de11-9442-001e3786a8ec"), nonRequest.Uid);
		Assert.AreEqual(8, nonRequest.FidOrder.Count);
		Assert.AreEqual("id", nonRequest.FidOrder[0]);
		Assert.AreEqual("titleId", nonRequest.FidOrder[nonRequest.FidOrder.Count - 1]);
	}

	[Test]
	public void OptInClassMetadataSerialization()
	{
		OptInClass optInClass = new OptInClass();
		optInClass.Age = 26;
		optInClass.Name = "James NK";
		optInClass.NotIncluded = "Poor me :(";
		string actual = JsonConvert.SerializeObject(optInClass, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Name\": \"James NK\",\r\n  \"Age\": 26\r\n}", actual);
		OptInClass optInClass2 = JsonConvert.DeserializeObject<OptInClass>("{\r\n  \"Name\": \"James NK\",\r\n  \"NotIncluded\": \"Ignore me!\",\r\n  \"Age\": 26\r\n}");
		Assert.AreEqual(26, optInClass2.Age);
		Assert.AreEqual("James NK", optInClass2.Name);
		Assert.AreEqual(null, optInClass2.NotIncluded);
	}

	[Test]
	public void SerializeDataContractPrivateMembers()
	{
		DataContractPrivateMembers dataContractPrivateMembers = new DataContractPrivateMembers("Jeff", 26, 10, "Dr");
		dataContractPrivateMembers.NotIncluded = "Hi";
		string text = JsonConvert.SerializeObject(dataContractPrivateMembers, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"_name\": \"Jeff\",\r\n  \"_age\": 26,\r\n  \"Rank\": 10,\r\n  \"JsonTitle\": \"Dr\"\r\n}", text);
		DataContractPrivateMembers dataContractPrivateMembers2 = JsonConvert.DeserializeObject<DataContractPrivateMembers>(text);
		Assert.AreEqual("_name: Jeff, _age: 26, Rank: 10, JsonTitle: Dr", dataContractPrivateMembers2.ToString());
	}

	[Test]
	public void DeserializeDictionaryInterface()
	{
		string value = "{\r\n  \"Name\": \"Name!\",\r\n  \"Dictionary\": {\r\n    \"Item\": 11\r\n  }\r\n}";
		DictionaryInterfaceClass dictionaryInterfaceClass = JsonConvert.DeserializeObject<DictionaryInterfaceClass>(value, new JsonSerializerSettings
		{
			ObjectCreationHandling = ObjectCreationHandling.Replace
		});
		Assert.AreEqual("Name!", dictionaryInterfaceClass.Name);
		Assert.AreEqual(1, dictionaryInterfaceClass.Dictionary.Count);
		Assert.AreEqual(11, dictionaryInterfaceClass.Dictionary["Item"]);
	}

	[Test]
	public void DeserializeDictionaryInterfaceWithExistingValues()
	{
		string value = "{\r\n  \"Random\": {\r\n    \"blah\": 1\r\n  },\r\n  \"Name\": \"Name!\",\r\n  \"Dictionary\": {\r\n    \"Item\": 11,\r\n    \"Item1\": 12\r\n  },\r\n  \"Collection\": [\r\n    999\r\n  ],\r\n  \"Employee\": {\r\n    \"Manager\": {\r\n      \"Name\": \"ManagerName!\"\r\n    }\r\n  }\r\n}";
		DictionaryInterfaceClass dictionaryInterfaceClass = JsonConvert.DeserializeObject<DictionaryInterfaceClass>(value, new JsonSerializerSettings
		{
			ObjectCreationHandling = ObjectCreationHandling.Reuse
		});
		Assert.AreEqual("Name!", dictionaryInterfaceClass.Name);
		Assert.AreEqual(3, dictionaryInterfaceClass.Dictionary.Count);
		Assert.AreEqual(11, dictionaryInterfaceClass.Dictionary["Item"]);
		Assert.AreEqual(1, dictionaryInterfaceClass.Dictionary["existing"]);
		Assert.AreEqual(4, dictionaryInterfaceClass.Collection.Count);
		Assert.AreEqual(1, dictionaryInterfaceClass.Collection.ElementAt(0));
		Assert.AreEqual(999, dictionaryInterfaceClass.Collection.ElementAt(3));
		Assert.AreEqual("EmployeeName!", dictionaryInterfaceClass.Employee.Name);
		Assert.AreEqual("ManagerName!", dictionaryInterfaceClass.Employee.Manager.Name);
		Assert.IsNotNull(dictionaryInterfaceClass.Random);
	}

	[Test]
	public void TypedObjectDeserializationWithComments()
	{
		string value = "/*comment1*/ { /*comment2*/\r\n        \"Name\": /*comment3*/ \"Apple\" /*comment4*/, /*comment5*/\r\n        \"ExpiryDate\": \"\\/Date(1230422400000)\\/\",\r\n        \"Price\": 3.99,\r\n        \"Sizes\": /*comment6*/ [ /*comment7*/\r\n          \"Small\", /*comment8*/\r\n          \"Medium\" /*comment9*/,\r\n          /*comment10*/ \"Large\"\r\n        /*comment11*/ ] /*comment12*/\r\n      } /*comment13*/";
		Product product = (Product)JsonConvert.DeserializeObject(value, typeof(Product));
		Assert.AreEqual("Apple", product.Name);
		Assert.AreEqual(new DateTime(2008, 12, 28, 0, 0, 0, DateTimeKind.Utc), product.ExpiryDate);
		Assert.AreEqual(3.99m, product.Price);
		Assert.AreEqual("Small", product.Sizes[0]);
		Assert.AreEqual("Medium", product.Sizes[1]);
		Assert.AreEqual("Large", product.Sizes[2]);
	}

	[Test]
	public void NestedInsideOuterObject()
	{
		string json = "{\r\n  \"short\": {\r\n    \"original\": \"http://www.contrast.ie/blog/online&#45;marketing&#45;2009/\",\r\n    \"short\": \"m2sqc6\",\r\n    \"shortened\": \"http://short.ie/m2sqc6\",\r\n    \"error\": {\r\n      \"code\": 0,\r\n      \"msg\": \"No action taken\"\r\n    }\r\n  }\r\n}";
		JObject jObject = JObject.Parse(json);
		Shortie shortie = JsonConvert.DeserializeObject<Shortie>(jObject["short"].ToString());
		Assert.IsNotNull(shortie);
		Assert.AreEqual(shortie.Original, "http://www.contrast.ie/blog/online&#45;marketing&#45;2009/");
		Assert.AreEqual(shortie.Short, "m2sqc6");
		Assert.AreEqual(shortie.Shortened, "http://short.ie/m2sqc6");
	}

	[Test]
	public void UriSerialization()
	{
		Uri uri = new Uri("http://codeplex.com");
		string value = JsonConvert.SerializeObject(uri);
		Assert.AreEqual("http://codeplex.com/", uri.ToString());
		Uri actual = JsonConvert.DeserializeObject<Uri>(value);
		Assert.AreEqual(uri, actual);
	}

	[Test]
	public void AnonymousPlusLinqToSql()
	{
		var value = new
		{
			bar = new JObject(new JProperty("baz", 13))
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"bar\":{\"baz\":13}}", actual);
	}

	[Test]
	public void SerializeEnumerableAsObject()
	{
		Content value = new Content
		{
			Text = "Blah, blah, blah",
			Children = new List<Content>
			{
				new Content
				{
					Text = "First"
				},
				new Content
				{
					Text = "Second"
				}
			}
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Children\": [\r\n    {\r\n      \"Children\": null,\r\n      \"Text\": \"First\"\r\n    },\r\n    {\r\n      \"Children\": null,\r\n      \"Text\": \"Second\"\r\n    }\r\n  ],\r\n  \"Text\": \"Blah, blah, blah\"\r\n}", actual);
	}

	[Test]
	public void DeserializeEnumerableAsObject()
	{
		string value = "{\r\n  \"Children\": [\r\n    {\r\n      \"Children\": null,\r\n      \"Text\": \"First\"\r\n    },\r\n    {\r\n      \"Children\": null,\r\n      \"Text\": \"Second\"\r\n    }\r\n  ],\r\n  \"Text\": \"Blah, blah, blah\"\r\n}";
		Content content = JsonConvert.DeserializeObject<Content>(value);
		Assert.AreEqual("Blah, blah, blah", content.Text);
		Assert.AreEqual(2, content.Children.Count);
		Assert.AreEqual("First", content.Children[0].Text);
		Assert.AreEqual("Second", content.Children[1].Text);
	}

	[Test]
	public void RoleTransferTest()
	{
		string value = "{\"Operation\":\"1\",\"RoleName\":\"Admin\",\"Direction\":\"0\"}";
		RoleTransfer roleTransfer = JsonConvert.DeserializeObject<RoleTransfer>(value);
		Assert.AreEqual(RoleTransferOperation.Second, roleTransfer.Operation);
		Assert.AreEqual("Admin", roleTransfer.RoleName);
		Assert.AreEqual(RoleTransferDirection.First, roleTransfer.Direction);
	}

	[Test]
	public void DeserializeGenericDictionary()
	{
		string value = "{\"key1\":\"value1\",\"key2\":\"value2\"}";
		Dictionary<string, string> dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(value);
		Assert.AreEqual(2, dictionary.Count);
		Assert.AreEqual("value1", dictionary["key1"]);
		Assert.AreEqual("value2", dictionary["key2"]);
	}

	[Test]
	public void DeserializeEmptyStringToNullableDateTime()
	{
		string value = "{\"DateTimeField\":\"\"}";
		NullableDateTimeTestClass nullableDateTimeTestClass = JsonConvert.DeserializeObject<NullableDateTimeTestClass>(value);
		Assert.AreEqual(null, nullableDateTimeTestClass.DateTimeField);
	}

	[Test]
	public void FailWhenClassWithNoDefaultConstructorHasMultipleConstructorsWithArguments()
	{
		string json = "{\"sublocation\":\"AlertEmailSender.Program.Main\",\"userId\":0,\"type\":0,\"summary\":\"Loading settings variables\",\"details\":null,\"stackTrace\":\"   at System.Environment.GetStackTrace(Exception e, Boolean needFileInfo)\\r\\n   at System.Environment.get_StackTrace()\\r\\n   at mr.Logging.Event..ctor(String summary) in C:\\\\Projects\\\\MRUtils\\\\Logging\\\\Event.vb:line 71\\r\\n   at AlertEmailSender.Program.Main(String[] args) in C:\\\\Projects\\\\AlertEmailSender\\\\AlertEmailSender\\\\Program.cs:line 25\",\"tag\":null,\"time\":\"\\/Date(1249591032026-0400)\\/\"}";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<Event>(json);
		}, new string[1] { "Unable to find a constructor to use for type Newtonsoft.Json.Tests.TestObjects.Events.Event. A class should either have a default constructor, one constructor with arguments or a constructor marked with the JsonConstructor attribute. Path 'sublocation', line 1, position 15." });
	}

	[Test]
	public void DeserializeObjectSetOnlyProperty()
	{
		string value = "{'SetOnlyProperty':[1,2,3,4,5]}";
		SetOnlyPropertyClass2 setOnlyPropertyClass = JsonConvert.DeserializeObject<SetOnlyPropertyClass2>(value);
		JArray jArray = (JArray)setOnlyPropertyClass.GetValue();
		Assert.AreEqual(5, jArray.Count);
		Assert.AreEqual(1, (int)jArray[0]);
		Assert.AreEqual(5, (int)jArray[jArray.Count - 1]);
	}

	[Test]
	public void DeserializeOptInClasses()
	{
		string value = "{id: \"12\", name: \"test\", items: [{id: \"112\", name: \"testing\"}]}";
		ListTestClass listTestClass = JsonConvert.DeserializeObject<ListTestClass>(value);
	}

	[Test]
	public void DeserializeNullableListWithNulls()
	{
		List<decimal?> list = JsonConvert.DeserializeObject<List<decimal?>>("[ 3.3, null, 1.1 ] ");
		Assert.AreEqual(3, list.Count);
		Assert.AreEqual(3.3m, list[0]);
		Assert.AreEqual(null, list[1]);
		Assert.AreEqual(1.1m, list[2]);
	}

	[Test]
	public void CannotDeserializeArrayIntoObject()
	{
		string json = "[]";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<Person>(json);
		}, new string[1] { "Cannot deserialize the current JSON array (e.g. [1,2,3]) into type 'Newtonsoft.Json.Tests.TestObjects.Organization.Person' because the type requires a JSON object (e.g. {\"name\":\"value\"}) to deserialize correctly.\r\nTo fix this error either change the JSON to a JSON object (e.g. {\"name\":\"value\"}) or change the deserialized type to an array or a type that implements a collection interface (e.g. ICollection, IList) like List<T> that can be deserialized from a JSON array. JsonArrayAttribute can also be added to the type to force it to deserialize from a JSON array.\r\nPath '', line 1, position 1." });
	}

	[Test]
	public void CannotDeserializeArrayIntoDictionary()
	{
		string json = "[]";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
		}, new string[1] { "Cannot deserialize the current JSON array (e.g. [1,2,3]) into type 'System.Collections.Generic.Dictionary`2[System.String,System.String]' because the type requires a JSON object (e.g. {\"name\":\"value\"}) to deserialize correctly.\r\nTo fix this error either change the JSON to a JSON object (e.g. {\"name\":\"value\"}) or change the deserialized type to an array or a type that implements a collection interface (e.g. ICollection, IList) like List<T> that can be deserialized from a JSON array. JsonArrayAttribute can also be added to the type to force it to deserialize from a JSON array.\r\nPath '', line 1, position 1." });
	}

	[Test]
	public void CannotDeserializeArrayIntoDouble()
	{
		string json = "[]";
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<double>(json);
		}, new string[1] { "Unexpected character encountered while parsing value: [. Path '', line 1, position 1." });
	}

	[Test]
	public void CannotDeserializeArrayIntoDynamic()
	{
		string json = "[]";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<DynamicDictionary>(json);
		}, new string[1] { "Cannot deserialize the current JSON array (e.g. [1,2,3]) into type 'Newtonsoft.Json.Tests.Linq.DynamicDictionary' because the type requires a JSON object (e.g. {\"name\":\"value\"}) to deserialize correctly.\r\nTo fix this error either change the JSON to a JSON object (e.g. {\"name\":\"value\"}) or change the deserialized type to an array or a type that implements a collection interface (e.g. ICollection, IList) like List<T> that can be deserialized from a JSON array. JsonArrayAttribute can also be added to the type to force it to deserialize from a JSON array.\r\nPath '', line 1, position 1." });
	}

	[Test]
	public void CannotDeserializeArrayIntoLinqToJson()
	{
		string json = "[]";
		ExceptionAssert.Throws<InvalidCastException>(() =>
		{
			JsonConvert.DeserializeObject<JObject>(json);
		}, new string[2] { "Unable to cast object of type 'Newtonsoft.Json.Linq.JArray' to type 'Newtonsoft.Json.Linq.JObject'.", "Cannot cast from source type to destination type." });
	}

	[Test]
	public void CannotDeserializeConstructorIntoObject()
	{
		string json = "new Constructor(123)";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<Person>(json);
		}, new string[1] { "Error converting value \"Constructor\" to type 'Newtonsoft.Json.Tests.TestObjects.Organization.Person'. Path '', line 1, position 16." });
	}

	[Test]
	public void CannotDeserializeConstructorIntoObjectNested()
	{
		string json = "[new Constructor(123)]";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<List<Person>>(json);
		}, new string[1] { "Error converting value \"Constructor\" to type 'Newtonsoft.Json.Tests.TestObjects.Organization.Person'. Path '[0]', line 1, position 17." });
	}

	[Test]
	public void CannotDeserializeObjectIntoArray()
	{
		string value = "{}";
		try
		{
			JsonConvert.DeserializeObject<List<Person>>(value);
			Assert.Fail();
		}
		catch (JsonSerializationException ex)
		{
			Assert.IsTrue(ex.Message.StartsWith("Cannot deserialize the current JSON object (e.g. {\"name\":\"value\"}) into type 'System.Collections.Generic.List`1[Newtonsoft.Json.Tests.TestObjects.Organization.Person]' because the type requires a JSON array (e.g. [1,2,3]) to deserialize correctly." + Environment.NewLine + "To fix this error either change the JSON to a JSON array (e.g. [1,2,3]) or change the deserialized type so that it is a normal .NET type (e.g. not a primitive type like integer, not a collection type like an array or List<T>) that can be deserialized from a JSON object. JsonObjectAttribute can also be added to the type to force it to deserialize from a JSON object." + Environment.NewLine + "Path ''"));
		}
	}

	[Test]
	public void CannotPopulateArrayIntoObject()
	{
		string json = "[]";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.PopulateObject(json, new Person());
		}, new string[1] { "Cannot populate JSON array onto type 'Newtonsoft.Json.Tests.TestObjects.Organization.Person'. Path '', line 1, position 1." });
	}

	[Test]
	public void CannotPopulateObjectIntoArray()
	{
		string json = "{}";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.PopulateObject(json, new List<Person>());
		}, new string[1] { "Cannot populate JSON object onto type 'System.Collections.Generic.List`1[Newtonsoft.Json.Tests.TestObjects.Organization.Person]'. Path '', line 1, position 2." });
	}

	[Test]
	public void DeserializeEmptyString()
	{
		string value = "{\"Name\":\"\"}";
		Person person = JsonConvert.DeserializeObject<Person>(value);
		Assert.AreEqual("", person.Name);
	}

	[Test]
	public void SerializePropertyGetError()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.SerializeObject(new MemoryStream(), new JsonSerializerSettings
			{
				ContractResolver = new DefaultContractResolver()
			});
		}, new string[1] { "Error getting value from 'ReadTimeout' on 'System.IO.MemoryStream'." });
	}

	[Test]
	public void DeserializePropertySetError()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<MemoryStream>("{ReadTimeout:0}", new JsonSerializerSettings
			{
				ContractResolver = new DefaultContractResolver()
			});
		}, new string[1] { "Error setting value to 'ReadTimeout' on 'System.IO.MemoryStream'." });
	}

	[Test]
	public void DeserializeEnsureTypeEmptyStringToIntError()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<MemoryStream>("{ReadTimeout:''}", new JsonSerializerSettings
			{
				ContractResolver = new DefaultContractResolver()
			});
		}, new string[1] { "Error converting value {null} to type 'System.Int32'. Path 'ReadTimeout', line 1, position 15." });
	}

	[Test]
	public void DeserializeEnsureTypeNullToIntError()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<MemoryStream>("{ReadTimeout:null}", new JsonSerializerSettings
			{
				ContractResolver = new DefaultContractResolver()
			});
		}, new string[1] { "Error converting value {null} to type 'System.Int32'. Path 'ReadTimeout', line 1, position 17." });
	}

	[Test]
	public void SerializeGenericListOfStrings()
	{
		List<string> list = new List<string>();
		list.Add("str_1");
		list.Add("str_2");
		list.Add("str_3");
		string actual = JsonConvert.SerializeObject(list);
		Assert.AreEqual("[\"str_1\",\"str_2\",\"str_3\"]", actual);
	}

	[Test]
	public void ConstructorReadonlyFieldsTest()
	{
		ConstructorReadonlyFields value = new ConstructorReadonlyFields("String!", int.MaxValue);
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"A\": \"String!\",\r\n  \"B\": 2147483647\r\n}", text);
		ConstructorReadonlyFields constructorReadonlyFields = JsonConvert.DeserializeObject<ConstructorReadonlyFields>(text);
		Assert.AreEqual("String!", constructorReadonlyFields.A);
		Assert.AreEqual(int.MaxValue, constructorReadonlyFields.B);
	}

	[Test]
	public void SerializeStruct()
	{
		StructTest structTest = new StructTest
		{
			StringProperty = "StringProperty!",
			StringField = "StringField",
			IntProperty = 5,
			IntField = 10
		};
		string text = JsonConvert.SerializeObject(structTest, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"StringField\": \"StringField\",\r\n  \"IntField\": 10,\r\n  \"StringProperty\": \"StringProperty!\",\r\n  \"IntProperty\": 5\r\n}", text);
		StructTest structTest2 = JsonConvert.DeserializeObject<StructTest>(text);
		Assert.AreEqual(structTest.StringProperty, structTest2.StringProperty);
		Assert.AreEqual(structTest.StringField, structTest2.StringField);
		Assert.AreEqual(structTest.IntProperty, structTest2.IntProperty);
		Assert.AreEqual(structTest.IntField, structTest2.IntField);
	}

	[Test]
	public void SerializeListWithJsonConverter()
	{
		Foo foo = new Foo();
		foo.Bars.Add(new Bar
		{
			Id = 0
		});
		foo.Bars.Add(new Bar
		{
			Id = 1
		});
		foo.Bars.Add(new Bar
		{
			Id = 2
		});
		string text = JsonConvert.SerializeObject(foo, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Bars\": [\r\n    0,\r\n    1,\r\n    2\r\n  ]\r\n}", text);
		Foo foo2 = JsonConvert.DeserializeObject<Foo>(text);
		Assert.AreEqual(3, foo2.Bars.Count);
		Assert.AreEqual(0, foo2.Bars[0].Id);
		Assert.AreEqual(1, foo2.Bars[1].Id);
		Assert.AreEqual(2, foo2.Bars[2].Id);
	}

	[Test]
	public void SerializeGuidKeyedDictionary()
	{
		Dictionary<Guid, int> dictionary = new Dictionary<Guid, int>();
		dictionary.Add(new Guid("F60EAEE0-AE47-488E-B330-59527B742D77"), 1);
		dictionary.Add(new Guid("C2594C02-EBA1-426A-AA87-8DD8871350B0"), 2);
		string actual = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"f60eaee0-ae47-488e-b330-59527b742d77\": 1,\r\n  \"c2594c02-eba1-426a-aa87-8dd8871350b0\": 2\r\n}", actual);
	}

	[Test]
	public void SerializePersonKeyedDictionary()
	{
		Dictionary<Person, int> dictionary = new Dictionary<Person, int>();
		dictionary.Add(new Person
		{
			Name = "p1"
		}, 1);
		dictionary.Add(new Person
		{
			Name = "p2"
		}, 2);
		string actual = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Newtonsoft.Json.Tests.TestObjects.Organization.Person\": 1,\r\n  \"Newtonsoft.Json.Tests.TestObjects.Organization.Person\": 2\r\n}", actual);
	}

	[Test]
	public void DeserializePersonKeyedDictionary()
	{
		try
		{
			string value = "{\r\n  \"Newtonsoft.Json.Tests.TestObjects.Organization.Person\": 1,\r\n  \"Newtonsoft.Json.Tests.TestObjects.Organization.Person\": 2\r\n}";
			JsonConvert.DeserializeObject<Dictionary<Person, int>>(value);
			Assert.Fail();
		}
		catch (JsonSerializationException ex)
		{
			Assert.IsTrue(ex.Message.StartsWith("Could not convert string 'Newtonsoft.Json.Tests.TestObjects.Organization.Person' to dictionary key type 'Newtonsoft.Json.Tests.TestObjects.Organization.Person'. Create a TypeConverter to convert from the string to the key type object. Path '['Newtonsoft.Json.Tests.TestObjects.Organization.Person']'"));
		}
	}

	[Test]
	public void SerializeFragment()
	{
		string json = "{\r\n        \"responseData\": {\r\n          \"results\": [\r\n            {\r\n              \"GsearchResultClass\": \"GwebSearch\",\r\n              \"unescapedUrl\": \"http://en.wikipedia.org/wiki/Paris_Hilton\",\r\n              \"url\": \"http://en.wikipedia.org/wiki/Paris_Hilton\",\r\n              \"visibleUrl\": \"en.wikipedia.org\",\r\n              \"cacheUrl\": \"http://www.google.com/search?q=cache:TwrPfhd22hYJ:en.wikipedia.org\",\r\n              \"title\": \"<b>Paris Hilton</b> - Wikipedia, the free encyclopedia\",\r\n              \"titleNoFormatting\": \"Paris Hilton - Wikipedia, the free encyclopedia\",\r\n              \"content\": \"[1] In 2006, she released her debut album...\"\r\n            },\r\n            {\r\n              \"GsearchResultClass\": \"GwebSearch\",\r\n              \"unescapedUrl\": \"http://www.imdb.com/name/nm0385296/\",\r\n              \"url\": \"http://www.imdb.com/name/nm0385296/\",\r\n              \"visibleUrl\": \"www.imdb.com\",\r\n              \"cacheUrl\": \"http://www.google.com/search?q=cache:1i34KkqnsooJ:www.imdb.com\",\r\n              \"title\": \"<b>Paris Hilton</b>\",\r\n              \"titleNoFormatting\": \"Paris Hilton\",\r\n              \"content\": \"Self: Zoolander. Socialite <b>Paris Hilton</b>...\"\r\n            }\r\n          ],\r\n          \"cursor\": {\r\n            \"pages\": [\r\n              {\r\n                \"start\": \"0\",\r\n                \"label\": 1\r\n              },\r\n              {\r\n                \"start\": \"4\",\r\n                \"label\": 2\r\n              },\r\n              {\r\n                \"start\": \"8\",\r\n                \"label\": 3\r\n              },\r\n              {\r\n                \"start\": \"12\",\r\n                \"label\": 4\r\n              }\r\n            ],\r\n            \"estimatedResultCount\": \"59600000\",\r\n            \"currentPageIndex\": 0,\r\n            \"moreResultsUrl\": \"http://www.google.com/search?oe=utf8&ie=utf8...\"\r\n          }\r\n        },\r\n        \"responseDetails\": null,\r\n        \"responseStatus\": 200\r\n      }";
		JObject jObject = JObject.Parse(json);
		IList<JToken> list = jObject["responseData"]["results"].Children().ToList();
		IList<SearchResult> list2 = new List<SearchResult>();
		foreach (JToken item2 in list)
		{
			SearchResult item = JsonConvert.DeserializeObject<SearchResult>(item2.ToString());
			list2.Add(item);
		}
		Assert.AreEqual(2, list2.Count);
		Assert.AreEqual("<b>Paris Hilton</b> - Wikipedia, the free encyclopedia", list2[0].Title);
		Assert.AreEqual("<b>Paris Hilton</b>", list2[1].Title);
	}

	[Test]
	public void DeserializeBaseReferenceWithDerivedValue()
	{
		PersonPropertyClass personPropertyClass = new PersonPropertyClass();
		WagePerson wagePerson = (WagePerson)personPropertyClass.Person;
		wagePerson.BirthDate = new DateTime(2000, 11, 29, 23, 59, 59, DateTimeKind.Utc);
		wagePerson.Department = "McDees";
		wagePerson.HourlyWage = 12.50m;
		wagePerson.LastModified = new DateTime(2000, 11, 29, 23, 59, 59, DateTimeKind.Utc);
		wagePerson.Name = "Jim Bob";
		string text = JsonConvert.SerializeObject(personPropertyClass, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Person\": {\r\n    \"HourlyWage\": 12.50,\r\n    \"Name\": \"Jim Bob\",\r\n    \"BirthDate\": \"2000-11-29T23:59:59Z\",\r\n    \"LastModified\": \"2000-11-29T23:59:59Z\"\r\n  }\r\n}", text);
		PersonPropertyClass personPropertyClass2 = JsonConvert.DeserializeObject<PersonPropertyClass>(text);
		Assert.AreEqual(wagePerson.HourlyWage, ((WagePerson)personPropertyClass2.Person).HourlyWage);
	}

	[Test]
	public void DeserializePopulateDictionaryAndList()
	{
		ExistingValueClass existingValueClass = JsonConvert.DeserializeObject<ExistingValueClass>("{'Dictionary':{appended:'appended',existing:'new'}}");
		Assert.IsNotNull(existingValueClass);
		Assert.IsNotNull(existingValueClass.Dictionary);
		Assert.AreEqual(typeof(Dictionary<string, string>), existingValueClass.Dictionary.GetType());
		Assert.AreEqual(typeof(List<string>), existingValueClass.List.GetType());
		Assert.AreEqual(2, existingValueClass.Dictionary.Count);
		Assert.AreEqual("new", existingValueClass.Dictionary["existing"]);
		Assert.AreEqual("appended", existingValueClass.Dictionary["appended"]);
		Assert.AreEqual(1, existingValueClass.List.Count);
		Assert.AreEqual("existing", existingValueClass.List[0]);
	}

	[Test]
	public void IgnoreIndexedProperties()
	{
		ThisGenericTest<KeyValueId> thisGenericTest = new ThisGenericTest<KeyValueId>();
		thisGenericTest.Add(new KeyValueId
		{
			Id = 1,
			Key = "key1",
			Value = "value1"
		});
		thisGenericTest.Add(new KeyValueId
		{
			Id = 2,
			Key = "key2",
			Value = "value2"
		});
		thisGenericTest.MyProperty = "some value";
		string text = thisGenericTest.ToJson();
		StringAssert.AreEqual("{\r\n  \"MyProperty\": \"some value\",\r\n  \"TheItems\": [\r\n    {\r\n      \"Id\": 1,\r\n      \"Key\": \"key1\",\r\n      \"Value\": \"value1\"\r\n    },\r\n    {\r\n      \"Id\": 2,\r\n      \"Key\": \"key2\",\r\n      \"Value\": \"value2\"\r\n    }\r\n  ]\r\n}", text);
		ThisGenericTest<KeyValueId> thisGenericTest2 = JsonConvert.DeserializeObject<ThisGenericTest<KeyValueId>>(text);
		Assert.AreEqual("some value", thisGenericTest2.MyProperty);
	}

	[Test]
	public void JRawValue()
	{
		JRawValueTestObject jRawValueTestObject = JsonConvert.DeserializeObject<JRawValueTestObject>("{value:3}");
		Assert.AreEqual("3", jRawValueTestObject.Value.ToString());
		jRawValueTestObject = JsonConvert.DeserializeObject<JRawValueTestObject>("{value:'3'}");
		Assert.AreEqual("\"3\"", jRawValueTestObject.Value.ToString());
	}

	[Test]
	public void DeserializeDictionaryWithNoDefaultConstructor()
	{
		string value = "{key1:'value1',key2:'value2',key3:'value3'}";
		DictionaryWithNoDefaultConstructor dictionaryWithNoDefaultConstructor = JsonConvert.DeserializeObject<DictionaryWithNoDefaultConstructor>(value);
		Assert.AreEqual(3, dictionaryWithNoDefaultConstructor.Count);
		Assert.AreEqual("value1", dictionaryWithNoDefaultConstructor["key1"]);
		Assert.AreEqual("value2", dictionaryWithNoDefaultConstructor["key2"]);
		Assert.AreEqual("value3", dictionaryWithNoDefaultConstructor["key3"]);
	}

	[Test]
	public void DeserializeDictionaryWithNoDefaultConstructor_PreserveReferences()
	{
		string json = "{'$id':'1',key1:'value1',key2:'value2',key3:'value3'}";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<DictionaryWithNoDefaultConstructor>(json, new JsonSerializerSettings
			{
				PreserveReferencesHandling = PreserveReferencesHandling.All,
				MetadataPropertyHandling = MetadataPropertyHandling.Default
			});
		}, new string[1] { "Cannot preserve reference to readonly dictionary, or dictionary created from a non-default constructor: Newtonsoft.Json.Tests.TestObjects.DictionaryWithNoDefaultConstructor. Path 'key1', line 1, position 16." });
	}

	[Test]
	public void SerializeNonPublicBaseJsonProperties()
	{
		B value = new B();
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"B2\": null,\r\n  \"A1\": null,\r\n  \"B3\": null,\r\n  \"A2\": null\r\n}", actual);
	}

	[Test]
	public void DeserializeDateTimeOffsetAndDateTime()
	{
		string value = "{\"DateTimeOffsetValue\":\"2012-02-25T19:55:50.6095676+00:00\", \"DateTimeValue\":\"2012-02-25T19:55:50.6095676+00:00\"}";
		DateTimeOffsetWrapper dateTimeOffsetWrapper = JsonConvert.DeserializeObject<DateTimeOffsetWrapper>(value, new JsonSerializerSettings
		{
			DateParseHandling = DateParseHandling.DateTimeOffset,
			Converters = { (JsonConverter)new IsoDateTimeConverter() }
		});
		DateTimeOffsetWrapper dateTimeOffsetWrapper2 = JsonConvert.DeserializeObject<DateTimeOffsetWrapper>(value, new JsonSerializerSettings
		{
			DateParseHandling = DateParseHandling.DateTimeOffset
		});
		Assert.AreEqual(dateTimeOffsetWrapper2.DateTimeOffsetValue, dateTimeOffsetWrapper.DateTimeOffsetValue);
	}

	[Test]
	public void CircularConstructorDeserialize()
	{
		CircularConstructor1 circularConstructor = new CircularConstructor1(null)
		{
			StringProperty = "Value!"
		};
		CircularConstructor2 circularConstructor2 = (circularConstructor.C2 = new CircularConstructor2(null)
		{
			IntProperty = 1
		});
		circularConstructor2.C1 = circularConstructor;
		string actual = JsonConvert.SerializeObject(circularConstructor, new JsonSerializerSettings
		{
			ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
			Formatting = Formatting.Indented
		});
		StringAssert.AreEqual("{\r\n  \"C2\": {\r\n    \"IntProperty\": 1\r\n  },\r\n  \"StringProperty\": \"Value!\"\r\n}", actual);
		CircularConstructor1 circularConstructor4 = JsonConvert.DeserializeObject<CircularConstructor1>("{\r\n  \"C2\": {\r\n    \"IntProperty\": 1,\r\n    \"C1\": {}\r\n  },\r\n  \"StringProperty\": \"Value!\"\r\n}");
		Assert.AreEqual("Value!", circularConstructor4.StringProperty);
		Assert.AreEqual(1, circularConstructor4.C2.IntProperty);
		Assert.AreEqual(null, circularConstructor4.C2.C1.StringProperty);
		Assert.AreEqual(null, circularConstructor4.C2.C1.C2);
	}

	[Test]
	public void DeserializeToObjectProperty()
	{
		string value = "{ Key: 'abc', Value: 123 }";
		KeyValueTestClass keyValueTestClass = JsonConvert.DeserializeObject<KeyValueTestClass>(value);
		Assert.AreEqual(123L, keyValueTestClass.Value);
	}

	[Test]
	public void DataContractJsonSerializerTest()
	{
		DataContractJsonSerializerTestClass graph = new DataContractJsonSerializerTestClass
		{
			TimeSpanProperty = new TimeSpan(200, 20, 59, 30, 900),
			GuidProperty = new Guid("66143115-BE2A-4a59-AF0A-348E1EA15B1E"),
			AnimalProperty = new Human
			{
				Ethnicity = "European"
			}
		};
		MemoryStream memoryStream = new MemoryStream();
		DataContractJsonSerializer dataContractJsonSerializer = new DataContractJsonSerializer(typeof(DataContractJsonSerializerTestClass), new Type[1] { typeof(Human) });
		dataContractJsonSerializer.WriteObject(memoryStream, graph);
		byte[] array = memoryStream.ToArray();
		string text = Encoding.UTF8.GetString(array, 0, array.Length);
	}

	[Test]
	public void SerializeNonIDictionary()
	{
		ModelStateDictionary<string> modelStateDictionary = new ModelStateDictionary<string>();
		modelStateDictionary.Add("key", "value");
		string text = JsonConvert.SerializeObject(modelStateDictionary);
		Assert.AreEqual("{\"key\":\"value\"}", text);
		ModelStateDictionary<string> modelStateDictionary2 = JsonConvert.DeserializeObject<ModelStateDictionary<string>>(text);
		Assert.AreEqual(1, modelStateDictionary2.Count);
		Assert.AreEqual("value", modelStateDictionary2["key"]);
	}

	[Test]
	public void DeserializeUsingNonDefaultConstructorWithLeftOverValues()
	{
		List<KVPair<string, string>> list = JsonConvert.DeserializeObject<List<KVPair<string, string>>>("[{\"Key\":\"Two\",\"Value\":\"2\"},{\"Key\":\"One\",\"Value\":\"1\"}]");
		Assert.AreEqual(2, list.Count);
		Assert.AreEqual("Two", list[0].Key);
		Assert.AreEqual("2", list[0].Value);
		Assert.AreEqual("One", list[1].Key);
		Assert.AreEqual("1", list[1].Value);
	}

	[Test]
	public void SerializeClassWithInheritedProtectedMember()
	{
		AATestClass value = new AATestClass(2);
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"AA_field1\": 2,\r\n  \"AA_property1\": 2,\r\n  \"AA_property2\": 2,\r\n  \"AA_property3\": 2,\r\n  \"AA_property4\": 2\r\n}", actual);
		BBTestClass value2 = new BBTestClass(3, 4);
		actual = JsonConvert.SerializeObject(value2, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"BB_field1\": 4,\r\n  \"BB_field2\": 4,\r\n  \"AA_field1\": 3,\r\n  \"BB_property1\": 4,\r\n  \"BB_property2\": 4,\r\n  \"BB_property3\": 4,\r\n  \"BB_property4\": 4,\r\n  \"BB_property5\": 4,\r\n  \"BB_property7\": 4,\r\n  \"AA_property1\": 3,\r\n  \"AA_property2\": 3,\r\n  \"AA_property3\": 3,\r\n  \"AA_property4\": 3\r\n}", actual);
	}

	[Test]
	public void SerializeDeserializeXNodeProperties()
	{
		XNodeTestObject xNodeTestObject = new XNodeTestObject();
		xNodeTestObject.Document = XDocument.Parse("<root>hehe, root</root>");
		xNodeTestObject.Element = XElement.Parse("<fifth xmlns:json=\"http://json.org\" json:Awesome=\"true\">element</fifth>");
		string text = JsonConvert.SerializeObject(xNodeTestObject, Formatting.Indented);
		string expected = "{\r\n  \"Document\": {\r\n    \"root\": \"hehe, root\"\r\n  },\r\n  \"Element\": {\r\n    \"fifth\": {\r\n      \"@xmlns:json\": \"http://json.org\",\r\n      \"@json:Awesome\": \"true\",\r\n      \"#text\": \"element\"\r\n    }\r\n  }\r\n}";
		StringAssert.AreEqual(expected, text);
		XNodeTestObject xNodeTestObject2 = JsonConvert.DeserializeObject<XNodeTestObject>(text);
		Assert.AreEqual(xNodeTestObject.Document.ToString(), xNodeTestObject2.Document.ToString());
		Assert.AreEqual(xNodeTestObject.Element.ToString(), xNodeTestObject2.Element.ToString());
		Assert.IsNull(xNodeTestObject2.Element.Parent);
	}

	[Test]
	public void FullClientMapSerialization()
	{
		ClientMap value = new ClientMap
		{
			position = new Pos
			{
				X = 100,
				Y = 200
			},
			center = new PosDouble
			{
				X = 251.6,
				Y = 361.3
			}
		};
		string actual = JsonConvert.SerializeObject(value, new PosConverter(), new PosDoubleConverter());
		Assert.AreEqual("{\"position\":new Pos(100,200),\"center\":new PosD(251.6,361.3)}", actual);
	}

	[Test]
	public void SerializeRefAdditionalContent()
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("$ref", "Persons");
		dictionary.Add("$id", 1);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
		dictionary2.Add("_id", 2);
		dictionary2.Add("Name", "Isabell");
		dictionary2.Add("Father", dictionary);
		string json = JsonConvert.SerializeObject(dictionary2, Formatting.Indented);
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
		}, new string[1] { "Additional content found in JSON reference object. A JSON reference object should only have a $ref property. Path 'Father.$id', line 6, position 10." });
	}

	[Test]
	public void SerializeRefBadType()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			Dictionary<string, object> value = new Dictionary<string, object>
			{
				{ "$ref", 1 },
				{ "$id", 1 }
			};
			string value2 = JsonConvert.SerializeObject(new Dictionary<string, object>
			{
				{ "_id", 2 },
				{ "Name", "Isabell" },
				{ "Father", value }
			}, Formatting.Indented);
			JsonConvert.DeserializeObject<Dictionary<string, object>>(value2);
		}, new string[1] { "JSON reference $ref property must have a string or null value. Path 'Father.$ref', line 5, position 13." });
	}

	[Test]
	public void SerializeRefNull()
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("$ref", null);
		dictionary.Add("$id", null);
		dictionary.Add("blah", "blah!");
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
		dictionary2.Add("_id", 2);
		dictionary2.Add("Name", "Isabell");
		dictionary2.Add("Father", dictionary);
		string text = JsonConvert.SerializeObject(dictionary2);
		Assert.AreEqual("{\"_id\":2,\"Name\":\"Isabell\",\"Father\":{\"$ref\":null,\"$id\":null,\"blah\":\"blah!\"}}", text);
		Dictionary<string, object> dictionary3 = JsonConvert.DeserializeObject<Dictionary<string, object>>(text);
		Assert.AreEqual(3, dictionary3.Count);
		Assert.AreEqual(1, ((JObject)dictionary3["Father"]).Count);
		Assert.AreEqual("blah!", (string)((JObject)dictionary3["Father"])["blah"]);
	}

	[Test]
	public void DeserializeIgnoredPropertyInConstructor()
	{
		string value = "{\"First\":\"First\",\"Second\":2,\"Ignored\":{\"Name\":\"James\"},\"AdditionalContent\":{\"LOL\":true}}";
		ConstructorCompexIgnoredProperty constructorCompexIgnoredProperty = JsonConvert.DeserializeObject<ConstructorCompexIgnoredProperty>(value);
		Assert.AreEqual("First", constructorCompexIgnoredProperty.First);
		Assert.AreEqual(2, constructorCompexIgnoredProperty.Second);
		Assert.AreEqual(null, constructorCompexIgnoredProperty.Ignored);
	}

	[Test]
	public void DeserializeFloatAsDecimal()
	{
		string value = "{'value':9.9}";
		IDictionary<string, object> dictionary = JsonConvert.DeserializeObject<IDictionary<string, object>>(value, new JsonSerializerSettings
		{
			FloatParseHandling = FloatParseHandling.Decimal
		});
		Assert.AreEqual(typeof(decimal), dictionary["value"].GetType());
		Assert.AreEqual(9.9m, dictionary["value"]);
	}

	[Test]
	public void SerializeDeserializeDictionaryKey()
	{
		Dictionary<DictionaryKey, string> dictionary = new Dictionary<DictionaryKey, string>();
		dictionary.Add(new DictionaryKey
		{
			Value = "First!"
		}, "First");
		dictionary.Add(new DictionaryKey
		{
			Value = "Second!"
		}, "Second");
		string text = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"First!\": \"First\",\r\n  \"Second!\": \"Second\"\r\n}", text);
		Dictionary<DictionaryKey, string> dictionary2 = JsonConvert.DeserializeObject<Dictionary<DictionaryKey, string>>(text);
		Assert.AreEqual(2, dictionary2.Count);
	}

	[Test]
	public void SerializeNullableArray()
	{
		string actual = JsonConvert.SerializeObject(new double?[3] { 2.4, 4.3, null }, Formatting.Indented);
		StringAssert.AreEqual("[\r\n  2.4,\r\n  4.3,\r\n  null\r\n]", actual);
	}

	[Test]
	public void DeserializeNullableArray()
	{
		double?[] array = (double?[])JsonConvert.DeserializeObject("[\r\n  2.4,\r\n  4.3,\r\n  null\r\n]", typeof(double?[]));
		Assert.AreEqual(3, array.Length);
		Assert.AreEqual(2.4, array[0]);
		Assert.AreEqual(4.3, array[1]);
		Assert.AreEqual(null, array[2]);
	}

	[Test]
	public void SerializeHashSet()
	{
		string text = JsonConvert.SerializeObject(new HashSet<string> { "One", "2", "III" }, Formatting.Indented);
		StringAssert.AreEqual("[\r\n  \"One\",\r\n  \"2\",\r\n  \"III\"\r\n]", text);
		HashSet<string> hashSet = JsonConvert.DeserializeObject<HashSet<string>>(text);
		Assert.AreEqual(3, hashSet.Count);
		Assert.IsTrue(hashSet.Contains("One"));
		Assert.IsTrue(hashSet.Contains("2"));
		Assert.IsTrue(hashSet.Contains("III"));
	}

	[Test]
	public void DeserializeByteArray()
	{
		JsonSerializer jsonSerializer = new JsonSerializer();
		jsonSerializer.Converters.Add(new IsoDateTimeConverter());
		jsonSerializer.NullValueHandling = NullValueHandling.Ignore;
		string s = "[{\"Prop1\":\"\"},{\"Prop1\":\"\"}]";
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ByteArrayTestClass[] array = (ByteArrayTestClass[])jsonSerializer.Deserialize(reader, typeof(ByteArrayTestClass[]));
		Assert.AreEqual(2, array.Length);
		Assert.AreEqual(0, array[0].Prop1.Length);
		Assert.AreEqual(0, array[1].Prop1.Length);
	}

	[Test]
	public void StringDictionaryTest()
	{
		string fullName = typeof(StringDictionary).FullName;
		StringDictionaryTestClass stringDictionaryTestClass = new StringDictionaryTestClass
		{
			StringDictionaryProperty = new StringDictionary
			{
				{ "1", "One" },
				{ "2", "II" },
				{ "3", "3" }
			}
		};
		string json = JsonConvert.SerializeObject(stringDictionaryTestClass, Formatting.Indented);
		if (stringDictionaryTestClass.StringDictionaryProperty is IDictionary<string, string>)
		{
			StringDictionaryTestClass stringDictionaryTestClass2 = JsonConvert.DeserializeObject<StringDictionaryTestClass>(json);
			Assert.AreEqual(3, stringDictionaryTestClass2.StringDictionaryProperty.Count);
			Assert.AreEqual("One", stringDictionaryTestClass2.StringDictionaryProperty["1"]);
			Assert.AreEqual("II", stringDictionaryTestClass2.StringDictionaryProperty["2"]);
			Assert.AreEqual("3", stringDictionaryTestClass2.StringDictionaryProperty["3"]);
		}
		else
		{
			ExceptionAssert.Throws<JsonSerializationException>(() =>
			{
				JsonConvert.DeserializeObject<StringDictionaryTestClass>(json);
			}, new string[1] { "Cannot create and populate list type " + fullName + ". Path 'StringDictionaryProperty', line 2, position 31." });
		}
	}

	[Test]
	public void SerializeStructWithJsonObjectAttribute()
	{
		StructWithAttribute structWithAttribute = new StructWithAttribute
		{
			MyInt = int.MaxValue
		};
		string text = JsonConvert.SerializeObject(structWithAttribute, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"MyInt\": 2147483647\r\n}", text);
		Assert.AreEqual(int.MaxValue, JsonConvert.DeserializeObject<StructWithAttribute>(text).MyInt);
	}

	[Test]
	public void ReadWriteTimeZoneOffsetIso()
	{
		string text = JsonConvert.SerializeObject(new TimeZoneOffsetObject
		{
			Offset = new DateTimeOffset(new DateTime(2000, 1, 1), TimeSpan.FromHours(6.0))
		});
		Assert.AreEqual("{\"Offset\":\"2000-01-01T00:00:00+06:00\"}", text);
		JsonTextReader reader = new JsonTextReader(new StringReader(text))
		{
			DateParseHandling = DateParseHandling.None
		};
		JsonSerializer jsonSerializer = new JsonSerializer();
		TimeZoneOffsetObject timeZoneOffsetObject = jsonSerializer.Deserialize<TimeZoneOffsetObject>(reader);
		Assert.AreEqual(TimeSpan.FromHours(6.0), timeZoneOffsetObject.Offset.Offset);
		Assert.AreEqual(new DateTime(2000, 1, 1), timeZoneOffsetObject.Offset.Date);
	}

	[Test]
	public void DeserializePropertyNullableDateTimeOffsetExactIso()
	{
		NullableDateTimeTestClass nullableDateTimeTestClass = JsonConvert.DeserializeObject<NullableDateTimeTestClass>("{\"DateTimeOffsetField\":\"2000-01-01T00:00:00+06:00\"}");
		Assert.AreEqual(new DateTimeOffset(new DateTime(2000, 1, 1), TimeSpan.FromHours(6.0)), nullableDateTimeTestClass.DateTimeOffsetField);
	}

	[Test]
	public void ReadWriteTimeZoneOffsetMsAjax()
	{
		string text = JsonConvert.SerializeObject(new TimeZoneOffsetObject
		{
			Offset = new DateTimeOffset(new DateTime(2000, 1, 1), TimeSpan.FromHours(6.0))
		}, Formatting.None, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
		});
		Assert.AreEqual("{\"Offset\":\"\\/Date(946663200000+0600)\\/\"}", text);
		JsonTextReader reader = new JsonTextReader(new StringReader(text));
		JsonSerializer jsonSerializer = new JsonSerializer();
		jsonSerializer.DateParseHandling = DateParseHandling.None;
		TimeZoneOffsetObject timeZoneOffsetObject = jsonSerializer.Deserialize<TimeZoneOffsetObject>(reader);
		Assert.AreEqual(TimeSpan.FromHours(6.0), timeZoneOffsetObject.Offset.Offset);
		Assert.AreEqual(new DateTime(2000, 1, 1), timeZoneOffsetObject.Offset.Date);
	}

	[Test]
	public void DeserializePropertyNullableDateTimeOffsetExactMsAjax()
	{
		NullableDateTimeTestClass nullableDateTimeTestClass = JsonConvert.DeserializeObject<NullableDateTimeTestClass>("{\"DateTimeOffsetField\":\"\\/Date(946663200000+0600)\\/\"}");
		Assert.AreEqual(new DateTimeOffset(new DateTime(2000, 1, 1), TimeSpan.FromHours(6.0)), nullableDateTimeTestClass.DateTimeOffsetField);
	}

	[Test]
	public void OverridenPropertyMembers()
	{
		string actual = JsonConvert.SerializeObject(new DerivedEvent(), Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"event\": \"derived\"\r\n}", actual);
	}

	[Test]
	public void SerializeExpandoObject()
	{
		dynamic val = new ExpandoObject();
		val.Int = 1;
		val.Decimal = 99.9;
		val.Complex = new ExpandoObject();
		val.Complex.String = "I am a string";
		val.Complex.DateTime = new DateTime(2000, 12, 20, 18, 55, 0, DateTimeKind.Utc);
		string text = JsonConvert.SerializeObject(val, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Int\": 1,\r\n  \"Decimal\": 99.9,\r\n  \"Complex\": {\r\n    \"String\": \"I am a string\",\r\n    \"DateTime\": \"2000-12-20T18:55:00Z\"\r\n  }\r\n}", text);
		IDictionary<string, object> dictionary = JsonConvert.DeserializeObject<ExpandoObject>(text);
		CustomAssert.IsInstanceOfType(typeof(long), dictionary["Int"]);
		Assert.AreEqual((long)val.Int, dictionary["Int"]);
		CustomAssert.IsInstanceOfType(typeof(double), dictionary["Decimal"]);
		Assert.AreEqual(val.Decimal, dictionary["Decimal"]);
		CustomAssert.IsInstanceOfType(typeof(ExpandoObject), dictionary["Complex"]);
		IDictionary<string, object> dictionary2 = (ExpandoObject)dictionary["Complex"];
		CustomAssert.IsInstanceOfType(typeof(string), dictionary2["String"]);
		Assert.AreEqual(val.Complex.String, dictionary2["String"]);
		CustomAssert.IsInstanceOfType(typeof(DateTime), dictionary2["DateTime"]);
		Assert.AreEqual(val.Complex.DateTime, dictionary2["DateTime"]);
	}

	[Test]
	public void DeserializeDecimalExact()
	{
		decimal num = JsonConvert.DeserializeObject<decimal>("123456789876543.21");
		Assert.AreEqual(123456789876543.21m, num);
	}

	[Test]
	public void DeserializeNullableDecimalExact()
	{
		decimal? num = JsonConvert.DeserializeObject<decimal?>("123456789876543.21");
		Assert.AreEqual(123456789876543.21m, num);
	}

	[Test]
	public void DeserializeDecimalPropertyExact()
	{
		string s = "{Amount:123456789876543.21}";
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(s));
		jsonTextReader.FloatParseHandling = FloatParseHandling.Decimal;
		JsonSerializer jsonSerializer = new JsonSerializer();
		Invoice invoice = jsonSerializer.Deserialize<Invoice>(jsonTextReader);
		Assert.AreEqual(123456789876543.21m, invoice.Amount);
	}

	[Test]
	public void DeserializeDecimalArrayExact()
	{
		string value = "[123456789876543.21]";
		IList<decimal> list = JsonConvert.DeserializeObject<IList<decimal>>(value);
		Assert.AreEqual(123456789876543.21m, list[0]);
	}

	[Test]
	public void DeserializeDecimalDictionaryExact()
	{
		string s = "{'Value':123456789876543.21}";
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(s));
		jsonTextReader.FloatParseHandling = FloatParseHandling.Decimal;
		JsonSerializer jsonSerializer = new JsonSerializer();
		IDictionary<string, decimal> dictionary = jsonSerializer.Deserialize<IDictionary<string, decimal>>(jsonTextReader);
		Assert.AreEqual(123456789876543.21m, dictionary["Value"]);
	}

	[Test]
	public void DeserializeStructProperty()
	{
		VectorParent vectorParent = new VectorParent();
		vectorParent.Position = new Vector
		{
			X = 1f,
			Y = 2f,
			Z = 3f
		};
		string value = JsonConvert.SerializeObject(vectorParent);
		vectorParent = JsonConvert.DeserializeObject<VectorParent>(value);
		Assert.AreEqual(1, vectorParent.Position.X);
		Assert.AreEqual(2, vectorParent.Position.Y);
		Assert.AreEqual(3, vectorParent.Position.Z);
	}

	[Test]
	public void PrivateSetterOnBaseClassProperty()
	{
		PrivateSetterDerived value = new PrivateSetterDerived("meh", "woo");
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			TypeNameHandling = TypeNameHandling.Objects,
			ConstructorHandling = ConstructorHandling.AllowNonPublicDefaultConstructor
		};
		string value2 = JsonConvert.SerializeObject(value, Formatting.Indented, settings);
		PrivateSetterBase privateSetterBase = JsonConvert.DeserializeObject<PrivateSetterBase>(value2, settings);
		Assert.AreEqual(((PrivateSetterDerived)privateSetterBase).IDoWork, "woo");
		Assert.AreEqual(privateSetterBase.IDontWork, "meh");
	}

	[Test]
	public void DeserializeNullableStruct()
	{
		NullableStructPropertyClass value = new NullableStructPropertyClass
		{
			Foo1 = new StructISerializable
			{
				Name = "foo 1"
			},
			Foo2 = new StructISerializable
			{
				Name = "foo 2"
			}
		};
		NullableStructPropertyClass value2 = new NullableStructPropertyClass
		{
			Foo1 = new StructISerializable
			{
				Name = "foo 1"
			},
			Foo2 = null
		};
		string serStr = JsonConvert.SerializeObject(value);
		NullableStructPropertyClass nullableStructPropertyClass = deserialize(serStr);
		Assert.AreEqual(nullableStructPropertyClass.Foo1.Name, "foo 1");
		Assert.AreEqual(nullableStructPropertyClass.Foo2.Value.Name, "foo 2");
		serStr = JsonConvert.SerializeObject(value2);
		nullableStructPropertyClass = deserialize(serStr);
		Assert.AreEqual(nullableStructPropertyClass.Foo1.Name, "foo 1");
		Assert.AreEqual(nullableStructPropertyClass.Foo2, null);
	}

	private static NullableStructPropertyClass deserialize(string serStr)
	{
		return JsonConvert.DeserializeObject<NullableStructPropertyClass>(serStr, new JsonSerializerSettings
		{
			NullValueHandling = NullValueHandling.Ignore,
			MissingMemberHandling = MissingMemberHandling.Ignore
		});
	}

	[Test]
	public void DeserializeJToken()
	{
		JTokenTestClass jTokenTestClass = new JTokenTestClass();
		jTokenTestClass.Name = "Success";
		jTokenTestClass.Data = new JObject(new JProperty("First", "Value1"), new JProperty("Second", "Value2"));
		JTokenTestClass jTokenTestClass2 = jTokenTestClass;
		string value = JsonConvert.SerializeObject(jTokenTestClass2, Formatting.Indented);
		JTokenTestClass jTokenTestClass3 = JsonConvert.DeserializeObject<JTokenTestClass>(value);
		Assert.AreEqual("Success", jTokenTestClass3.Name);
		Assert.IsTrue(jTokenTestClass3.Data.DeepEquals(jTokenTestClass2.Data));
	}

	[Test]
	public void DeserializeMinValueDecimal()
	{
		DecimalTest value = new DecimalTest(decimal.MinValue);
		string value2 = JsonConvert.SerializeObject(value);
		DecimalTest decimalTest = JsonConvert.DeserializeObject<DecimalTest>(value2, new JsonSerializerSettings
		{
			MetadataPropertyHandling = MetadataPropertyHandling.Default
		});
		Assert.AreEqual(decimal.MinValue, decimalTest.Value);
	}

	[Test]
	public void NonPublicConstructorWithJsonConstructorTest()
	{
		NonPublicConstructorWithJsonConstructor nonPublicConstructorWithJsonConstructor = JsonConvert.DeserializeObject<NonPublicConstructorWithJsonConstructor>("{}");
		Assert.AreEqual("NonPublic", nonPublicConstructorWithJsonConstructor.Constructor);
	}

	[Test]
	public void PublicConstructorOverridenByJsonConstructorTest()
	{
		PublicConstructorOverridenByJsonConstructor publicConstructorOverridenByJsonConstructor = JsonConvert.DeserializeObject<PublicConstructorOverridenByJsonConstructor>("{Value:'value!'}");
		Assert.AreEqual("Public Parameterized", publicConstructorOverridenByJsonConstructor.Constructor);
		Assert.AreEqual("value!", publicConstructorOverridenByJsonConstructor.Value);
	}

	[Test]
	public void MultipleParametrizedConstructorsJsonConstructorTest()
	{
		MultipleParametrizedConstructorsJsonConstructor multipleParametrizedConstructorsJsonConstructor = JsonConvert.DeserializeObject<MultipleParametrizedConstructorsJsonConstructor>("{Value:'value!', Age:1}");
		Assert.AreEqual("Public Parameterized 2", multipleParametrizedConstructorsJsonConstructor.Constructor);
		Assert.AreEqual("value!", multipleParametrizedConstructorsJsonConstructor.Value);
		Assert.AreEqual(1, multipleParametrizedConstructorsJsonConstructor.Age);
	}

	[Test]
	public void DeserializeEnumerable()
	{
		EnumerableClass value = new EnumerableClass
		{
			Enumerable = new List<string> { "One", "Two", "Three" }
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Enumerable\": [\r\n    \"One\",\r\n    \"Two\",\r\n    \"Three\"\r\n  ]\r\n}", text);
		EnumerableClass enumerableClass = JsonConvert.DeserializeObject<EnumerableClass>(text);
		Assert.AreEqual("One", enumerableClass.Enumerable.ElementAt(0));
		Assert.AreEqual("Two", enumerableClass.Enumerable.ElementAt(1));
		Assert.AreEqual("Three", enumerableClass.Enumerable.ElementAt(2));
	}

	[Test]
	public void SerializeAttributesOnBase()
	{
		ComplexItem value = new ComplexItem();
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Name\": null\r\n}", actual);
	}

	[Test]
	public void DeserializeStringEnglish()
	{
		string value = "{\r\n  'Name': 'James Hughes',\r\n  'Age': '40',\r\n  'Height': '44.4',\r\n  'Price': '4'\r\n}";
		DeserializeStringConvert deserializeStringConvert = JsonConvert.DeserializeObject<DeserializeStringConvert>(value);
		Assert.AreEqual(40, deserializeStringConvert.Age);
		Assert.AreEqual(44.4, deserializeStringConvert.Height);
		Assert.AreEqual(4m, deserializeStringConvert.Price);
	}

	[Test]
	public void DeserializeNullDateTimeValueTest()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject("null", typeof(DateTime));
		}, new string[1] { "Error converting value {null} to type 'System.DateTime'. Path '', line 1, position 4." });
	}

	[Test]
	public void DeserializeNullNullableDateTimeValueTest()
	{
		object anObject = JsonConvert.DeserializeObject("null", typeof(DateTime?));
		Assert.IsNull(anObject);
	}

	[Test]
	public void MultiIndexSuperTest()
	{
		MultiIndexSuper value = new MultiIndexSuper();
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		Assert.AreEqual("{}", actual);
	}

	[Test]
	public void CommentTestClassTest()
	{
		string value = "{\"indexed\":true, \"startYear\":1939, \"values\":\r\n                            [  3000,  /* 1940-1949 */\r\n                               3000,   3600,   3600,   3600,   3600,   4200,   4200,   4200,   4200,   4800,  /* 1950-1959 */\r\n                               4800,   4800,   4800,   4800,   4800,   4800,   6600,   6600,   7800,   7800,  /* 1960-1969 */\r\n                               7800,   7800,   9000,  10800,  13200,  14100,  15300,  16500,  17700,  22900,  /* 1970-1979 */\r\n                              25900,  29700,  32400,  35700,  37800,  39600,  42000,  43800,  45000,  48000,  /* 1980-1989 */\r\n                              51300,  53400,  55500,  57600,  60600,  61200,  62700,  65400,  68400,  72600,  /* 1990-1999 */\r\n                              76200,  80400,  84900,  87000,  87900,  90000,  94200,  97500, 102000, 106800,  /* 2000-2009 */\r\n                             106800, 106800]  /* 2010-2011 */\r\n                                }";
		CommentTestClass commentTestClass = JsonConvert.DeserializeObject<CommentTestClass>(value);
		Assert.AreEqual(true, commentTestClass.Indexed);
		Assert.AreEqual(1939, commentTestClass.StartYear);
		Assert.AreEqual(63, commentTestClass.Values.Count);
	}

	[Test]
	public void PopulationBehaviourForOmittedPropertiesIsTheSameForParameterisedConstructorAsForDefaultConstructor()
	{
		string value = "{A:\"Test\"}";
		DTOWithoutParameterisedConstructor dTOWithoutParameterisedConstructor = JsonConvert.DeserializeObject<DTOWithoutParameterisedConstructor>(value);
		DTOWithParameterisedConstructor dTOWithParameterisedConstructor = JsonConvert.DeserializeObject<DTOWithParameterisedConstructor>(value);
		Assert.AreEqual(dTOWithoutParameterisedConstructor.B, dTOWithParameterisedConstructor.B);
	}

	[Test]
	public void SkipPopulatingArrayPropertyClass()
	{
		string value = JsonConvert.SerializeObject(new EnumerableArrayPropertyClass());
		JsonConvert.DeserializeObject<EnumerableArrayPropertyClass>(value);
	}

	[Test]
	public void ChildDataContractTest()
	{
		ChildDataContract value = new ChildDataContract
		{
			VirtualMember = "VirtualMember!",
			NonVirtualMember = "NonVirtualMember!"
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"virtualMember\": \"VirtualMember!\",\r\n  \"nonVirtualMember\": \"NonVirtualMember!\"\r\n}", actual);
	}

	[Test]
	public void ChildDataContractTestWithDataContractSerializer()
	{
		ChildDataContract graph = new ChildDataContract
		{
			VirtualMember = "VirtualMember!",
			NonVirtualMember = "NonVirtualMember!"
		};
		DataContractSerializer dataContractSerializer = new DataContractSerializer(typeof(ChildDataContract));
		MemoryStream memoryStream = new MemoryStream();
		dataContractSerializer.WriteObject(memoryStream, graph);
		string actual = Encoding.UTF8.GetString(memoryStream.ToArray(), 0, Convert.ToInt32(memoryStream.Length));
		Assert.AreEqual("<ChildDataContract xmlns=\"http://schemas.datacontract.org/2004/07/Newtonsoft.Json.Tests.TestObjects\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\"><nonVirtualMember>NonVirtualMember!</nonVirtualMember><virtualMember>VirtualMember!</virtualMember><NewMember i:nil=\"true\"/></ChildDataContract>", actual);
	}

	[Test]
	public void ChildObjectTest()
	{
		VirtualOverrideNewChildObject value = new VirtualOverrideNewChildObject
		{
			VirtualMember = "VirtualMember!",
			NonVirtualMember = "NonVirtualMember!"
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"virtualMember\":\"VirtualMember!\",\"nonVirtualMember\":\"NonVirtualMember!\"}", actual);
	}

	[Test]
	public void ChildWithDifferentOverrideObjectTest()
	{
		VirtualOverrideNewChildWithDifferentOverrideObject value = new VirtualOverrideNewChildWithDifferentOverrideObject
		{
			VirtualMember = "VirtualMember!",
			NonVirtualMember = "NonVirtualMember!"
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"differentVirtualMember\":\"VirtualMember!\",\"nonVirtualMember\":\"NonVirtualMember!\"}", actual);
	}

	[Test]
	public void ImplementInterfaceObjectTest()
	{
		ImplementInterfaceObject value = new ImplementInterfaceObject
		{
			InterfaceMember = new DateTime(2010, 12, 31, 0, 0, 0, DateTimeKind.Utc),
			NewMember = "NewMember!"
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"virtualMember\": \"2010-12-31T00:00:00Z\",\r\n  \"newMemberWithProperty\": null\r\n}", actual);
	}

	[Test]
	public void NonDefaultConstructorWithReadOnlyCollectionPropertyTest()
	{
		NonDefaultConstructorWithReadOnlyCollectionProperty nonDefaultConstructorWithReadOnlyCollectionProperty = new NonDefaultConstructorWithReadOnlyCollectionProperty("blah");
		nonDefaultConstructorWithReadOnlyCollectionProperty.Categories.Add("one");
		nonDefaultConstructorWithReadOnlyCollectionProperty.Categories.Add("two");
		string text = JsonConvert.SerializeObject(nonDefaultConstructorWithReadOnlyCollectionProperty, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Title\": \"blah\",\r\n  \"Categories\": [\r\n    \"one\",\r\n    \"two\"\r\n  ]\r\n}", text);
		NonDefaultConstructorWithReadOnlyCollectionProperty nonDefaultConstructorWithReadOnlyCollectionProperty2 = JsonConvert.DeserializeObject<NonDefaultConstructorWithReadOnlyCollectionProperty>(text);
		Assert.AreEqual(nonDefaultConstructorWithReadOnlyCollectionProperty.Title, nonDefaultConstructorWithReadOnlyCollectionProperty2.Title);
		Assert.AreEqual(nonDefaultConstructorWithReadOnlyCollectionProperty.Categories.Count, nonDefaultConstructorWithReadOnlyCollectionProperty2.Categories.Count);
		Assert.AreEqual("one", nonDefaultConstructorWithReadOnlyCollectionProperty2.Categories[0]);
		Assert.AreEqual("two", nonDefaultConstructorWithReadOnlyCollectionProperty2.Categories[1]);
	}

	[Test]
	public void NonDefaultConstructorWithReadOnlyDictionaryPropertyTest()
	{
		NonDefaultConstructorWithReadOnlyDictionaryProperty nonDefaultConstructorWithReadOnlyDictionaryProperty = new NonDefaultConstructorWithReadOnlyDictionaryProperty("blah");
		nonDefaultConstructorWithReadOnlyDictionaryProperty.Categories.Add("one", 1);
		nonDefaultConstructorWithReadOnlyDictionaryProperty.Categories.Add("two", 2);
		string text = JsonConvert.SerializeObject(nonDefaultConstructorWithReadOnlyDictionaryProperty, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Title\": \"blah\",\r\n  \"Categories\": {\r\n    \"one\": 1,\r\n    \"two\": 2\r\n  }\r\n}", text);
		NonDefaultConstructorWithReadOnlyDictionaryProperty nonDefaultConstructorWithReadOnlyDictionaryProperty2 = JsonConvert.DeserializeObject<NonDefaultConstructorWithReadOnlyDictionaryProperty>(text);
		Assert.AreEqual(nonDefaultConstructorWithReadOnlyDictionaryProperty.Title, nonDefaultConstructorWithReadOnlyDictionaryProperty2.Title);
		Assert.AreEqual(nonDefaultConstructorWithReadOnlyDictionaryProperty.Categories.Count, nonDefaultConstructorWithReadOnlyDictionaryProperty2.Categories.Count);
		Assert.AreEqual(1, nonDefaultConstructorWithReadOnlyDictionaryProperty2.Categories["one"]);
		Assert.AreEqual(2, nonDefaultConstructorWithReadOnlyDictionaryProperty2.Categories["two"]);
	}

	[Test]
	public void ClassAttributesInheritance()
	{
		string actual = JsonConvert.SerializeObject(new ClassAttributeDerived
		{
			BaseClassValue = "BaseClassValue!",
			DerivedClassValue = "DerivedClassValue!",
			NonSerialized = "NonSerialized!"
		}, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"DerivedClassValue\": \"DerivedClassValue!\",\r\n  \"BaseClassValue\": \"BaseClassValue!\"\r\n}", actual);
		actual = JsonConvert.SerializeObject(new CollectionClassAttributeDerived
		{
			BaseClassValue = "BaseClassValue!",
			CollectionDerivedClassValue = "CollectionDerivedClassValue!"
		}, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"CollectionDerivedClassValue\": \"CollectionDerivedClassValue!\",\r\n  \"BaseClassValue\": \"BaseClassValue!\"\r\n}", actual);
	}

	[Test]
	public void PrivateMembersClassWithAttributesTest()
	{
		PrivateMembersClassWithAttributes value = new PrivateMembersClassWithAttributes("privateString!", "internalString!", "readonlyString!");
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"_privateString\": \"privateString!\",\r\n  \"_readonlyString\": \"readonlyString!\",\r\n  \"_internalString\": \"internalString!\"\r\n}", text);
		PrivateMembersClassWithAttributes privateMembersClassWithAttributes = JsonConvert.DeserializeObject<PrivateMembersClassWithAttributes>(text);
		Assert.AreEqual("readonlyString!", privateMembersClassWithAttributes.UseValue());
	}

	[Test]
	public void DeserializeGenericEnumerableProperty()
	{
		BusRun busRun = JsonConvert.DeserializeObject<BusRun>("{\"Departures\":[\"\\/Date(1309874148734-0400)\\/\",\"\\/Date(1309874148739-0400)\\/\",null],\"WheelchairAccessible\":true}");
		Assert.AreEqual(typeof(List<DateTime?>), busRun.Departures.GetType());
		Assert.AreEqual(3, busRun.Departures.Count());
		Assert.IsNotNull(busRun.Departures.ElementAt(0));
		Assert.IsNotNull(busRun.Departures.ElementAt(1));
		Assert.IsNull(busRun.Departures.ElementAt(2));
	}

	[Test]
	public void JsonPropertyDataMemberOrder()
	{
		DerivedType value = new DerivedType();
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"dinosaur\": null,\r\n  \"dog\": null,\r\n  \"cat\": null,\r\n  \"zebra\": null,\r\n  \"bird\": null,\r\n  \"parrot\": null,\r\n  \"albatross\": null,\r\n  \"antelope\": null\r\n}", actual);
	}

	[Test]
	public void UriGuidTimeSpanTestClassEmptyTest()
	{
		UriGuidTimeSpanTestClass uriGuidTimeSpanTestClass = new UriGuidTimeSpanTestClass();
		string text = JsonConvert.SerializeObject(uriGuidTimeSpanTestClass, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Guid\": \"00000000-0000-0000-0000-000000000000\",\r\n  \"NullableGuid\": null,\r\n  \"TimeSpan\": \"00:00:00\",\r\n  \"NullableTimeSpan\": null,\r\n  \"Uri\": null\r\n}", text);
		UriGuidTimeSpanTestClass uriGuidTimeSpanTestClass2 = JsonConvert.DeserializeObject<UriGuidTimeSpanTestClass>(text);
		Assert.AreEqual(uriGuidTimeSpanTestClass.Guid, uriGuidTimeSpanTestClass2.Guid);
		Assert.AreEqual(uriGuidTimeSpanTestClass.NullableGuid, uriGuidTimeSpanTestClass2.NullableGuid);
		Assert.AreEqual(uriGuidTimeSpanTestClass.TimeSpan, uriGuidTimeSpanTestClass2.TimeSpan);
		Assert.AreEqual(uriGuidTimeSpanTestClass.NullableTimeSpan, uriGuidTimeSpanTestClass2.NullableTimeSpan);
		Assert.AreEqual(uriGuidTimeSpanTestClass.Uri, uriGuidTimeSpanTestClass2.Uri);
	}

	[Test]
	public void UriGuidTimeSpanTestClassValuesTest()
	{
		UriGuidTimeSpanTestClass uriGuidTimeSpanTestClass = new UriGuidTimeSpanTestClass
		{
			Guid = new Guid("1924129C-F7E0-40F3-9607-9939C531395A"),
			NullableGuid = new Guid("9E9F3ADF-E017-4F72-91E0-617EBE85967D"),
			TimeSpan = TimeSpan.FromDays(1.0),
			NullableTimeSpan = TimeSpan.FromHours(1.0),
			Uri = new Uri("http://testuri.com")
		};
		string text = JsonConvert.SerializeObject(uriGuidTimeSpanTestClass, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"Guid\": \"1924129c-f7e0-40f3-9607-9939c531395a\",\r\n  \"NullableGuid\": \"9e9f3adf-e017-4f72-91e0-617ebe85967d\",\r\n  \"TimeSpan\": \"1.00:00:00\",\r\n  \"NullableTimeSpan\": \"01:00:00\",\r\n  \"Uri\": \"http://testuri.com\"\r\n}", text);
		UriGuidTimeSpanTestClass uriGuidTimeSpanTestClass2 = JsonConvert.DeserializeObject<UriGuidTimeSpanTestClass>(text);
		Assert.AreEqual(uriGuidTimeSpanTestClass.Guid, uriGuidTimeSpanTestClass2.Guid);
		Assert.AreEqual(uriGuidTimeSpanTestClass.NullableGuid, uriGuidTimeSpanTestClass2.NullableGuid);
		Assert.AreEqual(uriGuidTimeSpanTestClass.TimeSpan, uriGuidTimeSpanTestClass2.TimeSpan);
		Assert.AreEqual(uriGuidTimeSpanTestClass.NullableTimeSpan, uriGuidTimeSpanTestClass2.NullableTimeSpan);
		Assert.AreEqual(uriGuidTimeSpanTestClass.Uri, uriGuidTimeSpanTestClass2.Uri);
	}

	[Test]
	public void UsingJsonTextWriter()
	{
		object o = new
		{
			p = 1
		};
		JObject jObject = JObject.FromObject(o);
		using StringWriter stringWriter = new StringWriter();
		using JsonTextWriter jsonTextWriter = new JsonTextWriter(stringWriter);
		jsonTextWriter.WriteToken(jObject.CreateReader());
		jsonTextWriter.Flush();
		string actual = stringWriter.ToString();
		Assert.AreEqual("{\"p\":1}", actual);
	}

	[Test]
	public void SerializeUriWithQuotes()
	{
		string uriString = "http://test.com/%22foo+bar%22";
		Uri uri = new Uri(uriString);
		string value = JsonConvert.SerializeObject(uri);
		Uri actual = JsonConvert.DeserializeObject<Uri>(value);
		Assert.AreEqual(uri, actual);
	}

	[Test]
	public void SerializeUriWithSlashes()
	{
		string uriString = "http://tes/?a=b\\\\c&d=e\\";
		Uri uri = new Uri(uriString);
		string value = JsonConvert.SerializeObject(uri);
		Uri actual = JsonConvert.DeserializeObject<Uri>(value);
		Assert.AreEqual(uri, actual);
	}

	[Test]
	public void DeserializeByteArrayWithTypeNameHandling()
	{
		TestObject value = new TestObject("Test", new byte[6] { 72, 63, 62, 71, 92, 55 });
		JsonSerializer jsonSerializer = new JsonSerializer();
		jsonSerializer.TypeNameHandling = TypeNameHandling.All;
		byte[] buffer;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			using JsonWriter jsonWriter = new JsonTextWriter(new StreamWriter(memoryStream));
			jsonSerializer.Serialize(jsonWriter, value);
			jsonWriter.Flush();
			buffer = memoryStream.ToArray();
		}
		using MemoryStream stream = new MemoryStream(buffer);
		using JsonReader reader = new JsonTextReader(new StreamReader(stream));
		TestObject testObject = (TestObject)jsonSerializer.Deserialize(reader);
		Assert.AreEqual("Test", testObject.Name);
		CollectionAssert.AreEquivalent(new byte[6] { 72, 63, 62, 71, 92, 55 }, testObject.Data);
	}

	[Test]
	public void SerializeStaticDefault()
	{
		DefaultContractResolver contractResolver = new DefaultContractResolver();
		StaticTestClass value = new StaticTestClass
		{
			x = int.MaxValue
		};
		StaticTestClass.y = 2;
		StaticTestClass.z = 3;
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			ContractResolver = contractResolver
		});
		StringAssert.AreEqual("{\r\n  \"x\": 2147483647,\r\n  \"y\": 2,\r\n  \"z\": 3\r\n}", actual);
		StaticTestClass staticTestClass = JsonConvert.DeserializeObject<StaticTestClass>("{\r\n  \"x\": -1,\r\n  \"y\": -2,\r\n  \"z\": -3\r\n}", new JsonSerializerSettings
		{
			ContractResolver = contractResolver
		});
		Assert.AreEqual(-1, staticTestClass.x);
		Assert.AreEqual(-2, StaticTestClass.y);
		Assert.AreEqual(-3, StaticTestClass.z);
	}

	[Test]
	public void SerializeStaticReflection()
	{
		ReflectionContractResolver contractResolver = new ReflectionContractResolver();
		StaticTestClass value = new StaticTestClass
		{
			x = int.MaxValue
		};
		StaticTestClass.y = 2;
		StaticTestClass.z = 3;
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			ContractResolver = contractResolver
		});
		StringAssert.AreEqual("{\r\n  \"x\": 2147483647,\r\n  \"y\": 2,\r\n  \"z\": 3\r\n}", actual);
		StaticTestClass staticTestClass = JsonConvert.DeserializeObject<StaticTestClass>("{\r\n  \"x\": -1,\r\n  \"y\": -2,\r\n  \"z\": -3\r\n}", new JsonSerializerSettings
		{
			ContractResolver = contractResolver
		});
		Assert.AreEqual(-1, staticTestClass.x);
		Assert.AreEqual(-2, StaticTestClass.y);
		Assert.AreEqual(-3, StaticTestClass.z);
	}

	[Test]
	public void DeserializeDecimalsWithCulture()
	{
		CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
		try
		{
			CultureInfo cultureInfo = CultureInfo.CreateSpecificCulture("nb-NO");
			Thread.CurrentThread.CurrentCulture = cultureInfo;
			Thread.CurrentThread.CurrentUICulture = cultureInfo;
			string value = "{ 'Quantity': '1.5', 'OptionalQuantity': '2.2' }";
			DecimalTestClass decimalTestClass = JsonConvert.DeserializeObject<DecimalTestClass>(value);
			Assert.AreEqual(1.5m, decimalTestClass.Quantity);
			Assert.AreEqual(2.2, decimalTestClass.OptionalQuantity);
		}
		finally
		{
			Thread.CurrentThread.CurrentCulture = currentCulture;
			Thread.CurrentThread.CurrentUICulture = currentCulture;
		}
	}

	[Test]
	public void ReadForTypeHackFixDecimal()
	{
		IList<decimal> list = new List<decimal> { 1.1m };
		string value = JsonConvert.SerializeObject(list);
		IList<decimal> list2 = JsonConvert.DeserializeObject<IList<decimal>>(value);
		Assert.AreEqual(list.Count, list2.Count);
		Assert.AreEqual(list[0], list2[0]);
	}

	[Test]
	public void ReadForTypeHackFixDateTimeOffset()
	{
		IList<DateTimeOffset?> list = new List<DateTimeOffset?> { null };
		string value = JsonConvert.SerializeObject(list);
		IList<DateTimeOffset?> list2 = JsonConvert.DeserializeObject<IList<DateTimeOffset?>>(value);
		Assert.AreEqual(list.Count, list2.Count);
		Assert.AreEqual(list[0], list2[0]);
	}

	[Test]
	public void ReadForTypeHackFixByteArray()
	{
		IList<byte[]> list = new List<byte[]> { null };
		string value = JsonConvert.SerializeObject(list);
		IList<byte[]> list2 = JsonConvert.DeserializeObject<IList<byte[]>>(value);
		Assert.AreEqual(list.Count, list2.Count);
		Assert.AreEqual(list[0], list2[0]);
	}

	[Test]
	public void SerializeInheritanceHierarchyWithDuplicateProperty()
	{
		Bb bb = new Bb();
		bb.no = true;
		Aa aa = bb;
		aa.no = int.MaxValue;
		string text = JsonConvert.SerializeObject(bb);
		Assert.AreEqual("{\"no\":true}", text);
		Bb bb2 = JsonConvert.DeserializeObject<Bb>(text);
		Assert.AreEqual(true, bb2.no);
	}

	[Test]
	public void DeserializeNullInt()
	{
		string json = "[\r\n  1,\r\n  2,\r\n  3,\r\n  null\r\n]";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			List<int> list = JsonConvert.DeserializeObject<List<int>>(json);
		}, new string[1] { "Error converting value {null} to type 'System.Int32'. Path '[3]', line 5, position 6." });
	}

	[Test]
	public void SerializeNullableWidgetStruct()
	{
		Widget value = new Widget
		{
			Id = new WidgetId
			{
				Value = "id"
			}
		};
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"Id\":{\"Value\":\"id\"}}", actual);
	}

	[Test]
	public void DeserializeNullableWidgetStruct()
	{
		string value = "{\"Id\":{\"Value\":\"id\"}}";
		Widget widget = JsonConvert.DeserializeObject<Widget>(value);
		Assert.AreEqual(new WidgetId
		{
			Value = "id"
		}, widget.Id);
		Assert.AreEqual(new WidgetId
		{
			Value = "id"
		}, widget.Id.Value);
		Assert.AreEqual("id", widget.Id.Value.Value);
	}

	[Test]
	public void DeserializeBoolInt()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			string value = "{\r\n  \"PreProperty\": true,\r\n  \"PostProperty\": \"-1\"\r\n}";
			JsonConvert.DeserializeObject<MyClass>(value);
		}, new string[1] { "Unexpected character encountered while parsing value: t. Path 'PreProperty', line 2, position 18." });
	}

	[Test]
	public void DeserializeUnexpectedEndInt()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			string value = "{\r\n  \"PreProperty\": ";
			JsonConvert.DeserializeObject<MyClass>(value);
		}, new string[0]);
	}

	[Test]
	public void DeserializeNullableGuid()
	{
		string value = "{\"Id\":null}";
		NullableGuid nullableGuid = JsonConvert.DeserializeObject<NullableGuid>(value);
		Assert.AreEqual(null, nullableGuid.Id);
		value = "{\"Id\":\"d8220a4b-75b1-4b7a-8112-b7bdae956a45\"}";
		nullableGuid = JsonConvert.DeserializeObject<NullableGuid>(value);
		Assert.AreEqual(new Guid("d8220a4b-75b1-4b7a-8112-b7bdae956a45"), nullableGuid.Id);
	}

	[Test]
	public void SerializeNullableGuidCustomWriterOverridesNullableGuid()
	{
		NullableGuid value = new NullableGuid
		{
			Id = Guid.Empty
		};
		NullableGuidCountingJsonTextWriter nullableGuidCountingJsonTextWriter = new NullableGuidCountingJsonTextWriter(new StreamWriter(Stream.Null));
		JsonSerializer jsonSerializer = JsonSerializer.Create();
		jsonSerializer.Serialize(nullableGuidCountingJsonTextWriter, value);
		Assert.AreEqual(1, nullableGuidCountingJsonTextWriter.NullableGuidCount);
		MemoryTraceWriter traceWriter = new MemoryTraceWriter();
		jsonSerializer.TraceWriter = traceWriter;
		jsonSerializer.Serialize(nullableGuidCountingJsonTextWriter, value);
		Assert.AreEqual(2, nullableGuidCountingJsonTextWriter.NullableGuidCount);
	}

	[Test]
	public void DeserializeGuid()
	{
		Item item = new Item();
		item.SourceTypeID = new Guid("d8220a4b-75b1-4b7a-8112-b7bdae956a45");
		item.BrokerID = new Guid("951663c4-924e-4c86-a57a-7ed737501dbd");
		item.Latitude = 33.657145;
		item.Longitude = -117.766684;
		item.TimeStamp = new DateTime(2000, 3, 1, 23, 59, 59, DateTimeKind.Utc);
		item.Payload = new byte[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		Item value = item;
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"SourceTypeID\": \"d8220a4b-75b1-4b7a-8112-b7bdae956a45\",\r\n  \"BrokerID\": \"951663c4-924e-4c86-a57a-7ed737501dbd\",\r\n  \"Latitude\": 33.657145,\r\n  \"Longitude\": -117.766684,\r\n  \"TimeStamp\": \"2000-03-01T23:59:59Z\",\r\n  \"Payload\": {\r\n    \"$type\": \"" + ReflectionUtils.GetTypeName(typeof(byte[]), TypeNameAssemblyFormatHandling.Simple, DefaultSerializationBinder.Instance) + "\",\r\n    \"$value\": \"AAECAwQFBgcICQ==\"\r\n  }\r\n}", text);
		Item item2 = JsonConvert.DeserializeObject<Item>(text);
		Assert.AreEqual(new Guid("d8220a4b-75b1-4b7a-8112-b7bdae956a45"), item2.SourceTypeID);
		Assert.AreEqual(new Guid("951663c4-924e-4c86-a57a-7ed737501dbd"), item2.BrokerID);
		byte[] source = (byte[])item2.Payload;
		CollectionAssert.AreEquivalent(new byte[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 }.ToList(), source.ToList());
	}

	[Test]
	public void DeserializeObjectDictionary()
	{
		JsonSerializer jsonSerializer = JsonSerializer.Create(new JsonSerializerSettings());
		Dictionary<string, string> dictionary = jsonSerializer.Deserialize<Dictionary<string, string>>(new JsonTextReader(new StringReader("{'k1':'','k2':'v2'}")));
		Assert.AreEqual("", dictionary["k1"]);
		Assert.AreEqual("v2", dictionary["k2"]);
	}

	[Test]
	public void DeserializeNullableEnum()
	{
		string text = JsonConvert.SerializeObject(new WithEnums
		{
			Id = 7,
			NullableEnum = null
		});
		Assert.AreEqual("{\"Id\":7,\"NullableEnum\":null}", text);
		WithEnums withEnums = JsonConvert.DeserializeObject<WithEnums>(text);
		Assert.AreEqual(null, withEnums.NullableEnum);
		text = JsonConvert.SerializeObject(new WithEnums
		{
			Id = 7,
			NullableEnum = MyEnum.Value2
		});
		Assert.AreEqual("{\"Id\":7,\"NullableEnum\":1}", text);
		withEnums = JsonConvert.DeserializeObject<WithEnums>(text);
		Assert.AreEqual(MyEnum.Value2, withEnums.NullableEnum);
	}

	[Test]
	public void NullableStructWithConverter()
	{
		string actual = JsonConvert.SerializeObject(new Widget1
		{
			Id = new WidgetId1
			{
				Value = 1234L
			}
		});
		Assert.AreEqual("{\"Id\":\"1234\"}", actual);
		Widget1 widget = JsonConvert.DeserializeObject<Widget1>("{\"Id\":\"1234\"}");
		Assert.AreEqual(new WidgetId1
		{
			Value = 1234L
		}, widget.Id);
	}

	[Test]
	public void SerializeDictionaryStringStringAndStringObject()
	{
		JsonSerializer jsonSerializer = JsonSerializer.Create(new JsonSerializerSettings());
		Dictionary<string, string> dictionary = jsonSerializer.Deserialize<Dictionary<string, string>>(new JsonTextReader(new StringReader("{'k1':'','k2':'v2'}")));
		JsonTextReader reader = new JsonTextReader(new StringReader("{'k1':'','k2':'v2'}"));
		Dictionary<string, object> dictionary2 = jsonSerializer.Deserialize<Dictionary<string, object>>(reader);
		Assert.AreEqual(dictionary["k1"], dictionary2["k1"]);
	}

	[Test]
	public void DeserializeEmptyStrings()
	{
		object anObject = JsonConvert.DeserializeObject<double?>("");
		Assert.IsNull(anObject);
		anObject = JsonConvert.DeserializeObject<char?>("");
		Assert.IsNull(anObject);
		anObject = JsonConvert.DeserializeObject<int?>("");
		Assert.IsNull(anObject);
		anObject = JsonConvert.DeserializeObject<decimal?>("");
		Assert.IsNull(anObject);
		anObject = JsonConvert.DeserializeObject<DateTime?>("");
		Assert.IsNull(anObject);
		anObject = JsonConvert.DeserializeObject<DateTimeOffset?>("");
		Assert.IsNull(anObject);
		anObject = JsonConvert.DeserializeObject<byte[]>("");
		Assert.IsNull(anObject);
	}

	[Test]
	public void DeserializeDoubleFromEmptyString()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<double>("");
		}, new string[1] { "No JSON content found and type 'System.Double' is not nullable. Path '', line 0, position 0." });
	}

	[Test]
	public void DeserializeEnumFromEmptyString()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<StringComparison>("");
		}, new string[1] { "No JSON content found and type 'System.StringComparison' is not nullable. Path '', line 0, position 0." });
	}

	[Test]
	public void DeserializeInt32FromEmptyString()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<int>("");
		}, new string[1] { "No JSON content found and type 'System.Int32' is not nullable. Path '', line 0, position 0." });
	}

	[Test]
	public void DeserializeByteArrayFromEmptyString()
	{
		byte[] anObject = JsonConvert.DeserializeObject<byte[]>("");
		Assert.IsNull(anObject);
	}

	[Test]
	public void DeserializeDoubleFromNullString()
	{
		ExceptionAssert.Throws<ArgumentNullException>(() =>
		{
			JsonConvert.DeserializeObject<double>(null);
		}, new string[2]
		{
			"Value cannot be null." + Environment.NewLine + "Parameter name: value",
			"Argument cannot be null." + Environment.NewLine + "Parameter name: value"
		});
	}

	[Test]
	public void DeserializeFromNullString()
	{
		ExceptionAssert.Throws<ArgumentNullException>(() =>
		{
			JsonConvert.DeserializeObject(null);
		}, new string[2]
		{
			"Value cannot be null." + Environment.NewLine + "Parameter name: value",
			"Argument cannot be null." + Environment.NewLine + "Parameter name: value"
		});
	}

	[Test]
	public void DeserializeIsoDatesWithIsoConverter()
	{
		string value = "{\"Value\":\"2012-02-25T19:55:50.6095676+13:00\"}";
		DateTimeWrapper dateTimeWrapper = JsonConvert.DeserializeObject<DateTimeWrapper>(value, new JsonConverter[1]
		{
			new IsoDateTimeConverter()
		});
		Assert.AreEqual(DateTimeKind.Local, dateTimeWrapper.Value.Kind);
	}

	[Test]
	public void DeserializeUTC()
	{
		DateTimeTestClass dateTimeTestClass = JsonConvert.DeserializeObject<DateTimeTestClass>("{\"PreField\":\"Pre\",\"DateTimeField\":\"2008-12-12T12:12:12Z\",\"DateTimeOffsetField\":\"2008-12-12T12:12:12Z\",\"PostField\":\"Post\"}", new JsonSerializerSettings
		{
			DateTimeZoneHandling = DateTimeZoneHandling.Local
		});
		Assert.AreEqual(new DateTime(2008, 12, 12, 12, 12, 12, 0, DateTimeKind.Utc).ToLocalTime(), dateTimeTestClass.DateTimeField);
		Assert.AreEqual(new DateTimeOffset(2008, 12, 12, 12, 12, 12, 0, TimeSpan.Zero), dateTimeTestClass.DateTimeOffsetField);
		Assert.AreEqual("Pre", dateTimeTestClass.PreField);
		Assert.AreEqual("Post", dateTimeTestClass.PostField);
		DateTimeTestClass dateTimeTestClass2 = JsonConvert.DeserializeObject<DateTimeTestClass>("{\"PreField\":\"Pre\",\"DateTimeField\":\"2008-01-01T01:01:01Z\",\"DateTimeOffsetField\":\"2008-01-01T01:01:01Z\",\"PostField\":\"Post\"}", new JsonSerializerSettings
		{
			DateTimeZoneHandling = DateTimeZoneHandling.Local
		});
		Assert.AreEqual(new DateTime(2008, 1, 1, 1, 1, 1, 0, DateTimeKind.Utc).ToLocalTime(), dateTimeTestClass2.DateTimeField);
		Assert.AreEqual(new DateTimeOffset(2008, 1, 1, 1, 1, 1, 0, TimeSpan.Zero), dateTimeTestClass2.DateTimeOffsetField);
		Assert.AreEqual("Pre", dateTimeTestClass2.PreField);
		Assert.AreEqual("Post", dateTimeTestClass2.PostField);
	}

	[Test]
	public void NullableDeserializeUTC()
	{
		NullableDateTimeTestClass nullableDateTimeTestClass = JsonConvert.DeserializeObject<NullableDateTimeTestClass>("{\"PreField\":\"Pre\",\"DateTimeField\":\"2008-12-12T12:12:12Z\",\"DateTimeOffsetField\":\"2008-12-12T12:12:12Z\",\"PostField\":\"Post\"}", new JsonSerializerSettings
		{
			DateTimeZoneHandling = DateTimeZoneHandling.Local
		});
		Assert.AreEqual(new DateTime(2008, 12, 12, 12, 12, 12, 0, DateTimeKind.Utc).ToLocalTime(), nullableDateTimeTestClass.DateTimeField);
		Assert.AreEqual(new DateTimeOffset(2008, 12, 12, 12, 12, 12, 0, TimeSpan.Zero), nullableDateTimeTestClass.DateTimeOffsetField);
		Assert.AreEqual("Pre", nullableDateTimeTestClass.PreField);
		Assert.AreEqual("Post", nullableDateTimeTestClass.PostField);
		NullableDateTimeTestClass nullableDateTimeTestClass2 = JsonConvert.DeserializeObject<NullableDateTimeTestClass>("{\"PreField\":\"Pre\",\"DateTimeField\":null,\"DateTimeOffsetField\":null,\"PostField\":\"Post\"}");
		Assert.AreEqual(null, nullableDateTimeTestClass2.DateTimeField);
		Assert.AreEqual(null, nullableDateTimeTestClass2.DateTimeOffsetField);
		Assert.AreEqual("Pre", nullableDateTimeTestClass2.PreField);
		Assert.AreEqual("Post", nullableDateTimeTestClass2.PostField);
	}

	[Test]
	public void PrivateConstructor()
	{
		PersonWithPrivateConstructor personWithPrivateConstructor = PersonWithPrivateConstructor.CreatePerson();
		personWithPrivateConstructor.Name = "John Doe";
		personWithPrivateConstructor.Age = 25;
		string value = JsonConvert.SerializeObject(personWithPrivateConstructor);
		PersonWithPrivateConstructor personWithPrivateConstructor2 = JsonConvert.DeserializeObject<PersonWithPrivateConstructor>(value);
		Assert.AreEqual(personWithPrivateConstructor.Name, personWithPrivateConstructor2.Name);
	}

	[Test]
	public void MetroBlogPost()
	{
		Product product = new Product();
		product.Name = "Apple";
		product.ExpiryDate = new DateTime(2012, 4, 1);
		product.Price = 3.99m;
		product.Sizes = new string[3] { "Small", "Medium", "Large" };
		Product value = product;
		string text = JsonConvert.SerializeObject(value);
		string actual = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			ContractResolver = new MetroPropertyNameResolver(),
			Converters = { (JsonConverter)new MetroStringConverter() },
			Formatting = Formatting.Indented
		});
		StringAssert.AreEqual("{\r\n  \":::NAME:::\": \":::APPLE:::\",\r\n  \":::EXPIRYDATE:::\": \"2012-04-01T00:00:00\",\r\n  \":::PRICE:::\": 3.99,\r\n  \":::SIZES:::\": [\r\n    \":::SMALL:::\",\r\n    \":::MEDIUM:::\",\r\n    \":::LARGE:::\"\r\n  ]\r\n}", actual);
		Color[] value2 = new Color[6]
		{
			Color.Blue,
			Color.Red,
			Color.Yellow,
			Color.Green,
			Color.Black,
			Color.Brown
		};
		string actual2 = JsonConvert.SerializeObject(value2, new JsonSerializerSettings
		{
			ContractResolver = new MetroPropertyNameResolver(),
			Converters = 
			{
				(JsonConverter)new MetroStringConverter(),
				(JsonConverter)new MetroColorConverter()
			},
			Formatting = Formatting.Indented
		});
		StringAssert.AreEqual("[\r\n  \":::GRAY:::\",\r\n  \":::GRAY:::\",\r\n  \":::GRAY:::\",\r\n  \":::GRAY:::\",\r\n  \":::BLACK:::\",\r\n  \":::GRAY:::\"\r\n]", actual2);
	}

	[Test]
	public void MultipleItems()
	{
		IList<MultipleItemsClass> list = new List<MultipleItemsClass>();
		JsonTextReader jsonTextReader = new JsonTextReader(new StringReader("{ \"name\": \"bar\" }{ \"name\": \"baz\" }"));
		jsonTextReader.SupportMultipleContent = true;
		while (jsonTextReader.Read())
		{
			JsonSerializer jsonSerializer = new JsonSerializer();
			MultipleItemsClass item = jsonSerializer.Deserialize<MultipleItemsClass>(jsonTextReader);
			list.Add(item);
		}
		Assert.AreEqual(2, list.Count);
		Assert.AreEqual("bar", list[0].Name);
		Assert.AreEqual("baz", list[1].Name);
	}

	[Test]
	public void TokenFromBson()
	{
		MemoryStream memoryStream = new MemoryStream();
		BsonWriter bsonWriter = new BsonWriter(memoryStream);
		bsonWriter.WriteStartArray();
		bsonWriter.WriteValue("2000-01-02T03:04:05+06:00");
		bsonWriter.WriteEndArray();
		byte[] buffer = memoryStream.ToArray();
		BsonReader reader = new BsonReader(new MemoryStream(buffer))
		{
			ReadRootValueAsArray = true
		};
		JArray jArray = (JArray)JToken.ReadFrom(reader);
		JValue jValue = (JValue)jArray[0];
		Assert.AreEqual(typeof(string), jValue.Value.GetType());
		StringAssert.AreEqual("[\r\n  \"2000-01-02T03:04:05+06:00\"\r\n]", jArray.ToString());
	}

	[Test]
	public void ObjectRequiredDeserializeMissing()
	{
		string value = "{}";
		IList<string> errors = new List<string>();
		EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> error = (object s, Newtonsoft.Json.Serialization.ErrorEventArgs e) =>
		{
			errors.Add(e.ErrorContext.Error.Message);
			e.ErrorContext.Handled = true;
		};
		RequiredObject anObject = JsonConvert.DeserializeObject<RequiredObject>(value, new JsonSerializerSettings
		{
			Error = error
		});
		Assert.IsNotNull(anObject);
		Assert.AreEqual(4, errors.Count);
		Assert.IsTrue(errors[0].StartsWith("Required property 'NonAttributeProperty' not found in JSON. Path ''"));
		Assert.IsTrue(errors[1].StartsWith("Required property 'UnsetProperty' not found in JSON. Path ''"));
		Assert.IsTrue(errors[2].StartsWith("Required property 'AllowNullProperty' not found in JSON. Path ''"));
		Assert.IsTrue(errors[3].StartsWith("Required property 'AlwaysProperty' not found in JSON. Path ''"));
	}

	[Test]
	public void ObjectRequiredDeserializeNull()
	{
		string value = "{'NonAttributeProperty':null,'UnsetProperty':null,'AllowNullProperty':null,'AlwaysProperty':null}";
		IList<string> errors = new List<string>();
		EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> error = (object s, Newtonsoft.Json.Serialization.ErrorEventArgs e) =>
		{
			errors.Add(e.ErrorContext.Error.Message);
			e.ErrorContext.Handled = true;
		};
		RequiredObject anObject = JsonConvert.DeserializeObject<RequiredObject>(value, new JsonSerializerSettings
		{
			Error = error
		});
		Assert.IsNotNull(anObject);
		Assert.AreEqual(3, errors.Count);
		Assert.IsTrue(errors[0].StartsWith("Required property 'NonAttributeProperty' expects a value but got null. Path ''"));
		Assert.IsTrue(errors[1].StartsWith("Required property 'UnsetProperty' expects a value but got null. Path ''"));
		Assert.IsTrue(errors[2].StartsWith("Required property 'AlwaysProperty' expects a value but got null. Path ''"));
	}

	[Test]
	public void ObjectRequiredSerialize()
	{
		IList<string> errors = new List<string>();
		EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> error = (object s, Newtonsoft.Json.Serialization.ErrorEventArgs e) =>
		{
			errors.Add(e.ErrorContext.Error.Message);
			e.ErrorContext.Handled = true;
		};
		string actual = JsonConvert.SerializeObject(new RequiredObject(), new JsonSerializerSettings
		{
			Error = error,
			Formatting = Formatting.Indented
		});
		StringAssert.AreEqual("{\r\n  \"DefaultProperty\": null,\r\n  \"AllowNullProperty\": null\r\n}", actual);
		Assert.AreEqual(3, errors.Count);
		Assert.AreEqual("Cannot write a null value for property 'NonAttributeProperty'. Property requires a value. Path ''.", errors[0]);
		Assert.AreEqual("Cannot write a null value for property 'UnsetProperty'. Property requires a value. Path ''.", errors[1]);
		Assert.AreEqual("Cannot write a null value for property 'AlwaysProperty'. Property requires a value. Path ''.", errors[2]);
	}

	[Test]
	public void DeserializeCollectionItemConverter()
	{
		PropertyItemConverter propertyItemConverter = new PropertyItemConverter();
		propertyItemConverter.Data = new string[3] { "one", "two", "three" };
		PropertyItemConverter propertyItemConverter2 = propertyItemConverter;
		PropertyItemConverter propertyItemConverter3 = JsonConvert.DeserializeObject<PropertyItemConverter>("{'Data':['::ONE::','::TWO::']}");
		Assert.IsNotNull(propertyItemConverter3);
		Assert.AreEqual(2, propertyItemConverter3.Data.Count);
		Assert.AreEqual("one", propertyItemConverter3.Data[0]);
		Assert.AreEqual("two", propertyItemConverter3.Data[1]);
	}

	[Test]
	public void SerializeCollectionItemConverter()
	{
		PropertyItemConverter propertyItemConverter = new PropertyItemConverter();
		propertyItemConverter.Data = new string[3] { "one", "two", "three" };
		PropertyItemConverter value = propertyItemConverter;
		string actual = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"Data\":[\":::ONE:::\",\":::TWO:::\",\":::THREE:::\"]}", actual);
	}

	[Test]
	public void DateTimeDictionaryKey_DateTimeOffset_Iso()
	{
		IDictionary<DateTimeOffset, int> value = new Dictionary<DateTimeOffset, int>
		{
			{
				new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.Zero),
				1
			},
			{
				new DateTimeOffset(2013, 12, 12, 12, 12, 12, TimeSpan.Zero),
				2
			}
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"2000-12-12T12:12:12+00:00\": 1,\r\n  \"2013-12-12T12:12:12+00:00\": 2\r\n}", text);
		IDictionary<DateTimeOffset, int> dictionary = JsonConvert.DeserializeObject<IDictionary<DateTimeOffset, int>>(text);
		Assert.AreEqual(2, dictionary.Count);
		Assert.AreEqual(1, dictionary[new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.Zero)]);
		Assert.AreEqual(2, dictionary[new DateTimeOffset(2013, 12, 12, 12, 12, 12, TimeSpan.Zero)]);
	}

	[Test]
	public void DateTimeDictionaryKey_DateTimeOffset_MS()
	{
		IDictionary<DateTimeOffset?, int> value = new Dictionary<DateTimeOffset?, int>
		{
			{
				new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.Zero),
				1
			},
			{
				new DateTimeOffset(2013, 12, 12, 12, 12, 12, TimeSpan.Zero),
				2
			}
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
		});
		StringAssert.AreEqual("{\r\n  \"\\/Date(976623132000+0000)\\/\": 1,\r\n  \"\\/Date(1386850332000+0000)\\/\": 2\r\n}", text);
		IDictionary<DateTimeOffset?, int> dictionary = JsonConvert.DeserializeObject<IDictionary<DateTimeOffset?, int>>(text);
		Assert.AreEqual(2, dictionary.Count);
		Assert.AreEqual(1, dictionary[new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.Zero)]);
		Assert.AreEqual(2, dictionary[new DateTimeOffset(2013, 12, 12, 12, 12, 12, TimeSpan.Zero)]);
	}

	[Test]
	public void DateTimeDictionaryKey_DateTime_Iso()
	{
		IDictionary<DateTime, int> value = new Dictionary<DateTime, int>
		{
			{
				new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc),
				1
			},
			{
				new DateTime(2013, 12, 12, 12, 12, 12, DateTimeKind.Utc),
				2
			}
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"2000-12-12T12:12:12Z\": 1,\r\n  \"2013-12-12T12:12:12Z\": 2\r\n}", text);
		IDictionary<DateTime, int> dictionary = JsonConvert.DeserializeObject<IDictionary<DateTime, int>>(text);
		Assert.AreEqual(2, dictionary.Count);
		Assert.AreEqual(1, dictionary[new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc)]);
		Assert.AreEqual(2, dictionary[new DateTime(2013, 12, 12, 12, 12, 12, DateTimeKind.Utc)]);
	}

	[Test]
	public void DateTimeDictionaryKey_DateTime_Iso_Local()
	{
		IDictionary<DateTime, int> value = new Dictionary<DateTime, int>
		{
			{
				new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc),
				1
			},
			{
				new DateTime(2013, 12, 12, 12, 12, 12, DateTimeKind.Utc),
				2
			}
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			DateTimeZoneHandling = DateTimeZoneHandling.Local
		});
		JObject jObject = JObject.Parse(text);
		Assert.IsFalse(jObject.Properties().ElementAt(0).Name.Contains("Z"));
		Assert.IsFalse(jObject.Properties().ElementAt(1).Name.Contains("Z"));
		IDictionary<DateTime, int> dictionary = JsonConvert.DeserializeObject<IDictionary<DateTime, int>>(text, new JsonSerializerSettings
		{
			DateTimeZoneHandling = DateTimeZoneHandling.Utc
		});
		Assert.AreEqual(2, dictionary.Count);
		Assert.AreEqual(1, dictionary[new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc)]);
		Assert.AreEqual(2, dictionary[new DateTime(2013, 12, 12, 12, 12, 12, DateTimeKind.Utc)]);
	}

	[Test]
	public void DateTimeDictionaryKey_DateTime_MS()
	{
		IDictionary<DateTime, int> value = new Dictionary<DateTime, int>
		{
			{
				new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc),
				1
			},
			{
				new DateTime(2013, 12, 12, 12, 12, 12, DateTimeKind.Utc),
				2
			}
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
		});
		StringAssert.AreEqual("{\r\n  \"\\/Date(976623132000)\\/\": 1,\r\n  \"\\/Date(1386850332000)\\/\": 2\r\n}", text);
		IDictionary<DateTime, int> dictionary = JsonConvert.DeserializeObject<IDictionary<DateTime, int>>(text);
		Assert.AreEqual(2, dictionary.Count);
		Assert.AreEqual(1, dictionary[new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc)]);
		Assert.AreEqual(2, dictionary[new DateTime(2013, 12, 12, 12, 12, 12, DateTimeKind.Utc)]);
	}

	[Test]
	public void DeserializeEmptyJsonString()
	{
		string actual = (string)new JsonSerializer().Deserialize(new JsonTextReader(new StringReader("''")));
		Assert.AreEqual("", actual);
	}

	[Test]
	public void PropertyItemConverter()
	{
		Event1 value = new Event1
		{
			EventName = "Blackadder III",
			Venue = "Gryphon Theatre",
			Performances = new List<DateTime>
			{
				DateTimeUtils.ConvertJavaScriptTicksToDateTime(1336458600000L),
				DateTimeUtils.ConvertJavaScriptTicksToDateTime(1336545000000L),
				DateTimeUtils.ConvertJavaScriptTicksToDateTime(1336636800000L)
			}
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"EventName\": \"Blackadder III\",\r\n  \"Venue\": \"Gryphon Theatre\",\r\n  \"Performances\": [\r\n    new Date(\r\n      1336458600000\r\n    ),\r\n    new Date(\r\n      1336545000000\r\n    ),\r\n    new Date(\r\n      1336636800000\r\n    )\r\n  ]\r\n}", actual);
	}

	[Test]
	public void IgnoreDataMemberTest()
	{
		string actual = JsonConvert.SerializeObject(new IgnoreDataMemberTestClass
		{
			Ignored = int.MaxValue
		}, Formatting.Indented);
		Assert.AreEqual("{}", actual);
	}

	[Test]
	public void SerializeDataContractSerializationAttributes()
	{
		DataContractSerializationAttributesClass value = new DataContractSerializationAttributesClass
		{
			NoAttribute = "Value!",
			IgnoreDataMemberAttribute = "Value!",
			DataMemberAttribute = "Value!",
			IgnoreDataMemberAndDataMemberAttribute = "Value!"
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"DataMemberAttribute\": \"Value!\",\r\n  \"IgnoreDataMemberAndDataMemberAttribute\": \"Value!\"\r\n}", actual);
		PocoDataContractSerializationAttributesClass value2 = new PocoDataContractSerializationAttributesClass
		{
			NoAttribute = "Value!",
			IgnoreDataMemberAttribute = "Value!",
			DataMemberAttribute = "Value!",
			IgnoreDataMemberAndDataMemberAttribute = "Value!"
		};
		actual = JsonConvert.SerializeObject(value2, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"NoAttribute\": \"Value!\",\r\n  \"DataMemberAttribute\": \"Value!\"\r\n}", actual);
	}

	[Test]
	public void CheckAdditionalContent()
	{
		string json = "{one:1}{}";
		JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings();
		JsonSerializer s = JsonSerializer.Create(jsonSerializerSettings);
		IDictionary<string, int> dictionary = s.Deserialize<Dictionary<string, int>>(new JsonTextReader(new StringReader(json)));
		Assert.IsNotNull(dictionary);
		Assert.AreEqual(1, dictionary["one"]);
		jsonSerializerSettings.CheckAdditionalContent = true;
		s = JsonSerializer.Create(jsonSerializerSettings);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			s.Deserialize<Dictionary<string, int>>(new JsonTextReader(new StringReader(json)));
		}, new string[1] { "Additional text encountered after finished reading JSON content: {. Path '', line 1, position 7." });
	}

	[Test]
	public void CheckAdditionalContentJustComment()
	{
		string s = "{one:1} // This is just a comment";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			CheckAdditionalContent = true
		};
		JsonSerializer jsonSerializer = JsonSerializer.Create(settings);
		IDictionary<string, int> dictionary = jsonSerializer.Deserialize<Dictionary<string, int>>(new JsonTextReader(new StringReader(s)));
		Assert.IsNotNull(dictionary);
		Assert.AreEqual(1, dictionary["one"]);
	}

	[Test]
	public void CheckAdditionalContentJustMultipleComments()
	{
		string s = "{one:1} // This is just a comment\r\n/* This is just a comment\r\nover multiple\r\nlines.*/\r\n\r\n// This is just another comment.";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			CheckAdditionalContent = true
		};
		JsonSerializer jsonSerializer = JsonSerializer.Create(settings);
		IDictionary<string, int> dictionary = jsonSerializer.Deserialize<Dictionary<string, int>>(new JsonTextReader(new StringReader(s)));
		Assert.IsNotNull(dictionary);
		Assert.AreEqual(1, dictionary["one"]);
	}

	[Test]
	public void CheckAdditionalContentCommentsThenAnotherObject()
	{
		string json = "{one:1} // This is just a comment\r\n/* This is just a comment\r\nover multiple\r\nlines.*/\r\n\r\n// This is just another comment. But here comes an empty object.\r\n{}";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			CheckAdditionalContent = true
		};
		JsonSerializer s = JsonSerializer.Create(settings);
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			s.Deserialize<Dictionary<string, int>>(new JsonTextReader(new StringReader(json)));
		}, new string[1] { "Additional text encountered after finished reading JSON content: {. Path '', line 7, position 0." });
	}

	[Test]
	public void AdditionalContentAfterFinish()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			string s = "[{},1]";
			JsonSerializer jsonSerializer = new JsonSerializer
			{
				CheckAdditionalContent = true
			};
			JsonTextReader jsonTextReader = new JsonTextReader(new StringReader(s));
			jsonTextReader.Read();
			jsonTextReader.Read();
			jsonSerializer.Deserialize(jsonTextReader, typeof(ItemConverterTestClass));
		}, new string[1] { "Additional text found in JSON string after finishing deserializing object. Path '[1]', line 1, position 5." });
	}

	[Test]
	public void AdditionalContentAfterFinishCheckNotRequested()
	{
		string s = "{ \"MyProperty\":{\"Key\":\"Value\"}} A bunch of junk at the end of the json";
		JsonSerializer jsonSerializer = new JsonSerializer();
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ItemConverterTestClass itemConverterTestClass = (ItemConverterTestClass)jsonSerializer.Deserialize(reader, typeof(ItemConverterTestClass));
		Assert.AreEqual(1, itemConverterTestClass.MyProperty.Count);
	}

	[Test]
	public void AdditionalContentAfterCommentsCheckNotRequested()
	{
		string s = "{ \"MyProperty\":{\"Key\":\"Value\"}} /*this is a comment */\r\n// this is also a comment\r\nThis is just junk, though.";
		JsonSerializer jsonSerializer = new JsonSerializer();
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		ItemConverterTestClass itemConverterTestClass = (ItemConverterTestClass)jsonSerializer.Deserialize(reader, typeof(ItemConverterTestClass));
		Assert.AreEqual(1, itemConverterTestClass.MyProperty.Count);
	}

	[Test]
	public void AdditionalContentAfterComments()
	{
		string s = "[{ \"MyProperty\":{\"Key\":\"Value\"}} /*this is a comment */\r\n// this is also a comment\r\n,{}";
		JsonSerializer serializer = new JsonSerializer();
		serializer.CheckAdditionalContent = true;
		JsonTextReader reader = new JsonTextReader(new StringReader(s));
		reader.Read();
		reader.Read();
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			serializer.Deserialize(reader, typeof(ItemConverterTestClass));
		}, new string[1] { "Additional text found in JSON string after finishing deserializing object. Path '[1]', line 3, position 2." });
	}

	[Test]
	public void DeserializeRelativeUri()
	{
		IList<Uri> list = JsonConvert.DeserializeObject<IList<Uri>>("[\"http://localhost/path?query#hash\"]");
		Assert.AreEqual(1, list.Count);
		Assert.AreEqual(new Uri("http://localhost/path?query#hash"), list[0]);
		Uri anObject = JsonConvert.DeserializeObject<Uri>("\"http://localhost/path?query#hash\"");
		Assert.IsNotNull(anObject);
		Uri expected = new Uri("http://localhost/path?query#hash", UriKind.RelativeOrAbsolute);
		Uri actual = new Uri("http://localhost/path?query#hash");
		Assert.AreEqual(expected, actual);
		anObject = JsonConvert.DeserializeObject<Uri>("\"/path?query#hash\"");
		Assert.IsNotNull(anObject);
		Assert.AreEqual(new Uri("/path?query#hash", UriKind.RelativeOrAbsolute), anObject);
	}

	[Test]
	public void DeserializeDictionaryItemConverter()
	{
		ItemConverterTestClass itemConverterTestClass = JsonConvert.DeserializeObject<ItemConverterTestClass>("{ \"MyProperty\":{\"Key\":\"Y\"}}");
		Assert.AreEqual("X", itemConverterTestClass.MyProperty["Key"]);
	}

	[Test]
	public void DeserializeCaseInsensitiveKeyValuePairConverter()
	{
		KeyValuePair<int, string> keyValuePair = JsonConvert.DeserializeObject<KeyValuePair<int, string>>("{key: 123, \"VALUE\": \"test value\"}");
		Assert.AreEqual(123, keyValuePair.Key);
		Assert.AreEqual("test value", keyValuePair.Value);
	}

	[Test]
	public void SerializeKeyValuePairConverterWithCamelCase()
	{
		string actual = JsonConvert.SerializeObject(new KeyValuePair<int, string>(123, "test value"), Formatting.Indented, new JsonSerializerSettings
		{
			ContractResolver = new CamelCasePropertyNamesContractResolver()
		});
		StringAssert.AreEqual("{\r\n  \"key\": 123,\r\n  \"value\": \"test value\"\r\n}", actual);
	}

	[Test]
	public void SerializeFloatingPointHandling()
	{
		IList<double> value = new List<double>
		{
			1.1,
			double.NaN,
			double.PositiveInfinity
		};
		string text = JsonConvert.SerializeObject(value);
		text = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			FloatFormatHandling = FloatFormatHandling.Symbol
		});
		text = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			FloatFormatHandling = FloatFormatHandling.DefaultValue
		});
		Assert.AreEqual("[1.1,0.0,0.0]", text);
	}

	[Test]
	public void DeserializeReadOnlyListWithInt()
	{
		string value = "[\r\n        900\r\n      ]";
		IReadOnlyList<int> readOnlyList = JsonConvert.DeserializeObject<IReadOnlyList<int>>(value);
		int num = readOnlyList[0];
		Assert.AreEqual(900, num);
	}

	[Test]
	public void DeserializeReadOnlyListWithNullableType()
	{
		string value = "[\r\n        1,\r\n        null\r\n      ]";
		IReadOnlyList<int?> readOnlyList = JsonConvert.DeserializeObject<IReadOnlyList<int?>>(value);
		Assert.AreEqual(1, readOnlyList[0]);
		Assert.AreEqual(null, readOnlyList[1]);
	}

	[Test]
	public void SerializeCustomTupleWithSerializableAttribute()
	{
		MyTuple<int> value = new MyTuple<int>(500);
		string json = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"m_Item1\":500}", json);
		MyTuple<int> obj = null;
		Action action = () =>
		{
			obj = JsonConvert.DeserializeObject<MyTuple<int>>(json);
		};
		ExceptionAssert.Throws<JsonSerializationException>(action, new string[1] { "Unable to find a constructor to use for type Newtonsoft.Json.Tests.TestObjects.MyTuple`1[System.Int32]. A class should either have a default constructor, one constructor with arguments or a constructor marked with the JsonConstructor attribute. Path 'm_Item1', line 1, position 11." });
	}

	[Test]
	public void SerializeCustomTupleWithSerializableAttributeInPartialTrust()
	{
		try
		{
			JsonTypeReflector.SetFullyTrusted(false);
			MyTuplePartial<int> value = new MyTuplePartial<int>(500);
			string json = JsonConvert.SerializeObject(value);
			Assert.AreEqual("{\"m_Item1\":500}", json);
			ExceptionAssert.Throws<JsonSerializationException>(() =>
			{
				JsonConvert.DeserializeObject<MyTuplePartial<int>>(json);
			}, new string[1] { "Unable to find a constructor to use for type Newtonsoft.Json.Tests.TestObjects.MyTuplePartial`1[System.Int32]. A class should either have a default constructor, one constructor with arguments or a constructor marked with the JsonConstructor attribute. Path 'm_Item1', line 1, position 11." });
		}
		finally
		{
			JsonTypeReflector.SetFullyTrusted(true);
		}
	}

	[Test]
	public void RoundtripOfDateTimeOffset()
	{
		string value = "{\"startDateTime\":\"2012-07-19T14:30:00+09:30\"}";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatHandling = DateFormatHandling.IsoDateFormat,
			DateParseHandling = DateParseHandling.DateTimeOffset,
			DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind
		};
		JObject jObject = (JObject)JsonConvert.DeserializeObject(value, settings);
		DateTimeOffset dateTimeOffset = (DateTimeOffset)((JValue)jObject["startDateTime"]).Value;
		Assert.AreEqual(TimeSpan.FromHours(9.5), dateTimeOffset.Offset);
		Assert.AreEqual("07/19/2012 14:30:00 +09:30", dateTimeOffset.ToString(CultureInfo.InvariantCulture));
	}

	[Test]
	public void NullableFloatingPoint()
	{
		NullableFloats value = new NullableFloats
		{
			Object = double.NaN,
			ObjectNull = null,
			Float = float.NaN,
			NullableDouble = double.NaN,
			NullableFloat = null
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			FloatFormatHandling = FloatFormatHandling.DefaultValue
		});
		StringAssert.AreEqual("{\r\n  \"Object\": 0.0,\r\n  \"Float\": 0.0,\r\n  \"Double\": 0.0,\r\n  \"NullableFloat\": null,\r\n  \"NullableDouble\": null,\r\n  \"ObjectNull\": null\r\n}", actual);
	}

	[Test]
	public void DateFormatString()
	{
		CultureInfo cultureInfo = new CultureInfo("en-NZ");
		cultureInfo.DateTimeFormat.AMDesignator = "a.m.";
		cultureInfo.DateTimeFormat.PMDesignator = "p.m.";
		IList<object> value = new List<object>
		{
			new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc),
			new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.FromHours(1.0))
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			DateFormatString = "yyyy tt",
			Culture = cultureInfo
		});
		StringAssert.AreEqual("[\r\n  \"2000 p.m.\",\r\n  \"2000 p.m.\"\r\n]", actual);
	}

	[Test]
	public void DateFormatStringForInternetExplorer()
	{
		IList<object> value = new List<object>
		{
			new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc),
			new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.FromHours(1.0))
		};
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			DateFormatString = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.fffK"
		});
		StringAssert.AreEqual("[\r\n  \"2000-12-12T12:12:12.000Z\",\r\n  \"2000-12-12T12:12:12.000+01:00\"\r\n]", actual);
	}

	[Test]
	public void JsonSerializerDateFormatString()
	{
		CultureInfo cultureInfo = new CultureInfo("en-NZ");
		cultureInfo.DateTimeFormat.AMDesignator = "a.m.";
		cultureInfo.DateTimeFormat.PMDesignator = "p.m.";
		IList<object> value = new List<object>
		{
			new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc),
			new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.FromHours(1.0))
		};
		StringWriter stringWriter = new StringWriter();
		JsonTextWriter jsonTextWriter = new JsonTextWriter(stringWriter);
		JsonSerializer jsonSerializer = JsonSerializer.Create(new JsonSerializerSettings
		{
			DateFormatString = "yyyy tt",
			Culture = cultureInfo,
			Formatting = Formatting.Indented
		});
		jsonSerializer.Serialize(jsonTextWriter, value);
		Assert.IsNull(jsonTextWriter.DateFormatString);
		Assert.AreEqual(CultureInfo.InvariantCulture, jsonTextWriter.Culture);
		Assert.AreEqual(Formatting.None, jsonTextWriter.Formatting);
		string actual = stringWriter.ToString();
		StringAssert.AreEqual("[\r\n  \"2000 p.m.\",\r\n  \"2000 p.m.\"\r\n]", actual);
	}

	[Test]
	public void SerializeDeserializeTuple()
	{
		Tuple<int, int> value = Tuple.Create(500, 20);
		string text = JsonConvert.SerializeObject(value);
		Assert.AreEqual("{\"Item1\":500,\"Item2\":20}", text);
		Tuple<int, int> tuple = JsonConvert.DeserializeObject<Tuple<int, int>>(text);
		Assert.AreEqual(500, tuple.Item1);
		Assert.AreEqual(20, tuple.Item2);
	}

	[Test]
	public void JsonSerializerStringEscapeHandling()
	{
		StringWriter stringWriter = new StringWriter();
		JsonTextWriter jsonTextWriter = new JsonTextWriter(stringWriter);
		JsonSerializer jsonSerializer = JsonSerializer.Create(new JsonSerializerSettings
		{
			StringEscapeHandling = StringEscapeHandling.EscapeHtml,
			Formatting = Formatting.Indented
		});
		jsonSerializer.Serialize(jsonTextWriter, new
		{
			html = "<html></html>"
		});
		Assert.AreEqual(StringEscapeHandling.Default, jsonTextWriter.StringEscapeHandling);
		string actual = stringWriter.ToString();
		StringAssert.AreEqual("{\r\n  \"html\": \"\\u003chtml\\u003e\\u003c/html\\u003e\"\r\n}", actual);
	}

	[Test]
	public void NoConstructorReadOnlyCollectionTest()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<NoConstructorReadOnlyCollection<int>>("[1]");
		}, new string[1] { "Cannot deserialize readonly or fixed size list: Newtonsoft.Json.Tests.TestObjects.NoConstructorReadOnlyCollection`1[System.Int32]. Path '', line 1, position 1." });
	}

	[Test]
	public void NoConstructorReadOnlyDictionaryTest()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<NoConstructorReadOnlyDictionary<int, int>>("{'1':1}");
		}, new string[1] { "Cannot deserialize readonly or fixed size dictionary: Newtonsoft.Json.Tests.TestObjects.NoConstructorReadOnlyDictionary`2[System.Int32,System.Int32]. Path '1', line 1, position 5." });
	}

	[Test]
	public void SerializeStructWithSerializableAndDataContract()
	{
		Pair<string, int> pair = new Pair<string, int>("One", 2);
		string actual = JsonConvert.SerializeObject(pair);
		Assert.AreEqual("{\"First\":\"One\",\"Second\":2}", actual);
	}

	[Test]
	public void ReadStringFloatingPointSymbols()
	{
		string value = "[\r\n  \"NaN\",\r\n  \"Infinity\",\r\n  \"-Infinity\"\r\n]";
		IList<float> list = JsonConvert.DeserializeObject<IList<float>>(value);
		Assert.AreEqual(float.NaN, list[0]);
		Assert.AreEqual(float.PositiveInfinity, list[1]);
		Assert.AreEqual(float.NegativeInfinity, list[2]);
		IList<double> list2 = JsonConvert.DeserializeObject<IList<double>>(value);
		Assert.AreEqual(float.NaN, list2[0]);
		Assert.AreEqual(float.PositiveInfinity, list2[1]);
		Assert.AreEqual(float.NegativeInfinity, list2[2]);
	}

	[Test]
	public void DefaultDateStringFormatVsUnsetDateStringFormat()
	{
		IDictionary<string, object> value = new Dictionary<string, object>
		{
			{
				"DateTime-Unspecified",
				new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Unspecified)
			},
			{
				"DateTime-Utc",
				new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Utc)
			},
			{
				"DateTime-Local",
				new DateTime(2000, 12, 12, 12, 12, 12, DateTimeKind.Local)
			},
			{
				"DateTimeOffset-Zero",
				new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.Zero)
			},
			{
				"DateTimeOffset-Plus1",
				new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.FromHours(1.0))
			},
			{
				"DateTimeOffset-Plus15",
				new DateTimeOffset(2000, 12, 12, 12, 12, 12, TimeSpan.FromHours(1.5))
			}
		};
		string expected = JsonConvert.SerializeObject(value, Formatting.Indented);
		string actual = JsonConvert.SerializeObject(value, Formatting.Indented, new JsonSerializerSettings
		{
			DateFormatString = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK"
		});
		Assert.AreEqual(expected, actual);
	}

	[Test]
	public void TestStringToNullableDeserialization()
	{
		string value = "{\r\n  \"MyNullableBool\": \"\",\r\n  \"MyNullableInteger\": \"\",\r\n  \"MyNullableDateTime\": \"\",\r\n  \"MyNullableDateTimeOffset\": \"\",\r\n  \"MyNullableDecimal\": \"\"\r\n}";
		NullableTestClass nullableTestClass = JsonConvert.DeserializeObject<NullableTestClass>(value);
		Assert.IsNull(nullableTestClass.MyNullableBool);
		Assert.IsNull(nullableTestClass.MyNullableInteger);
		Assert.IsNull(nullableTestClass.MyNullableDateTime);
		Assert.IsNull(nullableTestClass.MyNullableDateTimeOffset);
		Assert.IsNull(nullableTestClass.MyNullableDecimal);
	}

	[Test]
	public void HashSetInterface()
	{
		ISet<string> set = new HashSet<string>(new string[3] { "1", "two", "III" });
		string value = JsonConvert.SerializeObject(set);
		ISet<string> set2 = JsonConvert.DeserializeObject<ISet<string>>(value);
		Assert.AreEqual(set.Count, set2.Count);
		foreach (string item in set)
		{
			Assert.IsTrue(set2.Contains(item));
		}
	}

	[Test]
	public void DeserializeDecimal()
	{
		JsonTextReader reader = new JsonTextReader(new StringReader("1234567890.123456"));
		JsonSerializerSettings settings = new JsonSerializerSettings();
		JsonSerializer jsonSerializer = JsonSerializer.Create(settings);
		decimal? num = jsonSerializer.Deserialize<decimal?>(reader);
		Assert.AreEqual(1234567890.123456m, num);
	}

	[Test]
	public void DeserializeWithConstructor()
	{
		FooConstructor fooConstructor = JsonConvert.DeserializeObject<FooConstructor>("{\"something_else\":\"my value\"}");
		Assert.AreEqual("my value", fooConstructor.Bar);
	}

	[Test]
	public void SerializeCustomReferenceResolver()
	{
		PersonReference personReference = new PersonReference
		{
			Id = new Guid("0B64FFDF-D155-44AD-9689-58D9ADB137F3"),
			Name = "John Smith"
		};
		PersonReference personReference2 = (personReference.Spouse = new PersonReference
		{
			Id = new Guid("AE3C399C-058D-431D-91B0-A36C266441B9"),
			Name = "Jane Smith"
		});
		personReference2.Spouse = personReference;
		IList<PersonReference> value = new List<PersonReference> { personReference, personReference2 };
		string actual = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			ReferenceResolver = new IdReferenceResolver(),
			PreserveReferencesHandling = PreserveReferencesHandling.Objects,
			Formatting = Formatting.Indented
		});
		StringAssert.AreEqual("[\r\n  {\r\n    \"$id\": \"0b64ffdf-d155-44ad-9689-58d9adb137f3\",\r\n    \"Name\": \"John Smith\",\r\n    \"Spouse\": {\r\n      \"$id\": \"ae3c399c-058d-431d-91b0-a36c266441b9\",\r\n      \"Name\": \"Jane Smith\",\r\n      \"Spouse\": {\r\n        \"$ref\": \"0b64ffdf-d155-44ad-9689-58d9adb137f3\"\r\n      }\r\n    }\r\n  },\r\n  {\r\n    \"$ref\": \"ae3c399c-058d-431d-91b0-a36c266441b9\"\r\n  }\r\n]", actual);
	}

	[Test]
	public void NullReferenceResolver()
	{
		PersonReference personReference = new PersonReference
		{
			Id = new Guid("0B64FFDF-D155-44AD-9689-58D9ADB137F3"),
			Name = "John Smith"
		};
		PersonReference personReference2 = (personReference.Spouse = new PersonReference
		{
			Id = new Guid("AE3C399C-058D-431D-91B0-A36C266441B9"),
			Name = "Jane Smith"
		});
		personReference2.Spouse = personReference;
		IList<PersonReference> value = new List<PersonReference> { personReference, personReference2 };
		string actual = JsonConvert.SerializeObject(value, new JsonSerializerSettings
		{
			ReferenceResolver = null,
			PreserveReferencesHandling = PreserveReferencesHandling.Objects,
			Formatting = Formatting.Indented
		});
		StringAssert.AreEqual("[\r\n  {\r\n    \"$id\": \"1\",\r\n    \"Name\": \"John Smith\",\r\n    \"Spouse\": {\r\n      \"$id\": \"2\",\r\n      \"Name\": \"Jane Smith\",\r\n      \"Spouse\": {\r\n        \"$ref\": \"1\"\r\n      }\r\n    }\r\n  },\r\n  {\r\n    \"$ref\": \"2\"\r\n  }\r\n]", actual);
	}

	[Test]
	public void DeserializeCustomReferenceResolver()
	{
		string value = "[\r\n  {\r\n    \"$id\": \"0b64ffdf-d155-44ad-9689-58d9adb137f3\",\r\n    \"Name\": \"John Smith\",\r\n    \"Spouse\": {\r\n      \"$id\": \"ae3c399c-058d-431d-91b0-a36c266441b9\",\r\n      \"Name\": \"Jane Smith\",\r\n      \"Spouse\": {\r\n        \"$ref\": \"0b64ffdf-d155-44ad-9689-58d9adb137f3\"\r\n      }\r\n    }\r\n  },\r\n  {\r\n    \"$ref\": \"ae3c399c-058d-431d-91b0-a36c266441b9\"\r\n  }\r\n]";
		IList<PersonReference> list = JsonConvert.DeserializeObject<IList<PersonReference>>(value, new JsonSerializerSettings
		{
			ReferenceResolver = new IdReferenceResolver(),
			PreserveReferencesHandling = PreserveReferencesHandling.Objects,
			Formatting = Formatting.Indented
		});
		Assert.AreEqual(2, list.Count);
		PersonReference personReference = list[0];
		PersonReference personReference2 = list[1];
		Assert.AreEqual(personReference, personReference2.Spouse);
		Assert.AreEqual(personReference2, personReference.Spouse);
	}

	[Test]
	public void DeserializeCustomReferenceResolver_ViaProvider()
	{
		string value = "[\r\n  {\r\n    \"$id\": \"0b64ffdf-d155-44ad-9689-58d9adb137f3\",\r\n    \"Name\": \"John Smith\",\r\n    \"Spouse\": {\r\n      \"$id\": \"ae3c399c-058d-431d-91b0-a36c266441b9\",\r\n      \"Name\": \"Jane Smith\",\r\n      \"Spouse\": {\r\n        \"$ref\": \"0b64ffdf-d155-44ad-9689-58d9adb137f3\"\r\n      }\r\n    }\r\n  },\r\n  {\r\n    \"$ref\": \"ae3c399c-058d-431d-91b0-a36c266441b9\"\r\n  }\r\n]";
		IList<PersonReference> list = JsonConvert.DeserializeObject<IList<PersonReference>>(value, new JsonSerializerSettings
		{
			ReferenceResolverProvider = () => new IdReferenceResolver(),
			PreserveReferencesHandling = PreserveReferencesHandling.Objects,
			Formatting = Formatting.Indented
		});
		Assert.AreEqual(2, list.Count);
		PersonReference personReference = list[0];
		PersonReference personReference2 = list[1];
		Assert.AreEqual(personReference, personReference2.Spouse);
		Assert.AreEqual(personReference2, personReference.Spouse);
	}

	[Test]
	public void Main()
	{
		ParticipantEntity participantEntity = new ParticipantEntity();
		participantEntity.Properties = new Dictionary<string, string> { { "s", "d" } };
		string text = JsonConvert.SerializeObject(participantEntity);
		Assert.AreEqual("{\"pa_info\":{\"s\":\"d\"}}", text);
		ParticipantEntity participantEntity2 = JsonConvert.DeserializeObject<ParticipantEntity>(text);
	}

	[Test]
	public void DuplicatePropertiesInNestedObject()
	{
		string value = "{\"result\":{\"time\":1408188592,\"time\":1408188593},\"error\":null,\"id\":\"1\"}";
		JObject jObject = JsonConvert.DeserializeObject<JObject>(value);
		int num = (int)jObject["result"]["time"];
		Assert.AreEqual(1408188593, num);
	}

	[Test]
	public void RoundtripUriOriginalString()
	{
		string text = "https://test.com?m=a%2bb";
		Uri value = new Uri(text);
		string value2 = JsonConvert.SerializeObject(value);
		Uri uri = JsonConvert.DeserializeObject<Uri>(value2);
		Assert.AreEqual(text, uri.OriginalString);
	}

	[Test]
	public void DateFormatStringWithDateTime()
	{
		DateTime dateTime = new DateTime(2000, 12, 22);
		string dateFormatString = "yyyy'-pie-'MMM'-'dddd'-'dd";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatString = dateFormatString
		};
		string text = JsonConvert.SerializeObject(dateTime, settings);
		Assert.AreEqual("\"2000-pie-Dec-Friday-22\"", text);
		DateTime dateTime2 = JsonConvert.DeserializeObject<DateTime>(text, settings);
		Assert.AreEqual(dateTime, dateTime2);
		JsonTextReader reader = new JsonTextReader(new StringReader(text))
		{
			DateFormatString = dateFormatString
		};
		JValue jValue = (JValue)JToken.ReadFrom(reader);
		Assert.AreEqual(JTokenType.Date, jValue.Type);
		Assert.AreEqual(typeof(DateTime), jValue.Value.GetType());
		Assert.AreEqual(dateTime, (DateTime)jValue.Value);
		reader = new JsonTextReader(new StringReader("\"abc\""))
		{
			DateFormatString = dateFormatString
		};
		jValue = (JValue)JToken.ReadFrom(reader);
		Assert.AreEqual(JTokenType.String, jValue.Type);
		Assert.AreEqual(typeof(string), jValue.Value.GetType());
		Assert.AreEqual("abc", jValue.Value);
	}

	[Test]
	public void DateFormatStringWithDateTimeAndCulture()
	{
		CultureInfo culture = new CultureInfo("tr-TR");
		DateTime dateTime = new DateTime(2000, 12, 22);
		string dateFormatString = "yyyy'-pie-'MMM'-'dddd'-'dd";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatString = dateFormatString,
			Culture = culture
		};
		string text = JsonConvert.SerializeObject(dateTime, settings);
		Assert.AreEqual("\"2000-pie-Ara-Cuma-22\"", text);
		DateTime dateTime2 = JsonConvert.DeserializeObject<DateTime>(text, settings);
		Assert.AreEqual(dateTime, dateTime2);
		JsonTextReader reader = new JsonTextReader(new StringReader(text))
		{
			DateFormatString = dateFormatString,
			Culture = culture
		};
		JValue jValue = (JValue)JToken.ReadFrom(reader);
		Assert.AreEqual(JTokenType.Date, jValue.Type);
		Assert.AreEqual(typeof(DateTime), jValue.Value.GetType());
		Assert.AreEqual(dateTime, (DateTime)jValue.Value);
		reader = new JsonTextReader(new StringReader("\"2000-pie-Dec-Friday-22\""))
		{
			DateFormatString = dateFormatString,
			Culture = culture
		};
		jValue = (JValue)JToken.ReadFrom(reader);
		Assert.AreEqual(JTokenType.String, jValue.Type);
		Assert.AreEqual(typeof(string), jValue.Value.GetType());
		Assert.AreEqual("2000-pie-Dec-Friday-22", jValue.Value);
	}

	[Test]
	public void DateFormatStringWithDictionaryKey_DateTime()
	{
		DateTime dateTime = new DateTime(2000, 12, 22);
		string dateFormatString = "yyyy'-pie-'MMM'-'dddd'-'dd";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatString = dateFormatString,
			Formatting = Formatting.Indented
		};
		string text = JsonConvert.SerializeObject(new Dictionary<DateTime, string> { { dateTime, "123" } }, settings);
		StringAssert.AreEqual("{\r\n  \"2000-pie-Dec-Friday-22\": \"123\"\r\n}", text);
		Dictionary<DateTime, string> dictionary = JsonConvert.DeserializeObject<Dictionary<DateTime, string>>(text, settings);
		Assert.AreEqual(dateTime, dictionary.Keys.ElementAt(0));
	}

	[Test]
	public void DateFormatStringWithDictionaryKey_DateTime_ReadAhead()
	{
		DateTime dateTime = new DateTime(2000, 12, 22);
		string dateFormatString = "yyyy'-pie-'MMM'-'dddd'-'dd";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatString = dateFormatString,
			MetadataPropertyHandling = MetadataPropertyHandling.ReadAhead,
			Formatting = Formatting.Indented
		};
		string text = JsonConvert.SerializeObject(new Dictionary<DateTime, string> { { dateTime, "123" } }, settings);
		StringAssert.AreEqual("{\r\n  \"2000-pie-Dec-Friday-22\": \"123\"\r\n}", text);
		Dictionary<DateTime, string> dictionary = JsonConvert.DeserializeObject<Dictionary<DateTime, string>>(text, settings);
		Assert.AreEqual(dateTime, dictionary.Keys.ElementAt(0));
	}

	[Test]
	public void DateFormatStringWithDictionaryKey_DateTimeOffset()
	{
		DateTimeOffset dateTimeOffset = new DateTimeOffset(2000, 12, 22, 0, 0, 0, TimeSpan.Zero);
		string dateFormatString = "yyyy'-pie-'MMM'-'dddd'-'dd'!'K";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatString = dateFormatString,
			Formatting = Formatting.Indented
		};
		string text = JsonConvert.SerializeObject(new Dictionary<DateTimeOffset, string> { { dateTimeOffset, "123" } }, settings);
		StringAssert.AreEqual("{\r\n  \"2000-pie-Dec-Friday-22!+00:00\": \"123\"\r\n}", text);
		Dictionary<DateTimeOffset, string> dictionary = JsonConvert.DeserializeObject<Dictionary<DateTimeOffset, string>>(text, settings);
		Assert.AreEqual(dateTimeOffset, dictionary.Keys.ElementAt(0));
	}

	[Test]
	public void DateFormatStringWithDictionaryKey_DateTimeOffset_ReadAhead()
	{
		DateTimeOffset dateTimeOffset = new DateTimeOffset(2000, 12, 22, 0, 0, 0, TimeSpan.Zero);
		string dateFormatString = "yyyy'-pie-'MMM'-'dddd'-'dd'!'K";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatString = dateFormatString,
			MetadataPropertyHandling = MetadataPropertyHandling.ReadAhead,
			Formatting = Formatting.Indented
		};
		string text = JsonConvert.SerializeObject(new Dictionary<DateTimeOffset, string> { { dateTimeOffset, "123" } }, settings);
		StringAssert.AreEqual("{\r\n  \"2000-pie-Dec-Friday-22!+00:00\": \"123\"\r\n}", text);
		Dictionary<DateTimeOffset, string> dictionary = JsonConvert.DeserializeObject<Dictionary<DateTimeOffset, string>>(text, settings);
		Assert.AreEqual(dateTimeOffset, dictionary.Keys.ElementAt(0));
	}

	[Test]
	public void DateFormatStringWithDateTimeOffset()
	{
		DateTimeOffset dateTimeOffset = new DateTimeOffset(new DateTime(2000, 12, 22));
		string dateFormatString = "yyyy'-pie-'MMM'-'dddd'-'dd";
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			DateFormatString = dateFormatString
		};
		string text = JsonConvert.SerializeObject(dateTimeOffset, settings);
		Assert.AreEqual("\"2000-pie-Dec-Friday-22\"", text);
		DateTimeOffset dateTimeOffset2 = JsonConvert.DeserializeObject<DateTimeOffset>(text, settings);
		Assert.AreEqual(dateTimeOffset, dateTimeOffset2);
		JsonTextReader reader = new JsonTextReader(new StringReader(text))
		{
			DateFormatString = dateFormatString,
			DateParseHandling = DateParseHandling.DateTimeOffset
		};
		JValue jValue = (JValue)JToken.ReadFrom(reader);
		Assert.AreEqual(JTokenType.Date, jValue.Type);
		Assert.AreEqual(typeof(DateTimeOffset), jValue.Value.GetType());
		Assert.AreEqual(dateTimeOffset, (DateTimeOffset)jValue.Value);
	}

	[Test]
	public void DeserializeConstantProperty()
	{
		ConstantTestClass value = new ConstantTestClass();
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"MY_CONSTANT\": \".\"\r\n}", text);
		JsonConvert.DeserializeObject<ConstantTestClass>(text);
	}

	[Test]
	public void SerializeObjectWithEvent()
	{
		MyObservableObject value = new MyObservableObject
		{
			TestString = "Test string"
		};
		string text = JsonConvert.SerializeObject(value, Formatting.Indented);
		StringAssert.AreEqual("{\r\n  \"PropertyChanged\": null,\r\n  \"TestString\": \"Test string\"\r\n}", text);
		MyObservableObject myObservableObject = JsonConvert.DeserializeObject<MyObservableObject>(text);
		Assert.AreEqual("Test string", myObservableObject.TestString);
	}

	[Test]
	public void ParameterizedConstructorWithBasePrivateProperties()
	{
		DerivedConstructorType value = new DerivedConstructorType("Base", "Derived");
		JsonSerializerSettings settings = new JsonSerializerSettings();
		string value2 = JsonConvert.SerializeObject(value, settings);
		DerivedConstructorType derivedConstructorType = JsonConvert.DeserializeObject<DerivedConstructorType>(value2, settings);
		Assert.AreEqual("Base", derivedConstructorType.BaseProperty);
		Assert.AreEqual("Derived", derivedConstructorType.DerivedProperty);
	}

	[Test]
	public void ErrorCreatingJsonConverter()
	{
		ExceptionAssert.Throws<JsonException>(() =>
		{
			JsonConvert.SerializeObject(new ErroringTestClass());
		}, new string[1] { "Error creating 'Newtonsoft.Json.Tests.TestObjects.ErroringJsonConverter'." });
	}

	[Test]
	public void DeserializeInvalidOctalRootError()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<string>("020474068");
		}, new string[1] { "Input string '020474068' is not a valid number. Path '', line 1, position 9." });
	}

	[Test]
	public void DeserializedDerivedWithPrivate()
	{
		string value = "{\r\n  \"DerivedProperty\": \"derived\",\r\n  \"BaseProperty\": \"base\"\r\n}";
		DerivedWithPrivate derivedWithPrivate = JsonConvert.DeserializeObject<DerivedWithPrivate>(value);
		Assert.AreEqual("base", derivedWithPrivate.BaseProperty);
		Assert.AreEqual("derived", derivedWithPrivate.DerivedProperty);
	}

	[Test]
	public void MailMessageConverterTest()
	{
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<MailMessage>("{\r\n  \"From\": {\r\n    \"Address\": \"askywalker@theEmpire.gov\",\r\n    \"DisplayName\": \"Darth Vader\"\r\n  },\r\n  \"Sender\": null,\r\n  \"ReplyTo\": null,\r\n  \"ReplyToList\": [],\r\n  \"To\": [\r\n    {\r\n      \"Address\": \"lskywalker@theRebellion.org\",\r\n      \"DisplayName\": \"Luke Skywalker\"\r\n    }\r\n  ],\r\n  \"Bcc\": [],\r\n  \"CC\": [\r\n    {\r\n      \"Address\": \"lorgana@alderaan.gov\",\r\n      \"DisplayName\": \"Princess Leia\"\r\n    }\r\n  ],\r\n  \"Priority\": 0,\r\n  \"DeliveryNotificationOptions\": 0,\r\n  \"Subject\": \"Family tree\",\r\n  \"SubjectEncoding\": null,\r\n  \"Headers\": [],\r\n  \"HeadersEncoding\": null,\r\n  \"Body\": \"<strong>I am your father!</strong>\",\r\n  \"BodyEncoding\": \"US-ASCII\",\r\n  \"BodyTransferEncoding\": -1,\r\n  \"IsBodyHtml\": true,\r\n  \"Attachments\": [\r\n    {\r\n      \"FileName\": \"skywalker family tree.jpg\",\r\n      \"ContentBase64\": \"AQIDBAU=\"\r\n    }\r\n  ],\r\n  \"AlternateViews\": []\r\n}", new JsonConverter[3]
			{
				new MailAddressReadConverter(),
				new AttachmentReadConverter(),
				new EncodingReadConverter()
			});
		}, new string[1] { "Cannot populate list type System.Net.Mime.HeaderCollection. Path 'Headers', line 26, position 14." });
	}

	[Test]
	public void ParametrizedConstructor_IncompleteJson()
	{
		string s = "{\"text\":\"s\",\"cursorPosition\":189,\"dataSource\":\"json_northwind\",";
		ExceptionAssert.Throws<JsonSerializationException>(() =>
		{
			JsonConvert.DeserializeObject<CompletionDataRequest>(s);
		}, new string[1] { "Unexpected end when deserializing object. Path 'dataSource', line 1, position 63." });
	}

	[Test]
	public void ChildClassWithProtectedOverridePlusJsonProperty_Serialize()
	{
		JsonObjectContract jsonObjectContract = (JsonObjectContract)DefaultContractResolver.Instance.ResolveContract(typeof(ChildClassWithProtectedOverridePlusJsonProperty));
		Assert.AreEqual(1, jsonObjectContract.Properties.Count);
		string text = "test";
		string value = "{ 'MyProperty' : '" + text + "' }";
		ChildClassWithProtectedOverridePlusJsonProperty childClassWithProtectedOverridePlusJsonProperty = JsonConvert.DeserializeObject<ChildClassWithProtectedOverridePlusJsonProperty>(value);
		Assert.AreEqual(text, childClassWithProtectedOverridePlusJsonProperty.GetPropertyValue(), "MyProperty should be populated");
	}

	[Test]
	public void JsonPropertyConverter()
	{
		DateTime dateTime = new DateTime(2000, 12, 20, 0, 0, 0, DateTimeKind.Utc);
		JsonSerializerSettings settings = new JsonSerializerSettings
		{
			ContractResolver = new JsonPropertyConverterContractResolver(),
			Formatting = Formatting.Indented
		};
		JsonPropertyConverterTestClass value = new JsonPropertyConverterTestClass
		{
			NormalDate = dateTime,
			JavaScriptDate = dateTime
		};
		string text = JsonConvert.SerializeObject(value, settings);
		StringAssert.AreEqual("{\r\n  \"NormalDate\": \"2000-12-20T00:00:00Z\",\r\n  \"JavaScriptDate\": new Date(\r\n    977270400000\r\n  )\r\n}", text);
		JsonPropertyConverterTestClass jsonPropertyConverterTestClass = JsonConvert.DeserializeObject<JsonPropertyConverterTestClass>(text, settings);
		Assert.AreEqual(dateTime, jsonPropertyConverterTestClass.NormalDate);
		Assert.AreEqual(dateTime, jsonPropertyConverterTestClass.JavaScriptDate);
	}

	[Test]
	public void StringEmptyValue()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<EmptyJsonValueTestClass>("{ A: , B: 1, C: 123, D: 1.23, E: 3.45, F: null }");
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path 'A', line 1, position 6." });
	}

	[Test]
	public void NullableIntEmptyValue()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<EmptyJsonValueTestClass>("{ A: \"\", B: , C: 123, D: 1.23, E: 3.45, F: null }");
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path 'B', line 1, position 13." });
	}

	[Test]
	public void NullableLongEmptyValue()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<EmptyJsonValueTestClass>("{ A: \"\", B: 1, C: , D: 1.23, E: 3.45, F: null }");
		}, new string[1] { "An undefined token is not a valid System.Nullable`1[System.Int64]. Path 'C', line 1, position 18." });
	}

	[Test]
	public void NullableDecimalEmptyValue()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<EmptyJsonValueTestClass>("{ A: \"\", B: 1, C: 123, D: , E: 3.45, F: null }");
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path 'D', line 1, position 27." });
	}

	[Test]
	public void NullableDoubleEmptyValue()
	{
		ExceptionAssert.Throws<JsonReaderException>(() =>
		{
			JsonConvert.DeserializeObject<EmptyJsonValueTestClass>("{ A: \"\", B: 1, C: 123, D: 1.23, E: , F: null }");
		}, new string[1] { "Unexpected character encountered while parsing value: ,. Path 'E', line 1, position 36." });
	}
}
